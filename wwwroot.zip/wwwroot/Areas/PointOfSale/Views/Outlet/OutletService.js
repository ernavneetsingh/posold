﻿
'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getData = function (propertyId) {
            
            var url = apiPath + 'PointOfSale/Outlet/allByPropertyIdmin2/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                deferred.resolve(result.Collection);
            }).error(function (err) {
                
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getById = function (id) {

            var url = apiPath + 'PointOfSale/Outlet/GetById/' + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Data);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetKOTType = function () {
            var url = apiPath + 'ReferenceConstant/KOTInitializeType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetOutletType = function () {
            var url = apiPath + 'ReferenceConstant/OutletType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetClassification = function () {
            var url = apiPath + 'ReferenceConstant/ClassificationType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetRoundOff = function () {
            var url = apiPath + 'ReferenceConstant/RoundOffType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetBillInitializeType = function () {
            var url = apiPath + 'ReferenceConstant/KOTInitializeType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetCostCenter = function (propertyId, active) {

            var url = apiPath + "GlobalSetting/CostCenter/all/?propertyId=" + propertyId + "&active=" + active;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var save = function (model) {

            var url = apiPath + 'PointOfSale/Outlet/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var remove = function (id) {

            var url = apiPath + 'PointOfSale/Outlet/delete/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                msg(data.Message);
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {

            var url = apiPath + 'PointOfSale/Outlet/status';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var isCodeExist = function (PropertId, code) {

            var url = apiPath + 'PointOfSale/Outlet/IsCodeExist/' + PropertId + "/" + code;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        return {
            getData: getData,
            getById:getById,
            GetKOTType: GetKOTType,
            GetClassification: GetClassification,
            GetRoundOff: GetRoundOff,
            GetBillInitializeType: GetBillInitializeType,
            GetOutletType: GetOutletType,
            GetCostCenter: GetCostCenter,
            save: save,
            remove: remove,
            statusChange: statusChange,
            isCodeExist: isCodeExist
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
