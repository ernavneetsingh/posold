﻿
app.service('GuestMessageService', [
    '$http', '$q', '$window', '$filter', function (
        $http, $q, $window, $filter) {

        var service = this;
        service.init = function ($scope, notClosable) {
            service.notClosable = notClosable;
            $scope.beforePopup = function (group, messageForTypeId, receiver, messageTypeId) {

                $scope.group = group;
                $scope.groupItem = 0;
                service.messageForTypeId = messageForTypeId;
                service.receiver = receiver;
                service.messageTypeId = messageTypeId;
                $scope.SetCheckINGuest(receiver.Id);
            };

            service.next = function (ahead) {
                if (ahead) {
                    if ($scope.groupItem < $scope.group.items.length - 1) $scope.groupItem++;
                } else {
                    if ($scope.groupItem > 0) $scope.groupItem--;
                }
            };
            service.acknowledge = function (model) {

                if (!$scope['MessageAcknowledgeForm'].$valid) {
                    $scope.ShowErrorMessageA = true;
                    return;
                }
                model.ModifiedBy = $scope.ModifiedBy;
                model.MessageActionId = 3;
                model.MessageAcknowledgeOn = $scope.ModifiedDate;

                service.save(model).then(function (d) {
                    msg("Message acknowledged successfully.", d.Status);
                    $('#modalGuestMessage').modal('hide');
                    if (!service.receiver)
                        $scope.reset();
                    else
                        service.getMessageList(service.messageForTypeId, service.receiver, service.messageTypeId);
                });
            };
            service.save = function (model) {
                return httpPoster(apiPath + "FrontOffice/Messenger/Save", $http, $q, model);
            };
            service.getMessageListCaller = function (propertyId, messageForTypeId, messageForId, messageTypeId) {
                return httpCaller(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId", $http, $q, { propertyId: propertyId, messageTypeId: messageTypeId, messageForTypeId: messageForTypeId, messageActionId: 12, messageForId: messageForId, numberofdays: 20 });
            };
            service.getMessageList = function (messageForTypeId, receiver, messageTypeId) {

                service.getMessageListCaller($scope.PropertyID, messageForTypeId, receiver.Id, messageTypeId).then(function (m) {
                    if (!receiver.count) receiver.count = [];
                    if (!receiver.messages) receiver.messages = [];
                    if (!receiver.group) receiver.group = [];
                    receiver.count[messageTypeId] = m.Collection.length;
                    receiver.messages[messageTypeId] = $filter('groupBy')(m.Collection, 'MessageToName', 'RoomNumber');
                    receiver.group[messageTypeId] = receiver.messages[messageTypeId]['0000'];
                }, function (e) {
                    msg(e.Message);
                });
            };
            service.MapReport = function (filterValue, reportName) {
                return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
            };
            service.print = function () {
                service.MapReport($scope.PropertyID, 'guestmessage')
                           .then(function (s) {
                               $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + $scope.group.items[$scope.groupItem].Id, '_blank');
                           }, function (e) {
                               msgInPopup('Error in mapping to print.');
                           });
            };

            return service;
        };

    }
]);
