﻿
app.service('CheckINService', [
    "$http", "$q", '$filter', function ($http, $q, $filter) {

        //TODO: Navneet2.0
         this.GetConstantByPropertyId = function(propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckIN/GetConstantByPropertyId/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        //TODO: Navneet2.0
        this.GetSetup = function (propertyId, id) {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetSetup/" + propertyId, $http, $q);
        };

        //TODO: Navneet2.0
        this.saveRoomStatus = function (model) {

            var deferred = $q.defer();
            var url = apiPath + 'FrontOffice/RoomStatus/SaveStatus';
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };

        this.getRoomFeatureRoom = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/RoomChart/GetRoomChartRoomFeatureRoom/" + propertyId, $http, $q, {});
        };

        this.SearchReservationList = function (item) {
            return httpPoster(apiPath + "FrontOffice/Reservation/SearchExact", $http, $q, item);
        };
        this.getReservationSearch = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/Search", $http, $q, model);
        };
        this.getReservationList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/Reservation/AllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getReservation = function (propertyId, id, businessDate) {
            return httpCaller(apiPath + "FrontOffice/Reservation/GetById/" + id + "/" + propertyId + "/" + businessDate, $http, $q);
        };

        this.getRoomTypeList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/RoomType/GetAllByPropertyIdMin", $http, $q, { propertyId: propertyId });
        };
        this.getRoomList = function (propertyId, roomTypeId, featureId, floorId, blockId, roomStatusId, statusDate) {
            return httpCaller(apiPath + "FrontOffice/RoomMaster/Search", $http, $q, { propertyId: propertyId, roomTypeId: roomTypeId, featureId: featureId || 'All', floorId: floorId || 'All', blockId: blockId || 'All', roomStatusId: roomStatusId || 'All', statusDate: statusDate });
        };
        this.getRate = function (propertyId, id) {
            return httpCaller(apiPath + "FrontOffice/RateMaster/getById/" + id, $http, $q);
        };

        this.getMealPlanList = function () {
            return httpCaller(apiPath + "referencedata/MealPlan", $http, $q);
        };
        this.getStateList = function (countryId) {
            return httpCaller(apiPath + "referencedata/state/" + countryId, $http, $q);
        };
        //this.getBookingTypeList = function () {
        //    return httpCaller(apiPath + "ReferenceConstant/BookingType/All", $http, $q);
        //};
        //this.getPaxTypeList = function (propertyId) {
        //    return httpCaller(apiPath + "ReferenceConstant/PaxType/All?propertyId=" + propertyId, $http, $q);
        //};
        this.getAmenitiesList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/amenities/all/" + propertyId, $http, $q);
        }
        //this.getTravelTypeList = function () {
        //    return httpCaller(apiPath + "ReferenceConstant/TravelType/all", $http, $q);
        //};
        //this.getVisitTypeList = function () {
        //    return httpCaller(apiPath + "ReferenceConstant/VisitType/all", $http, $q);
        //};
        this.getGuestHistory = function (propertyId, guestId) {
            return httpCaller(apiPath + "FrontOffice/Guest/GetById/" + guestId, $http, $q);
        };
        this.getCorporateDiscountList = function (propertyId, corporateId) {
            return httpCaller(apiPath + "GlobalSetting/CorporateDiscount/GetAllByCorporateId/" + corporateId + "/" + propertyId, $http, $q);
        };
        //this.getDefaultSettings = function (propertyId) {
        //    return httpCaller(apiPath + "GlobalSetting/DefaultSetting/Details/" + propertyId, $http, $q);
        //};
        this.getAllGuestByName = function (propertyId, name) {
            return httpCaller(apiPath + "FrontOffice/Guest/GetAllByName/" + propertyId + "/" + name, $http, $q);
        };
        this.getAllGuestByMobile = function (propertyId, mobileNumber) {
            return httpCaller(apiPath + "FrontOffice/Guest/GetAllByMobile/" + propertyId + "/" + mobileNumber, $http, $q);
        };
        //this.getPickupDropTypes = function () {
        //    return httpCaller(apiPath + "ReferenceConstant/PickupDropType/All", $http, $q);
        //};
        this.getLocationTypes = function () {
            return httpCaller(apiPath + "ReferenceConstant/LocationType/All", $http, $q);
        };

        this.getDates = function (propertyId, date, period) {
            return httpCaller(apiPath + "FrontOffice/Reservation/GetDates", $http, $q, { propertyId: propertyId, date: date, period: period, min: true });
        };
        this.getRoomStatus = function (propertyId, roomMasterId, date) {
            return httpCaller(apiPath + "FrontOffice/RoomStatus/RoomStatusByDate", $http, $q, { propertyId: propertyId, roomMasterId: roomMasterId, date: date });
        };


        this.get = function (propertyId, id) {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetById/" + id + "/" + propertyId, $http, $q);
        };
        this.getByReservation = function (propertyId, reservationId) {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetByReservationId/" + reservationId + "/" + propertyId, $http, $q);
        };

        this.ChangeRoom = function (propertyId, roomMasterId) {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetByRoom", $http, $q, { propertyId: propertyId, roomMasterId: roomMasterId });
        };
        this.getCurrentRoomGuests = function (roomMasterId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetCurrentRoomGuests", $http, $q, { roomMasterId: roomMasterId, businessDate: businessDate });
        };
        this.getAllCheckINGuestByRoomId = function (roomMasterId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetAllByRoomId", $http, $q, { roomMasterId: roomMasterId });
        };

        this.saveGuest = function (model) {
            return httpPoster(apiPath + "FrontOffice/Guest/Save", $http, $q, model);
        };
        this.saveGuestWithPassport = function (model) {
            return httpPoster(apiPath + "FrontOffice/Guest/SaveWithPassportNo", $http, $q, model);
        };
        //this.save = function (model) {
        //    return httpPoster(apiPath + "FrontOffice/CheckIN/Save", $http, $q, model);
        //};
        this.saveWalkIN = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckIN/SaveWalkIN", $http, $q, model);
        };
        this.remove = function (propertyId, id) {
            var params = { propertyId: propertyId, id: id };
            return httpCaller(apiPath + "FrontOffice/CheckIN/Delete", $http, $q, params);
        };

        //this.getMessageList = function (propertyId, messageTypeId, messageForTypeId, messageForId) {
        //    return httpCaller(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId", $http, $q, { propertyId: propertyId, messageTypeId: messageTypeId, messageForTypeId: messageForTypeId, messageForId: messageForId, messageActionId: 1 });
        //};
        this.getCreditCardNetworkList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/CorporateCreditCardNetwork/GetAllActiveByPropertyId/" + propertyId, $http, $q);
        }

        this.getRoom = function (propertyId, id) {
            return httpCaller(apiPath + "FrontOffice/RoomMaster/GetById/" + propertyId + "/" + id, $http, $q);
        };
        this.getServerTime = function () {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetServerTime", $http, $q);
        };

        this.GetRateByCorporateId = function (id) {
            return httpCaller(apiPath + "GlobalSetting/Corporate/GetRateByCorporateId/" + id, $http, $q);
        };

        this.MapReport = function (filterValue, reportName) {
            return httpCaller1(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
        };
        var httpCaller1 = function (url, $http, $q, params) {

            var config = { headers: headers, params: params };
            var deferred = $q.defer();
            $http.defaults.useXDomain = true;
            try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e4) { }
            $http.get(url, config)
                .then(function (response) {
                    deferred.resolve(response.data);
                })
                .catch(function (ex) {

                    msg("Error in calling : " + url);
                    //msg(ex.data.Message);
                    deferred.reject(ex.data, status);
                });
            return deferred.promise;
        }

        this.GetBillsByParentId = function (propertyId, chargePostToId, chargePostId, parentId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetByParentId", $http, $q, { propertyId: propertyId, chargePostToId: chargePostToId, chargePostId: chargePostId, parentId: parentId });
        }

        this.saveCorporate = function (model) {
            return httpPoster(apiPath + "GlobalSetting/corporate/save", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "GlobalSetting/corporate/save",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };
        //this.getDesignationList = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "GlobalSetting/designation/GetAllByModuleId/" + propertyId + "/7")
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};
        //this.getCorporateTypes = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "GlobalSetting/PropertyCorporateType/GetAll?propertyid=" + propertyId)
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};
        //this.getCorporateCategory = function () {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "ReferenceConstant/CorporateCategory/all")
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};
        //this.getCorporate = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "GlobalSetting/Corporate/GetAllByPropertyIdMin/" + propertyId)
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};
        this.getCorporateByCode = function (code, propertyid) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/corporate/GetByCode/" + code + "/" + propertyid)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        this.getAllState = function (id) {
            var url = apiPath + 'referencedata/state/' + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {}
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        this.getCorporateById = function (corporateId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "/GlobalSetting/corporate/GetById/" + corporateId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };
        this.getByModuleSettingName = function (propertyId, moduleSettingName, error_suppress) {
            var params = { propertyId: propertyId, moduleSettingName: moduleSettingName };
            return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/get", $http, $q, params, error_suppress);
        };

        

        this.sendSMS = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/SendSMS", $http, $q, model);
        };
        this.sendEMail = function (model) {
            return httpPoster(apiPath + "GlobalSetting/EMail/Sent", $http, $q, model);
        };

        this.sendCheckINEMail = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckIN/SendEMail", $http, $q, model);
        };

        this.getAddSendLinkTemplate = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckIN/GetAddSendLinkTemplate", $http, $q, model);
        };
        this.saveCheckINGuestVerification = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckINVerification/Save", $http, $q, model);
        };

        this.getCheckINGuestVerification = function (guid) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckINVerification/GetByGUID/" + guid,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        this.getGuestById = function (id) {
            var deferred = $q.defer();
            $http.get(apiPath + "frontoffice/Guest/GetById/" + id)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        this.showHistoryComplaints = function (propertyId, checkINGuestId) {
            return httpCaller(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId", $http, $q, { propertyId: propertyId, messageTypeId: '3', messageToTypeId: 5, messageToId: checkINGuestId });
        };

        this.GetCheckINGuestRoomInterPropertyTransfer = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuestRoomInterPropertyTransfer/GetAllByPropertyId/" + propertyId, $http, $q, { });
        };

        this.GetByCheckINGuestRoomId = function (id) {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetByCheckINGuestRoomId/" + id, $http, $q, {});
        };

        this.GetReceipts = function (propertyId, chargePostToId, chargePostId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetReceipts", $http, $q, { propertyId: propertyId, chargePostToId: chargePostToId, chargePostId: chargePostId });
        };
        this.GetRefunds = function (propertyId, chargePostToId, chargePostId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetRefunds", $http, $q, { propertyId: propertyId, chargePostToId: chargePostToId, chargePostId: chargePostId });
        };
    }
]);
