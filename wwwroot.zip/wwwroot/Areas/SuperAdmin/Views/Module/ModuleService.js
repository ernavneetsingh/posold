﻿'use strict';


(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var model = [];

        var getAll = function (options) {

            var url = apiPath + "configuration/module?currentPage=" + options.currentPage + "&" +
               "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: options,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                angular.forEach(result.Collection, function (data, key) {
                    
                    result.Collection[key].UploadFile = apiPath + "/" + data.UploadFile;

                });

                angular.copy(result.Collection, model);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
      
        var save = function (model) {
            
            var url = apiPath + 'configuration/module/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isNameExist = function (model) {
            
            var url = apiPath + 'configuration/module/exist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isOrderSNoExist = function (model) {
            
            var url = apiPath + 'configuration/module/orderexist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var changeStatus = function (id) {
            
            var url = apiPath + 'configuration/module/status/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var uploadFile = function (file) {
            
            var formData = new FormData();
            formData.append("file", file);
            var defer = $q.defer();
            $http.post(apiPath + 'Upload/File/' + "SPA/Module", formData,
                {
                    withCredentials: true,
                    //headers: { 'Content-Type': undefined },
                    "duxtechApiKey": accessToken,
                    "Content-Type": "application/json",
                    transformRequest: angular.identity
                })
            .success(function (d) {
                defer.resolve(d);
            })
            .error(function (error) {
                defer.reject(error.Message);
            });
            return defer.promise;
        };


        var uploadBase64 = function (model) {

            var url = apiPath + 'Upload/FileBase64/';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };


        return {
            dataModel: model,
            getAll: getAll,
            save: save,
            uploadFile: uploadFile,
            uploadBase64:uploadBase64,
            isOrderSNoExist: isOrderSNoExist,
            isNameExist: isNameExist,
            changeStatus: changeStatus
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
