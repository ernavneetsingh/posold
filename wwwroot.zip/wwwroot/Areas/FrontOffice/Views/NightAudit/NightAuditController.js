﻿
app.controller('controller', [
    '$scope', '$filter', '$cookies', 'service', '$window', 'localStorageService','manuService','checkINCommonService','$rootScope',  function (
        $scope, $filter, $cookies, service, $window, localStorageService,manuService,checkINCommonService, $rootScope) {
        
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.IsProgress = false;
        $scope.UserName = $cookies.get('UserName');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        var businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.BusinessDateStr = $filter("date")(businessDate, $scope.DateFormat);

        var nexDate = GetJavaScriptDate(date, $scope.DateFormat,1);
        $scope.NextBusinessDateStr = $filter("date")(nexDate, $scope.DateFormat);

        $scope.MinDate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
        
        $('#txtCheckOUTTime').timepicker({ 'timeFormat': 'h:i A' });

        function GetBusinessDate()
        {
            return $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
        }
  
        //-----------------------------------------------
        //Progress Bar
        //-----------------------------------------------
        $scope.ManuService = manuService;
        $scope.IsProgress = true;
        
        $scope.ProgressStart = function () {
            $scope.IsProgress = true;
            $('#body').addClass("disablewholepage");
            $scope.ManuService.setProgress(true);
        }
        $scope.ProgressEnd = function () {
            $scope.IsProgress = false;
            $('#body').removeClass("disablewholepage");
            $scope.ManuService.setProgress(false);
        }
        //-----------------------------------------------

        $scope.NightAudit = {
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName,
            BusinessDate: GetBusinessDate()
        };
        $scope.OccupiedRooms     =[];
        $scope.ExpectedArrivals  =[];
        $scope.ExpectedDepartures = [];
        $scope.OccupiedRoomGuests = [];
        $scope.Outlets = [];
        $scope.FOBills = [];
        $scope.DiscountTypes = [];
        $scope.TaxStructures = [];
        $scope.Packages = [];
        $scope.getSetup = function () {
            
            var promiseGet1 = service.GetConstantByPropertyId($scope.PropertyID);
            promiseGet1.then(function (data, status) {
                $scope.PropertyConstant = data.Data;

                service.getSetup($scope.PropertyID)
                    .then(function (data) {

                        $scope.setupData = data.Data;
                        $scope.ReservationModes =data.Data[1];
                        $scope.BillingInstructions =data.Data[2];
                        $scope.MarketSegments =data.Data[3];
                        $scope.NewsPapers =data.Data[4];
                        $scope.BusinessSources =data.Data[5];
                        $scope.TaxStructures =data.Data[6];
                        $scope.Designations =data.Data[7];
                        $scope.Corporates =data.Data[8];
                        $scope.Bookers =data.Data[9];
                        $scope.DocumentTypes =data.Data[10];
                        $scope.DefaultSettings =data.Data[11];
                        $scope.DefaultSetting = {

                            CurrencyConversionRate: data.Data[11][0].CurrencyConversionRate,
                            CurrencyConversionMargin: data.Data[11][0].CurrencyConversionMargin,
                            CurrencydecimalPlaces: data.Data[11][0].CurrencydecimalPlaces,
                            DateFormat: data.Data[11][0].DateFormat,
                            TimeZoneLocation: data.Data[11][0].TimeZoneLocation,
                            TimeFormat: data.Data[11][0].TimeFormat,
                            ChildAge: data.Data[11][0].ChildAge,
                            InfantAge: data.Data[11][0].InfantAge,
                            DefaultNationality: data.Data[11][0].DefaultNationality,
                            GlobalLanguage: data.Data[11][0].GlobalLanguage,
                            Software_Started_Date: data.Data[11][0].Software_Started_Date,
                            Financial_FromYear: data.Data[11][0].Financial_FromYear,
                            Financial_ToYear: data.Data[11][0].Financial_ToYear,
                            CheckOUTTypeId: data.Data[11][0].CheckOUTTypeId,
                            EarlyArrival: data.Data[11][0].EarlyArrival,
                            LateDeparture: data.Data[11][0].LateDeparture,
                            CountryMasterId: data.Data[11][0].CountryMasterId,
                            MarketSegmentId: data.Data[11][0].MarketSegmentId,
                            RateMasterId: data.Data[11][0].RateMasterId,
                            RoomTypeId: data.Data[11][0].RoomTypeId,
                            BusinessSourceId: data.Data[11][0].BusinessSourceId,
                            CurrencyMasterId: data.Data[11][0].CurrencyMasterId,
                            MealPlanId: data.Data[11][0].MealPlanId,
                            RevenueHeadId: data.Data[11][0].RevenueHeadId,
                            RevenueHeadCode: data.Data[11][0].RevenueHeadCode,
                            SalutationId: data.Data[11][0].SalutationId.toString(),
                            StateMasterId: data.Data[11][0].StateMasterId,
                        };
                        $scope.Amenitys =data.Data[12];
                        $scope.RevenueHeads =data.Data[13];
                        angular.forEach($scope.RevenueHeads, function (item) {
                            item.RevenueForId = item.RevenueForId.toString();
                        })
                        $scope.AdvanceRevenueHeads = $scope.RevenueHeads.filter(x=>x.RevenueForId == '6');  //Navneet Do not Confuse with Reservation Advance
                        $scope.RateMasters =data.Data[14];
                        $scope.RateMasterList = $scope.RateMasters;

                        $scope.GuestStatuss =data.Data[15];
                        $scope.OccupationMasters =data.Data[16];
                        $scope.BookerTypes =data.Data[17];
                        $scope.CorporateTypes =data.Data[18];
                        $scope.Currencys =data.Data[19];
                        $scope.Salutations =data.Data[20];
                        $scope.Countrys =data.Data[21];
                        $scope.GuestClasss =data.Data[22];
                        $scope.MealPlans =data.Data[23];
                        //$scope.CreditCardNetworks =data.Data[24];
                        $scope.NetworkList =data.Data[24];
                        //$scope.RoomTypes =data.Data[25];
                        $scope.RoomTypeRates =data.Data[26];
                        $scope.OccupancyRates =data.Data[26];
                        $scope.OccupancyMealPlanRates =data.Data[27];
                        $scope.LinkTaxStructures =data.Data[28];
                        $scope.DiscountTypes = $scope.PropertyConstant.DiscountTypes;
                        //$scope.TaxStructures = $scope.setupData.TaxStructures;
                        //$scope.RoomTypes = $scope.setupData.RoomTypes;
                        $scope.Packages = $scope.PropertyConstant.Packages;

                        //GetRateMaster();

                        //$scope.DefaultSetting = {
                        //    CurrencyConversionRate: data.Data.DefaultSetting.CurrencyConversionRate,
                        //    CurrencyConversionMargin: data.Data.DefaultSetting.CurrencyConversionMargin,
                        //    CurrencydecimalPlaces: data.Data.DefaultSetting.CurrencydecimalPlaces,
                        //    DateFormat: data.Data.DefaultSetting.DateFormat,
                        //    TimeZoneLocation: data.Data.DefaultSetting.TimeZoneLocation,
                        //    TimeFormat: data.Data.DefaultSetting.TimeFormat,
                        //    ChildAge: data.Data.DefaultSetting.ChildAge,
                        //    InfantAge: data.Data.DefaultSetting.InfantAge,
                        //    DefaultNationality: data.Data.DefaultSetting.DefaultNationality,
                        //    GlobalLanguage: data.Data.DefaultSetting.GlobalLanguage,
                        //    Software_Started_Date: data.Data.DefaultSetting.Software_Started_Date,
                        //    Financial_FromYear: data.Data.DefaultSetting.Financial_FromYear,
                        //    Financial_ToYear: data.Data.DefaultSetting.Financial_ToYear,
                        //    CheckOUTTypeId: data.Data.DefaultSetting.CheckOUTTypeId,
                        //    EarlyArrival: data.Data.DefaultSetting.EarlyArrival,
                        //    LateDeparture: data.Data.DefaultSetting.LateDeparture,
                        //    CountryMasterId: data.Data.DefaultSetting.CountryMasterId,
                        //    MarketSegmentId: data.Data.DefaultSetting.MarketSegmentId,
                        //    RateMasterId: data.Data.DefaultSetting.RateMasterId,
                        //    RoomTypeId: data.Data.DefaultSetting.RoomTypeId,
                        //    BusinessSourceId: data.Data.DefaultSetting.BusinessSourceId,
                        //    CurrencyMasterId: data.Data.DefaultSetting.CurrencyMasterId,
                        //    MealPlanId: data.Data.DefaultSetting.MealPlanId,
                        //    RevenueHeadId: data.Data.DefaultSetting.RevenueHeadId,
                        //    SalutationId: data.Data.DefaultSetting.SalutationId,
                        //    StateMasterId: data.Data.DefaultSetting.StateMasterId,
                        //};
                        $scope.ProgressEnd();

                    }, function (err) {
                        msg(err.Message);
                        $scope.ProgressEnd();
                    });
            });
        };
        $scope.getSetup();

        
        $scope.LastNightAuditDate   = "";
        $scope.CurrentBusinessDate  = "";
        $scope.TimeBefore           = "";
        $scope.IsConfirm           = false;
        $scope.IsFirstNightAudit    = false;
            
        $scope.SetConfirm = function()
        {
            $scope.IsConfirm           = true;
            $('#LastNightAudit').modal('hide');
                
        }
        $scope.GoToDashBoard = function()
        {
            window.location.href = "../../FO/Dashboard";
        }

        function Reset() {

            $scope.NightAudit = {

                PropertyID: $scope.PropertyID,
                ModifiedBy: $scope.UserName,
                BusinessDate: GetBusinessDate()
            };
            $scope.OccupiedRooms = [];
            $scope.ExpectedArrivals = [];
            $scope.ExpectedPartialArrivals = [];
            $scope.ExpectedDepartures = [];
            $scope.OccupiedRoomGuests = [];
        }

        GetNightAudit();
        function GetNightAudit()
        {
            Reset();
            $scope.IsProgress = true;
            $scope.ProgressStart();
            var promiseGet = service.getNightAudit($scope.PropertyID, GetBusinessDate());
            promiseGet.then(function (data) {
                
                $scope.IsFirstNightAudit   = data.Data.IsFirstNightAudit;
                if(!$scope.IsFirstNightAudit)
                {
                    $scope.LastNightAuditDate   = data.Data.LastNightAuditDate;
                    $scope.CurrentBusinessDate  = data.Data.BusinessDate;
                    $scope.TimeBefore           = data.Data.TimeBefore;
                }
                
                $scope.OccupiedRooms = data.Data.OccupiedRooms;
                $scope.ExpectedArrivals = data.Data.ExpectedArrivals;

                $scope.TaxStructures = data.Data.TaxStructures;
                $scope.Outlets = data.Data.Outlets;
                $scope.FOBills = data.Data.FOBills;
                
                angular.forEach($scope.OccupiedRooms, function (item) {
                    
                    var businessDate = GetJavaScriptDate($scope.BusinessDateStr, $scope.DateFormat, 0);
                    var IsExist = false;
                    angular.forEach(item.CheckINGuests, function (checkINGuest) {

                        checkINGuest.RoomINDate = $filter("date")(checkINGuest.RoomINDate, $scope.DateFormat);
                        checkINGuest.RoomOUTDate = $filter("date")(checkINGuest.RoomOUTDate, $scope.DateFormat);

                        var a = GetMomentDate($filter("date")(checkINGuest.RoomOUTDate, $scope.DateFormat), $scope.DateFormat);
                        var b = GetMomentDate($scope.BusinessDateStr, $scope.DateFormat);
                        if (a.isSame(b)) {
                            IsExist = true;
                        }
                    });
                    
                    if (IsExist)
                    {
                        $scope.ExpectedDepartures.push(item);
                    }
                });

                angular.forEach($scope.ExpectedArrivals, function (room) {

                    room.ReservationDate = $filter("date")(room.ReservationDate, $scope.DateFormat);
                    room.GuestArrivalDate = $filter("date")(room.GuestArrivalDate, $scope.DateFormat);
                    room.GuestDepartureDate = $filter("date")(room.GuestDepartureDate, $scope.DateFormat);

                    angular.forEach(room.ReservationRoomTypes, function (roomtype) {
                        roomtype.ArrivalDate = $filter("date")(roomtype.ArrivalDate, $scope.DateFormat);
                        roomtype.DepartureDate = $filter("date")(roomtype.DepartureDate, $scope.DateFormat);                       
                    });
                });
                angular.forEach(data.Data.ExpectedPartialArrivals, function (item) {
                    angular.forEach(item.ReservationRoomTypes, function (room) {

                        //room.ReservationDate = $filter("date")(room.ReservationDate, $scope.DateFormat);
                        //room.GuestArrivalDate = $filter("date")(room.GuestArrivalDate, $scope.DateFormat);
                        //room.GuestDepartureDate = $filter("date")(room.GuestDepartureDate, $scope.DateFormat);

                        angular.forEach(room.ReservationRoomTypeGuests, function (roomtype) {
                            if(roomtype.IsCheckedIN == false)
                            {
                                roomtype.ReservationDate = $filter("date")(roomtype.ReservationDate, $scope.DateFormat);
                                roomtype.ArrivalDate = $filter("date")(roomtype.ArrivalDate, $scope.DateFormat);
                                roomtype.DepartureDate = $filter("date")(roomtype.DepartureDate, $scope.DateFormat); 
                                $scope.ExpectedPartialArrivals.push(roomtype);                                                      
                            }
                        });
                    });
                });
                $scope.IsProgress = false;
                $scope.ProgressEnd();
                $('#body').removeClass("disablewholepage");

                if(!$scope.IsConfirm)
                {
                    $scope.IsConfirm           = true;

                    $('#LastNightAudit').modal('show');
                }
                
            },
                function (error) {
                    $scope.IsProgress = false;
                    $scope.ProgressEnd();
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        }

        $scope.GetNightAudit = function () {
            GetNightAudit();
        };

        $scope.GetNightAuditMessage = function () {
            GetNightAuditMessage();
        };

        $scope.Messages = [];
        $scope.unAcknowledges=[];
        function GetNightAuditMessage() {
            
            var promiseGet = service.getNightAuditMessage(5,$scope.PropertyID, GetBusinessDate());
            promiseGet.then(function (data) {
                
                $scope.Messages = data.Collection;
                if( $scope.Messages.length>0)
                {
                    $scope.unAcknowledges = $scope.Messages.filter(x=>x.MessageActionId!=3);
                    if (unAcknowledges.length>0) {
                        scrollPageOnTop();
                        $('#messageBox').modal('show');
                        return;
                    }
                }
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        }
        GetNightAuditMessage();

        $scope.SelectedRoom = {};
        $scope.SelectRoom = function (room) {
            
            $scope.SelectedRoom = room;

            angular.forEach(room.CheckINGuests, function (item) {

                var test = item.CheckINGuestRoom.CheckINGuestRoomRates;

            });

        };

        //Edit Tariff Start
        $scope.IsMultiRate = "1";


        $scope.CheckINGuestRoomRate = {

            CheckINGuestRoomId: '',
            ChargeDate: '',
            DayRate: 0,
            RateDiscountInId: '1',
            RateDiscountValue: 0,
            DayRateAmount: 0,
            TotalTariffTAXAmount: 0,
            MealPlanDayRate: 0,
            MealPlanDayRateApply: 0,
            MealPlanDiscountInId: '2',
            MealPlanDiscountValue: 0,
            MealPlanDayRateAmount: 0,
            TotalMealPlanTAXAmount: 0,
            ExtraBedAmount: 0,
            EarlyArrivalCharge: 0,
            LateDepartureCharge: 0,
            RateTaxStructureId:'',
            MealPlanTaxStructureId:'',
            TariffLinkTaxStructures: [],
            MealPlanLinkTaxStructures: []

        };

        
        $scope.IsExtraBed = false;
        $scope.GetCheckINGuestRoomRate = function (checkINGuests,checkINGuestRoom) {
            $scope.IsExtraBed = false;
            $scope.CheckINRoomRatePackages = [];
            $scope.IsMultiRate = "1";

            if($scope.Model)
            {
                $scope.Model.CheckINGuests =checkINGuests;
            }
            else
            {
                $scope.Model={CheckINGuests:[]}
                $scope.Model.CheckINGuests =checkINGuests;
            }

            scrollPageOnTop();
            var corporateId = '';
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                if (checkINGuestRoom.SNo == checkINGuest.SNo) {
                    corporateId = checkINGuest.CorporateId;
                }
            });

            $scope.CheckINGuestRoom = checkINGuestRoom;
            $scope.CheckINGuestRoom.CorporateId = corporateId;
            $scope.CheckINGuestRoom.SNo = 1;

            if ($scope.CheckINGuestRoom.IsMultiRate == true) {
                $scope.IsMultiRate = "2"
            }
            if ($scope.CheckINGuestRoom.PackageId != null && $scope.CheckINGuestRoom.PackageId.length > 0) {
                $scope.IsMultiRate = "3"

                angular.forEach($scope.Packages, function (item) {
                    if (item.RoomTypeId == $scope.CheckINGuestRoom.RoomTypeId) {
                        $scope.CheckINRoomRatePackages.push(item);
                    }
                });
                $scope.CheckINGuestRoom.PackageId = $scope.CheckINGuestRoom.PackageId;
            }
            $scope.GetCheckINGuestRoom(checkINGuestRoom);

        };
        $scope.CheckINGuestRoomReset={};
        $scope.CheckINGuestRooms=[];
        $scope.GetCheckINGuestRoom = function (checkINGuestRoom) {
            $scope.CheckINGuestRoom={};
            $scope.IsProgress = true;
            $scope.ProgressStart();
            
            service.getCheckINGuestRoom(checkINGuestRoom.Id)
            .then(function (result) {

                $scope.CheckINGuestRoomReset = result.Data;
                $scope.CheckINGuestRoom = result.Data;
                //$scope.CheckINGuestRoom.RateTypeId == '2'
                SetCheckINGuestRoom();

                $scope.IsProgress = false;
            }, function (err) {
                $scope.IsProgress = false;
                msg(err.Message);
            });
        };
        
        $scope.ChargeDate = function(comment) {
            var date = new Date(comment.ChargeDateOriginal);
            return date;
        };

        function SetCheckINGuestRoom()
        {
            if($scope.CheckINGuestRoom.IsMultiRate==true)
            {
                $scope.IsMultiRate = "2";
            }
            else
            {
                $scope.IsMultiRate = "1";
            }
            checkINCommonService.SetTax($scope,$scope.CheckINGuestRoom);
            angular.forEach($scope.CheckINGuestRoom.CheckINGuestRoomRates,function(item){

                item.ChargeDateOriginal = angular.copy( item.ChargeDate);
                item.ChargeDate = $filter('date')(item.ChargeDate,$scope.DateFormat);
                item.RateDiscountInId =item.RateDiscountInId.toString();

                var bdate = $scope.BusinessDate.Year+'-'+$scope.BusinessDate.Month+'-'+ $scope.BusinessDate.Day;
                var chargeDate = GetMomentDate($filter('date')(item.ChargeDate, $scope.DateFormat), $scope.DateFormat);
                var currentDate = GetMomentDate(bdate, 'YYYY-MM-DD');
                if (chargeDate.isBefore(currentDate)) {
                    item.IsRateDisabled = true;
                }
                
            });
                
            
            angular.forEach($scope.RoomTypes, function (item) {
                if (item.Id == $scope.CheckINGuestRoom.RoomTypeId) {
                    $scope.CheckINGuestRoom.RoomTypeRates = angular.copy(item.RoomTypeRates);
                }
            });

            //Tarif
            angular.forEach($scope.CheckINGuestRoom.RoomTypeRates, function (rate, index) {
                if ($scope.CheckINGuestRoom.RateMasterId == rate.RateMasterId) {
                    //Tarif
                    angular.forEach(rate.OccupancyRates, function (occupancyRate, index) {
                        if ($scope.CheckINGuestRoom.NumberOfPax == occupancyRate.OccupancyId) {
                            $scope.CheckINGuestRoom.Tariff = parseFloat(occupancyRate.RateDay1);
                            angular.forEach(occupancyRate.OccupancyMealPlanRates, function (occupancyMealPlanRate, index) {
                                if ($scope.CheckINGuestRoom.MealPlanId == occupancyMealPlanRate.MealPlanId) {
                                    $scope.CheckINGuestRoom.MealPlanCode = occupancyMealPlanRate.MealPlanCode;
                                    $scope.CheckINGuestRoom.MealPlanRate = occupancyMealPlanRate.RateDay1;
                                }
                            });
                        }
                        else if ($scope.CheckINGuestRoom.NumberOfPax == 0) {
                            $scope.CheckINGuestRoom.Tariff = 0;
                            $scope.CheckINGuestRoom.MealPlanRate = 0;
                        }
                    });

                    //Extra Bed
                    $scope.CheckINGuestRoom.ExtraBedAdultRate = parseFloat(rate.ExtraBedAdultRate);
                    $scope.CheckINGuestRoom.ExtraBedChildRate = parseFloat(rate.ExtraBedChildRate);
                    $scope.CheckINGuestRoom.ExtraBedInfantRate = parseFloat(rate.ExtraBedInfantRate);

                    angular.forEach(rate.OccupancyRates, function (occupancyRate, index) {
                        if ($scope.CheckINGuestRoom.ExtraBedNumber == occupancyRate.OccupancyId) {
                            angular.forEach(occupancyRate.OccupancyMealPlanRates, function (occupancyMealPlanRate, index) {

                                if ($scope.CheckINGuestRoom.MealPlanId == occupancyMealPlanRate.MealPlanId) {
                                    $scope.CheckINGuestRoom.ExtraBedMealPlanCode = occupancyMealPlanRate.MealPlanCode;
                                    $scope.CheckINGuestRoom.ExtraBedMealPlanDayRate = occupancyMealPlanRate.RateDay1;
                                }
                            });
                        }
                    });
                }
            });
    
            $scope.CheckINGuestRooms.push($scope.CheckINGuestRoom);
            //checkINCommonService.SetRate($scope,$scope.CheckINGuestRoom);
            checkINCommonService.GetTotal($scope);
        }

        $scope.GetChangeRate = function (fromId) {
            checkINCommonService.GetChangeRate($scope,fromId)
        };
        $scope.SetRate = function (fromId) {
            checkINCommonService.SetRate($scope,fromId)
        };

        $scope.SetRate = function () {
            checkINCommonService.SetRate($scope,$scope.CheckINGuestRoom);
        }

        //Change Tariff

        $scope.ResetDayRate = function () {

            if (!$scope.CheckINGuestRoomRate) {
                parent.posFailureMessage("Room Rate Details are missing.");
                return;
            }

            if (isNaN(parseFloat($scope.CheckINGuestRoomRate.DayRateAmount))) {
                parent.posFailureMessage("Please enter Day Rate Amount.");
                return;
            }

            if (isNaN(parseFloat($scope.CheckINGuestRoomRate.MealPlanDayRateAmount))) {
                parent.posFailureMessage("Please enter Meal Plan Amount.");
                return;
            }
                        
            $scope.CheckINGuestRoomRate.PropertyID = $scope.PropertyID;
            $scope.CheckINGuestRoomRate.ModifiedBy = $scope.UserName;
            $scope.CheckINGuestRoomRate.DateFormat = $scope.DateFormat;

            var promiseGet = service.resetDayRate($scope.CheckINGuestRoomRate);
            promiseGet.then(function (data, status) {
                

                parent.successMessage("Room Rate saved.");

                $scope.CheckINGuestRoomRate = {};

                GetNightAudit();

                $('#edittariff').hide();
                $('.modal-backdrop.fade.in').hide();



            }, function (error, status) {
                parent.posFailureMessage(error.Message);
            });
        };

        $scope.saveCheckINGuestRoom = function () {
            
        
            $scope.CheckINGuestRoom.IsMultiRate = $scope.IsMultiRate=='2';

            $scope.CheckINGuestRoom.PropertyID = $scope.PropertyID;
            $scope.CheckINGuestRoom.ModifiedBy = $scope.UserName;
            $scope.CheckINGuestRoom.DateFormat = $scope.DateFormat;
            $scope.CheckINGuestRoom.BusinessDate = $scope.BusinessDate.Year +'-'+ $scope.BusinessDate.Month +'-'+ $scope.BusinessDate.Day;

            var promiseGet = service.saveCheckINGuestRoom($scope.CheckINGuestRoom);
            promiseGet.then(function (data, status) {
                parent.successMessage("Room Rate saved.");
                $scope.CheckINGuestRoom = {};
                GetNightAudit();
                $('#edittariffNew').hide();
                $('.modal-backdrop.fade.in').hide();

            }, function (error, status) {
                parent.posFailureMessage(error.Message);
            });
        };

        //End Tariff Start

        //KOT
        $scope.KOTs = [];
        $scope.KOTBills = [];
        $scope.SetOutlet = function (outletid) {
            
            $scope.IsProgress = true;
            $scope.ProgressStart();
            var promiseGet = service.getPendingKOTs($scope.PropertyID, outletid);
            promiseGet.then(function (data) {

                $scope.KOTs = data.Collection;
                

                $scope.IsProgress = false;
                $('#body').removeClass("disablewholepage");
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });

            var promiseGet1 = service.getPendingKOTBills($scope.PropertyID, outletid);
            promiseGet1.then(function (data) {

                $scope.KOTBills = data.Collection;


                $scope.IsProgress = false;
                $('#body').removeClass("disablewholepage");
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        };

        //Laundry
        $scope.Laundrys = [];
        $scope.LaundryBills = [];

        $scope.SetHousekeeping  = function () {
            
            $scope.IsProgress = true;
            $scope.ProgressStart();
            var promiseGet = service.getAllUnBill($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Laundrys = data.Collection;

                $scope.IsProgress = false;
                $('#body').removeClass("disablewholepage");
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });

            var promiseGet1 = service.getAllUnSettled($scope.PropertyID);
            promiseGet1.then(function (data) {

                $scope.LaundryBills = data.Collection;

                $scope.IsProgress = false;
                $('#body').removeClass("disablewholepage");
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        };
        $scope.SetHousekeeping();
        //change arrival date
        $scope.OpenNowShow = function (id) {
            $scope.ReservationId = id;
        };
        $scope.OpenNowShowGuest = function (partialArrival) {
            $scope.ReservationRoomTypeGuest = partialArrival;
        };
        $scope.SetReservationRoomType = function (id) {
            $scope.ReservationRoomTypeId = id;
        };
        
        $scope.Model = {};
        $scope.IsNOShow = false;
        $scope.SaveNOShow = function (form) {

            
            if ($scope[form].$valid) {

                $scope.Model.ReasonId = $scope.ReasonId;
                $scope.Model.CancellationRemark = $scope.CancellationRemark;

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.UserName;
                $scope.Model.DateFormat = $scope.DateFormat;

                if ($scope.IsNOShow) {
                    $scope.Model.Id = $scope.ReservationId;

                    var promiseGet = service.noShow($scope.Model);
                    promiseGet.then(function (data, status) {
                    
                        parent.successMessage("NO Show marked.");
                        $('#noshowbox').modal('hide');
                        GetNightAudit();
                    }, function (error, status) {
                        parent.popErrorMessage(error.Message);
                    });
                }
                else
                {
                    parent.popErrorMessage("Please Check Is NO Show.");
                }
            }

        };

        $scope.SaveNOShowGuest = function (form) {

            
            if ($scope[form].$valid) {

                $scope.Model.ReasonId = $scope.ReasonId;
                $scope.Model.CancellationRemark = $scope.CancellationRemark;

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.UserName;
                $scope.Model.DateFormat = $scope.DateFormat;

                if ($scope.IsNOShow) {
                    $scope.Model.ReservationId = $scope.ReservationRoomTypeGuest.ReservationId;
                    $scope.Model.ReservationRoomTypeId = $scope.ReservationRoomTypeGuest.ReservationRoomTypeId;
                    $scope.Model.Id = $scope.ReservationRoomTypeGuest.Id;

                    var promiseGet = service.noShowGuest($scope.Model);
                    promiseGet.then(function (data, status) {
                    
                        parent.successMessage("NO Show marked.");
                        $('#noshowbox').modal('hide');
                        GetNightAudit();
                    }, function (error, status) {
                        parent.popErrorMessage(error.Message);
                    });
                }
                else
                {
                    parent.popErrorMessage("Please Check Is NO Show.");
                }
            }

        };


        $scope.Reasons=[];
        $scope.GetReason = function() {
            
            var promiseGet = service.GetReason($scope.PropertyID);
            promiseGet.then(function (data) {
                
                $scope.Reasons=data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        }
        $scope.GetReason();


        $scope.ChangeArrivalDate = function () {
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            $scope.Model.DateFormat = $scope.DateFormat;

            $scope.Model.Id = $scope.ReservationRoomTypeId;
            $scope.Model.ArrivalDate = GetServerDate($scope.Model.ArrivalDate, $scope.DateFormat);

            var promiseGet = service.changeArrivalDate($scope.Model);
            promiseGet.then(function (data, status) {
                
                parent.successMessage("Arrival Date changed successfully.");
                $('#expectedarrivalpopup').modal('hide');
                GetNightAudit();
            }, function (error, status) {
                $scope.Model.ArrivalDate = GetLocalDate($scope.Model.ArrivalDate, $scope.DateFormat);
                parent.popErrorMessage(error.Message);
            });

        };

        //Change departure date
        $scope.SetCheckIN = function (checkINGuest) {
            $scope.CheckINGuest = checkINGuest;
            //$scope.CheckOUTDate = checkINGuest.RoomOUTDate;
        };

        //--
        $scope.IsLoadingChangeRoomOutDate=false;
        $scope.ChangeRoomOutDate = function(){
            if($scope.IsLoadingChangeRoomOutDate)
            {
                return;
            }
            else
            {
                $scope.IsLoadingChangeRoomOutDate=true;
            }
            var checkINGuestId = $scope.CheckINGuest.Id;
            var newRoomOUTDate =  GetServerDate($scope.CheckINGuest.RoomOUTDate, $scope.DateFormat);
            var bDate= GetBusinessDate();
            
            var promiseGet = service.ChangeRoomOutDate(checkINGuestId, newRoomOUTDate,  bDate);
            promiseGet.then(function (result) {
                $scope.IsLoadingChangeRoomOutDate=false;
                if(result.Data == "Success")
                {
                    //parent.popSuccessMessage("Departure date change successfully.");
                    parent.successMessage("Departure Date changed successfully.");
                    $scope.Model = {}
                    GetNightAudit();
                    $('#expecteddeparturepopup').hide();
                    $('.modal-backdrop.fade.in').hide();
                    
                }
            },
            function (message) {
                $scope.IsLoadingChangeRoomOutDate=false;
                parent.popErrorMessage(message);
            });
            scrollPageOnTop();
        }
        
        $scope.ChargePosts = [];
        $scope.GetAllChargePost = function() {
            $scope.IsProgress = true;
            $scope.ProgressStart();
            var promiseGet = service.getAllChargePost($scope.PropertyID, GetBusinessDate());
            promiseGet.then(function (data) {
                
                $scope.ChargePosts = data.Collection;
                
                $scope.IsProgress = false;
                $scope.ProgressEnd();

                $('#body').removeClass("disablewholepage");
            },
                function (error) {
                    $scope.ProgressEnd();

                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        }

        //Close the Day
        $scope.DayClose = function () {
            //$scope.IsProgress = true;
            //$scope.ProgressStart();

            $scope.NightAudit.NightAuditDate = GetBusinessDate();
            $scope.NightAudit.PropertyID = $scope.PropertyID;
            $scope.NightAudit.ModifiedBy = $scope.UserName;

            $('#body').addClass("disablewholepage");
            $scope.IsProgress = true;
            $scope.ProgressStart();
            var promiseGet = service.dayClose($scope.NightAudit);
            promiseGet.then(function (data) {

                $scope.IsProgress = false;
                if (data.Status)
                {
                    parent.successMessage("Night Audit Done Successfully.");
                    SessionExpired();
                    return;
                }

                parent.posFailureMessage("Night Audit Fail.");

                $scope.IsProgress = false;
                $('#body').removeClass("disablewholepage");
            },
                function (error) {
                    $scope.IsProgress = false;
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        };

        $scope.SelectReservation = function(reservation)
        {
            $scope.SelectedReservation = reservation;
        }

        //Tax Calculation New
        //$scope.IsInclusive = function (selectedRoom) {
        //    checkINCommonService.IsInclusive($scope, selectedRoom);
        //};
        $scope.IsInclusive = function (selectedRoom) {
            selectedRoom.RoomTypeRates =[];
            selectedRoom.SNo= $scope.Model.CheckINGuests[0].SNo;
            selectedRoom.FolioNo= $scope.Model.CheckINGuests[0].FolioNo;
           
            if ($scope.setupData) {
                if ($scope.RoomTypeRates) {
                    angular.forEach($scope.RoomTypeRates, function (item) {
                        if(item.RoomTypeId == selectedRoom.RoomTypeId && item.RateMasterId == selectedRoom.RateMasterId)
                        {
                            // $scope.CheckINGuestRoom.RoomTypeRates = item.RoomTypeRates;
                            selectedRoom.RoomTypeRates.push(item);
                        }
                    });
                }
            }
            checkINCommonService.IsInclusive($scope, selectedRoom);
        };


        $scope.ChangeRateDiscountValue = function (roomRate, index) {
            checkINCommonService.ChangeRateDiscountValue($scope, roomRate, index);
        };
        $scope.CalculateDiscount = function (roomRate, index) {
            checkINCommonService.CalculateDiscount($scope, roomRate, index);
        };
        //filters for Posting
        $scope.filterForRateType = function (rate) {
            return checkINCommonService.filterForRateType($scope,rate);
        };

        $scope.RateMasters = [];
        function GetRateMaster() {

            $scope.RateMasters = [];
            if ($scope.Model.CorporateId) {
                angular.forEach($scope.CorporateRates, function (item) {
                    $scope.RateMasters.push(item);
                });
            }

            if ($scope.setupData) {
                if ($scope.setupData.RateMasters) {
                    angular.forEach($scope.setupData.RateMasters, function (item) {
                        $scope.RateMasters.push(item);
                    });
                }
            }

        }

        $scope.SaveAcknowledge = function (messenger) {

            messenger.MessageAcknowledgeRemark = "OK"
            messenger.PropertyID = $scope.PropertyID;
            messenger.ModifiedBy = $scope.UserName;
            
            var promiseGet = service.saveAcknowledge(messenger);
            promiseGet.then(function (data) {
                if (data.Status) {
                    GetNightAuditMessage();
                    parent.successMessage("Message acknowledged Successfully.");
                }
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        };
        
        $scope.$on("CallDashboardCheckIN", function (event, obj) {
            //alert('Guest Details Changed. Reloading Night Audit.');
            GetNightAudit();
        });

    }

]);
