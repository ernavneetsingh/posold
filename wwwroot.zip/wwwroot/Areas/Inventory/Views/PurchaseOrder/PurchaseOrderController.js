﻿
'use strict';
app.requires.push('ui.grid.autoResize');

app.controller("controller", ["$scope", "service", "$cookies", "$filter", "localStorageService","$window", "$http", "$q","FreightChargeService","PaymentTermsService","AfterSaveBoxService",
    function ($scope, service, $cookies, $filter, localStorageService,$window, $http, $q,freightChargeService,paymentTermsService,afterSaveBoxService) {

        $scope.LoginId = $cookies.get('LoginId');
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MaxDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
        $scope.paymentTermsService = paymentTermsService.init($scope);
        $scope.afterSaveBoxService = afterSaveBoxService.init($scope);
        $scope.keys=localStorageService.get('ActionKeys');
        $scope.Model = {
            Id: '',
            PODate: $filter('date')(date, $scope.DateFormat),
            PONumber: '',
            VendorId: "",
            VendorName: '',
            VendorCode: '',
            POStatusType: '',
            POStatusTypeId: 6,
            POStatusTypeName: '',
            PaymentTerms: '',
            Remarks: '',
            ApplyDiscount: '',
            TotalAmount: 0,
            TotalTax: 0,
            TotalDiscount: 0,
            GrossAmount: 0,
            DeliveryDate: '',
            ReasonId: '',
            ReasonName: '',
            ModificationRemarks: '',
            IsApproved: '',
            ApprovedBy: '',
            ApprovedByName: '',
            ApprovedDate: '',
            PurchaseOrderItems: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: []
        };

        $scope.PurchaseOrderItem = {
            Id: '',
            PurchaseOrderId: '',
            StoreId: '',
            StoreName: "",
            CostCenterId: '',
            CostCenterName: '',
            InventoryItemId: '',
            InventoryItemName: '',
            InventoryItemCode: '',
            ItemType: '',
            ItemTypeId: '',
            ItemTypeName: '',
            BrandId: '',
            BrandName: '',
            UnitOfMeasurementId: '',
            UnitOfMeasurementName: '',
            Rate: '',
            Quantity: '',
            QuantityReceived: '',
            Amount: '',
            Discount: '',
            DiscountIn: '',
            DiscountInId: '',
            DiscountInName: '',
            TaxAmount: '',
            TaxStructureId: '',
            TaxStructureName: '',
            POItemStatus: '',
            POItemStatusId: '',
            POItemStatusName: '',
            DeliveryDate: '',
            PurchaseOrderItemTaxs: [],
            Brands: [],
            ForDisplayCostCenters: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: ''
        }

        $scope.PurchaseOrderItemTax = {
            Id: '',
            PurchaseOrderItemId: '',
            TaxTypeId: '',
            TaxTypeName: "",
            TaxAmount: '',
            TaxIn: '',
            TaxInId: '',
            TaxInName: '',
            TaxValue: '',
            PropertyID: '',
            ModifiedBy: ''
        }

        $scope.Index = '';
        $scope.Model.PurchaseOrderItems = [];
        $scope.SelectedDeliveryDate = $filter('date')(date, $scope.DateFormat);

        $scope.SelectedTaxStructureId = "";
        $scope.OldSelectedTaxStructureId = '';
        $scope.LinkTaxStructures = [];
        $scope.ItemLinkTaxStructures = [];
        $scope.Reasons = [];

        $scope.SetSelectedDeliveryDate = function (index) {

            angular.forEach($scope.Model.PurchaseOrderItems, function (item, key) {

                if (key == index) {
                    $scope.SelectedDeliveryDate = item.DeliveryDate;
                }

            });
        };

        $scope.Status = null;
        setTimeout(function () {
            $scope.Status = "All";
        }, 300);
               
        var pathServer = Path;
        $scope.gridOptions = {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: {
                text: "PO Details",
                style: 'headerStyle'
            },
            exporterPdfFooter: function (currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(),
                    style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22,
                    bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10,
                    bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            
            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {

                    if (row.isExpanded) {

                        row.entity.subGridOptions = {
                            columnDefs: [
                            {
                                name: 'StoreName'
                            },
                            {
                                name: 'InventoryItemName'
                            },
                            {
                                name: 'BrandName'
                            },
                            {
                                name: 'ItemTypeName'
                            },
                            {
                                name: 'Quantity',
                                cellClass: 'grid-align-center'
                            },
                             {
                                 name: 'Rate',
                                 cellClass: 'grid-align-right'
                             },
                            {
                                name: 'DiscountAmount',
                                cellClass: 'grid-align-right'

                            },
                            {
                                name: 'TaxAmount',
                                cellClass: 'grid-align-right'
                            },

                            {
                                name: 'CostCenterName'
                            },
                            {
                                name: 'DeliveryDate'
                            }
                            ]
                        };
                        
                        row.entity.subGridOptions.data = row.entity.PurchaseOrderItems;

                    }
                });
            }

        }
        $scope.gridOptions.columnDefs = [
        {
            name: 'PONumber', pinnedLeft: true
        },
        {
            name: 'PODate'
        },
        {
            name: 'VendorName'
        },
        {
            name: 'TotalAmount', cellClass: 'grid-align-right'
        },
        {
            name: 'PaymentTerms'
        },
        {
            name: 'ApprovedByName'
        },
        {
            name: 'POStatusTypeName'
        }
        ];

        //Common
        $scope.VendorList = [];
        $scope.TaxStructures = [];

        $scope.myConfig = {
            valueField: "Id",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: false,
            maxItems: 1
        }

        GetAllVendor();
        function GetAllVendor() {
            var promiseGet = service.getAllVendor($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.VendorListAll =$scope.VendorList = data;
            },
            function (data) {
                parent.failureMessage(data.message);
                scrollPageOnTop();
            });
        }
        GetAllTaxStructure();
        function GetAllTaxStructure() {

            var promiseGet = service.getAllTaxStructure(5, $scope.PropertyID);

            promiseGet.then(function (data) {

                $scope.TaxStructures = data;
            },
            function (data) {
                parent.failureMessage(data.message);
                scrollPageOnTop();
            });
        }
        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        }

        //TAB: 1
        GetAllPOVendor();
        function GetAllPOVendor() {
            var promiseGet = service.getAllPOVendor(6, 'All', 'All', $scope.PropertyID);
            promiseGet.then(function (details) {
                $scope.items = details;
                FormatPO($scope.items)
                $scope.search();
            },
            function (xhr) {
                var errorMessage = $.parseJSON(xhr.responseText);
                parent.failureMessage(errorMessage.Message);
                scrollPageOnTop();
            });
        }
        $scope.GetAllPOVendor = function (data, searchText, searchType) {
            var promiseGet = service.getAllPOVendor(data, searchText, searchType, $scope.PropertyID);
            promiseGet.then(function (details) {
                $scope.items = details;
                FormatPO($scope.items)
                $scope.search();
            },
            function (xhr) {
                var errorMessage = $.parseJSON(xhr.responseText);
                parent.failureMessage(errorMessage.Message);
                scrollPageOnTop();
            });
        };

        function FormatPO(POList) {
            angular.forEach(POList, function (po) {
                po.PODate = $filter('date')(new Date(po.PODate), $scope.DateFormat);
                po.TotalAmount = $filter('number')(po.TotalAmount, 2).replace(/,/g, '');
                angular.forEach(po.PurchaseOrderItems, function (item) {
                    item.DeliveryDate = $filter('date')(new Date(item.DeliveryDate), $scope.DateFormat);
                    item.Quantity = $filter('number')(item.Quantity, 2).replace(/,/g, '');
                    item.Discount = $filter('number')(item.Discount, 2).replace(/,/g, '');
                    item.Rate = $filter('number')(item.Rate, 2).replace(/,/g, '');
                    item.TaxAmount = $filter('number')(item.TaxAmount, 2).replace(/,/g, '');
                });
            });
        }

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "VendorName" || attr === "PONumber" || attr === "PODate") {
                        var dd = item[attr];
                        if (dd == null || dd === 'undefined' || dd === '') {
                        } else {
                            if (searchMatch(item[attr], $scope.query))
                                return true;
                        }
                    }
                }
                return false;

            });
            $scope.gridOptions.data = $scope.filteredItems;
            if ($scope.filteredItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
            } else {
                $scope.MsgNotFound = "";
            }
        };

        //TAB: 2 Create PO
        //FORPERCENTAGE
        $scope.percent = 0;
        $scope.maxValue = 100;
        $scope.maxDecimals = 2;
        $scope.currencyIncludeDecimals = true;

        $scope.Model.PODate = $scope.ModifiedDate ;
        $scope.isCreatePO = true;
        $scope.clickCopyButton = function () {
            $scope.isCreatePO = false;
            if ($scope.PONumber != undefined && $scope.PONumber != null && $scope.PONumber != "") {
                $scope.showErrorCopyMsg = false;
            } else {
                $scope.showErrorCopyMsg = true;
            }
        };

        $scope.GetItemSearch = function (txt) {

            service.getItemSearch(txt, $scope.PropertyID,$scope.Model.PoTypeId==='2'?$scope.Model.VendorId:'',$scope.ModifiedDate);
        };
        $scope.changePOdate = function (poDate) {
            $scope.VendorList=$scope.VendorListAll.filter(x=>x.ApplicableFromString<=poDate);
        };
        $scope.GetPOSearch = function (txt) {
            $scope.Model.DateFormat = $scope.DateFormat;
            service.getPOSearch(6, txt, $scope.PropertyID); // 6 for All in POStatus
        };
        $scope.getTaxFocus = function (item, index) {

            $scope.Index = index;

            $("#taxstructurebox").show('slow');
            $("#taxStructure").show('slow');
            $("#LinkTaxStructureDIV").show('slow');

            var items = "<option Value='0'>Select</option>";
            $.each($scope.TaxStructures, function (index, value) {
                items += "<option Value='" + value.Id + "'>" + value.Name + "</option>";
            });
            $("#applyTaxStructure").html(items);

            var taxStructureID = item.TaxStructureId;

            if (taxStructureID == null)
                taxStructureID = '';

            if ($scope.OldSelectedTaxStructureId == null)
                $scope.OldSelectedTaxStructureId = '';

            if (taxStructureID != '') {
                $scope.OldSelectedTaxStructureId = taxStructureID;
            }
            else {
                taxStructureID = $scope.OldSelectedTaxStructureId;
            }

            $("#applyTaxStructure").val(taxStructureID);
            GetLinkTax(taxStructureID);

        };
        $scope.AddItemTax = function () {

            var index = $scope.Index;

            $scope.OldSelectedTaxStructureId = $scope.SelectedTaxStructureId;

            $scope.Model.PurchaseOrderItems[index].TaxStructureId = $scope.SelectedTaxStructureId;

            $scope.Model.PurchaseOrderItems[index].LinkTaxStructures = [];
            angular.forEach($scope.TaxStructures, function (tax, i) {
                if (tax.Id == $scope.SelectedTaxStructureId) {
                    $scope.Model.PurchaseOrderItems[index].LinkTaxStructures = angular.copy(tax.LinkTaxStructures);
                }
            })
            //Calculate TAX
            $scope.CalculateTAX($scope.Model.PurchaseOrderItems);
            $scope.CalculateTotal();
            $('#taxstructurebox').hide('slow');

        }
        $scope.CalculateTAX = function (items) {

            var total = 0;
            $scope.TaxTypeTransaction = [];
            if (items.length > 0) {
                angular.forEach(items, function (item, index) {
                    if (item.LinkTaxStructures != undefined && item.LinkTaxStructures != '' && item.LinkTaxStructures != null)
                        if (item.LinkTaxStructures.length > 0) {

                            total = parseFloat($scope.CalculatedTaxValue(item, index));
                        }
                });
            }
            //total = $filter("number")(total, 2);
            //$scope.TaxAmount = total.replace(/,/g, "");
            //return $scope.TaxAmount;
        };
        $scope.CalculatedTaxValue = function (item, index) {
            //$scope.TaxStructureApply = [];

            var linkTaxStructures = item.LinkTaxStructures;
            var calculatetax = 0;
            var taxAmount = 0;
            item.TaxAmount = 0;
            item.PurchaseOrderItemTaxs = [];

            var itemAmount = item.Amount.toString();
            itemAmount = replaceAll(itemAmount, ',', '');

            var itemDiscount = item.Discount.toString();
            itemDiscount = replaceAll(itemDiscount, ',', '');

            for (var p = 0; p < linkTaxStructures.length; p++) {

                var itemtax = linkTaxStructures[p].TaxValue.toString();
                itemtax = replaceAll(itemtax, ',', '');

                if (linkTaxStructures[p].TaxOnId === 1 || linkTaxStructures[p].TaxOnId === 3) {

                    if (linkTaxStructures[p].TaxInName === "Percent") {
                        calculatetax = parseFloat(itemAmount) * parseFloat(itemtax) / 100;
                        $scope.TaxTypeTransaction.push({

                            Index: index,
                            TaxTypeId: linkTaxStructures[p].TaxTypeId,
                            TaxAmount: calculatetax,
                            TaxInId: 2,
                            TaxValue: linkTaxStructures[p].TaxValue

                        });
                    } else {
                        calculatetax = parseFloat(itemtax);
                        $scope.TaxTypeTransaction.push({

                            Index: index,
                            TaxTypeId: linkTaxStructures[p].TaxTypeId,
                            TaxAmount: calculatetax,
                            TaxInId: 1,
                            TaxValue: linkTaxStructures[p].TaxValue

                        });
                    }

                    item.TaxAmount += calculatetax;
                    calculatetax = 0;
                } else if (linkTaxStructures[p].TaxOnId === 2) {

                    var discoutedamount = 0;

                    if (item.DiscountInId === "2") {
                        discoutedamount = parseFloat(itemAmount) - (parseFloat(itemAmount) * parseFloat(itemDiscount) / 100);
                    } else {
                        discoutedamount = parseFloat(itemAmount) - parseFloat(itemDiscount);
                    }
                    if (linkTaxStructures[p].TaxInName === "Percent") {
                        calculatetax = parseFloat(discoutedamount) * parseFloat(itemtax) / 100;
                        $scope.TaxTypeTransaction.push({
                            Index: index,
                            TaxTypeId: linkTaxStructures[p].TaxTypeId,
                            TaxAmount: calculatetax,
                            TaxInId: 2,
                            TaxValue: linkTaxStructures[p].TaxValue
                        });
                    } else {
                        calculatetax = parseFloat(itemtax);
                        $scope.TaxTypeTransaction.push({
                            Index: index,
                            TaxTypeId: linkTaxStructures[p].TaxTypeId,
                            TaxAmount: calculatetax,
                            TaxInId: 1,
                            TaxValue: linkTaxStructures[p].TaxValue
                        });
                    }

                    item.TaxAmount += calculatetax;
                    calculatetax = 0;

                } else {
                    if ($scope.TaxTypeTransaction.length > 0) {

                        var taxontaxdata = linkTaxStructures[p].TaxTypeId.split("-");
                        var newautoId = (parseInt(taxontaxdata[0]) - 1) + "-" + taxontaxdata[1] + "-" + taxontaxdata[2];

                        for (var t = 0; t < $scope.TaxTypeTransaction.length; t++) {
                            if (newautoId === $scope.TaxTypeTransaction[t].TaxTypeId) {
                                if (linkTaxStructures[p].TaxInName === "Percent") {
                                    calculatetax = parseFloat($scope.TaxTypeTransaction[t].TaxAmount) * parseFloat(itemtax) / 100;
                                    $scope.TaxTypeTransaction.push({
                                        Index: index,
                                        TaxTypeId: linkTaxStructures[p].TaxTypeId,
                                        TaxAmount: calculatetax,
                                        TaxInId: 2,
                                        TaxValue: linkTaxStructures[p].TaxValue
                                    });
                                } else {
                                    calculatetax = parseFloat(itemtax);
                                    $scope.TaxTypeTransaction.push({
                                        Index: index,
                                        TaxTypeId: linkTaxStructures[p].TaxTypeId,
                                        TaxAmount: calculatetax,
                                        TaxInId: 1,
                                        TaxValue: linkTaxStructures[p].TaxValue
                                    });
                                }
                                item.TaxAmount += calculatetax;
                                calculatetax = 0;
                            }
                        }
                    }
                    item.TaxAmount += calculatetax; 0
                    calculatetax = 0;
                }
            }

            var taxSum = 0;
            var taxItem = 0;

            for (var l = 0; l < $scope.TaxTypeTransaction.length; l++) {

                taxSum += parseFloat($scope.TaxTypeTransaction[l].TaxAmount);
                //setting item wise tax amount

                if (index == $scope.TaxTypeTransaction[l].Index) {
                    item.PurchaseOrderItemTaxs.push({
                        TaxTypeId: $scope.TaxTypeTransaction[l].TaxTypeId,
                        TaxAmount: $scope.TaxTypeTransaction[l].TaxAmount,
                        TaxInId: $scope.TaxTypeTransaction[l].TaxInId,
                        TaxValue: $scope.TaxTypeTransaction[l].TaxValue
                    });
                }
            }
            item.TaxAmount = $filter("number")(item.TaxAmount, 2).replace(/,/g, "");
            var taxValue = $filter("number")(taxSum, 2).replace(/,/g, "");
            return parseFloat(taxValue);
        };

        $scope.GetAmount = function (index) {

            angular.forEach($scope.Model.PurchaseOrderItems, function (item, i) {

                if (item.Discount == undefined) {
                    item.Discount = 0;
                }

                if (i === index) {

                    $scope.Model.ApplyDiscount = "";
                    item.DiscountAmount = 0;
                    if (item.DiscountInId == '2') {
                        if (parseFloat(item.Discount) > 100) {
                            parent.failureMessage(item.InventoryItemName + " Percent(%) value can not be more then 100");
                            item.Discount = 0.00;
                            scrollPageOnTop();
                        }
                    } else if (item.DiscountInId == '1') {

                        var itemvalue = item.Amount.toString();
                        itemvalue = replaceAll(itemvalue, ',', '');

                        if (parseFloat(item.Discount) > parseFloat(itemvalue)) {
                            parent.failureMessage(item.InventoryItemName + " discount value can not be more then " + item.Amount);
                            item.Discount = 0.00;
                            scrollPageOnTop();
                        }
                    }

                    if (item.DiscountInId == '2') {
                        item.DiscountAmount = parseFloat(item.Rate) * parseFloat(item.Quantity) * item.Discount * 0.01;
                    }
                    else if (item.DiscountInId == '1')  {
                        item.DiscountAmount = item.Discount;
                    }
                    item.Amount = parseFloat(item.Rate) * parseFloat(item.Quantity);//- parseFloat(item.DiscountAmount);
                    item.Amount = $filter('number')(parseFloat(item.Amount), 2);
                }
            });

            $scope.Index = index;
            $scope.CalculateTAX($scope.Model.PurchaseOrderItems);
            $scope.CalculateTotal();
        }

        $scope.GetLinkTax = function (value) {

            GetLinkTax(value);
            $("#taxStructureDIV").show();
            $("#taxStructureDIV").show();
            $("#LinkTaxStructureDIV").show();
        };
        function GetLinkTax(value) {

            var str = "<table width='100%' border='1'><thead><tr><th align='center'>Sr No.</th><th align='center'>Tax Type </th><th align='center'>Tax In </th><th align='center'>Tax Value</th></tr></thead>";
            var trow = "";
            var i = 1;
            if (value != undefined && value != "") {
                $.each($scope.TaxStructures, function (index, val) {
                    if (val.Id == value) {
                        angular.forEach(val.LinkTaxStructures, function (link, key) {
                            trow += "<tr><td align='center'>" + i++ + "</td><td align='center'>" + link.TaxTypeName + "</td><td align='center'>" + link.TaxIn + "</td><td align='center'>" + link.TaxValue + "</td></tr>";
                        });
                    }
                });

                str += trow;
            }
            str += "</table>";
            $("#LinkTaxStructureDIV").html("<p>" + str + "</p>");
        };

        $scope.changeApplyDiscount = function (applyTax) {

            if (applyTax != "" && applyTax != undefined) {
            } else {
                applyTax = 0;
            }

            for (var i = 0; i < $scope.Model.PurchaseOrderItems.length; i++) {

                $scope.Model.PurchaseOrderItems[i].DiscountInId = '2';    //percentage
                $scope.Model.PurchaseOrderItems[i].Discount = applyTax;
                var discounts = ((parseFloat($scope.Model.PurchaseOrderItems[i].Quantity) * parseFloat($scope.Model.PurchaseOrderItems[i].Rate)) * parseFloat(applyTax)) / 100;
            }
            //Calculate TAX
            $scope.CalculateTAX($scope.Model.PurchaseOrderItems);
            $scope.CalculateTotal();
        };
        $scope.CalculateTotal = function () {

            var totalDiscount = 0.00;
            var totalTaxAmount = 0.00;
            var grossAmount = 0.00;
            var netAmount = 0.00;

            angular.forEach($scope.Model.PurchaseOrderItems, function (item) {

                var amount = item.Amount.toString();
                amount = replaceAll(amount, ',', '');

                var discount = item.Discount.toString();
                discount = replaceAll(discount, ',', '');

                var taxAmount =item.TaxAmount? item.TaxAmount.toString():"0";
                taxAmount = replaceAll(taxAmount, ',', '');

                if (item.DiscountInId === '2') {

                    totalDiscount += parseFloat((parseFloat(amount) * parseFloat(discount)) / 100);

                }
                else if (item.DiscountInId == '1'){
                    totalDiscount += parseFloat(discount);

                }

                grossAmount += parseFloat(amount);
                totalTaxAmount += parseFloat(taxAmount);

            });

            grossAmount +=  $scope.freightChargeServiceTotal;
            
            netAmount = grossAmount + totalTaxAmount - totalDiscount;

            $scope.Model.TotalAmount = $filter('number')(parseFloat(netAmount), 2).replace(/,/g, '');
            $scope.Model.TotalTax = $filter('number')(parseFloat(totalTaxAmount), 2).replace(/,/g, '');
            $scope.Model.TotalDiscount = $filter('number')(parseFloat(totalDiscount), 2).replace(/,/g, '');
            $scope.Model.GrossAmount = $filter('number')(parseFloat(grossAmount), 2).replace(/,/g, '');

        };
        $scope.freightChargeService = freightChargeService.init($scope,$scope.CalculateTotal);

        GetReason();
        function GetReason() {

            var promiseGet = service.getReason($scope.PropertyID);

            promiseGet.then(function (data) {

                $scope.Reasons = data;
            },
            function (data) {
                parent.failureMessage(data.message);
                scrollPageOnTop();
            });
        };

        $scope.Save = function (formName) {

            if ($scope.PONumber == "No Records Found") {
                $scope.PONumber = "";
            }
            if (!$scope[formName].$valid) {
                $scope.showErrorMsg = true;
                return;
            }
            if (angular.isUndefined($scope.Model.VendorId) || $scope.Model.VendorId === "" || $scope.Model.VendorId === null) {
                parent.failureMessage("Please Select Vendor.");
                scrollPageOnTop();
                return;
            }
            if (formName == 'modifyForm') {
                if (angular.isUndefined($scope.PONumber) || $scope.PONumber === "" || $scope.PONumber === null) {
                    parent.failureMessage("Please Select PO Number.");
                    scrollPageOnTop();
                    return;
                }
            }

            if (formName == 'createForm') {
               
                if ($scope.Model.PurchaseOrderItems.length === 0) {
                    parent.failureMessage("Please Select Item.");
                    scrollPageOnTop();
                    return;
                }
            }
                        
            angular.forEach($scope.Model.PurchaseOrderItems, function (item) {
                item.Amount = item.Amount.toString().replace(',', '');
            });

            for (var g = 0; g < $scope.Model.PurchaseOrderItems.length; g++) {

                if ($scope.Model.PurchaseOrderItems[g].Quantity === 0) {
                    parent.failureMessage("Item Quantity should not be 0.");
                    scrollPageOnTop();
                    return;
                }

                if ($scope.Model.PurchaseOrderItems[g].Rate === 0) {
                    parent.failureMessage("Please Enter Item Rate.");
                    scrollPageOnTop();
                    return;
                }
                 
                $scope.PODate = new Date($scope.Model.PODate);
                $scope.DeliveryDate = new Date($scope.Model.PurchaseOrderItems[g].DeliveryDate);
                if ($scope.PODate > $scope.DeliveryDate) {
                    parent.failureMessage("Delivery Date should not be less then Create PO Date.");
                    scrollPageOnTop();
                    return;
                }
            }

            if (formName == 'createForm') {

                $scope.Model.Id = null;
            }
            else {
                if (angular.isUndefined($scope.Model.ReasonId) || $scope.Model.ReasonId === "" || $scope.Model.ReasonId === null) {
                    parent.failureMessage("Please Select Reason.");
                    scrollPageOnTop();
                    return;
                }
            }

            if ($scope[formName].$valid) {

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                $scope.Model.DateFormat = $scope.DateFormat;
                
                $scope.Model.PurchaseOrderCharges=$scope.Charges;
                $scope.Model.PurchaseOrderTerms=$scope.PaymentTerms;//[{ PaymentTermId: $scope._PaymentTermId}];// $scope.PaymentTerms;
                $scope.IsSaving=true;
                var promiseGet = service.save($scope.Model);
                promiseGet.then(function (d) {

                    parent.successMessage("PO successfully saved.");
                    var m1 = d.Message.split(" ");
                    var idx= m1.indexOf("and");
                    var pid= idx > 0 ? m1[idx-1]: m1.pop();
                    var m2 =m1.join(' ');
                    if(idx > 0 ) m2 = m2.replace(pid,"");
                    
                    service.MapReport($scope.PropertyID, 'purchase_order')
                             .then(function (s) {
                                 //var m1 = d.Message.split(" ");
                                 //var idx= m1.indexOf("and");
                                 //var pid= idx > 0 ? m1[idx-1]: m1.pop();
                                 //var m2 =m1.join(' ');
                                 //if(idx > 0 ) m2 = m2.replace(pid,"");

                                 fancyPrintConfirm(m2, $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid);
                             }, function (e) {
                                 msg('Error in mapping to print.');
                             });
                    
                    if(!$scope.Model.Id || $scope.Model.Id.length<1) $scope.Model.Id = pid;
                    $scope.afterSaveBoxService.open('Purchase Order', $scope.htmlASBpo,$scope.poSend,Reset);
              
                    //Reset();
                    //scrollPageOnTop();
                },
                function (xhr) {
                    //var errorMessage = $.parseJSON(xhr.responseText);
                    msg(xhr.Message);
                }).finally(function(){
                    $scope.IsSaving=false;
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };
        
        $scope.getDuplicateItem = function (itemId, brandId, costCenterId, index) {

            for (var i = 0; i < $scope.Model.PurchaseOrderItems.length; i++) {
                if (index != i) {
                    if (($scope.Model.PurchaseOrderItems[i].InventoryItemId.length > 0) && ($scope.Model.PurchaseOrderItems[i].BrandId.length > 0) && ($scope.Model.PurchaseOrderItems[i].CostCenterId.length > 0)) {
                        if ($scope.Model.PurchaseOrderItems[i].InventoryItemId === itemId && $scope.Model.PurchaseOrderItems[i].BrandId === brandId && $scope.Model.PurchaseOrderItems[i].CostCenterId === costCenterId) {
                            parent.failureMessage("Same Item with duplicate Brand and Cost Center.");
                            $scope.Model.PurchaseOrderItems[index].CostCenterId = "";
                            scrollPageOnTop();
                            return;//  break;
                        }
                    }
                }
            }
            if($scope.Model.PoTypeId==='2') return;

            service.getItemRate($scope.PropertyID, itemId, brandId)
                .then(function (result) {

                    $scope.Model.PurchaseOrderItems[index].Rate = result.Data;
                    $scope.GetAmount(index);
                });
         
        }
        $scope.RemoveCreate = function (index) {

            $scope.Model.PurchaseOrderItems.splice(index, 1);
            if ($scope.Model.PurchaseOrderItems.length == 0) {
                $scope.Model.TotalAmount = "";
                $scope.Model.TotalDiscount = "";
                $scope.Model.TotalTax = "";
                $scope.Model.GrossAmount = "";
            }
            $scope.CalculateTotal();
        };

        Reset();
        function Reset() {

            $scope.Model = {
                Id: '',
                PODate: $filter('date')(date, $scope.DateFormat),
                PONumber: '',
                VendorId: "",
                VendorName: '',
                VendorCode: '',
                POStatusType: '',
                POStatusTypeId: 6,
                POStatusTypeName: '',
                PaymentTerms: '',
                Remarks: '',
                ApplyDiscount: '',
                TotalAmount: 0,
                TotalTax: 0,
                TotalDiscount: 0,
                GrossAmount: 0,
                DeliveryDate: '',
                ReasonId: '',
                ReasonName: '',
                ModificationRemarks: '',
                IsApproved: '',
                ApprovedBy: '',
                ApprovedByName: '',
                ApprovedDate: '',
                PurchaseOrderItems: [],
                PropertyID: '',
                ModifiedBy: '',
                DateFormat: '',
                items: [],
                PoTypeId : '1',
            };
            $scope.Model.PODate = $scope.ModifiedDate ;// $filter('date')(date, $scope.DateFormat);
            $scope.PurchaseOrders = [];
            $scope.PurchaseOrderItems = [];

            $scope.AuthorizationPOs = [];
            $scope.Model.Remarks = "";
            $("#authorizationSearch").val("");

            $scope.PONumber = "";
            $scope.Search = "";
            //$scope.SelectedTaxStructureId = "";
            $scope.GetAllPOVendor(6, '', '');

            scrollPageOnTop();
            $scope.prs=null;
            $scope.freightChargeService.reset();
            $scope.paymentTermsService.reset();
        }

        $scope.showPR = function (item, index) {
            $("#prbox").show('slow');
            if (!$scope.prs) $scope.getAllPR(34, 'All', 'All');
        };
        $scope.closePrBox = function () {
            $("#prbox").hide('slow');
        };
        $scope.usePR = function (item, index) {
            $scope.closePrBox();
            $scope.Model.PurchaseOrderItems=[];
            
            $scope.gridOptionsPR.data.forEach(function (row) {
                row.PurchaseRequisitionItems.forEach(function (subRow) {
                    if (subRow.IsSelected && subRow.Quantity>0)
                    {                     
                        if(!subRow.PurchaseRequisitionItemPOs ) subRow.PurchaseRequisitionItemPOs=[];
                        subRow.PurchaseRequisitionItemPOs.push({
                            PurchaseRequisitionItemId:subRow.Id,
                            UnitOfMeasurementId: subRow.UnitOfMeasurementId,
                            Quantity:subRow.Quantity,
                        });
                      
                        var poItem=angular.copy(subRow);
                        var idxT = subRow.RequiredDate.indexOf('T');
                        poItem.DeliveryDate=subRow.RequiredDate.substr(0,idxT > 0?idxT : null);
                        poItem.IsDisabled=true;
                      
                        var found = $scope.Model.PurchaseOrderItems.find(x=>x.InventoryItemId==subRow.InventoryItemId && x.BrandId==subRow.BrandId);// && x.PurchaseRequisitionId==subRow.Id);
                        if(found) {
                            found.Quantity+=subRow.Quantity;
                            subRow.PurchaseRequisitionItemPOs.forEach(function(ipo){
                                found.PurchaseRequisitionItemPOs.push(ipo);                           
                            });
                        }
                        else
                            $scope.Model.PurchaseOrderItems.push(poItem);
                    }
                });
            });

            $scope.Model.PurchaseOrderItems.forEach(function(poi,index){
                $scope.getDuplicateItem(poi.InventoryItemId,poi.BrandId,poi.CostCenterId,index);
            });
        };
        $scope.getAllPR = function (statusTypeId, searchText, searchType) {
            service.getAllPR($scope.PropertyID, statusTypeId, searchText, searchType)
                .then(function (result) {
                    result.Collection.forEach(function(row){
                        row.PurchaseRequisitionItems.forEach(function (subRow) {                        
                            subRow.QuantityOriginal=subRow.Quantity;
                            subRow.CostCenterId=row.CostCenterId;
                        });
                    });
                    $scope.gridOptionsPR.data = $scope.prs = result.Collection;
                    //$timeout(function () {
                    //    $scope.gridOptionsPR.data = $scope.prs = result.Collection;
                    //}, 1000);
                });
        };
        $scope.gridOptionsPR = {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: {
                text: "PR Details",
                style: 'headerStyle'
            },
            exporterPdfFooter: function (currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(),
                    style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22,
                    bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10,
                    bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {

                    if (row.isExpanded) {

                        row.entity.subGridOptions = {
                            appScopeProvider: $scope.subGridScope,
                            columnDefs: [
                            {
                                name: 'IsSelected', displayName: 'Select', pinnedLeft: true, type: 'boolean', cellTemplate: '<input type="checkbox" ng-model="row.entity.IsSelected" ng-click="grid.appScope.unCheck(row)"  >'
                            },
                            {
                                name: 'Quantity',displayName:'Order Quantity', cellClass: 'grid-align-right', cellTemplate: '<input type="text" ng-model="row.entity.Quantity" maxlength="12" only-digits >'
                            },
                            {
                                name: 'StoreName'
                            },
                            {
                                name: 'InventoryItemName'
                            },
                            {
                                name: 'BrandName'
                            },
                            {
                                name: 'ItemTypeName'
                            },
                            {
                                name: 'QuantityOriginal',displayName:'Quantity', cellClass: 'grid-align-right'
                            },
                             {
                                 name: 'UnitOfMeasurementName', displayName: 'UOM', cellClass: 'grid-align-right'
                             },
                            {
                                name: 'RequiredDate', cellFilter: 'date:' + $scope.DateFormat
                            }
                            ]
                        };
                        row.entity.subGridOptions.data = row.entity.PurchaseRequisitionItems;

                    }
                });

            },
           
        };
        $scope.gridOptionsPR.columnDefs = [
         {
             name: 'IsSelected', displayName: 'Select', pinnedLeft: true, type: 'boolean', cellTemplate: '<input type="checkbox" ng-model="row.entity.IsSelected" ng-click="grid.appScope.selectAllPRItem(row.entity)" >'
         },
         {
             name: 'PRNumber', pinnedLeft: true
         },
        {
            name: 'PRDate', cellFilter: 'date:grid.appScope.DateFormat'
        },
        {
            name: 'CostCenterName', displayName: 'Cost Center'
        },
        {
            name: 'ApprovedByName', displayName: 'Approved By'
        },
        {
            name: 'PRStatusTypeName', displayName: 'Status'
        }
        ];
        $scope.subGridScope =  { 
            unCheck : function (row) {
                 
                //if(!row.IsSelected) row.grid.parentRow.entity.IsSelected=false;
                var countChecked = 0;
                var count= 0;
                angular.forEach(row.grid.parentRow.entity.PurchaseRequisitionItems, function (key) {
                    count++;
                    if (key.IsSelected) {
                        countChecked++;
                    }
                });
                row.grid.parentRow.entity.IsSelected= countChecked ===count;
            }
        };
        $scope.selectAllPRItem = function (row) {
             
            row.PurchaseRequisitionItems.forEach(function (subRow) {
                subRow.IsSelected = row.IsSelected;
            });
        };
        $scope.unCheck = function () {
             
            var countChecked = 0;
            var count= 0;
            angular.forEach($scope.prs, function (key) {
                count++;
                if (key.IsSelected) {
                    countChecked++;
                }
            });
            if (countChecked <count) $scope.selectAllT = false;
        }
   
        //----for Tab-3-----
        $scope.GetItemSearch1 = function (txt) {
            service.getItemSearch1(txt, $scope.PropertyID);
        };
        $scope.GetPOSearchMO = function (txt) {
            service.getPOSearchMO(3, txt, $scope.PropertyID);   // 3 for Pending in POStatus
        };

        //------For Tab-4-------
        $scope.GetPOSearchCancel = function (txt) {

            service.getPOSearchCancel(3, txt, $scope.PropertyID);   // 3 for Pending in POStatus
        };
        $scope.CancelPO = function (formName) {
            //if (angular.isUndefined($scope.Model.VendorId) || $scope.Model.VendorId === "" || $scope.Model.VendorId === null) {
            //    parent.failureMessage("Please Select Vendor.");
            //    scrollPageOnTop();
            //    return;
            //}

            //if (formName === 'cancelForm') {
            //    
            //    $scope.Model.Id = null;
            //}

            if (angular.isUndefined($scope.PONumber) || $scope.PONumber === "" || $scope.PONumber === null) {
                parent.failureMessage("Please Select PO Number.");
                scrollPageOnTop();
                return;
            }

            if (angular.isUndefined($scope.Model.ReasonId) || $scope.Model.ReasonId === "" || $scope.Model.ReasonId === null) {
                parent.failureMessage("Please Select Reason.");
                scrollPageOnTop();
                return;
            }

            //angular.forEach($scope.Model.PurchaseOrderItems, function (item) {
            //    item.Amount = item.Amount.toString().replace(',', '');

            //    if (item.Quantity === 0) {
            //        parent.failureMessage("Item Quantity should not be 0.");
            //        scrollPageOnTop();
            //        return;
            //    }

            //    $scope.datepo = new Date($scope.Model.PODate);
            //    $scope.DeliveryDate = new Date(item.DeliveryDate);
            //    if ($scope.datepo < $scope.DeliveryDate) {
            //        parent.failureMessage("PO Date should be greater then Delivery Date.");
            //        scrollPageOnTop();
            //        return;
            //    }

            //});

            if ($scope[formName].$valid) {

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;

                var promiseGet = service.cancelPO($scope.Model);

                promiseGet.then(function (details) {


                    parent.successMessage("PO Cancel successfully.");
                    Reset();
                    scrollPageOnTop();

                },
                function (xhr) {
                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };

        //----For Tab-5----
        $scope.GetPOSearchClose = function (txt) {

            $scope.Model.DateFormat = $scope.DateFormat;
            service.getPOSearchClose(4, txt, $scope.PropertyID);    // 4 for partial in POStatus
        };
        $scope.ClosePO = function (formName) {

            //if (angular.isUndefined($scope.Model.VendorId) || $scope.Model.VendorId === "" || $scope.Model.VendorId === null) {
            //    parent.failureMessage("Please Select Vendor.");
            //    scrollPageOnTop();
            //    return;
            //}
            if (angular.isUndefined($scope.PONumber) || $scope.PONumber === "" || $scope.PONumber === null) {
                parent.failureMessage("Please Select PONumber.");
                scrollPageOnTop();
                return;
            }
            if (angular.isUndefined($scope.Model.ReasonId) || $scope.Model.ReasonId === "" || $scope.Model.ReasonId === null) {
                parent.failureMessage("Please Select Reason.");
                scrollPageOnTop();
                return;
            }

            //angular.forEach($scope.Model.PurchaseOrderItems, function (item) {
            //    item.Amount = item.Amount.toString().replace(',', '');

            //    if (item.Quantity === 0) {
            //        parent.failureMessage("Item Quantity should not be 0.");
            //        scrollPageOnTop();
            //        return;
            //    }

            //    $scope.datepo = new Date($scope.Model.PODate);
            //    $scope.DeliveryDate = new Date(item.DeliveryDate);
            //    if ($scope.datepo < $scope.DeliveryDate) {
            //        parent.failureMessage("PO Date should be greater then Delivery Date.");
            //        scrollPageOnTop();
            //        return;
            //    }

            //});

            if ($scope[formName].$valid) {

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                $scope.Model.DateFormat = $scope.DateFormat;

                var promiseGet = service.closePO($scope.Model);
                promiseGet.then(function (details) {

                    parent.successMessage("PO Closed successfully.");
                    Reset();
                    scrollPageOnTop();
                },
                function (xhr) {

                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };

        //---For Tab-6-----
        $scope.AuthorizationPOs = [];
        $scope.checkAllAuthorizationPO = function () {
            if ($scope.selectedAllAuthorization) {
                angular.forEach($scope.PurchaseOrders, function (value, key) {
                    value.IsApproved = true;
                    $scope.AuthorizationPOs.push(value);
                });
                $scope.selectedAllAuthorization = true;
            } else {
                angular.forEach($scope.PurchaseOrders, function (value, key) {
                    value.IsApproved = false;
                });
                $scope.AuthorizationPOs = [];
                $scope.selectedAllAuthorization = false;
            }
        };

        $scope.toggleSelection = function (itm) {
            var idx = $scope.AuthorizationPOs.indexOf(itm);
            if (idx > -1) {
                $scope.AuthorizationPOs.splice(idx, 1);
            } else {
                $scope.AuthorizationPOs.push(itm);
            }
        };

        $scope.GetPOSearchAuthorized = function (txt) {

            // 3 for Pending in POStatus
            service.getPOSearchAuthorized(3, txt, $scope.PropertyID);


        };

        $scope.PurchaseOrders = [];
        $scope.GetUnauthorizedList = function () {
            $scope.PurchaseOrders = [];
            $scope.Model.PurchaseOrderItems = [];

            var promiseGet = service.getUnauthorizedList($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.PurchaseOrders = data;
                FormatPO($scope.PurchaseOrders);

            },
            function (data) {
                parent.failureMessage(data.message);
                scrollPageOnTop();
            });
        };
        $scope.SaveAuthorization = function () {
            if (!$scope.keys.IsAuthorize)
            {  
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }

            if ($scope.Model.Remarks == undefined)
                $scope.Model.Remarks = "";

            if ($scope.AuthorizationPOs.length == 0) {
                parent.failureMessage("Please select atleast one PO.");
                scrollPageOnTop();
                return;
            }

            angular.forEach($scope.AuthorizationPOs, function (value, key) {
                value.ModificationRemarks = $scope.Model.Remarks;
                value.ApprovedDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
                value.PropertyID = $scope.PropertyID;
                value.ModifiedBy = $scope.ModifiedBy;
            });

            var promiseGet = service.saveAuthorization($scope.AuthorizationPOs);

            promiseGet.then(function (details) {
                parent.successMessage("Authorization successfully saved.");
                scrollPageOnTop();
                $scope.GetUnauthorizedList();
                Reset();

            },
            function (xhr) {
                var errorMessage = $.parseJSON(xhr.responseText);
                parent.failureMessage(errorMessage.Message);
                scrollPageOnTop();
            });
            scrollPageOnTop();
        };

        $scope.ClearModel = function () {

            //$scope.Model = {};
            $scope.Model.PurchaseOrderItems = [];
            $scope.PurchaseOrderItem = {};
            $scope.PurchaseOrderItemTax = {};
            $scope.PONumber = '';
            $scope.query = '';
            $scope.SelectedTaxStructureId = "";
            Reset();
        };
        //$scope.poEmail=function(){
        //    //msg("calling email",true);
        //    //m.PropertyID = $scope.PropertyID;
        //    //m.ModifiedBy = $scope.ModifiedBy;

        //    service.send($scope.Model)
        //        .then(function (s) {
        //            if (s) {
        //                msg(s.Message, true);
        //            }
        //        }, function (e) {
        //            msg(e.Message);
        //        });
        //};
        $scope.poSend=function(sms){

            service.send($scope.PropertyID,$scope.Model.Id,sms)
                .then(function (s) {
                    if (s) {
                        msg(s.Message, true);
                    }
                }, function (e) {
                    msg(e.Message);
                });
        };

        $scope.htmlASBpo = `<p>
                   <div class="row">
               <div class="col-md-4"><strong>PO Type : </strong> <span>{{Model.PoTypeId==="1"?"Regular":Model.PoTypeId==="2"?"Contract":"Service"}}</span> </div>
               <div class="col-md-4"><strong>Transaction Date : </strong> <span>{{Model.PODate|date:DateFormat}}</span> </div>
               <div class="clearfix"></div>
                                        <div class="clearfix"></div>
                                    <div class="clearfix"></div>

                                    <div class="row margin-top-15">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-hover table-striped" style="width:100% !important;">
                                                    <thead>
                                                        <tr>
                                                            <th>SNo</th>
                                                            <th>Item</th>
                                                            <th>Brand</th>
                                                            <th>UoM</th>
                                                            <th>Qty</th>
                                                            <th>Cost Conter</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr data-ng-repeat="item in Model.PurchaseOrderItems track by $index">
                                                            <td>{{$index+1}}</td>
                                                    <td>{{item.InventoryItemName}}</td>
                                                    <td>{{item.BrandName}}</td>
                                                    <td>{{item.UnitOfMeasurementName}}</td>
                                                    <td>{{item.Quantity}}</td>
                                                    <td>{{item.CostCenterName}}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <br /><br />
                        </p>`;
                       
}
]);
