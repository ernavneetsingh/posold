﻿
'use strict';
app.service('PurchaseRequisitionService', ['$http', '$q', '$filter', function ($http, $q, $filter) {

    this.getReasons = function (propertyId, moduleId) {
        return httpCaller(apiPath + "GlobalSetting/Reason/all", $http, $q, { propertyId: propertyId, moduleId: moduleId, active: 1 });
    };
    this.getCostCenters = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/CostCenter/all", $http, $q, { propertyId: propertyId, active: 1 });
    };

    this.getItemSearch = function (searchTxt, propertyId) {

        $("#searchItem")
            .autocomplete({
                source: function (request, response) {

                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: apiPath + 'Inventory/InventoryItem/AllBySearchTxt?searchTxt=' + searchTxt + "&propertyId=" + propertyId,
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.Name,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {
                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {

                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();

                            scope.$apply(function () {
                                var promiseGet = getSearchitemsDetails(ui.item.val, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.InventoryItem = data.Data;
                                    if ((scope.InventoryItem != null) && scope.InventoryItem != '') {

                                        scope.PurchaseRequisitionItem = {};
                                        scope.PurchaseRequisitionItem.Id = '';
                                        scope.PurchaseRequisitionItem.PurchaseRequisitionId = '';
                                        scope.PurchaseRequisitionItem.CostCenterId = scope.model.CostCenterId;
                                        scope.PurchaseRequisitionItem.CostCenterName = '';
                                        scope.PurchaseRequisitionItem.InventoryItemId = scope.InventoryItem.Id;
                                        scope.PurchaseRequisitionItem.InventoryItemName = scope.InventoryItem.Name;
                                        scope.PurchaseRequisitionItem.InventoryItemCode = scope.InventoryItem.Code;
                                        scope.PurchaseRequisitionItem.ItemTypeId = scope.InventoryItem.ItemTypeId;
                                        scope.PurchaseRequisitionItem.ItemTypeName = scope.InventoryItem.ItemTypeName;
                                        scope.PurchaseRequisitionItem.BrandId = '';
                                        scope.PurchaseRequisitionItem.BrandName = '';
                                        scope.PurchaseRequisitionItem.UnitOfMeasurementId = scope.InventoryItem.UnitOfMeasurementId;
                                        scope.PurchaseRequisitionItem.UnitOfMeasurementName = scope.InventoryItem.UnitOfMeasurementName;
                                        scope.PurchaseRequisitionItem.Quantity = 1;
                                        scope.PurchaseRequisitionItem.RequiredDate = scope.ModifiedDate;//SelectedDeliveryDate;

                                        scope.PurchaseRequisitionItem.ForDisplayBrands = scope.InventoryItem.Brands;

                                        if (scope.PurchaseRequisitionItem.ForDisplayBrands.length == 1) {
                                            scope.PurchaseRequisitionItem.BrandId = scope.PurchaseRequisitionItem.ForDisplayBrands[0].Id;
                                            scope.getDuplicateItem(scope.PurchaseRequisitionItem);
                                        }

                                        scope.PurchaseRequisitionItem.PropertyID = scope.PropertyID;
                                        scope.PurchaseRequisitionItem.ModifiedBy = scope.ModifiedBy;
                                        scope.PurchaseRequisitionItem.DateFormat = scope.DateFormat;

                                        scope.model.PurchaseRequisitionItems.push(scope.PurchaseRequisitionItem);
                                    }
                                    scope.Search = "";
                                }, function (error, status) {
                                    parent.failureMessage(error.Message);
                                });
                            });
                        }
                    }
                },
                minLength: 1
            });
    };
    function getSearchitemsDetails(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "Inventory/InventoryItem/GetItemById?propertyId=" + propertyId + "&id=" + itemId,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getAll = function (propertyId, statusTypeId, searchText, searchType) {
        return httpCaller(apiPath + "Inventory/PurchaseRequisition/all/", $http, $q, { propertyId: propertyId, statusTypeId: statusTypeId, searchText: searchText, searchType: searchType });
    };
    this.save = function (model) {
        var params = { model: model };
        return httpPoster(apiPath + "Inventory/PurchaseRequisition/Save", $http, $q, model);
    };

    this.getPRSearch = function (poStatusTypeId, searchTxt, propertyId) {

        $("#searchPR")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/PurchaseRequisition/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {

                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.PRNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        if (ui.item.value !== "No Records Found") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();
                            scope.$apply(function () {
                                var promiseGet = getPRDetails(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.model = data.Data;
                                    scope.model.PurchaseRequisitionItems.forEach(function (item) {
                                        scope.getDuplicateItem(item);
                                    });

                                }, function (error, status) {
                                    msg(error.Message);
                                });
                            });
                        }
                    }
                },
                minLength: 1
            });
    };
    function getPRDetails(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + 'Inventory/PurchaseRequisition/exist/' + itemId + "/" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getPRSearchMO = function (poStatusTypeId, searchTxt, propertyId, control) {

        $("#modifiedPRDetails")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/PurchaseRequisition/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.PRNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            if (ui.item.value === "No Records Found") {
                                ui.item.value = "";
                            }
                            else {
                                var promiseGet = getPRDetailsMO(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.model = data.Data;
                                    scope.model.PurchaseRequisitionItems.forEach(function (item) {
                                        scope.getDuplicateItem(item);
                                    });
                                }, function (error, status) {

                                    parent.failureMessage(error.Message);
                                });

                            }
                        });
                    }
                },
                minLength: 1
            });
    };
    function getPRDetailsMO(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + 'Inventory/PurchaseRequisition/exist/' + itemId + "/" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getItemSearch1 = function (searchTxt, propertyId) {
        $("#search_item-mo")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: apiPath + 'Inventory/InventoryItem/AllBySearchTxt?searchTxt=' + searchTxt + "&propertyId=" + propertyId,
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.Name,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();
                            scope.$apply(function () {
                                var promiseGet = getSearchitemsDetails1(ui.item.val, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.InventoryItem = data.Data;
                                    if ((scope.InventoryItem != null) && scope.InventoryItem != '') {

                                        scope.PurchaseRequisitionItem = {};
                                        scope.PurchaseRequisitionItem.Id = '';
                                        scope.PurchaseRequisitionItem.PurchaseRequisitionId = '';
                                        scope.PurchaseRequisitionItem.StoreId = scope.InventoryItem.StoreId;
                                        scope.PurchaseRequisitionItem.StoreName = scope.InventoryItem.StoreName;
                                        scope.PurchaseRequisitionItem.InventoryItemId = scope.InventoryItem.Id;
                                        scope.PurchaseRequisitionItem.InventoryItemName = scope.InventoryItem.Name;
                                        scope.PurchaseRequisitionItem.InventoryItemCode = scope.InventoryItem.Code;
                                        scope.PurchaseRequisitionItem.ItemTypeId = scope.InventoryItem.ItemTypeId;
                                        scope.PurchaseRequisitionItem.ItemTypeName = scope.InventoryItem.ItemTypeName;
                                        scope.PurchaseRequisitionItem.BrandId = '';
                                        scope.PurchaseRequisitionItem.BrandName = '';
                                        scope.PurchaseRequisitionItem.UnitOfMeasurementId = scope.InventoryItem.UnitOfMeasurementId;
                                        scope.PurchaseRequisitionItem.UnitOfMeasurementName = scope.InventoryItem.UnitOfMeasurementName;
                                        scope.PurchaseRequisitionItem.Rate = scope.InventoryItem.Rate;
                                        scope.PurchaseRequisitionItem.Quantity = 1;
                                        scope.PurchaseRequisitionItem.RequiredDate = '',
                                        scope.PurchaseRequisitionItem.ForDisplayBrands = scope.InventoryItem.Brands;
                                        if (scope.PurchaseRequisitionItem.ForDisplayBrands.length == 1) {
                                            scope.PurchaseRequisitionItem.BrandId = scope.PurchaseRequisitionItem.ForDisplayBrands[0].Id;
                                            scope.getDuplicateItem(scope.PurchaseRequisitionItem);
                                        }
                                        scope.PurchaseRequisitionItem.PropertyID = scope.PropertyID;
                                        scope.PurchaseRequisitionItem.ModifiedBy = scope.ModifiedBy;
                                        scope.model.PurchaseRequisitionItems.push(scope.PurchaseRequisitionItem);

                                    }

                                    scope.Search1 = "";

                                }, function (error, status) {

                                    parent.failureMessage(error.Message);
                                });
                            });
                        }
                    }
                },
                minLength: 1
            });
    };
    function getSearchitemsDetails1(itemId, propertyId) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "Inventory/InventoryItem/GetItemById?propertyId=" + propertyId + "&id=" + itemId,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getPRSearchCancel = function (poStatusTypeId, searchTxt, propertyId) {

        $("#cancelPRDetails")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/PurchaseRequisition/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.PRNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {

                    if (ui.item) {

                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            if (ui.item.value === "No Records Found") {
                                ui.item.value = "";
                            }
                            else {
                                //if (ui.item.value !== "No Record Found!") {
                                var promiseGet = getPRDetailsCancel(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {
                                    //scope.Model.PODate = $filter('date')(Model.PODate, scope.DateFormat);
                                    //angular.forEach(data.Data.PurchaseRequisitionItems, function (val) {

                                    //    val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);;
                                    //    val.DiscountInId = val.DiscountInId.toString();
                                    //});

                                    scope.model = data.Data;
                                    //scope.Model.VendorId = scope.Model.VendorId.toString();
                                    //scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                },
                                    function (error, status) {
                                        parent.failureMessage(error.Message);
                                    });
                            }
                        });
                    }
                },
                minLength: 1
            });
        //});
    };
    function getPRDetailsCancel(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + 'Inventory/PurchaseRequisition/exist/' + itemId + "/" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.cancelPR = function (model) {

        var deferred = $q.defer();
        var url = apiPath + 'Inventory/PurchaseRequisition/SaveCancel';
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    this.getPRSearchClose = function (poStatusTypeId, searchTxt, propertyId) {

        $("#closePRDetails")
            .autocomplete({
                source: function (request, response) {

                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/PurchaseRequisition/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {

                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.PRNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {

                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();
                            scope.$apply(function () {
                                var promiseGet = getPRDetailsClose(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {


                                    var ReceiveItems = [];
                                    //angular.forEach(data.Data.PurchaseRequisitionItems, function (item) {

                                    //    item.DeliveryDate = $filter('date')(item.DeliveryDate, item.DateFormat);;
                                    //    item.DiscountInId = item.DiscountInId.toString();

                                    //    if (item.QuantityToReceive != 0) {
                                    //        ReceiveItems.push(item);
                                    //    }
                                    //});

                                    scope.model = data.Data;
                                    //scope.Model.PurchaseRequisitionItems = [];
                                    //scope.model.PurchaseRequisitionItems = ReceiveItems;
                                    //scope.Model.VendorId = scope.Model.VendorId.toString();
                                    //scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);
                                },
                                    function (error, status) {

                                        parent.failureMessage(error.Message);
                                    });
                            });
                        }
                    }
                },
                minLength: 1
            });
        //});
    };
    function getPRDetailsClose(poid, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + "Inventory/PurchaseRequisition/GetPendingPoItems?poId=" + poid + "&propertyId=" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.closePR = function (model) {

        var deferred = $q.defer();
        var url = apiPath + 'Inventory/PurchaseRequisition/SaveClose';
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    this.getPRSearchAuthorized = function (poStatusTypeId, searchTxt, propertyId) {

        $("#authorization_search_po")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/PurchaseRequisition/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.PONumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();
                            scope.$apply(function () {

                                scope.PurchaseRequisitions = [];

                                var promiseGet = getPRDetailsAuthorized(ui.item.value, propertyId);

                                promiseGet.then(function (data, status) {

                                    //angular.forEach(data.Data.PurchaseRequisitionItems, function (val) {
                                    //    val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);;
                                    //    val.DiscountInId = val.DiscountInId.toString();
                                    //});

                                    scope.model = data.Data;
                                    //scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                    scope.PurchaseRequisitions.push(scope.model);

                                },
                                    function (error, status) {

                                        parent.failureMessage(error.Message);
                                    });
                            });
                        }
                    }
                },
                minLength: 1
            });
        //});
    };
    this.getUnauthorizedList = function (propertyId) {
        var url = apiPath + "Inventory/PurchaseRequisition/GetAllNotApproved/" + propertyId;
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result.Collection);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;

    };
    this.saveAuthorization = function (PurchaseRequisitions) {

        var deferred = $q.defer();
        var url = apiPath + 'Inventory/PurchaseRequisition/SaveAuthorization';
        $http({
            dataType: 'json',
            method: 'POST',
            url: url,
            data: JSON.stringify(PurchaseRequisitions),
            headers: {
                "duxtechApiKey": accessToken,
                "Content-Type": "application/json"
            }
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    this.getItemStock = function (propertyId, itemId, brandId, date, costCenterId) {
        var params = { propertyId: propertyId, date: date, itemId: itemId, brandId: brandId, costCenterId: costCenterId };
        if (costCenterId)
            return httpCaller(apiPath + "Inventory/InventoryTransactionItem/StockByCostCenter", $http, $q, params);
        return httpCaller(apiPath + "Inventory/InventoryTransactionItem/Stock", $http, $q, params);
    };
    this.getItemRate = function (propertyId, itemId, brandId) {
        if (!brandId) brandId = "0";
        var params = { propertyId: propertyId, itemId: itemId, brandId: brandId };
        return httpCaller(apiPath + "Inventory/InventoryTransactionItem/LastRate", $http, $q, params);
    };

    this.MapReport = function (filterValue, reportName) {
        return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
    };

}]);
