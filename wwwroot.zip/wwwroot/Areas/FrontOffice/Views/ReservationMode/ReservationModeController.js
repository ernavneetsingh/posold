﻿
app.controller("ReservCtler",
    function ($scope, $http, $filter, $cookies, reservationmodeService, $window, localStorageService) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.IsActive = true;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";

        $scope.dt = $filter("date")(new Date(), $scope.DateFormat);

        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
        getreservationmodeData();

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "Code" || attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;

        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        //Save/Update
        $scope.Save = function (form) {



            if ($scope[form].$valid) {



                var reservmodeData = new Object();

                reservmodeData.Code = $scope.Code;
                reservmodeData.Name = $scope.Name;
                reservmodeData.Description = $scope.Description;
                reservmodeData.IsActive = $scope.IsActive;

                reservmodeData.PropertyID = $scope.PropertyID;
                reservmodeData.ModifiedBy = $scope.UserName;

                reservmodeData.Id = $scope.Id;
                reservmodeData.ApplicableFrom = $scope.dt;
                var saveData = reservationmodeService.savereservmodeData(reservmodeData);
                saveData.then(function (data) {
                    $scope.Code = "";
                    $scope.Name = "";
                    $scope.Description = "";
                    $scope.IsActive = true;
                    $scope.Id = "";
                    $scope.IsReadonly = false;
                    $scope.dt = $filter("date")(new Date(), $scope.DateFormat);
                    getreservationmodeData();
                    parent.successMessage(data.Message);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
            scrollPageOnTop();

        };
        //Reset All Feild
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.Code = "";
            $scope.Name = "";
            $scope.Description = "";
            $scope.IsActive = true;
            $scope.Id = "";
            $scope.IsReadonly = false;
            $scope.dt = $filter("date")(new Date(), $scope.DateFormat);
            scrollPageOnTop();
            $scope.query = "";
            $scope.search();
        };

        //Get All floor Data
        function getreservationmodeData() {
            $scope.ActionMode = "";
            var getData = reservationmodeService.getreservationmodeData($scope.PropertyID);
            getData.then(function (reservmodeData) {
                $scope.$apply(function () {
                    $scope.items = reservmodeData.Collection;
                    $scope.search();
                });
            });
        };

        //Change floor Status
        $scope.activeRow = function (reservmodeData) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var statusData = reservationmodeService.statusreservmodeData(reservmodeData, $scope.UserName);
            statusData.then(function (data) {
                getreservationmodeData();
                parent.successMessage(data.Message);
            });
            scrollPageOnTop();
        };

        //Delete Record
        $scope.removeRow = function (reservmodeData) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (reservmodeData != undefined) {

                                var removeData = reservationmodeService.removereservmodeData(reservmodeData);
                                removeData.then(function (data) {
                                    parent.successMessage(data.Message);
                                    $("html, body").animate({ scrollTop: 0 }, "slow");
                                    getreservationmodeData();

                                },
                                    function (error) {
                                        parent.failureMessage(error.Message);
                                        $("html, body").animate({ scrollTop: 0 }, "slow");
                                    });
                            }
                            $.fancybox.close();
                        });
                }
            });
            scrollPageOnTop();

        };

        //Check existing floor Code
        $scope.txtreservModeCodes = function () {
            if (!$scope.Code) return;
            var floorCode = reservationmodeService.reservmodeDataExists($scope.Code, $scope.PropertyID);
            floorCode.then(function (data) {

            }, function (error) {
                //error handler function 
                $scope.$apply(function () {
                    $scope.Code = "";
                });

            });
        };

        //Fill floor Data 
        $scope.fillreservmodeData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.Code = record.Code;
            $scope.Name = record.Name;
            $scope.Description = record.Description;
            $scope.IsActive = record.IsActive;
            $scope.Id = record.Id;
            $scope.IsReadonly = true;
            $scope.dt = $filter("date")(record.ApplicableFrom, $scope.DateFormat);
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);

        };
    });
