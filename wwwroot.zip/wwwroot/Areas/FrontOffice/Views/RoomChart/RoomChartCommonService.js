﻿app.service('roomChartCommonService', ["$http", "$q","$filter", function ($http, $q,$filter) {

    var GetRoomChart = function (scope) {
        prevMonth = "";
        scope.ProgressStart();
        scope.RoomChart = {
            PropertyID: scope.PropertyID,
            FromDate: GetServerDate( scope.date.startDate, scope.DateFormat),
            ToDate: GetServerDate(scope.date.endDate, scope.DateFormat),
            BusinessDate: businessDate,
            RoomTypes:[],
            Days:[],
        };

        var promiseGet = roomChartService.GetRoomChartCalendar(scope.RoomChart);
        promiseGet.then(function (data, status) {
            var fromDate = GetMomentDate($filter('date')(scope.RoomChart.FromDate, scope.DateFormat), scope.DateFormat);
            var toDate = GetMomentDate($filter('date')(scope.RoomChart.ToDate, scope.DateFormat), scope.DateFormat);
            var id=1;
            for (var m = moment(fromDate) ; m.isBefore(toDate) ; m.add(1, 'days')) {
                var day ={
                    Id : id,
                    Day : m.format('DD'),
                    DayName : m.format("ddd"),
                    Month : m.format('MM'),
                    MonthName : m.format("MMM"),
                    Year : m.format('YY'),
                    IsSelected :false,
                    FutureDate : m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD'),
                    IsWeekEnd : m.format("ddd") == 'Sun' ? true : m.format("ddd") == 'Sat' ? true : false,
                };
                scope.RoomChart.Days.push(day);
                id++;
            }
            var roomList = data.Data;
            var roomTypeIds = scope.GetDistinctRoomType(roomList);
            angular.forEach(roomTypeIds, function (roomTypeId) {
                var roomType ={
                    Id:roomTypeId,
                    IsStickyDayName:false,
                    Rooms:[],
                    Availabilitys:[],
                } ;
                    
                var rooms = roomList.filter(x => x.RoomTypeId == roomTypeId);
                for (var m = moment(fromDate) ; m.isBefore(toDate) ; m.add(1, 'days')) {
                    var date = m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD');
                    var availability = 
                    {
                        Id : id,
                        Day : m.format('DD'),
                        DayName : m.format("ddd"),
                        Month : m.format('MM'),
                        //MonthName : m.format("MMM"),
                        Year : m.format('YYYY'),
                        IsSelected :false,
                        FutureDate : m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD'),
                        IsWeekEnd : m.format("ddd") == 'Sun' ? true : m.format("ddd") == 'Sat' ? true : false,
                        IsBusinessDate :GetMomentDate(date,'YYYY-MM-DD').isSame(GetMomentDate(scope.MinDate ,'YYYY-MM-DD')) ? true : false,
                        RoomTypeId:roomTypeId,
                        RoomCount:rooms.length,
                        ManagementBlockCount:0,
                        MaintenanceBlockCount :0,
                        ReservationBlockCount:0,
                        OccupiedCount:0,
                        AvailabilityCount :0,//= roomType.Rooms.Count - (managementBlocks.Count + maintenanceBlocks.Count + reservationBlocks.Count + occupieds.Count) - roomTypeDay.TotalDayReservation,
                        TotalDayReservation :0,// roomTypeDay.TotalDayReservation,
                    };
                    roomType.Availabilitys.push(availability);
                }
                    
                angular.forEach(rooms,function(room){
                        
                    roomType.RoomTypeOrder = rooms[0].RoomTypeOrder;
                    id=1;
                    var r ={
                        Id:room.RoomMasterId,
                        Name:room.RoomNumber,
                        RoomTypeId:roomTypeId,
                        RoomTypeName:rooms[0].RoomTypeName,
                        RoomOrder:room.RoomOrder,
                        MaxPerson:room.MaxPerson,
                        CurrentRoomStatusId:room.CurrentRoomStatusId,
                        Days:[],
                        IsShow:true,
                        IsLinkRoom : true,
                        LinkRooms:[]
                    }
                    for (var m = moment(fromDate) ; m.isBefore(toDate) ; m.add(1, 'days')) {
                        var date = m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD');
                        Object.keys(room).filter(function (col,key) {

                            if(key>8)
                            {
                                var roomDay  ={
                                    Id : id,
                                    DayPart:'AM',
                                    Day : m.format('DD'),
                                    DayName : m.format("ddd").toUpperCase(),
                                    Month : m.format('MM'),
                                    MonthName : m.format("MMM").toUpperCase(),
                                    Year : m.format('YYYY'),
                                    IsSelected :false,
                                    FutureDate : m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD'),
                                    IsWeekEnd : m.format("ddd") == 'Sun' ? true : m.format("ddd") == 'Sat' ? true : false,
                                    IsBusinessDate :GetMomentDate(date,'YYYY-MM-DD').isSame(GetMomentDate(scope.MinDate ,'YYYY-MM-DD')) ? true : false,
                                    RoomTypeId : roomTypeId,
                                    RoomTypeName:rooms[0].RoomTypeName,
                                    RoomId : room.RoomMasterId,
                                    RoomNumber: room.RoomNumber,
                                    Content :  room[col],
                                    OccupiedStatusId:'1',
                                    IsCheckOUTToday:false,
                                    Left:0,
                                    Top:0,
                                    //RoomStatusTypeId:1,
                                };
                                    
                                if(date +'P' ==col)
                                {
                                    roomDay.DayPart='PM';
                                }

                                var data =data = room[col].split('$');
                                    
                                var totalDayReservation = data[data.length-1];

                                roomDay.RoomStatusTypeId=data[0];

                                if(roomDay.RoomStatusTypeId=='4')
                                {
                                    roomDay.RoomBlockId = data[2];
                                }
                                else if(roomDay.RoomStatusTypeId=='5')
                                {
                                    roomDay.RoomBlockId = data[2];
                                }
                                else if(roomDay.RoomStatusTypeId=='6')
                                {
                                        
                                    roomDay.ReservationRoomTypeId = data[1];
                                    roomDay.ReservationId = data[2];
                                    roomDay.GuestName = data[4];
                                    roomDay.FromDateStr = data[7];
                                    roomDay.ToDateStr= data[8];
                                    try
                                    {
                                        roomDay.BookingTypeId= data[10];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId);
                                    }
                                    catch(ex){}
                                }
                                else if(roomDay.RoomStatusTypeId=='7')
                                {
                                    roomDay.CheckINGuestRoomId = data[1];
                                    roomDay.CheckINId = data[2];
                                }
                                else if(roomDay.RoomStatusTypeId=='8')
                                {
                                    roomDay.CheckINGuestRoomId = data[1];
                                    roomDay.CheckINId = data[2];
                                }
                                else if(roomDay.RoomStatusTypeId=='9')
                                {
                                    roomDay.CheckINGuestRoomId = data[1];
                                    roomDay.CheckINId = data[2];
                                }
                                else
                                {
                                    roomDay.Content = '';
                                }

                                if(date +'A' ==col)
                                {
                                    //roomCurrentStatus
                                    if(roomDay.IsBusinessDate)
                                    {   
                                        if(r.CurrentRoomStatusId=='0' || r.CurrentRoomStatusId=='1')
                                        {
                                            r.CurrentRoomStatus='Ready'; 
                                        }
                                        else if(r.CurrentRoomStatusId=='2')
                                        {
                                            r.CurrentRoomStatus='Dirty';
                                        }
                                        else if(r.CurrentRoomStatusId=='3')
                                        {
                                            r.CurrentRoomStatus='Clean';
                                        }
                                    }
                                    r.Days.push(roomDay);
                                    id++;
                                }
                                else if(date +'P' ==col)
                                {
                                    //roomCurrentStatus
                                    if(roomDay.IsBusinessDate)
                                    {   
                                        if(r.CurrentRoomStatusId=='0' || r.CurrentRoomStatusId=='1')
                                        {
                                            r.CurrentRoomStatus='Ready'; 
                                        }
                                        else if(r.CurrentRoomStatusId=='2')
                                        {
                                            r.CurrentRoomStatus='Dirty';
                                        }
                                        else if(r.CurrentRoomStatusId=='3')
                                        {
                                            r.CurrentRoomStatus='Clean';
                                        }
                                    }
                                    r.Days.push(roomDay);
                                    id++;
                                }
                            }
                        });
                    }
                    r.Days = $filter('orderBy')(r.Days, 'FutureDate');
                    roomType.Rooms.push(r);
                });
                    
                roomType.Rooms = $filter('orderBy')(roomType.Rooms, 'RoomOrder');
                roomType.Name = rooms[0].RoomTypeName;
                roomType.IsRoomType = true;
                scope.RoomChart.RoomTypes.push(roomType);
            });
            scope.GetRoomChartCheckINGuestRoom();
        },
        function (error, status) {
            msg(error.Message);
            scope.IsLoading = false;
            scope.ProgressEnd();
        });
        scrollPageOnTop();

    };

    return {
        GetRoomChart: GetRoomChart,
    };
}
]);