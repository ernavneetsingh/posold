﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        
        $scope.LoginId = $cookies.get('LoginId');
        $scope.keys = localStorageService.get('ActionKeys');
        
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            Code: '',
            FirstName: '',
            LastName: '',
            Address1: '',
            Address2: '',
            City: '',
            StateId: '',
            StateName: '',
            CountryId: '',
            CountryName: '',
            PIN: '',
            Mobile1: '',
            Mobile2: '',
            Email: '',
            PhoneNo: '',
            FaxNo: '',
            IsActive: true,
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: []

        };

        $scope.IsReadonly = false;
        //------------------------------------------------
        ////page configuration parameter
        //------------------------------------------------
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "FirstName" || attr == "Code" || attr == "Mobile1") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };

        // show items per page
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {
            $scope.ActionMode = "";
            var promiseGet = service.getData($scope.PropertyID, 2);
            promiseGet.then(function (data) {

                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   
                   parent.failureMessage(data.message);
               });

        };

        $scope.Countries = [];
        GetAllCountry();
        function GetAllCountry() {
            var promiseGet = service.getAllCountry();
            promiseGet.then(function (data) {
                $scope.Countries = data;
            },
            function (data) {
                parent.failureMessage(data.Message);
            });
        }

        $scope.States = [];
        $scope.CountryChange = function (id) {
            
            var promiseGet = service.getAllState(id);
            promiseGet.then(function (data) {
                
                $scope.States = data.Collection;
                $scope.Model.StateId = $scope.Model.ItemCategoryIdStore;
                $scope.Model.ItemCategoryIdStore = "";
            },
            function (data) {
                
                parent.failureMessage(data.Message);
            });

        };

        $scope.Save = function (model, form) {
            
            if ($scope[form].$valid) {

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;

                var status = service.save(model);

                status.then(function (result) {
                    
                    if (result.Status == true) {
                        var msg = model.FirstName + result.Message;
                        parent.successMessage(msg);
                        getData();
                    }

                    $scope.Reset();

                },
                function (error) {
                    
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }

            $scope.model.ApplicableFromDate = '';
        }
        $scope.Remove = function (model) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            

                            parent.successMessage("Record Successfully deleted.");

                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };

        $scope.SelectedUnitTypeId = "";
        $scope.ActionMode = "";
        $scope.Edit = function (model) {
            $scope.ActionMode = "Edit";
            $scope.Model = model;
            $scope.Model.Id = model.Id;
            $scope.Model.FirstName = model.FirstName;
            $scope.Model.Code = model.Code;
            $scope.Model.Address1 = model.Address1;
            $scope.Model.City = model.City;
            $scope.Model.PIN = model.PIN;
            $scope.Model.CountryId = model.CountryId.toString();
            $scope.Model.Email = model.Email;
            $scope.Model.Mobile1 = model.Mobile1;
            $scope.Model.FaxNo = model.FaxNo;
            $scope.Model.ItemCategoryIdStore = model.StateId.toString();
            $scope.CountryChange(model.CountryId);
            $scope.Model.ContractPerson = model.ContractPerson;
            $scope.Model.Mobile2 = model.Mobile2;
            $scope.Model.PhoneNo = model.PhoneNo;
            $scope.Model.Description = model.Description;
            $scope.IsReadonly = true;
            $scope.Model.ApplicableFrom = $filter('date')(model.ApplicableFrom, $scope.DateFormat);
            $scope.Model.IsActive = model.IsActive;
            scrollPageOnTop();
        }
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.Model = {};
            $scope.Model.Email = "";
            $scope.query = "";
            $scope.SalesOfficeContactPersonEmailId = "";
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            getData();
            scrollPageOnTop();
        }

        $scope.IsCodeExist = function (code) {
            var promiseGet = service.isCodeExist($scope.PropertyID, code);
            promiseGet.then(function (data) {
            },
                function (error) {

                    $scope.Model.Code = "";
                    parent.failureMessage(error.Message);
                    scrollPageOnTop();
                });
        };
        $scope.IsEmailExist = function (email) {
            
            var promise = service.isEmailExist($scope.PropertyID, email, $scope.Model.Id);
            promise.then(function (data) {
                
            },
                function (error) {
                    
                    $scope.Model.Email = "";
                    msg(error.Message);
                });
        };
        $scope.IsMobile1Exist = function (mobile1) {
            
            var promise = service.isMobile1Exist($scope.PropertyID, mobile1, $scope.Model.Id);
            promise.then(function (data) {
                
            },
                function (error) {
                    
                    $scope.Model.Mobile1 = "";
                    msg(error.Message);
                });
        };


    }
]);
