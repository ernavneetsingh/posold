﻿app.service('LPService', ['$http', '$q', '$filter', LPService]);

app.controller("CashieringController", ["$scope", "CashieringService", "localStorageService", "$cookies", "$filter", "$timeout", "$window", "GuestMessageService", "manuService", 'ImageService', 'CreditCardService', 'DocumentViewerService', "$rootScope",'LPService',function (
    $scope, service, localStorageService, $cookies, $filter, $timeout, $window, guestMessageService, manuService, imageService, creditCardService, documentViewerService,$rootScope,lpService) {
    
    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.FOShiftId = localStorageService.get('FOShiftId'); 
    $scope.ModifiedBy = $cookies.get('UserName');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    $scope.guestMessageService = guestMessageService.init($scope);
    
    $scope.APIPath = apiPath;
    $scope.apiPath = apiPath;

    $scope.imageService = imageService;
    creditCardService.init($scope);
    $scope.lpService = lpService.init($scope);
    $scope.documentViewerService = documentViewerService.init($scope);

    var businessDate = $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' + $scope.BusinessDate.Day;
    
    $scope.BusinessDateFormatted = $filter('date')(new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month -1, $scope.BusinessDate.Day),  $scope.DateFormat );

    $scope.MaxDate = $filter('date')(new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day), 'yyyy-MM-dd');
    $scope.MinDOB = dateAdd($scope.ModifiedDate, 'year', -120, $filter);
    $scope.MaxDOB = $scope.ModifiedDate;

    $scope.timeFormat = "HH:mm";

    $scope.Clock = $filter("date")(new Date, $scope.timeFormat);
    $scope.tickInterval = 1000 //ms
    var tick = function () {
        $scope.Clock = $filter("date")(new Date, $scope.timeFormat);
        $timeout(tick, $scope.tickInterval); // reset the timer
    }
    // Start the timer
    $timeout(tick, $scope.tickInterval);

    $scope.IsGroupSelected=false;
    $scope.IsGuestSelected=true;

    $scope.PaymentModeRevenueHeads=[];
    $scope.PaymentModeRevenueHeads.push({Code:'CSH',Name:'CASH'});
    $scope.PaymentModeRevenueHeads.push({Code:'CRD',Name:'CREDIT CARD'});
    $scope.PaymentModeRevenueHeads.push({Code:'CHQ',Name:'CHEQUE'});
    $scope.PaymentModeRevenueHeads.push({Code:'ECP',Name:'ELECTRONIC PAYMENT'});
    	
    //-----------------------------------------------
    //Progress Bar
    //-----------------------------------------------
    $scope.ManuService = manuService;
    $scope.IsProgress = true;
    $scope.ProgressStart = function () {
        $scope.IsProgress = true;
        $('#body').addClass("disablewholepage");
        $scope.ManuService.setProgress(true);
    }
    $scope.ProgressEnd = function () {
        $scope.IsProgress = false;
        $('#body').removeClass("disablewholepage");
        $scope.ManuService.setProgress(false);
    }
    //-----------------------------------------------

    $scope.postingnew = true;
    $scope.splitguestfolio = false;
    $scope.paxcheckout = false
    $scope.transferrevenue = false;
    $scope.ModuleId = 1;
    $scope.postingnewtab = function () {
        $scope.postingnew = true;
        $scope.transferrevenue = false;
        $scope.paxcheckout = false;
        $scope.splitguestfolio = false;

    }
    $scope.sgf = function () {
        $scope.postingnew = false;
        $scope.transferrevenue = false;
        $scope.paxcheckout = false;
        $scope.splitguestfolio = true;

    }
    $scope.pco = function () {
        $scope.postingnew = false;
        $scope.splitguestfolio = false;
        $scope.transferrevenue = false;
        $scope.paxcheckout = true;

    }
    $scope.transrev = function () {
        $scope.transferrevenue = true;

        $scope.postingnew = false;
        $scope.splitguestfolio = false;
        $scope.paxcheckout = false;

    }

    $scope.IsGuestLoading = false;

    $scope.FOTaxStructures = [];
    function  getFOTaxStructures() {
        service.getFOTaxStructures($scope.PropertyID)
            .then(function (result) {
                $scope.FOTaxStructures = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    getFOTaxStructures();

    $scope.OccupiedRooms = [];
    $scope.CheckINGuests = [];
   
    $scope.GetOccupiedRooms = function () {
        $scope.OccupiedRooms=[];
        $scope.IsGuestLoading = true;
        var promiseGet = service.getOccupiedRoomsNew($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.OccupiedRooms = data.Collection;
            $scope.IsGuestLoading = false;
        },
            function (error) {
                $scope.IsGuestLoading = false;
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.GetAllCheckINGuest = function (roomMasterId) {
        if(roomMasterId)
        {
            $scope.GetAllCheckINGuestLoading =true;
            var promiseGet = service.GetAllCheckINGuest(roomMasterId);
            promiseGet.then(function (data) {
                $scope.SelectedRoom.CheckINGuests = data.Collection;
                angular.forEach($scope.SelectedRoom.CheckINGuests,function(item){
                    item.FolioNo = item.FolioNo.toString();
                });
                $scope.GetAllCheckINGuestLoading =false;
            },
                function (error) {
                    $scope.GetAllCheckINGuestLoading =false;
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        }
    };
    $scope.SelectedRoom={};
    $scope.GetAllCheckINGuestByRoomId = function(room){
        
        $scope.CheckINGuest ={}
        $scope.CheckINGuestRevenuePosts=[];
        $scope.Model.CheckINGuestId = '';
        $scope.ImageUrl = '';

        $scope.SelectedRoom = room;
        angular.forEach($scope.OccupiedRooms,function(item){
            item.IsSelected=false;
            if(item.RoomMasterId == room.RoomMasterId)
            {
                item.IsSelected=true;
            }
        });

        $scope.GetAllCheckINGuest($scope.SelectedRoom.RoomMasterId);
        $('#checkINGuestBox').modal('show');
    }

    $scope.getMessageList =function(checkINGuest)
    {
        if(checkINGuest.TotalMessages==0)
        {
            return;
        }
        guestMessageService.getMessageList(3, checkINGuest, 1);
        guestMessageService.getMessageList(3, checkINGuest, 2);
        guestMessageService.getMessageList(3, checkINGuest, 3);
        guestMessageService.getMessageList(3, checkINGuest, 4);
    }


    $scope.GroupCheckINGuest={};
    $scope.GetOccupiedGroupLeaderRooms = function (checkINGuest) {
        
        $scope.IsGuestLoading=true;
        $scope.IsGroupSelected=true;
        $scope.IsGuestSelected=false;
        
        $scope.CheckINGuestRevenuePosts=[];
        $scope.SelectedTransactions=[];

        $scope.GroupCheckINGuest = checkINGuest;
        $scope.CheckINGuest = checkINGuest;
        //$scope.CheckINGuest = {};
        
        $scope.OccupiedRooms = [];
        service.getOccupiedGroupLeaderRooms($scope.PropertyID, $scope.ModifiedDate,checkINGuest.Id)
            .then(function (result) {

                angular.forEach(result.Collection, function (room) {
                    angular.forEach(room.CheckINGuests, function (checkINGuest) {
                        checkINGuest.PaxCount = room.CheckINGuests.filter(x => x.FolioNo == checkINGuest.FolioNo).length;
                        guestMessageService.getMessageList(3, checkINGuest, 1);
                        guestMessageService.getMessageList(3, checkINGuest, 2);
                        guestMessageService.getMessageList(3, checkINGuest, 3);
                        guestMessageService.getMessageList(3, checkINGuest, 4);

                    });
                });

                $scope.OccupiedRooms = result.Collection;
                $scope.GroupCheckINGuest.GroupTolalRoom = $scope.OccupiedRooms.length;
                var totallpax=0;
                angular.forEach($scope.OccupiedRooms,function(room){
                    totallpax= totallpax+ room.CheckINGuests.length;
                });
                $scope.GroupCheckINGuest.GroupTolalPAX = totallpax;
                $scope.GetDistinctCheckINGuest();//All & Distinct CheckINGuest
                $scope.SetCheckINGuest(checkINGuest.Id);
                $scope.IsGuestLoading=false;
                $scope.IsGroupSelected=true;
                $scope.IsGuestSelected=false;

            }, function (err) {
                $scope.IsGuestLoading=false;
                msg(err.Message);
            });
    };

    $scope.FPs = [];
    $scope.IsFPLoading = false;
    $scope.GetFPCashiering = function () {
        $scope.FPs = [];
        $scope.IsFPLoading = true;
        var promiseGet = service.GetFPCashiering($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.FPs = data.Data[0];
            $scope.IsFPLoading = false;
        },
            function (error) {
                $scope.IsFPLoading = false;
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });
    };


    $scope.SelectedFP = {};
    $scope.GetFPById = function (id) {
        
        $scope.reset();
        $scope.SelectedFP = {};
        var promiseGet = service.GetFPById(id);
        promiseGet.then(function (data) {
            $scope.SelectedFP = data.Data;
debugger;
            $scope.CheckINGuest = {
                Id: $scope.SelectedFP.BanquetBookingEventId,
                CheckINNo: $scope.SelectedFP.FPNo,
                GuestName: $scope.SelectedFP.GuestName,
                CheckINDate: $scope.SelectedFP.FPDate,
                CheckOUTDate: "",
                //PaxCount: paxCount,
                PaxCount: 'Adult :' + $scope.SelectedFP.BanquetBookingEventGuaranteedAdult + ' Child :' + $scope.SelectedFP.BanquetBookingEventGuaranteedChild,
                DayRateAmount: $scope.SelectedFP.BanquetBookingEventHallAmount,
                MealPlanName: $scope.SelectedFP.BanquetBookingEventBanquetMenuCardName + ' (FPP : ' + $scope.SelectedFP.BanquetBookingEventFoodPerPlateAdultAmount +')',
                
                //DayRateAmount: 
                CorporateName: $scope.SelectedFP.CorporateName,
                Nationality: '',
                GuestClassDescription: '',
                BillingInstructionName: $scope.SelectedFP.BillingInstructionName,
                //TotalRevenueDr: $scope.SelectedFP.TotalNetAmount,
                //TotalRevenueCr: $scope.SelectedFP.TotalAdvance,
                TotalRevenueDr: $scope.SelectedFP.TotalRevenueDr,
                TotalRevenueCr: $scope.SelectedFP.TotalRevenueCr,
                RoomTypeName: $scope.SelectedFP.BanquetBookingEventHallName,
                IsRoomOwner: true,
                IsFOBilled: $scope.SelectedFP.IsFOBilled,
            };

            $scope.Model.CheckINGuestId = $scope.CheckINGuest.Id;
            $scope.GetRevenuePost($scope.CheckINGuest.Id);

        },
            function (error) {
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });
    }

    $scope.GetBillByFunctionProspectusId= function () {
        
        
        if (!$scope.SelectedFP.Id) {
            msg('Please Select Function Prospectus.');
            return;
        }

        $scope.BanquetBill = {};
        var promiseGet = service.GetBillByFunctionProspectusId($scope.SelectedFP.Id,businessDate);
        promiseGet.then(function (data) {
            $scope.BanquetBill = data.Data;
            var totalAmount = 0.0;

            var menuGroupTypeName = '';
            var menuGroupTypeNameTXT = '';
            var menuCategoryName = '';
            var menuCategoryNameTXT = '';

            angular.forEach($scope.BanquetBill.BanquetBillBookingEventItems, function (item) {
                totalAmount += item.Amount;
                
                if (menuGroupTypeName != item.MenuGroupTypeName) {
                    menuGroupTypeName = item.MenuGroupTypeName;
                    menuGroupTypeNameTXT = menuGroupTypeName 
                }
                else if (menuGroupTypeName == item.MenuGroupTypeName) {
                    menuGroupTypeNameTXT = '';
                }
                else {
                    menuGroupTypeName = '';
                }
                item.MenuGroupTypeName = menuGroupTypeNameTXT;

                if (menuCategoryName != item.MenuCategoryName) {
                    menuCategoryName = item.MenuCategoryName;
                    menuCategoryNameTXT = menuCategoryName 
                }
                else if (menuCategoryName == item.MenuCategoryName) {
                    menuCategoryNameTXT = '';
                }
                else {
                    menuCategoryName = '';
                }
                item.MenuCategoryName = menuCategoryNameTXT;

            });
            $scope.BanquetBill.TotalAmount = totalAmount;

            $('#banquetBillBox').modal('show');
        },
            function (error) {
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });
    }




    $scope.fillReservation = function (record) {
        $scope.reset();
        $scope.SelectedReservation = record;
        $scope.CheckINGuest = {
            Id: record.Id,
            CheckINId: record.Id,
            CheckINNo: record.ReservationNo,
            Name: record.GuestName,
            CheckINDate: record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].ArrivalDate : "",
            CheckOUTDate: record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].DepartureDate : "",
            //PaxCount: paxCount,
            PaxCount: record.TotalPax,
            Tariff: record.ReservationRoomTypes[0].Tariff,
            //RoomTypeName = record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].RoomTypeName : ""            
            DayRateAmount: record.ReservationAmount,
            CorporateName: record.CorporateName,
            Nationality: !record.ReservationRoomTypes || record.ReservationRoomTypes.length < 1 ? "" : !record.ReservationRoomTypes[0].ReservationRoomTypeGuests || record.ReservationRoomTypes[0].ReservationRoomTypeGuests.length < 1 ? "" : record.ReservationRoomTypes[0].ReservationRoomTypeGuests[0].Nationality,
            GuestClassDescription: !record.ReservationRoomTypes || record.ReservationRoomTypes.length < 1 ? "" : !record.ReservationRoomTypes[0].ReservationRoomTypeGuests || record.ReservationRoomTypes[0].ReservationRoomTypeGuests.length < 1 ? "" : record.ReservationRoomTypes[0].ReservationRoomTypeGuests[0].GuestClassName,
            BillingInstructionName: record.BillingInstructionName,
            TotalRevenueDr: record.TotalNetAmount,
            TotalRevenueCr: record.TotalAdvance,
            CheckINGuestRoom: {
                RoomTypeName: record.RoomTypeNamesForDisplay,
                MealPlanName: record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].MealPlanName : "",
            },
        };

        $scope.GetRevenuePost($scope.CheckINGuest.Id);
    };



    $scope.TotalFolioInRoom = 0;
    $scope.SelectedRoom = { IsLinkedTo: true };

    //TODO: Navneet2.0
    $scope.SetCheckINGuest = function (checkINGuestId) {
        if (!checkINGuestId) {
            return;
        }
        $scope.IsSeeMessage=false;
        $scope.IsGroupSelected=false;
        $scope.IsGuestSelected=true;
        $scope.SplitRevenuePosts = [];
        $scope.OriginalSplitRevenuePosts = [];
        $scope.CheckINGuestRevenuePosts = [];
        $scope.SelectedTransactions=[];
        //$scope.SelectedRoom = {};
        $scope.model.LinkTaxStructures = [];
        
        $scope.CheckINGuest ={}
        $scope.CheckINGuest.TotalRevenueDr=0;
        $scope.CheckINGuest.TotalRevenueCr=0;
        
        $scope.Model.CheckINGuestId = '';
        $scope.ImageUrl = '';
        $scope.CheckINGuests = angular.copy($scope.SelectedRoom.CheckINGuests);
        $scope.CheckINGuest.Id = checkINGuestId;
        var promiseGet = service.GetCheckINGuestCashiering(checkINGuestId);
        promiseGet.then(function (data) {
            $scope.CheckINGuest = data.Collection[0];
            $scope.GetRevenuePost($scope.CheckINGuest.Id);
            $scope.Model.CheckINGuestId = $scope.CheckINGuest.Id;
            $scope.ImageUrl = $scope.CheckINGuest.ImageUrl;
            $scope.guestEdit($scope.CheckINGuest, true);  
            $('#checkINGuestBox').modal('hide');
        },
        function (data) {
            parent.failureMessage(data.Message);
            scrollPageOnTop();
        });


    };
    
    $scope.SetCheckINGuest2 = function(checkINGuest){
        

        var selectedCheckINGuest = angular.copy( checkINGuest);

        angular.forEach($scope.CheckINGuests,function(item){
            item.IsSelected = false;
        });
        angular.forEach($scope.CheckINGuests,function(item){
            if(item.Id == selectedCheckINGuest.Id)
            {
                item.IsSelected = selectedCheckINGuest.IsSelected;
                $scope.CheckINGuest = item;
            }
        });


        if($scope.CheckINGuest.IsSelected)
        {
            $scope.ImageUrl = checkINGuest.GuestImageUrl;
            $scope.GetRevenuePost($scope.CheckINGuest.Id);
            $scope.Model.CheckINGuestId = $scope.CheckINGuest.Id;
            $scope.guestEdit($scope.CheckINGuest, true);        //service.getCheckInGuestById(checkINGuestId).then(function (s) { $scope.CheckINGuestEdit = s.Data; });
        }
        else
        {
            $scope.CheckINGuest = {};
            $scope.ImageUrl = '';
            $scope.Model.CheckINGuestId = '';
            $scope.SplitRevenuePosts = [];
            $scope.OriginalSplitRevenuePosts = [];
            $scope.CheckINGuestRevenuePosts = [];
            $scope.SelectedTransactions=[];
            $scope.CheckINGuestEdit={};
        }
       
    }
    
    $scope.AdvRevenueHeadList = [];
    $scope.CancelRevenueHeadList = [];

    $scope.RevenueHeadListForAllowance = [];
    $scope.getRevenueHeadList = function () {
        $scope.RevenueHeadListForAllowance = [];
        //$scope.RevenueHeadList = result.Collection;
        angular.forEach($scope.RevenueHeads, function (item) {
            item.RevenueForId = item.RevenueForId.toString();
            item.RevenueTypeId = item.RevenueTypeId.toString();
            item.RevenueClassificationTypeId = item.RevenueClassificationTypeId.toString();
            if (item.RevenueTypeId != '0' && item.RevenueClassificationTypeId == '3') {
                if (item.RevenueForId == '1' || item.RevenueForId == '2' || item.RevenueForId == '3' || item.RevenueForId == '4') {
                    $scope.RevenueHeadListForAllowance.push(item);
                }
            }
            if(item.Code=='ARCS' || item.Code=='ARCH' || item.Code=='ARCC' || item.Code=='AREP')
            {
                $scope.AdvRevenueHeadList.push(item);
            }
                    
            if(item.Code=='RTN' || item.Code=='CCRG' || item.Code=='NSCG' )
            {
                $scope.CancelRevenueHeadList.push(item);
            }

        })


        //service.getRevenueHeadList($scope.PropertyID)
        //    .then(function (result) {
                
        //        $scope.RevenueHeadList = result.Collection;
        //        angular.forEach($scope.RevenueHeadList, function (item) {
        //            item.RevenueForId = item.RevenueForId.toString();
        //            item.RevenueTypeId = item.RevenueTypeId.toString();
        //            item.RevenueClassificationTypeId = item.RevenueClassificationTypeId.toString();
        //            if (item.RevenueTypeId != '0' && item.RevenueClassificationTypeId == '3') {
        //                if (item.RevenueForId == '1' || item.RevenueForId == '2' || item.RevenueForId == '3' || item.RevenueForId == '4') {
        //                    $scope.RevenueHeadListForAllowance.push(item);
        //                }
        //            }
        //            if(item.Code=='ARCS' || item.Code=='ARCH' || item.Code=='ARCC' || item.Code=='AREP')
        //            {
        //                $scope.AdvRevenueHeadList.push(item);
        //            }
                    
        //            if(item.Code=='RTN' || item.Code=='CCRG' || item.Code=='NSCG' )
        //            {
        //                $scope.CancelRevenueHeadList.push(item);
        //            }

        //        })

        //    }, function (err) {
        //        msg(err.Message);
        //    });

    };
    

    //$scope.getCurrencyList = function () {
    //    service.getCurrencyList($scope.PropertyID)
    //        .then(function (result) {

    //            $scope.CurrencyList = result.Collection;
    //        }, function (err) {
    //            msg(err.Message);
    //        });

    //};
    //$scope.getCurrencyList();
    //$scope.getDefaultSettings = function () {
    //    service.getDefaultSettings($scope.PropertyID)
    //        .then(function (data) {
    //            $scope.DefaultSettings = data.Data;
    //            $scope.reset();
    //        });
    //};
    //$scope.getDefaultSettings();
    $scope.selectRevenueHead = function (model) {
        if (!model || !model.RevenueHeadId) return;
        var rh = $scope.RevenueHeads.find(x => x.Id == model.RevenueHeadId);
        if (!rh) return;
        model.RevenueHeadCode = rh.Code;
    };

    $scope.calculateTax = function () {
        
        if(!$scope.RevenueHeads)
        {
            return;
        }
        if($scope.CheckINGuest && $scope.CheckINGuest.Id)
            service.getCheckInDiscount($scope.PropertyID,$scope.CheckINGuest.Id,$scope.model.RevenueHeadId)
                .then(function (s) {
                    if(s.Data)
                    {
                        parent.posFailureMessage('Please apply discount: '+s.Data.DiscountValue+(s.Data.DiscountTypeId==2?'%':''));             
                    }
                });
 
        var revenueHead = $scope.RevenueHeads.find(x => x.Id == $scope.model.RevenueHeadId);
        $scope.model.RevenueHeadCode = revenueHead.Code;
        if(revenueHead)
        {
            if(revenueHead.IsMiscellaneous && $scope.ChargePostToId==7) //(!revenueHead.IsMiscellaneous)
            {
                $scope.model.TaxStructureId = revenueHead.MiscTaxStructureId;
            }
            else
            {
                $scope.model.TaxStructureId = revenueHead.TaxStructureId;
            }
        }
       

        if (!revenueHead || !$scope.model.TaxStructureId) {
            if ($scope.model.Amount) $scope.model.TotalAmount = $scope.model.Amount.toFixed(2);
            $scope.model.TaxAmount = 0;
            return;
        }

        $scope.model.LinkTaxStructures=[];
        if($scope.model.TaxStructureId)
        {
            //service.getTaxStructure($scope.model.TaxStructureId)
            //    .then(function (data) {
            //        $scope.LinkTaxStructures = data.Data.LinkTaxStructures;
            //        $scope.calculateRoomRateTax();
            //    });

            $scope.model.LinkTaxStructures = $scope.LinkTaxStructures.filter(x=>x.TaxStructureId == $scope.model.TaxStructureId);
            $scope.calculateRoomRateTax();
        }

    };
    $scope.formatAmount = function () {
        $scope.model.Amount = parseFloat($scope.model.Amount).toFixed(2);
    };

    $scope.reset = function () {
        
        if($scope.DefaultSetting)
        {
            //$scope.SelectedReservation={};
            $scope.Settlement={};
            $scope.GroupCheckINGuest={};
            $scope.RoomOwners = [];
            $scope.IsEdit = false;
            var cpt = $scope.model.ChargePostToId;
            $scope.CheckINGuest = {
                IsFOBilled: false,
            }
            $scope.model = {};
            $scope.ImageUrl = '';
            $scope.model.ChargePostToId = cpt ? cpt : "1";
            $scope.LinkRevenues = [];
            if (!cpt) $scope.changeChargePostToId();
            $scope.model.PostDate = $scope.ModifiedDate;
            $scope.model.CurrencyId = !$scope.DefaultSetting.CurrencyMasterId ? "0" : $scope.DefaultSetting.CurrencyMasterId.toString();
            $scope.model.ChargePostDetails = [];
            $scope.model.Amount = 0;

            $scope.BillList = [];
            $scope.TaxStructure = {};

            angular.forEach($scope.RoomRateRevenueHeads, function (item) {
                item.IsSelected = false;
            });
        }
    };

    $scope.resetTab = function () {

        $scope.model.PostDate = $scope.ModifiedDate;
        $scope.model.ReferenceNo = '';
        $scope.RevenueHead = {};
        $scope.model.RevenueHeadId = '';
        $scope.model.RevenueHeadCode = '';
        $scope.model.CurrencyId = !$scope.DefaultSetting.CurrencyMasterId ? "0" : $scope.DefaultSetting.CurrencyMasterId.toString();
        $scope.model.Amount = 0;
        $scope.model.TaxAmount = 0;
        $scope.model.TotalAmount = 0;
        $scope.model.Particular = '';
        $scope.model.ReasonId = '';
        $scope.model.Remark = '';

        $scope.model.ChargePostDetails = [];
        $scope.ChargePostDetails = [];
        $scope.BillList = [];
        $scope.TaxStructure = {};

        $scope.IsEdit = false;
        //angular.forEach($scope.RoomRateRevenueHeads, function (item) {
        //    item.IsSelected = false;
        //});

    };
    $scope.SetTab = function (tab) {
        
        $scope.resetTab();
        if (!tab) {

            //$scope.CurrentTab = $scope.model.ChargePostToId == 7 ? 4 : $scope.model.ChargePostToId == 5 ? 2 : 1;

            if($scope.model.ChargePostToId == 7)
            {
                $scope.CurrentTab = 4;
            }
            else if($scope.model.ChargePostToId == 8)
            {
                $scope.CurrentTab = 11;
            }
            else if($scope.model.ChargePostToId == 5)
            {
                $scope.CurrentTab = 2;
            }
            else
            {
                $scope.CurrentTab = 1;
            }

            return;
        }

        $scope.CurrentTab = tab;

        switch (tab) {
            case 5: $scope.getReceiptList(); break;
            case 3: $scope.model.RevenueHeadCode ='PAO'; break;
            case 10: $scope.model.RevenueHeadCode ='ARCS'; break;
        }
        $scope.BillAllowanceList = [];
    }
    $scope.ResetModel = function () {
        $scope.model = {

            ChargePostToId: $scope.ChargePostToId,

            PostDate: $scope.ModifiedDate,
            ReferenceNo: '',
            RevenueHeadId: '',
            CurrencyId: !$scope.DefaultSetting.CurrencyMasterId ? "0" : $scope.DefaultSetting.CurrencyMasterId.toString(),
            Amount: 0,
            TaxAmount: 0,
            TotalAmount: 0,
            IsTaxInclusive: false,
            Particular: '',
            TaxRateIn: '',
            ReasonId: '',
            Remark: '',
            ChargePostDetails: [],
        };
        $scope.ChargePostDetails = [];
        $scope.BillList = [];
        $scope.BillAllowanceList = [];
    }

    $scope.save = function (form, chargePostTypeId, postingTypeId) {
        
        if($scope.model.ChargePostToId!=8) //Skip for Hotel Paid OUT
        {
            if(!$scope.model.RevenueHeadId && chargePostTypeId !=3)
            {
                $scope.ShowErrorMessage = true;
                parent.posFailureMessage('Please Select Revenue.');
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please Select Revenue.', Status:false});
                return;
            }
        }

        var checkINGuestId='';
        var guestName='';

        if (!$scope.CheckINGuest) {
            parent.posFailureMessage('Please select a guest.');
            $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please select a guest.', Status:false});
            return;
        }
        else
        { 
            if (chargePostTypeId != 4 && chargePostTypeId !=11)  // Anush skip for misc and hotel paid out
            {
                    checkINGuestId = $scope.CheckINGuest.Id;
                    guestName = $scope.CheckINGuest.Name ;

                    if (!checkINGuestId) {
                        parent.posFailureMessage('Please select a guest.');
                        $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please select a guest.', Status:false});
                        return;
                }
            }           
        }
        if (!$scope[form].$valid) {
            var count = 0;
            if ($scope[form].$error.required)
                $scope[form].$error.required.forEach(function (e) {
                    if (e.$name !== 'docForm' && e.$name !== 'ccNumber') count++;
                });
            else
                Object.keys($scope[form].$error).forEach(function (e) {
                    if (e !== 'docForm' && e !== 'ccNumber' && e !== 'ccNumberType' && e !== 'maxlength') count++;
                });
            if (count > 0) {
                $scope.ShowErrorMessage = true;
                msg('');
                return;
            }
            if ($scope.model.RevenueHeadCode == 'ACC' && !$scope.model.CreditCardNumber) {
                parent.posFailureMessage('Please enter credit card number.');
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please enter credit card number.', Status:false});
                return;
            }
        }
        // var revenueHead={};
        var revenueHead = $scope.RevenueHeads.find(x => x.Id == $scope.model.RevenueHeadId);
        if (chargePostTypeId == 6) {
            var modelMulti = {};
            modelMulti.ChargePosts = [];
            angular.forEach($scope.BillList, function (bill) {
                var sno = 1;

                if (bill.DiscountAmount > 0) {
                    var multi = {
                        ChargePostTypeId: chargePostTypeId,
                        ChargePostToId: $scope.model.ChargePostToId,// 1,
                        ChargePostId: checkINGuestId,
                        TaxStructureId: revenueHead.TaxStructureId,
                        Particular: $scope.model.Particular,
                        //TaxRateIn : splitRevenuePost.TaxRateIn,
                        CurrencyId: bill.CurrencyId,
                        ReferenceNo: $scope.model.ReferenceNo,
                        Amount: bill.DiscountAmount,
                        TaxAmount: bill.DiscountTaxAmount,
                        TotalAmount: bill.DiscountTotalAmount,
                        Remark: 'against charge post id ' + bill.Id + ', Allowance in ' + (bill.DiscountTypeId == "1" ? 'Amount' : 'Percentage') + ', Value ' + bill.DiscountValue,
                        IsTaxInclusive: bill.IsTaxInclusive,
                        PostDate: $scope.ModifiedDate,

                        Id: $scope.model.Id,
                        RevenuePostId: bill.ParentId,
                        ParentId: bill.ParentId,

                    };
                    
                    multi.ChargePostDetails = [];
                    multi.ChargePostDetails.push({ SNo: sno++, RevenueHeadCode: revenueHead.Code, Amount: bill.IsTaxInclusive ? bill.DiscountTotalAmount - bill.DiscountTaxAmount : bill.DiscountAmount, PostingTypeId: postingTypeId });
                    
                    //TODO: Navneet 11-01-2019
                    angular.forEach($scope.ChargePostDetails, function (linkRevenue) {
                        multi.ChargePostDetails.push({ SNo: sno++, RevenueHeadCode: linkRevenue.RevenueHeadCode, Amount: linkRevenue.Amount, PostingTypeId: postingTypeId });
                    });


                    modelMulti.ChargePosts.push(multi);
                }
            });
            if (modelMulti.ChargePosts.length < 1) {
                parent.posFailureMessage('Please enter at least one allowance amount.');
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please enter at least one allowance amount.', Status:false});

                return;
            }

            modelMulti.IsGroupSelected = $scope.IsGroupSelected;
            modelMulti.PropertyID = $scope.PropertyID;
            modelMulti.ModifiedBy = $scope.ModifiedBy;

            $scope.IsProgress = true;
            $scope.ProgressStart();
            service.saveMulti(modelMulti)
                .then(function (d) {

                    $scope.IsProgress = false;
                    $scope.ProgressEnd();
                    
                    parent.popSuccessMessage(d.Message);
                    $scope.GetRevenuePost(checkINGuestId);
                    if(checkINGuestId)
                    {
                        $scope.SetCheckINGuest(checkINGuestId)
                    }

                    $scope.SelectedRoom = {};
                    $scope.ResetModel();

                    $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:d.Message, Status:d.Status});

                        
                }).catch(function (e) {
                    $scope.IsProgress = false;
                    $scope.ProgressEnd();
                    parent.posFailureMessage(e.Message);
                });
        }
        else {
            
            if(chargePostTypeId=='5')
            {
                revenueHead = $scope.AdvRevenueHeadList.find(x => x.Id == $scope.model.RevenueHeadId);
            }
            var amount = chargePostTypeId == 1 ? $scope.model.TotalAmount - $scope.model.TaxAmount : $scope.model.Amount;
            if (chargePostTypeId != 1)
                $scope.model.TotalAmount = parseFloat($scope.model.Amount) + parseFloat($scope.model.TaxAmount);
            if (!$scope.model.Amount || $scope.model.TotalAmount <= 0) {
                //msgInPopup('Please enter amount');
                parent.posFailureMessage('Please enter amount');
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please enter amount.', Status:false});
                return;
            }
            if (amount < 0) {
                parent.posFailureMessage('Amount cannot be negative.');
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Amount cannot be negative.', Status:false});
                return;
            }

            $scope.model.AccountingDate = businessDate;
            $scope.model.ChargePostTypeId = chargePostTypeId;
            //$scope.model.ChargePostToId = 1;
            $scope.model.ChargePostId = checkINGuestId;

            if (chargePostTypeId == 3) {
                var revenueHead ={};
                revenueHead.Code ='PAO'; //PAID OUT 
            }
            if (chargePostTypeId == 4) {
                $scope.model.ChargePostToId = 7;
            }
            else if (chargePostTypeId == 8) {
            }
            else {
                if($scope.model.ChargePostToId != 8)
                {
                    if(revenueHead)
                    {
                        $scope.model.TaxStructureId = revenueHead.TaxStructureId;
                    }
                }
                
            }

            if($scope.model.ChargePostToId == 8)
            {
                if(!revenueHead)
                {
                    var revenueHead={};
                }
                revenueHead.Code ='POH'; //PAID OUT HOTEL
            }
                
            
            if($scope.CurrentTab == 10)
            {
                $scope.model.ChargePostTypeId = 10; //CancellationCharge
            }

            $scope.model.IsGroupSelected = $scope.IsGroupSelected;
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            
            $scope.model.ChargePostDetails = [];

            if(chargePostTypeId=='2')//Receipt
            {
                $scope.ChargePostDetails=[];
            }
            
            $scope.ChargePostDetails.push({
                ChargePostId: '',
                SNo: 1,
                RevenueHeadId: '',
                RevenueHeadCode: revenueHead.Code,
                PostingTypeId: postingTypeId,
                Amount: amount,

            });

            $scope.model.ChargePostDetails = $scope.ChargePostDetails;
            $scope.model.FOShiftId =$scope.FOShiftId;

            $scope.IsProgress = true;
            $scope.ProgressStart();
            service.save($scope.model, true)
                .then(function (d) {

                    $scope.IsProgress = false;
                    $scope.ProgressEnd();

                    parent.popSuccessMessage(d.Message);

                    service.MapReport($scope.PropertyID, 'voucher')
                        .then(function (s) {
                            $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid + '&name=' + guestName, '_blank');
                            //$window.open(origin + '/Reporter/DisplayDesign?id='+s.Data+'&table=FO_ChargePost&pid='+pid+'&name='+$scope.CheckINGuest.Name, '_blank');
                        }, function (e) {
                            parent.posFailureMessage('Error in mapping to print.');
                        });

                    
                    if($scope.model.ChargePostToId==7)
                    {
                        $scope.getMiscellaneous();
                    }
                    else if($scope.model.ChargePostToId==8)
                    {
                        $scope.getHotelPaidOUT();
                    }
                    else if($scope.model.ChargePostToId == '5')
                    {
                        $scope.changeChargePostToId();
                        $scope.fillReservation($scope.SelectedReservation);
                    }
                    else
                    {
                        $scope.GetRevenuePost(checkINGuestId);
                        if(checkINGuestId)
                        {
                            $scope.SetCheckINGuest(checkINGuestId)
                        }
                        $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:d.Message, Status:d.Status});
                    }
                    
                    
                    if($scope.CurrentTab == 10)
                    {
                        $scope.getReservations();
                    }               
                    $scope.ResetModel();
                }).catch(function (e) {
                    $scope.IsProgress = false;
                    $scope.ProgressEnd();
                    parent.posFailureMessage(e.Message);
                    $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:e.Message, Status:false});
                    $scope.ChargePostDetails = [];
                });

        }
    };

    $scope.IsNewReference = function (reference) {

        if (!reference || $scope.IsEdit) return;
        service.IsNewReference($scope.PropertyID, reference)
            .then(function (data) {

                if (!data.Status) {
                    parent.posFailureMessage(data.Message);
                    $scope.model.ReferenceNo = "";
                }
            }, function (error) {
                parent.posFailureMessage(error.Message);
            });
    };
    $scope.getReceiptList = function () {
        
        if($scope.CheckINGuest.Id)
        {
            service.getReceiptList($scope.PropertyID, $scope.model.ChargePostToId, $scope.CheckINGuest.Id)
            .then(function (result) {
                $scope.ReceiptList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
            $scope.model.RevenueHeadId = $scope.RevenueHeads.find(x => x.Code == 'ADF').Id;
        }
    };
    $scope.receiptSelect = function (guestId) {

        $scope.model.Amount = 0;
        angular.forEach($scope.ReceiptList, function (receipt) {

            if (receipt.IsSelected) {
                $scope.model.Amount += receipt.Amount;
            }

        });

    };
    $scope.loadBill = function (b) {
        angular.forEach($scope.BillList,function(bill){
            if(bill.Id!=b.Id)
            {
                bill.IsSelected=false;
            }
            bill.DiscountValue = 0;
            bill.DiscountAmount=0;
            bill.DiscountTaxAmount=0;
            bill.DiscountTotalAmount=0;
            bill.ChargePostDetails=[];
        });
       
        $scope.BillAllowanceList = [];
        service.getByParentId($scope.PropertyID, b.ChargePostToId, b.ChargePostId, b.ParentId)
            .then(function (data) {
                $scope.BillAllowanceList = data.Collection;
            });
    };
    $scope.getBillList = function () {      //Navneet26-02-2019
        
        $scope.BillAllowanceList = [];

        if (!$scope.CheckINGuest) {
            parent.posFailureMessage('Please select a guest');
            return;
        }

        //var revenueHead = JSON.parse($scope.model.RevenueHead);
        
        var revenueHead = $scope.RevenueHeads.find(x => x.Id == $scope.model.RevenueHeadId);
        if (!revenueHead || !revenueHead.Id) return;
        if(revenueHead.TaxStructureId)
        {
            service.getTaxStructure(revenueHead.TaxStructureId)
            .then(function (data) {
                revenueHead.TaxStructure = data.Data;
            });

        }
        
        service.getBillList($scope.PropertyID, $scope.CheckINGuest.Id, revenueHead.Id)
            .then(function (result) {
                
                $scope.BillList = result.Collection;
                $scope.BillList.forEach(function (bill) {
                    bill.TaxStructure =  revenueHead.TaxStructure;
                    bill.TaxStructureId =  revenueHead.TaxStructureId;
                    bill.DiscountTypeId = "1";
                });
            }, function (err) {
                parent.posFailureMessage(err.Message);
            });
    };
    
    $scope.billSelectNew = function (idx) {
        
        var bill = $scope.BillList[idx];

        if (bill.DiscountTypeId == 1)
            bill.DiscountAmount = bill.DiscountValue;
        else if (bill.DiscountTypeId == 2)
            bill.DiscountAmount = bill.Amount * bill.DiscountValue * 0.01;

        //
        //if(bill.IsTaxInclusive)
        //{
        //    if (bill.DiscountAmount > (bill.Amount + bill.TaxAmount)) {
        //        parent.posFailureMessage('Bill allowance cannot be greater than bill amount.', false);
        //        bill.DiscountValue = 0;
        //        bill.DiscountAmount=0;
        //        bill.DiscountTaxAmount=0;
        //        bill.DiscountTotalAmount=0;
        //        return;
        //    }
        //}
        //else
        //{
        if (bill.DiscountAmount > bill.Amount) {
            parent.posFailureMessage('Bill allowance cannot be greater than bill amount.', false);
            bill.DiscountValue = 0;
            bill.DiscountAmount=0;
            bill.DiscountTaxAmount=0;
            bill.DiscountTotalAmount=0;
            return;
        }
        //}
        
        //var revenueHead = JSON.parse($scope.model.RevenueHead);
        var revenueHead = $scope.RevenueHeads.find(x => x.Id == $scope.model.RevenueHeadId);
        if (revenueHead.Code == 'TRF' || revenueHead.Code == 'MP') {//|| revenueHead.Code=='EXB'){
            service.getTaxStructureByRevenue($scope.PropertyID, revenueHead.Code, bill.RevenuePostId, bill.Id)
                .then(function (data) {
                    bill.TaxStructureId = data.Data.Id;
                    bill.TaxStructure = data.Data;
                    $scope.loadBillTaxNew(bill);
                });
        }
        else
        {
            bill.TaxStructureId = revenueHead.TaxStructureId;
            bill.TaxStructure = revenueHead.TaxStructure;
            $scope.loadBillTaxNew(bill);
        }

        

        return;

        //if (revenueHead.Code == 'TRF' || revenueHead.Code == 'MP') {//|| revenueHead.Code=='EXB'){
        //    service.getTaxStructureByRevenue($scope.PropertyID, revenueHead.Code, bill.RevenuePostId, bill.Id)
        //        .then(function (data) {
        //            $scope.loadBillTax(bill, data.Data);
        //        });
        //}
        //    //else if (revenueHead.Code=='MP'){
        //    //    $scope.loadBillTax(bill);
        //    //}
        //else if (bill.TaxStructureId == revenueHead.TaxStructureId)
        //    $scope.loadBillTaxNew(bill);
        //else {
        //    service.getTaxStructure(revenueHead.TaxStructureId)
        //        .then(function (data) {
        //            $scope.loadBillTax(bill, data.Data);
        //        });
        //}
    };

    $scope.loadBillTaxNew = function (bill) {
      
        bill.LinkRevenues = [];
        if (!bill.DiscountAmount) bill.DiscountAmount = 0;


        bill.DiscountAmount = parseFloat(bill.DiscountAmount);
        bill.DiscountTaxAmount = 0;
        bill.DiscountTotalAmount = bill.DiscountAmount;

        bill.LinkTaxStructures =[];
        i=1;
        
        var taxStructure ={};
        
        
        if(bill.IsTaxInclusive)
        {
            //var model= {TaxStructure:{LinkTaxStructures:[]},Amount:0};
            //model.TaxStructure.TaxStructureId = bill.TaxStructureId;
            //model.TaxStructure.LinkTaxStructures = bill.TaxStructure.LinkTaxStructures;
            ////model.Amount =bill.DiscountAmount;
            ////model.Amount =parseFloat( bill.Amount )+ parseFloat(bill.TaxAmount) ;
            //model.Amount =bill.DiscountAmount;
            //model.BillAmt =bill.Amount;
            //model.TotalBillAmt=bill.TotalAmount;
            //model.IsTaxInclusive = true;
            ////taxStructure = IS_TAX_INCLUSIVE_ALLOWANCE(model);
            taxStructure = GET_TAX_STRUCTURE_ALLOWANCE(bill.TaxStructure.LinkTaxStructures, parseFloat(bill.TotalAmount), parseFloat(bill.DiscountAmount));    

        }
        else{
            taxStructure = GET_TAX_STRUCTURE_ALLOWANCE(bill.TaxStructure.LinkTaxStructures, parseFloat(bill.Amount), parseFloat(bill.DiscountAmount));    
        }
        
        angular.forEach(taxStructure.LinkTaxStructures,function(item){
            var t = bill.TaxStructure.LinkTaxStructures.find(x=>x.Id == item.Id);
            if(t)
            {
                item.TaxTypeCode=t.TaxTypeCode;
            }

            item.TaxAmount = $filter("number")(item.TaxAmount  , 2).replace(/,/g, "");
            bill.LinkTaxStructures.push(item);
        });

        
        bill.DiscountTaxAmount = taxStructure.TaxAmount;

        if(bill.IsTaxInclusive)
        {
            bill.DiscountAmount = parseFloat(bill.DiscountAmount);// - parseFloat(bill.DiscountTaxAmount);
        }
        
        bill.DiscountTaxAmount = $filter("number")(bill.DiscountTaxAmount , 2).replace(/,/g, "");
        bill.DiscountAmount = $filter("number")(bill.DiscountAmount , 2).replace(/,/g, "");
        bill.DiscountTotalAmount =  parseFloat(bill.DiscountAmount) + parseFloat(bill.DiscountTaxAmount);


        $scope.model.TaxAmount = 0;
        $scope.model.TotalPer =  0;
        $scope.model.TotalAmt =  0;

        bill.ChargePostDetails=[];
        $scope.ChargePostDetails=[];        
        
        
        angular.forEach(bill.LinkTaxStructures,function(item){
            $scope.ChargePostDetails.push({

                ChargePostId: '',
                SNo: i,
                RevenueHeadId: '',
                RevenueHeadCode: item.TaxTypeCode,
                TaxTypeId:item.TaxTypeId,
                PostingTypeId: 1,
                Amount: item.TaxAmount,
                TaxRateIn: item.TaxRateIn
            });
            i = 1 + i;

            $scope.model.TaxAmount = parseFloat($scope.model.TaxAmount) + parseFloat(item.TaxAmount);
            //$scope.model.TotalPer = parseFloat($scope.model.TotalPer) + parseFloat(totalPer);
            //$scope.model.TotalAmt = parseFloat($scope.model.TotalAmt) + parseFloat(totalAmt);

        });
        
        bill.ChargePostDetails = angular.copy($scope.ChargePostDetails);
        $scope.model.TotalAmt = parseFloat(bill.DiscountTaxAmount) + parseFloat($scope.model.TaxAmount);
        


        
        //TODO: Navneet 11-01-2019
        
        //---------------------
        //if(bill.DiscountTypeId=='1')
        //{
        //    $scope.model.Amount = bill.DiscountValue;
        //}
        //else
        //{
        //    $scope.model.Amount = (bill.Amount * bill.DiscountValue)/100;
        //}

        //$scope.model.TaxStructureId = tax.Id;
        //if ($scope.model.TaxStructureId) {
        //    service.getTaxStructure($scope.model.TaxStructureId)
        //        .then(function (data) {
        //            $scope.LinkTaxStructures = data.Data.LinkTaxStructures;
        //            $scope.calculateRoomRateTax();
        //            bill.ChargePostDetails=[];

        //            bill.ChargePostDetails = angular.copy($scope.ChargePostDetails);
                    
        //        });
        //}

    };

    $scope.BillAllowanceListSum =function(){
        var amount = 0;
        angular.forEach($scope.BillAllowanceList,function(item){
            item.Amount = $filter("number")(item.Amount , 2).replace(/,/g, "");
            amount = parseFloat(amount) + parseFloat(item.Amount);
            

        });
        return $filter("number")(amount , 2).replace(/,/g, "");
    }
    $scope.loadBillTax = function (bill, tax) {
        
        if (tax) {
            bill.TaxStructureId = tax.Id;
            $scope.TaxStructure = tax;
        }

        bill.LinkRevenues = [];
        if (!bill.DiscountAmount) bill.DiscountAmount = 0;
        bill.DiscountTaxAmount = 0;
        bill.DiscountTotalAmount = bill.DiscountAmount;
        angular.forEach($scope.TaxStructure.LinkTaxStructures, function (linktax) {
            var linkRevenue1 = $scope.RevenueHeads.find(x => x.Code == linktax.TaxTypeCode);
            if (linkRevenue1) {
                var linkRevenue = angular.copy(linkRevenue1);
                if (!($scope.TaxStructure.IsSlab && (bill.Amount < linktax.MinRange || bill.Amount > linktax.MaxRange))) {
                    if (linktax.TaxInId === 2) {//Percent
                        linkRevenue.DiscountAmount = decimalValD(parseFloat(bill.DiscountAmount) * parseFloat(linktax.TaxValue) / 100);
                    } else {
                        linkRevenue.DiscountAmount = decimalValD(linktax.TaxValue);
                    }
                    bill.DiscountTaxAmount += linkRevenue.DiscountAmount;
                    bill.DiscountTotalAmount = parseFloat(bill.DiscountAmount) + parseFloat(bill.DiscountTaxAmount);
                    bill.LinkRevenues.push(linkRevenue);
                }
            }
        });

        bill.DiscountTaxAmount = decimalValD(bill.DiscountTaxAmount);
        bill.DiscountTotalAmount = decimalValD(bill.DiscountTotalAmount);
        
        //TODO: Navneet 11-01-2019
        
        //---------------------
        if(bill.DiscountTypeId=='1')
        {
            $scope.model.Amount = bill.DiscountValue;
        }
        else
        {
            $scope.model.Amount = (bill.Amount * bill.DiscountValue)/100;
        }

        $scope.model.TaxStructureId = tax.Id;
        if ($scope.model.TaxStructureId) {

            //service.getTaxStructure($scope.model.TaxStructureId)
            //    .then(function (data) {
            //        $scope.LinkTaxStructures = data.Data.LinkTaxStructures;
            //        $scope.calculateRoomRateTax();
            //        bill.ChargePostDetails=[];
            //        bill.ChargePostDetails = angular.copy($scope.ChargePostDetails);
            //    });

            $scope.model.LinkTaxStructures = $scope.LinkTaxStructures.filter(x=>x.TaxStructureId == $scope.model.TaxStructureId);
            bill.ChargePostDetails=[];
            bill.ChargePostDetails = angular.copy($scope.ChargePostDetails);
        }

    };
    $scope.getBillTotal = function () {

        if (!$scope.CheckINGuest) {
            msg('Please select a guest');
            return;
        }
        //var revenueHead = JSON.parse($scope.model.RevenueHead);
        var revenueHead = $scope.RevenueHeads.find(x => x.Id == $scope.model.RevenueHeadId);
        service.getBillTotal($scope.PropertyID, $scope.CheckINGuest.Id, revenueHead.Id)
            .then(function (result) {
                $scope.BillConsolidated = result.Data;
            }, function (err) {
                msg(err.Message);
            });

    };

    $scope.openPostingDialog = function () {
        $scope.CurrentTab = 1;
        $scope.model.PostDate = $scope.ModifiedDate;
        $scope.model.ReferenceNo = '';
        $scope.model.RevenueHeadId = '';
        $scope.model.CurrencyId = !$scope.DefaultSetting.CurrencyMasterId ? "0" : $scope.DefaultSetting.CurrencyMasterId.toString();
        $scope.model.Amount = '';
        $scope.model.TaxAmount = '';
        $scope.model.TotalAmount = '';
        $scope.model.IsTaxInclusive = '';
        $scope.model.Particular = '';
        $scope.model.ReasonId = '';
        $scope.model.Remark = '';
        $scope.model.Mobile = '';
        $scope.ChargePostDetails = [];

        $scope.model.PaymentModeRevenueHeadCode = '';
        $scope.model.CreditCardNetworkId= '0';
        $scope.model.CreditCardNumber ='';
        $scope.model.GuestName        ='';
        $scope.model.ChequeNo         ='';
        $scope.model.BankName         ='';


        $('#postingModal').modal('show');
        $scope.SetTab();

    };

    $scope.deleteChargePost = function (id) {
        
        var model ={
            RevenuePostId :id,
            ChargePostToId:7
        };
        $scope.deleteConfirm(model);
    };

    $scope.editChargePost = function (misc) {
        
        var model ={
            RevenuePostId :misc.Id,
            RevenueHeadId: misc.RevenueHeadId,
            ChargePostToId:7
        };
        $scope.editTransaction(model);
    };

    $scope.SelectedTransaction={};
    $scope.deleteConfirm = function (model) {
        $scope.SelectedTransaction=model;    
        $scope.SelectedTransaction.Remark="";    

        var strDelete = DeletePopup("Are you sure you want to delete this transaction?");
        var ret;
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $("#fancyconfirm_cancel")
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $("#fancyConfirm_ok")
                    .click(function () {

                        ret = true;

                        $('#transactionDeleteModal').modal('show');
                        
                        $.fancybox.close();
                    });
            }
        });
    };

    $scope.DeleteTransaction = function () {

        if (!$scope.SelectedTransaction.ReasonId) {
            msg('Please select a Reason.');
            return;
        }
        if (!$scope.SelectedTransaction.Remark) {
            msg('Please enter remarks.');
            return;
        }
        var model = $scope.SelectedTransaction;
        service.deleteTransaction({ Id: model.RevenuePostId, ChargePostId: model.ChargePostId, ReasonId: model.ReasonId, Remark: model.Remark, ModifiedBy: $scope.ModifiedBy })
            .then(function (d) {
                msg(d.Message, d.Status);
                                
                if(model.ChargePostToId==7)
                {
                    $scope.getMiscellaneous();
                }
                else
                {
                    var index;
                    angular.forEach($scope.CheckINGuestRevenuePosts,function(item,key){
                        if(item.Id == model.Id)
                        {
                            index=key
                        }
                    })
                    if(index)
                    {
                        $scope.CheckINGuestRevenuePosts.splice(index, 1);
                    }
                    $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:d.Message, Status:d.Status});
                }

                angular.forEach($scope.CheckINGuests,function(item){
                    if(item.IsSelected)
                    {
                        $scope.SetCheckINGuest2(item);
                    }
                });

                $scope.SelectedTransaction={};

                $scope.reset();
                $('#transactionDeleteModal').modal('hide');

            }, function (error) {
                msg(error.Message);
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:error.Message, Status:false});
            });
    };

    $scope.editTransaction = function (tran) {
        $scope.ChargePostDetails = [];

        var strDelete = DeletePopup("Are you sure you want to edit this transaction?");
        var ret;
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $("#fancyconfirm_cancel")
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $("#fancyConfirm_ok")
                    .click(function () {

                        ret = true;
                        $.fancybox.close();
                        $scope.$apply(function () {
                            //$('#postingModal').modal('show');

                            service.GetById(tran.RevenuePostId)
                                .then(function (result) {

                                    
                                    var chargePost = result.Data;

                                    if (chargePost.ChargePostTypeId == 2) {
                                        chargePost = {};
                                        msg('Receipt can not be modify.');
                                        $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Receipt can not be modify.', Status:false});
                                    }
                                    else {

                                        $scope.openPostingDialog();
                                        $scope.SetTab(chargePost.ChargePostTypeId);
                                        $scope.IsEdit = true;
                                        $scope.model = chargePost;
                                        $scope.model.ChargePostId = chargePost.ChargePostId;
                                        $scope.model.ChargePostToId = chargePost.ChargePostToId.toString();
                                        $scope.model.CurrencyId = chargePost.CurrencyId.toString();
                                        $scope.model.RevenueHeadId = tran.RevenueHeadId.toString();
                                        if(tran.RevenueHeadCode)
                                        {
                                            $scope.model.RevenueHeadCode = tran.RevenueHeadCode.toString();
                                        }
                                        
                                        angular.forEach(chargePost.ChargePostDetails, function (item) {
                                            if (item.SNo != 1) {
                                                $scope.ChargePostDetails.push(item);
                                            }
                                            
                                            if(chargePost.ChargePostTypeId=='4' && item.PostingTypeId=='1')
                                            {
                                                
                                                $scope.model.PaymentModeRevenueHeadCode = item.RevenueHeadCode;
                                                $scope.model.CreditCardNetworkId= chargePost.CreditCardNetworkId.toString();
                                            }
                                        });
                                        if (chargePost.ChargePostTypeId == 6) {
                                            $scope.getBillList();
                                        }
                                    }
                                    $scope.calculateTax();
                                });
                        });
                    });
            }
        });

    };

    $scope.ChargePostToId = 1;
    $scope.model.ChargePostToId = 1;
    $scope.RevenueForId='6';
    $scope.changeChargePostToId = function () { 

        $scope.IsGroupSelected=false;
        $scope.GroupCheckINGuest={};
        $scope.model.ChargePostToId = $scope.ChargePostToId;
        $scope.reset();
        $scope.CheckINGuest = {};
        $scope.Transactions = [];
        $scope.FPs = [];
        
        $scope.CheckINGuestRevenuePosts = [];
        $scope.RevenueForId='6';
        switch ($scope.model.ChargePostToId) {
            case "1": $scope.SelectedFP={};$scope.GetOccupiedRooms();break;
            case "5": $scope.SelectedFP={};$scope.getReservations(); break;
            case "7": $scope.SelectedFP={};$scope.getMiscellaneous();break;
            case "8": $scope.SelectedFP={};$scope.getHotelPaidOUT(); break;
            case "10": $scope.GetFPCashiering(); break;
        }

        if($scope.model.ChargePostToId=="999")
        {
            $scope.GetAllGroup();
        }

    };

    $scope.IsGroupLoading= false;
    $scope.GetAllGroup = function () {
        $scope.IsGroupLoading= true;
        $scope.IsGroupSelected=true;
        $scope.IsGuestSelected=false;
        $scope.OccupiedRooms =[];
        $scope.GroupCheckINGuests = [];
        service.getAllGroup($scope.PropertyID, 2, businessDate)
            .then(function (data, status) {
                $scope.GroupCheckINGuests = data.Collection;
                $scope.IsGroupLoading= false;
            }, function (e) {
                msg(e.Message);
                $scope.IsGroupLoading= false;
            });
    };

    $scope.getReservations = function () {
        $scope.ProgressStart();
        var promise;
        if ($scope.SearchReservation || $scope.SearchGuest)
            promise = service.getReservations({ PropertyID: $scope.PropertyID, ReservationNo: $scope.SearchReservation, GuestName: $scope.SearchGuest, IsPending: true, DepartureDateString: $scope.ModifiedDate });
        else
            promise = service.getReservations({ PropertyID: $scope.PropertyID, ArrivalDateString: $scope.ModifiedDate, DepartureDateString: $scope.ModifiedDate, IsPending: true });
        promise.then(function (result) {
            $scope.Reservations = result.Collection;

            $scope.Reservations.forEach(function (r) {
                guestMessageService.getMessageList(1, r, 2);
                guestMessageService.getMessageList(1, r, 1);
                //service.getMessageList($scope.PropertyID, 1, r.Id).then(function (m) {
                //    r.messagesCount=m.Collection.length;
                //    r.messages = $filter('groupBy')(m.Collection, 'MessageToName','RoomNumber');
                //    r.group=r.messages['0000'];
                //}, function (err) {
                //    msg(err.Message);
                //});
            });
            $scope.ProgressEnd();
        }, function (err) {
            $scope.ProgressEnd();
            msg(err.Message);
        });

    };
    $scope.fillReservation = function (record) {
        $scope.reset();
        $scope.SelectedReservation = record;
        $scope.CheckINGuest = {
            Id: record.Id,
            CheckINId: record.Id,
            CheckINNo:record.ReservationNo,
            Name: record.GuestName,
            CheckINDate: record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].ArrivalDate : "",
            CheckOUTDate: record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].DepartureDate : "",
            //PaxCount: paxCount,
            PaxCount: record.TotalPax,
            Tariff :    record.ReservationRoomTypes[0].Tariff,
            //RoomTypeName = record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].RoomTypeName : ""            
            DayRateAmount: record.ReservationAmount,
            CorporateName: record.CorporateName,
            Nationality: !record.ReservationRoomTypes || record.ReservationRoomTypes.length < 1 ? "" : !record.ReservationRoomTypes[0].ReservationRoomTypeGuests || record.ReservationRoomTypes[0].ReservationRoomTypeGuests.length < 1 ? "" : record.ReservationRoomTypes[0].ReservationRoomTypeGuests[0].Nationality,
            GuestClassDescription: !record.ReservationRoomTypes || record.ReservationRoomTypes.length < 1 ? "" : !record.ReservationRoomTypes[0].ReservationRoomTypeGuests || record.ReservationRoomTypes[0].ReservationRoomTypeGuests.length < 1 ? "" : record.ReservationRoomTypes[0].ReservationRoomTypeGuests[0].GuestClassName,
            BillingInstructionName: record.BillingInstructionName,
            TotalRevenueDr : record.TotalNetAmount,
            TotalRevenueCr : record.TotalAdvance,
            CheckINGuestRoom:{
                RoomTypeName: record.RoomTypeNamesForDisplay,
                MealPlanName: record.ReservationRoomTypes && record.ReservationRoomTypes.length > 0 ? record.ReservationRoomTypes[0].MealPlanName : "",
            },
        };

        $scope.GetRevenuePost($scope.CheckINGuest.Id);
    };


    $scope.getMiscellaneous = function () {
        $scope.ProgressStart();
        service.getMiscellaneous($scope.PropertyID, $scope.ModifiedDate)
            .then(function (result) {
                
                $scope.Miscs = result.Collection;
                $scope.ProgressEnd();
            }, function (err) {
                $scope.ProgressEnd();
                msg(err.Message);
            });

    };

    $scope.getHotelPaidOUT = function () {
        $scope.ProgressStart();
        service.getHotelPaidOUT($scope.PropertyID, $scope.ModifiedDate)
            .then(function (result) {
                
                $scope.Miscs = result.Collection;
                $scope.ProgressEnd();
            }, function (err) {
                $scope.ProgressEnd();
                msg(err.Message);
            });

    };

    $scope.fillMisc = function (record) {
        $scope.reset();
        //$scope.CheckINGuest = $scope.CheckINGuest = record;
        //$scope.CheckINGuest.Id = record.ChargePostId;
        //return; //navneet
        $scope.model.ChargePostToId='7';
        $scope.GetRevenuePost('');
    };

    //Room Rate
    $scope.SelectedRoomRateRevenueHeadCode = 'TRF';
    $scope.RoomRateRevenueHeads = [];
    $scope.RoomRateRevenueHeadDetail = {};
    $scope.RoomRateRevenueHeads.push({ Code: 'TRF', Name: 'TARIFF', IsSelected: false });
    $scope.RoomRateRevenueHeads.push({ Code: 'MP', Name: 'MEAL PLAN', IsSelected: false });
    $scope.RoomRateRevenueHeads.push({ Code: 'EXB', Name: 'EXTRA BED', IsSelected: false });
    $scope.RoomRateRevenueHeads.push({ Code: 'RTN', Name: 'RETENTION', IsSelected: false });
    $scope.RoomRateRevenueHeads.push({ Code: 'ERA', Name: 'EARLY ARRIVAL', IsSelected: false });
    $scope.RoomRateRevenueHeads.push({ Code: 'LTD', Name: 'LATE DEPARTURE', IsSelected: false });

    $scope.LinkTaxStructures = [];
    $scope.SelectRoomRateRevenueHead = function (roomRateRevenueHead) {
        $scope.model.LinkTaxStructures=[];
        //$scope.LinkTaxStructures = [];
        $scope.ChargePostDetails = [];
        $scope.model.TaxStructureId = "";
        $scope.model.Amount = 0;
        $scope.model.TaxAmount = 0;
        $scope.model.TotalAmount = 0;
        
        if (!roomRateRevenueHead.IsSelected) {
            roomRateRevenueHead.IsSelected = true;
            return;
        }
        $scope.SelectedRoomRateRevenueHeadCode = '';
        angular.forEach($scope.RoomRateRevenueHeads, function (item) {
            if (roomRateRevenueHead.Code != item.Code) {
                item.IsSelected = false;
            }
            else {

                $scope.SelectedRoomRateRevenueHeadCode = item.Code;
                $scope.SelectedRoomRateRevenueHeadName = item.Name;


                $scope.model.RevenueHeadCode = item.Code;
                $scope.model.RevenueHeadId = '';
                if(!$scope.CheckINGuest.MealPlanTaxStructureId)
                {
                    $scope.CheckINGuest.MealPlanTaxStructureId=$scope.CheckINGuest.MealPlanTaxStructureId
                 }
                //Pick Room Rate
                angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {

                    var revenuePost = item.RevenuePosts.find(x=>x.RevenueHeadCode == $scope.model.RevenueHeadCode);
                    if(revenuePost)
                    {
                        if ( $scope.model.RevenueHeadCode == revenuePost.RevenueHeadCode)
                        {
                            if ( revenuePost.RevenueHeadCode == 'MP' ) {
                                $scope.model.TaxStructureId = !$scope.CheckINGuest.MealPlanTaxStructureId?$scope.CheckINGuest.CheckINGuestRoom.MealPlanTaxStructureId :$scope.CheckINGuest.MealPlanTaxStructureId;
                                $scope.model.Amount = revenuePost.Amount;
                            }
                            else if (revenuePost.RevenueHeadCode == 'EXB') {

                                $scope.model.TaxStructureId = !$scope.CheckINGuest.RateTaxStructureId?$scope.CheckINGuest.CheckINGuestRoom.RateTaxStructureId :$scope.CheckINGuest.RateTaxStructureId;
                                
                                //$scope.model.Amount = $scope.CheckINGuest.ExtraBedAmount;
                                $scope.model.Amount = revenuePost.Amount;
                            }
                            else if ((revenuePost.RevenueHeadCode == 'TRF') 
                                || (revenuePost.RevenueHeadCode == 'RTN') 
                                || (revenuePost.RevenueHeadCode == 'ERA') 
                                || (revenuePost.RevenueHeadCode == 'LTD') ) {
                                //TRF/RTN/ERA/LTD
                                $scope.model.TaxStructureId = !$scope.CheckINGuest.RateTaxStructureId?$scope.CheckINGuest.CheckINGuestRoom.RateTaxStructureId :$scope.CheckINGuest.RateTaxStructureId;
                                $scope.model.Amount = revenuePost.Amount;
                            }
                        }
                    }
                });

                //if (item.Code == 'MP' ) {
                //    $scope.model.TaxStructureId = $scope.CheckINGuest.MealPlanTaxStructureId;
                //}
                //else if (item.Code == 'EXB') {

                //    $scope.model.TaxStructureId = $scope.CheckINGuest.RateTaxStructureId;
                //    $scope.model.Amount = $scope.CheckINGuest.ExtraBedAmount;
                //}
                //else {
                //    //TRF/RTN/ERA/LTD

                //    $scope.model.TaxStructureId = $scope.CheckINGuest.RateTaxStructureId;
                    
                //    //Pick Room Rate
                //    angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {
                //        angular.forEach(item.RevenuePosts, function (revenuePost) {
                //            if (revenuePost.RevenueHeadCode == 'TRF' && revenuePost.PostingTypeId==1) {
                //                $scope.model.Amount = revenuePost.Amount;
                //            }
                //        });
                //    });

                //}

                if ($scope.model.TaxStructureId) {

                    //service.getTaxStructure($scope.model.TaxStructureId)
                    //    .then(function (data) {
                    //        $scope.LinkTaxStructures = data.Data.LinkTaxStructures;
                    //        $scope.calculateRoomRateTax();
                    //    });

                    $scope.model.LinkTaxStructures =  $scope.LinkTaxStructures.filter(x=>x.TaxStructureId == $scope.model.TaxStructureId);
                    $scope.calculateRoomRateTax();
                }
                
            }
        });
    };

    $scope.ChargePostDetails = [];
    $scope.TaxRateIn = "";
    $scope.calculateRoomRateTax = function () {
        $scope.ChargePostDetails = [];
        var i = 2;
        $scope.model.TaxAmount = 0.0;
        $scope.model.TotalAmount = 0.0;

        $scope.model.TaxRateIn = "";
        $scope.model.TotalPer = 0.0;
        $scope.model.TotalAmt = 0.0;

        if ($scope.model.TaxStructureId) {
            //Tariff
            var taxAmount = 0.0;
            var taxRateIn = 0.0;
            
            angular.forEach($scope.model.LinkTaxStructures, function (linkTaxStructure, index) {

                taxAmount = $scope.GetTaxAmount($scope.ChargePostDetails, linkTaxStructure, parseFloat($scope.model.Amount), parseFloat($scope.model.Amount));
                if (isNaN(taxAmount)) {
                    taxAmount = 0;
                }

                taxAmount = $filter("number")(taxAmount, 2).replace(/,/g, "");


                if (parseFloat(totalAmt) > 0) {
                    taxRateIn = $filter("number")(parseFloat(totalAmt), 2).replace(/,/g, "") + "Amt";
                }
                else {
                    taxRateIn = $filter("number")(parseFloat(totalPer), 2).replace(/,/g, "") + "%";
                }
                
                $scope.ChargePostDetails.push({

                    ChargePostId: '',
                    SNo: i,
                    RevenueHeadId: '',
                    RevenueHeadCode: linkTaxStructure.TaxTypeCode,
                    TaxTypeId:linkTaxStructure.TaxTypeId,
                    PostingTypeId: 1,
                    Amount: taxAmount,
                    TaxRateIn: taxRateIn
                });
                i = 1 + i;

                $scope.model.TaxAmount = parseFloat($scope.model.TaxAmount) + parseFloat(taxAmount);
                $scope.model.TotalPer = parseFloat($scope.model.TotalPer) + parseFloat(totalPer);
                $scope.model.TotalAmt = parseFloat($scope.model.TotalAmt) + parseFloat(totalAmt);

            })

        }

        var txt = "";
        if ($scope.model.TotalPer > 0) {
            txt = $filter("number")($scope.model.TotalPer, 2).replace(/,/g, "");
        }

        if ($scope.model.TotalAmt > 0) {
            if (txt.length > 0) {
                txt = txt + "%, ";
            }
            txt = txt + $filter("number")($scope.model.TotalAmt, 2).replace(/,/g, "") + " Amt";
        }
        else {
            if (txt.length > 0) {
                txt = txt + "%";
            }
        }

        $scope.model.TaxRateIn = txt;

        $scope.model.TaxAmount = $filter("number")($scope.model.TaxAmount, 2).replace(/,/g, "");
        $scope.model.TotalAmount = $filter("number")(parseFloat($scope.model.Amount) + parseFloat($scope.model.TaxAmount), 2).replace(/,/g, "");
        $scope.model.Amount = $filter("number")($scope.model.Amount, 2).replace(/,/g, "");

    };

    var totalPer = 0.0;
    var totalAmt = 0.0;

    $scope.GetTaxAmount = function (reservationRoomTypeRateTaxs, tax, OriginalRate, ChangeRate) {
        
        totalPer = 0.0;
        totalAmt = 0.0;

        var calculatetax = 0.0;
        var itemTax = tax.TaxValue.toString();
        itemTax = replaceAll(itemTax, ',', '');

        if (tax.TaxOnId === 1) {
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                        totalPer += itemTax;
                    } else {
                        calculatetax = parseFloat(itemTax);
                        totalAmt += itemTax;
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                    totalPer += itemTax;
                } else {
                    calculatetax = parseFloat(OriginalRate);
                    totalAmt += itemTax;
                }
            }
        } else if (tax.TaxOnId === 2) {//Discounted For MealPlan
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(ChangeRate) && parseFloat(tax.MaxRange) >= parseFloat(ChangeRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                        totalPer += itemTax;
                    } else {
                        calculatetax = parseFloat(itemTax);
                        totalAmt += itemTax;
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                    totalPer += itemTax;
                } else {
                    calculatetax = parseFloat(itemTax);
                    totalAmt += itemTax;
                }
            }
        }
        else if (tax.TaxOnId === 5) {
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                        totalPer += itemTax;
                    } else {
                        calculatetax = parseFloat(itemTax);
                        totalAmt += itemTax;
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                    totalPer += itemTax;
                } else {
                    calculatetax = parseFloat(itemTax);
                    totalAmt += itemTax;
                }
            }
        }
        else if (tax.TaxOnId === 6) {
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(ChangeRate) && parseFloat(tax.MaxRange) >= parseFloat(ChangeRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                        totalPer += itemTax;
                    } else {
                        calculatetax = parseFloat(itemTax);
                        totalAmt += itemTax;
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                    totalPer += itemTax;
                } else {
                    calculatetax = parseFloat(itemTax);
                    totalAmt += itemTax;
                }
            }
        }
        else {
                
            if(reservationRoomTypeRateTaxs.length>0)
            {
                angular.forEach(reservationRoomTypeRateTaxs,function(item){
                    if(tax.TaxOnTaxTypeId == item.TaxTypeId)
                    {
                        if (tax.TaxInId === 2) {//Percent
                            calculatetax = parseFloat(item.Amount) * parseFloat(itemTax) / 100;
                        } else {
                            calculatetax = parseFloat(itemTax);
                        }
                    }
                });
            }
        }

        return parseFloat(calculatetax);
    };

    $scope.IsInclusive = function () {
        if (!$scope.model.IsTaxInclusive) {
            $scope.model.Amount = $scope.model.TotalAmount;
            $scope.calculateRoomRateTax();
            return;
        }
        var i = 1;
        //$scope.model.Amount = 0;
        $scope.model.TaxAmount = 0;
        $scope.model.TotalAmount = 0;
        $scope.ChargePostDetails = [];
        var chargeAmount = $scope.model.Amount;
        var totalTaxPercent = 0.0;
        angular.forEach($scope.model.LinkTaxStructures, function (linkTaxStructure, index) {
            if (linkTaxStructure.IsSlab) {
                if (linkTaxStructure.MinRange <= chargeAmount && linkTaxStructure.MaxRange >= chargeAmount) {
                    totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                }
            }
            else {
                totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
            }
        });

        var totalTariff = 0.0;
        totalTariff = (chargeAmount * 100) / (100 + parseFloat(totalTaxPercent));

        angular.forEach($scope.model.LinkTaxStructures, function (linkTaxStructure, index) {
            if (!linkTaxStructure.IsSlab || (linkTaxStructure.MinRange <= chargeAmount && linkTaxStructure.MaxRange >= chargeAmount)) {
                
                var tax = (totalTariff * linkTaxStructure.TaxValue) / 100;
                tax = $filter("number")(tax, 3).replace(/,/g, ""),
                    $scope.ChargePostDetails.push({
                        Id: '',
                        //CheckINGuestRoomRateId:rate.Id ,
                        //RoomItemTypeId        :'1',
                        SNo: index + 2,
                        TaxTypeId: linkTaxStructure.TaxTypeId,
                        TaxOnId: linkTaxStructure.TaxOnId,
                        IsTariffOn: linkTaxStructure.IsTariffOn,
                        TaxInId: linkTaxStructure.TaxInId,
                        TaxValue: linkTaxStructure.TaxValue,
                        TaxAmount: tax,
                        RevenueHeadCode: linkTaxStructure.TaxTypeCode,
                        Amount: tax,
                        PostingTypeId: 1,

                    });
            }
        });

        $scope.model.Amount = totalTariff;
        $scope.model.TaxAmount = chargeAmount - totalTariff;
        $scope.model.TotalAmount = parseFloat($scope.model.Amount) + parseFloat($scope.model.TaxAmount);

        $scope.model.Amount = $filter("number")($scope.model.Amount, 2).replace(/,/g, "");
        $scope.model.TaxAmount = $filter("number")($scope.model.TaxAmount, 2).replace(/,/g, "");
        $scope.model.TotalAmount = $filter("number")($scope.model.TotalAmount, 2).replace(/,/g, "");

    };
    $scope.saveRoomRate = function (form, chargePostTypeId, postingTypeId) {

        if (!$scope[form].$valid) {
            $scope.ShowErrorMessage = true;
            return;
        }
        if (!$scope.CheckINGuest) {
            msgInPopup('Please select a guest');
            return;
        }
        if ($scope.model.Amount <= 0) {
            parent.posFailureMessage('Please enter amount');
            msgInPopup('Please enter amount');
            return;
        }
        $scope.model.Particular = $scope.SelectedRoomRateRevenueHeadName + " charge for the day.";
        $scope.model.ChargePostId = $scope.CheckINGuest.Id;
        $scope.model.ChargePostTypeId = chargePostTypeId;
        
        $scope.ChargePostDetails.push({
            ChargePostId: '',
            SNo: 1,
            RevenueHeadId: '',
            RevenueHeadCode: $scope.SelectedRoomRateRevenueHeadCode,
            PostingTypeId: 1,
            Amount: $scope.model.Amount
        });

        $scope.model.ChargePostDetails = $scope.ChargePostDetails;

        $scope.model.IsGroupSelected = $scope.IsGroupSelected;
        $scope.model.PropertyID = $scope.PropertyID;
        $scope.model.ModifiedBy = $scope.ModifiedBy;

        if($scope.IsProgress)
        {
            return;
        }
        $scope.IsProgress = true;
        $scope.ProgressStart();

        service.save($scope.model)
            .then(function (d) {
                $scope.GetRevenuePost($scope.CheckINGuest.Id);
                if (chargePostTypeId == 9) {
                    parent.successMessage("Late Departure saved successfully.");
                    $('#lateDepartureBox').modal('hide');

                    GetCheckOUTSetup();
                    $scope.ShowCheckOUTModel();
                }
                else {
                    msgInPopup(d.Message, d.Status);
                }
                $scope.model.ChargePostDetails = [];
                $scope.model.Amount = 0;
                $scope.model.TaxAmount = 0;
                $scope.model.TotalAmount = 0;

                $scope.IsProgress = false;
                $scope.ProgressEnd();

                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:d.Message, Status:d.Status});

            }).finally(function () {
                $scope.IsProgress = false;
                $scope.ProgressEnd();
            });
    };

    function replaceAll(str, find, replace) {
        return str.replace(new RegExp(find, 'g'), replace);
    }
    //END Room Rate

    //Late Departure
    $scope.SaveLateDepartureCharge = function (form, chargePostTypeId, postingTypeId) {

        if (!$scope[form].$valid) {
            $scope.ShowErrorMessage = true;
            return;
        }

        if (!$scope.CheckINGuest) {
            msgInPopup('Please select a guest');
            $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Please select a guest', Status:false});
            return;
        }

        $scope.model.Particular = $scope.SelectedRoomRateRevenueHeadName + " charge for the day.";
        $scope.model.ChargePostId = $scope.CheckINGuest.Id;
        $scope.model.ChargePostTypeId = chargePostTypeId;
        

        $scope.ChargePostDetails.push({
            ChargePostId: '',
            SNo: 1,
            RevenueHeadId: '',
            RevenueHeadCode: $scope.SelectedRoomRateRevenueHeadCode,
            PostingTypeId: 1,
            Amount: $scope.model.Amount,
        });

        $scope.model.ChargePostDetails = $scope.ChargePostDetails;

        $scope.model.IsGroupSelected = $scope.IsGroupSelected;
        $scope.model.PropertyID = $scope.PropertyID;
        $scope.model.ModifiedBy = $scope.ModifiedBy;
        
        $scope.IsProgress = true;
        $scope.ProgressStart();

        service.save($scope.model)
            .then(function (d) {
                msgInPopup(d.Message, d.Status);
                $scope.GetRevenuePost($scope.CheckINGuest.Id);
                $scope.reset();
                $scope.Model.CheckINGuestId = '';
                $scope.IsProgress = false;
                $scope.ProgressEnd();
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:d.Message, Status:d.Status});
            });
    };
    $scope.SkipLateDepartureCharge = function () {
        $('#lateDepartureBox').modal('hide');
        GetCheckOUTSetup();
        $scope.ShowCheckOUTModel();
    };
    //End Late Departure1

    //CheckOUT ~navneet
    $scope.CheckOUT = {};
    $scope.RoomOwners = [];
    $scope.IsGetCheckOUTSetup = false;

    GetCheckOUTSetup();
    function GetCheckOUTSetup() {
        
        if($scope.IsGroupSelected)
        {
            GetGroupCheckOUTSetup();
            return;
        }

        SplitBillings = [];
        $scope.CheckOUT = {};
        $scope.RoomOwners = [];
        $scope.SplitRevenuePosts = [];
        $scope.SplitBillings = [];

        if (!$scope.CheckINGuest) {
            return;
        }
        $scope.IsGetCheckOUTSetup = true;

        if ($scope.model.ChargePostToId == "10") {

        }
        
        if ($scope.model.ChargePostToId == 1) {
            var checkINGuestRoomId = $scope.CheckINGuest.CheckINGuestRoomId;
            if (!checkINGuestRoomId) {
                parent.failureMessage("Please Select CheckIN Room.");
                return;
            }
        }
        
        service.getCheckOUT($scope.PropertyID, checkINGuestRoomId, businessDate, $scope.SelectedFP.Id)
            .then(function (data) {
                $scope.IsGetCheckOUTSetup = false;
                $scope.CheckOUT = data.Data;
                $scope.RoomOwnerCheckINGuestId = data.Data.RoomOwnerCheckINGuestId;
                $scope.RoomOwners = data.Data.RoomOwners;

                $scope.SplitRevenuePosts = data.Data.SplitRevenuePosts;
                
                $scope.FOBills = data.Data.FOBills;
                $scope.SetRoomOwnerRevenuePost();
                $scope.ProgressEnd();
            },function (error) {
                
                $scope.IsGetCheckOUTSetup = false;
                parent.posFailureMessage(error.Message);
                $('#checkoutModal').modal('hide');
                scrollPageOnTop();
                $scope.IsProgress = false;
            });
    }

    $scope.GetReservationCancelBill = function(reservationId){
        
        $scope.FOBills=[];  
        service.GetReservationCancelBill(reservationId)
            .then(function (data) {
                //$scope.IsGetCheckOUTSetup = false;
                $scope.FOBills = data.Collection;
                $scope.ProgressEnd();
            },function (error) {
                
                //$scope.IsGetCheckOUTSetup = false;
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
                $scope.IsProgress = false;
            });
    }

    function GetGroupCheckOUTSetup() {

        SplitBillings = [];
        $scope.CheckOUT = {};
        $scope.RoomOwners = [];
        $scope.SplitRevenuePosts = [];
        $scope.SplitBillings = [];

        if (!$scope.CheckINGuest) {
            return;
        }

        var checkINGuestId = $scope.CheckINGuest.Id;
        if (!checkINGuestId) {
            parent.failureMessage("Please Select Group Leader.");
            return;
        }

        service.getGroupCheckOUT($scope.PropertyID, checkINGuestId, businessDate)
            .then(function (data) {

                $scope.CheckOUT = data.Data;
                $scope.RoomOwnerCheckINGuestId = data.Data.RoomOwnerCheckINGuestId;
                $scope.RoomOwners = data.Data.RoomOwners;

                $scope.SplitRevenuePosts = data.Data.SplitRevenuePosts;
                
                $scope.FOBills = data.Data.FOBills;
                $scope.SetRoomOwnerRevenuePost();
                $scope.ProgressEnd();
            });
    }
    $scope.GetCheckOUTSetup = function () {
        GetCheckOUTSetup();
    };

    $scope.SaveAcknowledge = function (messenger) {
        messenger.MessageAcknowledgeRemark = "OK"
        messenger.PropertyID = $scope.PropertyID;
        messenger.ModifiedBy = $scope.UserName;
            
        var promiseGet = service.saveAcknowledge(messenger);
        promiseGet.then(function (data) {
            if (data.Status) {
                $scope.GetCheckOUT();
                parent.successMessage("Message acknowledged Successfully.");
            }
        },
            function (error) {
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.IsSeeMessage=false;
    $scope.SetIsSeeMessage= function()
    {
        $scope.IsSeeMessage=true;
        $scope.GetCheckOUT();
    };
    $scope.IsCheckOUTDateSame = true;
    $scope.unAcknowledges=[];
    $scope.GetCheckOUT = function () {
        if ($scope.model.ChargePostToId == "1") {
            if (!$scope.CheckINGuest.CheckINGuestRoomId) {
                $scope.CheckINGuest.CheckINGuestRoomId = $scope.CheckINGuest.Id;
            }
            if ($scope.CheckINGuest.IsKOTPending == true) {
                scrollPageOnTop();
                parent.failureMessage("Please settle Pending KOT(s).");
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", { Message: "Please settle Pending KOT(s).", Status: false });
                return;
            }
            if ($scope.CheckINGuest.IsLoundryPending == true) {
                scrollPageOnTop();
                parent.failureMessage("Please settle Loundry Bill(s).");
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", { Message: "Please settle Loundry Bill(s).", Status: false });
                return;
            }
            if ($scope.CheckINGuest.IsLaundryDeliveryPending == true) {
                scrollPageOnTop();
                parent.failureMessage("Laundry Delivery is pending.");
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", { Message: "Laundry Delivery is pending.", Status: false });
                return;
            }

            //Get CheckOUT Message
            var promiseGet = service.getAllByMessageTypeId(6, 3, $scope.CheckINGuest.Id);
            promiseGet.then(function (data) {
                $scope.Messages = data.Collection;
                if ($scope.Messages.length == 0) {
                    $scope.IsSeeMessage = true;
                }
                $scope.unAcknowledges = $scope.Messages.filter(x => x.MessageActionId != 3);
                if ($scope.unAcknowledges.length > 0 || !$scope.IsSeeMessage) {
                    scrollPageOnTop();
                    $('#messageBox').modal('show');
                    return;
                }
                else {
                    $('#messageBox').modal('hide');
                }

                $scope.ChargePosts = [];

                var guestCheckINDate = GetJavaScriptDate($filter('date')($scope.CheckINGuest.CheckINDate, $scope.DateFormat), $scope.DateFormat, 0);
                var guestCheckOUTDate = GetJavaScriptDate($filter('date')($scope.CheckINGuest.CheckOUTDate, $scope.DateFormat), $scope.DateFormat, 0);
                var businessdate = GetJavaScriptDate(new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day), $scope.DateFormat, 0);

                //Check for Multiple CheckOUTDate in Same Folio
                $scope.IsCheckOUTDateSame = true;
                if ($scope.CheckINGuests.length > 1) {
                    angular.forEach($scope.CheckINGuests, function (checkINGuest) {
                        if ($scope.CheckINGuest.FolioNo == checkINGuest.FolioNo) {
                            if ($scope.CheckINGuest.CheckOUTDate != checkINGuest.RoomOUTDate) {
                                $scope.IsCheckOUTDateSame = false;
                            }
                        }
                    });
                }


                //Check For Same Day Departure

                var a = GetMomentDate($filter('date')($scope.CheckINGuest.CheckINDate, $scope.DateFormat), $scope.DateFormat);
                var b = GetMomentDate($filter('date')(new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day), $scope.DateFormat), $scope.DateFormat);
                if (a.isSame(b)) {
                    var isExist = false;
                    angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {
                        if (item.RevenueHeadCode == 'TRF') {
                            isExist = true;
                        }
                    });
                    if (!isExist) {
                        $scope.GetAllChargePost();
                        //Show Day End Box
                        $('#dayEndBox').modal('show');
                        return;
                    }
                }
                else {
                    //Check For Late Departure
                    var lateDepartureTime = $scope.DefaultSetting.LateDepartureTime;
                    var checkOUTTypeId = $scope.DefaultSetting.CheckOUTTypeId;
                    if (checkOUTTypeId == 1) {
                        var checkOUTTime = "720";  //12 noon

                        var clockMoment = getMomentFromTimeString($scope.Clock);
                        var clockAsMinutes = (clockMoment.hour() * 60) + clockMoment.minute();

                        var timeDiff = clockAsMinutes - checkOUTTime;
                        if (timeDiff > lateDepartureTime) {
                            $scope.model.TaxStructureId = $scope.CheckINGuest.RateTaxStructureId;
                            angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {
                                angular.forEach(item.RevenuePosts, function (revenuePost) {
                                    if (revenuePost.RevenueHeadCode == 'TRF') {
                                        $scope.model.Amount = revenuePost.Amount;
                                    }
                                });
                            });
                            var isExist = false;
                            angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {
                                if (item.RevenueHeadCode == 'LTD') {
                                    isExist = true;
                                }
                            });
                            if (!isExist) {
                                $scope.calculateRoomRateTax()
                                $scope.SelectedRoomRateRevenueHeadCode = 'LTD';
                                $scope.SelectedRoomRateRevenueHeadName = 'Late Departure '
                                $('#lateDepartureBox').modal('show');
                                return;
                            }
                        }
                    }
                    else//24
                    {
                        var checkOUTTime = $scope.CheckINGuest.CheckINTimeForDisplay;
                    }
                }

                GetCheckOUTSetup();
                $scope.ShowCheckOUTModel();
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                    $scope.IsProgress = false;
                });
        }
        else if ($scope.model.ChargePostToId == "10") {
            

            var isExist = false;
            angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {
                if (item.RevenueHeadCode == 'PPRA') {
                    isExist = true;
                }
            });
            if (!isExist) {
                $scope.GetBillByFunctionProspectusId();
                //Show Day End Box
                //$('#dayEndBox').modal('show');
                return;
            }

            GetCheckOUTSetup();
            $scope.ShowCheckOUTModel();
        }
    };
        
    $scope.GetGroupCheckOUT = function () {
        $scope.GetCheckOUT();
    };
    $scope.ShowCheckOUTModel = function () {
        
        if (!$scope.IsCheckOUTDateSame) {
            var strMsg = DeletePopup("Multiple Check-OUT Dates found in Same Folio. Do you want to Check-OUT all Guest? <br/><br/> Click Cancel to create New Folio.");
            $.fancybox({
                'modal': true,
                'content': strMsg,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            $.fancybox.close();
                            $('#splitguestfolioModal').modal('show')
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {
                            $.fancybox.close();
                            $('#checkoutModal').modal('show');
                        });
                }
            });
        }
        else {
            $('#checkoutModal').modal('show');
        }

    };

    function getMomentFromTimeString(str) {
        var t = moment(str, 'HH:mm A');
        // Now t is a moment.js object of today's date at the time given in str

        if (t.get('hour') < 22) // If it's before 9 pm
            t.add('d', 1); // Add 1 day, so that t is tomorrow's date at the same time

        return t;
    }

    $scope.ChargePosts = [];
    $scope.GetAllChargePost = function () {

        $scope.IsProgress = true;
        var promiseGet = service.getAllChargePost($scope.PropertyID, GetBusinessDate(), $scope.CheckINGuest.Id);
        promiseGet.then(function (data) {

            $scope.ChargePosts = data.Collection;

            $scope.IsProgress = false;

            $('#body').removeClass("disablewholepage");
        },
            function (error) {
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
                $scope.IsProgress = false;
            });

    }

    //Close CheckINGuest Day
    $scope.NightAudit = {};
    $scope.GuestDayClose = function () {

        $scope.IsProgress = true;
        $scope.NightAudit.PropertyID = $scope.PropertyID;
        $scope.NightAudit.ModifiedBy = $scope.UserName;
        $scope.NightAudit.BusinessDate = GetBusinessDate();
        $scope.NightAudit.CheckINGuestId = $scope.CheckINGuest.Id;
        $scope.ProgressStart();
        var promiseGet = service.guestDayClose($scope.NightAudit);
        promiseGet.then(function (data) {

            if (data.Status) {

                $scope.GetRevenuePost($scope.CheckINGuest.Id);
                $scope.ChargePosts = [];
                $scope.NightAudit = {};
                parent.successMessage("Guest Day Tariff saved successfully.");
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Guest Day Tariff saved successfully', Status:data.Status});
                $scope.ProgressEnd();
                $('#dayEndBox').modal('hide');
                return;
            }
            else {
                parent.posFailureMessage("Guest Day Close Fail.");
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:'Guest Day Close Fail', Status:false});
                $scope.IsProgress = false;
                $scope.ProgressEnd();
                $('#body').removeClass("disablewholepage");
            }
        },
            function (error) {

                $scope.IsProgress = false;
                $scope.ProgressEnd();
                parent.posFailureMessage(error.Message);
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:error.Message, Status:false});

                scrollPageOnTop();
            });
    };

    function GetBusinessDate() {
        return $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
    }
    $scope.SetRoomOwnerRevenuePost = function () {

        $scope.RevenuePosts = [];
        //$scope.SplitRevenuePosts=[];
        angular.forEach($scope.RoomOwners, function (roomOwner) {
            roomOwner.TotalAmount = 0;
            if ($scope.model.ChargePostToId != 10) {
                if (!roomOwner.CheckINGuest.IsFOBilled) {
                    if (roomOwner.IsSelected) {
                        angular.forEach(roomOwner.RevenuePostGroups, function(group) {

                            if (roomOwner.CheckINGuest.Id == group.ChargePostId) {

                                $scope.RevenuePosts.push(group);
                                if (group.PostingTypeId == 1) {
                                    roomOwner.TotalAmount += group.TotalAmount;
                                }
                                else if (group.PostingTypeId == 2) {
                                    roomOwner.TotalAmount -= group.TotalAmount;
                                }

                            }
                        });
                    }
                }
                else {
                    roomOwner.IsSelected = false;
                }
            }
            else {
                angular.forEach(roomOwner.RevenuePostGroups, function(group) {
                    $scope.RevenuePosts.push(group);
                    if (group.PostingTypeId == 1) {
                        roomOwner.TotalAmount += group.TotalAmount;
                    }
                    else if (group.PostingTypeId == 2) {
                        roomOwner.TotalAmount -= group.TotalAmount;
                    }
                });
            }
        });
        //Format TotalAmount
        angular.forEach($scope.RoomOwners, function (roomOwner) {
            roomOwner.TotalAmount = $filter("number")(parseFloat(roomOwner.TotalAmount), 2).replace(/,/g, "");
        });
        //Check for new Revenue Posts 
        if ($scope.SplitRevenuePosts.length > 0) {
            angular.forEach($scope.RevenuePosts, function (revenue) {
                var isExit = false;
                angular.forEach($scope.SplitRevenuePosts, function (splitRevenue) {
                    if (revenue.Id == splitRevenue.Id) {
                        isExit = true;
                    }
                });
                if (isExit == false) {
                    revenue.RevenuePostGroupSNo = $scope.SplitRevenuePosts.length + 1;
                    $scope.SplitRevenuePosts.push(revenue);
                }
            });
        }
        $scope.GetCheckOUTNew();
    };
    $scope.GetCheckOUTNew = function () {
        
        $scope.SplitBillings = [];
        $scope.SelectedSplitBilling = { Id: '', };
        $scope.OriginalSplitRevenuePosts = [];
        if ($scope.SplitRevenuePosts.length == 0) {
            $scope.SplitRevenuePosts = angular.copy($scope.RevenuePosts);
            $scope.OriginalSplitRevenuePosts = angular.copy($scope.RevenuePosts);
        }

        
        if($scope.RoomOwners[0].IsGroupLeader)
        {
            var revenueHeads = $scope.RoomOwners[0].CheckINGuest.RevenueHeads;
            if(revenueHeads.length>0)
            {
                var groupCheckINGuestId = $scope.RoomOwners[0].CheckINGuest.Id;
                angular.forEach(revenueHeads,function(revenueHead){
                    angular.forEach($scope.SplitRevenuePosts,function(item){
                        if(revenueHead.Code == item.RevenueHeadCode)
                        {
                            item.MargeChargePostId = groupCheckINGuestId;

                            if(item.MargeChargePostId == groupCheckINGuestId)
                            {
                                item.BillingTypeId = 2;//Company
                            }
                            else
                            {
                                item.BillingTypeId = 1;//Direct
                            }
                        }
                    });
                });

            }
        }

        var id = 1;
        angular.forEach($scope.RoomOwners, function (roomOwner) {
            if (roomOwner.IsSelected) {
                roomOwner.CheckINGuest.Name = roomOwner.CheckINGuest.Name.substring(0, 15);
                roomOwner.CheckINGuest.GuestName = roomOwner.CheckINGuest.Name.substring(0, 15);
                roomOwner.CheckINGuest.CorporateName = roomOwner.CheckINGuest.CorporateName.substring(0, 15);
                roomOwner.CheckINGuest.BillingInstructionName = roomOwner.CheckINGuest.BillingInstructionName.substring(0, 15);
                roomOwner.CheckINGuest.PaxCount = roomOwner.CheckINGuest.CheckINGuestRoom.CurrentFolioOccupancy;
                var roomOwnerSplitRevenuePosts = $scope.SplitRevenuePosts.filter(x => x.MargeChargePostId == roomOwner.CheckINGuest.Id);
                var distinctBillingTypeIds = $scope.GetDistinctBillingTypeId(roomOwnerSplitRevenuePosts);
                distinctBillingTypeIds = $filter('orderBy')(distinctBillingTypeIds)
                angular.forEach(distinctBillingTypeIds, function (billingTypeId) {
                    var billingTypeName = "Custom";
                    if (billingTypeId == 1) {
                        billingTypeName = "Direct";
                    }
                    if (billingTypeId == 2) {
                        billingTypeName = "Company";
                    }

                    $scope.SplitBilling = {
                        Id: id,
                        BillingTypeId: billingTypeId,
                        BillingTypeName: billingTypeName,
                        CheckINGuest: roomOwner.CheckINGuest,
                        RevenuePosts: [],
                        Summarys: [],
                        NetAmount: 0,
                        IsSelected: false,
                    };

                    angular.forEach(roomOwnerSplitRevenuePosts, function (splitRevenuePost) {

                        if (billingTypeId == splitRevenuePost.BillingTypeId) {

                            splitRevenuePost.Particular = splitRevenuePost.Particular.substring(0, 25);
                            splitRevenuePost.TaxRateIn = splitRevenuePost.TaxRateIn;
                            splitRevenuePost.TotalAmount = $filter("number")(parseFloat(splitRevenuePost.TotalAmount), 2).replace(/,/g, "");
                            $scope.SplitBilling.RevenuePosts.push(splitRevenuePost);
                        }
                    });

                    //summary
                    if ($scope.SplitBilling.RevenuePosts.length > 0) {
                        $scope.SetRevenueSummary($scope.SplitBilling);
                        $scope.SplitBillings.push($scope.SplitBilling);
                        id++;
                    }
                });
            }
        });
    };

    $scope.SelectedSplitBilling = { Id: '', };
    $scope.SelectSplitBilling = function (splitBilling) {

        angular.forEach($scope.SplitBillings, function (item) {
            item.IsSelected = false;
        });
        splitBilling.IsSelected = true;
        $scope.SelectedSplitBilling = splitBilling;
    };

    //Split Folio
    $scope.SplitRevenuePosts = [];
    $scope.OriginalSplitRevenuePosts = [];
    $scope.CheckINGuestRevenuePosts = [];
    $scope.IsTransactionLoading = false;
    $scope.GetRevenuePost = function (checkINGuestId) {
        if(!checkINGuestId)
        {
            parent.failureMessage("Select Guest.");

        }
        if($scope.IsGroupSelected)
        {
            $scope.GetOccupiedGroupLeaderRooms($scope.GroupCheckINGuest)
            return;
        }
        $scope.CheckINGuestRevenuePosts=[];
        $scope.IsTransactionLoading = true;
        
        
        service.getRevenuePost($scope.PropertyID, checkINGuestId, $scope.model.ChargePostToId)
            .then(function (data) {
                if($scope.ChargePostToId == '5')
                {
                    $scope.CheckINGuest.TotalRevenueCr=0;
                }

                $scope.CheckINGuestRevenuePosts = data.Collection;
                angular.forEach($scope.CheckINGuestRevenuePosts, function (revenue) {

                    var postDate = $filter('date')(new Date(revenue.BusinessDate), 'yyyy-MM-dd');
                    revenue.IsEdit = $scope.ModifiedDate == postDate;

                    //if (revenue.RevenueHeadCode == 'TRF' || revenue.RevenueHeadCode == 'MP' || revenue.RevenueHeadCode == 'EXB' || revenue.RevenueHeadCode == 'RTN' || revenue.RevenueHeadCode == 'LTD' || revenue.RevenueHeadCode == 'ERA') {
                    //    revenue.IsEdit = false || revenue.PostingTypeId == 2;
                    //}

                    // Anush -- Hide change post type as Reciept and Advanced Refund
                    if(revenue.RevenueHeadCode =='ACC' ||revenue.RevenueHeadCode =='ADC' || revenue.RevenueHeadCode =='ADQ' || revenue.RevenueHeadCode =='ADE' || revenue.RevenueHeadCode =='ARCH' || revenue.RevenueHeadCode =='ARCC' || revenue.RevenueHeadCode =='ARCS' || revenue.RevenueHeadCode =='AREP' || revenue.RevenueHeadCode =='RADC')
                    {
                        revenue.IsEdit = false
                    }
                   
                    if($scope.ChargePostToId == '5')    //Reservation Guest
                    {
                        if(revenue.RevenueHeadCode=='ADC' || revenue.RevenueHeadCode=='ACC' || revenue.RevenueHeadCode=='ADQ' || revenue.RevenueHeadCode=='RADE' )
                        {
                            $scope.CheckINGuest.TotalRevenueCr= $scope.CheckINGuest.TotalRevenueCr + revenue.TotalAmount ;
                        }

                        if(revenue.RevenueHeadCode=='ARCS' || revenue.RevenueHeadCode=='ARCH' || revenue.RevenueHeadCode=='ARCC' || revenue.RevenueHeadCode=='AREP' )
                        {
                            $scope.CheckINGuest.TotalRevenueCr= $scope.CheckINGuest.TotalRevenueCr - revenue.TotalAmount ;
                        }
                    }

                });
                if($scope.ChargePostToId == '1')
                {
                    //Get Split RevenuePOsts
                    service.getSplitRevenuePost($scope.PropertyID, checkINGuestId)
                        .then(function (data) {
                            $scope.SplitRevenuePosts = data.Collection;
                            $scope.OriginalSplitRevenuePosts = angular.copy($scope.SplitRevenuePosts);
                            //Check for new Revenue Posts 
                            if ($scope.SplitRevenuePosts.length > 0) {
                                angular.forEach($scope.CheckINGuestRevenuePosts, function (revenue) {
                                    var isExit = false;

                                    angular.forEach($scope.SplitRevenuePosts, function (splitRevenue) {
                                        if (revenue.Id == splitRevenue.Id) {
                                            isExit = true;
                                        }
                                    });
                                    if (isExit == false) {
                                        $scope.SplitRevenuePosts.push(revenue);
                                    }
                                });
                            }
                        });
                    //Get FO Bills
                    service.getAllFOBill($scope.PropertyID, checkINGuestId,$scope.ChargePostToId)
                        .then(function (data) {
                            
                            $scope.FOBills = data.Collection;
                            //$scope.SearchBill("Pending");

                            $scope.Settlement = {

                                Id: '',
                                SettlementDate: $filter('date')(date, $scope.DateFormat),
                                ModuleId: 1,
                                ModuleName: '',
                                BillId: '',
                                BillDate: '',
                                BillNo: '',

                                RoomNumber: $scope.CheckINGuest.RoomNumber,
                                RoomTypeName: $scope.CheckINGuest.RoomTypeName,
                                CheckINNo: $scope.CheckINGuest.CheckINNo,
                                FolioNo: $scope.CheckINGuest.FolioNo,
                                CheckINDate: $scope.CheckINGuest.CheckINDate,
                                //CheckINTimeForDisplay: $scope.CheckINGuest.CheckINTimeForDisplay,
                                CheckOUTDate: $scope.CheckINGuest.CheckOUTDate,
                                //CheckOUTTimeForDisplay: $scope.CheckINGuest.CheckOUTTimeForDisplay,
                                PAX: $scope.CheckINGuest.PaxCount,
                                BillingInstructionName: $scope.CheckINGuest.BillingInstructionName,
                                RevenueHeadId: $scope.CheckINGuest.RevenueHeadId,
                                RevenueHeadName: $scope.CheckINGuest.RevenueHeadName,

                                GuestName: $scope.CheckINGuest.GuestName,
                                GuestCity: $scope.CheckINGuest.GuestCity,
                                CorporateName: $scope.CheckINGuest.CorporateName,
                                CorporateCity: $scope.CheckINGuest.CorporateCity,
                                TotalNetAmount: 0,

                                SettlementDetails: []
                            };

                        });
                    //$scope.ProgressEnd();
                }
                
                $scope.IsTransactionLoading = false;
            });

    };

    //array of array
    $scope.SplitFolios = [];
    $scope.Split = {
        Guests: [],
    };
    $scope.Guests = [];
    $scope.Guest = {};
    $scope.DistinctCheckINGuests = [];

    $scope.ChangeFolio = function (checkINGuest) {
        $scope.SetRoomOwner(checkINGuest);
    };


    $scope.RoomOwnerValidation = function(){
        
        var value =true;
        var getDistinctRoomIds = $scope.GetDistinctRoomId($scope.CheckINGuests);
        getDistinctRoomIds.forEach(function (roomid) {
            var guests = $scope.CheckINGuests.filter(x=>x.RoomMasterId == roomid && x.IsRoomOwner == true);
            if(guests.length==0)
            {
                value =false;
            }
        });
        return value;
    };

    $scope.SetRoomOwner = function(checkINGuest){
        if(!checkINGuest.RoomMasterId)
        {
            checkINGuest.IsRoomOwner=false;
            return;
        }
        var distinctFolioNos = $scope.GetDistinctFolioNos($scope.CheckINGuests);
        distinctFolioNos.forEach(function (folioNo) {

            var i = 0;
            //Reset
            $scope.CheckINGuests.forEach(function (guest) {   
                if(checkINGuest.FolioNo == guest.FolioNo && checkINGuest.RoomMasterId==guest.RoomMasterId && guest.IsFOBilled==false)
                {
                    guest.IsRoomOwner = false;
                }  
            });

            //Set
            $scope.CheckINGuests.forEach(function (guest) {   
                if(checkINGuest.Id == guest.Id  && guest.RoomMasterId==checkINGuest.RoomMasterId  && guest.IsFOBilled==false)
                {
                    guest.IsRoomOwner = true;
                }                    
            });

            var guests = $scope.CheckINGuests.filter(x=>x.FolioNo == folioNo && x.RoomMasterId==checkINGuest.RoomMasterId  && guest.IsFOBilled==false);
            if(guests.length==1)
            {
                guests[0].IsRoomOwner = true;
            }
            var guests = $scope.CheckINGuests.filter(x=>x.FolioNo == folioNo && x.IsRoomOwner == true && x.RoomMasterId==checkINGuest.RoomMasterId  && guest.IsFOBilled==false);
            if(guests.length==0)
            {
                var guests = $scope.CheckINGuests.filter(x=>x.FolioNo == folioNo  && x.RoomMasterId==checkINGuest.RoomMasterId  && guest.IsFOBilled==false );
                if(guests.length==1)
                {
                    guests[0].IsRoomOwner = true;
                }
            }

        });
          
        
        $scope.GetSplitFolio($scope.CheckINGuests);
    };
    $scope.GetDistinctFolioNos = function (list) {

        var distinctValues = [];
        var newArr = list.filter(function (el) {
            if (distinctValues.indexOf(el.FolioNo) === -1) {
                // If not present in array, then add it
                distinctValues.push(el.FolioNo);
                return true;
            }
            else {
                // Already present in array, don't add it
                return false;
            }
        });
        return distinctValues;
    };

    $scope.GetSplitFolio = function (checkINGuests) {

        $scope.SplitFolios = [];
        // Keep an array of elements whose id is added in filtered array
        var distinctFolio = $scope.GetDistinctFolio(checkINGuests);
        angular.forEach(distinctFolio, function (folioNo) {
            $scope.Split = {
                Guests: []
            };
            angular.forEach(checkINGuests, function (guest) {
                if (folioNo == guest.FolioNo  && guest.IsFOBilled==false) {
                    $scope.Split.Guests.push(guest);
                }
            });
            $scope.SplitFolios.push($scope.Split);
        });

    };
    $scope.GetDistinctCheckINGuest = function () {
        $scope.DistinctCheckINGuests = [];
        angular.forEach($scope.OccupiedRooms, function (room) {
            //all check in guest
            angular.forEach(room.CheckINGuests, function (checkINGuest) {
                $scope.AllCheckINGuests.push(checkINGuest);
            });
            //distinct check in guest
            var distinctFolio = $scope.GetDistinctFolio(room.CheckINGuests);
            angular.forEach(distinctFolio, function (folioNo) {
                var guest = room.CheckINGuests.find(x => x.FolioNo == folioNo);
                $scope.DistinctCheckINGuests.push(guest);
            });
        });
    };
    $scope.SplitFolioReset = function () {
        angular.forEach($scope.CheckINGuests, function (guest) {
            guest.FolioNo = 1;
        });
        $scope.SplitFolios = [];
    };
    $scope.SaveSplitFolio = function () {

        angular.forEach($scope.CheckINGuests, function (guest) {
            guest.PropertyID = $scope.PropertyID;
            guest.ModifiedBy = $scope.ModifiedBy;
            guest.BusinessDate = businessDate
        });
        $scope.SplitFolios = [];

        service.saveSplitFolio($scope.CheckINGuests)
            .then(function (d) {
                parent.successMessage(d.Message);
                $scope.CheckINGuests = [];
                //msg(d.Message, d.Status);
                $scope.GetOccupiedRooms();
                $scope.SplitFolioReset();
                $('#splitguestfolioModal').modal('hide');
                $scope.Model.CheckINGuestId = '';
            }, function (error, status) {

                $scope.SplitFolioReset();
                $('#splitguestfolioModal').modal('hide');
                parent.failureMessage(error.Message);
            });
    };

    $scope.RoomOUTTimeForDisplay = "";
    $scope.SetRoomOUTTime = function () {
        $scope.RoomOUTTimeForDisplay = $filter('date')(new Date(), 'HH:mm');
    };
    $scope.RoomOUTCheckINGuests = [];
    $scope.IsRoomOUTChange = function () {

        $scope.RoomOUTCheckINGuests = [];

        angular.forEach($scope.CheckINGuests, function (item) {
            if (item.IsRoomOUT) {
                item.RoomOUTDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
                item.RoomOUTTimeForDisplay = $scope.RoomOUTTimeForDisplay;

                $scope.RoomOUTCheckINGuests.push(item);

            }
        });

    };
    $scope.SavePAXCheckOUT = function () {
        //check for minimum folio
        var IsRoomOwner = false;
        var keepGoing = true;
        var NumberofFolio = 0;
        var distinctFolio = $scope.GetDistinctFolio($scope.CheckINGuests);

        angular.forEach(distinctFolio, function (folioNo) {
            angular.forEach($scope.CheckINGuests, function (guest) {
                if (guest.FolioNo == folioNo) {
                    NumberofFolio++;
                }
            });
        });

        angular.forEach( $scope.CheckINGuests,function(item){
            item.BusinessDate = businessDate;
        })


        if (NumberofFolio <= 1) {
            parent.failureMessage("PAX Check not allowed as he is room owner.");
            return;
        }
        else {
            var promiseGet = service.savePAXCheckOUT($scope.CheckINGuests);
            promiseGet.then(function (data, status) {

                parent.successMessage("PAX Check-OUT Done.");

                $scope.GetOccupiedRooms();

                $scope.CheckINGuest = { PaxCount: 1 };
                $scope.CheckINGuests = [];
                $scope.CheckINGuestRevenuePosts = [];
                $scope.RoomOUTCheckINGuests = [];

                $('#paxcheckouttModal').modal('hide');


            }, function (error, status) {

                $('#paxcheckouttModal').modal('hide');
                parent.failureMessage(error.Message);

            });
        }

    };

    $scope.GetReason = function () {
        service.getReason($scope.PropertyID)
            .then(function (result) {
                $scope.Reasons = result.Collection;
            }, function (err) {
                parent.posFailureMessage(err.Message);
                //msg(err.Message);
            });
    };
    $scope.GetReason();

    //Transfer Revenue
    $scope.TransferRevenues = [];
    $scope.SelectedTransactions = [];
    $scope.SelectTransaction = function (tran) {

        if (tran.IsSelected)
            tran.IsCollapse = true;


        $scope.SelectedTransactions = [];
        angular.forEach($scope.CheckINGuestRevenuePosts, function (item) {
            if (item.IsSelected) {
                var temp = angular.copy(item);
                $scope.SelectedTransactions.push(temp);
            }
        });

    };
    $scope.ShowTransaction = function (tran) {
        tran.IsCollapse = !tran.IsCollapse;
    };
    $scope.Collapse = function () {
        angular.forEach($scope.SelectedTransactions, function (item) {
            item.IsSelected = false;
        });
    };

    //Get Distinct CheckINGuest
    $scope.AllCheckINGuests = [];
    $scope.DistinctCheckINGuests = [];

    $scope.TransferRevenue =
        {
            SourceCheckINGuestId: '',
            DestinationCheckINGuestId: '',
            BusinessDate: '',
            ReasonId: '',
            Remark: '',
            RevenuePosts: '',
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
        };

    $scope.SaveTransferRevenue = function () {
        if (!$scope.TransferRevenue.ReasonId) {
            parent.posFailureMessage("Please Select Reason.");
            return;
        }
        if (!$scope.TransferRevenue.DestinationCheckINGuestId) {
            parent.posFailureMessage("Please select destination CheckIN guest.");
            return;
        }
        

        $scope.TransferRevenue.SourceCheckINGuestId = $scope.CheckINGuest.Id;
        $scope.TransferRevenue.SourceRoomNumber = $scope.CheckINGuest.RoomNumber;
        $scope.TransferRevenue.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
        $scope.TransferRevenue.RevenuePosts = $scope.SelectedTransactions;
        $scope.TransferRevenue.PropertyID = $scope.PropertyID;
        $scope.TransferRevenue.ModifiedBy = $scope.ModifiedBy;
        $scope.TransferRevenue.DateFormat = $scope.DateFormat;

        var promiseGet = service.saveTransferRevenue($scope.TransferRevenue);
        promiseGet.then(function (data, status) {
            $scope.GetRevenuePost($scope.CheckINGuest.Id);
            $scope.SelectedTransactions = [];
            $scope.TransferRevenue = {};
            parent.successMessage("Transfer Revenue Done.");
            $('#transferrevenueModal').modal('hide');

        }, function (error, status) {
            parent.posFailureMessage(error.Message);
        });
    };
    $scope.SetDestinationCheckINGuest = function (checkINGuest) {
        $scope.TransferRevenue.DestinationCheckINGuestId = checkINGuest.CheckINGuestId;
        $scope.TransferRevenue.DestinationRoomNumber = checkINGuest.RoomNumber;

    };
    $scope.ResetTransferRevenue = function () {
        $scope.SelectedTransactions = [];
    };

    //Split Folio(BillingType)
    $scope.GetDistinctFolio = function (checkINGuests) {
        var distinctFolio = [];
        var newArr = checkINGuests.filter(function (el) {
            if (distinctFolio.indexOf(el.FolioNo) === -1) {
                // If not present in array, then add it
                distinctFolio.push(el.FolioNo);
                return true;
            }
            else {
                // Already present in array, don't add it
                return false;
            }
        });
        return distinctFolio;
    };
    $scope.GetDistinctRevenueHeadCode = function (list) {
        var distinctRevenueHeadCode = [];
        var newArr = list.filter(function (el) {
            if (distinctRevenueHeadCode.indexOf(el.RevenueHeadCode) === -1) {
                // If not present in array, then add it
                distinctRevenueHeadCode.push(el.RevenueHeadCode);
                return true;
            }
            else {
                // Already present in array, don't add it
                return false;
            }
        });
        return distinctRevenueHeadCode;
    };
    $scope.GetDistinctBillingTypeId = function (list) {
        var distinctBillingTypeId = [];
        var newArr = list.filter(function (el) {
            if (distinctBillingTypeId.indexOf(el.BillingTypeId) === -1) {
                // If not present in array, then add it
                distinctBillingTypeId.push(el.BillingTypeId);
                return true;
            }
            else {
                // Already present in array, don't add it
                return false;
            }
        });
        return distinctBillingTypeId;
    };

    $scope.SplitBillings = [];
    $scope.SplitBilling = {
        BillingTypeId: 1,
        BillingTypeName: 'Direct',
        CheckINGuest: '',
        RevenuePosts: [],
        Summary: [],
        NetAmount: 0,
    };
    $scope.Summary = {
        RevenueHeadCode: '',
        Amount: 0,
    };

    //CheckOUT Start     

    //summary
    $scope.SetRevenueSummary = function (splitBilling) {
        var distinctReveueCodes = $scope.GetDistinctRevenueHeadCode(splitBilling.RevenuePosts);
        angular.forEach(distinctReveueCodes, function (revenueHeadCode) {
            var amount = 0;
            var revenueHeadName = '';
            angular.forEach(splitBilling.RevenuePosts, function (revenuePost) {
                if (revenuePost.RevenueHeadCode == revenueHeadCode) {

                    revenueHeadName = revenuePost.RevenueHeadName;
                    if (revenuePost.PostingTypeId == 1) {
                        amount = parseFloat(amount) + parseFloat(revenuePost.TotalAmount);
                    }
                    else {
                        amount = parseFloat(amount) - parseFloat(revenuePost.TotalAmount);
                    }
                }
            });
            $scope.Summary = {
                RevenueHeadCode: revenueHeadCode,
                RevenueHeadName: revenueHeadName,
                TotalAmount: $filter("number")(parseFloat(amount), 2).replace(/,/g, "")
            };
            splitBilling.Summarys.push($scope.Summary);
        });

        splitBilling.NetAmount = 0;
        angular.forEach(splitBilling.Summarys, function (summary) {
            splitBilling.NetAmount = parseFloat(splitBilling.NetAmount) + parseFloat(summary.TotalAmount);
            splitBilling.NetAmount = $filter("number")(parseFloat(splitBilling.NetAmount), 2).replace(/,/g, "");
        });

    };
    $scope.GetSplitBilling = function () {
        var isExist = false;
        var maxBillingTypeId = 0;
        var customeCount = 1;
        angular.forEach($scope.SplitBillings, function (item) {

            if (item.BillingTypeId > maxBillingTypeId) {
                maxBillingTypeId = item.BillingTypeId;
            }
            if (item.BillingTypeId > 2) {
                customeCount++;
            }
        });

        if (maxBillingTypeId == 1) {
            maxBillingTypeId = maxBillingTypeId + 1;
        }

        maxBillingTypeId++;

        $scope.SplitBilling = {
            Id: $scope.SplitBillings.length + 1,
            BillingTypeId: parseInt(maxBillingTypeId),
            BillingTypeName: 'Custom',
            CheckINGuest: $scope.SelectedSplitBilling.CheckINGuest,
            RevenuePosts: [],
            Summarys: [],
            NetAmount: 0,
            IsSelected: false,
        };
        $scope.SplitBillings.push($scope.SplitBilling);

    };
    $scope.handleDrop = function (tran, splitBilling) {
        
        var tran = angular.fromJson(tran);
        var splitBilling = angular.fromJson(splitBilling);
        billingTypeId = parseInt(splitBilling.BillingTypeId);
        angular.forEach($scope.SplitRevenuePosts, function (revenuePost) {
            if (revenuePost.RevenuePostGroupSNo == tran.RevenuePostGroupSNo) {
                var billingTypeName = "Custom";
                if (billingTypeId == 1) {
                    billingTypeName = "Direct";
                }
                if (billingTypeId == 2) {
                    billingTypeName = "Company";
                }
                revenuePost.RoomOwnerCheckINGuestId = splitBilling.CheckINGuest.Id;
                revenuePost.BillingTypeId = billingTypeId;
                revenuePost.BillingTypeName = billingTypeName;
            }
        });
        $scope.GetCheckOUTNew();
    };

    $scope.MergeFolio = function () {
        var margeChargePostId = $scope.SplitBillings[0].CheckINGuest.Id;
        angular.forEach($scope.SplitRevenuePosts, function (revenuePost) {
            angular.forEach($scope.RoomOwners, function (roomOwner) {
                if (roomOwner.CheckINGuest.Id == revenuePost.ChargePostId) {
                    if (roomOwner.IsSelected) {
                        revenuePost.MargeChargePostId = margeChargePostId;
                    }
                }
            });
        });
        $scope.GetCheckOUTNew();
    };
    $scope.ResetMergeFolio = function () {

        angular.forEach($scope.SplitRevenuePosts, function (revenuePost) {


            angular.forEach($scope.RoomOwners, function (roomOwner) {
                if (roomOwner.CheckINGuest.Id == revenuePost.ChargePostId) {
                    if (roomOwner.IsSelected) {
                        revenuePost.MargeChargePostId = revenuePost.ChargePostId;
                    }
                }
            });

        });
        $scope.GetCheckOUTNew();
    };
    $scope.ResetFolio = function () {

        angular.forEach($scope.RoomOwners, function (roomOwner) {
            roomOwner.IsSelected = true;
        });

        $scope.SplitRevenuePosts = [];
        $scope.SplitRevenuePosts = angular.copy($scope.OriginalSplitRevenuePosts);
        $scope.SetRoomOwnerRevenuePost();

    };

    $scope.editRevenuePostAmount = function (tran) {
        tran.SplitTotalAmount = angular.copy(tran.TotalAmount);
        tran.IsAmountEditing = true;
    };
    $scope.doneRevenuePostAmount = function (tran, splitBilling) {

        if (tran.IsAmountEditing == false)
            return;

        if (tran.TotalAmount < tran.SplitTotalAmount) {
            parent.posFailureMessage("Split Amount should be less then Revenue Amount.");
            //parent.failureMessage("Split Amount should be less then Revenue Amount.");
            tran.IsAmountEditing = true;
            return;
        }
        else if (tran.TotalAmount == tran.SplitTotalAmount) {
            tran.SplitTotalAmount = 0;
            tran.IsAmountEditing = false;
            return;
        }

        var ratio = tran.SplitTotalAmount / tran.TotalAmount;
        var splitTran = angular.copy(tran);
        splitTran.RevenuePostGroupSNo = 1 + $scope.SplitRevenuePosts.length;
        splitTran.IsAmountEditing = false;
        splitTran.TotalAmount = splitTran.TotalAmount * ratio;
        angular.forEach(splitTran.RevenuePosts, function (splitRevenue) {
            splitRevenue.Amount = splitRevenue.Amount * ratio;
        });

        $scope.SplitRevenuePosts.push(splitTran);

        //original tran
        tran.IsAmountEditing = false;
        tran.TotalAmount = tran.TotalAmount - splitTran.TotalAmount;
        angular.forEach(splitTran.RevenuePosts, function (splitRevenue) {
            //original tran
            angular.forEach(tran.RevenuePosts, function (revenue) {
                if (splitRevenue.RevenueHeadCode == revenue.RevenueHeadCode)
                    revenue.Amount = revenue.Amount - splitRevenue.Amount;
            });
        });

        angular.forEach($scope.SplitRevenuePosts, function (item, index) {
            if ((item.ChargePostId == tran.ChargePostId) && (index == item.RevenuePostGroupSNo - 1)) {
                item = angular.copy(tran);
            }
        });

        $scope.GetCheckOUTNew();
    };
    $scope.doneRevenuePostAmountOld = function (tran, splitBilling) {

        if (tran.IsAmountEditing == false)
            return;

        if (tran.TotalAmount < tran.SplitTotalAmount) {
            parent.posFailureMessage("Split Amount should be less then Revenue Amount.");
            //parent.failureMessage("Split Amount should be less then Revenue Amount.");
            tran.IsAmountEditing = true;
            return;
        }
        else if (tran.TotalAmount == tran.SplitTotalAmount) {
            tran.SplitTotalAmount = 0;
            tran.IsAmountEditing = false;
            return;
        }

        var ratio = tran.SplitTotalAmount / tran.TotalAmount;
        var splitTran = angular.copy(tran);
        splitTran.RevenuePostGroupSNo = 1 + $scope.SplitRevenuePosts.length;
        splitTran.IsAmountEditing = false;
        splitTran.TotalAmount = splitTran.TotalAmount * ratio;
        angular.forEach(splitTran.RevenuePosts, function (splitRevenue) {
            splitRevenue.Amount = splitRevenue.Amount * ratio;
        });

        $scope.SplitRevenuePosts.push(splitTran);

        //original tran
        tran.IsAmountEditing = false;
        tran.TotalAmount = tran.TotalAmount - splitTran.TotalAmount;
        angular.forEach(splitTran.RevenuePosts, function (splitRevenue) {
            //original tran
            angular.forEach(tran.RevenuePosts, function (revenue) {
                if (splitRevenue.RevenueHeadCode == revenue.RevenueHeadCode)
                    revenue.Amount = revenue.Amount - splitRevenue.Amount;
            });
        });
        $scope.SplitRevenuePosts[tran.RevenuePostGroupSNo - 1] = angular.copy(tran);

        //$scope.GetCheckOUT();
    };
    $scope.SaveSplitRevenuePost = function (callProvisionalPrint) {
        if ($scope.SplitRevenuePosts.length == 0) {
            parent.posFailureMessage("Please Select Billing Type.");
            //parent.failureMessage("Please Select Billing Type.");
            return;
        }
        if ($scope.CheckINGuest.Id) {
        }
        else {
            parent.posFailureMessage("Please Select CheckIN Guest.");
            return;
        }

        $scope.model = {
            Amount: 0,
            ChargePostToId: "1",//1=IN House
            CheckINGuestId: $scope.RoomOwnerCheckINGuestId,
            RevenuePostGroups: $scope.SplitRevenuePosts,
            BusinessDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.ModifiedBy,
            DateFormat: $scope.DateFormat,
        };

        $scope.ProgressStart();
        var promiseGet = service.saveSplitRevenuePost($scope.model);
        promiseGet.then(function (data, status) {
            
            $scope.GetRevenuePost($scope.CheckINGuest.Id);
            if(callProvisionalPrint) $scope.PrintProvisionalBill($scope.CheckINGuest.Id);
            $scope.ProgressEnd();
            $('#checkoutModal').modal('hide');
            parent.popSuccessMessage("Split Revenue Done.");

        }, function (error, status) {
            $scope.ProgressEnd();
            parent.failureMessage(error.Message);
        });
    };

    $scope.SaveFOBill = function () {

        var chargePostToId = $scope.model.ChargePostToId;
       
        if (!$scope.FOShiftId) {
            parent.posFailureMessage('Please Select FO Shift.');
            return;
        }
        if ($scope.SplitRevenuePosts.length == 0) {
            parent.posFailureMessage("Please Select Billing Type.");
            $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:"Please Select Billing Type.", Status:false});
            return;
        }
        if ($scope.CheckINGuest.Id) {
        }
        else {
            parent.posFailureMessage("Please Select CheckIN Guest.");
            $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:"Please Select CheckIN Guest.", Status:false});
            return;
        }

        var isNegative = false;
        angular.forEach($scope.SplitBillings, function (bill) {
            var netAmount = parseFloat(bill.NetAmount);
            if (netAmount < 0) {
                isNegative = true;
            }
        });

        if (isNegative) {
            parent.posFailureMessage("Please Settle Credit Amount.");
            $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:"Please Settle Credit Amount.", Status:false});
            return;
        }

        var splitBillingRevenuePosts = [];
        angular.forEach($scope.SplitBillings, function (splitBilling) {
            angular.forEach(splitBilling.RevenuePosts, function (revenuePost) {
                splitBillingRevenuePosts.push(revenuePost);
            });
        });

        $scope.model = {
            ChargePostToId: chargePostToId,
            CheckINGuestId:$scope.CheckINGuest.Id,
            Amount: 0,
            FOShiftId: $scope.FOShiftId,
            RevenuePostGroups: splitBillingRevenuePosts,
            BillDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
            BusinessDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
            ActualCheckOUTTime: $filter("date")(new Date, "hh:mm a"),
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.ModifiedBy,
            DateFormat: $scope.DateFormat,
        };

        $scope.IsProgress = true;
        $scope.ProgressStart();
        var promiseGet = service.saveFOBill($scope.model);
        promiseGet.then(function (data, status) {

            parent.successMessage(data.Message);

            var promiseGet1 = service.GetAllFOBillByCheckINGuestId($scope.PropertyID, $scope.CheckINGuest.Id);
            promiseGet1.then(function (data, status) {
                angular.forEach(data.Collection,function(pid){
                    service.MapReport($scope.PropertyID, 'bill')
                        .then(function (s) {
                            $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid, '_blank');
                        }, function (e) {
                            msgInPopup('Error in mapping to print.');
                        });
                });
            });


            $timeout(function () {
                $rootScope.$broadcast("CallRoomChartPostChargeMessage", {Message:data.Message, Status:data.Status});
                $scope.changeChargePostToId();
                $scope.SplitBillings = [];
                $scope.model = { ChargePostToId: $scope.ChargePostToId };
                $scope.IsProgress = false;
                $scope.ProgressEnd();
                $('#checkoutModal').modal('hide');
                $scope.CheckINGuestRevenuePosts = [];
                $scope.CheckINGuest.IsFOBilled = true;
         
            },200);
            if($scope.model.ChargePostToId == 10)
            {
                $scope.GetFPById($scope.SelectedFP.Id);
            }                
            else
            {
                $scope.SetCheckINGuest($scope.CheckINGuest.Id);
            }

            
            

        }, function (error, status) {
            $scope.IsProgress = false;
            $scope.ProgressEnd();
            parent.posFailureMessage(error.Message);
        });
    };

    $scope.BanquetBillPostRevenue = function () {
        
        if (!$scope.SelectedFP.Id) {
            parent.posFailureMessage('Please Select Function Prospectus.');
            return;
        }
        
        var postRevenueModel = {
            FunctionProspectusId: $scope.SelectedFP.Id,
            BillDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
            ModifiedBy: $scope.ModifiedBy,
        };

        $scope.IsProgress = true;
        $scope.ProgressStart();
        var promiseGet = service.BanquetBillPostRevenue(postRevenueModel);
        promiseGet.then(function (data, status) {
            
            parent.successMessage(data.Message);
            
            $timeout(function () {
                
                $scope.GetFPCashiering();

                $scope.SplitBillings = [];
                $scope.model = { ChargePostToId: 10 };

                $scope.IsProgress = false;
                $scope.ProgressEnd();

                $('#banquetBillBox').modal('hide');

                $scope.CheckINGuestRevenuePosts = [];
                $scope.CheckINGuest.IsFOBilled = true;
                $scope.GetFPById($scope.SelectedFP.Id)

            }, 200);


        }, function (error, status) {
            $scope.IsProgress = false;
            $scope.ProgressEnd();
            parent.posFailureMessage(error.Message);
        });
    };

    //Settlement start
    var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month, $scope.BusinessDate.Day);

    $scope.SettlementDetailSelect = {
        RevenueHeadCode: 'CSH',
        NoOfCheckINGuest: 0
    };

    $scope.Model = {
        Amount: 0,
        ModuleId: 1, //FrontOffice
        PropertyID: $scope.PropertyID,
        ModifiedBy: $scope.ModifiedBy,
        BusinessDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
        DateFormat: $scope.DateFormat,
        CheckINGuestId: '',
    };

    $scope.Settlement = {
        Id: '',
        SettlementDate: '',
        ModuleId: '',
        ModuleName: '',
        BillId: '',
        CustomerName: '',
        RoomNumber: '',
        MobileNo: '',
        Email: '',
        TotalNetAmount: 0,
        BalanceAmount: 0,

        BillNo: '',
        BillDate: '',
        TableId: '',
        TableName: '',

        SettlementDetails: []
    };

    $scope.SettlementDetail = {
        SNo: 1,
        SettlementId: '',
        RevenueHeadId: '',
        RevenueHeadName: '',
        RevenueHeadCode: '',
        Amount: 0,
        Remark: '',
        TipAmount: 0,
        CreditCardNumber: '',
        CreditCardNetworkId: '',
        CreditCardNetworkName: '',
        GuestName: '',
        CorporateId: '',
        CorporateCode: '',
        CorporateName: '',
        ChequeNo: '',
        BankName: '',
        BankBranch: '',
        CheckINGuestId: '',
        CheckINGuestName: '',
        CheckINGuestRoom: '',
        CheckINGuestMobile: '',
        AuthorizedBy: '',
        CouponType: '',
        CouponId: '',
        NCDepartmentId: '',
        NCDepartmentName: '',
        CurrencyId: '',
        CurrencyCode: '',
        CurrencyName: '',
        ExchangeRate: '',
        CurrencyAmount: '',
        CurrencyPaidOut: '',
    };

    $scope.FOBills = [];
    $scope.SettlementModes = [];

    $scope.GetAllBillByStatus = function (status) {

        $scope.SettlementModel = {};

        if (status == "Pending") {
            $scope.SettlementModel.BillStatusId = 3;  //Pending 
        }
        else {
            $scope.SettlementModel.BillStatusId = 1;  //Settlement 
        }

        $scope.SettlementModel.PropertyID = $scope.PropertyID;
        $scope.SettlementModel.CheckINGuestId = $scope.Model.CheckINGuestId;
        $scope.SettlementModel.ChargePostToId = $scope.ChargePostToId;

        $scope.IsProgress = true;
        var promiseGet = service.getAllBillByStatus($scope.SettlementModel);

        promiseGet.then(function (data) {
            $timeout(function () {
                $scope.FOBills = data.Collection;
                $scope.IsProgress = false;
            }, 200);
           
        },
            function (error) {
                parent.posFailureMessage(error.Message);
            });
    }
    $scope.GetBill = function (bill) {

        if (bill.BillStatusId == 1) {
            parent.posFailureMessage("Bill is already Settled.");
            scrollPageOnTop();
            return;
        }

        $scope.IsProgress = true;
        $scope.Settlement = {};
        $scope.SettlementDetail = {};
        $scope.SettlementDetailSelect = {};
        $scope.Settlement.SettlementDetails = [];
        
        $scope.Settlement = {

            Id: '',
            BillingForId : bill.BillingForId.toString(),
            SettlementDate: $filter('date')(date, $scope.DateFormat),
            ModuleId: '',
            ModuleName: '',
            BillId: bill.Id,
            BillDate: $filter('date')(bill.BillDate, $scope.DateFormat),
            BillNo: bill.BillNo,
            RoomNumber: bill.RoomNumber,
            RoomTypeName: bill.RoomTypeName,
            CheckINNo: bill.CheckINNo,
            FolioNo: bill.FolioNo,
            CheckINDate: bill.CheckINDate,
            CheckINTimeForDisplay: bill.CheckINTimeForDisplay,
            CheckOUTDate: bill.CheckOUTDate,
            CheckOUTTimeForDisplay: bill.CheckOUTTimeForDisplay,
            PAX: bill.PAX,
            BillingInstructionId: bill.BillingInstructionId,
            BillingInstructionName: bill.BillingInstructionName,
            RevenueHeadId: bill.RevenueHeadId,
            RevenueHeadName: bill.RevenueHeadName,
            GuestName: bill.GuestName,
            GuestCity: bill.GuestCity,
            CorporateName: bill.CorporateName,
            CorporateCity: bill.CorporateCity,
            TotalNetAmount: bill.TotalNetAmount,

            SettlementDetails: [],

            BillStatusId : bill.BillStatusId,
        };

        //set CASH as default
        $scope.SettlementDetail = {
            SNo: 1,
            SettlementId: '',
            RevenueHeadId: '',
            RevenueHeadName: 'Cash',
            RevenueHeadCode: 'CSH',
            Amount: bill.TotalNetAmount,
            Remark: '',
            TipAmount: 0,
            CreditCardNumber: '',
            CreditCardNetworkId: '',
            CreditCardNetworkName: '',
            GuestName: '',
            CorporateId: '',
            CorporateCode: '',
            CorporateName: '',
            ChequeNo: '',
            BankName: '',
            BankBranch: '',
            CheckINGuestId: '',
            CheckINGuestName: '',
            CheckINGuestRoom: '',
            CheckINGuestMobile: '',
            AuthorizedBy: '',
            CouponType: '',
            CouponId: '',
            NCDepartmentId: '',
            NCDepartmentName: '',
            CurrencyId: '',
            CurrencyCode: '',
            CurrencyName: '',
            ExchangeRate: '',
            CurrencyAmount: '',
            CurrencyPaidOut: '',
        };

        $scope.SettlementDetailSelect.RevenueHeadCode = 'CSH';
        $scope.Settlement.SettlementDetails.push($scope.SettlementDetail);

        $scope.Total();

        $scope.IsProgress = false;

        if(!$scope.CheckINGuest || !$scope.CheckINGuest.GuestId) $scope.CheckINGuest.GuestId=$scope.CurrentGuestId;
    }
    $scope.Total = function () {

        $scope.Settlement.SettlementAmount = 0;
        $scope.Settlement.BalanceAmount = 0;

        if ($scope.Settlement.SettlementDetails.length > 0) {
            angular.forEach($scope.Settlement.SettlementDetails, function (item) {

                if (item.Amount > 0) {
                    $scope.Settlement.SettlementAmount = parseFloat($scope.Settlement.SettlementAmount) + parseFloat(item.Amount);
                }
            });
        }

        $scope.Settlement.BalanceAmount = parseFloat($scope.Settlement.TotalNetAmount) - parseFloat($scope.Settlement.SettlementAmount)
    }
    $scope.GetBalanceAmount = function (changeamount) {

    }
    
    $scope.GetAllSettlementMode = function () {
        $scope.GetAllBillByStatus('Pending');
        //GetAllSettlementMode();
    };
    //GetAllSettlementMode();
    //function GetAllSettlementMode() {
    //    $scope.IsProgress = true;
    //    var promiseGet = service.getAllSettlementMode($scope.PropertyID, 1);
    //    promiseGet.then(function (data) {
    //        $scope.SettlementMode = data.Collection[0];
    //        $scope.SettlementMode.SettlementModeDetails = $scope.SettlementMode.SettlementModeDetails.filter(x => x.RevenueForId != 6);
    //        $scope.IsProgress = false;
    //    },
    //        function (error) {
    //            parent.posFailureMessage(error.Message);
    //        });
    //}

    $scope.SaveSettelenemt = function () {
        
        if ($scope.IsProgress) {
            return;
        }

        if ($scope.Settlement.BillId == undefined || $scope.Settlement.BillId == "" || $scope.Settlement.BillId == null) {
            parent.posFailureMessage("Please Select Bill for Settle.");
        }

        $scope.Settlement.SettlementDate = businessDate;
        $scope.Settlement.ModuleId = $scope.ModuleId;
        $scope.Settlement.PropertyID = $scope.PropertyID;
        $scope.Settlement.ModifiedBy = $scope.ModifiedBy;
        $scope.Settlement.SettlementTimeForDisplay = $scope.Clock;

        $scope.IsProgress = true;
        $scope.ProgressStart();
        $scope.SettlementTemp = angular.copy( $scope.Settlement);
        var promiseGet = service.saveSettlement($scope.Settlement);
        promiseGet.then(function (data) {

            if(!data.Status)
            {
                $scope.IsProgress = false;
                $scope.ProgressEnd();
                parent.posFailureMessage(data.Message);
                scrollPageOnTop();

                return;
            }
            $scope.CurrentGuestId=$scope.CheckINGuest.GuestId;

            angular.forEach($scope.FOBills, function (bill) {
                if (bill.Id == $scope.SettlementTemp.BillId) {
                    bill.BillStatusId = '1';
                }
            });


            var pid = $scope.SettlementTemp.BillId;
            service.MapReport($scope.PropertyID, 'bill')
                .then(function (s) {
                    $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid, '_blank');
                }, function (e) {
                    msgInPopup('Error in mapping to print.');
                });


            $scope.GetAllBillByStatus("Pending");
            $scope.reset();
            $scope.model.ChargePostToId = "1";
            $scope.changeChargePostToId();
            parent.popSuccessMessage("Settlement done successfully.");
            
            $scope.IsProgress = false;
            $scope.ProgressEnd();

            if ($scope.FOBills.length == 1) {
                $rootScope.$broadcast("CallRoomChartReload", {});
                $('#settlement1').modal('hide');
            }
            
            if ($scope.SettlementTemp.BillStatusId == 5)
            {
                $('#settlement1').modal('hide');
            }
            $scope.Settlement = {};
            $scope.SettlementTemp = {};

        }, function (error) {
            $scope.IsProgress = false;
            $scope.ProgressEnd();
            parent.posFailureMessage(error.Message);
            scrollPageOnTop();
        });

    };
    function removeTableList(tables, tableId) {
        angular.forEach(tables, function (b, index) {
            if (tableId == b.Id) {
                tables.splice(index, 1);
            }
        });
    };
    $scope.SaveSettlementDetail = function () {

        if (!$scope.SettlementDetailSelect.Amount) {
            return;
        }

        if ($scope.SettlementDetailSelect.Amount == 0 || $scope.SettlementDetailSelect.Amount == undefined) {
            parent.posFailureMessage("Please enter Amount.");
            return;
        }

        var max = 1;
        if ($scope.SettlementDetailSelect.SNo != 0 && $scope.SettlementDetailSelect.SNo != undefined) {
            if ($scope.Settlement.SettlementDetails.length > 0) {
                angular.forEach($scope.Settlement.SettlementDetails, function (item) {
                    if ($scope.SettlementDetailSelect.SNo == item.SNo) {

                        item.SNo = $scope.SettlementDetailSelect.SNo;
                        item.SettlementId = $scope.SettlementDetailSelect.SettlementId;
                        item.RevenueHeadId = $scope.SettlementDetailSelect.RevenueHeadId;
                        item.RevenueHeadName = $scope.SettlementDetailSelect.RevenueHeadName;
                        item.RevenueHeadCode = $scope.SettlementDetailSelect.RevenueHeadCode;
                        item.Amount = $scope.SettlementDetailSelect.Amount;
                        item.Remark = $scope.SettlementDetailSelect.Remark;
                        item.TipAmount = $scope.SettlementDetailSelect.TipAmount;
                        item.CreditCardNumber = $scope.SettlementDetailSelect.CreditCardNumber;
                        item.CreditCardNetworkId = $scope.SettlementDetailSelect.CreditCardNetworkId;
                        item.CreditCardNetworkName = $scope.SettlementDetailSelect.CreditCardNetworkName;
                        item.GuestName = $scope.SettlementDetailSelect.GuestName;
                        item.CorporateId = $scope.SettlementDetailSelect.CorporateId;
                        item.CorporateCode = $scope.SettlementDetailSelect.CorporateCode;
                        item.CorporateName = $scope.SettlementDetailSelect.CorporateName;
                        item.ChequeNo = $scope.SettlementDetailSelect.ChequeNo;
                        item.BankName = $scope.SettlementDetailSelect.BankName;
                        item.BankBranch = $scope.SettlementDetailSelect.BankBranch;
                        item.CheckINGuestId = $scope.SettlementDetailSelect.CheckINGuestId;
                        item.CheckINGuestName = $scope.SettlementDetailSelect.CheckINGuestName;
                        item.CheckINGuestRoom = $scope.SettlementDetailSelect.CheckINGuestRoom;
                        item.CheckINGuestMobile = $scope.SettlementDetailSelect.CheckINGuestMobile;
                        item.AuthorizedBy = $scope.SettlementDetailSelect.AuthorizedBy;
                        item.CouponType = $scope.SettlementDetailSelect.CouponType;
                        item.CouponId = $scope.SettlementDetailSelect.CouponId;
                        item.NCDepartmentId = $scope.SettlementDetailSelect.NCDepartmentId;
                        item.NCDepartmentName = $scope.SettlementDetailSelect.NCDepartmentName;
                        item.CurrencyId = $scope.SettlementDetailSelect.CurrencyId;
                        item.CurrencyCode = $scope.SettlementDetailSelect.CurrencyCode;
                        item.CurrencyName = $scope.SettlementDetailSelect.CurrencyName;
                        item.ExchangeRate = $scope.SettlementDetailSelect.ExchangeRate;
                        item.CurrencyAmount = $scope.SettlementDetailSelect.CurrencyAmount;
                        item.CurrencyPaidOut = $scope.SettlementDetailSelect.CurrencyPaidOut;

                    }
                });
            }
        }
        else {
            if ($scope.SettlementDetailSelect.RevenueHeadCode == 'CSH') {
                var isexist = false;
                angular.forEach($scope.Settlement.SettlementDetails, function (item, index) {
                    if (item.RevenueHeadCode == $scope.SettlementDetailSelect.RevenueHeadCode) {
                        isexist = true;
                    }
                });

                if (isexist) {
                    parent.posFailureMessage("Cash Payment Mode already selected.");
                    scrollPageOnTop();
                    return;
                }
            }
            if ($scope.SettlementDetailSelect.RevenueHeadCode == 'CRD') {
                if (!$scope.SettlementDetailSelect.CreditCardNetworkId) {
                    parent.posFailureMessage("Please select CreditCard Type.");
                    scrollPageOnTop();
                    return;
                }
                var isexist = false;
                angular.forEach($scope.Settlement.SettlementDetails, function (item, index) {
                    if ((item.RevenueHeadCode == $scope.SettlementDetailSelect.RevenueHeadCode) && (item.CreditCardNumber == $scope.SettlementDetailSelect.CreditCardNumber)) {
                        isexist = true;
                    }
                });

                if (isexist) {
                    parent.posFailureMessage("Same Credit Card number already exist.");
                    scrollPageOnTop();
                    return;
                }
            }

            angular.forEach($scope.Settlement.SettlementDetails, function (item) {
                if (max < item.SNo) {
                    max = item.SNo;
                }
            });
            max = max + 1;
            $scope.SettlementDetailSelect.SNo = max;
            $scope.SettlementDetailSelect.RevenueHeadName = $scope.GetRevenueName($scope.SettlementDetailSelect.RevenueHeadCode);
            $scope.Settlement.SettlementDetails.push($scope.SettlementDetailSelect);
        }

        $scope.Total();

        if ($scope.Settlement.BalanceAmount < 0) {

            parent.posFailureMessage("You can't settle negative amount.");
           
            $scope.Settlement.SettlementDetails.splice($scope.Settlement.SettlementDetails.length - 1, 1);
            $scope.Total();
            $scope.SettlementDetailSelect.SNo = 0;
            $scope.SettlementDetailSelect.Amount = $scope.Settlement.BalanceAmount;
            return;
        }
        else {
            $scope.Reset();
        }

    };
    $scope.GetSettlementDetail = function (sno, code) {

        if ($scope.Settlement.SettlementDetails.length > 0) {
            //$scope.Settlement.SettlementAmount = 0;
            angular.forEach($scope.Settlement.SettlementDetails, function (item) {

                if (sno == item.SNo) {
                    $scope.SettlementDetailSelect = {

                        SNo: item.SNo,
                        SettlementId: item.SettlementId,
                        RevenueHeadId: item.RevenueHeadId,
                        RevenueHeadName: item.RevenueHeadName,
                        RevenueHeadCode: item.RevenueHeadCode,
                        Amount: item.Amount,
                        Remark: item.Remark,
                        TipAmount: item.TipAmount,
                        CreditCardNumber: item.CreditCardNumber,
                        CreditCardNetworkId: item.CreditCardNetworkId,
                        CreditCardNetworkName: item.CreditCardNetworkName,
                        GuestName: item.GuestName,
                        CorporateId: item.CorporateId,
                        CorporateCode: item.CorporateCode,
                        CorporateName: item.CorporateName,
                        ChequeNo: item.ChequeNo,
                        BankName: item.BankName,
                        BankBranch: item.BankBranch,
                        CheckINGuestId: item.CheckINGuestId,
                        CheckINGuestName: item.CheckINGuestName,
                        CheckINGuestRoom: item.CheckINGuestRoom,
                        CheckINGuestMobile: item.CheckINGuestMobile,
                        AuthorizedBy: item.AuthorizedBy,
                        CouponType: item.CouponType,
                        CouponId: item.CouponId,
                        NCDepartmentId: item.NCDepartmentId,
                        NCDepartmentName: item.NCDepartmentName,
                        CurrencyId: item.CurrencyId,
                        CurrencyCode: item.CurrencyCode,
                        CurrencyName: item.CurrencyName,
                        ExchangeRate: item.ExchangeRate,
                        CurrencyAmount: item.CurrencyAmount,
                        CurrencyPaidOut: item.CurrencyPaidOut,

                    };
                }
            });


        }
    };
    $scope.Delete = function (sno) {
        var index = 0;
        angular.forEach($scope.Settlement.SettlementDetails, function (item, key) {

            if (sno == item.SNo) {
                index = key;
            }
        });

        $scope.Settlement.SettlementDetails.splice(index, 1);
        $scope.Total();
    };
    $scope.Reset = function () {
        var revenueHeadCode = $scope.SettlementDetailSelect.RevenueHeadCode;
        $scope.SettlementDetailSelect = {};
        $scope.SettlementDetailSelect.SNo = 0;
        $scope.SettlementDetailSelect.RevenueHeadCode = revenueHeadCode;
    };

    $scope.CRD = {};
    $scope.GetCRD = function (sno) {

        angular.forEach($scope.Settlement.SettlementDetails, function (item) {
            if (sno == item.SNo) {

                $scope.CRD.SNo = item.SNo;
                $scope.CRD.SettlementId = item.SettlementId;
                $scope.CRD.RevenueHeadId = item.RevenueHeadId;
                $scope.CRD.RevenueHeadName = item.RevenueHeadName;
                $scope.CRD.RevenueHeadCode = item.RevenueHeadCode;
                $scope.CRD.Amount = item.Amount;
                $scope.CRD.Remark = item.Remark;
                $scope.CRD.TipAmount = item.TipAmount;
                $scope.CRD.CreditCardNumber = item.CreditCardNumber;
                $scope.CRD.CreditCardNetworkId = item.CreditCardNetworkId;
                $scope.CRD.CreditCardNetworkName = item.CreditCardNetworkName;
                $scope.CRD.GuestName = item.GuestName;
                $scope.CRD.CorporateId = item.CorporateId;
                $scope.CRD.CorporateCode = item.CorporateCode;
                $scope.CRD.CorporateName = item.CorporateName;
                $scope.CRD.ChequeNo = item.ChequeNo;
                $scope.CRD.BankName = item.BankName;
                $scope.CRD.BankBranch = item.BankBranch;
                $scope.CRD.CheckINGuestId = item.CheckINGuestId;
                $scope.CRD.CheckINGuestName = item.CheckINGuestName;
                $scope.CRD.CheckINGuestRoom = item.CheckINGuestRoom;
                $scope.CRD.CheckINGuestMobile = item.CheckINGuestMobile;
                $scope.CRD.AuthorizedBy = item.AuthorizedBy;
                $scope.CRD.CouponType = item.CouponType;
                $scope.CRD.CouponId = item.CouponId;
                $scope.CRD.NCDepartmentId = item.NCDepartmentId;
                $scope.CRD.NCDepartmentName = item.NCDepartmentName;
                $scope.CRD.CurrencyId = item.CurrencyId;
                $scope.CRD.CurrencyCode = item.CurrencyCode;
                $scope.CRD.CurrencyName = item.CurrencyName;
                $scope.CRD.ExchangeRate = item.ExchangeRate;
                $scope.CRD.CurrencyAmount = item.CurrencyAmount;
                $scope.CRD.CurrencyPaidOut = item.CurrencyPaidOut;

            }
        });
    };
    $scope.CRDConfirm = function () {


    }
    $scope.SetRevenueHead = function (mode) {
        
        var code = mode.RevenueHeadCode;
        if (code == 'CSH') {
            var isexist = false;
            angular.forEach($scope.Settlement.SettlementDetails, function (item, index) {
                if (item.RevenueHeadCode == code) {
                    //$scope.GetSettlementDetail(index + 1, 'CSH');   
                    isexist = true;
                }
            });
            if (isexist) {
                parent.posFailureMessage("Cash Payment Mode already selected.");
                scrollPageOnTop();
                return;
            }
        }

        if ((code == 'CMP') || (code == 'VOID') || (code == 'BOH') || (code == 'NC')) {
            $scope.Settlement.SettlementDetails = [];
            $scope.Total();
        }
        $scope.SettlementDetailSelect = {};
        $scope.SettlementDetailSelect.RevenueHeadCode = code;
        $scope.SettlementDetailSelect.RevenueHeadName = mode.RevenueHeadName;
        $scope.SettlementDetailSelect.Amount = $scope.Settlement.BalanceAmount;
        $scope.SettlementDetailSelect.SNo = 0;
        $scope.SettlementDetailSelect.GuestName = $scope.Settlement.GuestName;
        if (code == 'GUST') {
            $scope.GetOccupiedRooms();
        }
        else if (code == 'COM') {
            $scope.GetCorporate();
        }
        else if (code == 'LPT') {
            if ($scope.Settlement && $scope.CheckINGuest.GuestId) {
                $scope.lpService.getLoyaltyBalance($scope.CheckINGuest.GuestId);
                $scope.lpService.getMinimumRedeemPoints($scope.CheckINGuest.GuestId);
                $scope.lpService.calculateBillPoints($scope.Settlement.BillId,1);
                $scope.lpService.currentBillPoints($scope.Settlement.BillId,1);
            }
        }
    };
    $scope.GetRevenueName = function (code) {
        var revenueHeadCode = '';
        angular.forEach($scope.SettlementModeDetails, function (item) {

            if (code == item.RevenueHeadCode) {
                revenueHeadCode = item.RevenueHeadName;
            }
        });
        return revenueHeadCode;
    };

    $scope.myCorporateConfig = {
        valueField: "Id",
        labelField: "Name",
        searchField: ["Name"],
        sortField: "Name",
        create: true,
        maxItems: 1
    };

    $scope.Corporates = [];
    $scope.GetCorporate = function () {
        
        var promiseGet = service.getCorporate($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.Corporates = data.Collection;
        },
            function (error) {
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });

        $scope.GetOccupiedRooms();
        //$scope.GetCurrency();
    };

    $scope.CheckINGuests = [];
    //$scope.GetCheckINGuest = function (roomId) {
    //    
    //    $scope.CheckINGuests = [];
    //    angular.forEach($scope.OccupiedRooms, function (item) {
    //        if (roomId == item.RoomMasterId) {
    //            //$scope.CheckINGuests = angular.copy(item.CheckINGuests);

    //            var checkINGuest

    //        }
    //    });
    //};

    //$scope.Currencys = [];
    //$scope.GetCurrency = function () {

    //    var promiseGet = service.getCurrency();
    //    promiseGet.then(function (data) {
    //        $scope.Currencys = data.Collection;
    //    },
    //        function (error) {
    //            parent.posFailureMessage(error.Message);
    //            scrollPageOnTop();
    //        });
    //};

    $scope.GetCheckINGuestDetail = function (checkINGuestId) {

        $scope.CheckINGuest = {};
        angular.forEach($scope.CheckINGuests, function (item) {
            if (checkINGuestId == item.Id) {

                $scope.SettlementDetailSelect.GuestName = item.Name;

                $scope.SettlementDetailSelect.CheckINGuestId = item.Id;
                $scope.SettlementDetailSelect.CheckINGuestCheckINNo = item.CheckINNo;
                $scope.SettlementDetailSelect.CheckINGuestFolio = item.FolioNo;
                $scope.SettlementDetailSelect.CheckINGuestName = item.Name;
                $scope.SettlementDetailSelect.CheckINGuestRoom = item.CheckINGuestRoom.RoomNumber;

                $scope.SettlementDetailSelect.BillingInstructionName = item.BillingInstructionName;
                $scope.SettlementDetailSelect.SpecialInstructions = item.SpecialInstructions;

            }
        });
    };
    $scope.FOBillCancel = function (checkINGuest) {
        $scope.CancelCheckINGuest = checkINGuest;
        $.fancybox({
            'href': '#cancelfobill',
            'modal': true,
            'afterShow': function () {
                $("#fancyconfirm_cancel")
                    .click(function () {
                        $.fancybox.close();
                    });
                $("#fancyConfirm_ok")
                    .click(function () {
                        ret = true;
                        $scope.model.ChargePostToId = $scope.ChargePostToId;
                        $scope.model.CheckINGuestId = checkINGuest.Id;
                        $scope.model.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
                        $scope.model.ModifiedBy = $scope.ModifiedBy;
                        $scope.model.PropertyID = $scope.PropertyID;
                        service.billCancel($scope.model)
                            .then(function (d) {
                                msg(d.Message, d.Status);
                                $scope.reset();
                                $scope.changeChargePostToId();
                                $scope.CheckINGuest = {};
                            }, function (error) {
                                msg(error.Message);
                            });

                        //parent.successMessage("Bill Cancelled Successfully.");
                        $.fancybox.close();
                    });
            }
        });
    };
    $scope.FOBillCancelCall = function (checkINGuest) {

        if (!$scope.model.CancellationReasonId) {
            parent.posFailureMessage("Please select reason.");
            return;
        }
        $scope.model.ChargePostToId = $scope.ChargePostToId;
        $scope.model.CheckINGuestId = checkINGuest.Id;
        $scope.model.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
        $scope.model.ModifiedBy = $scope.ModifiedBy;
        $scope.model.PropertyID = $scope.PropertyID;
        service.billCancel($scope.model)
            .then(function (d) {
                msg(d.Message, d.Status);
                $scope.reset();
                $scope.changeChargePostToId();
                $scope.CheckINGuest = {};
                $scope.SelectedFP = {};

            }, function (error) {
                msg(error.Message);
            }).finally(function () {
                parent.$.fancybox.close();
            });

    };
    
    //End Settlement

    //Room Link Start
    $scope.CheckINGuestRoomLink = {
        CheckINGuestRoomId: '',
        CheckINGuestRoomToLinkId: '',
        CheckINGuestRoomToLinks: [],
        ModifiedBy: $scope.ModifiedBy,
        PropertyID: $scope.PropertyID,
    };

    $scope.GetRoomLink = function () {

        $scope.RoomLinkAll = [];
        var selectedRoomId = $scope.CheckINGuest.RoomMasterId;
        angular.forEach($scope.OccupiedRooms, function (room) {
            if (selectedRoomId != room.RoomMasterId) {
                room.IsSelected = false;
                $scope.RoomLinkAll.push(room);
            }
        });

        //from database
        var promiseGet = service.getByCheckINGuestRoomId($scope.PropertyID, $scope.CheckINGuest.CheckINGuestRoomId);
        promiseGet.then(function (data) {

            var links = data.Data.CheckINGuestRoomToLinks;
            angular.forEach(links, function (link) {

                angular.forEach($scope.RoomLinkAll, function (room) {
                    if (room.RoomMasterId == link.RoomMasterId) {
                        room.IsSelected = true;
                        //$scope.SelectedRoomLinks.push(room);
                    }
                });
            });

        },
            function (error) {

                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });

    };
    $scope.SetRoomLink = function (roomid) {

        var notAllow = false;
        angular.forEach($scope.RoomLinkAll, function (room) {
            if (roomid == room.RoomMasterId) {
                if (room.IsFOBilled) {
                    notAllow = true;
                }
                //angular.forEach(room.CheckINGuests, function (checkINGuest) {
                //    if (checkINGuest.IsFOBilled) {
                //        notAllow = true;
                //    }
                //});
            }
        });

        if (!notAllow) {
            angular.forEach($scope.RoomLinkAll, function (room) {
                if (roomid == room.RoomMasterId) {
                    room.IsSelected = true;
                }
            });
        }
        else {
            parent.popErrorMessage("Bill Genereted, Room Link not allowed.");
        }
    };
    $scope.ResetRoomLink = function () {
        angular.forEach($scope.RoomLinkAll, function (room) {
            room.IsSelected = false;
        });

        $scope.GetRoomLink();
    };
    $scope.DeleteRoomLink = function (roomid) {
        angular.forEach($scope.RoomLinkAll, function (room, index) {
            if (roomid == room.RoomMasterId) {
                room.IsSelected = false;
                room.IsLinkedFrom = false;
                room.IsLinkedTo = false
            }
        });
    };
    $scope.SaveRoomLink = function () {


        $scope.CheckINGuestRoomLink = {
            CheckINGuestRoomId: $scope.CheckINGuest.CheckINGuestRoomId,
            CheckINGuestRoomToLinkId: '',
            CheckINGuestRoomToLinks: [],
            ModifiedBy: $scope.ModifiedBy,
            PropertyID: $scope.PropertyID,
        };

        angular.forEach($scope.RoomLinkAll, function (item) {
            if (item.IsSelected) {
                var checkINGuestRoomId = item.CheckINGuestRoomId;
                $scope.CheckINGuestRoomLink.CheckINGuestRoomToLinks.push({
                    Id: checkINGuestRoomId,
                });
            }
        });

        //if($scope.CheckINGuestRoomLink.CheckINGuestRoomToLinks.length==0)
        //{
        //    parent.posFailureMessage("Please Select Room to Link.");
        //    return;
        //}

        var promiseGet = service.saveRoomLink($scope.CheckINGuestRoomLink);
        promiseGet.then(function (data) {
            $scope.GetOccupiedRooms();
            $('#dlinkModal').modal('hide');
            parent.successMessage("Room Link/D-Link Done.");
            $scope.Model.CheckINGuestId = '';

        },
            function (error) {

                $('#dlinkModal').modal('hide');
                parent.posFailureMessage(error.Message);
                scrollPageOnTop();
            });

    };
    //End Room Link

    $scope.guestEdit = function (checkInGuest, dontCall) {
        
        $scope.CheckINGuestEdit = {};
        service.getCheckInGuestById(checkInGuest.Id)
            .then(function (data) {

                
                $scope.CheckINGuestEdit = data.Data;

                ////// checkin guest
                //$scope.CheckINGuestEdit.CheckINDate = checkInGuest.CheckINDate;
                //$scope.CheckINGuestEdit.CheckINTimeForDisplay = checkInGuest.CheckINTimeForDisplay;
                //$scope.CheckINGuestEdit.CheckOUTDate = checkInGuest.CheckOUTDate;
                //$scope.CheckINGuestEdit.CheckOUTTimeForDisplay = checkInGuest.CheckOUTTimeForDisplay;
                //$scope.CheckINGuestEdit.PaxCount = checkInGuest.PaxCount;
                //$scope.CheckINGuestEdit.BookerName = checkInGuest.BookerName;
                //$scope.CheckINGuestEdit.CorporateName = checkInGuest.CorporateName;
                //$scope.CheckINGuestEdit.IsCorporateGuest = checkInGuest.CorporateId && checkInGuest.CorporateId.length > 1;
                //$scope.CheckINGuestEdit.MealPlanId = $scope.CheckINGuestEdit.MealPlanId ? $scope.CheckINGuestEdit.MealPlanId.toString() : '';
                //$scope.CheckINGuestEdit.BillingInstructionId = checkInGuest.BillingInstructionId ? checkInGuest.BillingInstructionId.toString() : '';
                //$scope.CheckINGuestEdit.BillingInstructionName = checkInGuest.BillingInstructionName;
                //$scope.CheckINGuestEdit.BusinessSourceId = checkInGuest.BusinessSourceId ? checkInGuest.BusinessSourceId.toString() : '';
                //$scope.CheckINGuestEdit.BookingTypeId = checkInGuest.BookingTypeId ? checkInGuest.BookingTypeId.toString() : '';
                //$scope.CheckINGuestEdit.CurrencyMasterId = checkInGuest.CurrencyMasterId ? checkInGuest.CurrencyMasterId.toString() : '';
                //$scope.CheckINGuestEdit.CurrencyMasterRate = checkInGuest.CurrencyMasterRate;
                //$scope.CheckINGuestEdit.RevenueHeadId = checkInGuest.RevenueHeadId ? checkInGuest.RevenueHeadId.toString() : '';
                //$scope.CheckINGuestEdit.SpecialInstruction = checkInGuest.SpecialInstruction;

                // guest 
                $scope.CheckINGuestEdit.SalutationId = $scope.CheckINGuestEdit.SalutationId.toString();
                $scope.CheckINGuestEdit.CountryMasterId = $scope.CheckINGuestEdit.CountryMasterId.toString();
                $scope.CheckINGuestEdit.StateId = $scope.CheckINGuestEdit.StateId.toString();
                $scope.changeGuestCountry($scope.CheckINGuestEdit);
                if($scope.CheckINGuestEdit.GuestClassId)
                {
                    $scope.CheckINGuestEdit.GuestClassId = $scope.CheckINGuestEdit.GuestClassId.toString();
                }
                
                $scope.getLocalStateList($scope.CheckINGuestEdit);
                $scope.ImageUrl = $scope.CheckINGuestEdit.ImageUrl;

                angular.extend($scope.Customer,{},$scope.CheckINGuestEdit);
                
                $scope.CheckINGuestEdit.CheckINGuestWorkPermit = !$scope.CheckINGuestEdit.CheckINGuestWorkPermits || $scope.CheckINGuestEdit.CheckINGuestWorkPermits.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestWorkPermits[0];
                if ($scope.CheckINGuestEdit.CheckINGuestWorkPermit && $scope.CheckINGuestEdit.CheckINGuestWorkPermit.CountryId) {
                    $scope.CheckINGuestEdit.CheckINGuestWorkPermit.CountryId = $scope.CheckINGuestEdit.CheckINGuestWorkPermit.CountryId.toString();
                    $scope.changeWorkCountry($scope.CheckINGuestEdit.CheckINGuestWorkPermit);
                    $scope.CheckINGuestEdit.CheckINGuestWorkPermit.StateId = !$scope.CheckINGuestEdit.CheckINGuestWorkPermit || !$scope.CheckINGuestEdit.CheckINGuestWorkPermit.StateId ? '' : $scope.CheckINGuestEdit.CheckINGuestWorkPermit.StateId.toString();
                }

                $scope.CheckINGuestEdit.checkINGuestVehicle = !$scope.CheckINGuestEdit.CheckINGuestVehicles || $scope.CheckINGuestEdit.CheckINGuestVehicles.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestVehicles[0];
                $scope.CheckINGuestEdit.NewsPaperId = !$scope.CheckINGuestEdit.NewsPaperId ? '' : $scope.CheckINGuestEdit.NewsPaperId.toString();

                $scope.CheckINGuestEdit.CheckINGuestLocalContact = !$scope.CheckINGuestEdit.CheckINGuestLocalContacts || $scope.CheckINGuestEdit.CheckINGuestLocalContacts.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestLocalContacts[0];
                if ($scope.CheckINGuestEdit.CheckINGuestLocalContact && $scope.CheckINGuestEdit.CheckINGuestLocalContact.StateId)
                    $scope.CheckINGuestEdit.CheckINGuestLocalContact.StateId = $scope.CheckINGuestEdit.CheckINGuestLocalContact.StateId.toString();

                $scope.CheckINGuestEdit.CheckINGuestVisitDetail = !$scope.CheckINGuestEdit.CheckINGuestVisitDetails || $scope.CheckINGuestEdit.CheckINGuestVisitDetails.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestVisitDetails[0];
                if ($scope.CheckINGuestEdit.CheckINGuestVisitDetail && $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalCountryId) {
                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalCountryId = $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalCountryId.toString();
                    $scope.changeArrivingCountry($scope.CheckINGuestEdit.CheckINGuestVisitDetail);
                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalStateId = !$scope.CheckINGuestEdit.CheckINGuestVisitDetail || !$scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalStateId ? '' : $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalStateId.toString();

                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToCountryId = !$scope.CheckINGuestEdit.CheckINGuestVisitDetail || !$scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToCountryId ? '' : $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToCountryId.toString();
                    $scope.changeProceedingCountry($scope.CheckINGuestEdit.CheckINGuestVisitDetail);
                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToStateId = !$scope.CheckINGuestEdit.CheckINGuestVisitDetail || !$scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToStateId ? '' : $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToStateId.toString();
                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalViaId = !$scope.CheckINGuestEdit.CheckINGuestVisitDetail || !$scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalViaId ? '' : $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ArrivalViaId.toString();
                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToViaId = !$scope.CheckINGuestEdit.CheckINGuestVisitDetail || !$scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToViaId ? '' : $scope.CheckINGuestEdit.CheckINGuestVisitDetail.ProceedToViaId.toString();
                    $scope.CheckINGuestEdit.CheckINGuestVisitDetail.PurposeofVisitId = !$scope.CheckINGuestEdit.CheckINGuestVisitDetail || !$scope.CheckINGuestEdit.CheckINGuestVisitDetail.PurposeofVisitId ? '' : $scope.CheckINGuestEdit.CheckINGuestVisitDetail.PurposeofVisitId.toString();
                }

                $scope.CheckINGuestEdit.CheckINGuestExtraCharge = !$scope.CheckINGuestEdit.CheckINGuestExtraCharges || $scope.CheckINGuestEdit.CheckINGuestExtraCharges.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestExtraCharges[0];
                if ($scope.CheckINGuestEdit.CheckINGuestExtraCharge && $scope.CheckINGuestEdit.CheckINGuestExtraCharge.RevenueHeadId)
                    $scope.CheckINGuestEdit.CheckINGuestExtraCharge.RevenueHeadId = $scope.CheckINGuestEdit.CheckINGuestExtraCharge.RevenueHeadId.toString();

                $scope.CheckINGuestEdit.CheckINGuestDiplomatDetail = !$scope.CheckINGuestEdit.CheckINGuestDiplomatDetails || $scope.CheckINGuestEdit.CheckINGuestDiplomatDetails.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestDiplomatDetails[0];
                if ($scope.CheckINGuestEdit.CheckINGuestDiplomatDetail && $scope.CheckINGuestEdit.CheckINGuestDiplomatDetail.CountryId)
                    $scope.CheckINGuestEdit.CheckINGuestDiplomatDetail.CountryId = $scope.CheckINGuestEdit.CheckINGuestDiplomatDetail.CountryId.toString();

                $scope.CheckINGuestEdit.CheckINGuestPickupDrop = !$scope.CheckINGuestEdit.CheckINGuestPickupDrops || $scope.CheckINGuestEdit.CheckINGuestPickupDrops.length < 1 ? {} : $scope.CheckINGuestEdit.CheckINGuestPickupDrops[0];
                if ($scope.CheckINGuestEdit.CheckINGuestPickupDrop && $scope.CheckINGuestEdit.CheckINGuestPickupDrop.PickupDropTypeId) {
                    $scope.CheckINGuestEdit.CheckINGuestPickupDrop.PickupDropTypeId = $scope.CheckINGuestEdit.CheckINGuestPickupDrop.PickupDropTypeId.toString();
                    $scope.CheckINGuestEdit.CheckINGuestPickupDrop.LocationTypeId = !$scope.CheckINGuestEdit.CheckINGuestPickupDrop || !$scope.CheckINGuestEdit.CheckINGuestPickupDrop.LocationTypeId ? '' : $scope.CheckINGuestEdit.CheckINGuestPickupDrop.LocationTypeId.toString();
                }

                $('#checkINGuestBox').modal('hide');

            }, function (err) {
                msg(err.Message);
            });
        if (!dontCall) $('#myModal1').modal('show');
    };
    $scope.getLocalStateList = function (guest) {

        service.getStateList(95)
            .then(function (result) {
                guest.LocalStateList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    //$scope.getPickupDropTypes = function () {
    //    service.getPickupDropTypes($scope.PropertyID)
    //        .then(function (result) {
    //            $scope.PickupDropTypes = result.Collection;
    //        }, function (err) {
    //            msg(err.Message);
    //        });

    //};
    //$scope.getPickupDropTypes();
    //$scope.getLocationTypes = function () {
    //    service.getLocationTypes($scope.PropertyID)
    //        .then(function (result) {
    //            $scope.LocationTypes = result.Collection;
    //        }, function (err) {
    //            msg(err.Message);
    //        });

    //};
    //$scope.getLocationTypes();

    //$scope.getSetup = function () {
    //    service.getSetup($scope.PropertyID)
    //        .then(function (data) {
    //            $scope.setupData = data.Data;
    //        }, function (err) {
    //            msg(err.Message);
    //        });

    //};
    //$scope.getSetup();

    //Navneet2.0
    Setup();
    function Setup() {
        $scope.IsProgress = true;
        $scope.ProgressStart();
        var promiseGet1 = service.GetConstantByPropertyId($scope.PropertyID);
        promiseGet1.then(function (data, status) {
            $scope.PropertyConstant = data.Data;

            var promiseGet = service.GetSetup($scope.PropertyID);
            promiseGet.then(function (data, status) {
                
                $scope.SettlementModeDetailsAll = data.Data[0];
                $scope.SettlementModeDetails = $scope.SettlementModeDetailsAll.filter(x => x.RevenueForId != '6');

                $scope.ReservationModes =data.Data[1];
                $scope.BillingInstructions =data.Data[2];
                $scope.MarketSegments =data.Data[3];
                $scope.NewsPapers =data.Data[4];
                $scope.BusinessSources =data.Data[5];
                $scope.TaxStructures =data.Data[6];
                $scope.Designations =data.Data[7];
                $scope.Corporates =data.Data[8];
                $scope.Bookers =data.Data[9];
                $scope.DocumentTypes =data.Data[10];
                $scope.DefaultSettings =data.Data[11];
                $scope.DefaultSetting = {

                    CurrencyConversionRate: data.Data[11][0].CurrencyConversionRate,
                    CurrencyConversionMargin: data.Data[11][0].CurrencyConversionMargin,
                    CurrencydecimalPlaces: data.Data[11][0].CurrencydecimalPlaces,
                    DateFormat: data.Data[11][0].DateFormat,
                    TimeZoneLocation: data.Data[11][0].TimeZoneLocation,
                    TimeFormat: data.Data[11][0].TimeFormat,
                    ChildAge: data.Data[11][0].ChildAge,
                    InfantAge: data.Data[11][0].InfantAge,
                    DefaultNationality: data.Data[11][0].DefaultNationality,
                    GlobalLanguage: data.Data[11][0].GlobalLanguage,
                    Software_Started_Date: data.Data[11][0].Software_Started_Date,
                    Financial_FromYear: data.Data[11][0].Financial_FromYear,
                    Financial_ToYear: data.Data[11][0].Financial_ToYear,
                    CheckOUTTypeId: data.Data[11][0].CheckOUTTypeId,
                    EarlyArrival: data.Data[11][0].EarlyArrival,
                    LateDeparture: data.Data[11][0].LateDeparture,
                    CountryMasterId: data.Data[11][0].CountryMasterId,
                    MarketSegmentId: data.Data[11][0].MarketSegmentId,
                    RateMasterId: data.Data[11][0].RateMasterId,
                    RoomTypeId: data.Data[11][0].RoomTypeId,
                    BusinessSourceId: data.Data[11][0].BusinessSourceId,
                    CurrencyMasterId: data.Data[11][0].CurrencyMasterId,
                    MealPlanId: data.Data[11][0].MealPlanId,
                    RevenueHeadId: data.Data[11][0].RevenueHeadId,
                    RevenueHeadCode: data.Data[11][0].RevenueHeadCode,
                    SalutationId: data.Data[11][0].SalutationId.toString(),
                    StateMasterId: data.Data[11][0].StateMasterId,
                    LateDepartureTime: data.Data[11][0].LateDepartureTime,
                };
                $scope.Amenitys =data.Data[12];
                $scope.RevenueHeads =data.Data[13];
                angular.forEach($scope.RevenueHeads, function (item) {
                    item.RevenueForId = item.RevenueForId.toString();
                })
                $scope.AdvanceRevenueHeads = $scope.RevenueHeads.filter(x=>x.RevenueForId == '6');  //Navneet Do not Confuse with Reservation Advance
                $scope.RateMasters =data.Data[14];
                $scope.RateMasterList = $scope.RateMasters;

                $scope.GuestStatuss =data.Data[15];
                $scope.OccupationMasters =data.Data[16];
                $scope.BookerTypes =data.Data[17];
                $scope.CorporateTypes =data.Data[18];
                $scope.Currencys =data.Data[19];
                $scope.Salutations =data.Data[20];
                $scope.Countrys =data.Data[21];
                $scope.GuestClasss =data.Data[22];
                $scope.MealPlans =data.Data[23];
                //$scope.CreditCardNetworks =data.Data[24];
                $scope.NetworkList =data.Data[24];
                $scope.RoomTypes =data.Data[25];
                $scope.OccupancyRates =data.Data[26];
                $scope.OccupancyMealPlanRates =data.Data[27];
                $scope.LinkTaxStructures =data.Data[28];

                $scope.BookingStatuss =$scope.PropertyConstant.BookingStatuss;
                $scope.DiscountTypes =$scope.PropertyConstant.DiscountTypes;
                $scope.LocationTypes =$scope.PropertyConstant.LocationTypes;    //
                $scope.CorporateCategorys =$scope.PropertyConstant.CorporateCategorys;

                $scope.BookingTypes     =$scope.PropertyConstant.BookingTypes;
                $scope.PaxTypes         =$scope.PropertyConstant.PaxTypes;
                $scope.TravelTypes      =$scope.PropertyConstant.TravelTypes;
                $scope.VisitTypes       =$scope.PropertyConstant.VisitTypes;
                $scope.PickupDropTypes  =$scope.PropertyConstant.PickupDropTypes;   //

                $scope.getRevenueHeadList();

                $scope.ProgressEnd();
              
                $rootScope.$broadcast("CallPostChargeOpen", {});
            },
                function (error, status) {
                    parent.failureMessage(error.Message); scrollPageOnTop();
                    $scope.ProgressEnd();
                });
        });
    }

    $scope.$on("CallPostCharge", function (event, obj) {
        
        $scope.IsSeeMessage=false;
        $scope.IsGroupSelected=false;
        $scope.IsGuestSelected=true;
        $scope.SplitRevenuePosts = [];
        $scope.OriginalSplitRevenuePosts = [];
        $scope.CheckINGuestRevenuePosts = [];
        $scope.SelectedTransactions=[];

        $scope.SelectedRoom = {};
        $scope.model.LinkTaxStructures = [];

        $scope.CheckINGuests = angular.copy(obj.CurrentCheckINGuests);
        angular.forEach($scope.CheckINGuests,function(item){
            item.IsSelected = false;
        });

        $scope.SelectedRoom = $scope.CheckINGuests[0].CheckINGuestRoom;
       
        $rootScope.$broadcast("CallOpenPostCharge", {});
        $scope.openPostingDialog();

    });


    $scope.IsPostingDisabled = function()
    {
        
        
        //CheckINGuest.IsRoomOwner==false ||  FOBills.length>0 || (!CheckINGuest.Id && (model.ChargePostToId!=7))
        try
        {
            if($scope.ChargePostToId)
            {
                if($scope.ChargePostToId==1)
                {
                    if(!$scope.CheckINGuest)
                    {
                        return false;
                    }
                    if($scope.CheckINGuest.IsFOBilled)
                    {
                        return true;
                    }
                    if($scope.CheckINGuest.IsRoomOwner)
                    {
                        return !$scope.CheckINGuest.IsRoomOwner;
                    }
                }
                else if($scope.ChargePostToId==5)
                {
                    if(!$scope.CheckINGuest)
                    {
                        return false;
                    }
                    if($scope.CheckINGuest.Id)
                    {
                        return false;
                    }
                }
                else if($scope.ChargePostToId==7)
                {
                    return false;
                }
                else if($scope.ChargePostToId==8)
                {
                    return false;
                }
                else if($scope.ChargePostToId==999)
                {
                    if(!$scope.CheckINGuest)
                    {
                        return false;
                    }
                    if($scope.CheckINGuest.Id)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        catch(ex)
        {
            return true;
        }
    }



    $scope.validateEmail = function (event) {

        if (event.currentTarget.value == "") {
            $(event.currentTarget).removeClass("danger");
            $(event.currentTarget).addClass("success");
            return false;
        }
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (expr.test((event.currentTarget.value)) == false) {
            event.currentTarget.value = "";
            $(event.currentTarget).removeClass("success");
            $(event.currentTarget).addClass("danger");
            return false;
        } else {
            $(event.currentTarget).addClass("success");
            return true;
        }
    };

    $scope.changeGuestCountry = function (guest) {
        if (!guest || !guest.CountryMasterId) return;
        service.getStateList(guest.CountryMasterId)
            .then(function (result) {

                guest.StateList = result.Collection;
                var tcountry = $scope.Countrys.find(x => x.Id.toString() === guest.CountryMasterId);
                guest.Nationality = tcountry ? tcountry.Nationality : null;

            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.changeWorkCountry = function (guest) {
        if (!guest.CountryId) return;
        service.getStateList(guest.CountryId)
            .then(function (result) {
                guest.StateList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.changeLocalContactCountry = function (guest) {
        if (!guest || !guest.CountryMasterId) return;
        service.getStateList(guest.CountryMasterId)
            .then(function (result) {

                guest.StateList = result.Collection;
                var tcountry = $scope.Countrys.find(x => x.Id.toString() === guest.CountryMasterId);
                guest.Nationality = tcountry ? tcountry.Nationality : null;

            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.changeArrivingCountry = function (guest) {
        if (!guest.ArrivalCountryId) return;
        service.getStateList(guest.ArrivalCountryId)
            .then(function (result) {

                guest.ArrivingStateList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.changeProceedingCountry = function (guest) {
        if (!guest.ProceedToCountryId) return;
        service.getStateList(guest.ProceedToCountryId)
            .then(function (result) {

                guest.ProceedToStateList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.getTravelTypeList = function () {

        service.getTravelTypeList()
            .then(function (result) {

                $scope.TravelTypeList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.getTravelTypeList();
    $scope.getVisitTypeList = function () {

        service.getVisitTypeList()
            .then(function (result) {

                $scope.VisitTypeList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.getVisitTypeList();
    Document = function (doc) {
        if (!$scope.EditGuest.GuestDocuments) $scope.EditGuest.GuestDocuments = [];
        $scope.EditGuest.GuestDocuments.push(doc);
    };
    $scope.deleteGuestDocument = function (i) {
        $scope.EditGuest.GuestDocuments.splice(i, 1);
    };
    $scope.getBookingTypeList = function () {
        service.getBookingTypeList($scope.PropertyID)
            .then(function (result) {
                $scope.BookingTypeList = result.Collection;
            }, function (err) {
                msg(err.Message);
            });
    };
    $scope.getBookingTypeList();
    $scope.addDiscount = function (dis, guest) {

        if (!guest.CheckINGuestDiscounts) guest.CheckINGuestDiscounts = [];
        dis.DiscountTypeName = dis.DiscountTypeId == "1" ? "Amount" : "Percentage";
        var rhead = $scope.RevenueHeads.find(x => x.Id === dis.RevenueHeadId);
        dis.RevenueHeadName = rhead == null ? "" : rhead.Name;
        guest.CheckINGuestDiscounts.push(angular.copy(dis));

    };
    $scope.removeDiscount = function (idx) {
        $scope.CheckINGuest.CheckINGuestDiscounts.splice(idx, 1);
    };
    $scope.addDocument = function (doc, guest) {

        if (!guest.GuestDocuments) guest.GuestDocuments = [];
        var rhead = $scope.DocumentTypes.find(x => x.Id === doc.DocumentTypeId);
        doc.DocumentTypeName = rhead == null ? "" : rhead.Name;
        guest.GuestDocuments.push(angular.copy(doc));

    };

    $scope.saveGuestPhoto = function () {
        if (!$scope.CheckINGuestEdit || !$scope.ImageUrl) {
            msg('Please select a guest and photo.');
            return;
        }
        $scope.CheckINGuestEdit.ModifiedBy = $scope.ModifiedBy;
        $scope.CheckINGuestEdit.ImageModel = imageService.getImageModel($scope.ImageUrl, $scope.PropertyID, 'Guest');
        service.saveGuest($scope.CheckINGuestEdit).then(function (s) {
            msg("Guest photo modified successfully.", s.Status);
            $scope.guestEdit($scope.CheckINGuestEdit, true);  
        });
    };
    $scope.saveGuest = function (form, passDocuments) {
        
        if (!$scope[form].$valid) {
            var count = 0;
            $scope[form].$error.required.forEach(function (e) {
                if (e.$name !== 'docForm') count++;
            });
            if (count > 0) {
                $scope.ShowErrorMessageG = true;
                msg('');
                return;
            }
        }

        if (!passDocuments && $scope.DocumentTypes) {
            var requiredDocs = '', expiredDocs = '';
            $scope.DocumentTypes.forEach(function (t) {

                if (t.IsRequired) {
                    var found = !$scope.CheckINGuestEdit.GuestDocuments ? null : $scope.CheckINGuestEdit.GuestDocuments.find(x => x.DocumentTypeId == t.Id);
                    if (!found) requiredDocs += t.Name + ' and ';
                    else if (found.ExpiryDateString < $scope.ModifiedDate) expiredDocs += t.Name + ' and ';
                }
            });
            if (requiredDocs.length > 4 || expiredDocs.length > 4) {
                if (requiredDocs.lastIndexOf('and') > -1) requiredDocs = requiredDocs.substr(0, requiredDocs.lastIndexOf('and'));
                if (expiredDocs.lastIndexOf('and') > -1) expiredDocs = expiredDocs.substr(0, expiredDocs.lastIndexOf('and'));
                var strDelete = DeletePopup("!!WARNING!!<br/><br/>" + (requiredDocs.length > 1 ? requiredDocs + " not attached, " : "") + (expiredDocs.length > 1 ? "<br/>" + expiredDocs + " expired, " : "") + "<br/>Do you want to continue?");
                //var strDelete = DeletePopup(requiredDocs+ " not attached, do you want to continue?");
                var ret;
                $('#myModal1').hide('slow');
                $.fancybox({
                    'modal': true,
                    'content': strDelete,
                    'afterShow': function () {
                        $("#fancyconfirm_cancel")
                            .click(function () {
                                ret = false;
                                $.fancybox.close();
                                $('#myModal1').show('slow');
                                return;
                            });
                        $("#fancyConfirm_ok")
                            .click(function () {

                                ret = true;
                                $.fancybox.close();
                                //$('#myModal1').show('slow');
                                $scope.saveGuest(form, true);
                            });
                    }
                });
                return;
            }
        }
        
        $scope.CheckINGuestEdit.ModifiedBy = $scope.ModifiedBy;
        $scope.CheckINGuestEdit.CheckINGuestWorkPermits = [];
        $scope.CheckINGuestEdit.CheckINGuestWorkPermits.push($scope.CheckINGuestEdit.CheckINGuestWorkPermit);
        $scope.CheckINGuestEdit.CheckINGuestVehicles = [];
        $scope.CheckINGuestEdit.CheckINGuestVehicles.push($scope.CheckINGuestEdit.checkINGuestVehicle);
        $scope.CheckINGuestEdit.CheckINGuestLocalContacts = [];
        if ($scope.CheckINGuestEdit.CheckINGuestLocalContact.Name && $scope.CheckINGuestEdit.CheckINGuestLocalContact.Name.length > 1) $scope.CheckINGuestEdit.CheckINGuestLocalContacts.push($scope.CheckINGuestEdit.CheckINGuestLocalContact);
        $scope.CheckINGuestEdit.CheckINGuestVisitDetails = [];
        $scope.CheckINGuestEdit.CheckINGuestVisitDetails.push($scope.CheckINGuestEdit.CheckINGuestVisitDetail);
        $scope.CheckINGuestEdit.CheckINGuestExtraCharges = [];
        $scope.CheckINGuestEdit.CheckINGuestExtraCharges.push($scope.CheckINGuestEdit.CheckINGuestExtraCharge);
        $scope.CheckINGuestEdit.CheckINGuestDiplomatDetails = [];
        $scope.CheckINGuestEdit.CheckINGuestDiplomatDetails.push($scope.CheckINGuestEdit.CheckINGuestDiplomatDetail);
        $scope.CheckINGuestEdit.CheckINGuestPickupDrops = [];
        if ($scope.CheckINGuestEdit.CheckINGuestPickupDrop.OnTime && !$scope.CheckINGuestEdit.CheckINGuestPickupDrop.OnDate) {
            $('#myModal1').modal('hide');
            msg('Please enter pickup drop date.');
            return;
        }
        if ($scope.CheckINGuestEdit.CheckINGuestPickupDrop.OnDate) $scope.CheckINGuestEdit.CheckINGuestPickupDrop.PickupDropTypeId = 2;
        $scope.CheckINGuestEdit.CheckINGuestPickupDrops.push($scope.CheckINGuestEdit.CheckINGuestPickupDrop);
        $scope.CheckINGuestEdit.NationalityCountryId = $scope.CheckINGuestEdit.CountryMasterId;

        if($scope.Customer) angular.extend($scope.CheckINGuestEdit,{LPCardId: $scope.Customer.LPCardId,LPCardNumber: $scope.Customer.LPCardNumber,LPCardIssueDate: $scope.Customer.LPCardIssueDate,LPOpeningPoints: $scope.Customer.LPOpeningPoints});

        service.saveGuest($scope.CheckINGuestEdit)
        //service.saveCheckInGuest($scope.CheckINGuestEdit)
            .then(function (result) {
                $('#myModal1').modal('hide');
                msg("Guest information modified successfully, Now saving CheckINguest", result.Status);
                //msg("CheckINGuest information modified successfully, Now saving guest", result.Status);
                $scope.CheckINGuestEdit.GuestId=result.Message;
                service.saveCheckInGuest($scope.CheckINGuestEdit)
                //service.saveGuest($scope.CheckINGuestEdit)
                    .then(function (result2) {
                        msg("CheckINGuest information modified successfully.", result2.Status);
                        //msg("Guest information modified successfully.", result2.Status);
                    }, function (e2) {
                        msg(e.Message);
                    }).finally(function () {
                        $scope.GetOccupiedRooms();
                    });
            }, function (e) {
                $('#myModal1').modal('hide');
                msg(e.Message);
            }).finally(function () {
                $scope.GetOccupiedRooms();
            });
    };
    $scope.getGuestHistory = function (guest) {

        service.getGuestHistory($scope.PropertyID, guest.GuestId)
            .then(function (s) {
                guest.GuestHistoryList = s.Data.CheckINGuests;
                guest.TotalRoomRevenue = 0;
                guest.TotalRoomNights = 0;
                guest.GuestHistoryList.forEach(function (c) {
                    guest.TotalRoomRevenue += c.TotalRoomRevenue;
                    guest.TotalRoomNights += dateCompare(c.CheckOUTDate, c.CheckINDate);
                });
                guest.TotalRoomRevenue = decimalValD(guest.TotalRoomRevenue);
            });
    };

    ///////////////////////////
    //$scope.getReasons = function () {
    //    service.getReasons($scope.PropertyID, 1, $scope.ModifiedDate)
    //        .then(function (data, status) {
    //            $scope.ReasonList = data.Collection;
    //        });
    //};
    //$scope.getReasons();
    ///////////////////////////

    //filters for Posting
    $scope.selectedRevenueForPosting = ['1', '3'];
    $scope.filterForPosting = function (revenueHead) {
        return ($scope.selectedRevenueForPosting.indexOf(revenueHead.RevenueForId) !== -1);
    };

    $scope.selectedRevenueForPostingTAX = ['4'];
    $scope.filterForPostingTAX = function (revenueHead) {
        return ($scope.selectedRevenueForPostingTAX.indexOf(revenueHead.RevenueForId) !== -1);
    };

    $scope.getNetworkList = function () {
        var promise = service.getNetworkList($scope.PropertyID);
        promise.then(function (data) {
            $scope.NetworkList = data.Collection;
        });
    };
    $scope.getNetworkList();
    $scope.pickCorporateForCard1 = function (form) {

        //$scope.SettlementDetailSelect.CreditCardNetworkId = '';
        if (!$scope.SettlementDetailSelect.CreditCardNumber) return;
        var network = $scope.NetworkList.find(x => x.Name.toLowerCase() === $scope[form].ccNumber.$ccEagerType.toLowerCase());
        if (!network) return;
        //$scope.SettlementDetailSelect.CreditCardNetworkId = network.Id;
        var ccIcon = $('#ccIcon1');
        ccIcon.removeClass();
        ccIcon.addClass('fa fa-cc-' + network.Name.toLowerCase());
    };


    
    $scope.OpenPOSBill =function(transaction){
        var revenuePostId = transaction.RevenuePostId //SettlementDetailId
        service.getKOTBillIdBySettlementDetailId(revenuePostId)
                    .then(function (data) {
                        var kotBillId = data.Data;
                        service.POSBillPrintingGetByBillId(kotBillId,$scope.PropertyID)
                        .then(function (data) {
                            var img = data.Data.URLs;
                            var reportURL = apiPath+img;
                            window.open(reportURL,'_blank');
                        });
                    });
    }

    $scope.printRegCard = function () {
        if (!$scope.Model.CheckINGuestId) {
            msg('Please select guest.');
            return;
        }
        service.MapReport($scope.PropertyID, 'registration_card')
            .then(function (s) {
                fancyPrintConfirm('Do you want to print again ? ', $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + $scope.Model.CheckINGuestId);
            }, function (e) {
                msg('Error in mapping to print.');
            });
    };
    $scope.printCForm = function () {
        if (!$scope.Model.CheckINGuestId) {
            msg('Please select guest.');
            return;
        }
        service.MapReport($scope.PropertyID, 'c_form')
            .then(function (s) {
                fancyPrintConfirm('Do you want to print again ? ', $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + $scope.Model.CheckINGuestId);
            }, function (e) {
                msg('Error in mapping to print.');
            });
    };
    //$scope.printTransaction = function (t) {
       
    //    var id = '';    
    //    if(t.RevenuePostId)
    //    {
    //        id=t.RevenuePostId;
    //    }
    //    else
    //    {
    //        id = t.Id;
    //    }
    //    service.MapReport($scope.PropertyID, 'voucher')
    //        .then(function (s) {
    //            fancyPrintConfirm('Do you want to print again ? ', $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + id);
    //        }, function (e) {
    //            msg('Error in mapping to print.');
    //        });
    //};

    $scope.printBill = function (transaction) {
        if (!transaction) {
            msg('Please select transaction.');
            return;
        }
        
        var settlementDetailId = transaction.RevenuePostId;

        if(transaction.RevenuePostTypeId=='4' )
        {
            service.getKOTBillIdBySettlementDetailId(settlementDetailId)
                        .then(function (data) {
                            var kotBillId = data.Data;
                            service.POSBillPrintingGetByBillId(kotBillId,$scope.PropertyID)
                            .then(function (data) {
                                var img = data.Data.URLs;
                                var reportURL = apiPath+img;
                                window.open(reportURL,'_blank');
                            });
                        });
        }
        else if(transaction.RevenuePostTypeId=='5' )
        {
            service.GetLaundryBillIdBySettlementDetailId(settlementDetailId)
                       .then(function (data) {
                           var billId = data.Data;

                           service.MapReport($scope.PropertyID, 'laundry_bill')
                            .then(function (s) {
                                fancyPrintConfirm('Do you want to print again ? ', $window, '/Reporter/ReportViewer?id='+s.Data+'&pid=' +billId);
                            }, function (e) {
                                msg('Error in mapping to print.');
                            });
                       });
        }
        else
        {
            var id = ''; 
            if(transaction.RevenuePostId)
            {
                id=transaction.RevenuePostId;
            }
            else
            {
                id = transaction.Id;
            }
            service.MapReport($scope.PropertyID, 'voucher')
                .then(function (s) {
                    fancyPrintConfirm('Do you want to print again ? ', $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + id);
                }, function (e) {
                    msg('Error in mapping to print.');
                });

        }
        
    };




    $scope.getAutoSuggest = function (g) {
        var txt = g.CorporateName;
        $("#CorporateName").autocomplete({
            source: function (request, response) {
                g.CorporateId = "";
                if (!$scope.Corporates || $scope.Corporates.length < 1) {
                    msg('Corporates not available.');
                    return;
                }
                $scope.CorporateListSearched = [];
                angular.forEach($scope.Corporates, function (item) {
                    if (item.Name.toLowerCase().indexOf(request.term.toLowerCase()) > -1) {
                        $scope.CorporateListSearched.push(item);
                    }
                });
                if (!$scope.CorporateListSearched || $scope.CorporateListSearched.length < 1) {
                    msg('Corporates not found.');
                    return;
                }
                response($.map($scope.CorporateListSearched, function (item) {
                    return {
                        label: item.Name + ': ' + item.Code + ': ' + item.City,
                        val: item
                    };
                }));
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {

                        //$scope.CheckINGuestEdit.CorporateId=ui.item.val.Id; 
                        //$scope.CheckINGuestEdit.CorporateName=ui.item.val.Name; 

                        g.CorporateId = ui.item.val.Id;
                        g.CorporateName = ui.item.val.Name;
                    }
                }
            },
            minLength: 1
        });
    };

    //// document center
    $scope.formdata1 = new FormData();
    $scope.addDocument = function (doc) {
        if (!$scope.CheckINGuestEdit) return;
        if (!$scope['docForm'].$valid) {
            $scope.showEmsgs = true;
            msg('');
            return;
        }
        doc.DocumentTypeName = $scope.DocumentTypes.find(x => x.Id == doc.DocumentTypeId).Name;
        if (!$scope.CheckINGuestEdit.GuestDocuments) $scope.CheckINGuestEdit.GuestDocuments = [];
        var newDoc = angular.copy(doc);
        imageService.file_upload($scope.PropertyID + '/guest/' + $scope.CheckINGuestEdit.GuestId + '/', $scope.formdata1)
            .then(function (s) {
                if (s.Message && s.Message.indexOf('rror') > -1) {
                    parent.popErrorMessage(s.Message);
                    return;
                }
                $scope.CheckINGuestEdit.GuestDocuments.push(newDoc);
                $scope.resetGuestDocument();//$scope.doc={};
                var filePaths = s.Collection;
                newDoc.Path = filePaths && filePaths.length > 0 ? filePaths[0].fileNameLarge : '';
            });
        if (!newDoc.ExpiryDateString) newDoc.ExpiryDateString = $scope.ModifiedDate;

    };
    $scope.deleteDocument = function (doc) {
        if (!$scope.CheckINGuestEdit || !doc) return;
        $scope.CheckINGuestEdit.GuestDocuments = $scope.CheckINGuestEdit.GuestDocuments.filter(x => x.Id != doc.Id);
    };
    $scope.resetGuestDocument = function () {
        $scope.doc = {};
        $scope.formdata1 = new FormData();
        document.getElementById("guestDocFile").value = '';
    };

    $scope.PrintProvisionalBill = function (pid) {
        service.MapReport($scope.PropertyID, 'provisional_bill')
            .then(function (s) {
                fancyPrintConfirm('Do you want to print provisional bill ? ', $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid);
            }, function (e) {
                msg('Error in mapping to print.');
            });
    };
    $scope.showHistoryComplaints = function (history) {
        $scope.showComplaints=! $scope.showComplaints;

        service.showHistoryComplaints($scope.PropertyID, history.Id)
            .then(function (s) {
                history.Complaints=s.Collection;
            }, function (e) {
                msg(e.Message);
            });
    };

    $scope.SettledBills=[];
    $scope.GetAllSettledBill = function () {
        $scope.SettledBills=[];
        
        $scope.ProgressStart();
        service.GetAllSettledBill($scope.PropertyID, $scope.ModifiedDate)
            .then(function (result) {
                $scope.SettledBills = result.Collection;

                angular.forEach($scope.SettledBills, function (item) {
                    if (item.BillStatusId == 1) {
                        item.BillStatusName = 'Settled'
                    }
                    else if (item.BillStatusId == 3) {
                        item.BillStatusName = 'Pending'
                    }
                    else if (item.BillStatusId == 5) {
                        item.BillStatusName = 'Re-Settlement Pending'
                    }
                });

                $scope.ProgressEnd();
            }, function (err) {
                $scope.ProgressEnd();
                msg(err.Message);
            });

    };

    $scope.SendOTP = function () {
        $scope.IsResend = false;
        var id = $scope.Settlement.BillId;
        var promiseGet = service.SendOTP(id);
        promiseGet.then(function (data) {

            $scope.IsOTP = false;
            if (data.Data == "True") {
                $scope.IsOTP = true;
                $scope.SMSTimer(60); //Wait 60 sec
            }
        },
            function (error) {
                parent.posFailureMessage(error.Message);
            });
    };

    //
    $scope.duration = 0;
    $scope.IsResend = false;
    $scope.SMSTimer = function (eventTime) {

        $scope.IsResend = false;
        //var eventTime = 0;//1366549200; // Timestamp - Sun, 21 Apr 2013 13:00:00 GMT
        var currentTime = 0;//1366547400; // Timestamp - Sun, 21 Apr 2013 12:30:00 GMT
        var diffTime = eventTime - currentTime;
        var duration = moment.duration(diffTime * 1000, 'milliseconds');
        var interval = 1000;

        setInterval(function () {

            if ($scope.IsResend) {
                return;
            }
            duration = moment.duration(duration - interval, 'milliseconds');
            if (duration == 0) {

                //$scope.SendOTP();
                $scope.IsResend = true;
            }

            if (duration < 0) return;
            $scope.duration = duration._data.seconds;
            //$('.countdown').text(duration.hours() + ":" + duration.minutes() + ":" + duration.seconds())
        }, interval);
    };


    $scope.DeleteSettledBill = function (billId) {
        var strDelete = DeletePopup("Are you sure you want to delete this Settlement Detail? Previous Settlement will be Deleted.");
        var ret;
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $("#fancyconfirm_cancel")
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $("#fancyConfirm_ok")
                    .click(function () {

                        ret = true;
                        
                        
                        $scope.ProgressStart();
                        service.DeleteSettledBill(billId)
                            .then(function (result) {
                                if(result.Status)
                                {
                                    angular.forEach($scope.SettledBills, function (item) {
                                        if(item.Id == billId)
                                        {
                                            item.BillStatusId = 5;
                                            item.BillStatusName = 'Re-Settlement Pending';
                                            item.SettlementModeForDisplay ='';
                                        }
                                    });
                                }
                                msg("Settlement Delete sucessfully. Please Re-Settle NOW!.", result.Status);
                                $scope.ProgressEnd();
                            }, function (err) {
                                $scope.ProgressEnd();
                                msg(err.Message);
                            });

                        $.fancybox.close();
                    });
            }
        });
    };

    $scope.GetFOBillById = function (billId) {
        
        $scope.ProgressStart();
        service.GetFOBillById(billId)
            .then(function (result) {
                if(result.Status)
                {
                    $scope.FOBill = result.Data;
                    $scope.GetBill($scope.FOBill);

                    $('#settledBillModal').modal('hide');
                    $('#settlement1').modal('show');
                }
                
                $scope.ProgressEnd();
            }, function (err) {
                $scope.ProgressEnd();
                msg(err.Message);
            });
    };

    $scope.greaterThan = function(prop, val){
        return function(item){
            return item[prop] > val;
        }
    }

    //SignalR
    
    $scope.IsHubConnected = false;
    var connection = $.hubConnection(apiPath);
    var eventName = "onMessageListened";
    connection.start().done(function () {
        $scope.IsHubConnected = true;
    });
    var messageBroadCast = connection.createHubProxy('BroadCastHub');
    messageBroadCast.on(eventName, function (message) {
        var res = message.split("$");
        if (res[0] == "FO_GUEST_CHARGE_POST") {
            if($scope.CheckINGuest.Id == res[1] && res[3] == "1" )
            {
                $scope.SetCheckINGuest(res[1]);
                $scope.GetRevenuePost(res[1]);
            }
        }
        if (res[0] == "FO_GUEST_FOBill") {
            if($scope.CheckINGuest.Id == res[1])
            {
                $timeout(function () {
                    $scope.GetOccupiedRooms()
                    $scope.SplitBillings = [];
                    $scope.model = { ChargePostToId: 1 };
                    $scope.CheckINGuestRevenuePosts = [];
                    $scope.CheckINGuest.IsFOBilled = true;
                    $scope.SetCheckINGuest(res[1]);
                },200);
            }
        }
    });


    $scope.$on("CallDashboardCheckIN", function (event, obj) {
        //alert('Guest Details Changed. Reloading Guest.');
        $scope.changeChargePostToId();
    });

    //end signalR

    $scope.UpdateRoomStatus = function(){
        
        if($scope.Model.CheckINGuestId)
        {
            service.UpdateRoomStatus($scope.Model.CheckINGuestId,businessDate)
            .then(function (result) {
                              
            }, function (err) {
                $scope.ProgressEnd();
                msg(err.Message);
            });
        }
    }

            
    $scope.FOBillCancelReservation =function(reservation){
        alert('Bill Cancel is Under Development.');
    }

    $scope.PropertyGroups = [];
    $scope.GetPropertyGroupByPropertyId = function () {
        $scope.PropertyGroups = [];
        service.GetAllInterPropertyPropertyGroup($scope.PropertyID)
               .then(function (result) {
                   $scope.PropertyGroups = result.Collection;
               }, function (err) {
                   msg(err.Message);
               });
    };
    $scope.GetPropertyGroupByPropertyId();

    //OpenInterProperty
    $scope.OpenInterProperty = function(){
        $scope.ToPropertyId ='';
        $scope.CheckINGuestRoomInterPropertyTransferRemark='';

        scrollPageOnTop();
        $("#InterPropertyPOPCheckIN").modal('show');
    }

    //ReservationInterPropertyTransfer
    $scope.TransferCheckIN = function(){
        
        if(!$scope.CheckINGuest)
        {
            parent.popErrorMessage(  "Please Select Room.");
            return;
        }
        else{
            if(!$scope.CheckINGuest.CheckINGuestRoomId)
            {
                parent.popErrorMessage("Please Select Room.");
                return;
            }
        }
        if(!$scope.ToPropertyId)
        {
            parent.popErrorMessage(  "Please Select Property.");
            return;
        }

        var strDelete = DeletePopup("Are you sure you want to Transfer Room?");
        var ret;
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $("#fancyconfirm_cancel")
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $("#fancyConfirm_ok")
                    .click(function () {
                        ret = true;
                        var model={};
                        model.CheckINGuestRoomId = $scope.CheckINGuest.CheckINGuestRoomId;
                        model.ToPropertyId=$scope.ToPropertyId;
                        model.TransferDate=businessDate;
                        model.Remark=$scope.CheckINGuestRoomInterPropertyTransferRemark;
                        model.ModifiedBy = $scope.UserName;
                        model.PropertyID = $scope.PropertyID;

                        var promiseGet = service.SaveCheckINGuestRoomInterPropertyTransfer(model);
                        promiseGet.then(function (data, status) {
                            msg(data.Data, true);
                            $("#InterPropertyPOPCheckIN").modal('hide');
                        },
                            function (error, status) {
                                $scope.GetOccupiedRooms();
                                parent.popErrorMessage(error.responseJSON.Message);
                                scrollPageOnTop();
                            });
                        $.fancybox.close();
                    });
            }
        });

    }

   
$scope.ViewFP = function(){
if($scope.SelectedFP.Id)
{
var pid = $scope.SelectedFP.Id;
            service.MapReport($scope.PropertyID, 'ViewFP')
                .then(function (s) {
                    $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid, '_blank');
                }, function (e) {
                    msgInPopup('Error in mapping to print.');
                });
}

}

    //-----------------------------------------------------------------------------------------------------
    //CheckINMenu USE IN 1) CHECK-IN And 2) ROOM CHART CHECK-IN
    //-----------------------------------------------------------------------------------------------------
    $('#guestinfoshow').click(function () {
        $('#guestinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#passportinfo, #pickupdropinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox,#historydetailsbox,  #groupinfo, #likedislike, #vehiclenumber, #extrachargesnew,#arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#passportvisashow').click(function () {
        $('#passportinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");

        $('#guestinfo, #pickupdropinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox, #groupinfo,#historydetailsbox, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#pickdropinfoshow').click(function () {
        $('#pickupdropinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox, #groupinfo,#historydetailsbox, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#advanceshow').click(function () {
        $('#advance').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo, #discount,#localcontactbox, #extracharges,#visitdetailsbox,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#discountshow').click(function () {
        $('#discount').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox, #extracharges,#visitdetailsbox,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#extrachargesshow').click(function () {
        $('#extracharges').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox,#visitdetailsbox, #discount,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#groupinformationshow').click(function () {
        $('#groupinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox,#visitdetailsbox,#historydetailsbox, #discount, #extracharges, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#likedislikeshow').click(function () {
        $('#likedislike').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox, #advance,#visitdetailsbox,#historydetailsbox, #discount, #extracharges, #groupinfo, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#vehicleinformationshow').click(function () {
        $('#vehiclenumber').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    });

    $('#arrangementsamenitiesshow').click(function () {
        $('#arrangements').slideToggle();
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike, #extrachargesnew,#vehiclenumber,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    });

    $('#documentcentershow').click(function () {
        $('#documentcenter').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo,#localcontactbox,#visitdetailsbox, #pickupdropinfo,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew,#arrangements,#diplomat').css('display', 'none');
    });

    $('#workdetailshow').click(function () {
        $('#workdetail').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo,#localcontactbox,#visitdetailsbox, #pickupdropinfo,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew,#arrangements,#diplomat').css('display', 'none');
    });

    $('#localcontactshow').click(function () {
        $('#localcontactbox').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    });
    $('#visitdetails').click(function () {
        $('#visitdetailsbox').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#historydetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    });
    $('#historyshow').click(function () {
        $('#historydetailsbox').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    });
    $('#extraamount').click(function () {
        $('#extrachargesnew').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#documentcenter,#historydetailsbox,#diplomat,#workdetail').css('display', 'none');

    });
    $('#diplomatshow').click(function () {
        $('#diplomat').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#historydetailsbox,#workdetail').css('display', 'none');

    });

    $('.navigation ul li a').click(function () {
        $('.navigation ul li a').removeClass('selectedli')
        $(this).addClass('selectedli');
    });
        
    //EndMenu
    //-----------------------------------------------------------------------------------------------------

}
]);
