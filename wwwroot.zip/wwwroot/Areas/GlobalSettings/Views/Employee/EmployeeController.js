﻿
app.controller("controller",
[
    "$scope", "employeeService", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, employeeService, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        
        $scope.LoginId = $cookies.get('LoginId');
       
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
        $scope.keys=localStorageService.get('ActionKeys');

        $scope.Model = {
            Id: '',
            EmployeeType: '',
            EmployeeTypeId: '1',
            EmployeeTypeName: '',
            FirstName: '',
            LastName: '',
            Address1: '',
            Address2: '',
            City: '',
            StateId: '',
            StateName: '',
            PIN: '',
            Mobile1: '',
            Mobile2: '',
            Email: '',
            PersonalEmail: '',
            DOB: '',
            DOJ: '',
            IsActive: true,
            DesignationMasterId: '',
            DesignationMasterName: '',
            IsUser: false,
            UserId: '',
            UserName: '',
            Password: '',
            ConfirmPassword: '',
            UserProfileId: '',
            UserProfileName: '',
            Roles: [],
            Properties: [],
            UserPages: [],
            PropertyID: '',
            ModifiedBy: '',
            items:[]
        };
              
        $scope.IsReadonly = false;
        $scope.ShowErrorMessage = false;
        //------------------------------------------------
        ////page configuration parameter
        //------------------------------------------------
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        //------------------------------------------------

        //------------------------------------------------
        //page configuration start
        //------------------------------------------------
        // init the filtered items
        $scope.search = function () {
            
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                
                for (var attr in item) {
                    
                    if (attr === "FirstName" || attr === "LastName" || attr === "Mobile1") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };

        // show items per page
        $scope.perPage = function () {
            $scope.groupToPages();
        };

        // calculate page in place
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };

        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };

        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };

        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };

        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }

        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }

        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };

        // change sorting order
        $scope.sort_by = function (newSortingOrder) {
            
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };
        //------------------------------------------------
        //page configuration end
        //------------------------------------------------
        $scope.propertyListSettings = {
            scrollableHeight: "200px",
            scrollable: true,
            enableSearch: true,
            displayProp: "Name",
            //idProp: 'PropertyID',
            //externalIdProp: 'PropertyID'
        };
                
        $scope.Properties = $scope.LoginPropertys;
        $scope.selectedPropertys = [];
       
        function getData() {
            $scope.ActionMode="";
            var promiseGet = employeeService.getData($scope.PropertyID);
            promiseGet.then(function (data) {
                
                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   
                   parent.failureMessage(data.message);
               });
        };
        getData();

        $scope.ChangeStatus = function (model) {

            if(!$scope.keys.IsEdit)
            { 
                parent.failureMessage("Unauthorized access !!!");
                scrollPageOnTop();
                return false;
            }
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = employeeService.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.designation = [];
        getDesignation();
        function getDesignation() {
            
            var promiseGet = employeeService.GetDesignation($scope.PropertyID);
            promiseGet.then(function (data) {
                
                $scope.designation = data.filter(x=>x.IsActive);
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.Save = function (model, form) {
          
            if ($scope.IsUser) {
                if ($scope.Model.LoginStart == undefined || $scope.Model.LoginStart == "" || $scope.Model.LoginStart == null) {
                    parent.posFailureMessage("Please enter Login Start.");
                    scrollPageOnTop();
                    return false;
                }
                if ($scope.Model.LoginExpired == undefined || $scope.Model.LoginExpired == "" || $scope.Model.LoginExpired == null) {
                    parent.posFailureMessage("Please enter Login Start.");
                    scrollPageOnTop();
                    return false;
                }
                if ($scope.Model.Email == undefined || $scope.Model.Email == "" || $scope.Model.Email == null) {
                    parent.posFailureMessage("Please enter Login Start.");
                    scrollPageOnTop();
                    return false;
                }
                if ($scope.Model.Password == undefined || $scope.Model.Password == "" || $scope.Model.Password == null) {
                    parent.posFailureMessage("Please enter Login Start.");
                    scrollPageOnTop();
                    return false;
                }
                if ($scope.Model.ConfirmPassword == undefined || $scope.Model.ConfirmPassword == "" || $scope.Model.ConfirmPassword == null) {
                    parent.posFailureMessage("Please enter Login Start.");
                    scrollPageOnTop();
                    return false;
                }

                if ($scope.Model.Password != $scope.Model.ConfirmPassword) {
                    parent.posFailureMessage("Confirm Password does not matched.");
                    scrollPageOnTop();
                    return false;
                }
            }

            if ($scope[form].$valid) {

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                model.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

                model.DOB = GetServerDate(model.DOB, $scope.DateFormat);
                model.DOJ = GetServerDate(model.DOJ, $scope.DateFormat);
                
                if ($scope.Model.IsUser)
                {
                    model.Properties = [];
                    angular.forEach($scope.selectedPropertys, function (item) {
                        model.Properties.push({PropertyID:item.Id});
                    });
                    model.Roles = $scope.selectedRoles;

                    model.LoginStart = GetServerDate(model.LoginStart, $scope.DateFormat);
                    model.LoginExpired = GetServerDate(model.LoginExpired, $scope.DateFormat);

                }

                var status = employeeService.save(model);
                status.then(function (result) {
                    if (result.Status == true) {
                        
                        var msg = result.Message;
                        parent.successMessage(msg);
                        getData();
                    }
                    $scope.Reset();
                },
                function (error) {
                    
                    model.DOB = GetLocalDate(model.DOB, $scope.DateFormat);
                    model.DOJ = GetLocalDate(model.DOJ, $scope.DateFormat);

                    if ($scope.Model.IsUser) {
                        model.LoginStart = GetLocalDate(model.LoginStart, $scope.DateFormat);
                        model.LoginExpired = GetLocalDate(model.LoginExpired, $scope.DateFormat);
                    }
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
                scrollPageOnTop();
            }
            $scope.model.ApplicableFromDate = '';
        }

        $scope.Reset = function () {
            
            $scope.Model = {};
            $scope.selectedRoles = [];
            $scope.selectedPropertys = [];
            $scope.query = "";
            $scope.Model.EmployeeTypeId = '1';
            $scope.Model.IsActive = true;
            $scope.ActionMode="";
            getData();
            scrollPageOnTop();
        };
        $scope.ActionMode="";
        $scope.Edit = function (model) {
            $scope.ActionMode="Edit";                                                     
            var Model = angular.copy(model);
            $scope.selectedPropertys = [];
            $scope.selectedRoles = [];

            $scope.Model = Model;
            
            angular.forEach(Model.Properties, function (item) {
                angular.forEach($scope.Properties, function (property) {
                    if (item.PropertyID == property.Id)
                    {
                        
                        $scope.selectedPropertys.push({ Id: property.Id, Name: property.Name });
                    }
                });
            });
            
            angular.forEach(Model.Roles, function (item) {
                angular.forEach($scope.Roles, function (role) {
                    if (item.Id == role.Id) {
                        $scope.selectedRoles.push(role);
                    }
                });
            });

            $scope.Model.DOB = $filter('date')(Model.DOB, $scope.DateFormat);
            $scope.Model.DOJ = $filter('date')(Model.DOJ, $scope.DateFormat);
            $scope.Model.LoginStart = $filter('date')(Model.LoginStart, $scope.DateFormat);
            $scope.Model.LoginExpired = $filter('date')(Model.LoginExpired, $scope.DateFormat);

            $scope.Model.CountryId = Model.CountryId.toString();
            $scope.CountryChange($scope.Model.CountryId);
            $scope.Model.StateId = Model.StateId.toString();
            
            scrollPageOnTop();
        };

        $scope.Countrys=[]

        GetAllCountry();
        function GetAllCountry() {
            
            var promiseGet = employeeService.getAllCountry();
            promiseGet.then(function (data) {
                
                $scope.Countrys = data;
                
            },
            function (data) {
                
                parent.failureMessage(data.Message);
            });
        }

        $scope.States = [];
        $scope.CountryChange = function (id) {
            var promiseGet = employeeService.getAllState(id);
            promiseGet.then(function (data) {
                $scope.States = data.Collection;
            }, function (data) {

                parent.failureMessage(data.Message);
            });
        };
        
        $scope.RoleListSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
        $scope.Roles = [];
        $scope.selectedRoles = [];
        GetAllRole();
        function GetAllRole() {
            
            var promiseGet = employeeService.getAllRole($scope.PropertyID);

            promiseGet.then(function (data) {
                
                $scope.Roles = data.filter(x=>x.IsActive);
                $scope.selectedRoles = [];
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.Model.EmployeeType = null;
        setTimeout(function () {
            $scope.Model.EmployeeType = "true";
        }, 300);

    }
]);
