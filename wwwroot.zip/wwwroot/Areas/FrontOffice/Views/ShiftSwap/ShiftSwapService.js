﻿
app.service('shiftSwapService', [
    "$http", "$q", function (
        $http, $q) {

        this.getOccupiedRoomList = function (propertyId, date) {
            return httpCaller(apiPath + "FrontOffice/RoomMaster/allWithGuest", $http, $q, { propertyId: propertyId, date: date, onlyWithGuests: true });
        };
        //this.getVacantRoomList = function (propertyId) {
        //    return httpCaller(apiPath + "FrontOffice/RoomStatus/GetAllByRoomStatusType", $http, $q, { propertyId: propertyId, occupiedStatusId: 1 });
        //};

        this.getRoomTypeList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/RoomType/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getRoomFeatureList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/roomfeatures/details", $http, $q, { propertyId: propertyId });
        };
        this.getFloorList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/Floor/allByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getBlockList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/Block/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getRoomList = function (propertyId, featureId, floorId, blockId, roomTypeId) {
            return httpCaller(apiPath + "FrontOffice/RoomMaster/Search", $http, $q, { propertyId: propertyId, roomTypeId: roomTypeId || "All", featureId: featureId || 'All', floorId: floorId || 'All', blockId: blockId || 'All', roomStatusId: 'All' });
        };

        this.getReasonList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/Reason/AllByModuleId", $http, $q, { propertyId: propertyId, moduleId: 1 });
        };

        this.save = function (model) {
            return httpPoster(apiPath + "FrontOffice/GuestManagement/Save", $http, $q, model);
        };

    }
]);
