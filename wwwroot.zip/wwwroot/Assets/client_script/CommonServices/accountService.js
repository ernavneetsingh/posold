﻿(function () {

    function accountService($http, $q) {

        var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';
        

        function loginRequest(model) {
            
            var url = apiPath + "security/login";

            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            }).success(function (data) {

                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }


        function forgotRequest(forgotModel) {
            var accountUrl = apiPath + "security/ForgotPassword";
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: accountUrl,
                data: forgotModel
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        function getCompany() {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "referencedata/Company",
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        function getAddress(latitude, longitude) {
            
            var url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + latitude + "," + longitude + "&key=" + YOUR_API_KEY;

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: url
            }).success(function (data, status, headers, cfg) {
                
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        //function getLastShift(proprtyId) {
        //    var deferred = $q.defer();
        //    $http({
        //        method: "GET",
        //        url: apiPath + "FrontOffice/FOShift/GetLastShift/" + proprtyId,
        //        headers: { 'duxtechApiKey': accessToken },
        //        contentType: "application/json; charset=utf-8"
        //    }).success(function (data, status, headers, cfg) {
        //        deferred.resolve(data);
        //    }).error(function (err, status) {
        //        deferred.reject(err, status);
        //    });
        //    return deferred.promise;
        //};


        function getLastShift(model) {
            var url = apiPath + "FrontOffice/FOShift/GetLastShift";
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var service = {
            loginRequest: loginRequest,
            forgotRequest: forgotRequest,
            getCompany: getCompany,
            getAddress: getAddress,
            getLastShift: getLastShift,
            //hotelRegistrationRequest: hotelRegistrationRequest,
            //getCountry: getCountry,
            //getAllState: getAllState,
            //changeAdminPasswordRequest: changeAdminPasswordRequest
        };
        accessToken = "";

        return service;
    }

    app.factory('accountService', ['$http', '$q', accountService]);
})();
