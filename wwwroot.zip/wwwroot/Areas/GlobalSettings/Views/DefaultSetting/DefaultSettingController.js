﻿
app.controller('controller', ['$scope', '$cookies', 'service', 'localStorageService', '$filter', function ($scope, $cookies, service, localStorageService, $filter) {

    $scope.UserName = $cookies.get('UserName');
    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

    var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
    $scope.MaxDatess = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

    $scope.isSaving = true;
    $scope.Countries = [];
    $scope.currencylist = [];
    $scope.MealPlanlist = [];
    $scope.Salutationlist = [];
    $scope.PayModelist = [];
    $scope.Countrylist = [];
    $scope.Statelist = [];
    $scope.RoomTypelist = [];
    $scope.RateMasterlist = [];
    $scope.MarketSegmentlist = [];
    $scope.BusinessSourcelist = [];
    $scope.DefaultSetting = {};

    $scope.Model = {};
    $scope.Model.CurrencydecimalPlaces = "2";

    getAllCountry();
    getAllCurrency();
    getAllMealPlan();
    getAllSalutation();
    getAllPaymentMode();
    getAllRoomType();
    getAllRateMaster();
    getAllMarketSegment();
    getAllBusinessSource();
    getDefaultSetting();

    function getAllCountry() {
        var promiseGet = service.getAllCountry();
        promiseGet.then(function (data) {
            $scope.Countries = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllCurrency() {
        var promiseGet = service.getAllCurrency();
        promiseGet.then(function (data) {
            $scope.currencylist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllMealPlan() {
        var promiseGet = service.getAllMealPlan();
        promiseGet.then(function (data) {
            $scope.MealPlanlist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllSalutation() {
        var promiseGet = service.getAllSalutation();
        promiseGet.then(function (data) {
            $scope.Salutationlist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllPaymentMode() {
        var promiseGet = service.getAllPaymentMode($scope.PropertyID);
        promiseGet.then(function (data) {
            if (data && data.length > 0)
                $scope.PayModelist = data[0].SettlementModeDetails;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllRoomType() {
        var promiseGet = service.getAllRoomType($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.RoomTypelist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllRateMaster() {
        var promiseGet = service.getAllRateMaster($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.RateMasterlist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllMarketSegment() {
        var promiseGet = service.getAllMarketSegment($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.MarketSegmentlist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }
    function getAllBusinessSource() {
        var promiseGet = service.getAllBusinessSource($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.BusinessSourcelist = data;
        },
        function (data) {
            msg(data.Message);
        });
    }

    $scope.CountryChange = function (selectedModelCountry) {
        CountryChange(selectedModelCountry);
    }
    function CountryChange(selectedModelCountry) {
        $scope.SelectedModelCountry = [];
        $scope.States = [];

        if (selectedModelCountry != null) {
            $scope.SelectedModelCountry = selectedModelCountry;

            var promiseGet = service.getAllState(selectedModelCountry);
            promiseGet.then(function (data) {
                $scope.States = data.Collection;
            },
                function (error) {
                    msg(error.Message);
                });
        }
    }

    function getDefaultSetting() {

        var promiseGet = service.getDefaultSetting($scope.PropertyID);
        promiseGet.then(function (data) {

            if (data != null) {

                $scope.Model = data;
                $scope.Model.GlobalLanguage = data.GlobalLanguage.toString();
                $scope.Model.CurrencyMasterId = data.CurrencyMasterId.toString();
                $scope.Model.CurrencydecimalPlaces = data.CurrencydecimalPlaces.toString();
                $scope.Model.RoomTypeId = data.RoomTypeId.toString();
                $scope.Model.RateMasterId = data.RateMasterId.toString();
                $scope.Model.MarketSegmentId = data.MarketSegmentId.toString();
                $scope.Model.BusinessSourceId = data.BusinessSourceId.toString();
                $scope.Model.MealPlanId = data.MealPlanId.toString();
                $scope.Model.PaymentModeId = data.RevenueHeadId.toString();
                $scope.Model.SalutationId = data.SalutationId.toString();
                $scope.Model.CountryMasterId = data.CountryMasterId.toString();

                $scope.Model.RoundOffTypeId = data.RoundOffTypeId.toString();

                $scope.Model.DefaultNationality = data.DefaultNationality.toString();
                $scope.Model.Software_Started_Date = $filter('date')(data.Software_Started_Date, $scope.DateFormat);
                $scope.Model.Financial_FromYear = $filter('date')(data.Financial_FromYear.toString(), $scope.DateFormat);
                $scope.Model.Financial_ToYear = $filter('date')(data.Financial_ToYear.toString(), $scope.DateFormat);

                $scope.Model.CheckOUTTypeId = data.CheckOUTTypeId.toString();

                //$scope.Model.EarlyArrivalHH = data.EarlyArrival.split(':')[0];// + ":" + model.EarlyArrivalMM;
                //$scope.Model.EarlyArrivalMM = data.EarlyArrival.split(':')[1];// + ":" + model.LateDepartureMM;
                //$scope.Model.LateDepartureHH = data.LateDeparture.split(':')[0];// + ":" + model.EarlyArrivalMM;
                //$scope.Model.LateDepartureMM = data.LateDeparture.split(':')[1];// + ":" + model.LateDepartureMM;

                //model.EarlyArrival = model.EarlyArrivalHH + ":" + model.EarlyArrivalMM;
                //model.LateDeparture = model.LateDepartureHH + ":" + model.LateDepartureMM;

                CountryChange($scope.Model.CountryMasterId);
                $scope.Model.StateMasterId = data.StateMasterId.toString();
            }


        },
        function (data) {
            msg(data.Message);
        });
    }

    $scope.Save = function (model, form) {

        if (!$scope[form].$valid) {
            $scope.ShowErrorMessage = true;
            return;
        }
        if (!($scope.Model.ChildAge > 0)) {
            msg('Child age should be greater than 0');
            return;
        }
        model.PropertyID = $scope.PropertyID;
        model.ModifiedBy = $scope.UserName;
        model.ModifiedDate = $scope.ModifiedDate;

        model.EarlyArrival = model.EarlyArrival;
        model.LateDeparture = model.LateDeparture;

        model.Software_Started_Date = GetServerDate(model.Software_Started_Date, $scope.DateFormat);
        model.Financial_FromYear = GetServerDate(model.Financial_FromYear, $scope.DateFormat);
        model.Financial_ToYear = GetServerDate(model.Financial_ToYear, $scope.DateFormat);

        var promiseGet = service.save(model);
        promiseGet.then(function (data, status) {
            msg(data.Message, true);
            $scope.isSaving = true;

            model.Software_Started_Date = GetLocalDate(model.Software_Started_Date, $scope.DateFormat);
            model.Financial_FromYear = GetLocalDate(model.Financial_FromYear, $scope.DateFormat);
            model.Financial_ToYear = GetLocalDate(model.Financial_ToYear, $scope.DateFormat);

        },
        function (data, status, headers, config) {
            msg(data.Message);
        });

    };
    $scope.Reset = function () {
        $scope.isSaving = false;

        getDefaultSetting();
    }

    $scope.RoundOff = [];
    getRoundOff();
    function getRoundOff() {
        var promiseGet = service.GetRoundOff();
        promiseGet.then(function (data) {

            $scope.RoundOff = data;
        },
            function (data) {
                msg(data.message);
            });
    }

}]);
