﻿
app.controller("controller", [
    "$scope", "InventoryItemService", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        //$scope.ModifiedBy = $cookies.get('UserName');
        //$scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');
        $scope.keys=localStorageService.get('ActionKeys');
        $scope.ActionMode="";
        $scope.Model = {
            Id: '',
            Code: '',
            Name: '',
            ItemGroupType: '',
            ItemGroupTypeId: "",
            ItemGroupTypeName: '',
            ItemType: '',
            ItemTypeId: 1,
            ItemTypeName: '',
            ItemCategoryId: '',
            ItemCategoryName: '',
            StoreId: '',
            StoreName: '',
            PurchaseFrom: true,
            UnitOfMeasurementId: '',
            UnitOfMeasurementName: '',
            UnitType: '',
            UnitTypeId: '',
            UnitTypeName: '',
            IsShowExpiryDate: false,
            IsShowBatchNo: false,
            IsShowCapitalItem: true,
            IsShowConsignmentNo: false,
            IsActive: true,
            PropertyID: '',
            ModifiedBy: '',
            Brands: [],
            items: [],
            CostCenterRols: [{}]
        };

        $scope.BrandListSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];//$scope.pageAttrs = ["Symbol", "Name"]; //TODO
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "Code" || attr === "Name" || attr === "ItemTypeName") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {
            $scope.ActionMode=""; 
            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   parent.failureMessage(data.message);
               });

        };
        $scope.ItemGroups = [];

        GetAllItemGroup();
        function GetAllItemGroup() {

            var temp = $scope.PropertyID;
            var promiseGet = service.getItemGroup();

            promiseGet.then(function (data) {

                $scope.ItemGroups = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.Stores = [];
        GetStoreType();
        function GetStoreType() {
            var promiseGet = service.getStoreType();
            promiseGet.then(function (data) {
                $scope.Stores = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.SubStores = [];
        $scope.GetSubStores = function (storeTypeId) {

            var promiseGet = service.getSubStore($scope.PropertyID, storeTypeId);
            promiseGet.then(function (data) {
                $scope.SubStores = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.UnitOfMeasurementFroms = [];
        $scope.GetSelectUnit = function (id) {

            var temp = $scope.PropertyID;
            var promiseGet = service.getSelectUnit($scope.PropertyID, id);
            promiseGet.then(function (data) {
                $scope.UnitOfMeasurementFroms = data;
                $scope.Model.UnitOfMeasurementId = $scope.Model.UnitOfMeasurementIdStore;
                $scope.Model.UnitOfMeasurementIdStore = "";
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }
        $scope.GetItemCategory = function (id) {
            var promiseGet = service.getItemCategory($scope.PropertyID, id, $scope.ModifiedDate);
            promiseGet.then(function (data) {
                $scope.ItemCategory = data;
                $scope.Model.ItemCategoryId = $scope.Model.ItemCategoryIdStore;
                $scope.Model.ItemCategoryIdStore = "";
            },
            function (data) {
                parent.failureMessage(data.message);
            });
        }
        $scope.UnitTypes = [];
        GetAllUnitType();
        function GetAllUnitType() {

            var temp = $scope.PropertyID;
            var promiseGet = service.getAllUnitType();

            promiseGet.then(function (data) {

                $scope.UnitTypes = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }
        $scope.Brand = [];
        $scope.brandList = [];
        GetAllBrand();
        function GetAllBrand() {

            var promiseGet = service.getAllBrand($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Brand = data;
                $scope.brandList = [];

            }, function (data) {
                parent.failureMessage(data.message);
            });
        }

        $scope.getInventoryLocationList = function (id) {

            var promise = service.getInventoryLocationList($scope.PropertyID, id);
            promise.then(function (data) {

                $scope.InventoryLocationList = data.Collection;
            }, function (data) {
                msg(data.message);
            });
        }
        $scope.getInventoryLocationList();

        $scope.formdata = new FormData();
        $scope.getTheFiles = function ($files, fd) {
            angular.forEach($files, function (value, key) {

                fd.append(key, value);
            });
        };
        $scope.uploadExcel = function (fd) {
            $scope.IsUploadingExcel = true;
            service.saveFromExcel(fd, $scope)
                .then(function () {
                    getData();
                });
        };

        $scope.Save = function (model, form) {
            $scope.IsSaving = true;
            if ($scope[form].$valid) {

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                model.ModifiedDate = $scope.ModifiedDate;
                model.Brands = $scope.brandList;

                var status = service.save(model);
                status.then(function (result) {

                    if (result.Status === true) {
                        msg(result.Message, true);
                        //parent.successMessage(msg);
                        $scope.Model.ItemTypeId = 1;
                        $scope.Model.PurchaseFrom = true;
                        $scope.Model.IsShowExpiryDate = false;
                        $scope.Model.IsShowBatchNo = false;
                        $scope.Model.IsShowConsignmentNo = false;
                        $scope.Model.IsShowCapitalItem = true;
                        //getData();
                        //scrollPageOnTop();
                    }
                    $scope.Reset();
                    //scrollPageOnTop();
                    //$scope.IsSaving = false;
                }, function (error) {

                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                }).finally(function () {
                    $scope.IsSaving = false;
                });
            } else {
                $scope.ShowErrorMessage = true;
                scrollPageOnTop();
                $scope.IsSaving = false;
            }
            $scope.model.ApplicableFromDate = '';
        }
        $scope.Remove = function (model) {
            if (!$scope.keys.IsDelete)
            {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;

                        var status = service.remove($scope.PropertyID, model.Id);
                        status.then(function (r) {
                            msg(r.Message, true);
                            getData();
                        }, function (error) {
                            msg(error.Message);
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange($scope.PropertyID, model.Id);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };

        $scope.SelectedUnitTypeId = "";
        $scope.Edit = function (model) {
            $scope.ActionMode="Edit"; 
            $scope.resetCostCenterList();
            $scope.Model =angular.copy(model);
            $scope.Model.ItemGroupTypeId = model.ItemCategoryGroupTypeId.toString();
            $scope.Model.ItemCategoryIdStore = model.ItemCategoryId.toString();
            $scope.GetItemCategory(model.ItemGroupTypeId);
            $scope.Model.ItemTypeId = model.ItemType.toString();
            $scope.Model.PurchaseFrom = model.PurchaseFrom === "true";
            $scope.Model.UnitTypeId = model.UnitType.toString();
            $scope.Model.UnitOfMeasurementIdStore = model.UnitOfMeasurementId.toString();
            $scope.GetSelectUnit(model.UnitTypeId);
            $scope.StoreId = model.StoreTypeId;
            $scope.Model.StoreId = model.StoreId.toString();
            $scope.GetSubStores(model.StoreTypeId);
            $scope.Model.StoreName = model.StoreName.toString();

            //$scope.Model.Brands = model.Brands.toString();
            $scope.Model.ApplicableFrom = $filter('date')(model.ApplicableFrom, $scope.DateFormat);
            $scope.brandList = model.Brands;
            if (!$scope.Model.CostCenterRols || $scope.Model.CostCenterRols.length < 1) $scope.Model.CostCenterRols = [];
            $scope.CostCenterList.forEach(function (cc) {
                $scope.Model.CostCenterRols.forEach(function (ccr) {
                    if (ccr.CostCenterId === cc.Id)
                        cc.isDisabled = true;
                });
            });
            $scope.Model.CostCenterRols.push({});

            scrollPageOnTop();
        }
        $scope.Reset = function () {
            $scope.ActionMode=""; 
            $scope.Model = { CostCenterRols: [{}] };
            $scope.StoreId = "";
            $scope.brandList = [];
            $scope.Model.IsActive = true;
            $scope.Model.ItemTypeId = 1;
            $scope.Model.PurchaseFrom = true;
            $scope.Model.IsShowExpiryDate = false;
            $scope.Model.IsShowBatchNo = false;
            $scope.Model.IsShowConsignmentNo = false;
            $scope.Model.IsShowCapitalItem = true;
            $scope.query = "";
            getData();
            scrollPageOnTop();
            //$scope.CostCenterList = $scope.CostCenters;
            $scope.resetCostCenterList();
        };
        $scope.IsLocationExist = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.isLocationExist($scope.PropertyID, model.Code);
            promiseGet.then(function (data) {

            }, function (error) {

                $scope.Model.Code = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
        };

        $scope.getCostCenterList = function () {

            service.getCostCenterList($scope.PropertyID).then(function (s) {
                $scope.CostCenterList = s.Collection;
                //$scope.CostCenterList = $scope.CostCenters;
            }, function (e) {
                msg(e.message);
            });
        };
        $scope.getCostCenterList();
        $scope.addCostCenterRol = function (costCenterId) {
            $scope.CostCenterList.forEach(function (cc) {
                if (costCenterId === cc.Id)
                    cc.isDisabled = true;
            });
            $scope.Model.CostCenterRols.push({});
        };
        $scope.deleteCostCenterRol = function (i) {
            var c = $scope.Model.CostCenterRols[i];
            $scope.Model.CostCenterRols.splice(i, 1);
            if ($scope.Model.CostCenterRols.length <= 0) $scope.Model.CostCenterRols = [{}];
            $scope.CostCenterList.forEach(function (cc) {
                if (c.CostCenterId === cc.Id)
                    cc.isDisabled = false;
            });
        };
        $scope.resetCostCenterList = function () {
            $scope.CostCenterList.forEach(function (cc) { cc.isDisabled = false; });
        };
        $scope.changeSubStore = function () {
            var s= $scope.SubStores.find(x=>x.Id===$scope.Model.StoreId);
            $scope.Model.StoreName = s?s.Name:"";
        };

    }
]);
