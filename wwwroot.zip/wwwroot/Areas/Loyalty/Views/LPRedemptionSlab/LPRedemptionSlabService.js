﻿
app.service('LPRedemptionSlabService', [
    '$http', '$q', function (
        $http, $q) {

        this.getAllDiscountType = function () {
            return httpCaller(apiPath + "ReferenceConstant/DiscountType/All", $http, $q);
        };
        this.getAllLPCard = function (propertyId) {
            return httpCaller(apiPath + "Loyalty/LPCard/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getAll = function (options) {
            return httpCaller(apiPath + "Loyalty/LPRedemptionSlab/GetAll", $http, $q, options);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "Loyalty/LPRedemptionSlab/Save", $http, $q, model);
        };
        this.delete = function (id) {
            return httpCaller(apiPath + "Loyalty/LPRedemptionSlab/Delete", $http, $q, { id: id });
        };
        this.changeStatus = function (model) {
            return httpPoster(apiPath + "Loyalty/LPRedemptionSlab/Status", $http, $q, model);
        };

    }
]);
