﻿
var propertyId;
var currentUser;
app.service("desigService", function ($http, $q) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getdesigData = function (propertyId) {
        return $.ajax({
            type: "GET",
            url: apiPath + "GlobalSetting/designation/all/" + propertyId,
            params: {},
            dataType: "json",
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8",
            success: function () {
            },
            error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        });
    };

    this.getModuleData = function () {

        
        var url = apiPath + "configuration/Module/all";
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result.Collection);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;

    };

    this.savedesigData = function (desigData) {
        return httpPoster(apiPath + "GlobalSetting/designation/create/modify", $http, $q, desigData);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/designation/create/modify",
        //    data: JSON.stringify(desigData),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.removedesigData = function (desigData) {
        return httpPoster(apiPath + "GlobalSetting/designation/remove/" + desigData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/designation/remove/" + desigData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.statusdesigData = function (model) {
        return httpPoster(apiPath + "GlobalSetting/designation/changestatus", $http, $q, model);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/designation/changestatus",
        //    data: model,
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});

    };

    this.desigDataExists = function (propertyId, desigData) {
        return httpPoster(apiPath + "GlobalSetting/designation/existcode/" + propertyId + "/" + desigData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/designation/existcode/" + propertyId + "/" + desigData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function (data) {

        //    }
        //    ,
        //    error: function (data) {

        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});
    };
});
