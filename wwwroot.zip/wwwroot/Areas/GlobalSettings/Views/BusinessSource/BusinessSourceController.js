﻿
app.controller("BusinessSourceController",
[
    "$scope", "BusinessSourceService", "$cookies", "localStorageService",
    function ($scope, businessSourceService, $cookies, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); // "XY01CC58";
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.UserName = $cookies.get('UserName');//"Admin";
        $scope.IsReadonly = false;
        $scope.bsid = "";
        $scope.Name = "";
        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;
        $scope.IsBanquet = false;
        $scope.businessSourceModel = {};
        $scope.Save = "Save";
        $scope.businessSourceData = [];
        $scope.businessSourceDetails = [];
        var sortKeyOrder = {
            key: "",
            order: ""
        };
        $scope.keys = localStorageService.get('ActionKeys');
        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        getData($scope, businessSourceService, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, businessSourceService, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, businessSourceService, localStorageService);
        };
        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, businessSourceService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, businessSourceService, localStorageService);
        }
        function getBusinessSourceDetails(businessSourceId) {

            var promiseGet = businessSourceService.getBusinessSourceData(businessSourceId, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                $scope.BusinessSourceDetails = data[0].BusinessSource;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.isExist = function () {

            var promiseGet = businessSourceService.getCodeExistBusinessSource($scope.bsCode, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        msg(data.Message);
                        $scope.bsCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.bsid = "";
            $scope.bsName = "";
            $scope.bsCode = "";
            $scope.bsDescription = "";
            $scope.IsActive = true;
            $scope.IsBanquet = false;
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            $scope.searchfor = "";
            localStorageService.set("searchfor", $scope.searchfor);
            getData($scope, businessSourceService, localStorageService);
        };
        $scope.saveBusinessSourceData = function (form) {

            if ($scope[form].$valid) {
                var bsObj = new Object();
                bsObj.Id = $scope.bsid;
                bsObj.Name = $scope.bsName;
                bsObj.Code = $scope.bsCode;
                bsObj.Description = $scope.bsDescription;
                bsObj.IsActive = $scope.IsActive;
                bsObj.IsBanquet = $scope.IsBanquet;
                bsObj.PropertyId = $scope.PropertyID;
                bsObj.ModifiedBy = $scope.UserName;
                bsObj.ModifiedDate = $scope.ModifiedDate;
                var promiseGet = businessSourceService.saveBusinessSource(bsObj);
                promiseGet.then(function (data, status) {
                    getData($scope, businessSourceService, localStorageService);
                    $scope.reset();
                    if (data.Status) {
                        msg(data.Message, true);
                    }
                },
                function (error, status) {
                    msg(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.updateBusinessSourceData = function (bsModel) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            bsModel.ModifiedBy = $scope.UserName;
            bsModel.ModifiedDate = $scope.ModifiedDate;

            var promiseGet = businessSourceService.updateIsActiveBusinessSource(bsModel);
            promiseGet.then(function (data, status) {
                getData($scope, businessSourceService, localStorageService);
                if (data.Status) {
                    msg(data.Message, true);
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.removeRow = function (bsModel) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Business Source?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = businessSourceService.deleteBusinessSource(bsModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {

                                getData($scope, businessSourceService, localStorageService);
                                msg(d.Message, d.Status);
                            }, function (error) {
                                msg(error.Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.ActionMode = "";
        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.bsid = record.Id;
            $scope.bsName = record.Name;
            $scope.bsDescription = record.Description;
            $scope.bsCode = record.Code;
            $scope.IsActive = record.IsActive;
            $scope.IsBanquet = record.IsBanquet;
            $scope.IsReadonly = true;
            $scope.Save = "Update";
            msg('');
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.data = dataService.dataAllData;
    $scope.ActionMode = "";
    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getBusinessSource(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {

        msg("The request failed. Unable to connect to the remote server.");
    });

};
