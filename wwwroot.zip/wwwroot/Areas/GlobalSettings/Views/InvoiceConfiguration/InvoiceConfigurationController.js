﻿
app.controller("InvConfigController",
    function ($scope, $http, $filter, InvConfigService, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.Model = {
            IsActive: true
        }

        $scope.MsgNotFound = "";
        $scope.IsReadonlyPart1 = true;
        $scope.IsReadonlyPart2 = true;
        $scope.IsReadonlyPart3 = true;
        $scope.CheckSeparator = false;
        $scope.CheckDateSeparator = false;

        $scope.Part1 = "";
        $scope.Part2 = "";
        $scope.Part3 = "";
        $scope.Separators1 = "";
        $scope.Separators2 = "";
        $scope.DateSeparators1 = "";
        $scope.DateSeparators2 = "";
        $scope.sample = [];
        getCodeFor();

        $scope.sortingOrder = "Sequence";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
        getinvoiceData();

        $scope.part = [{ id: "A", name: "Auto Number" }, { id: "I", name: "Initial" }, { id: "D", name: "Date-Month-Year" }, { id: "M", name: "Month-Year" }, { id: "Y", name: "Year" }, { id: "Q", name: "Year-Month" }, { id: "R", name: "Year-Month-Date" }];
        $scope.formateseperator = [{ id: "-", name: "Hyphen(-)" }, { id: "/", name: "Forward Slash(/)" }, { id: "\\", name: "Back Slash(\\)" }];
        $scope.Separator = $scope.formateseperator[0];
        $scope.DateSeparator = $scope.formateseperator[0];

        $scope.Save = function (form) {
            if ($scope[form].$valid) {
                var codepart1 = "";
                var codepart2 = "";
                var codepart3 = "";

                if (angular.isUndefined($scope.CodeForPart1) && angular.isUndefined($scope.CodeForPart2) && angular.isUndefined($scope.CodeForPart3)) {
                    msg("Please Select sequence");
                    return;
                }

                if ($scope.CodeForPart1) {
                    //if (!angular.isUndefined($scope.CodeForPart1)) {
                    codepart1 = $scope.CodeForPart1.id;
                }
                if ($scope.CodeForPart2) {
                    //if (!angular.isUndefined($scope.CodeForPart2)) {
                    codepart2 = $scope.CodeForPart2.id;
                }
                if ($scope.CodeForPart3) {
                    //if (!angular.isUndefined($scope.CodeForPart3)) {
                    codepart3 = $scope.CodeForPart3.id;
                }

                if (codepart1 !== "A" && codepart2 !== "A" && codepart3 !== "A") {
                    msg("Please Select at least one Autonumber");
                    return;
                } else {

                    var p1Id = "", p2Id = "", p3Id = "";
                    var p1Name = "", p2Name = "", p3Name = "";
                    var item = new Object();
                    item.CodeForId = $scope.CodeFor.CodeForId;
                    if (!angular.isUndefined($scope.CodeInitial)) {

                        item.InvoiceInitialId = $scope.CodeInitial.Id;
                        item.CodeInitial = $scope.CodeInitial.InitialCode;
                        if (!angular.isUndefined($scope.CodeForPart1)) {
                            p1Id = $scope.CodeForPart1.id;
                            p1Name = $scope.CodeForPart1.name;
                        }
                        if (!angular.isUndefined($scope.CodeForPart2)) {
                            p2Id = $scope.CodeForPart2.id;
                            p2Name = $scope.CodeForPart2.name;
                        }
                        if (!angular.isUndefined($scope.CodeForPart3)) {
                            p3Id = $scope.CodeForPart3.id;
                            p3Name = $scope.CodeForPart3.name;
                        }

                        item.Sequence = p1Id + p2Id + p3Id;
                        item.Part1 = p1Name;
                        item.Part2 = p2Name;
                        item.Part3 = p3Name;
                        if ($scope.CheckSeparator === true) {
                            item.Seperator = $scope.Separator.id;
                        } else {
                            item.Seperator = "";
                        }
                        if ($scope.CheckDateSeparator === true) {
                            item.Dateseperator = $scope.DateSeparator.id;
                        } else {
                            item.Dateseperator = "";
                        }
                        item.CodeSampleFormate = $scope.FormatInvoiceNo;
                        item.InvoiceConfigId = "";
                        item.PropertyID = $scope.PropertyID;
                        item.ModifiedBy = $scope.UserName;

                        var saveData = InvConfigService.saveinvconfigData(item);
                        saveData.then(function (data) {
                            msg(data.Message, true);
                            getinvoiceData();
                            resetData();
                        });
                    } else {
                        msg("Code Initial set at first.");
                        return;
                    }
                }

            } else {
                $scope.ShowErrorMessage = true;
                msg('');
            }
        };
        //Get Code for detail
        function getCodeFor() {

            var getData = InvConfigService.getCodeForData();
            getData.then(function (codeforData) {
                $scope.$apply(function () {

                    $scope.sample = codeforData.Collection;
                });
            });
        }
        //Check Initial Code
        $scope.ChangeCodeFor = function () {
           
            $scope.IsReadonlyPart1 = false;
            $scope.IsReadonlyPart2 = false;
            $scope.IsReadonlyPart3 = false;
            if (!angular.isUndefined($scope.CodeFor)) {
                var getData = InvConfigService.getinitialCode($scope.CodeFor.Id, $scope.PropertyID);
                getData.then(function (codefor) {

                    $scope.$apply(function () {

                        $scope.CodeInitialList = codefor.Collection;
                        $scope.CodeInitial = $scope.CodeInitialList[0];

                    });
                });
            }

        }
        //Calculate formating CodeForPart1
        $scope.ChangeCodeForPart1 = function () {

            if ($scope.CheckDateSeparator === true) {
                $scope.DateSeparators1 = $scope.DateSeparator.id;
            }
            if ($scope.CodeForPart1) {
                //if (!angular.isUndefined($scope.CodeForPart1) || $scope.CodeForPart1 != null) {
                var val = $scope.CodeForPart1.id;
                var cDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
                if (val === "A") {
                    $scope.Part1 = "1";
                } else if (val === "I") {

                    $scope.Part1 = $scope.CodeInitial.Name;
                } else if (val === "D") {
                    $scope.Part1 = cDate.getDate() +
                        $scope.DateSeparators1 +
                        cDate.getMonth() +
                        $scope.DateSeparators1 +
                        cDate.getFullYear();
                } else if (val === "M") {
                    $scope.Part1 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
                } else if (val === "Y") {

                    $scope.Part1 = cDate.getFullYear();
                } else if (val === "Q") {
                    $scope.Part1 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
                } else if (val === "R") {
                    $scope.Part1 = cDate.getFullYear() +
                        $scope.DateSeparators1 +
                        cDate.getMonth() +
                        $scope.DateSeparators1 +
                        cDate.getDate();
                }
            }



            if ($scope.CheckSeparator === true) {

                if (($scope.Part1 !== "" && $scope.Part2 !== "") || ($scope.Part1 !== "" && $scope.Part3 !== "")) {
                    $scope.Separators1 = $scope.Separator.id;
                }
                if ($scope.Part2 !== "" && $scope.Part3 !== "") {
                    $scope.Separators2 = $scope.Separator.id;
                }
            } else {
                $scope.Separators1 = "";
                $scope.Separators2 = "";
            }


            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;

        }
        //Calculate formating CodeForPart2
        $scope.ChangeCodeForPart2 = function () {
            if ($scope.CheckDateSeparator === true) {
                $scope.DateSeparators1 = $scope.DateSeparator.id;
            }
            if (!angular.isUndefined($scope.CodeForPart2) || $scope.CodeForPart2 != null) {
                var val = $scope.CodeForPart2.id;
                var cDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
                if (val === "A") {
                    $scope.Part2 = "1";
                } else if (val === "I") {

                    $scope.Part2 = $scope.CodeInitial.Name;
                } else if (val === "D") {

                    $scope.Part2 = cDate.getDate() +
                        $scope.DateSeparators1 +
                        cDate.getMonth() +
                        $scope.DateSeparators1 +
                        cDate.getFullYear();
                } else if (val === "M") {
                    $scope.Part2 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
                } else if (val === "Y") {

                    $scope.Part2 = cDate.getFullYear();
                } else if (val === "Q") {

                    $scope.Part2 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
                } else if (val === "R") {

                    $scope.Part2 = cDate.getFullYear() +
                        $scope.DateSeparators1 +
                        cDate.getMonth() +
                        $scope.DateSeparators1 +
                        cDate.getDate();
                }
            }



            if ($scope.CheckSeparator === true) {

                if (($scope.Part1 !== "" && $scope.Part2 !== "") || ($scope.Part1 !== "" && $scope.Part3 !== "")) {
                    $scope.Separators1 = $scope.Separator.id;
                }
                if ($scope.Part2 !== "" && $scope.Part3 !== "") {
                    $scope.Separators2 = $scope.Separator.id;
                }
            }
            else {
                $scope.Separators1 = "";
                $scope.Separators2 = "";
            }


            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;

        }
        //Calculate formating CodeForPart2
        $scope.ChangeCodeForPart3 = function () {
            if ($scope.CheckDateSeparator === true) {
                $scope.DateSeparators1 = $scope.DateSeparator.id;
            }
            if (!angular.isUndefined($scope.CodeForPart3) || $scope.CodeForPart3 != null) {
                var val = $scope.CodeForPart3.id;
                var cDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
                if (val === "A") {
                    $scope.Part3 = "1";
                } else if (val === "I") {

                    $scope.Part3 = $scope.CodeInitial.Name;
                } else if (val === "D") {

                    $scope.Part3 = cDate.getDate() +
                        $scope.DateSeparators1 +
                        cDate.getMonth() +
                        $scope.DateSeparators1 +
                        cDate.getFullYear();
                } else if (val === "M") {
                    $scope.Part3 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
                } else if (val === "Y") {

                    $scope.Part3 = cDate.getFullYear();
                } else if (val === "Q") {

                    $scope.Part3 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
                } else if (val === "R") {

                    $scope.Part3 = cDate.getFullYear() +
                        $scope.DateSeparators1 +
                        cDate.getMonth() +
                        $scope.DateSeparators1 +
                        cDate.getDate();
                }

            }


            if ($scope.CheckSeparator === true) {

                if (($scope.Part1 !== "" && $scope.Part2 !== "") || ($scope.Part1 !== "" && $scope.Part3 !== "")) {
                    $scope.Separators1 = $scope.Separator.id;
                }
                if ($scope.Part2 !== "" && $scope.Part3 !== "") {
                    $scope.Separators2 = $scope.Separator.id;
                }
            }
            else {
                $scope.Separators1 = "";
                $scope.Separators2 = "";
            }


            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;

        }
        //Check for display seperator
        $scope.ChangeCheckSeparator = function () {
            if ($scope.CheckSeparator === true) {

                if (($scope.Part1 !== "" && $scope.Part2 !== "") || ($scope.Part1 !== "" && $scope.Part3 !== "")) {
                    $scope.Separators1 = $scope.Separator.id;
                }
                if ($scope.Part2 !== "" && $scope.Part3 !== "") {
                    $scope.Separators2 = $scope.Separator.id;
                }
            }
            else {
                $scope.Separators1 = "";
                $scope.Separators2 = "";
            }


            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;
        }
        //change display seperator
        $scope.ChangeSeparator = function () {
            if ($scope.CheckSeparator === true) {
                if (($scope.Part1 !== "" && $scope.Part2 !== "") || ($scope.Part1 !== "" && $scope.Part3 !== "")) {
                    $scope.Separators1 = $scope.Separator.id;
                }
                if ($scope.Part2 !== "" && $scope.Part3 !== "") {
                    $scope.Separators2 = $scope.Separator.id;
                }
            }
            else {
                $scope.Separators1 = "";
                $scope.Separators2 = "";
            }


            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;
        }
        $scope.ChangeCheckDateSeparator = function () {
            if ($scope.CheckDateSeparator === true) {
                $scope.DateSeparators1 = $scope.DateSeparator.id;
            } else {
                $scope.DateSeparators1 = "";
            }
            var cDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
            ///////////////////
            var val1 = $scope.CodeForPart1.id;

            if (val1 === "D") {
                $scope.Part1 = cDate.getDate() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val1 === "M") {
                $scope.Part1 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val1 === "Q") {
                $scope.Part1 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
            }
            else if (val1 === "R") {
                $scope.Part1 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getDate();
            }
            ////////////////////

            var val2 = $scope.CodeForPart2.id;

            if (val2 === "D") {
                $scope.Part2 = cDate.getDate() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val2 === "M") {
                $scope.Part2 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val2 === "Q") {
                $scope.Part2 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
            }
            else if (val2 === "R") {
                $scope.Part2 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getDate();
            }
            ////////////////////

            var val3 = $scope.CodeForPart1.id;

            if (val3 === "D") {
                $scope.Part3 = cDate.getDate() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val3 === "M") {
                $scope.Part3 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val3 === "Y") {

                $scope.Part3 = cDate.getFullYear();
            }
            else if (val3 === "Q") {
                $scope.Part3 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
            }
            else if (val3 === "R") {
                $scope.Part3 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getDate();
            }
            ////////////////////
            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;
        }
        $scope.ChangeDateSeparator = function () {
            if ($scope.CheckDateSeparator === true) {
                $scope.DateSeparators1 = $scope.DateSeparator.id;
            } else {
                $scope.DateSeparators1 = "";
            }
            var cDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
            ///////////////////
            var val1 = $scope.CodeForPart1.id;

            if (val1 === "D") {
                $scope.Part1 = cDate.getDate() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val1 === "M") {
                $scope.Part1 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val1 === "Q") {
                $scope.Part1 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
            }
            else if (val1 === "R") {
                $scope.Part1 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getDate();
            }
            ////////////////////

            var val2 = $scope.CodeForPart2.id;

            if (val2 === "D") {
                $scope.Part2 = cDate.getDate() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val2 === "M") {
                $scope.Part2 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val2 === "Q") {
                $scope.Part2 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
            }
            else if (val2 === "R") {
                $scope.Part2 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getDate();
            }
            ////////////////////

            var val3 = $scope.CodeForPart1.id;

            if (val3 === "D") {
                $scope.Part3 = cDate.getDate() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val3 === "M") {
                $scope.Part3 = cDate.getMonth() + $scope.DateSeparators1 + cDate.getFullYear();
            }
            else if (val3 === "Y") {

                $scope.Part3 = cDate.getFullYear();
            }
            else if (val3 === "Q") {
                $scope.Part3 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth();
            }
            else if (val3 === "R") {
                $scope.Part3 = cDate.getFullYear() + $scope.DateSeparators1 + cDate.getMonth() + $scope.DateSeparators1 + cDate.getDate();
            }
            ////////////////////
            $scope.FormatInvoiceNo = $scope.Part1 + $scope.Separators1 + $scope.Part2 + $scope.Separators2 + $scope.Part3;
        }
        function resetData() {

            $scope.CheckSeparator = false;
            $scope.CheckDateSeparator = false;
            $scope.sample = [];
            getCodeFor();
            $scope.part = [
                { id: "A", name: "Auto Number" }, { id: "I", name: "Initial" },
                { id: "D", name: "Date-Month-Year" },
                { id: "M", name: "Month-Year" }, { id: "Y", name: "Year" }, { id: "Q", name: "Year-Month" },
                { id: "R", name: "Year-Month-Date" }
            ];
            $scope.formateseperator = [
                { id: "-", name: "Hyphen(-)" }, { id: "/", name: "Forward Slash(/)" },
                { id: "\\", name: "Back Slash(\\)" }
            ];
            $scope.Separator = $scope.formateseperator[0];
            $scope.DateSeparator = $scope.formateseperator[0];
            $scope.CodeInitial = "";
            $scope.FormatInvoiceNo = "";
            $scope.query = "";
            $scope.search();
        }
        $scope.Reset = function () {
            resetData();
        }

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "InvoiceInitialName" || attr === "Sequence") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;

        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;
            $scope.sortingOrder = newSortingOrder;
        };

        function getinvoiceData() {
            var getData = InvConfigService.getinvData($scope.PropertyID);
            getData.then(function (invData) {
                $scope.$apply(function () {
                    $scope.items = invData.Collection;
                    $scope.search();
                });
            });
        };

        $scope.ChangeStatus = function (myform) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            myform.PropertyID = $scope.PropertyID;
            myform.ModifiedBy = $scope.UserName;
            var promiseGet = InvConfigService.statusChange(myform);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    msg(data.Message, true);
                    getinvoiceData();
                }
            },
            function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };

        //Delete Record
        $scope.removeRow = function (invoiceconfigData) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (invoiceconfigData != undefined) {

                                var removeData = InvConfigService.removeinitialCodeData(invoiceconfigData);
                                removeData.then(function (data) {
                                    msg(data.Message, true);
                                    $("html, body").animate({ scrollTop: 0 }, "slow");
                                    getinvoiceData();

                                },
                                    function (error) {
                                        msg(error.Message);
                                        $("html, body").animate({ scrollTop: 0 }, "slow");
                                    });
                            }
                            $.fancybox.close();
                        });
                }
            });


        }
    });
