﻿var apiPath = "https://duxposapi.azurewebsites.net/";
var Path = 'https://duxpos.azurewebsites.net/';
var reportApiPath = "http://127.0.0.1:86/";
var ReportXPath = "http://192.168.1.57:91/";


var YOUR_API_KEY = "AIzaSyB9qXBd0T2CLlv97B4Y2XelXHP10Rd1psw";

function GoToLogin() {

    var url = Path + "login.html";
    window.location.href = url;
    return;
};

function GoToHome() {
    var url = Path + "FO/DashBoard";
    window.location.href = url;
    return;
};

function SessionExpired() {

    window.location.href = Path + "login.html";
    return;
};

function ConvertDateToServerDate(date) {
    var momentObj = moment(date).format('YYYY-MM-DD');
    return momentObj; //server format
}


function GetServerDate(date, localformat) {
    var momentObj = moment(date, localformat.toUpperCase());
    return momentObj.format('YYYY-MM-DD'); //server format
}

function GetLocalDate(date, localformat) {
    var momentObj = moment(date, 'YYYY-MM-DD');
    return momentObj.format(localformat.toUpperCase());
}


function GetMomentDate(date, localformat) {
    return moment(date, localformat.toUpperCase());
}

//function GetMomentDate(date, localformat,adddays) {
//    return moment(date, localformat.toUpperCase()).add(adddays, 'days');
//}

function GetJavaScriptDate(date, localformat, adddays) {
    return moment(date, localformat.toUpperCase()).add(adddays, 'days').toDate();
}

function GetDayofWeek(date, localformat) {
    var dt = moment(date, localformat.toUpperCase());
    return dt.day();
}

function GetLocalTime(time, localformat, addMin) {
    var momentObj = moment(time, localformat);
    return moment(momentObj).add(addMin, 'minutes').format('HH:mm:ss');
}

function GetCalendarMinMaxDate(applicableFrom, localformat) {
    var cutOffDate = GetJavaScriptDate(applicableFrom, localformat, 0);
    return cutOffDate.getFullYear() + '/' + ('0' + (cutOffDate.getMonth() + 1)).slice(-2) + '/' + ('0' + cutOffDate.getDate()).slice(-2);
}

function GetDays(fromDate, toDate, localformat) {
    days = [];
    fromDate = GetMomentDate(fromDate, localformat);
    toDate = GetMomentDate(toDate, localformat);
    var duration = toDate.diff(fromDate, 'days')
    for (var i = 0; i <= duration ; i++) {
        var futureDate = moment(fromDate).add(i, 'days');
        days.push(futureDate);
    }
    return days;
};

//aMoment.isBefore(otherMoment);         //=> true or false
//aMoment.isAfter(otherMoment);            //=> true or false
//aMoment.compareTo(otherMoment);  //=> -1,0, or 1
