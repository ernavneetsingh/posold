﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');

        $scope.Model = {
            Id: '',
            UserName: '',
            Password: '',
            IsActive: '',
            Balance: '',
            
            PropertyID: '',
            ModifiedBy: '',
            
        };

        function GetByPropertyId() {
            var promiseGet = service.getByPropertyId($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Model = data.Data;
            },
                function (error) {
                    $scope.Model = {};
                    msg(error.Message);
                    scrollPageOnTop();
                });
        };
        GetByPropertyId();

        $scope.Save = function (form) {
            
            if ($scope[form].$valid) {

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                $scope.Model.ModifiedDate = $scope.ModifiedDate;
                var status = service.save($scope.Model);
                status.then(function (result) {
                    if (result.Status == true) {

                        GetByPropertyId();
                        msg($scope.Model.UserName + ' ' + result.Message, true);

                    }
                },
                function (error) {
                    scrollPageOnTop();
                    msg(error.Message);
                });
            }
            else
            {
                $scope.ShowErrorMessage = true;
            }
        }

    }
]);
