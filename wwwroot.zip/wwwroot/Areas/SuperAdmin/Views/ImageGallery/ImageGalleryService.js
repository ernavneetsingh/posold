﻿
app.service('ImageGalleryService', [
    '$http', '$q', function (
        $http, $q) {
        var service = this;

        service.init = function ($scope, pathToUpload) {

            service.pathToUpload = pathToUpload;

            $scope.file_changed = function (element, myfunc) {

                var photofile = element.files[0];
                var reader = new FileReader();
                reader.onload = function (e) {
                    return myfunc(e, element, photofile)
                };
                reader.readAsDataURL(photofile);
            };
            $scope.getTheFiles = function ($files, fd) {
                angular.forEach($files, function (value, key) {
                    fd.append(key, value);
                });
            };
            service.file_upload = function (fd) {

                return $http.post(apiPath + 'configuration/ImageGallery/Save?pathToUpload=' + service.pathToUpload, fd, {
                    withCredentials: false,
                    headers: { 'Content-Type': undefined, 'HotelLineApiKey': accessToken },
                    transformRequest: angular.identity
                }).then(function (d) {
                    msg(d.data.Message, d.data.Status);
                }).catch(function () {
                    msg('some error in uploading.');
                });

            }

        };
        service.getAll = function (options) {
            return httpCaller(apiPath + "configuration/ImageGallery/GetAll", $http, $q, options);
        };
    }
]);
