﻿
app.service("service", function ($http, $q) {

    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getData = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/amenities/all/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "FrontOffice/amenities/all/" + propertyId,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.save = function (amenitiesData) {
        return httpPoster(apiPath + "FrontOffice/amenities/create/modify", $http, $q, amenitiesData);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/amenities/create/modify",
        //    data: JSON.stringify(amenitiesData),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.remove = function (amenitiesData) {
        var url = apiPath + 'FrontOffice/amenities/remove/' + amenitiesData;
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);

        }).error(function (data, status, headers, config) {

            parent.failureMessage(data.Message);
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;

    };

    this.status = function (amenitiesData, currentUser) {
        var params = { amenitiesData: amenitiesData, currentUser: currentUser };
        return httpCaller(apiPath + "FrontOffice/amenities/changestatus", $http, $q, params);

    };

    this.GetRevenueHead = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/RevenueHead/revenuedetails/" + propertyId + '/1', $http, $q);
    };

    this.getAmenitieType = function () {
        return httpCaller(apiPath + "ReferenceConstant/AmenityType/All", $http, $q, {});
    };

    this.codeExists = function (amenitiesData, propertyId) {
        return httpPoster(apiPath + "FrontOffice/amenities/existcode/" + propertyId + "/" + amenitiesData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/amenities/existcode/" + propertyId + "/" + amenitiesData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    }
        //    ,
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);

        //    }
        //});

    };

});
