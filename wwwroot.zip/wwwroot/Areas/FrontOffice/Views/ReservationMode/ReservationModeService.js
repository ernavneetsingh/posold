﻿


app.service("reservationmodeService", function () {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getreservationmodeData = function (propertyId) {
        return httpCaller(apiPath + "reservationmode/allreservationmode/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "reservationmode/allreservationmode/" + propertyId,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.savereservmodeData = function (reservmodeData) {
        return httpPoster(apiPath + "reservationmode/create/modify", $http, $q, reservmodeData);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "reservationmode/create/modify",
        //    data: JSON.stringify(reservmodeData),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.removereservmodeData = function (reservmodeData) {
        return httpPoster(apiPath + "reservationmode/remove/" + reservmodeData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "reservationmode/remove/" + reservmodeData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.statusreservmodeData = function (reservmodeData, currentUser) {
        return httpPoster(apiPath + "reservationmode/changestatus/" + currentUser + "/" + reservmodeData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "reservationmode/changestatus/" + currentUser + "/" + reservmodeData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});

    };

    this.reservmodeDataExists = function (reservmodeData, propertyId) {
        return httpPoster(apiPath + "reservationmode/existcode/" + propertyId + "/" + reservmodeData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "reservationmode/existcode/" + propertyId + "/" + reservmodeData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    }
        //    ,
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});
    };
});
