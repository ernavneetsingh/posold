﻿
(function () {

    function occupationService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var _occupationData = [];

        var getAllOccupation = function (propertyId, options) {

            var url = apiPath +
                    "frontoffice/occupation/details/" +
                    propertyId +
                    "/?currentPage=" +
                    options.currentPage +
                    "&" +
                    "recordsPerPage=" +
                    options.recordsPerPage +
                    "&" +
                    "sortKey=" +
                    options.sortKeyOrder.key +
                    "&" +
                    "sortOrder=" +
                    options.sortKeyOrder.order +
                    "&searchfor=" +
                    options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                angular.copy(result.Collection, _occupationData);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var saveOccupation = function (module) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/Occupation/create",
                data: module,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        var updateOccupationStatus = function (occupationId, userName) {

            var url = apiPath + "FrontOffice/Occupation/status?occupationId=" + occupationId + "&userName=" + userName;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var deleteOccupation = function (occupationId) {

            var deferred = $q.defer();
            $http.post(apiPath + "FrontOffice/occupation/remove/" + occupationId)
                .then(function (result) {
                    deferred.resolve(result.data);
                }, function (e) {
                    deferred.reject(e.data);
                });

            return deferred.promise;
        };

        return {
            dataAllData: _occupationData,
            getAllOccupation: getAllOccupation,
            updateOccupationStatus: updateOccupationStatus,
            deleteOccupation: deleteOccupation,
            saveOccupation: saveOccupation
        };
    }

    app.factory("occupationService", ["$http", "$q", occupationService]);
})();
