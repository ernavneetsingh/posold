﻿"use strict";

app.controller("invoiceInitialController",
[
    "$scope", "invoiceInitialService", "localStorageService", "$cookies", function ($scope, invoiceInitialService, localStorageService, $cookies) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.InvoiceInitial = {};
        $scope.InvoiceInitial.IsActive = true;

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        getData($scope, invoiceInitialService, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, invoiceInitialService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, invoiceInitialService, localStorageService);
        };

        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, invoiceInitialService, localStorageService);
        };
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, invoiceInitialService, localStorageService);
        };
        $scope.ActionMode = "";
        $scope.editinvoiceInitial = function (item) {
            $scope.ActionMode = "Edit";
            $scope.InvoiceInitial = item;
            $scope.InvoiceInitial.InvoiceCodeId = item.InvoiceCodeId.toString();
            msg('');
        };
        $scope.reset = function () {
            $scope.InvoiceInitial = { IsActive: true };
            $scope.ActionMode = "";
            //            $scope.InvoiceInitial.IsActive = true;
            $scope.search();
            //$scope.searchfor = "";
            //localStorageService.set("searchfor", $scope.searchfor);
            //getData($scope, invoiceInitialService, localStorageService);
        };
        $scope.ShowErrorMessage = false;
        $scope.SaveinvoiceInitial = function (model, form) {
            if ($scope[form].$valid) {
                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.UserName;
                var promiseGet = invoiceInitialService.saveinvoiceInitial(model);
                promiseGet.then(function (data) {
                    getData($scope, invoiceInitialService, localStorageService);
                    $scope.reset();
                    parent.successMessage(data.Message);
                },
                    function (error) {
                        msg(error.Message);
                    });
            } else {
                $scope.ShowErrorMessage = true;
            }
        };

        $scope.Invoices = [];

        getAllInvoiceConfigruation();

        function getAllInvoiceConfigruation() {
            var promiseGet = invoiceInitialService.getAllinvoiceInitialConfiguration($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Invoices = data.Collection;
            },
                function (error) {
                    msg(error.Message);
                });
        }

        $scope.removeinvoiceInitial = function (invoiceInitialId) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this invoice Initial?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {
                            ret = true;
                            var deleteinvoiceInitial = invoiceInitialService.deleteinvoiceInitial(invoiceInitialId);
                            deleteinvoiceInitial.then(function (data) {

                                getData($scope, invoiceInitialService, localStorageService);
                                if (data.Status) {
                                    msg(data.Message, true);
                                }
                            },
                                function (err) {
                                    msg(err.Message);
                                });
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.changeinvoiceInitialStatus = function (invoiceInitialId) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var deleteinvoiceInitial = invoiceInitialService.updateinvoiceInitialStatus(invoiceInitialId, $scope.UserName);
            deleteinvoiceInitial.then(function (data) {

                if (data.Status) {
                    msg(data.Message, true);
                }
                getData($scope, invoiceInitialService, localStorageService);
            },
                function (err) {
                    msg(err.Message);
                });
        };
        $scope.selectCodeFor = function (invoiceInitialId) {
            $scope.InvoiceInitial = { IsActive: true };
            $scope.InvoiceInitial.InvoiceCodeId = invoiceInitialId;
            var promise = invoiceInitialService.getinitialcode($scope.PropertyID, invoiceInitialId);
            promise.then(function (data) {

                if (data.Collection.length > 0) $scope.editinvoiceInitial(data.Collection[0]);
            },
                function (err) {
                    msg(err.Message);
                });
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.data = dataService.dataAllData;
    $scope.ActionMode = "";
    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "InitialCode",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };

    $scope.showLoader = true;
    dataService.getAllinvoiceInitial($scope.PropertyID, options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                msg("The request failed. Unable to connect to the remote server.");
            });

};
