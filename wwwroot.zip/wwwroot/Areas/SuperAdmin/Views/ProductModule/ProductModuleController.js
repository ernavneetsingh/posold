﻿
app.controller('controller', ['$scope', 'service', 'localStorageService', function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = false;

    var sortKeyOrder = {
        key: '',
        order: '',
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 10;
    $scope.recordsPerPage = 10;
    $scope.numberOfPageButtons = 10;

    getData($scope, service, localStorageService);

    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get('sortKeyOrder');
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order === 'ASC')
                sortKeyOrder.order = 'DESC';
            else
                sortKeyOrder.order = 'ASC';
            localStorageService.set('sortKeyOrder', sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: 'ASC'
            };
            localStorageService.set('sortKeyOrder', sortKeyOrder);
        }
    };

    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };

    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    };

    $scope.Reset = function () {
        //$scope.Model = {};
        //$scope.Model.IsActive = false;
        //$scope.ModulesListItem = [];

        $scope.SelectedModelProduct = [];
        $scope.SelectedModelModules = [];
    };

    $scope.Edit = function (model) {
        $scope.Model.Id = model.Id;
        $scope.Model.Name = model.Name;
        $scope.Model.Code = model.Code;
        $scope.Model.Description = model.Description;
        $scope.IsReadonly = true;
        $scope.Model.ApplicableFrom = $filter('date')(model.ApplicableFrom, $scope.DateFormat);
        $scope.Model.IsActive = model.IsActive;
        scrollPageOnTop();
    }
    $scope.ShowErrorMessage = false;
    $scope.Save  = function (model, form) {
        
        if ($scope[form].$valid) {
            if ($scope.SelectedModelProduct != null) {

                $scope.Model = $scope.SelectedModelProduct;
                $scope.Model.Modules = $scope.SelectedModelModules;

                var promiseGet = service.save($scope.Model);
                promiseGet.then(function (data) {

                    $scope.Reset();
                    getData($scope, service, localStorageService);
                    parent.successMessage(data.Message);

                },
                    function (data) {
                        parent.failureMessage(data.Message);
                    });
            } else {
                $('#multiSelectModule').addClass("danger");
            }
        } else {
            $scope.ShowErrorMessage = true;
        }
    };


    $scope.Products = [];
    $scope.Modules = [];

    GetAllProducts();
    GetAllModels();


    function GetAllProducts() {
        
        var promiseGet = service.getAllProducts();
        promiseGet.then(function (data) {
            $scope.Products = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
        });
    }

    function GetAllModels() {
        var promiseGet = service.getAllModules();
        promiseGet.then(function (data) {
            $scope.Modules = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
        });
    }


    $scope.ChangeStatus = function (id) {
        
        var promiseGet = service.ChangeStatus(id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.SelectedModelProduct = [];
    $scope.SelectedModelModules = [];
    $scope.MultiSelectSettings = {
        scrollableHeight: '300px',
        scrollable: true,
        enableSearch: true,
        displayProp: 'Name'
    };

    if ($scope.SelectedModelModules.length > 0) {
        //$('#multiSelectModule').removeClass("danger");
    }


    $scope.ProductChange = function (selectedModelProduct) {
        

        $scope.SelectedModelProduct = [];
        $scope.SelectedModelModules = [];

        if (selectedModelProduct != null)
        {
            $scope.SelectedModelProduct = selectedModelProduct;
            $scope.SelectedModelModules = selectedModelProduct.Modules;
        }
    }


}]);


var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get('sortKeyOrder');
    if (sortKeyOrder === null) {
        sortKeyOrder = {
            key: 'Name',
            order: 'ASC'
        };
    }

    var searchfor = localStorageService.get('searchfor');
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };

    $scope.showLoader = true;
    dataService.getAll(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
        $scope.showLoader = false;
    },
    function () {
        parent.failureMessage("The request failed. Unable to connect to the remote server.");
    });

};