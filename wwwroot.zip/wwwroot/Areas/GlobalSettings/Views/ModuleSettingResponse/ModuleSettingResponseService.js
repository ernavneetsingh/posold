﻿
app.service('moduleSettingResponseService', function ($http, $q) {

    this.getModuleData = function () {
        return httpCaller(apiPath + "configuration/Module/all", $http, $q);
    };
    this.getAll = function (propertyId, moduleId) {
        var params = { propertyId: propertyId, moduleId: moduleId };
        return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/All", $http, $q, params);
    };
    this.getByModuleSetting = function (propertyId, moduleSettingId) {
        var params = { propertyId: propertyId, moduleSettingId: moduleSettingId };
        return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/get", $http, $q, params);
    };
    this.getByModuleSettingName = function (propertyId, moduleSettingName) {
        var params = { propertyId: propertyId, moduleSettingName: moduleSettingName };
        return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/get", $http, $q, params);
    };

    this.getLinkWithInventory = function ($scope, showMsg) {

        var promise = this.IsLinkedWithInventory($scope.PropertyID);
        promise.then(function (data, status) {
            $scope.IsLinkedWithInventory = data.Status && data.Data == "True";
        },
        function (error, status) {
            if (showMsg) msg(error.Message);
        });
    };
    this.IsLinkedWithInventory = function (propertyId) {
        var params = { propertyId: propertyId };
        return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/IsLinkedWithInventory", $http, $q, params);
    };
    this.IsCreditAllowedAfterLimit = function (propertyId) {
        var params = { propertyId: propertyId };
        return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/IsCreditAllowedAfterLimit", $http, $q, params);
    };

    this.save = function (model) {
        return httpPoster(apiPath + "GlobalSetting/ModuleSettingResponse/Save", $http, $q, model);
    };

});
