﻿
app.service('creditCardLinkService', function ($http, $q) {

    this.getNetworkList = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/CorporateCreditCardNetwork/allByPropertyId/" + propertyId, $http, $q);
    };
    this.getNetworkListSPA = function (propertyId) {
        
        return httpCaller(apiPath + "referencedata/CreditCardNetwork", $http, $q);
    };

    this.getCorporateByType = function (propertyId, corporateTypeId) {
        return httpCaller(apiPath + "GlobalSetting/Corporate/GetAllByCorporateTypeId/" + corporateTypeId + "/" + propertyId, $http, $q);
    }

    this.getList = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/CorporateCreditCardNetwork/allByPropertyId/" + propertyId, $http, $q);
    }
    this.save = function (model) {
        return httpPoster(apiPath + "GlobalSetting/CorporateCreditCardNetwork/save", $http, $q, model);
    };
    this.changeStatus = function (model) {
        return httpPoster(apiPath + "GlobalSetting/CorporateCreditCardNetwork/status", $http, $q, model);
    };

});
