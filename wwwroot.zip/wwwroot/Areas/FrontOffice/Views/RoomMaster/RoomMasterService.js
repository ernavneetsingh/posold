﻿
(function () {
    function roomMasterService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var linkModule = [];

        var getRoomMaster = function (options) {

            var url = apiPath + "FrontOffice/roommaster/GetAll?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getblockData(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/block/GetAllByPropertyId/?propertyId=" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        };

        function getroomFeatureData(propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roomfeatures/details/?propertyId=" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        };

        function getfloorData(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/floor/allByPropertyId/?propertyId=" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        };

        function GetAllMinByPropertyId(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/RoomMaster/GetAllMinByPropertyId/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        };

        function getroomtypseData(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/RoomType/GetAllByPropertyId/?propertyId=" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        };

        function getRoomMasterData(roomId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roommaster/details/" + roomId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getRoomMasterDetails(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roommaster/GetActive/" + propertyId + "/2",
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getRoomsByStatus(propertyId, status) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roommaster/all/" + propertyId + "/" + status,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getRoomGuests(propertyId, roomMasterId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckINGuest/GetRoomGuests/" + propertyId + "/" + roomMasterId,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getCodeExistRoomMaster(roomNumber, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roommaster/exist/" + roomNumber + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getExistRoomMaster(rooms, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roommaster/existroom/" + rooms + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function saveRoomMaster(roomMasterModel) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/roommaster/create",
                data: roomMasterModel,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        function updateIsActiveRoomMaster(model) {// roomId, isActive, propertyId, userName) {
            return httpPoster(apiPath + "FrontOffice/roommaster/ChangeStatus", $http, $q, model);

            //var deferred = $q.defer();
            //$http({
            //    method: "POST",
            //    url: apiPath + "FrontOffice/roommaster/ChangeStatus/" + roomId + "/" + isActive + "/" + propertyId + "/" + userName,
            //    data: {},
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8"
            //}).success(function (data, status, headers, cfg) {
            //    deferred.resolve(data);
            //}).error(function (err, status) {
            //    deferred.reject(status);
            //});
            //return deferred.promise;
        };

        function deleteRoomMaster(roomId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/roommaster/delete/" + roomId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var service = {
            getroomtypseData: getroomtypseData,
            dataAllData: linkModule,
            getRoomMaster: getRoomMaster,
            getCodeExistRoomMaster: getCodeExistRoomMaster,
            saveRoomMaster: saveRoomMaster,
            getRoomMasterData: getRoomMasterData,
            getRoomsByStatus: getRoomsByStatus,
            getRoomGuests: getRoomGuests,
            updateIsActiveRoomMaster: updateIsActiveRoomMaster,
            deleteRoomMaster: deleteRoomMaster,
            getblockData: getblockData,
            getfloorData: getfloorData,
            getroomFeatureData: getroomFeatureData,
            getExistRoomMaster: getExistRoomMaster,
            getRoomMasterDetails: getRoomMasterDetails,
            GetAllMinByPropertyId: GetAllMinByPropertyId,
        };
        return service;
    }

    app.factory("RoomMasterService", ["$http", "$q", roomMasterService]);
})();
