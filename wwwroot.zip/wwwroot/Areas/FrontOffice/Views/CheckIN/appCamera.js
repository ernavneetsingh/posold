﻿(function () {
    'use strict';
    angular.module('webcam', ['ng-webcam']);
})();

