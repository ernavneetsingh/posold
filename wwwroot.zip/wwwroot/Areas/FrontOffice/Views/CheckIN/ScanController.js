﻿
app.controller('ScanController', [
    '$scope', '$filter', '$cookies', 'CheckINService', '$window', 'localStorageService', '$http', '$rootScope', function (
        $scope, $filter, $cookies, checkINService, $window, localStorageService, $http, $rootScope) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');

        var businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        var businessDateStr = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
        $scope.MinDate = $scope.ModifiedDate;// date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);


        $scope.Document = {};
        $scope.IsScan = false;
        $scope.ScanAPIPath = "";

        $scope.$on("CallSetScanAPI", function (event, obj) {
            
            $scope.ScanAPIPath = obj.ScanAPIPath;
        });

        $scope.Scan = function () {
            
            $scope.IsScan = true;
            makeCorsRequest();

        }

        function createCORSRequest(method, url) {
            var xhr = new XMLHttpRequest();
            if ("withCredentials" in xhr) {
                // XHR for Chrome/Firefox/Opera/Safari.
                xhr.open(method, url, true);
                xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                xhr.setRequestHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            } else if (typeof XDomainRequest != "undefined") {
                // XDomainRequest for IE.
                xhr = new XDomainRequest();
                xhr.open(method, url);
                xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                xhr.setRequestHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            } else {
                // CORS not supported.
                xhr = null;
            }
            return xhr;
        }

        function getTitle(text) {
            return text.match('<title>(.*)?</title>')[1];
        }

        // Make  CORS request.
        function makeCorsRequest() {

            //var url = 'http://ttiscanner.com:8081/HttpListener/?id=455576677tgg';
            //var url = 'http://localhost:1698/api/Document/GetScanData';

            var xhr = createCORSRequest('GET', $scope.ScanAPIPath);
            if (!xhr) {
                //alert('CORS not supported');
                parent.popErrorMessage('CORS not supported');
                $scope.$apply(function () {
                    $scope.IsScan = false;
                });
                return;
            }

            // Response handlers.
            xhr.onload = function () {

                var text = xhr.responseText;
                //document.getElementById("resp").innerHTML = JSON.parse(text);
                var obj = JSON.parse(text);
                $scope.Document = obj.scan2PMS.SCANNEDINFO;
                $scope.$apply(function () {
                    $scope.IsScan = false;
                });
            };

            xhr.onerror = function () {
                //alert('There was an error making the request.');

                parent.popErrorMessage('There was an error making the request.');

                $scope.$apply(function () {
                    $scope.IsScan = false;
                });

            };

            xhr.send();
        }

        $scope.validateEmail1 = function (event) {
            // 
            if (event.currentTarget.value == "") {
                $(event.currentTarget).removeClass("error");
                //$(event.currentTarget).addClass("success");
                return false;
            }
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (expr.test((event.currentTarget.value)) == false) {
                event.currentTarget.value = "";
                //$(event.currentTarget).removeClass("success");
                $(event.currentTarget).addClass("error");
                return false;
            } else {
                //$(event.currentTarget).addClass("success");
                $(event.currentTarget).removeClass("error");
                return true;
            }
        };

        $scope.Accept = function () {
            
            var guest = {
                DocumentTypeName:$scope.Document.tti_type           ,
                Address1: $scope.Document.tti_address,
                Address2: $scope.Document.tti_address2,
                Address3: $scope.Document.tti_address3,
                City: $scope.Document.tti_city,
                CountryCode:$scope.Document.tti_countyshort    ,
                DOB: $scope.Document.tti_dob,
                ExpiryDate: $scope.Document.tti_expirationdate,
                //:$scope.Document.tti_eyes           ,
                ImageUrl: $scope.Document.tti_faceimage,
                //:$scope.Document.tti_fathername     ,
                //:$scope.Document.tti_hair           ,
                //:$scope.Document.tti_height         ,
                IssuePlace: $scope.Document.tti_poi ? $scope.Document.tti_poi : $scope.Document.tti_idcountry,
                IssueCountry: $scope.Document.tti_idcountry,
                //:$scope.Document.tti_image          ,
                IssueDate: $scope.Document.tti_issuedate,
                LicenseNo:$scope.Document.tti_license        ,
                //:$scope.Document.tti_mothername     ,
                Name: $scope.Document.tti_fullname ? $scope.Document.tti_fullname : $scope.Document.tti_firstname + ' ' + $scope.Document.tti_middlename + ' ' + $scope.Document.tti_lastname,
                //:$scope.Document.tti_firstname      ,
                //:$scope.Document.tti_lastname       ,
                //:$scope.Document.tti_middlename     ,
                Nationality: $scope.Document.tti_nationality2,
                PlaceofBirth: $scope.Document.tti_pob,
                IssuePlace: $scope.Document.tti_poi,
                GenderName: $scope.Document.tti_sex,
                SignatureUrl:$scope.Document.tti_signimage      ,
                StateName: $scope.Document.tti_state,
                //:$scope.Document.tti_weight         ,
                PIN: $scope.Document.tti_zip,
                CountryMasterName: $scope.Document.tti_county,
                //:$scope.Document.tti_udf1           ,
                //:$scope.Document.tti_udf2           ,
                //:$scope.Document.tti_udf3           ,
                //:$scope.Document.tti_udf4           ,
                //:$scope.Document.tti_udf5           ,
                //:$scope.Document.tti_county2        ,
                //:$scope.Document.tti_idnumber       ,
                Mobile: $scope.Document.tti_cell,
                EmailId: $scope.Document.tti_email,
                IssueCountry: $scope.Document.tti_countrylong ? $scope.Document.tti_countrylong : $scope.Document.tti_idcountry,
                PassportNo: $scope.Document.tti_passportnumber,
                //:$scope.Document.tti_personalnumber ,
                //:$scope.Document.tti_country2       ,
                VisaNo: $scope.Document.tti_visanumber,
                //:$scope.Document.tti_visatype       ,
            };

            guest.ImageModel = {
                Base64: $scope.Document.tti_faceimage,
                EntityName: 'Guest',
                PropertyID: $scope.PropertyID,
            };
            guest.PassportImageModel = {
                Base64: $scope.Document.tti_image,
                EntityName: 'Guest',
                PropertyID: $scope.PropertyID,
            };

            $rootScope.$broadcast("CallSaveGuestWithPassport", guest);

        }

        $scope.$on("CallCloseScanBox", function (event, obj) {
            $('#scanBox').modal('hide');
        });

        $scope.$on("CallResetScan", function (event, obj) {
            $scope.Document = {};
        });


    }
]);
