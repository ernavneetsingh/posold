﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        
        $scope.LoginId = $cookies.get('LoginId');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);

        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.GetCutOffDate = function () {
            $scope.CutOffDate = GetCalendarMinMaxDate($scope.Model.ApplicableFrom, $scope.DateFormat);
        }

        $scope.Model = {
            Id: '',
            ApplicableFrom: '',
            OutletType: '',
            OutletTypeId: '',
            OutletTypeName: '',
            ClassificationType: '',
            ClassificationTypeId: '',
            Code: '',
            Name: '',
            ImageUrl :'',
            ImageUrlForDisplay:'',
            CostCenterId: '',
            CostCenterName: '',
            IsTaxEnclusive: 'true',
            IsActive: true,
            KOTPrefix: '',
            BillPrefix: '',
            NCKOTPrefix: '',
            KOTInitializeType: '',
            KOTInitializeTypeId: '',
            KOTInitializeTypeName: '',
            KOTInitializeDate: '',
            BillInitializeType: '',
            BillInitializeTypeId: '',
            BillInitializeTypeName: '',
            BillInitializeDate: '',
            IsActivateDelivery: false,
            IsOnline: '',
            RoundOffType: '',
            RoundOffTypeId: '',
            RoundOffTypeName: '',
            KOTTypeMasters: [],
            NCDepartments: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: []
        };

        //-----------------------------
        $scope.APIPath = apiPath;
        $scope.file = "";
        $scope.IsUploading = false;
        $scope.ClearImage = function () {
            
            $scope.file = '';
            $scope.Model.ImageUrl = '';
            $scope.Model.UploadFile = '';
            scrollPageOnTop();
        };
        $scope.GetFileSize = function () {
            var size = parseFloat($scope.file.filesize) / 1024; //in kb
            size = $filter("number")(size, 2).replace(/,/g, "");
            $scope.fileSize = size.toString() + "KB";
        };
        //-----------------------------


        $scope.IsReadonly = false;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "Code" || attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {
            $scope.IsUploading = false;
            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {
                
                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   
                   msg(data.message);
               });

        };

        $scope.KOTType = [];
        getKOTType();
        function getKOTType() {
            var promiseGet = service.GetKOTType();
            promiseGet.then(function (data) {

                $scope.KOTType = data;
            },
                function (data) {
                    msg(data.message);
                });
        }

        $scope.Outlet = [];
        getOutletType();
        function getOutletType() {
            var promiseGet = service.GetOutletType();
            promiseGet.then(function (data) {

                $scope.Outlet = data;
            },
                function (data) {
                    msg(data.message);
                });
        }

        $scope.RoundOff = [];
        getRoundOff();
        function getRoundOff() {
            var promiseGet = service.GetRoundOff();
            promiseGet.then(function (data) {

                $scope.RoundOff = data;
            },
                function (data) {
                    msg(data.message);
                });
        }

        $scope.Classification = [];
        getClassification();
        function getClassification() {
            var promiseGet = service.GetClassification();
            promiseGet.then(function (data) {

                $scope.Classification = data;
            },
                function (data) {
                    msg(data.message);
                });
        }

        $scope.BillInitializeType = [];
        getBillInitializeType();
        function getBillInitializeType() {
            var promiseGet = service.GetBillInitializeType();
            promiseGet.then(function (data) {

                $scope.BillInitializeType = data;
            },
                function (data) {
                    msg(data.message);
                });
        }

        $scope.Costcenter = [];
        getCostcenter();
        function getCostcenter() {

            var promiseGet = service.GetCostCenter($scope.PropertyID, 1);
            promiseGet.then(function (data) {

                $scope.Costcenter = data;
            },
                function (data) {
                    msg(data.message);
                });
        }

        $scope.Save = function (model, form) {
            
            if ($scope[form].$valid) {

                //-----------------------------
                var ImageModel = {
                    Base64: $scope.file.base64,
                    FileName: $scope.file.filename,
                    FileSize: $scope.file.filesize,
                    FileType: $scope.file.filetype,
                    PropertyID: $scope.PropertyID,
                    EntityName: "Outlet"
                };
                if (ImageModel.Base64)
                {
                    $scope.IsUploading = true;
                    model.ImageModel = ImageModel;
                }
                //-----------------------------

                model.ApplicableFrom = GetServerDate(model.ApplicableFrom, $scope.DateFormat);
                model.KOTInitializeDate = GetServerDate(model.KOTInitializeDate, $scope.DateFormat);
                model.BillInitializeDate = GetServerDate(model.BillInitializeDate, $scope.DateFormat);

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                var status = service.save(model);

                status.then(function (result) {
                    if (result.Status == true) {
                        var msg1 = model.Name + result.Message;
                        msg(msg1, true);
                        getData();
                        scrollPageOnTop();
                    }
                    $scope.Reset();
                },
                function (error) {
                    
                    model.ApplicableFrom =  GetLocalDate(model.ApplicableFrom, $scope.DateFormat);
                    model.KOTInitializeDate = GetLocalDate(model.KOTInitializeDate, $scope.DateFormat);
                    model.BillInitializeDate = GetLocalDate(model.BillInitializeDate, $scope.DateFormat);

                    scrollPageOnTop();
                    msg(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }
        }
        $scope.Reset = function () {
            $scope.Model = {};
            $scope.Model.IsActive = true;
            $scope.Model.IsTaxEnclusive= 'true';
            $scope.IsReadonly = false;
            $scope.query = "";
            getData();
            scrollPageOnTop();
            $scope.ClearImage();
        }
        $scope.Edit = function (id) {
            
            $scope.IsUploading = false;
            var promiseGet = service.getById(id);
            promiseGet.then(function (data) {
                
                $scope.Model = data;

                //$scope.Model = model;
                //$scope.Model.Id = $scope.Model.Id;
                //$scope.Model.Name = $scope.Model.Name;
                //$scope.Model.Code = $scope.Model.Code;
                //$scope.Model.KOTPrefix = $scope.Model.KOTPrefix;
                //$scope.Model.BillPrefix = $scope.Model.BillPrefix;
                //$scope.Model.NCKOTPrefix = $scope.Model.NCKOTPrefix;

                $scope.Model.CostCenterId = $scope.Model.CostCenterId.toString();
                $scope.Model.OutletTypeId = $scope.Model.OutletTypeId.toString();
                $scope.Model.ClassificationTypeId = $scope.Model.ClassificationTypeId.toString();
                $scope.Model.IsTaxEnclusive = $scope.Model.IsTaxEnclusive.toString();
                $scope.Model.DonationAmount = $scope.Model.DonationAmount;
                $scope.Model.DonationRemark = $scope.Model.DonationRemark;
                $scope.Model.RoundOffTypeId = $scope.Model.RoundOffTypeId.toString();
                $scope.Model.KOTInitializeTypeId = $scope.Model.KOTInitializeType.toString();
                $scope.Model.BillInitializeTypeId = $scope.Model.BillInitializeType.toString();
                $scope.Model.ApplicableFrom = $filter('date')($scope.Model.ApplicableFrom, $scope.DateFormat);
                $scope.Model.KOTInitializeDate = $filter('date')($scope.Model.KOTInitializeDate, $scope.DateFormat);
                $scope.Model.BillInitializeDate = $filter('date')($scope.Model.BillInitializeDate, $scope.DateFormat);
                $scope.IsReadonly = true;
                $scope.Model.IsActive = $scope.Model.IsActive;
            },
               function (data) {

                   msg(data.message);
               });
            
           
            scrollPageOnTop();
        }
        $scope.Remove = function (model) {

            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            msg("Record Successfully deleted.", true);
                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    msg(data.Message, true);
                }
            },
            function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.IsCodeExist = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.isCodeExist($scope.PropertyID, model.Code);
            promiseGet.then(function (data) {
            },
                function (error) {

                    $scope.Model.Code = "";
                    msg(error.Message);
                    scrollPageOnTop();
                });
        };
        

    }
]);
