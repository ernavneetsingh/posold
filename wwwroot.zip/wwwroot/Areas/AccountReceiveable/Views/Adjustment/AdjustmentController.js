﻿
app.controller('AdjustmentController', function ($scope, $http, $filter, $window, $cookies, transactionService, periodCloseService, localStorageService) {

    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedBy = $cookies.get('UserName');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    //var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
    //$scope.MinDatess = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

    $scope.resetSearch = function () {
        $scope.Search = {};
    }
    $scope.resetHistory = function () {
        $scope.History = [];
    }
    $scope.resetCompany = function () {
        $scope.Company = {};
    }
    $scope.resetAdjustment = function () {
        $scope.Adjustment = {};
    }
    $scope.resetGrid = function () {
        $scope.Adjustments = [];
    }
    $scope.resetAll = function () {
        $scope.resetSearch();
        $scope.resetHistory();
        $scope.resetCompany();
        $scope.resetAdjustment();
        $scope.resetGrid();
    }
    $scope.resetAll();

    $scope.save = function (model, form) {

        if ($scope.Company === undefined || $scope.Company.Id === undefined || $scope.Company.Id === null) {
            msg('Please select company');
            return;
        }
        if (!$scope[form].$valid) {
            $scope.ShowErrorMessage = true;
            return;
        }
        if (!$scope.Adjustment.TransactionDateString) {
            msg('Please select adjustment date');
            return;
        }
        if (!$scope.Adjustment.BillFromId) {
            msg('Please select BillFrom');
            return;
        }
        if (!$scope.Adjustment.InvoiceDateString) {
            msg('Please select bill/invoice date');
            return;
        }
        if (!$scope.Adjustment.Amount || $scope.Adjustment.Amount === '0' || parseFloat($scope.Adjustment.Amount) === 0) {
            msg('Please enter some amount');
            return;
        }
        model.PropertyID = $scope.PropertyID;
        model.ModifiedBy = $scope.ModifiedBy;
        model.ModifiedDate = $scope.ModifiedDate;
        model.CorporateId = $scope.Company.Id;
        model.TransactionTypeId = '0';

        var saveData = transactionService.save(model, '', '');
        saveData.then(function (data) {

            if (data.Status) {
                msg('Adjustment successfully saved.', true); //$window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                $scope.resetAdjustment();
                $scope.getRecent();
            }
        });
    };
    $scope.delete = function (id) {

        var strDelete = DeletePopup('Are you sure you want to delete this?');
        var ret;
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $('#fancyconfirm_cancel')
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $('#fancyConfirm_ok')
                    .click(function () {
                        ret = true;
                        $.fancybox.close();

                        var promise = transactionService.delete(id, $scope.ModifiedBy, $scope.PropertyID);
                        promise.then(function (data) {
                            if (data != null) {

                                parent.successMessage('Adjustment Deleted Successfully');
                                $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                                $scope.getRecent();
                            }
                        });

                    });
            }
        });
    };
    $scope.getAutoSuggest = function (item, txt) {
        var promiseSuggest = transactionService.suggest($scope.PropertyID, item, txt);
        promiseSuggest.then(function (data, status) {
            $('#txtSearch' + item).autocomplete({
                source: function (request, response) {
                    response($.map(data.Data.Suggestions, function (ret) {
                        return {
                            label: ret,
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {
                    if (ui.item) {
                        if (txt !== 'Bank') {
                            var promiseSearch = transactionService.search($scope.PropertyID, item, ui.item.val, $scope.DateFormat);
                            promiseSearch.then(function (data, status) {

                                $scope.load(data);
                            });
                            //} else {
                            //    Get_BankDetail(ui.item.value, txt);
                        }
                    }
                },
                minLength: 1
            });
        });
    };
    $scope.getRecent = function () {
        var promise = transactionService.search($scope.PropertyID, 'CorporateId', $scope.Company.Id, $scope.DateFormat);
        promise.then(function (data, status) {

            $scope.load(data);
        });
    };
    $scope.load = function (data) {
        // $scope.resetAll();
        $scope.Company = data.Data;
        $scope.Adjustments = data.Data.Adjustments;
        $scope.History = data.Data.History;

    };

    function getDefaults() {
        var promiseGet = transactionService.GetDefaults($scope.PropertyID);
        promiseGet.then(function (data, status) {

            if (data.Status) {
                $scope.defaultData = data.Data;
            }
        },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
    };
    getDefaults();

    $scope.fillData = function (record) {
        

        $scope.Adjustment = {};
        //var tDate = formatDMYDate(record.TransactionDateString);
        //var minDate = new Date($scope.MinDate);
        if (record.TransactionDateString < $scope.MinDate) {
            //if (tDate.getTime() < minDate.getTime()) {
            msg('This adjustment cannot be edited because period is closed.');
            return;
        }

        $scope.Adjustment = record;
        $scope.IsReadonly = true;
        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
    };

    periodCloseService.getStartPeriod($scope); //transactionService.closePeriodDate($scope);
    $scope.TransactionDateChange = function () {
        
        $scope.MaxInvoiceDate = $filter('date')($scope.Adjustment.TransactionDateString, 'yyyy-MM-dd');// $scope.DateFormat);
        if ($scope.Adjustment.InvoiceDateString !== undefined && $scope.Adjustment.InvoiceDateString.length > 1) $scope.Adjustment.InvoiceDateString = '';
    }
});
