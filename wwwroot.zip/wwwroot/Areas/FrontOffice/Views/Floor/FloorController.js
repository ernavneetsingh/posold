﻿
app.controller("FloorController",
    function ($scope, $http, $filter, floorService, $window, $cookies, localStorageService) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.Model = {
            Id: "",
            Code: "",
            Name: "",
            Description: "",
            IsActive: true,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName
        };


        $scope.IsActive = true;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
        getfloorData();

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "Code" || attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;

        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        $scope.Save = function (form) {

            if ($scope[form].$valid) {

                var floorData = new Object();
                floorData.Id = $scope.Model.Id;
                floorData.Code = $scope.Model.Code;
                floorData.Name = $scope.Model.Name;
                floorData.Description = $scope.Model.Description;
                floorData.IsActive = $scope.Model.IsActive;

                floorData.PropertyID = $scope.PropertyID;
                floorData.ModifiedBy = $scope.UserName;

                var saveData = floorService.save(floorData);
                saveData.then(function (data) {

                    $scope.Reset();

                    getfloorData();
                    msg(data.Message, true);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }


        };
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.Model.Code = "";
            $scope.Model.Name = "";
            $scope.Model.Description = "";
            $scope.Model.IsActive = true;
            $scope.Model.Id = "";
            $scope.IsReadonly = false;
            $scope.query = "";
            $scope.search();
        };

        function getfloorData() {
            $scope.ActionMode = "";
            var getData = floorService.getData($scope.PropertyID);
            getData.then(function (floordata) {
                $scope.$apply(function () {
                    $scope.items = floordata.Collection;
                    $scope.search();
                });
            });
        };
        $scope.activeRow = function (floordata) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var statusData = floorService.status(floordata, $scope.UserName);
            statusData.then(function (data) {
                getfloorData();
                msg(data.Message, true);
            });
        };
        $scope.removeRow = function (floordata) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (floordata != undefined) {

                                var removeData = floorService.remove(floordata);
                                removeData.then(function (data) {
                                    msg(data.Message, true);
                                    //$("html, body").animate({ scrollTop: 0 }, "slow");
                                    getfloorData();

                                }, function (error) {
                                    msg(error.Message);
                                    //$("html, body").animate({ scrollTop: 0 }, "slow");
                                });
                            }
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.txtFloorCodes = function () {
            var floorCode = floorService.Exists($scope.Model.Code, $scope.PropertyID);
            floorCode.then(function (data) {

            }, function (error) {
                //error handler function

                $scope.$apply(function () {
                    $scope.Model.Code = "";
                });

            });
        };
        $scope.fillFloorData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.Model.Code = record.Code;
            $scope.Model.Name = record.Name;
            $scope.Model.Description = record.Description;
            $scope.Model.IsActive = record.IsActive;
            $scope.Model.Id = record.Id;
            $scope.IsReadonly = true;
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        };
    });
