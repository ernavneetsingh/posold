﻿app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');

        $scope.LoginId = $cookies.get('LoginId');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.ChangeFromDate = function () {

            $scope.MinDateForToDate = GetCalendarMinMaxDate($scope.Model.FromDate, $scope.DateFormat);
            $scope.DayInRangeValidation();
        }

        //$('#txtFromTime').timepicker({ 'timeFormat': 'h:i A' });
        //$('#txtToTime').timepicker({ 'timeFormat': 'h:i A' });

        $scope.Model = {
            Id: '',
            OutletId: '',
            OutletName: '',
            DiscountType: 'Amount',
            DiscountTypeId: 1,
            DiscountTypeName: '',
            DiscountValue: '',
            Name: '',
            FromDate: '',
            FromTime: '',
            ToDate: '',
            ToTime: '',
            IsWeek: '',
            IsMonday: false,
            IsTuesday: false,
            IsWednesday: false,
            IsThursday: false,
            IsFriday: false,
            IsSaturday: false,
            IsSunday: false,
            FromHr: '',
            FromMin: '',
            From: '',
            ToHr: '',
            ToMin: '',
            To: '',
            FromTimeString: '',
            ToTimeString: '',
            ToDateString: '',
            FromDateString: '',
            IsActive: true,
            HappyHourItems: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: []
        };

        $scope.HappyHourItem = {
            Id: '',
            HappyHourId: '',
            HappyHourName: '',
            POSItemId: '',
            POSItemCode: '',
            POSItemName: '',
            HappyHourRate: '',
            Rate: '',
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
        };

        $scope.MenuCategory = "MenuCategory";
        $scope.MenuSubCategory = "MenuSubCategory";
        $scope.ItemMaster = "ItemMaster";
        $scope.MenuType = "MenuType";

        $scope.ShowErrorMessage = false;

        $scope.IsReadonly = false;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }


            angular.forEach($scope.pagedItems, function (items) {
                angular.forEach(items, function (item) {
                    item.FromDate = $filter('date')(item.FromDate, $scope.DateFormat);
                    item.ToDate = $filter('date')(item.ToDate, $scope.DateFormat);
                });
            });

        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };


        getOutlet();

        getData();
        function getData() {
            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   msg(data.message);
               });

        };

        GetWeekDays();
        function GetWeekDays() {
            var promiseGet = service.getWeekDays();
            promiseGet.then(function (data) {

                $scope.Days = data;
            },
               function (data) {
                   msg(data.message);
               });

        };

        //checklist-model------------------------------------------------------------------------------------
        $scope.Days = [];

        $scope.SelectedDay = {
            Days: []
        };
        $scope.checkAllDay = function () {

            $scope.SelectedDay.Days = $scope.Days.map(function (item) { return item.Id; });
            $scope.DayInRangeValidation();
        };
        $scope.uncheckAllDay = function () {
            $scope.SelectedDay.Days = [];
        };
        $scope.checkFirstDay = function () {
            $scope.SelectedDay.Days.splice(0, $scope.SelectedDay.Days.length);
            $scope.SelectedDay.Days.push(1);
            $scope.DayInRangeValidation();
        };


        $scope.FilterItems = [];

        $scope.SelectedFilterItem = {
            FilterItems: []
        };
        $scope.checkAllFilterItem = function () {

            $scope.SelectedFilterItem.FilterItems = $scope.FilterItems.map(function (item) { return item.Id; });
        };
        $scope.uncheckAllFilterItem = function () {
            $scope.SelectedFilterItem.FilterItems = [];
        };
        $scope.checkFirstFilterItem = function () {
            $scope.SelectedFilterItem.FilterItems.splice(0, $scope.SelectedFilterItem.FilterItems.length);
            $scope.SelectedFilterItem.FilterItems.push(1);
        };


        //end checklist-model------------------------------------------------------------------------------------

        $scope.Save = function (form) {



            if ($scope[form].$valid) {

                var model = $scope.Model;

                if (model.Id && model.Id.length > 0) {
                    msg("Happy Hour can not be modifed.");
                    scrollPageOnTop();
                    return;
                }

                angular.forEach($scope.SelectedDay.Days, function (id) {

                    switch (id) {
                        case '1':
                            model.IsMonday = true;
                            break;
                        case '2':
                            model.IsTuesday = true;
                            break;
                        case '3':
                            model.IsWednesday = true;
                            break;
                        case '4':
                            model.IsThursday = true;
                            break;
                        case '5':
                            model.IsFriday = true;
                            break;
                        case '6':
                            model.IsSaturday = true;
                            break;
                        case '7':
                            model.IsSunday = true;
                            break;
                        default:
                    }


                });

                if (!model.IsMonday && !model.IsTuesday && !model.IsWednesday && !model.IsThursday && !model.IsFriday && !model.IsSaturday && !model.IsSunday) {
                    msg("Please Select Day");
                    scrollPageOnTop();
                    return;
                }

                model.HappyHourItems = [];
                angular.forEach($scope.POSItems, function (item) {
                    if (item.IsChecked) {
                        model.HappyHourItems.push(item);
                    }

                });

                if (model.HappyHourItems.length == 0) {
                    msg("Please add Happy Hour Item(s).");
                    scrollPageOnTop();
                    return;
                }

                if (model.DiscountValue == 0) {
                    msg("Discount Value can't be zero.");
                    scrollPageOnTop();
                    return;
                }
                if (model.DiscountValue > 100 && model.DiscountTypeId == "2") {
                    msg("Discount Value can't be greater then 100.");
                    scrollPageOnTop();
                    return;
                }



                model.FromDate = GetServerDate(model.FromDate, $scope.DateFormat);
                model.ToDate = GetServerDate(model.ToDate, $scope.DateFormat);

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;

                var status = service.save(model);
                status.then(function (result) {
                    if (result.Status == true) {
                        var msg1 = model.Name + ' ' + result.Message;
                        msg(msg1, true);
                        getData();
                    }
                    $scope.Reset();
                }, function (error) {

                    model.FromDate = GetLocalDate(model.FromDate, $scope.DateFormat);
                    model.ToDate = GetLocalDate(model.ToDate, $scope.DateFormat);

                    scrollPageOnTop();
                    msg(error.Message);
                });


            } else {
                scrollPageOnTop();
                $scope.ShowErrorMessage = true;
            }

        }
        $scope.Reset = function () {
            $scope.Model = {};
            $scope.Model.IsActive = true;

            $scope.Model.IsMonday = false;
            $scope.Model.IsTuesday = false;
            $scope.Model.IsWednesday = false;
            $scope.Model.IsThursday = false;
            $scope.Model.IsFriday = false;
            $scope.Model.IsSaturday = false;
            $scope.Model.IsSunday = false;

            $scope.EditMode = false;
            $scope.IsReadonly = false;
            $scope.Model.DiscountTypeId = "1";
            $scope.POSItems = [];
            $scope.HappyHourItems = [];
            $scope.IsChkAll = false;
            $scope.FilterBy = 'MenuType';
            $scope.FilterItem('MenuType');
            $scope.SelectedDay.Days = [];
            $scope.FilterItems = [];
            $scope.query = "";
            getData();
            scrollPageOnTop();
        }

        $scope.ResetCheckAll = function () {
            $scope.IsChkAll = false;
            $scope.CalculateDiscountRate($scope.Model.DiscountValue);
        }

        $scope.Remove = function (model) {
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            msg("Happy Hour successfully deleted.", true);
                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    msg(data.Message, true);
                }
            },
            function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };

        $scope.SelectedUnitTypeId = "";

        $scope.HappyHourItems = [];
        $scope.Edit = function (model) {

            scrollPageOnTop();
            $scope.HappyHourItems = [];
            $scope.POSItems = [];
            $scope.Model = model
            $scope.Model.FromDate = $filter('date')(model.FromDate, $scope.DateFormat);
            $scope.Model.ToDate = $filter('date')(model.ToDate, $scope.DateFormat);

            //$scope.Model.FromTime = model.FromTimeString;
            //$scope.Model.ToTime = model.ToTimeString;

            angular.forEach(model.HappyHourItems, function (item) {
                $scope.HappyHourItems.push(item);
                var posItem = {
                    IsChecked: true,
                    //Id: item.POSItemId,
                    POSItemId: item.POSItemId,
                    Code: item.POSItemCode,
                    Name: item.POSItemName,
                    HappyHourRate: item.HappyHourRate,
                    Rate: item.Rate,
                    IsLevelItem: item.IsLevelItem,
                };
                $scope.POSItems.push(posItem);
            });


            if (model.IsMonday)
                $scope.SelectedDay.Days.push("1");
            if (model.IsTuesday)
                $scope.SelectedDay.Days.push("2");
            if (model.IsWednesday)
                $scope.SelectedDay.Days.push("3");
            if (model.IsThursday)
                $scope.SelectedDay.Days.push("4");
            if (model.IsFriday)
                $scope.SelectedDay.Days.push("5");
            if (model.IsSaturday)
                $scope.SelectedDay.Days.push("6");
            if (model.IsSunday)
                $scope.SelectedDay.Days.push("7");



            $scope.EditMode = true;
            $scope.IsReadonly = true;

        }

        //----------------For Get MenuType , MenuCategory, MenuSubCategory---------------------------------


        $scope.GetPOSItemByFilterItem = function (FilterBy, id) {

            if ($scope.Model.OutletId == undefined || $scope.Model.OutletId == "") {
                $scope.SelectedFilterItem.FilterItems = [];
                msg("Please Select Outlet.");
                scrollPageOnTop();
                return;
            }

            $scope.IsChkAll = false;
            $scope.POSItems = [];
            
            angular.forEach($scope.SelectedFilterItem.FilterItems, function (id) {
                if (FilterBy == $scope.MenuType) {
                    var promise = service.getAllByMenuGroupType(id, $scope.Model.OutletId, $scope.PropertyID);
                    promise.then(function (data) {
                        angular.forEach(data, function (item) {
                            
                            var hhItem = {};
                            if (!item.IsLevelItem)
                            {
                                hhItem = {
                                    IsChecked: false,
                                    HappyHourId: '',
                                    POSItemId: item.Id,
                                    Code: item.Code,
                                    Name: item.Name,
                                    HappyHourRate: 0,
                                    Rate: item.OutletItemRate,
                                    IsLevelItem: item.IsLevelItem,
                                };

                                $scope.POSItems.push(hhItem);
                            }
                            else
                            {
                                angular.forEach(item.LevelItems, function (levelItem) {
                                    hhItem = {
                                        IsChecked: false,
                                        HappyHourId: '',
                                        POSItemId: levelItem.Id,
                                        Code: item.Code + " / " + levelItem.Code ,
                                        Name: item.Name + " / " + levelItem.Name,
                                        HappyHourRate: 0,
                                        //Rate: item.OutletItemRate,
                                        Rate: levelItem.LevelItemRate,
                                        ParentId: item.Id,
                                    };

                                    $scope.POSItems.push(hhItem);
                                });

                                
                            }
                            

                            
                        });
                    },
                        function (err) {
                            parent.failureMessage(err.data.Message);
                            scrollPageOnTop();
                        });
                }
                else if (FilterBy == $scope.MenuCategory) {
                    var promise = service.getAllByMenuCategoryId(id, $scope.Model.OutletId, $scope.PropertyID);
                    promise.then(function (data) {
                        angular.forEach(data, function (item) {
                            var hhItem = {
                                IsChecked: false,
                                HappyHourId: '',
                                POSItemId: item.Id,
                                Code: item.Code,
                                Name: item.Name,
                                HappyHourRate: 0,
                                Rate: item.OutletItemRate,
                                IsLevelItem: item.IsLevelItem,
                            };
                            $scope.POSItems.push(hhItem);
                        });
                    },
                        function (err) {
                            parent.failureMessage(err.data.Message);
                            scrollPageOnTop();
                        });
                }
                else if (FilterBy == $scope.MenuSubCategory) {
                    var promise = service.getAllByMenuSubCategoryId(id, $scope.Model.OutletId, $scope.PropertyID);
                    promise.then(function (data) {
                        angular.forEach(data, function (item) {
                            var hhItem = {
                                IsChecked: false,
                                HappyHourId: '',
                                POSItemId: item.Id,
                                Code: item.Code,
                                Name: item.Name,
                                HappyHourRate: 0,
                                Rate: item.OutletItemRate,
                                IsLevelItem: item.IsLevelItem,
                            };
                            $scope.POSItems.push(hhItem);
                        });
                    },
                        function (err) {
                            parent.failureMessage(err.data.Message);
                            scrollPageOnTop();
                        });
                }
            });


        };

        $scope.FilterItem = function (itemType) {

            $scope.SelectedFilterItem.FilterItems = [];
            $scope.FilterItems = [];
            $scope.POSItems = [];

            if (itemType === $scope.MenuType) {
                var promise = service.GetMenuGroup();
                promise.then(function (data) {
                    $scope.FilterItems = data;
                },
                    function (err) {

                        msg(err.data.Message);
                        scrollPageOnTop();
                    });
            }
            else if (itemType === $scope.MenuCategory) {

                var promise = service.GetMenuCategory($scope.PropertyID);
                promise.then(function (data) {
                    $scope.FilterItems = data;
                },
                    function (err) {

                        msg(err.data.Message);
                        scrollPageOnTop();
                    });
            }
            else if (itemType === $scope.MenuSubCategory) {

                var promise = service.GetMenuSubCategory($scope.PropertyID);
                promise.then(function (data) {
                    $scope.FilterItems = data;
                },
                    function (err) {

                        msg(err.data.Message);
                        scrollPageOnTop();
                    });
            }
            else if (itemType === $scope.ItemMaster) {
                $scope.FilterTypeId = null;

                if ($scope.Model.OutletId != undefined && $scope.Model.OutletId != "") {

                    var items = service.getItems($scope.Model.OutletId, $scope.PropertyID);
                    items.then(function (data) {

                        angular.forEach(data, function (item) {

                            var hhItem = {
                                IsChecked: false,
                                HappyHourId: '',
                                POSItemId: item.Id,
                                Code: item.Code,
                                Name: item.Name,
                                HappyHourRate: 0,
                                Rate: item.OutletItemRate,
                                IsLevelItem: item.IsLevelItem,
                            };

                            $scope.POSItems.push(hhItem);

                        });
                    },
                        function (err) {

                            msg(err.data.Message);
                            scrollPageOnTop();
                        });
                }
                else {
                    $("#checkedFilterRecord").attr("checked", false);
                    msg("Please Select Outlet.");
                    scrollPageOnTop();
                }
            }
            else { };

            $scope.FilterTypeValue = itemType;
        };
        $scope.POSItems = [];
        $scope.Reset();

        //------------For Outlet----------------------
        $scope.Outlets = [];
        function getOutlet() {
            var promiseGet = service.GetOutlet($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Outlets = data;
            },
                function (data) {

                    msg(data.message);
                });
        }

        //------------For Filter Item From Servicea and 1st data Bind------------------
        $scope.CheckedFilterData = [];
        $scope.getAllItem = function ($event) {

            if ($event.target.checked) {

                angular.forEach($scope.FilterItemData, function (itm) {

                    $scope.CheckedFilterData.push({ Id: itm.Id });
                });
            }
            if (!$event.target.checked) {

                $scope.CheckedFilterData = [];
            }

            if ($scope.CheckedFilterData.length > 0) {

                $scope.FilterTypeId = null;
                if ($scope.Model.OutletId != undefined && $scope.Model.OutletId != "") {

                    var items = service.getItems(2, $scope.Model.OutletId, $scope.PropertyID);
                    items.then(function (data) {

                        angular.forEach(data, function (item) {

                            var hhItem = {
                                IsChecked: false,
                                HappyHourId: '',
                                POSItemId: item.Id,
                                Code: item.Code,
                                Name: item.Name,
                                HappyHourRate: 0,
                                Rate: item.OutletItemRate,
                                IsLevelItem: item.IsLevelItem,
                            };
                            $scope.POSItems.push(hhItem);
                        });

                    },
                        function (err) {

                            parent.failureMessage(err.data.Message);
                            scrollPageOnTop();
                        });
                } else {
                    $("#checkedFilterRecord").attr("checked", false);
                    $scope.CheckedFilterData = [];
                    parent.failureMessage("Please select Outlet code first....");
                }
            }

        };

        //---------For check Days---Third Div----------------------------------
        $scope.CheckedAllApplicableDays = function ($event) {


            if ($event.target.checked) {
                $("#Sunday").prop("checked", true);
                $("#Monday").prop("checked", true);
                $("#Tuesday").prop("checked", true);
                $("#Wednesday").prop("checked", true);
                $("#Thursday").prop("checked", true);
                $("#Friday").prop("checked", true);
                $("#Saturday").prop("checked", true);
                $scope.Model.IsSunday = true;
                $scope.Model.IsMonday = true;
                $scope.Model.IsTuesday = true;
                $scope.Model.IsWednesday = true;
                $scope.Model.IsThursday = true;
                $scope.Model.IsFriday = true;
                $scope.Model.IsSaturday = true;

            }
            if (!$event.target.checked) {
                $("#Sunday").prop("checked", false);
                $("#Monday").prop("checked", false);
                $("#Tuesday").prop("checked", false);
                $("#Wednesday").prop("checked", false);
                $("#Thursday").prop("checked", false);
                $("#Friday").prop("checked", false);
                $("#Saturday").prop("checked", false);
                $scope.Model.IsSunday = false;
                $scope.Model.IsMonday = false;
                $scope.Model.IsTuesday = false;
                $scope.Model.IsWednesday = false;
                $scope.Model.IsThursday = false;
                $scope.Model.IsFriday = false;
                $scope.Model.IsSaturday = false;
            }
        }
        $scope.checkWeekDay = function () {


            $scope.Model.IsWeek = $scope.Model.IsSunday
               && $scope.Model.IsMonday
               && $scope.Model.IsTuesday
               && $scope.Model.IsWednesday
               && $scope.Model.IsThursday
               && $scope.Model.IsFriday
               && $scope.Model.IsSaturday
            ;
        }

        //-----------For DiscountRate TextBox/////Remain-------------------------------
        $scope.CalculateDiscountRate = function (rate) {

            if (!rate) {
                $scope.Model.DiscountValue = 0;
                rate = 0;
            }

            $scope.Model.DiscountValue = parseFloat($scope.Model.DiscountValue);

            if ($scope.Model.DiscountTypeId == "1") {

                //check for hire price 
                var isHireValue = true;
                angular.forEach($scope.POSItems, function (data) {

                    if (parseFloat(data.Rate) >= parseFloat(rate)) {
                        isHireValue = false;
                    }

                });

                if (isHireValue) {

                    $scope.Model.DiscountValue = 0;
                    $scope.CalculateDiscountRate(0);
                    parent.failureMessage("Discount amount cann't be greater then Item Rate.");
                    scrollPageOnTop();
                    return;
                }

                angular.forEach($scope.POSItems, function (data) {
                    data.HappyHourRate = 0;
                    if (data.IsChecked) {
                        var newRate = (parseFloat(data.Rate) - parseFloat(rate));
                        if (newRate < 0) {
                            data.HappyHourRate = 0;
                        } else {
                            data.HappyHourRate = newRate;
                        }
                    }

                });
            }
            if ($scope.Model.DiscountTypeId == "2") {


                if (parseFloat($scope.Model.DiscountValue) > 100) {

                    $scope.Model.DiscountValue = 0;
                    $scope.CalculateDiscountRate(0);
                    parent.failureMessage("Discount percentage cann't be greater then 100.");
                    scrollPageOnTop();
                    return;
                }


                angular.forEach($scope.POSItems, function (data) {
                    data.HappyHourRate = 0;
                    if (data.IsChecked) {

                        var newRate = (parseFloat(data.Rate) - ((parseFloat(data.Rate) * parseFloat(rate)) / 100));
                        if (newRate < 0) {
                            data.HappyHourRate = 0;
                        } else {
                            data.HappyHourRate = newRate;
                        }

                    }

                });
            }

        };

        //---2222222222222222222-----------For First Table Method----------------------------
        $scope.Model.HappyHourItems = [];
        $scope.CheckAll = function ($event) {

            if ($event.target.checked) {
                $scope.IsChkAll = true;
                angular.forEach($scope.POSItems, function (itm) {

                    itm.IsChecked = true;

                });
            }
            if (!$event.target.checked) {
                $scope.IsChkAll = false;
                angular.forEach($scope.POSItems, function (itm) {

                    itm.IsChecked = false;

                });
            }


            $scope.CalculateDiscountRate($scope.Model.DiscountValue);
        };

        //-----------------------------------------

        $scope.Model.DiscountTypeId = 1;
        setTimeout(function () {
            $scope.Model.DiscountTypeId = "1";
        }, 300);


        $scope.IsAllItemChecked = true;

        function removeFromList(list, id) {
            angular.forEach(list, function (b, index) {
                if (id == b) {
                    list.splice(index, 1);
                }
            });
        };

        //validate day
        $scope.DayInRangeValidation = function () {

            var startDate = moment($scope.Model.FromDate, $scope.DateFormat.toUpperCase());
            var endDate = moment($scope.Model.ToDate, $scope.DateFormat.toUpperCase());

            $scope.duration = endDate.diff(startDate, 'days')
            var isExist = false;

            var Days = angular.copy($scope.SelectedDay.Days);

            angular.forEach(Days, function (id, index) {

                for (var i = 0; i <= $scope.duration ; i++) {
                    var futureDate = moment(startDate).add(i, 'days');
                    var day = futureDate.day();

                    if (day == 0) {
                        if (id == 7) {
                            isExist = true;
                        }
                    }
                    else if (day == id) {
                        isExist = true;
                    }
                }

                if (!isExist) {

                    removeFromList($scope.SelectedDay.Days, id);
                    //$scope.SelectedDay.Days.splice(index, 1);
                    //$scope.SelectedDay.Days = [];
                    //parent.failureMessage("Invalid Day Selected.");
                    scrollPageOnTop();

                }
                isExist = false;
            });
        };

    }
]);
