﻿
(function () {
    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var linkModule = [];

        function  getRoomType(options) {

            var url = apiPath + "FrontOffice/RoomType/GetAll?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        function getroomtypseData(propertyId) {
            return httpCaller(apiPath + "FrontOffice/roomtype/GetAllByPropertyIdMin/?propertyId=" + propertyId, $http, $q);
            //return $.ajax({
            //    type: "GET",
            //    url: apiPath + "FrontOffice/roomtype/GetAllByPropertyIdMin/?propertyId=" + propertyId,
            //    params: {},
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    },
            //    error: function (data) { msg("Error!\n" + data.responseJSON.Message); }
            //});

        };

        function saveroomtypeData (roomtypeData) {
            return httpPoster(apiPath + "FrontOffice/roomtype/Save", $http, $q, roomtypeData);
            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/roomtype/Save",
            //    data: JSON.stringify(roomtypeData),
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    },
            //    error: function (data) { msg("Error!\n" + data.responseJSON.Message); }
            //});

        };

        function removeroomtypeData (roomtypeData) {
            return httpPoster(apiPath + "FrontOffice/roomtype/remove/" + roomtypeData, $http, $q);
            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/roomtype/remove/" + roomtypeData,
            //    data: {},
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    },
            //    error: function (data) { msg("Error!\n" + data.responseJSON.Message); }
            //});

        };

        function statusroomtypeData (roomtypeData) {
            return httpPoster(apiPath + "GlobalSetting/designation/create/modify", $http, $q, desigData);
            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/roomtype/changestatus",
            //    data: JSON.stringify(roomtypeData),
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    },
            //    error: function (data) {
            //        msg("Error!\n" + data.responseJSON.Message);
            //    }
            //});

        };

        function roomtypeDataExists(roomtypeData) {
            return httpPoster(apiPath + "FrontOffice/roomtype/existcode/" + propertyId + "/" + roomtypeData, $http, $q);
            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/roomtype/existcode/" + propertyId + "/" + roomtypeData,
            //    data: {},
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    }
            //    , error: function (data) {
            //        msg("Error!\n" + data.responseJSON.Message);
            //    }
            //});
        };

        function txtTypeSequenceData  (propertyId, orderSNo, id) {
            var params = { propertyId: propertyId, orderSNo: orderSNo, id: id };
            return httpCaller(apiPath + "FrontOffice/roomtype/existsequence", $http, $q, params);

            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/roomtype/existsequence/" + propertyId + "/" + txtSequence,
            //    data: {},
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    }
            //    ,
            //    error: function (data) {
            //        msg("Error!\n" + data.responseJSON.Message);
            //    }
            //});
        };

        var service = {
            dataAllData: linkModule,
            getRoomType: getRoomType,
            getroomtypseData: getroomtypseData,
            saveroomtypeData: saveroomtypeData,
            removeroomtypeData: removeroomtypeData,
            statusroomtypeData: statusroomtypeData,
            roomtypeDataExists: roomtypeDataExists,
            txtTypeSequenceData: txtTypeSequenceData,
        };
        return service;
    }

    app.factory("service", ["$http", "$q", service]);
})();
