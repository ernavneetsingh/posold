﻿
var PaymentTermsService = function ($http, $q, $filter) {

    var service = this;
    var scope;

    service.init = function ($scope, callbackForTotal) {
        scope = $scope;

        service.getPaymentTerms = function (propertyId) {
            return httpCaller(apiPath + "Inventory/PaymentTerm/GetAll", $http, $q, { propertyId: propertyId, active: 1 });
        };

        service.loadPaymentTerms = function () {
            service.reset();
            service.getPaymentTerms(scope.PropertyID)
                .then(function (s) {
                    scope.InvPaymentTerms = s.Collection;
                });
        };
        service.reset = function () {
            scope.PaymentTerms = [{}];
            scope._PaymentTermId = "";
        };
        service.set = function (c) {
            scope.PaymentTerms = c;
            //scope.PaymentTerms.push({});
            scope._PaymentTermId = c[0].PaymentTermId;
        };
        service.addTerm = function (paymentTermId) {
            //scope.InvPaymentTerms.forEach(function (ip) {
            //    if (paymentTermId === ip.Id)
            //        ip.isDisabled = true;
            //});
            scope.PaymentTerms = [{ PaymentTermId: paymentTermId }];//.push({ PaymentTermId: paymentTermId });
        };
        service.deleteTerm = function (i) {
            var p = scope.PaymentTerms[i];
            scope.PaymentTerms.splice(i, 1);
            if (scope.PaymentTerms.length <= 0) scope.PaymentTerms = [{}];
            scope.InvPaymentTerms.forEach(function (ip) {
                if (p.PaymentTermId === ip.Id)
                    ip.isDisabled = false;
            });
        };

        service.loadPaymentTerms();
        return service;
    };

};

app.service('PaymentTermsService', ['$http', '$q', '$filter', PaymentTermsService]);
