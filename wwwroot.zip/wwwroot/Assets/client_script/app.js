﻿
'use strict';
var app;
var apiUrlBulder;

(function () {
    app = angular.module("app", ['ngCookies', 'LocalStorageModule', 'ui.bootstrap', '720kb.datepicker', 'ngRoute', 'ivh.treeview', 'ui.grid', 'ui.grid.expandable', 'ui.grid.exporter', 'ngTouch', 'ngSelectable', 'ngAnimate', 'naif.base64', 'moment-picker', 'ui.grid.grouping', 'ui.grid.edit', 'ui.grid.selection', 'daterangepicker', 'credit-cards']);

    var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';

    app.config(function ($sceDelegateProvider) {
        try {
            //
            $sceDelegateProvider.resourceUrlWhitelist([
              ReportXPath + '**',
              ReportXPath + 'api/**',
            ]);
        } catch (e) { }

    });
    app.config(['$httpProvider', '$routeProvider', 'ivhTreeviewOptionsProvider', function ($httpProvider, $routeProvider, ivhTreeviewOptionsProvider) {

        ivhTreeviewOptionsProvider.set({
            defaultSelectedState: false,
            validate: true,
            expandToDepth: -1
        });

        $routeProvider.otherwise("/");

        if ((accessToken != undefined) && (accessToken != undefined) && (accessToken != null) && (accessToken != "")) {
            $httpProvider.defaults.headers.common['duxtechApiKey'] = accessToken;
        }

        $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
        $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';


        $httpProvider.defaults.transformRequest = [function (data) {
            var param = function (obj) {
                var query = '';
                var name, value, fullSubName, subName, subValue, innerObj, i;

                for (name in obj) {
                    value = obj[name];

                    if (value instanceof Array) {
                        for (i = 0; i < value.length; ++i) {
                            subValue = value[i];
                            fullSubName = name + '[' + i + ']';
                            innerObj = {};
                            innerObj[fullSubName] = subValue;
                            query += param(innerObj) + '&';
                        }
                    }
                    else if (value instanceof Object) {
                        for (subName in value) {
                            subValue = value[subName];
                            fullSubName = name + '[' + subName + ']';
                            innerObj = {};
                            innerObj[fullSubName] = subValue;
                            query += param(innerObj) + '&';
                        }
                    }
                    else if (value !== undefined && value !== null) {
                        query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
                    }
                }
                return query.length ? query.substr(0, query.length - 1) : query;
            };
            return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;
        }];
    }]);

    app.run(['$q', '$rootScope', function ($q, $rootScope, $location) {
        $rootScope.location = $location;
    }]);

    //var apiPath = "http://192.168.1.50:85/api/";
    //var Path = 'http://192.168.1.50:85/';


})();

//Directive for confirmation
app.directive('ngConfirmClick', [function () {
    return {
        link: function (scope, element, attr) {
            var msg = attr.ngConfirmClick || "Are you sure?";
            var clickAction = attr.confirmedClick;
            element.bind('click', function (event) {
                if (window.confirm(msg)) {
                    scope.$eval(clickAction);
                }
            });
        }
    };
}
]);

app.directive('onlyDigits', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^0-9.]/g, '');

                    if (digits.split('.').length > 2) {
                        digits = digits.substring(0, digits.length - 1);
                    }

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
});


app.directive('onlyMobile', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    val = val.trim();
                    if (val.length < 1) {
                        ctrl.$setViewValue(undefined);
                        ctrl.$render();
                    }

                    var digits = val.replace(/[^0-9\s]/g, '');

                    if (digits.split('.').length > 2) {
                        digits = digits.substring(0, digits.length - 1);
                    }

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
});


app.directive('onlyCode', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^a-zA-Z0-9]/g, '');

                    if (digits.split('.').length > 2) {
                        digits = digits.substring(0, digits.length - 1);
                    }

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return digits;
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
});


app.directive('checkList', function () {
    return {
        scope: {
            list: '=checkList',
            value: '@'
        },
        link: function (scope, elem, attrs) {
            var handler = function (setup) {
                var checked = elem.prop('checked');
                var index = scope.list.indexOf(scope.value);

                if (checked && index == -1) {
                    if (setup) elem.prop('checked', false);
                    else scope.list.push(scope.value);
                } else if (!checked && index != -1) {
                    if (setup) elem.prop('checked', true);
                    else scope.list.splice(index, 1);
                }
            };

            var setupHandler = handler.bind(null, true);
            var changeHandler = handler.bind(null, false);

            elem.on('change', function () {
                scope.$apply(changeHandler);
            });
            scope.$watch('list', setupHandler, true);
        }
    };
});

app.directive('datepicker', function () {
    return {
        link: function (scope, el, attr) {
            $(el).datepicker({
                onSelect: function (dateText) {
                    console.log(dateText);
                    var expression = attr.ngModel + " = " + "'" + dateText + "'";
                    scope.$apply(expression);
                }
            });
        }
    };
});

app.directive("akFileModel", ["$parse", function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            var model = $parse(attrs.akFileModel);
            var modelSetter = model.assign;
            element.bind("change", function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.directive('uploadFiles', function () {
    return {
        scope: true,        //create a new scope  
        link: function (scope, el, attrs) {
            el.bind('change', function (event) {
                var files = event.target.files;
                //iterate files since 'multiple' may be specified on the element  
                for (var i = 0; i < files.length; i++) {
                    //emit event upward  
                    scope.$emit("seletedFile", { file: files[i] });
                }
            });
        }
    };
});

app.directive('ngDropdownMultiselect', ['$filter', '$document', '$compile', '$parse', function ($filter, $document, $compile, $parse) {

    return {
        restrict: 'AE',
        scope: {
            selectedModel: '=',
            options: '=',
            extraSettings: '=',
            events: '=',
            searchFilter: '=?',
            translationTexts: '=',
            groupBy: '@'
        },
        template: function (element, attrs) {
            var checkboxes = attrs.checkboxes ? true : false;
            var groups = attrs.groupBy ? true : false;

            var template = '<div class="multiselect-parent btn-group dropdown-multiselect">';
            template += '<button type="button" class="dropdown-toggle" ng-class="settings.buttonClasses" ng-click="toggleDropdown()">{{getButtonText()}}&nbsp;<span class="caret"></span></button>';
            template += '<ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? \'block\' : \'none\', height : settings.scrollable ? settings.scrollableHeight : \'auto\' }" style="overflow: scroll" >';
            template += '<li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()"><span class="glyphicon glyphicon-ok"></span>  {{texts.checkAll}}</a>';
            template += '<li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();"><span class="glyphicon glyphicon-remove"></span>   {{texts.uncheckAll}}</a></li>';
            template += '<li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) && !settings.showUncheckAll" class="divider"></li>';

            if (groups) {
                template += '<li ng-repeat-start="option in orderedItems | filter: searchFilter" ng-show="getPropertyForObject(option, settings.groupBy) !== getPropertyForObject(orderedItems[$index - 1], settings.groupBy)" role="presentation" class="dropdown-header">{{ getGroupTitle(getPropertyForObject(option, settings.groupBy)) }}</li>';
                template += '<li ng-repeat-end role="presentation">';
            } else {
                template += '<li role="presentation" ng-repeat="option in options | filter: searchFilter">';
            }
            template += '<a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))">';
            if (checkboxes) {
                template += '<div class="checkbox"><label><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))" /> {{getPropertyForObject(option, settings.displayProp)}}</label></div></a>';
            } else {
                template += '<span data-ng-class="{\'glyphicon glyphicon-ok\': isChecked(getPropertyForObject(option,settings.idProp))}"></span> {{getPropertyForObject(option, settings.displayProp)}}</a>';
            }
            template += '</li>';
            template += '<li class="divider" ng-show="settings.selectionLimit > 1"></li>';
            template += '<li role="presentation" ng-show="settings.selectionLimit > 1"><a role="menuitem">{{selectedModel.length}} {{texts.selectionOf}} {{settings.selectionLimit}} {{texts.selectionCount}}</a></li>';
            template += '</ul>';
            template += '</div>';

            element.html(template);
        },
        link: function ($scope, $element, $attrs) {
            var $dropdownTrigger = $element.children()[0];

            $scope.toggleDropdown = function () {
                $scope.open = !$scope.open;
            };

            $scope.checkboxClick = function ($event, id) {
                $scope.setSelectedItem(id);
                $event.stopImmediatePropagation();
            };

            $scope.externalEvents = {
                onItemSelect: angular.noop,
                onItemDeselect: angular.noop,
                onSelectAll: angular.noop,
                onDeselectAll: angular.noop,
                onInitDone: angular.noop,
                onMaxSelectionReached: angular.noop
            };

            $scope.settings = {
                dynamicTitle: true,
                scrollable: false,
                scrollableHeight: '300px',
                closeOnBlur: true,
                displayProp: 'Name',
                idProp: 'Id',
                externalIdProp: 'Id',
                enableSearch: false,
                selectionLimit: 0,
                showCheckAll: true,
                showUncheckAll: true,
                closeOnSelect: false,
                buttonClasses: 'btn btn-default',
                closeOnDeselect: false,
                groupBy: $attrs.groupBy || undefined,
                groupByTextProvider: null,
                smartButtonMaxItems: 0,
                smartButtonTextConverter: angular.noop
            };

            $scope.texts = {
                checkAll: 'Check All',
                uncheckAll: 'Uncheck All',
                selectionCount: 'checked',
                selectionOf: '/',
                searchPlaceholder: 'Search...',
                buttonDefaultText: 'Select',
                dynamicButtonTextSuffix: 'checked'
            };

            $scope.searchFilter = $scope.searchFilter || '';

            if (angular.isDefined($scope.settings.groupBy)) {
                $scope.$watch('options', function (newValue) {
                    if (angular.isDefined(newValue)) {
                        $scope.orderedItems = $filter('orderBy')(newValue, $scope.settings.groupBy);
                    }
                });
            }

            angular.extend($scope.settings, $scope.extraSettings || []);
            angular.extend($scope.externalEvents, $scope.events || []);
            angular.extend($scope.texts, $scope.translationTexts);

            $scope.singleSelection = $scope.settings.selectionLimit === 1;

            function getFindObj(id) {
                var findObj = {};

                if ($scope.settings.externalIdProp === '') {
                    findObj[$scope.settings.idProp] = id;
                } else {
                    findObj[$scope.settings.externalIdProp] = id;
                }

                return findObj;
            }

            function clearObject(object) {
                for (var prop in object) {
                    delete object[prop];
                }
            }

            if ($scope.singleSelection) {
                if (angular.isArray($scope.selectedModel) && $scope.selectedModel.length === 0) {
                    clearObject($scope.selectedModel);
                }
            }

            if ($scope.settings.closeOnBlur) {
                $document.on('click', function (e) {
                    var target = e.target.parentElement;
                    var parentFound = false;

                    while (angular.isDefined(target) && target !== null && !parentFound) {
                        if (_.contains(target.className.split(' '), 'multiselect-parent') && !parentFound) {
                            if (target === $dropdownTrigger) {
                                parentFound = true;
                            }
                        }
                        target = target.parentElement;
                    }

                    if (!parentFound) {
                        $scope.$apply(function () {
                            $scope.open = false;
                        });
                    }
                });
            }

            $scope.getGroupTitle = function (groupValue) {
                if ($scope.settings.groupByTextProvider !== null) {
                    return $scope.settings.groupByTextProvider(groupValue);
                }

                return groupValue;
            };

            $scope.getButtonText = function () {
                if (!$scope.selectedModel) {
                    return;
                }

                if ($scope.settings.dynamicTitle && ($scope.selectedModel.length > 0 || (angular.isObject($scope.selectedModel) && _.keys($scope.selectedModel).length > 0))) {
                    if ($scope.settings.smartButtonMaxItems > 0) {
                        var itemsText = [];

                        angular.forEach($scope.options, function (optionItem) {
                            if ($scope.isChecked($scope.getPropertyForObject(optionItem, $scope.settings.idProp))) {
                                var displayText = $scope.getPropertyForObject(optionItem, $scope.settings.displayProp);
                                var converterResponse = $scope.settings.smartButtonTextConverter(displayText, optionItem);

                                itemsText.push(converterResponse ? converterResponse : displayText);
                            }
                        });

                        if ($scope.selectedModel.length > $scope.settings.smartButtonMaxItems) {
                            itemsText = itemsText.slice(0, $scope.settings.smartButtonMaxItems);
                            itemsText.push('...');
                        }

                        return itemsText.join(', ');
                    } else {
                        var totalSelected;

                        if ($scope.singleSelection) {
                            totalSelected = ($scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp])) ? 1 : 0;
                        } else {
                            totalSelected = angular.isDefined($scope.selectedModel) ? $scope.selectedModel.length : 0;
                        }

                        if (totalSelected === 0) {
                            return $scope.texts.buttonDefaultText;
                        } else {
                            return totalSelected + ' ' + $scope.texts.dynamicButtonTextSuffix;
                        }
                    }
                } else {
                    return $scope.texts.buttonDefaultText;
                }
            };

            $scope.getPropertyForObject = function (object, property) {
                if (angular.isDefined(object) && object.hasOwnProperty(property)) {
                    return object[property];
                }

                return '';
            };

            $scope.selectAll = function () {
                $scope.deselectAll(false);
                $scope.externalEvents.onSelectAll();

                angular.forEach($scope.options, function (value) {
                    $scope.setSelectedItem(value[$scope.settings.idProp], true);
                });
            };

            $scope.deselectAll = function (sendEvent) {
                sendEvent = sendEvent || true;

                if (sendEvent) {
                    $scope.externalEvents.onDeselectAll();
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                } else {
                    $scope.selectedModel.splice(0, $scope.selectedModel.length);
                }
            };

            $scope.setSelectedItem = function (id, dontRemove) {
                var findObj = getFindObj(id);
                var finalObj = null;

                if ($scope.settings.externalIdProp === '') {
                    finalObj = _.find($scope.options, findObj);
                } else {
                    finalObj = findObj;
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                    angular.extend($scope.selectedModel, finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                    if ($scope.settings.closeOnSelect) $scope.open = false;

                    return;
                }

                dontRemove = dontRemove || false;

                var exists = _.findIndex($scope.selectedModel, findObj) !== -1;

                if (!dontRemove && exists) {
                    $scope.selectedModel.splice(_.findIndex($scope.selectedModel, findObj), 1);
                    $scope.externalEvents.onItemDeselect(findObj);
                } else if (!exists && ($scope.settings.selectionLimit === 0 || $scope.selectedModel.length < $scope.settings.selectionLimit)) {
                    $scope.selectedModel.push(finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                }
                if ($scope.settings.closeOnSelect) $scope.open = false;
            };

            $scope.isChecked = function (id) {
                if ($scope.singleSelection) {
                    return $scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp]) && $scope.selectedModel[$scope.settings.idProp] === getFindObj(id)[$scope.settings.idProp];
                }

                return _.findIndex($scope.selectedModel, getFindObj(id)) !== -1;
            };

            $scope.externalEvents.onInitDone();
        }
    };
}]);

var compareTo = function () {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function (scope, element, attributes, ngModel) {

            ngModel.$validators.compareTo = function (modelValue) {
                return modelValue == scope.otherModelValue;
            };

            scope.$watch("otherModelValue", function () {
                ngModel.$validate();
            });
        }
    };
};

app.directive("compareTo", compareTo);

app.directive('noSpecialChar', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                if (inputValue == null)
                    return "";
                var cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
                if (cleanInputValue != inputValue) {
                    modelCtrl.$setViewValue(cleanInputValue);
                    modelCtrl.$render();
                }
                return cleanInputValue;
            });
        }
    }
});

app.directive('allowPattern', [allowPatternDirective]);

app.directive('httpPrefix', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, controller) {
            function ensureHttpPrefix(value) {
                if (value && !/^(https?):\/\//i.test(value)
                   && 'http://'.indexOf(value) === -1) {
                    controller.$setViewValue('http://' + value);
                    controller.$render();
                    return 'http://' + value;
                }
                else
                    return value;
            }
            controller.$formatters.push(ensureHttpPrefix);
            controller.$parsers.splice(0, 0, ensureHttpPrefix);
        }
    };
});

function allowPatternDirective() {
    return {
        restrict: "A",
        compile: function (tElement, tAttrs) {
            return function (scope, element, attrs) {
                // I handle key events
                element.bind("keypress", function (event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.
                    //skip backspace
                    if (keyCode != 8) {
                        //skip delete
                        if (keyCode != 46) {
                            // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                            if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                                event.preventDefault();
                                return false;
                            }
                        }
                    }
                });
            };
        }
    };
}

app.directive('saveEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.saveEnter);
                });
                event.preventDefault();
            }
        });
    };
});

app.directive("checkboxGroup", function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            // Determine initial checked boxes
            if (scope.array.indexOf(scope.item.id) !== -1) {
                elem[0].checked = true;
            }

            // Update array on click
            elem.bind('click', function () {
                var index = scope.array.indexOf(scope.item.id);
                // Add if checked
                if (elem[0].checked) {
                    if (index === -1) scope.array.push(scope.item.id);
                }
                    // Remove if unchecked
                else {
                    if (index !== -1) scope.array.splice(index, 1);
                }
                // Sort and update DOM display
                scope.$apply(scope.array.sort(function (a, b) {
                    return a - b;
                }));
            });
        }
    }
});

app.directive("checkOutlet", function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            // Determine initial checked boxes
            if (scope.CheckedOutlets.indexOf(scope.item.Id) !== -1) {
                elem[0].checked = true;
            }

            // Update array on click
            elem.bind('click', function () {
                var index = scope.CheckedOutlets.indexOf(scope.item.Id);
                // Add if checked
                if (elem[0].checked) {
                    if (index === -1) scope.CheckedOutlets.push(scope.item.Id);
                }
                    // Remove if unchecked
                else {
                    if (index !== -1) scope.CheckedOutlets.splice(index, 1);
                }
                // Sort and update DOM display
                scope.$apply(scope.CheckedOutlets.sort(function (a, b) {
                    return a - b;
                }));
            });
        }
    }
});

app.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                scope.$apply(function () {
                    scope.fileread = changeEvent.target.files[0];
                    // or all selected files:
                    // scope.fileread = changeEvent.target.files;
                });
            });
        }
    }
}]);

app.directive("checkGroup", function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            // Determine initial checked boxes
            if (scope.CheckedModels.indexOf(scope.item.Id) !== -1) {
                elem[0].checked = true;
            }

            // Update array on click
            elem.bind('click', function () {
                var index = scope.CheckedModels.indexOf(scope.item.Id);
                // Add if checked
                if (elem[0].checked) {
                    if (index === -1) scope.CheckedModels.push(scope.item.Id);
                }
                    // Remove if unchecked
                else {
                    if (index !== -1) scope.CheckedModels.splice(index, 1);
                }
                // Sort and update DOM display
                scope.$apply(scope.CheckedModels.sort(function (a, b) {
                    return a - b;
                }));
            });
        }
    }
});

app.value('selectizeConfig', {}).directive("selectize", ['selectizeConfig', function (selectizeConfig) {
    return {
        restrict: 'EA',
        require: '^ngModel',
        scope: { ngModel: '=', config: '=?', options: '=?', ngDisabled: '=', ngRequired: '&' },
        link: function (scope, element, attrs, modelCtrl) {

            Selectize.defaults.maxItems = null; //default to tag editor

            var selectize,
                config = angular.extend({}, Selectize.defaults, selectizeConfig, scope.config);

            modelCtrl.$isEmpty = function (val) {
                return (val === undefined || val === null || !val.length); //override to support checking empty arrays
            }

            function createItem(input) {
                var data = {};
                data[config.labelField] = input;
                data[config.valueField] = input;
                return data;
            }

            function toggle(disabled) {
                disabled ? selectize.disable() : selectize.enable();
            }

            var validate = function () {
                var isInvalid = (scope.ngRequired() || attrs.required || config.required) && modelCtrl.$isEmpty(scope.ngModel);
                modelCtrl.$setValidity('required', !isInvalid)
            };

            function generateOptions(data) {
                if (!data)
                    return [];

                data = angular.isArray(data) ? data : [data]

                return $.map(data, function (opt) {
                    return typeof opt === 'string' ? createItem(opt) : opt;
                });
            }

            function updateSelectize() {
                validate();

                selectize.$control.toggleClass('ng-valid', modelCtrl.$valid);
                selectize.$control.toggleClass('ng-invalid', modelCtrl.$invalid);
                selectize.$control.toggleClass('ng-dirty', modelCtrl.$dirty);
                selectize.$control.toggleClass('ng-pristine', modelCtrl.$pristine);

                if (!angular.equals(selectize.items, scope.ngModel)) {
                    selectize.addOption(generateOptions(scope.ngModel));
                    selectize.setValue(scope.ngModel);
                }
            }

            var onChange = config.onChange,
                onOptionAdd = config.onOptionAdd;

            config.onChange = function () {
                if (!angular.equals(selectize.items, scope.ngModel))
                    scope.$evalAsync(function () {
                        var value = selectize.items.slice();
                        if (config.maxItems == 1) {
                            value = value[0];
                        }
                        modelCtrl.$setViewValue(value);
                    });

                if (onChange) {
                    onChange.apply(this, arguments);
                }
            }

            config.onOptionAdd = function (value, data) {
                if (scope.options.indexOf(data) === -1)
                    scope.options.push(data);

                if (onOptionAdd) {
                    onOptionAdd.apply(this, arguments);
                }
            }

            // ngModel (ie selected items) is included in this because if no options are specified, we
            // need to create the corresponding options for the items to be visible
            scope.options = generateOptions((scope.options || config.options || scope.ngModel).slice());

            var angularCallback = config.onInitialize;

            config.onInitialize = function () {
                selectize = element[0].selectize;
                selectize.addOption(scope.options);
                selectize.setValue(scope.ngModel);

                //provides a way to access the selectize element from an
                //angular controller
                if (angularCallback) {
                    angularCallback(selectize);
                }

                scope.$watch('options', function () {
                    selectize.clearOptions();
                    selectize.addOption(scope.options);
                    selectize.setValue(scope.ngModel);
                }, true);

                scope.$watchCollection('ngModel', updateSelectize);
                scope.$watch('ngDisabled', toggle);
            }

            element.selectize(config);

            element.on('$destroy', function () {
                if (selectize) {
                    selectize.destroy();
                    element = null;
                }
            });

        }
    };
}]);

app.directive('singleclick', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            var fn = $parse(attr['singleclick']);
            var delay = 300, clicks = 0, timer = null;
            element.on('click', function (event) {
                clicks++;
                if (clicks === 1) {
                    timer = setTimeout(function () {
                        scope.$apply(function () {
                            fn(scope, { $event: event });
                        });
                        clicks = 0;
                    }, delay);
                } else {
                    clearTimeout(timer);
                    clicks = 0;
                }
            });
        }
    };
}])

app.directive('myCurrentTime', ['$interval', 'dateFilter',
      function ($interval, dateFilter) {
          return function (scope, element, attrs) {
              var format, stopTime;
              function updateTime() {
                  element.text(dateFilter(new Date(), format));
              }
              scope.$watch(attrs.myCurrentTime, function (value) {
                  format = value;
                  updateTime();
              });
              stopTime = $interval(updateTime, 1000);
              element.on('$destroy', function () {
                  $interval.cancel(stopTime);
              });
          }
      }]);

app.provider('creditCardInput', function () {

    var _amex, _discover, _master, _visa;
    _amex = 'amex';
    _visa = 'visa';
    _master = 'master';
    _discover = 'discover';
    this.setCardClasses = function (cardClassObj) {
        _amex = cardClassObj.americanExpress || 'amex';
        _visa = cardClassObj.visa || 'visa';
        _master = cardClassObj.masterCard || 'master';
        return _discover = cardClassObj.discoverCard || 'discover';
    };
    this.$get = function () {
        return {
            americanExpressClass: _amex,
            visaClass: _visa,
            masterCardClass: _master,
            discoverCardClass: _discover,
            cardClasses: [_amex, _visa, _master, _discover].join(' ')
        };
    };
    return this;
}).directive('type', [
    'creditCardInput', function (creditCardInput) {

        return {
            require: '?ngModel',
            link: function (scope, el, attrs, ngModel) {

                var amexFormat, cvcParse, easeDelete, formField, format, inputType, parse, standardFormat, validity;
                inputType = attrs.ngType || attrs.type;
                if (!ngModel) {
                    return;
                }
                if (!(inputType === 'credit card' || inputType === 'cvc')) {
                    return;
                }

                if (inputType === 'cvc') {
                    el.on('blur keyup change', function (e) {

                        return scope.$apply(function () {
                            var text;
                            if (!(text = el.val())) {
                                return;
                            }
                            ngModel.$setViewValue(text);
                            return el.val(cvcParse(ngModel.$viewValue));
                        });
                    });
                    cvcParse = function (val) {

                        var value;
                        value = val != null ? val.replace(/([^\d])*/g, '').slice(0, 4) : void 0;
                        ngModel.$setValidity('minlength', value.length >= 3 || ngModel.$isEmpty(value));
                        return value;
                    };
                    return ngModel.$parsers.push(cvcParse);
                } else {
                    formField = el.parent();
                    el.on('blur keyup change', function (e) {
                        return scope.$apply(function () {

                            var text;
                            if (!(text = el.val())) {
                                return;
                            }
                            ngModel.$setViewValue(text);
                            return el.val(format(ngModel.$viewValue));
                        });
                    });
                    parse = function (val) {

                        var ref, ref1;
                        validity(val);
                        if (formField.hasClass(creditCardInput.americanExpressClass)) {
                            return (ref = val.replace(/([^\d])*/g, '').slice(0, 15)) != null ? ref : '';
                        } else {
                            return (ref1 = val.replace(/([^\d])*/g, '').slice(0, 16)) != null ? ref1 : '';
                        }
                    };
                    ngModel.$parsers.push(parse);
                    format = function (text) {
                        var num, regAmex, regDisc, regMast, regVisa;
                        if (!text) {
                            ngModel.$setPristine();
                            return;
                        }

                        num = text.replace(/([^\d\s])*/g, '');
                        regAmex = new RegExp("^(34|37)");
                        regVisa = new RegExp("^4");
                        regMast = new RegExp("^5[1-5]");
                        regDisc = new RegExp("^60");
                        if (num.length < 2) {
                            formField.removeClass(creditCardInput.cardClasses);
                        }
                        if (num.length === 2) {
                            formField.addClass((function () {
                                switch (false) {
                                    case !regAmex.test(num):
                                        return creditCardInput.americanExpressClass;
                                    case !regVisa.test(num):
                                        return creditCardInput.visaClass;
                                    case !regMast.test(num):
                                        return creditCardInput.masterCardClass;
                                    case !regDisc.test(num):
                                        return creditCardInput.discoverCardClass;
                                }
                            })());
                        }
                        if (regAmex.test(num)) {
                            return amexFormat(num);
                        } else {
                            return standardFormat(num);
                        }
                    };
                    standardFormat = function (num) {
                        if (num[14] === ' ') {
                            if (num.length > 18) {
                                return num.slice(0, 19);
                            }
                        }
                        if ((num.length === 5 || num.length === 10 || num.length === 15) && num[num.length - 1] !== ' ') {
                            return num.slice(0, -1) + ' ' + num[num.length - 1];
                        } else if ((num.length === 6 || num.length === 11 || num.length === 16) && num[num.length - 2] !== ' ') {
                            return num.slice(0, -2) + ' ' + num.slice(num.length - 2);
                        } else if ((num.length === 7 || num.length === 12 || num.length === 17) && num[num.length - 3] !== ' ') {
                            return num.slice(0, -3) + ' ' + num.slice(num.length - 3);
                        } else if ((num.length === 8 || num.length === 13 || num.length === 18) && num[num.length - 4] !== ' ') {
                            return num.slice(0, -4) + ' ' + num.slice(num.length - 4);
                        } else if ((num.length === 9 || num.length === 14 || num.length === 19) && num[num.length - 5] !== ' ') {
                            return num.slice(0, -5) + ' ' + num.slice(num.length - 5);
                        } else {
                            return easeDelete(num);
                        }
                    };
                    amexFormat = function (num) {
                        if (num.length > 16) {
                            return num.slice(0, 17);
                        }
                        if ((num.length === 5 || num.length === 12) && num[num.length - 1] !== ' ') {
                            return num.slice(0, -1) + ' ' + num[num.length - 1];
                        } else if ((num.length === 6 || num.length === 13) && num[num.length - 2] !== ' ') {
                            return num.slice(0, -2) + ' ' + num.slice(num.length - 2);
                        } else if ((num.length === 7 || num.length === 14) && num[num.length - 3] !== ' ') {
                            return num.slice(0, -3) + ' ' + num.slice(num.length - 3);
                        } else if ((num.length === 8 || num.length === 15) && num[num.length - 4] !== ' ') {
                            return num.slice(0, -4) + ' ' + num.slice(num.length - 4);
                        } else if ((num.length === 9 || num.length === 16) && num[num.length - 5] !== ' ') {
                            return num.slice(0, -5) + ' ' + num.slice(num.length - 5);
                        } else {
                            return easeDelete(num);
                        }
                    };
                    easeDelete = function (num) {
                        if (num[num.length - 1] === ' ') {
                            return num.slice(0, -1);
                        } else {
                            return num;
                        }
                    };
                    return validity = function (text) {
                        var luhnArr, sum;
                        luhnArr = [[0, 2, 4, 6, 8, 1, 3, 5, 7, 9], [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]];
                        sum = 0;
                        text.replace(/\D+/g, "").replace(/[\d]/g, function (c, p, o) {
                            return sum += luhnArr[(o.length - p) & 1][parseInt(c, 10)];
                        });

                        return ngModel.$setValidity('mod10', !!(sum % 10 === 0 && sum > 0) || ngModel.$isEmpty(text));
                    };
                }
            }
        };
    }
]);

app.directive('draggable', function () {

    return function (scope, element) {
        // this gives us the native JS object
        var el = element[0];

        el.draggable = true;

        el.addEventListener(
          'dragstart',
          function (e) {
              e.dataTransfer.effectAllowed = 'move';
              e.dataTransfer.setData('Text', this.id);
              this.classList.add('drag');
              return false;
          },
          false
        );

        el.addEventListener(
          'dragend',
          function (e) {
              this.classList.remove('drag');
              return false;
          },
          false
        );
    }
});
app.directive('droppable', function () {

    return {
        scope: {
            drop: '&',
            bin: '='
        },
        link: function (scope, element) {
            var el = element[0];
            el.addEventListener(
              'dragover',
              function (e) {

                  e.dataTransfer.dropEffect = 'move';
                  if (e.preventDefault) e.preventDefault();
                  this.classList.add('over');
                  return false;
              },
              false
            );

            el.addEventListener(
              'dragenter',
              function (e) {
                  this.classList.add('over');
                  return false;
              },
              false
            );

            el.addEventListener(
              'dragleave',
              function (e) {
                  this.classList.remove('over');
                  return false;
              },
              false
            );

            el.addEventListener(
              'drop',
              function (e) {

                  e.preventDefault();
                  if (e.stopPropagation) e.stopPropagation();
                  this.classList.remove('over');
                  var binId = this.id;
                  var data = e.dataTransfer.getData("text");
                  var item = document.getElementById(data);
                  this.appendChild(item);

                  scope.$apply(function (scope) {

                      var fn = scope.drop();
                      if ('undefined' !== typeof fn) {
                          fn(item.id, binId);
                      }
                  });

                  return false;
              },
              false
            );
        }
    }
});
app.directive('dragSelect', function ($window, $document) {
    return {
        scope: {
            dragSelectIds: '='
        },
        controller: function ($scope, $element) {

            var cls = 'eng-selected-item';
            var startCell = null;
            var dragging = false;

            function mouseUp(el) {
                dragging = false;
            }

            function mouseDown(el) {
                dragging = true;
                setStartCell(el);
                setEndCell(el);
            }

            function mouseEnter(el) {
                if (!dragging) return;
                setEndCell(el);
            }

            function setStartCell(el) {
                startCell = el;
            }

            function setEndCell(el) {
                $scope.dragSelectIds = [];
                $element.find('td').removeClass(cls);
                cellsBetween(startCell, el).each(function () {
                    var el = angular.element(this);
                    el.addClass(cls);
                    $scope.dragSelectIds.push(el.attr('id'));
                });
            }

            function cellsBetween(start, end) {
                var coordsStart = getCoords(start);
                var coordsEnd = getCoords(end);
                var topLeft = {
                    column: $window.Math.min(coordsStart.column, coordsEnd.column),
                    row: $window.Math.min(coordsStart.row, coordsEnd.row),
                };
                var bottomRight = {
                    column: $window.Math.max(coordsStart.column, coordsEnd.column),
                    row: $window.Math.max(coordsStart.row, coordsEnd.row),
                };
                return $element.find('td').filter(function () {
                    var el = angular.element(this);
                    var coords = getCoords(el);
                    return coords.column >= topLeft.column
                        && coords.column <= bottomRight.column
                        && coords.row >= topLeft.row
                        && coords.row <= bottomRight.row;
                });
            }

            function getCoords(cell) {
                var row = cell.parents('row');
                return {
                    column: cell[0].cellIndex,
                    row: cell.parent()[0].rowIndex
                };
            }

            function wrap(fn) {
                return function () {
                    var el = angular.element(this);
                    $scope.$apply(function () {
                        fn(el);
                    });
                }
            }

            $element.delegate('td', 'mousedown', wrap(mouseDown));
            $element.delegate('td', 'mouseenter', wrap(mouseEnter));
            $document.delegate('body', 'mouseup', wrap(mouseUp));
        }
    }
});

app.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});
app.filter('removeHTMLTags', function () {
    return function (text) {
        return text ? String(text).replace(/<[^>]+>/gm, '') : '';
    };
});
/**
 * Percentage Field Directive
 */

app.directive('percentageField', ['$filter', function ($filter) {

    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            // currencyIncludeDecimals: '&',
        },
        link: function (scope, element, attr, ngModel) {



            attr['percentageMaxValue'] = attr['percentageMaxValue'] || 100;
            attr['percentageMaxDecimals'] = attr['percentageMaxDecimals'] || 2;

            $(element).css({ 'text-align': 'right' });

            // function called when parsing the inputted url
            // this validation may not be rfc compliant, but is more
            // designed to catch common url input issues.
            function into(input) {
                //
                var valid;

                if (input == '') {
                    ngModel.$setValidity('valid', true);
                    return '';
                }

                // if the user enters something that's not even remotely a number, reject it
                if (!input.match(/^\d+(\.\d+){0,1}%{0,1}$/gi)) {
                    ngModel.$setValidity('valid', false);
                    return '';
                }

                // strip everything but numbers from the input
                input = input.replace(/[^0-9\.]/gi, '');

                input = parseFloat(input);

                var power = Math.pow(10, attr['percentageMaxDecimals']);

                input = Math.round(input * power) / power;

                if (input > attr['percentageMaxValue']) input = attr['percentageMaxValue'];

                // valid!
                ngModel.$setValidity('valid', true);

                return input;
            }

            ngModel.$parsers.push(into);

            function out(input) {
                //
                if (ngModel.$valid && input !== undefined && input > '') {
                    return input + '%';
                }

                return '';
            }

            ngModel.$formatters.push(out);

            $(element).bind('click', function () {
                //$( element ).val( ngModel.$modelValue );
                $(element).select();
            });

            $(element).bind('blur', function () {
                $(element).val(out(ngModel.$modelValue));
            });
        }
    };
}]);

app.directive('checklistModel', ['$parse', '$compile', function ($parse, $compile) {
    // contains
    function contains(arr, item, comparator) {
        if (angular.isArray(arr)) {
            for (var i = arr.length; i--;) {
                if (comparator(arr[i], item)) {
                    return true;
                }
            }
        }
        return false;
    }

    // add
    function add(arr, item, comparator) {
        arr = angular.isArray(arr) ? arr : [];
        if (!contains(arr, item, comparator)) {
            arr.push(item);
        }
        return arr;
    }

    // remove
    function remove(arr, item, comparator) {
        if (angular.isArray(arr)) {
            for (var i = arr.length; i--;) {
                if (comparator(arr[i], item)) {
                    arr.splice(i, 1);
                    break;
                }
            }
        }
        return arr;
    }

    // http://stackoverflow.com/a/19228302/1458162
    function postLinkFn(scope, elem, attrs) {
        // exclude recursion, but still keep the model
        var checklistModel = attrs.checklistModel;
        attrs.$set("checklistModel", null);
        // compile with `ng-model` pointing to `checked`
        $compile(elem)(scope);
        attrs.$set("checklistModel", checklistModel);

        // getter / setter for original model
        var getter = $parse(checklistModel);
        var setter = getter.assign;
        var checklistChange = $parse(attrs.checklistChange);
        var checklistBeforeChange = $parse(attrs.checklistBeforeChange);

        // value added to list
        var value = attrs.checklistValue ? $parse(attrs.checklistValue)(scope.$parent) : attrs.value;


        var comparator = angular.equals;

        if (attrs.hasOwnProperty('checklistComparator')) {
            if (attrs.checklistComparator[0] == '.') {
                var comparatorExpression = attrs.checklistComparator.substring(1);
                comparator = function (a, b) {
                    return a[comparatorExpression] === b[comparatorExpression];
                };

            } else {
                comparator = $parse(attrs.checklistComparator)(scope.$parent);
            }
        }

        // watch UI checked change
        scope.$watch(attrs.ngModel, function (newValue, oldValue) {
            if (newValue === oldValue) {
                return;
            }

            if (checklistBeforeChange && (checklistBeforeChange(scope) === false)) {
                scope[attrs.ngModel] = contains(getter(scope.$parent), value, comparator);
                return;
            }

            setValueInChecklistModel(value, newValue);

            if (checklistChange) {
                checklistChange(scope);
            }
        });

        function setValueInChecklistModel(value, checked) {
            var current = getter(scope.$parent);
            if (angular.isFunction(setter)) {
                if (checked === true) {
                    setter(scope.$parent, add(current, value, comparator));
                } else {
                    setter(scope.$parent, remove(current, value, comparator));
                }
            }

        }

        // declare one function to be used for both $watch functions
        function setChecked(newArr, oldArr) {
            if (checklistBeforeChange && (checklistBeforeChange(scope) === false)) {
                setValueInChecklistModel(value, scope[attrs.ngModel]);
                return;
            }
            scope[attrs.ngModel] = contains(newArr, value, comparator);
        }

        // watch original model change
        // use the faster $watchCollection method if it's available
        if (angular.isFunction(scope.$parent.$watchCollection)) {
            scope.$parent.$watchCollection(checklistModel, setChecked);
        } else {
            scope.$parent.$watch(checklistModel, setChecked, true);
        }
    }

    return {
        restrict: 'A',
        priority: 1000,
        terminal: true,
        scope: true,
        compile: function (tElement, tAttrs) {
            if ((tElement[0].tagName !== 'INPUT' || tAttrs.type !== 'checkbox') && (tElement[0].tagName !== 'MD-CHECKBOX') && (!tAttrs.btnCheckbox)) {
                throw 'checklist-model should be applied to `input[type="checkbox"]` or `md-checkbox`.';
            }

            if (!tAttrs.checklistValue && !tAttrs.value) {
                throw 'You should provide `value` or `checklist-value`.';
            }

            // by default ngModel is 'checked', so we set it if not specified
            if (!tAttrs.ngModel) {
                // local scope var storing individual checkbox model
                tAttrs.$set("ngModel", "checked");
            }

            return postLinkFn;
        }
    };
}]);

app.directive('focusMe', ['$timeout', '$parse', function ($timeout, $parse) {
    return {
        //scope: true,   // optionally create a child scope
        link: function (scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function (value) {
                console.log('value=', value);
                if (value === true) {
                    $timeout(function () {
                        element[0].focus();
                    });
                }
            });
            // to address @blesh's comment, set attribute value to 'false'
            // on blur event:
            element.bind('blur', function () {
                console.log('blur');
                scope.$apply(model.assign(scope, false));
            });
        }
    };
}]);

app.directive('lowerThan', [
  function () {
      var link = function ($scope, $element, $attrs, ctrl) {
          var validate = function (viewValue) {
              var comparisonModel = $attrs.lowerThan;

              if (!viewValue || !comparisonModel) {
                  // It's valid because we have nothing to compare against
                  ctrl.$setValidity('lowerThan', true);
              }

              // It's valid if model is lower than the model we're comparing against
              ctrl.$setValidity('lowerThan', parseInt(viewValue, 10) <= parseInt(comparisonModel, 10));
              return viewValue;
          };
          ctrl.$parsers.unshift(validate);
          ctrl.$formatters.push(validate);
          $attrs.$observe('lowerThan', function (comparisonModel) {
              return validate(ctrl.$viewValue);
          });
      };
      return {
          require: 'ngModel',
          link: link
      };
  }
]);

app.directive('myFocus', function () {
    return {
        restrict: 'A',
        link: function postLink(scope, element, attrs) {
            if (attrs.myFocus == "") {
                attrs.myFocus = "focusElement";
            }
            scope.$watch(attrs.myFocus, function (value) {
                if (value == attrs.id) {
                    element[0].focus();
                }
            });
            element.on("blur", function () {
                scope[attrs.myFocus] = "";
                scope.$apply();
            })
        }
    };
});

app.directive('myText', ['$rootScope', function ($rootScope) {
    return {
        link: function (scope, element, attrs) {
            $rootScope.$on('add', function (e, val) {


                var valArr = val.split(':');    //cntr +':' + value

                var domElement = element[0];

                if (domElement.id == valArr[0]) {
                    val = valArr[1];
                    if (document.selection) {
                        domElement.focus();
                        var sel = document.selection.createRange();
                        sel.text = val;
                        domElement.focus();
                    } else if (domElement.selectionStart || domElement.selectionStart === 0) {
                        var startPos = domElement.selectionStart;
                        var endPos = domElement.selectionEnd;
                        var scrollTop = domElement.scrollTop;
                        domElement.value = domElement.value.substring(0, startPos) + val + domElement.value.substring(endPos, domElement.value.length);
                        domElement.focus();
                        domElement.selectionStart = startPos + val.length;
                        domElement.selectionEnd = startPos + val.length;
                        domElement.scrollTop = scrollTop;
                    } else {
                        domElement.value += val;
                        domElement.focus();
                    }

                }

            });
        }
    }
}])

app.directive('ckeditor', Directive);
function Directive($rootScope) {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModel) {
            var editorOptions;
            if (attr.ckeditor === 'minimal') {
                // minimal editor
                editorOptions = {
                    height: 100,
                    toolbar: [
                        { name: 'basic', items: ['Bold', 'Italic', 'Underline'] },
                        { name: 'links', items: ['Link', 'Unlink'] },
                        { name: 'tools', items: ['Maximize'] },
                        { name: 'document', items: ['Source'] },
                    ],
                    removePlugins: 'elementspath',
                    resize_enabled: false
                };
            }
            else if (attr.ckeditor === 'none') {                // g2018-01-24 11:00 AM
                editorOptions = {
                    height: attr.height ? attr.height : 100,
                    toolbar: [{ name: 'insert', items: ['Youtube', 'Font', 'FontSize', 'TextColor', 'BGColor'] }, ],
                    removePlugins: 'elementspath,iframe,pastetext,pastefromword,clipboard,language,tableresize,liststyle,tableselection,tabletools,scayt',
                    //removePlugins: 'elementspath,iframe,pastetext,pastefromword,clipboard,language,tableresize,liststyle,tableselection,tabletools,scayt,menu,menubutton,toolbar,contextmenu',
                    extraPlugins: 'youtube',
                    resize_enabled: false,
                    disableNativeSpellChecker: false
                    //youtube_responsive: true,

                };
            }
            else if (attr.ckeditor === 'email') {
                // email editor

                editorOptions = {
                    height: 400,
                    toolbar: [
                        { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat'] },
		                { name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language'] },
		                { name: 'links', items: ['Link', 'Unlink', 'Anchor'] },
		                { name: 'insert', items: ['Image', 'Flash', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe'] },
		                '/',
		                { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize'] },
		                { name: 'colors', items: ['TextColor', 'BGColor'] },
		                { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
                        { name: 'document', items: ['Source'] },

                    ],
                    removePlugins: 'elementspath',
                    resize_enabled: false
                };
            }
            else if (attr.ckeditor === "full") {

                editorOptions = {
                    height: attr.height ? attr.height : 100,
                    // height: 100,
                    toolbar: [
                        { name: 'document', items: ['Source', '-', 'Save', 'NewPage', 'Preview', 'Print', '-', 'Templates'] },
		                { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] },
		                { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll', '-', 'Scayt'] },
		                { name: 'forms', items: ['Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField'] },
		                '/',
		                { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat'] },
		                { name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language'] },
		                { name: 'links', items: ['Link', 'Unlink', 'Anchor'] },
		                { name: 'insert', items: ['Image', 'Youtube', 'Flash', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe'] },
		                '/',
		                { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize'] },
		                { name: 'colors', items: ['TextColor', 'BGColor'] },
		                { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
		                { name: 'about', items: ['About'] },
                    ],
                    removePlugins: 'elementspath,iframe',
                    extraPlugins: 'youtube',
                    resize_enabled: false
                };
            }
            else {
                // regular editor
                editorOptions = {
                    filebrowserImageUploadUrl: $rootScope.globals.apiUrl + '/upload',
                    removeButtons: 'About,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Save,CreateDiv,Language,BidiLtr,BidiRtl,Flash,Iframe,addFile,Styles',
                    extraPlugins: 'video,simpleuploads,imagesfromword'
                };
            }

            // enable ckeditor
            var ckeditor = element.ckeditor(editorOptions);

            // update ngModel on change
            ckeditor.editor.on('change', function () {
                ngModel.$setViewValue(this.getData());
            });

        }
    };
}



app.factory('myInterceptor', ['$cookies', function ($cookieStore) {
    
    var requestInterceptor = {
        request: function (config) {
            var token = $cookieStore.get("accessToken");
            config.headers['access_Token'] = token;
            return config;
        }
    };

    return requestInterceptor;
}]);

app.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
}]);
