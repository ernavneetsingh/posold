﻿
(function () {

    function service($http, $q) {

        var linkItem = [];
        var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';

        //TODO: Navneet2.0
        function GetReservationSetup(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/Reservation/GetReservationSetup/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        //TODO: Navneet2.0
        function GetConstantByPropertyId(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/Reservation/GetConstantByPropertyId/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

            
        function getSetup(propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/Reservation/GetSetup/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getAllState = function (id) {

            var url = apiPath + 'referencedata/state/' + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {}
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var saveGuest = function (guest) {
            return httpPoster(apiPath + "FrontOffice/Guest/Save", $http, $q, guest);

            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/Guest/Save",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(guest),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        function getCorporateById(corporateId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "/GlobalSetting/corporate/GetById/" + corporateId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };
        function getReservationById(id, propertyId, businessDate) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "/FrontOffice/Reservation/GetById/" + id + "/" + propertyId + "/" + businessDate,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getReservationByIdMobile(id) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "/FrontOffice/Reservation/Mobile/GetById/" + id,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var getAutoSuggests = function (id, txt, propertyid) {

            //guestmobileid
            //gstemailid
            //grpcode
            //grpname
            //idGuestName1
            //emaild1

            var url = '';
            if (id == 'MobileNo' || id == 'GuestMobileNo') {
                url = apiPath + "FrontOffice/Guest/GetAllByMobile/" + propertyid + "/" + txt
            }
            else if (id == 'Name' || id == 'GuestName') {
                url = apiPath + "FrontOffice/Guest/GetAllByName/" + propertyid + "/" + txt
            }

            if (url) {
                $("#" + id)
              .autocomplete({
                  source: function (request, response) {

                      var deferred = $q.defer();
                      $http({
                          method: "GET",
                          url: url,
                          data: {},
                          headers: { 'duxtechApiKey': accessToken },
                          contentType: "application/json; charset=utf-8"
                      }).success(function (data, status, headers, cfg) {
                          deferred.resolve(data);

                          if (data.Collection.length > 0) {
                              response($.map(data.Collection,
                                  function (item) {
                                      return {
                                          //label: id == 'MobileNo' ? '<table><tr><td>' + item.Mobile + "</td><td>" + item.Name + "</td><td>" + item.EmailId + '</td></tr></table>' : '<table><tr><td>' + item.Name + "</td><td>" + item.Mobile + "</td><td>" + item.EmailId + '</td></tr></table>',
                                          label: id == 'MobileNo' ? item.Mobile + " " + item.Name : item.Name + " " + item.Mobile,
                                          val: item.Id
                                      };
                                  }));
                          } else {
                              response([{ label: "No Records Found", val: -1 }]);
                          }
                      }).error(function (err, status) {
                          deferred.reject(err, status);
                      });
                      return deferred.promise;

                  },
                  select: function (e, ui) {
                      if (ui.item) {
                          // return ui;
                          if (ui.item.label !== "No Record Found!") {

                              var element = angular.element($("#reservationdivid"));
                              var scope = element.scope();
                              scope.$apply(function () {
                                  getGuestById(ui.item.val, id);
                              });
                          }
                      }
                  },
                  minLength: 1
              });
            }


        };

        var getAutoSuggestsClear = function (id) {
            $("#" + id)
              .autocomplete({
                  source: function (request, response) {
                      var deferred = $q.defer();
                      response([{ label: "No Records Found", val: -1 }]);
                      //response([{ }]);
                      return deferred.promise;
                  }
              });
        };

        //function getGuestById(guestId, id) {           
        //    $.ajax({
        //        type: "GET",
        //        contentType: "application/json; charset=utf-8",
        //        url: apiPath + "FrontOffice/Guest/GetById/" + guestId,
        //        dataType: "json",
        //        headers: {
        //            'duxtechApiKey': accessToken
        //        },
        //        success: function (data) {
        //            // 
        //            var element = angular.element($("#reservationdivid"));
        //            var scope = element.scope();
        //            if (data !== null) {
        //                scope.$apply(function () {
        //                    if (data.Data !== null) {

        //                        scope.States = [];
        //                        var promiseGet = getAllState(data.Data.CountryMasterId);
        //                        promiseGet.then(function (data) {
        //                            scope.States = data.Collection;
        //                        },
        //                            function (error) {
        //                            });


        //                        if (id == 'GuestMobileNo' || id == 'GuestName') {

        //                            scope.Guest = data.Data;
        //                            scope.Guest.SalutationId = data.Data.SalutationId.toString();
        //                            scope.Guest.CountryMasterId = data.Data.CountryMasterId.toString();
        //                            scope.Guest.StateId = data.Data.StateId.toString();
        //                            scope.Guest.GuestClassId = data.Data.GuestClassId.toString();

        //                            scope.Guest.IssueDate = moment(new Date(scope.Guest.IssueDate)).format(scope.DateFormat.toUpperCase());
        //                            scope.Guest.ExpiryDate = moment(new Date(scope.Guest.ExpiryDate)).format(scope.DateFormat.toUpperCase());

        //                            scope.Guest.IssueVisaDate = moment(new Date(scope.Guest.IssueVisaDate)).format(scope.DateFormat.toUpperCase());
        //                            scope.Guest.ExpiryVisaDate = moment(new Date(scope.Guest.ExpiryVisaDate)).format(scope.DateFormat.toUpperCase());

        //                        }
        //                        else if (id == 'MobileNo' || id == 'Name') {

        //                            scope.Guest = data.Data;
        //                            scope.Reservation.Guest = data.Data;
        //                            scope.Reservation.SalutationId = data.Data.SalutationId.toString();
        //                            scope.Reservation.GuestName = data.Data.Name;
        //                            scope.Reservation.MobileNo = data.Data.Mobile;
        //                            scope.Reservation.Email = data.Data.EmailId;
        //                        }

        //                        showBlackListAlert(data.Data.IsBlackList);

        //                    }
        //                });
        //            }
        //        },
        //        error: function (xhr) {
        //            var errorMessage = $.parseJSON(xhr.responseText);
        //            parent.failureMessage(errorMessage.Message);
        //        }
        //    });
        //}


        function getGuestById(guestId, id) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/Guest/GetById/" + guestId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                var element = angular.element($("#reservationdivid"));
                var scope = element.scope();
                if (data !== null) {
                        if (data.Data !== null) {

                            scope.States = [];
                            var promiseGet = getAllState(data.Data.CountryMasterId);
                            promiseGet.then(function (data) {
                                scope.States = data.Collection;
                            },
                                function (error) {
                                });


                            if (id == 'GuestMobileNo' || id == 'GuestName') {

                                scope.Guest = data.Data;
                                scope.Guest.SalutationId = data.Data.SalutationId.toString();
                                scope.Guest.CountryMasterId = data.Data.CountryMasterId.toString();
                                scope.Guest.StateId = data.Data.StateId.toString();
                                scope.Guest.GuestClassId = data.Data.GuestClassId.toString();

                                scope.Guest.IssueDate = moment(new Date(scope.Guest.IssueDate)).format(scope.DateFormat.toUpperCase());
                                scope.Guest.ExpiryDate = moment(new Date(scope.Guest.ExpiryDate)).format(scope.DateFormat.toUpperCase());

                                scope.Guest.IssueVisaDate = moment(new Date(scope.Guest.IssueVisaDate)).format(scope.DateFormat.toUpperCase());
                                scope.Guest.ExpiryVisaDate = moment(new Date(scope.Guest.ExpiryVisaDate)).format(scope.DateFormat.toUpperCase());

                            }
                            else if (id == 'MobileNo' || id == 'Name') {

                                scope.Guest = data.Data;
                                scope.Reservation.Guest = data.Data;
                                scope.Reservation.SalutationId = data.Data.SalutationId.toString();
                                scope.Reservation.GuestName = data.Data.Name;
                                scope.Reservation.MobileNo = data.Data.Mobile;
                                scope.Reservation.Email = data.Data.EmailId;
                            }

                            showBlackListAlert(data.Data.IsBlackList);

                        }
                }
            }).error(function (err, status) {
                var errorMessage = $.parseJSON(err.responseText);
                parent.failureMessage(errorMessage.Message);
            });
            return deferred.promise;
        }

        function showBlackListAlert(isBlackList) {
            if (!isBlackList) return;
            msg('This Guest is black listed, so be cautious.');

        };

        function getGuestByIdNew(guestId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/Guest/GetById/" + guestId,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        }
        var save = function (model) {
            var deferred = $q.defer();
            var url = apiPath + 'FrontOffice/Reservation/Save';
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };

        //var save = function (model) {
        //    var deferred = $q.defer();
        //    $.ajax({
        //        type: "POST",
        //        url: apiPath + "FrontOffice/Reservation/Save",
        //        contentType: "application/json; charset=utf-8",
        //        dataType: "json",
        //        data: JSON.stringify(model),
        //        headers: {
        //            'duxtechApiKey': accessToken
        //        },
        //        success: function (data) {
        //            deferred.resolve(data);
        //        },
        //        error: function (data, status, headers, config) {
        //            deferred.reject(data, status, headers, config);
        //        }
        //    });
        //    return deferred.promise;
        //};

        function getGetRoomAvailableData(propertyId, roomTypeId, dtFrom, dtTill, rooms, dateFormat) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/roomavailable/" + propertyId + "/" + roomTypeId + "/" + dtFrom + "/" + dtTill + "/" + dateFormat + "/" + rooms,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getChangeRoomRateData(propertyId, rateId, roomTypeId, mealTypeCode) {
            //ratechange/{propertyId}/{rateId}
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/ratechange/" + propertyId + "/" + rateId + "/" + roomTypeId + "/" + mealTypeCode,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getPackageRoomRateData(propertyId, roomTypeId, mealplan, pax, applicbaleDate, applicableTill, dateFormat, status) {
            //ratechange/{propertyId}/{rateId}
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/packagedata/" + propertyId + "/" + roomTypeId + "/" + mealplan + "/" + pax + "/" + applicbaleDate + "/" + applicableTill + "/" + dateFormat + "/" + status,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getDefaultRoomRateData(propertyId, packageId, roomTypeId, pax, status) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/defaultroomdetails/" + propertyId + "/" + packageId + "/" + roomTypeId + "/" + pax + "/" + status,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var getRoomRateCalculationData = function (model) {
            return httpPoster(apiPath + "reservation/roomdetails", $http, $q, model);
            //var deferred = $q.defer();
            //var data1 = JSON.stringify(model);
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "reservation/roomdetails",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    traditional: true,
            //    //data: JSON.stringify({ 'reservationTaxDetails': data1 }),
            //    data: data1,//JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        //function getSearchGroupDetails(groupId) {
        //    $.ajax({
        //        type: "POST",
        //        contentType: "application/json; charset=utf-8",
        //        url: apiPath + "reservation/groupdetails/" + groupId,
        //        //data: "{'storeId':'" + searchType + "','itemname':'" + searchValue + "','brandId':'" + brandId + "'}",
        //        dataType: "json",
        //        headers: {
        //            'duxtechApiKey': accessToken
        //        },
        //        success: function (data) {
        //            var element = angular.element($("#reservationdivid"));
        //            var scope = element.scope();
        //            if (data !== null) {
        //                scope.$apply(function () {

        //                    if (data.Data !== null) {
        //                        scope.Reservation.GroupDetails.GroupCode = data.Data.GroupCode;
        //                        scope.Reservation.GroupDetails.GroupName = data.Data.GroupName;
        //                        scope.Reservation.GroupDetails.GroupId = data.Data.GroupDetailsId;
        //                    }
        //                });
        //            }
        //        },
        //        error: function (xhr) {
        //            var errorMessage = $.parseJSON(xhr.responseText);
        //            parent.failureMessage(errorMessage.Message);
        //        }
        //    });
        //}

        function getSearchGroupDetails(groupId) {
            var deferred = $q.defer();
            var url = apiPath + "reservation/groupdetails/" + groupId;
            $http({
                method: 'POST',
                url: url,
               // data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                var element = angular.element($("#reservationdivid"));
                var scope = element.scope();
                if (data !== null) {
                   // scope.$apply(function () {

                        if (data.Data !== null) {
                            scope.Reservation.GroupDetails.GroupCode = data.Data.GroupCode;
                            scope.Reservation.GroupDetails.GroupName = data.Data.GroupName;
                            scope.Reservation.GroupDetails.GroupId = data.Data.GroupDetailsId;
                        }
                   // });
                }
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }

        var getPackageRoomRateCalculationData = function (reservationTaxDetails) {
            return httpPoster(apiPath + "reservation/packageroomdetails", $http, $q, reservationTaxDetails);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "reservation/packageroomdetails",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(reservationTaxDetails),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        function getRoomWiseRateData(propertyId, roomTypeId, ratemasterId, maxpax, rooms) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/roomwiseratedetails/" + propertyId + "/" + roomTypeId + "/" + ratemasterId + "/" + maxpax + "/" + rooms,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getRevenueNameData(propertyId, revenueId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/revenuename/" + propertyId + "/" + revenueId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function clearLockRoomsData(propertyId, loginId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/clearlockrooms/" + propertyId + "/" + loginId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getMultiChangeRoomRateData(propertyId, rateId, applicableFrom, applicableTill, roomTypeId, dateFormat) {
            //multiratechange/{propertyId}/{rateId}/{applicableFrom}/{applicableTill}
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "reservation/multiratechange/" + propertyId + "/" + rateId + "/" + applicableFrom + "/" + applicableTill + "/" + roomTypeId + "/" + dateFormat,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var uploadFile = function (file) {
            var formData = new FormData();
            formData.append("file", file);
            var defer = $q.defer();
            $http.post(apiPath + "reservation/document/upload", formData,
                {
                    withCredentials: true,
                    headers: { 'Content-Type': undefined },
                    transformRequest: angular.identity
                })
                .success(function (d) {
                    defer.resolve(d);
                })
                .error(function (error) {
                    defer.reject(error.Message);
                });
            return defer.promise;
        };

        var getMealPlanList = function () {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "referencedata/MealPlan",
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;

        };

        var sendSMS = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/SendSMS", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/Reservation/SendSMS",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };
        var MapReport = function (filterValue, reportName) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
        };

        var sendEMail = function (model) {
            return httpPoster(apiPath + "GlobalSetting/EMail/Sent", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "GlobalSetting/EMail/Sent",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        var getAddEMailTemplate = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/GetAddEMailTemplate", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/Reservation/GetAddEMailTemplate",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        var getSearch = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/Search", $http, $q, model);

            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/Reservation/Search",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {

            //        angular.copy(data.Collection, linkItem);
            //        deferred.resolve(data.RecordCount);
            //        //deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        linkItem = [];
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;

        };

        var getBlock = function (options) {

            var url = apiPath + "FrontOffice/Block/GetAll?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getById = function (id, propertyid, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/Reservation/GetById/" + id + "/" + propertyid + "/" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getReason = function (propertyId) {
            var posModuleId = 1;
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/Reason/AllByModuleId/?propertyId=" + propertyId + "&moduleId=" + posModuleId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var cancelReservationConfirm = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/Cancel", $http, $q, model);

            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "FrontOffice/Reservation/Cancel",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        var saveCorporate = function (model) {
            return httpPoster(apiPath + "GlobalSetting/corporate/save", $http, $q, model);

            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "GlobalSetting/corporate/save",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        var getDesignationList = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/designation/GetAllByModuleId/" + propertyId + "/1") //FrontOffice
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getCorporateTypes = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/PropertyCorporateType/GetAll?propertyid=" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getCorporateCategory = function () {
            var deferred = $q.defer();
            $http.get(apiPath + "ReferenceConstant/CorporateCategory/all")
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getCorporateByCode = function (code, propertyid) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/corporate/GetByCode/" + code + "/" + propertyid)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getBookerTypes = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/BookerType/allByPropertyId/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getSettlementMode = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/SettlementMode/allByModuleId/" + propertyId + "/1")
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getBooker = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/Booker/allByPropertyId/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getBookerByCode = function (code, propertyid) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/booker/GetByCode/" + code + "/" + propertyid)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getRoomById = function (id, propertyid) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/RoomMaster/GetById/" + propertyid + "/" + id)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        var getAllRoomTypeRatesByRoomTypeId = function (roomTypeId, propertyid) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/RoomTypeRate/GetAllByRoomTypeId/" + roomTypeId + "/" + propertyid)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getRoomChart = function (model) {

            var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartNew';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var getRoomChartTest = function (model) {
            var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartTest';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };

        var getAllReservationRoomType = function (model) {
            var url = apiPath + 'FrontOffice/RoomChart/GetAllReservationRoomType';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };

        var getRoomTypes = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/RoomType/GetAllByPropertyId?propertyId=" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        var getMinRoomTypes = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/RoomType/GetAllByPropertyIdMin?propertyId=" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var saveBooker = function (model) {

            var url = apiPath + 'GlobalSetting/Booker/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);

            }).error(function (data, status, headers, config) {


                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var IsRackRateChangeable = function (propertyId) {
            var params = { propertyId: propertyId };
            return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/IsRackRateChangeable", $http, $q, params);
        };

        return {
            getReservationByIdMobile: getReservationByIdMobile,
            getSettlementMode: getSettlementMode,
            dataAllData: linkItem,
            getSetup: getSetup,
            getCorporateById: getCorporateById,
            getReservationById: getReservationById,
            saveGuest: saveGuest,
            getAllState: getAllState,
            save: save,
            clearLockRoomsData: clearLockRoomsData,
            getAutoSuggests: getAutoSuggests,
            getAutoSuggestsClear: getAutoSuggestsClear,
            getGetRoomAvailableData: getGetRoomAvailableData,
            getRevenueNameData: getRevenueNameData,
            getPackageRoomRateCalculationData: getPackageRoomRateCalculationData,
            getRoomRateCalculationData: getRoomRateCalculationData,
            getRoomWiseRateData: getRoomWiseRateData,
            getDefaultRoomRateData: getDefaultRoomRateData,
            getPackageRoomRateData: getPackageRoomRateData,
            getMultiChangeRoomRateData: getMultiChangeRoomRateData,
            getChangeRoomRateData: getChangeRoomRateData,
            uploadFile: uploadFile,
            getMealPlanList: getMealPlanList,

            sendSMS: sendSMS,
            sendEMail: sendEMail,
            getAddEMailTemplate: getAddEMailTemplate,
            MapReport: MapReport,
            getSearch: getSearch,
            getById: getById,
            getGuestByIdNew: getGuestByIdNew,
            getReason: getReason,
            cancelReservationConfirm: cancelReservationConfirm,
            saveCorporate: saveCorporate,
            getDesignationList: getDesignationList,
            getCorporateTypes: getCorporateTypes,
            getCorporateCategory: getCorporateCategory,
            getCorporateByCode: getCorporateByCode,
            getBookerTypes: getBookerTypes,

            getBooker: getBooker,
            getBookerByCode: getBookerByCode,

            getRoomById: getRoomById,
            getAllRoomTypeRatesByRoomTypeId: getAllRoomTypeRatesByRoomTypeId,

            getProperty: function () {
                return property;
            },
            setProperty: function (value) {
                property = value;
            },

            getRoomChart: getRoomChart,
            getRoomTypes: getRoomTypes,
            getRoomChartTest: getRoomChartTest,
            getAllReservationRoomType: getAllReservationRoomType,
            GetReservationSetup: GetReservationSetup,
            GetConstantByPropertyId: GetConstantByPropertyId,
            IsRackRateChangeable: IsRackRateChangeable,
            saveBooker: saveBooker,
        };

    }

   

    app.factory("service", ["$http", "$q", service]);

})();

