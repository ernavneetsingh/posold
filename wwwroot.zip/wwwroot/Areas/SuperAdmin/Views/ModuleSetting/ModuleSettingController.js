﻿
app.controller('ModuleSettingController', [
    '$scope', '$filter', '$cookies', 'moduleSettingService', '$window', 'localStorageService', function (
        $scope, $filter, $cookies, moduleSettingService, $window, localStorageService) {
        
        $scope.getModuleData = function () {
            var getData = moduleSettingService.getModuleData();
            getData.then(function (desigData) {
                $scope.ModuleDetails = desigData.Collection;
            });
        };
        $scope.getModuleSettings = function () {
            var getData = moduleSettingService.getAll();
            getData.then(function (data) {
                $scope.items = data.Collection;
            });
        };
        $scope.save = function (form) {
            
            //var st = $scope[form].$valid;
            //if (!st) {
            //    $scope.ShowErrorMessage = true;
            //    return;
            //}
            var promise = moduleSettingService.save($scope.model);
            promise.then(function (d) {
                msg("ModuleSetting successfully saved.", true);
            });
        };
        $scope.ChangeStatus = function (model) {
            
            var promise = moduleSettingService.statusChange(model);
            promise.then(function (data, status) {
                getData();
                if (data.Status) {
                    msg(data.Message, true);
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.getModuleData();
        $scope.getModuleSettings();

    }]);
