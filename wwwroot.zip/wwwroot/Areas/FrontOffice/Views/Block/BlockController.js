﻿
app.controller("BlockController",
[
    "$scope", "BlockService", "$cookies", "localStorageService", function ($scope, blockService, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.Model = {
            Id: "",
            Code: "",
            Name: "",
            Description: "",
            IsActive: true,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName
        };

        $scope.IsReadonly = false;
        $scope.Save = "Save";
        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        getData($scope, blockService, localStorageService);
        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, blockService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, blockService, localStorageService);
        };
        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, blockService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, blockService, localStorageService);
        }

        $scope.isExist = function () {

            var promiseGet = blockService.getCodeExistBlock($scope.Model.Code, $scope.Model.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        //alert("Block Code Already Exist");
                        msg(data.Message);
                        $scope.Model.Code = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Model.Id = "";
            $scope.Model.Code = "";
            $scope.Model.Name = "";
            $scope.Model.Description = "";
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            $scope.search();

        };
        $scope.saveBlockData = function (form) {

            if ($scope[form].$valid) {

                var bsObj = new Object();

                bsObj.Id = $scope.Model.Id;
                bsObj.Name = $scope.Model.Name;
                bsObj.Code = $scope.Model.Code;
                bsObj.Description = $scope.Model.Description;
                bsObj.IsActive = $scope.Model.IsActive;
                bsObj.PropertyID = $scope.Model.PropertyID;
                bsObj.ModifiedBy = $scope.Model.ModifiedBy;

                var promiseGet = blockService.saveBlock(bsObj);
                promiseGet.then(function (data, status) {
                    getData($scope, blockService, localStorageService);
                    $scope.reset();
                    msg(data.Message, data.Status);
                },
                function (error, status) {
                    msg(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.changeStatus = function (model) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            //var promiseGet = blockService.updateIsActiveBlock(Model.Id, Model.IsActive, $scope.Model.PropertyID, $scope.Model.ModifiedBy);
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.UserName;
            var promiseGet = blockService.changeStatus(model);
            promiseGet.then(function (data, status) {
                getData($scope, blockService, localStorageService);
                msg(data.Message, data.Status);
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.removeRow = function (model) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Block?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {
                            ret = true;
                            var deleteGuestStatus = blockService.deleteBlock(model.Id, $scope.Model.PropertyID);
                            deleteGuestStatus.then(function (data) {

                                msg(data.Message, data.Status);
                                getData($scope, blockService, localStorageService);
                            }, function (err) {
                                msg($.parseJSON(err.responseText).Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };

        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.Model = record;
            //$scope.Model.Id = record.Id;
            //$scope.Model.Name = record.Name;
            //$scope.Model.Description = record.Description;
            //$scope.Model.Code = record.Code;
            //$scope.Model.Active = record.IsActive;

            $scope.IsReadonly = true;
            $scope.Save = "Update";
            msg('');
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getBlock(options)
    .then(function (totalItems) {

        $scope.totalItems = totalItems;
    },
    function () {

        msg("The request failed. Unable to connect to the remote server.");
    });

};
