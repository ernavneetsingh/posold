﻿'use strict';
var apppos;
var apiUrlBulder;

(function () {
    apppos = angular.module("apppos",
        ['ngCookies',
        'LocalStorageModule',
        'ui.bootstrap',
        '720kb.datepicker',
        'ngRoute',
        'ivh.treeview',
        'ui.grid',
        'ui.grid.expandable',
        'ui.grid.exporter',
        //'ngTouch',
        'ngSelectable',
        'ngAnimate',
        'ngAria',
        'ngMaterial',
        'material.components.keyboard']);

    var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';

    apppos.config(['$httpProvider', '$routeProvider', 'ivhTreeviewOptionsProvider', '$mdKeyboardProvider',

        function ($httpProvider, $routeProvider, ivhTreeviewOptionsProvider, $mdKeyboardProvider) {
            ivhTreeviewOptionsProvider.set({
                defaultSelectedState: false,
                validate: true,
                expandToDepth: -1
            });
            $routeProvider.otherwise("/");
            if ((accessToken != undefined) && (accessToken != undefined) && (accessToken != null) && (accessToken != "")) {
                $httpProvider.defaults.headers.common['duxtechApiKey'] = accessToken;
            }
            $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
            $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
            $httpProvider.defaults.transformRequest = [function (data) {
                var param = function (obj) {
                    var query = '';
                    var name, value, fullSubName, subName, subValue, innerObj, i;

                    for (name in obj) {
                        value = obj[name];

                        if (value instanceof Array) {
                            for (i = 0; i < value.length; ++i) {
                                subValue = value[i];
                                fullSubName = name + '[' + i + ']';
                                innerObj = {};
                                innerObj[fullSubName] = subValue;
                                query += param(innerObj) + '&';
                            }
                        }
                        else if (value instanceof Object) {
                            for (subName in value) {
                                subValue = value[subName];
                                fullSubName = name + '[' + subName + ']';
                                innerObj = {};
                                innerObj[fullSubName] = subValue;
                                query += param(innerObj) + '&';
                            }
                        }
                        else if (value !== undefined && value !== null) {
                            query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
                        }
                    }
                    return query.length ? query.substr(0, query.length - 1) : query;
                };
                return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;
            }];

            $mdKeyboardProvider.addLayout('Numbers', {
                'name': 'Numbers', 'keys': [
                    [['7', '7'], ['8', '8'], ['9', '9'], ['Bksp', 'Bksp']],
                    [['4', '4'], ['5', '5'], ['6', '6'], ['-', '-']],
                    [['1', '1'], ['2', '2'], ['3', '3'], ['+', '+']],
                    [['0', '0'], ['Spacer'], ['.'], ['Enter', 'Enter']]
                ], 'lang': ['de']
            });
            // default layout is german
            //$mdKeyboardProvider.defaultLayout('Deutsch');

        }]).controller('keyboardDemoCtrl', function ($log, $scope, $mdKeyboard) {
            $scope.text = '';
            $scope.numbers = '';
            
            $scope.keyboardVisible = $mdKeyboard.isVisible();

            $scope.hideKeyboard = function () {
                $mdKeyboard.hide();
            };

            $scope.$watch(
                function () {
                    
                    return $mdKeyboard.isVisible();
                },
                function (newValue) {
                    
                    $scope.keyboardVisible = newValue;
                }
            );
        });

    apppos.run(['$q', '$rootScope', '$location', '$window', function ($q, $rootScope, $location, $window) {

        $rootScope.location = $location;

        $rootScope.online = navigator.onLine;
        $window.addEventListener("offline", function () {
            $rootScope.$apply(function () {
                $rootScope.online = false;
            });
        }, false);

        $window.addEventListener("online", function () {
            $rootScope.$apply(function () {
                $rootScope.online = true;
            });
        }, false);

    }]);



})();

//Directive for confirmation
apppos.directive('ngConfirmClick', [function () {
    return {
        link: function (scope, element, attr) {
            var msg = attr.ngConfirmClick || "Are you sure?";
            var clickAction = attr.confirmedClick;
            element.bind('click', function (event) {
                if (window.confirm(msg)) {
                    scope.$eval(clickAction);
                }
            });
        }
    };
}
]);


apppos.directive('myenter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.myenter);
                });

                event.preventDefault();
            }
        });
    };
});

apppos.directive('onlyDigits', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^0-9.]/g, '');

                    if (digits.split('.').length > 2) {
                        digits = digits.substring(0, digits.length - 1);
                    }

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
});

apppos.directive('checkList', function () {
    return {
        scope: {
            list: '=checkList',
            value: '@'
        },
        link: function (scope, elem, attrs) {
            var handler = function (setup) {
                var checked = elem.prop('checked');
                var index = scope.list.indexOf(scope.value);

                if (checked && index == -1) {
                    if (setup) elem.prop('checked', false);
                    else scope.list.push(scope.value);
                } else if (!checked && index != -1) {
                    if (setup) elem.prop('checked', true);
                    else scope.list.splice(index, 1);
                }
            };

            var setupHandler = handler.bind(null, true);
            var changeHandler = handler.bind(null, false);

            elem.on('change', function () {
                scope.$apply(changeHandler);
            });
            scope.$watch('list', setupHandler, true);
        }
    };
});

apppos.directive('datepicker', function () {
    return {
        link: function (scope, el, attr) {
            $(el).datepicker({
                onSelect: function (dateText) {
                    console.log(dateText);
                    var expression = attr.ngModel + " = " + "'" + dateText + "'";
                    scope.$apply(expression);
                }
            });
        }
    };
});

apppos.directive("akFileModel", ["$parse", function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            var model = $parse(attrs.akFileModel);
            var modelSetter = model.assign;
            element.bind("change", function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

var compareTo = function () {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function (scope, element, attributes, ngModel) {

            ngModel.$validators.compareTo = function (modelValue) {
                return modelValue == scope.otherModelValue;
            };

            scope.$watch("otherModelValue", function () {
                ngModel.$validate();
            });
        }
    };
};

apppos.directive("compareTo", compareTo);

apppos.directive('noSpecialChar', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                if (inputValue == null)
                    return "";
                var cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
                if (cleanInputValue != inputValue) {
                    modelCtrl.$setViewValue(cleanInputValue);
                    modelCtrl.$render();
                }
                return cleanInputValue;
            });
        }
    }
});


apppos.directive('httpPrefix', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, controller) {
            function ensureHttpPrefix(value) {
                if (value && !/^(https?):\/\//i.test(value)
                   && 'http://'.indexOf(value) === -1) {
                    controller.$setViewValue('http://' + value);
                    controller.$render();
                    return 'http://' + value;
                }
                else
                    return value;
            }
            controller.$formatters.push(ensureHttpPrefix);
            controller.$parsers.splice(0, 0, ensureHttpPrefix);
        }
    };
});

apppos.directive('allowPattern', function () {
    return {
        restrict: "A",
        compile: function (tElement, tAttrs) {
            return function (scope, element, attrs) {
                // I handle key events
                element.bind("keypress", function (event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.

                    // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                    if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                        event.preventDefault();
                        return false;
                    }

                });
            };
        }
    };
});


apppos.directive('saveEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.saveEnter);
                });
                event.preventDefault();
            }
        });
    };
});

apppos.directive("checkboxGroup", function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            // Determine initial checked boxes
            if (scope.array.indexOf(scope.item.id) !== -1) {
                elem[0].checked = true;
            }

            // Update array on click
            elem.bind('click', function () {
                var index = scope.array.indexOf(scope.item.id);
                // Add if checked
                if (elem[0].checked) {
                    if (index === -1) scope.array.push(scope.item.id);
                }
                    // Remove if unchecked
                else {
                    if (index !== -1) scope.array.splice(index, 1);
                }
                // Sort and update DOM display
                scope.$apply(scope.array.sort(function (a, b) {
                    return a - b;
                }));
            });
        }
    }
});

apppos.directive("checkOutlet", function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            // Determine initial checked boxes
            if (scope.CheckedOutlets.indexOf(scope.item.Id) !== -1) {
                elem[0].checked = true;
            }

            // Update array on click
            elem.bind('click', function () {
                var index = scope.CheckedOutlets.indexOf(scope.item.Id);
                // Add if checked
                if (elem[0].checked) {
                    if (index === -1) scope.CheckedOutlets.push(scope.item.Id);
                }
                    // Remove if unchecked
                else {
                    if (index !== -1) scope.CheckedOutlets.splice(index, 1);
                }
                // Sort and update DOM display
                scope.$apply(scope.CheckedOutlets.sort(function (a, b) {
                    return a - b;
                }));
            });
        }
    }
});

apppos.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                scope.$apply(function () {
                    scope.fileread = changeEvent.target.files[0];
                    // or all selected files:
                    // scope.fileread = changeEvent.target.files;
                });
            });
        }
    }
}]);

apppos.directive("checkGroup", function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            // Determine initial checked boxes
            if (scope.CheckedModels.indexOf(scope.item.Id) !== -1) {
                elem[0].checked = true;
            }

            // Update array on click
            elem.bind('click', function () {
                var index = scope.CheckedModels.indexOf(scope.item.Id);
                // Add if checked
                if (elem[0].checked) {
                    if (index === -1) scope.CheckedModels.push(scope.item.Id);
                }
                    // Remove if unchecked
                else {
                    if (index !== -1) scope.CheckedModels.splice(index, 1);
                }
                // Sort and update DOM display
                scope.$apply(scope.CheckedModels.sort(function (a, b) {
                    return a - b;
                }));
            });
        }
    }
});

apppos.value('selectizeConfig', {}).directive("selectize", ['selectizeConfig', function (selectizeConfig) {
    return {
        restrict: 'EA',
        require: '^ngModel',
        scope: { ngModel: '=', config: '=?', options: '=?', ngDisabled: '=', ngRequired: '&' },
        link: function (scope, element, attrs, modelCtrl) {

            Selectize.defaults.maxItems = null; //default to tag editor

            var selectize,
                config = angular.extend({}, Selectize.defaults, selectizeConfig, scope.config);

            modelCtrl.$isEmpty = function (val) {
                return (val === undefined || val === null || !val.length); //override to support checking empty arrays
            }

            function createItem(input) {
                var data = {};
                data[config.labelField] = input;
                data[config.valueField] = input;
                return data;
            }

            function toggle(disabled) {
                disabled ? selectize.disable() : selectize.enable();
            }

            var validate = function () {
                var isInvalid = (scope.ngRequired() || attrs.required || config.required) && modelCtrl.$isEmpty(scope.ngModel);
                modelCtrl.$setValidity('required', !isInvalid)
            };

            function generateOptions(data) {
                if (!data)
                    return [];

                data = angular.isArray(data) ? data : [data]

                return $.map(data, function (opt) {
                    return typeof opt === 'string' ? createItem(opt) : opt;
                });
            }

            function updateSelectize() {
                validate();

                selectize.$control.toggleClass('ng-valid', modelCtrl.$valid);
                selectize.$control.toggleClass('ng-invalid', modelCtrl.$invalid);
                selectize.$control.toggleClass('ng-dirty', modelCtrl.$dirty);
                selectize.$control.toggleClass('ng-pristine', modelCtrl.$pristine);

                if (!angular.equals(selectize.items, scope.ngModel)) {
                    selectize.addOption(generateOptions(scope.ngModel));
                    selectize.setValue(scope.ngModel);
                }
            }

            var onChange = config.onChange,
                onOptionAdd = config.onOptionAdd;

            config.onChange = function () {
                if (!angular.equals(selectize.items, scope.ngModel))
                    scope.$evalAsync(function () {
                        var value = selectize.items.slice();
                        if (config.maxItems == 1) {
                            value = value[0];
                        }
                        modelCtrl.$setViewValue(value);
                    });

                if (onChange) {
                    onChange.apply(this, arguments);
                }
            }

            config.onOptionAdd = function (value, data) {
                if (scope.options.indexOf(data) === -1)
                    scope.options.push(data);

                if (onOptionAdd) {
                    onOptionAdd.apply(this, arguments);
                }
            }

            // ngModel (ie selected items) is included in this because if no options are specified, we
            // need to create the corresponding options for the items to be visible
            scope.options = generateOptions((scope.options || config.options || scope.ngModel).slice());

            var angularCallback = config.onInitialize;

            config.onInitialize = function () {
                selectize = element[0].selectize;
                selectize.addOption(scope.options);
                selectize.setValue(scope.ngModel);

                //provides a way to access the selectize element from an
                //angular controller
                if (angularCallback) {
                    angularCallback(selectize);
                }

                scope.$watch('options', function () {
                    selectize.clearOptions();
                    selectize.addOption(scope.options);
                    selectize.setValue(scope.ngModel);
                }, true);

                scope.$watchCollection('ngModel', updateSelectize);
                scope.$watch('ngDisabled', toggle);
            }

            element.selectize(config);

            element.on('$destroy', function () {
                if (selectize) {
                    selectize.destroy();
                    element = null;
                }
            });

        }
    };
}]);

apppos.directive('singleclick', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            var fn = $parse(attr['singleclick']);
            var delay = 300, clicks = 0, timer = null;
            element.on('click', function (event) {
                clicks++;
                if (clicks === 1) {
                    timer = setTimeout(function () {
                        scope.$apply(function () {
                            fn(scope, { $event: event });
                        });
                        clicks = 0;
                    }, delay);
                } else {
                    clearTimeout(timer);
                    clicks = 0;
                }
            });
        }
    };
}])

apppos.directive('myCurrentTime', ['$interval', 'dateFilter',
      function ($interval, dateFilter) {
          return function (scope, element, attrs) {
              var format, stopTime;
              function updateTime() {
                  element.text(dateFilter(new Date(), format));
              }
              scope.$watch(attrs.myCurrentTime, function (value) {
                  format = value;
                  updateTime();
              });
              stopTime = $interval(updateTime, 1000);
              element.on('$destroy', function () {
                  $interval.cancel(stopTime);
              });
          }
      }]);


apppos.provider('creditCardInput', function () {
    var _amex, _discover, _master, _visa;
    _amex = 'amex';
    _visa = 'visa';
    _master = 'master';
    _discover = 'discover';
    this.setCardClasses = function (cardClassObj) {
        _amex = cardClassObj.americanExpress || 'amex';
        _visa = cardClassObj.visa || 'visa';
        _master = cardClassObj.masterCard || 'master';
        return _discover = cardClassObj.discoverCard || 'discover';
    };
    this.$get = function () {
        return {
            americanExpressClass: _amex,
            visaClass: _visa,
            masterCardClass: _master,
            discoverCardClass: _discover,
            cardClasses: [_amex, _visa, _master, _discover].join(' ')
        };
    };
    return this;
}).directive('type', [
    'creditCardInput', function (creditCardInput) {
        return {
            require: '?ngModel',
            link: function (scope, el, attrs, ngModel) {
                var amexFormat, cvcParse, easeDelete, formField, format, inputType, parse, standardFormat, validity;
                inputType = attrs.ngType || attrs.type;
                if (!ngModel) {
                    return;
                }
                if (!(inputType === 'credit card' || inputType === 'cvc')) {
                    return;
                }
                if (inputType === 'cvc') {
                    el.on('blur keyup change', function (e) {
                        return scope.$apply(function () {
                            var text;
                            if (!(text = el.val())) {
                                return;
                            }
                            ngModel.$setViewValue(text);
                            return el.val(cvcParse(ngModel.$viewValue));
                        });
                    });
                    cvcParse = function (val) {

                        var value;
                        value = val != null ? val.replace(/([^\d])*/g, '').slice(0, 4) : void 0;
                        ngModel.$setValidity('minlength', value.length >= 3 || ngModel.$isEmpty(value));
                        return value;
                    };
                    return ngModel.$parsers.push(cvcParse);
                } else {
                    formField = el.parent();
                    el.on('blur keyup change', function (e) {
                        return scope.$apply(function () {
                            var text;
                            if (!(text = el.val())) {
                                return;
                            }
                            ngModel.$setViewValue(text);
                            return el.val(format(ngModel.$viewValue));
                        });
                    });
                    parse = function (val) {
                        var ref, ref1;
                        validity(val);
                        if (formField.hasClass(creditCardInput.americanExpressClass)) {
                            return (ref = val.replace(/([^\d])*/g, '').slice(0, 15)) != null ? ref : '';
                        } else {
                            return (ref1 = val.replace(/([^\d])*/g, '').slice(0, 16)) != null ? ref1 : '';
                        }
                    };
                    ngModel.$parsers.push(parse);
                    format = function (text) {
                        var num, regAmex, regDisc, regMast, regVisa;
                        if (!text) {
                            ngModel.$setPristine();
                            return;
                        }
                        num = text.replace(/([^\d\s])*/g, '');
                        regAmex = new RegExp("^(34|37)");
                        regVisa = new RegExp("^4");
                        regMast = new RegExp("^5[1-5]");
                        regDisc = new RegExp("^60");
                        if (num.length < 2) {
                            formField.removeClass(creditCardInput.cardClasses);
                        }
                        if (num.length === 2) {
                            formField.addClass((function () {
                                switch (false) {
                                    case !regAmex.test(num):
                                        return creditCardInput.americanExpressClass;
                                    case !regVisa.test(num):
                                        return creditCardInput.visaClass;
                                    case !regMast.test(num):
                                        return creditCardInput.masterCardClass;
                                    case !regDisc.test(num):
                                        return creditCardInput.discoverCardClass;
                                }
                            })());
                        }
                        if (regAmex.test(num)) {
                            return amexFormat(num);
                        } else {
                            return standardFormat(num);
                        }
                    };
                    standardFormat = function (num) {
                        if (num[14] === ' ') {
                            if (num.length > 18) {
                                return num.slice(0, 19);
                            }
                        }
                        if ((num.length === 5 || num.length === 10 || num.length === 15) && num[num.length - 1] !== ' ') {
                            return num.slice(0, -1) + ' ' + num[num.length - 1];
                        } else if ((num.length === 6 || num.length === 11 || num.length === 16) && num[num.length - 2] !== ' ') {
                            return num.slice(0, -2) + ' ' + num.slice(num.length - 2);
                        } else if ((num.length === 7 || num.length === 12 || num.length === 17) && num[num.length - 3] !== ' ') {
                            return num.slice(0, -3) + ' ' + num.slice(num.length - 3);
                        } else if ((num.length === 8 || num.length === 13 || num.length === 18) && num[num.length - 4] !== ' ') {
                            return num.slice(0, -4) + ' ' + num.slice(num.length - 4);
                        } else if ((num.length === 9 || num.length === 14 || num.length === 19) && num[num.length - 5] !== ' ') {
                            return num.slice(0, -5) + ' ' + num.slice(num.length - 5);
                        } else {
                            return easeDelete(num);
                        }
                    };
                    amexFormat = function (num) {
                        if (num.length > 16) {
                            return num.slice(0, 17);
                        }
                        if ((num.length === 5 || num.length === 12) && num[num.length - 1] !== ' ') {
                            return num.slice(0, -1) + ' ' + num[num.length - 1];
                        } else if ((num.length === 6 || num.length === 13) && num[num.length - 2] !== ' ') {
                            return num.slice(0, -2) + ' ' + num.slice(num.length - 2);
                        } else if ((num.length === 7 || num.length === 14) && num[num.length - 3] !== ' ') {
                            return num.slice(0, -3) + ' ' + num.slice(num.length - 3);
                        } else if ((num.length === 8 || num.length === 15) && num[num.length - 4] !== ' ') {
                            return num.slice(0, -4) + ' ' + num.slice(num.length - 4);
                        } else if ((num.length === 9 || num.length === 16) && num[num.length - 5] !== ' ') {
                            return num.slice(0, -5) + ' ' + num.slice(num.length - 5);
                        } else {
                            return easeDelete(num);
                        }
                    };
                    easeDelete = function (num) {
                        if (num[num.length - 1] === ' ') {
                            return num.slice(0, -1);
                        } else {
                            return num;
                        }
                    };
                    return validity = function (text) {
                        var luhnArr, sum;
                        luhnArr = [[0, 2, 4, 6, 8, 1, 3, 5, 7, 9], [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]];
                        sum = 0;
                        text.replace(/\D+/g, "").replace(/[\d]/g, function (c, p, o) {
                            return sum += luhnArr[(o.length - p) & 1][parseInt(c, 10)];
                        });

                        return ngModel.$setValidity('mod10', !!(sum % 10 === 0 && sum > 0) || ngModel.$isEmpty(text));
                    };
                }
            }
        };
    }
]);



apppos.directive('draggable', function () {
    return function (scope, element) {
        // this gives us the native JS object
        var el = element[0];

        el.draggable = true;

        el.addEventListener(
          'dragstart',
          function (e) {
              e.dataTransfer.effectAllowed = 'move';
              e.dataTransfer.setData('Text', this.id);
              this.classList.add('drag');
              return false;
          },
          false
        );

        el.addEventListener(
          'dragend',
          function (e) {
              this.classList.remove('drag');
              return false;
          },
          false
        );
    }
});

apppos.directive('droppable', function () {
    return {
        scope: {
            drop: '&',
            bin: '='
        },
        link: function (scope, element) {
            var el = element[0];
            el.addEventListener(
              'dragover',
              function (e) {
                  e.dataTransfer.dropEffect = 'move';
                  if (e.preventDefault) e.preventDefault();
                  this.classList.add('over');
                  return false;
              },
              false
            );

            el.addEventListener(
              'dragenter',
              function (e) {
                  this.classList.add('over');
                  return false;
              },
              false
            );

            el.addEventListener(
              'dragleave',
              function (e) {
                  this.classList.remove('over');
                  return false;
              },
              false
            );

            el.addEventListener(
              'drop',
              function (e) {
                  if (e.stopPropagation) e.stopPropagation();
                  this.classList.remove('over');
                  var binId = this.id;
                  var item = document.getElementById(e.dataTransfer.getData('Text'));
                  this.appendChild(item);
                  scope.$apply(function (scope) {
                      var fn = scope.drop();
                      if ('undefined' !== typeof fn) {
                          fn(item.id, binId);
                      }
                  });

                  return false;
              },
              false
            );
        }
    }
});
apppos.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});

/**
 * Percentage Field Directive
 */
apppos.directive('percentageField', ['$filter', function ($filter) {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            // currencyIncludeDecimals: '&',

        },
        link: function (scope, element, attr, ngModel) {

            attr['percentageMaxValue'] = attr['percentageMaxValue'] || 100;
            attr['percentageMaxDecimals'] = attr['percentageMaxDecimals'] || 2;

            $(element).css({ 'text-align': 'right' });

            // function called when parsing the inputted url
            // this validation may not be rfc compliant, but is more
            // designed to catch common url input issues.
            function into(input) {

                var valid;

                if (input == '') {
                    ngModel.$setValidity('valid', true);
                    return '';
                }

                // if the user enters something that's not even remotely a number, reject it
                if (!input.match(/^\d+(\.\d+){0,1}%{0,1}$/gi)) {
                    ngModel.$setValidity('valid', false);
                    return '';
                }

                // strip everything but numbers from the input
                input = input.replace(/[^0-9\.]/gi, '');

                input = parseFloat(input);

                var power = Math.pow(10, attr['percentageMaxDecimals']);

                input = Math.round(input * power) / power;

                if (input > attr['percentageMaxValue']) input = attr['percentageMaxValue'];

                // valid!
                ngModel.$setValidity('valid', true);

                return input;
            }

            ngModel.$parsers.push(into);

            function out(input) {
                if (ngModel.$valid && input !== undefined && input > '') {
                    return input + '%';
                }

                return '';
            }

            ngModel.$formatters.push(out);

            $(element).bind('click', function () {
                //$( element ).val( ngModel.$modelValue );
                $(element).select();
            });

            $(element).bind('blur', function () {
                $(element).val(out(ngModel.$modelValue));
            });
        }
    };
}]);


apppos.directive('autofocus', ['$timeout', function ($timeout) {
    return {
        restrict: 'A',
        link: function ($scope, $element) {
            $timeout(function () {
                $element[0].focus();
            });
        }
    }
}]);

apppos.directive('eventFocus', function (focus) {
    return function(scope, elem, attr) {
        elem.on(attr.eventFocus, function() {
            focus(attr.eventFocusId);
        });

        // Removes bound events in the element itself
        // when the scope is destroyed
        scope.$on('$destroy', function() {
            elem.off(attr.eventFocus);
        });
    };
});

apppos.directive('focusMe', ['$timeout', '$parse', function ($timeout, $parse) {
    return {
        //scope: true,   // optionally create a child scope
        link: function (scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function (value) {
                console.log('value=', value);
                if (value === true) {
                    $timeout(function () {
                        element[0].focus();
                    });
                }
            });
            // to address @blesh's comment, set attribute value to 'false'
            // on blur event:
            element.bind('blur', function () {
                console.log('blur');
                scope.$apply(model.assign(scope, false));
            });
        }
    };
}]);

apppos.directive('onlyMobile', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^0-9]/g, '');

                    if (digits.split('.').length > 2) {
                        digits = digits.substring(0, digits.length - 1);
                    }

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
});

apppos.directive('selectOnClick', ['$window', function ($window) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.on('click', function () {
                if (!$window.getSelection().toString()) {
                    // Required for mobile Safari
                    this.setSelectionRange(0, this.value.length)
                }
            });
        }
    };
}]);

apppos.factory('myInterceptor', ['$cookies', function ($cookieStore) {
    var requestInterceptor = {
        request: function (config) {
            var token = $cookieStore.get("accessToken");
            config.headers['access_Token'] = token;
            return config;
        }
    };

    return requestInterceptor;
}]);

apppos.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
}]);