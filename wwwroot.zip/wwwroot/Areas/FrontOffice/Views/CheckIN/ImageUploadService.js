﻿
(function () {
    function ImageUploadService($http, $rootScope, $q) {

        var connect = function () {
            $rootScope.$broadcast('eventFired', {
                data: 'something'
            });
        }

        var ImageURL = "";
        return {
            getImageURL: function () {
                return ImageURL;
            },
            setImageURL: function (value) {
                
                ImageURL = value;
                connect();
            }
        };
    }
    app.factory("ImageUploadService", ["$http", "$q", ImageUploadService]);
})();
