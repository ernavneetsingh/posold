﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.UserName = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.Model = {
            Id: "",
            RevenueForId: 1,
            RevenueForName: "",
            AuditCode: "",
            Code: "",
            Name: "",
            Description: "",
            RevenueClassificationTypeId: "",
            RevenueClassificationTypeName: "",
            RevenueTypeId: "",
            RevenueTypeName: "",
            TaxStructureId: "",
            TaxStructureName: "",
            IsTaxStructureSlab: false,
            IsTaxInclusive: "",

            IsMiscellaneous: false,
            MiscTaxStructureId: "",
            MiscTaxStructureName: "",
            IsMiscTaxStructureSlab: false,
            IsMiscTaxInclusive: "",
            IsActive: true,

            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName
        };

        //RevenueHead Sync with SPA 
        service.revenueHeadSync($scope.Model);

        $scope.Model.RevenueForId = "1";
        $scope.IsReadonly = false;
        $scope.bsId = "";
        $scope.Name = "";
        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;
        $scope.revenueHeadModel = {};
        $scope.save = "Save";
        $scope.blockData = [];
        $scope.blockDetails = [];
        $scope.rdoTax = "3";
        $scope.rdoMiscTax = "3";

        GetAuditCode();

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        getData($scope, service, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, service, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }

        function GetAuditCode() {
            var revenueForId = 1;// RevenueCode=1
            var promiseGet = service.getAuditCode($scope.PropertyID, revenueForId);
            promiseGet.then(function (data, status) {

                $scope.Model.AuditCode = data.Data;
                //$scope.revenueHeadAuditCode = $scope.AuditCode;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.RevenueClassificationTypes = [];
        $scope.RevenueTypes = [];
        GetRevenueClassificationType();
        GetRevenueType();

        function GetRevenueClassificationType() {
            var promiseGet = service.getRevenueClassificationType();
            promiseGet.then(function (data, status) {

                $scope.RevenueClassificationTypes = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        function GetRevenueType() {
            var promiseGet = service.getRevenueType();
            promiseGet.then(function (data, status) {

                $scope.RevenueTypes = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.AllTaxStructures = [];
        $scope.AllSlabStructures = [];
        $scope.AllWithoutSlabStructures = [];

        GetAllTaxStructure();
        function GetAllTaxStructure() {
            $scope.ActionMode = "";
            //var moduleId = 1;//front desk
            //var promiseGet = service.getAllTaxStructure(moduleId, $scope.PropertyID);
            var promiseGet = service.getAllTaxStructure($scope.PropertyID);
            promiseGet.then(function (data, status) {
                $scope.AllTaxStructures = data.Collection;
                angular.forEach($scope.AllTaxStructures, function (item) {
                    if (item.IsSlab) {
                        $scope.AllSlabStructures.push(item);
                    }
                    else {
                        $scope.AllWithoutSlabStructures.push(item);
                    }
                });
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.TaxStructures = [];
        $scope.getTaxStructures = function (id) {
            
            $scope.TaxStructures = [];
            if (id == 1) {
                $scope.TaxStructures = angular.copy($scope.AllWithoutSlabStructures);
            }
            else if (id == 2) {
                $scope.TaxStructures = angular.copy($scope.AllSlabStructures);
            }
            else {
                //$scope.TaxStructures = [];
                //$scope.Model.TaxStructureId = null;
            }
        };
        $scope.getMiscTaxStructures = function (id) {
            $scope.MiscTaxStructures = [];
            if (id == 1) {
                $scope.MiscTaxStructures = angular.copy($scope.AllWithoutSlabStructures);
            }
            else if (id == 2) {
                $scope.MiscTaxStructures = angular.copy($scope.AllSlabStructures);
            }
            else {
                //$scope.MiscTaxStructures = [];
                //$scope.Model.MiscTaxStructureId = null;
            }
        };
        function miscTaxDetails(isSlab, moduleId) {

            var promiseGet = service.getTaxStructureData(isSlab, moduleId, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                $scope.MiscTaxStructures = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        function taxDetails(isSlab, moduleId) {

            var promiseGet = service.getTaxStructureData(isSlab, moduleId, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                $scope.TaxStructures = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.isExist = function () {

            var promiseGet = service.getCodeExistRevenueHead($scope.Model.Code, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        // alert("Revenue Head Code Already Exist");
                        msg(data.Message);
                        $scope.Model.Code = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Model = {};
            $scope.Model.IsTaxStructureSlab = false;
            $scope.Model.IsMiscellaneous = false;
            $scope.Model.IsMiscTaxStructureSlab = false;
            $scope.Model.IsActive = true;
            $scope.rdoTax = "3";
            $scope.rdoMiscTax = "3";
            $scope.Model.RevenueForId = "1";

            $scope.IsReadonly = false;
            GetAuditCode();
            if ($scope.save !== "Save") {
                $scope.save = "Save";
            }
            $scope.searchfor = "";
            $scope.search();
            scrollPageOnTop();
        };
        $scope.Save = function (form) {
            
            //if ($scope.Model.RevenueForId != 1) {
            //    msg("You cann't modify System Generated Revenue Head.");
            //    return;
            //}
            if ($scope[form].$valid) {

                if ($scope.rdoTax != "3") {
                    if ($scope.Model.TaxStructureId == undefined) {
                        msg("Please Select Tax Structure.");
                        return;
                    }
                }
                if ($scope.rdoMiscTax != "3") {
                    if ($scope.Model.TaxStructureId == undefined) {
                        msg("Please Select Misc Tax Structure.");
                        return;
                    }
                }

                if ($scope.rdoTax == 3) {
                    $scope.Model.TaxStructureId = null;
                }

                if ($scope.rdoMiscTax == 3) {
                    $scope.Model.MiscTaxStructureId = null;
                }

                $scope.Model.RevenueForId = 1; //For RevenueHead
                $scope.Model.PropertyId = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.UserName;
                $scope.Model.ModifiedDate = $scope.ModifiedDate;

                var promiseGet = service.save($scope.Model);
                promiseGet.then(function (data, status) {
                    getData($scope, service, localStorageService);
                    GetAuditCode();
                    $scope.reset();
                    if (data.Status) { msg('Revenue Head ' + data.Message, true); }
                },
                function (error, status) {
                    msg(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.ChangeStatus = function (model) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            $scope.Model.Id = model.Id;
            $scope.Model.PropertyId = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            $scope.Model.ModifiedDate = $scope.ModifiedDate;

            var promiseGet = service.changeStatus($scope.Model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);
                if (data.Status) { msg(data.Message, true); }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.ActionMode = "";
        $scope.Edit = function (record) {
            $scope.ActionMode = "Edit";
            $scope.TaxStructures = [];
            $scope.MiscTaxStructures = [];
            $scope.Model = record;

            if ($scope.Model.TaxStructureId == null) {
                $scope.rdoTax = "3";
                $scope.TaxStructures = [];
                $scope.Model.TaxStructureId = null;
            }
            else {
                if ($scope.Model.IsTaxStructureSlab == true) {
                    $scope.rdoTax = "2";
                    $scope.TaxStructures = angular.copy($scope.AllSlabStructures);
                }
                else {
                    $scope.rdoTax = "1";
                    $scope.TaxStructures = angular.copy($scope.AllWithoutSlabStructures);
                }
            }
            if ($scope.Model.MiscTaxStructureId == null) {
                $scope.rdoMiscTax = "3";
                $scope.MiscTaxStructures = [];
                $scope.Model.MiscTaxStructureId = null;
            }
            else {

                $scope.Model.IsMiscellaneous = true;

                if ($scope.Model.IsMiscTaxStructureSlab == true) {
                    $scope.rdoMiscTax = "2";
                    $scope.MiscTaxStructures = angular.copy($scope.AllSlabStructures);
                }
                else {
                    $scope.rdoMiscTax = "1";
                    $scope.MiscTaxStructures = angular.copy($scope.AllWithoutSlabStructures);
                }
            }

            $scope.Model.RevenueClassificationTypeId = record.RevenueClassificationTypeId.toString();
            $scope.Model.RevenueTypeId = record.RevenueTypeId.toString();
            $scope.Model.TaxStructureId = record.TaxStructureId;
            $scope.Model.MiscTaxStructureId = record.MiscTaxStructureId;
            $scope.IsReadonly = true;
            $scope.save = "Update";
            scrollPageOnTop();
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    
    $scope.data = dataService.dataAllData;
    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID,
    };

    dataService.getRevenueHead(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
