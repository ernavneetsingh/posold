﻿
app.controller('Controller', [
    '$scope', 'localStorageService', 'ViewCheckOutService', '$window', '$http', '$q', '$cookies', function (
        $scope, localStorageService, service, $window, $http, $q, $cookies) {

        //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        //$scope.UserId = localStorageService.get('UserId');
        initCommon($scope, $http, $q, localStorageService, $cookies);

        $scope.getRoomList = function () {
            service.getRoomList($scope.PropertyID).then(function (s) {
                $scope.RoomList = s.Collection;
            });
        };
        //$scope.getBillList = function () {
        //    service.getBillList($scope.PropertyID).then(function (s) {
        //        $scope.BillList = s.Collection;
        //    });
        //};

        $scope.search = function () {
            if (($scope.model.PeriodFrom && !$scope.model.PeriodTo) || (!$scope.model.PeriodFrom && $scope.model.PeriodTo)) {
                msg('Please enter both dates period from and period to.');
                return;
            }
            $scope.IsLoading = true;
            $scope.items = [];
            $scope.model.PropertyID = $scope.PropertyID;

            service.search($scope.model)
                .then(function (s) {
                    $scope.items = s.Collection;
                    $scope.IsLoading = false;
                    if (s.Collection.length > 0) $scope.MsgNotFound = "";
                    else $scope.MsgNotFound = "Record Not Found";
                }, function (err) {
                    $scope.IsLoading = false;
                    msg(err.Message);
                });
        };
        $scope.reset = function () {
            msg('');
            $scope.model = { PeriodFrom: $scope.ModifiedDate, PeriodTo: $scope.ModifiedDate };
            $scope.items = [];
            $scope.search();
        };

        $scope.print = function (id) {
            service.MapReport($scope.PropertyID, 'bill')
                .then(function (s) {
                    //$window.open(origin + '/Reporter/DisplayDesign?id=' + s.Data + '&table=FO_FOBill&pid=' + id, '_blank');
                    $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&table=FO_FOBill&pid=' + id, '_blank');
                }, function (e) {
                    msgInPopup('Error in mapping to print.');
                });
        };

        $scope.getRoomList();
        //$scope.getBillList();

    }
]);
