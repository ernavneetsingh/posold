﻿
app.service('DashboardService', function ($http, $q) {

    this.GetTotalPickUp = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetTotalPickUp", $http, $q, { propertyId: propertyId});
    };
    this.GetTotalTentativeBooking = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetTotalTentativeBooking", $http, $q, { propertyId: propertyId });
    };
    this.GetTotalPreArrival = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetTotalPreArrival", $http, $q, { propertyId: propertyId });
    };

    this.GetAllReservation = function (propertyId, date) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllReservation", $http, $q, { propertyId: propertyId, date: date });
    };
    this.GetAllCheckIn = function (propertyId, date) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllCheckIn", $http, $q, { propertyId: propertyId, date: date });
    };
    this.GetAllArrival = function (propertyId, date) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllArrival", $http, $q, { propertyId: propertyId, date: date });
    };
    this.GetAllOccupancy = function (propertyId, date) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllOccupancy", $http, $q, { propertyId: propertyId, date: date });
    };
    this.GetAllPickUp = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllPickUp", $http, $q, { propertyId: propertyId });
    };
    this.GetAllTentativeBooking = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllTentativeBooking", $http, $q, { propertyId: propertyId });
    };
    this.GetAllPreArrival = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/FODashboard/GetAllPreArrival", $http, $q, { propertyId: propertyId });
    };

    this.SendMailPickupDrop = function (reservationRoomTypeGuestId) {
        return httpCaller(apiPath + "FrontOffice/ReservationGuestPickupDrop/SendMail/" + reservationRoomTypeGuestId, $http, $q, {});
    };

    this.SendMailTentativeBooking = function (id, smsTemplateTypeId,propertyId, businessDate) {
        return httpPoster(apiPath + "FrontOffice/Reservation/SendMailTentativeBooking", $http, $q, { Id: id, SMSTemplateTypeId: smsTemplateTypeId, PropertyID: propertyId, BusinessDate: businessDate });
    };


    this.SMSSendNow = function (model) {

        var deferred = $q.defer();
        $http({
            method: "POST",
            url: apiPath + "FrontOffice/FODashboard/SendDashboardSMS",
            data: model,
            headers: { 'duxtechApiKey': accessToken }
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            msg(err.Message);
            deferred.reject(status);
        });

        return deferred.promise;
    };

});
