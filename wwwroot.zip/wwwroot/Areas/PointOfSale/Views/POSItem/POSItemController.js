﻿
app.controller("controller", [
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.LoginId = $cookies.get('LoginId');
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        //-----------------------------
        $scope.APIPath = apiPath;
        $scope.imageFile = "";
        $scope.IsUploading = false;
        $scope.ClearImage = function () {

            $scope.imageFile = { filesize: 0 };
            $scope.Model.ImageUrl = '';
            $scope.Model.UploadFile = '';
            scrollPageOnTop();
            document.getElementById("uploadCaptureInputFile").value = "";
        };
        $scope.GetFileSize = function () {
            var ftype = $scope.imageFile.filetype.split('/')[0];
            if (ftype !== 'image' || $scope.imageFile.filesize > 1048576) {
                msg('Please select image file of size less than 1 MB.');
                $scope.ClearImage();
            }
            var size = parseFloat($scope.imageFile.filesize) / 1024; //in kb
            size = $filter("number")(size, 2).replace(/,/g, "");
            $scope.fileSize = size.toString() + "KB";
        };

        //---------------------
        $scope.ClearImageLevelItem = function (index) {
            
            angular.forEach($scope.LevelItems, function (item, key) {
                if (index == key) {
                    item.imageFile = { filesize: 0 };
                    item.ImageUrl = '';
                    item.UploadFile = '';
                    scrollPageOnTop();
                    document.getElementById("uploadCaptureInputFile"+index).value = "";
                }
            });

        };

        $scope.GetFileSizeLevelItem = function (index) {
            angular.forEach($scope.LevelItems, function (item, key) {
                if(index==key)
                {
                    var ftype = item.imageFile.filetype.split('/')[0];
                    if (ftype !== 'image' || item.imageFile.filesize > 1048576) {
                        msg('Please select image file of size less than 1 MB.');
                        $scope.ClearImageLevelItem(index);
                    }
                    var size = parseFloat(item.imageFile.filesize) / 1024; //in kb
                    size = $filter("number")(size, 2).replace(/,/g, "");
                    item.fileSize = size.toString() + "KB";
                }
            });

        };

        //-----------------------------
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";

        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";

        var sortKeyOrder = {
            key: "",
            order: ""
        };
        localStorageService.set("searchfor", '');
        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        getData($scope, $filter, service, localStorageService);
        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, $filter, service, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, $filter, service, localStorageService);
        };
        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, $filter, service, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, $filter, service, localStorageService);
        }

        //-------------------------------------------
        $scope.Model = {
            Id: '',
            ApplicableFrom: '',
            CourseMealType: '',
            CourseMealTypeId: '',
            CourseMealTypeName: '',
            Code: '',
            Name: '',
            Description: '',
            HSNCode: '',
            SACCode:'',
            Costing: '',
            KitchenId: '',
            KitchenCode: '',
            KitchenName: '',
            UnitOfMeasurementId: '',
            UnitOfMeasurementSymbol: '',
            UnitOfMeasurementName: '',
            MenuGroupTypeId: '',
            MenuGroupTypeName: '',
            MenuCategoryId: '',
            MenuCategoryCode: '',
            MenuCategoryName: '',
            MenuSubCategoryId: '',
            MenuSubCategoryCode: '',
            MenuSubCategoryName: '',
            IsNCAllowed: 'false',
            IsInventoryItem: false,
            InventoryItemId: '',
            InventoryItemCode: '',
            InventoryItemName: '',
            OpeningQuantity: '',
            ItemColor: '',
            ImageUrl: '',
            ParentId: '',
            ParentItemName: '',
            IsActive: true,
            IsLevelItem: false,
            ModifierGroups: [],
            MenuCards: [],
            OutletItems: [],
            HappyHourItems: [],
            LevelItems: [],
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.ModifiedBy,
            DateFormat: $scope.DateFormat,
            items: []
        };

        $scope.LevelItems = [];
        $scope.OutletItems = [];
        $scope.Outlets = [];
        $scope.CourseMealTypes = [];

        //checklist-model------------------------------------------------------------------------------------

        $scope.MenuCards = [];
        $scope.SelectedMenuCard = {
            MenuCards: []
        };
        $scope.checkAllMenuCard = function () {
            $scope.SelectedMenuCard.MenuCards = $scope.MenuCards.map(function (item) { return item.Id; });
        };
        $scope.uncheckAllMenuCard = function () {
            $scope.SelectedMenuCard.MenuCards = [];
        };
        $scope.checkFirstMenuCard = function () {
            $scope.SelectedMenuCard.MenuCards.splice(0, $scope.SelectedMenuCard.MenuCards.length);
            $scope.SelectedMenuCard.MenuCards.push(1);
        };

        $scope.ModifierGroups = [];
        $scope.SelectedModifierGroup = {
            ModifierGroups: []
        };
        $scope.checkAllModifierGroup = function () {
            $scope.SelectedModifierGroup.ModifierGroups = $scope.ModifierGroups.map(function (item) { return item.Id; });
        };
        $scope.uncheckAllModifierGroup = function () {
            $scope.SelectedModifierGroup.ModifierGroups = [];
        };
        $scope.checkFirstModifierGroup = function () {
            $scope.SelectedModifierGroup.ModifierGroups.splice(0, $scope.SelectedModifierGroup.ModifierGroups.length);
            $scope.SelectedModifierGroup.ModifierGroups.push(1);
        };

        //end checklist-model------------------------------------------------------------------------------------

        $scope.ForDisplayStores = [];
        $scope.ForDisplayInventoryItems = [];
        $scope.ForDisplayBrands = [];

        $scope.MenuGroupTypes = [];
        $scope.MenuCategorys = [];
        $scope.MenuSubCategorys = [];
        $scope.UnitOfMeasurements = [];
        $scope.Kitchens = [];

        $scope.SelectedModifierGroups = [];
        $scope.SelectedMenuCards = [];
        $scope.TaxStructures = [];
        $scope.Outlets = [];
        $scope.ItemUnitOfMeasurements = [];

        //$scope.IsReadonly = false;

        //FORPERCENTAGE
        $scope.percent = 0;
        $scope.maxValue = 100;
        $scope.maxDecimals = 2;
        // $scope.dollarValue = '';
        $scope.currencyIncludeDecimals = true;

        GetTaxStructure();
        function GetTaxStructure() {
            var promiseGet = service.getTaxStructure($scope.PropertyID);
            promiseGet.then(function (d) {

                $scope.TaxStructures = d;
                GetOutlet();
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetCourseMealType();
        function GetCourseMealType() {
            var promiseGet = service.getCourseMealType();
            promiseGet.then(function (d) {
                $scope.CourseMealTypes = d;
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetMenuGroupType();
        function GetMenuGroupType() {
            var promiseGet = service.getMenuGroupType();
            promiseGet.then(function (d) {
                $scope.MenuGroupTypes = d;
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        $scope.GetMenuCategory = function (id) {

            $scope.MenuSubCategorys = [];
            var promiseGet = service.getMenuCategory(id, $scope.PropertyID);;
            promiseGet.then(function (d) {

                $scope.MenuCategorys = d;

            }, function (e) {

                parent.failureMessage(e.Message);
            });
        }
        $scope.GetMenuSubCategory = function (id) {

            var promiseGet = service.getMenuSubCategory(id, $scope.PropertyID);
            promiseGet.then(function (d) {

                $scope.MenuSubCategorys = d;

            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetUnitOfMeasurement();
        function GetUnitOfMeasurement() {

            var promiseGet = service.getUnitOfMeasurement($scope.PropertyID);
            promiseGet.then(function (d) {
                $scope.UnitOfMeasurements = d;
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetKitchen();
        function GetKitchen() {
            var promiseGet = service.getKitchen($scope.PropertyID);
            promiseGet.then(function (d) {
                $scope.Kitchens = d;
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetMenuCard();
        function GetMenuCard() {

            $scope.SelectedMenuCard.MenuCards = [];

            var promiseGet = service.getMenuCard($scope.PropertyID);
            promiseGet.then(function (d) {

                //$scope.MenuCards = d;
                if (!angular.isUndefinedOrNull(d)) {
                    angular.forEach(d, function (item) {
                        if (item.IsActive) {
                            $scope.MenuCards.push({
                                Id: item.Id,
                                Name: item.Name,
                                IsChecked: false,
                            });
                        }
                    });
                }
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetModifierGroup();
        function GetModifierGroup() {

            $scope.SelectedModifierGroup.ModifierGroups = [];

            var promiseGet = service.getModifierGroup($scope.PropertyID);
            promiseGet.then(function (d) {

                $scope.ModifierGroups = d;
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        GetStore();
        function GetStore() {
            var promiseGet = service.getStore($scope.PropertyID);
            promiseGet.then(function (d) {
                $scope.ForDisplayStores = d;
                if ($scope.LevelItems.length > 0) {
                    angular.forEach($scope.LevelItems, function (levelItem, key) {
                        levelItem.ForDisplayStores = [];
                        levelItem.ForDisplayStores = angular.copy($scope.ForDisplayStores);
                    });
                }
                else {
                    GetLevelItems();
                }
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        $scope.GetInventoryItem = function (id, index) {

            $scope.InventoryItems = [];
            $scope.ForDisplayBrands = [];
            var promiseGet = service.getInventoryItem(id, $scope.PropertyID);;
            promiseGet.then(function (d) {

                $scope.ForDisplayInventoryItems = d;
                if (!angular.isUndefinedOrNull(index)) {

                    angular.forEach($scope.LevelItems, function (levelItem, key) {
                        if (key == index) {
                            levelItem.ForDisplayInventoryItems = angular.copy($scope.ForDisplayInventoryItems);
                        }
                    });
                }
            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }
        $scope.GetItemBrand = function (id, index) {

            $scope.ForDisplayBrands = [];
            angular.forEach($scope.ForDisplayInventoryItems, function (item) {
                if (id == item.Id) {

                    $scope.ForDisplayBrands = angular.copy(item.Brands)

                    if (!angular.isUndefinedOrNull(index)) {

                        angular.forEach($scope.LevelItems, function (levelItem, key) {
                            if (key == index) {

                                if (levelItem.Code.length == 0) {
                                    levelItem.Code = item.Code;
                                }

                                if (levelItem.Name.length == 0) {
                                    levelItem.Name = item.Name;
                                }

                                levelItem.ForDisplayBrands = angular.copy(item.Brands);
                            }
                        });

                    }

                }
            });
        }

        function GetOutlet() {
            var promiseGet = service.getOutlet($scope.PropertyID);
            promiseGet.then(function (d) {
                $scope.Outlets = d;
                angular.forEach($scope.Outlets, function (outlet, key) {

                    var outletItem = {
                        OutletId: outlet.Id,
                        OutletName: outlet.Name,
                        IsChecked: false,
                        POSItemId: '',
                        Rate: 0,
                        IsDiscounted: 'false',
                        TaxStructureId: '',
                        ForDisplayTaxStuctures: []
                    };

                    if ($scope.TaxStructures.length > 0) {
                        angular.forEach($scope.TaxStructures, function (tax, key) {
                            if (tax.OutletId == outlet.Id) {
                                outletItem.ForDisplayTaxStuctures.push(tax);
                            }
                        });
                    }

                    $scope.OutletItems.push(outletItem);

                });


            },
              function (e) {
                  parent.failureMessage(e.Message);
              });
        }

        $scope.GetRelatedUnitOfMeasurement = function (id) {
            if (id)
            {
                var promiseGet = service.getRelatedUnitOfMeasurement(id, $scope.PropertyID);;
                promiseGet.then(function (d) {
                    $scope.ItemUnitOfMeasurements = d;
                    if ($scope.LevelItems.length > 0) {
                        angular.forEach($scope.LevelItems, function (levelItem, key) {
                            levelItem.ForDisplayUnitOfMeasurements = [];
                            levelItem.ForDisplayUnitOfMeasurements = angular.copy($scope.ItemUnitOfMeasurements);
                        });
                    }
                    else {
                        GetLevelItems();
                    }
                },
                  function (e) {
                      parent.failureMessage(e.Message);
                  });
            }
        }
        angular.isUndefinedOrNull = function (val) {
            return angular.isUndefined(val) || val === null
        }

        GetLevelItems();
        function GetLevelItems() {

            $scope.ItemUnitOfMeasurements = [];
            if (!angular.isUndefinedOrNull($scope.Model.UnitOfMeasurementId)) {
                $scope.GetRelatedUnitOfMeasurement($scope.Model.UnitOfMeasurementId);
            }
            for (var i = 1; i <= 6; ++i) {
                var levelItem = {
                    Id: '',

                    Code: '',
                    Name: '',
                    UnitOfMeasurementId: '',
                    UnitOfMeasurementSymbol: '',
                    UnitOfMeasurementName: '',
                    LevelItemRate: 0,
                    ForDisplayUnitOfMeasurements: [],
                    imageFile : { filesize: 0 },

                    StoreId: '',
                    StoreCode: '',
                    StoreName: '',
                    InventoryItemId: '',
                    InventoryItemCode: '',
                    InventoryItemName: '',
                    BrandId: '',
                    BrandCode: '',

                    ForDisplayStores: [],
                    ForDisplayInventoryItems: [],
                    ForDisplayBrands: [],
                };

                levelItem.ForDisplayUnitOfMeasurements = angular.copy($scope.ItemUnitOfMeasurements);
                levelItem.ForDisplayStores = angular.copy($scope.ForDisplayStores);

                $scope.LevelItems.push(levelItem);

            }
        }

        $scope.Save = function (model, form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                scrollPageOnTop();
                return;
            }

            //-----------------------------
            var ImageModel = {
                Base64: $scope.imageFile.base64,
                FileName: $scope.imageFile.filename,
                FileSize: $scope.imageFile.filesize,
                FileType: $scope.imageFile.filetype,
                PropertyID: $scope.PropertyID,
                EntityName: "POSItem"
            };
            if (ImageModel.Base64) {
                $scope.IsUploading = true;
                $scope.Model.ImageModel = ImageModel;
            }

            angular.forEach($scope.LevelItems, function (item, key) {
                
                if (item)
                {
                    if (item.imageFile)
                    {
                        var ImageModelLevelItem = {
                            Base64: item.imageFile.base64,
                            FileName: item.imageFile.filename,
                            FileSize: item.imageFile.filesize,
                            FileType: item.imageFile.filetype,
                            PropertyID: item.PropertyID,
                            EntityName: "POSItem"
                        };
                        if (ImageModelLevelItem.Base64) {
                            item.IsUploading = true;
                            item.ImageModel = item.imageFile;
                        }
                    }
                }
            });


            //-----------------------------
            if ($scope.Model.IsInventoryItem == false) {
                if ($scope.Model.KitchenId == '') {
                    msg("Please Select Kitchen.");
                    scrollPageOnTop();
                    return;
                }
            }

            var isExist = false;
            if ($scope.LevelItems.length > 0) {
                angular.forEach($scope.LevelItems, function (item, key) {
                    if ($scope.Model.Code == item.Code) {
                        isExist = true;
                    }
                });
            }

            if (isExist) {
                msg("Level Item Code cannot be same as POS Item.");
                scrollPageOnTop();
                return;
            }

            $scope.Model.MenuCards = [];
            angular.forEach($scope.SelectedMenuCard.MenuCards, function (id, key) {
                $scope.Model.MenuCards.push(
                    {
                        Id: id,
                    });
            });
            if ($scope.Model.MenuCards.length === 0) {
                msg("Please Select at least one Menu Cards.");
                scrollPageOnTop();
                return;
            }
            $scope.Model.ModifierGroups = [];
            angular.forEach($scope.SelectedModifierGroup.ModifierGroups, function (id, key) {
                $scope.Model.ModifierGroups.push(
                    {
                        Id: id,
                    });
            });
            if ($scope.Model.ModifierGroups.length === 0) {
                msg("Please Select at least one Modifier Group.");
                scrollPageOnTop();
                return;
            }

            var SelectedOutlets = [];

            angular.forEach($scope.OutletItems, function (outletItem, key) {
                if (outletItem.IsChecked) {
                    SelectedOutlets.push(outletItem);
                }
            });
            $scope.Model.OutletItems = [];
            $scope.Model.OutletItems = SelectedOutlets;
            if ($scope.Model.OutletItems.length === 0) {
                msg("Please Select at least one Outlet Item.");
                scrollPageOnTop();
                return;
            }

            $scope.Model.LevelItems = [];
            $scope.Model.LevelItems = $scope.LevelItems;

            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.ModifiedBy;

            var status = service.save($scope.Model);
            status.then(function (result) {

                if (result.Status == true) {
                    var msg1 = $scope.Model.Name + result.Message;
                    msg(msg1, true);
                    getData($scope, $filter, service, localStorageService);
                    scrollPageOnTop();
                }
                $scope.Reset();
            }, function (error) {

                scrollPageOnTop();
                msg(error.Message);
                //model.OutletItems = allOutletItems;
            });

        }
        $scope.changeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;
            var promise = service.status(model);
            promise.then(function (result) {

                if (result.Status == true) {
                    var msg1 = model.Name + ' ' + result.Message;
                    msg(msg1, true);
                    getData($scope, $filter, service, localStorageService);
                    $scope.Reset();
                    scrollPageOnTop();
                }
                //$scope.Reset();
            }, function (error) {

                //scrollPageOnTop();
                msg(error.Message);
            });
        }
        $scope.remove = function (id) {

            var promise = service.remove(id);
            promise.then(function (result) {

                if (result.Status == true) {
                    msg(result.Message, true);
                    getData($scope, $filter, service, localStorageService);
                    $scope.Reset();
                    scrollPageOnTop();
                }
            }, function (error) {

                msg(error.Message);
            });
        }

        $scope.Remove = function (model) {
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            $scope.Model.Id = "";
                            msg("Item successfully deleted.", true);
                            getData($scope, $filter, service, localStorageService);
                        });


                        $.fancybox.close();
                    });
                }
            });
        }

        $scope.ResetOutlet = function () {

        }
        function ResetCheckBox() {

        }

        $scope.Reset = function () {
            Reset();
        }
        function Reset() {
            $scope.imageFile = "";
            $scope.IsUploading = false;
            $scope.Model = {};
            $scope.Model.IsNCAllowed = 'true';
            $scope.Model.LevelItems = [];

            $scope.Model.MenuCards = [];
            $scope.Model.ModifierGroups = [];

            $scope.SelectedMenuCard.MenuCards = [];
            $scope.SelectedModifierGroup.ModifierGroups = [];

            $scope.LevelItems = [];
            GetLevelItems();


            //$scope.Model.ApplicableFrom = '';
            //$scope.Model.Code = '';
            //$scope.Model.Name = '';

            //$scope.Model.Description = '';
            //$scope.Model.MenuGroupTypeId = '';
            //$scope.Model.MenuCategoryId = '';
            //$scope.Model.MenuSubCategoryId = '';
            //$scope.Model.CourseMealTypeId = '';
            //$scope.Model.UnitOfMeasurementId = '';
            //$scope.Model.Costing = '';
            //$scope.Model.IsNCAllowed = '';
            //$scope.Model.KitchenId = '';

            ////$scope.Model = {};
            ////GetOutlet();

            getData($scope, $filter, service, localStorageService);

            //

            $scope.Model.IsActive = true;

            $scope.IsReadonly = false;

            $('input:checkbox').removeAttr('checked');

            angular.forEach($scope.OutletItems, function (outletItem, key) {
                outletItem.IsChecked = false;
                outletItem.Rate = 0;
                outletItem.IsDiscounted = "false";
                outletItem.TaxStructureId = "";
            });

            $scope.searchfor = '';
            $scope.query = '';
            $scope.search('');

        }
        $scope.ItemViewModels = '';
        $scope.Edit = function (item) {
            Reset();
            var promiseGet = service.getGetById(item.Id);
            promiseGet.then(function (data) {
                $scope.Model = data.Data;
                if (!angular.isUndefinedOrNull($scope.Model)) {
                    $scope.Model.ApplicableFrom = $filter('date')($scope.Model.ApplicableFrom, $scope.DateFormat);
                    //$scope.Model.Costing = $scope.Model.Costing.toString();
                    $scope.Model.CourseMealTypeId = $scope.Model.CourseMealType.toString();
                    $scope.Model.IsNCAllowed = $scope.Model.IsNCAllowed.toString();
                    $scope.Model.MenuGroupTypeId = $scope.Model.MenuGroupTypeId.toString();
                    $scope.GetMenuCategory($scope.Model.MenuGroupTypeId);
                    $scope.Model.MenuCategoryId = $scope.Model.MenuCategoryId.toString();
                    $scope.GetMenuSubCategory($scope.Model.MenuCategoryId);
                    $scope.Model.MenuSubCategoryId = $scope.Model.MenuSubCategoryId.toString();
                    if ($scope.Model.IsInventoryItem) {
                        $scope.GetInventoryItem($scope.Model.StoreId);
                        $scope.ForDisplayBrands = $scope.Model.ForDisplayBrands;
                    }

                    //$scope.GetRelatedUnitOfMeasurement($scope.Model.UnitOfMeasurementId);
                    $scope.Model.UnitOfMeasurementId = $scope.Model.UnitOfMeasurementId;
                    angular.forEach($scope.Model.MenuCards, function (item) {
                        $scope.SelectedMenuCard.MenuCards.push(item.Id);
                    });
                    angular.forEach($scope.Model.ModifierGroups, function (item) {
                        $scope.SelectedModifierGroup.ModifierGroups.push(item.Id);
                    });

                    $scope.Model.MenuCards = [];
                    $scope.Model.ModifierGroups = [];

                    $scope.LevelItems = [];
                    GetLevelItems();
                    SetOutletRate($scope.Model.OutletItems);
                    if ($scope.Model.IsLevelItem) {
                        SetLevelItem($scope.Model.LevelItems)
                    }
                    $scope.IsReadonly = true;
                }


            },
                function (error) {
                    msg(error.Message);
                });


            scrollPageOnTop();
        }

        function SetOutletRate(outletitems) {
            angular.forEach($scope.OutletItems, function (outletItem, key) {
                angular.forEach(outletitems, function (oi) {
                    if (oi.OutletId == outletItem.OutletId) {
                        outletItem.IsChecked = true;
                        outletItem.Rate = oi.Rate;
                        outletItem.IsDiscounted = oi.IsDiscounted == true ? "true" : "false";
                        outletItem.TaxStructureId = oi.TaxStructureId;
                    }
                });
            });
        }
        $scope.checkAllOutlet = function () {
            angular.forEach($scope.OutletItems, function (outlet) {
                outlet.IsChecked = true;
            });
        };
        $scope.uncheckAllOutlet = function () {
            angular.forEach($scope.OutletItems, function (outlet) {
                outlet.IsChecked = false;
            });
        };

        function SetLevelItem(levelitems) {
            angular.forEach(levelitems, function (li, index) {
                $scope.LevelItems[index].Id = li.Id;
                $scope.LevelItems[index].Code = li.Code;
                $scope.LevelItems[index].Name = li.Name;
                $scope.LevelItems[index].UnitOfMeasurementId = li.UnitOfMeasurementId;
                $scope.LevelItems[index].LevelItemRate = li.LevelItemRate;
                $scope.LevelItems[index].ImageUrl = li.ImageUrl;
                $scope.LevelItems[index].ImageUrlForDisplay = li.ImageUrlForDisplay;
                $scope.LevelItems[index].ForDisplayStores = angular.copy($scope.ForDisplayStores);

                if (li.IsLevelItem) {
                    $scope.LevelItems[index].StoreId = li.StoreId;
                    $scope.GetInventoryItem(li.StoreId, index);
                    $scope.LevelItems[index].InventoryItemId = li.InventoryItemId;
                    $scope.LevelItems[index].ForDisplayBrands = li.ForDisplayBrands;
                    $scope.LevelItems[index].BrandId = li.BrandId;
                }
            });
        }

        $scope.formdata = new FormData();
        $scope.getTheFiles = function ($files, fd) {
            angular.forEach($files, function (value, key) {

                fd.append(key, value);
            });
        };
        $scope.uploadExcel = function (fd) {

            $scope.IsUploadingExcel = true;
            service.saveFromExcel(fd, $scope)
                .then(function () {
                    getData($scope, $filter, service, localStorageService);

                });

        };


    }
]);

var getData = function ($scope, $filter, dataService, localStorageService) {

    $scope.data = dataService.alldata;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Name",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getData($scope.PropertyID, options)
        .then(function (totalItems) {
            angular.forEach($scope.data, function (item) {
                item.ApplicableFrom = $filter('date')(item.ApplicableFrom, $scope.DateFormat);
            });

            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};
