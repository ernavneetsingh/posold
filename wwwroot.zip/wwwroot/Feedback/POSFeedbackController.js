﻿
app.controller("controller",[
    "$scope", "service", "$http", "$filter", "$window", "localStorageService", function (
        $scope, service, $http, $filter, $window, localStorageService) {
        
        $scope.Model = {
            FeedbackRatingOptions: []
        }
        
        var url = window.location.href;
        $scope.KOTBillId = getParameterByName('Id', url);
        $scope.ModuleId = 3;
        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }
        $scope.OutletImageUrl = '';
        function GetRating(id,moduleId) {
            
            $scope.OutletImageUrl = '';
            $scope.IsLoading = true;
            var promiseGet = service.getRating(id, moduleId);
            promiseGet.then(function (data) {
                $scope.Ratings = data.Collection;
                
                $scope.OutletImageUrl = apiPath + $scope.Ratings[0].OutletImageUrl;
                $scope.ResetRating();
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        }

        GetRating($scope.KOTBillId,$scope.ModuleId);

        $scope.SetRating =function(rating)
        {
            $scope.ResetRating();

            $scope.Selected = rating;

            angular.forEach($scope.Ratings, function (item) {
                if(item.Code <= rating.Code)
                {
                    item.Color = "#FFD700";
                }
            });
        }

        $scope.ResetRating = function () {

            angular.forEach($scope.Ratings, function (item) {
                item.Color = "#FFFFFF";
            });
        }
        
        $scope.syncOption = function (bool, item) {
            
            if (bool) {
                $scope.Model.FeedbackRatingOptions.push(item);
            } else {
                for (var i = 0 ; i < $scope.Model.FeedbackRatingOptions.length; i++) {
                    if ($scope.Model.FeedbackRatingOptions[i].Id == item.Id) {
                        $scope.Model.FeedbackRatingOptions.splice(i, 1);
                    }
                }
            }
        };

        $scope.IsThanks = false;
        $scope.Save = function () {
            
            if (!$scope.Selected) {
                parent.failureMessage('Please Select Rating.');
                return;
            }

            $scope.Model.PropertyID = $scope.Selected.PropertyID;
            $scope.Model.ModifiedBy = $scope.Selected.ModifiedBy;
            $scope.Model.KOTBillId = $scope.KOTBillId;
            $scope.Model.RatingId = $scope.Selected.Id;
            
            var status = service.save($scope.Model);
            status.then(function (result) {
                if (result.Status == true) {
                    $scope.IsThanks = true;
                    parent.successMessage("Thanks For Your Feedback.");
                }

            },
         function (error) {

             scrollPageOnTop();
             parent.failureMessage(error.Message);
         });
        };

    }
]);