﻿
app.service('GuestManagementService', [
    "$http", "$q", function (
        $http, $q) {

        this.getReservationList = function (propertyId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/Reservation/AllByPropertyId/TillDays", $http, $q, { propertyId: propertyId, businessDate: businessDate, tillDays: 30 });
        };
        this.getReservation = function (propertyId, id, businessDate) {
            return httpCaller(apiPath + "FrontOffice/Reservation/GetById/" + id + "/" + propertyId + "/" + businessDate, $http, $q);
        };
        this.getRoomList = function (propertyId, date) {
            return httpCaller(apiPath + "FrontOffice/RoomStatus/GetAllByOccupiedRoom", $http, $q, { propertyId: propertyId, businessDate: date });
        };
        this.getGuestList = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/Guest/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getCorporateList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/Corporate/allByPropertyId/" + propertyId, $http, $q);
        };
        this.getDepartmentList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/Department/allByPropertyId", $http, $q, { propertyId: propertyId });
        };

        this.getList = function (propertyId, messageTypeId, messageForTypeId) {
            return httpCaller(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId", $http, $q, { propertyId: propertyId, messageTypeId: messageTypeId, messageForTypeId: messageForTypeId, messageActionId: 12, numberofdays: 20 });
        };

    }
]);
