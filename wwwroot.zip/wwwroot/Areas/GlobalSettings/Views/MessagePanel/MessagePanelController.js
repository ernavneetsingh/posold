﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');

        //Reservation SearchModel

        //-----------------------------------------------------------
        //Paging
        //-----------------------------------------------------------
        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        getData($scope, service, localStorageService);
        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, service, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {

            $scope.SearchList = [];
            $scope.IsProgress = true;
            $scope.SearchModel.PropertyID = $scope.PropertyID;
            $scope.SearchModel.IsPending = true;

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);

            getData($scope, service, localStorageService);

        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }
        //-----------------------------------------------------------
        $scope.IsSave = false;
        //Reservation SearchModel
        $scope.SearchModel.ModuleId='3';
        $scope.ResetSearch = function () {
            $scope.SearchModel = {ModuleId:'3', IsExactSearch: true,IsSMS:false, IsEMail:false,MessagePanelTypeId:0};
            $scope.IsLocationSearch = false;
            $scope.IsAllSelected = false;
            angular.forEach($scope.SearchList, function (item) {
                item.IsSelected = false;
            });

        }

        $scope.IsAllSelected = false;
        $scope.SetCheckBox = function () {
            angular.forEach($scope.SearchList, function (item) {
                item.IsSelected = $scope.IsAllSelected;
            });
        }

        $scope.Save = function (form) {

            

            if (!$scope.SearchModel.MessagePanelTypeId) {
                msg("Please Select Message Type.");
                return;
            }

            if (!$scope.SearchModel.IsSMS && !$scope.SearchModel.IsEMail) {
                msg("Please Select Send SMS/EMail.");
                return;
            }

            //var model = {
            //    ModuleId: $scope.ModuleId,
            //    MessagePanelTypeId: $scope.MessagePanelTypeId,
            //    IsSMS: $scope.IsSMS,
            //    IsEMail: $scope.IsEMail,
            //    Customers:[],
            //}

            $scope.SearchModel.PropertyID = $scope.PropertyID;
            $scope.SearchModel.ModifiedBy = $scope.ModifiedBy;
            $scope.SearchModel.ModifiedDate = $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' +  $scope.BusinessDate.Day;
            $scope.SearchModel.Customers = [];
            angular.forEach($scope.SearchList, function (item) {
                if(item.IsSelected)
                {
                    $scope.SearchModel.Customers.push(item);
                }
            });

            if ($scope.SearchModel.Customers.length == 0)
            {
                msg("Please Select Customer.");
                return;
            }
            $scope.IsSave = true;
            var promiseGet = service.save($scope.SearchModel);
            promiseGet.then(function (data, status) {
                
                $scope.IsSave = false;
                $scope.ResetSearch();
                msg(data.Message, data.Status);
            },
            function (error, status) {
                $scope.IsSave = false;
                msg(error.Message);
            });
        };
    }
]);


var getData = function ($scope, dataService, localStorageService) {
    
    $scope.IsProgress = true;

    $scope.SearchList = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Name",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");

    if (!$scope.SearchModel) {
        $scope.SearchModel = {};
    }
    

    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        CurrentPage: $scope.currentPage,
        RecordsPerPage: $scope.recordsPerPage,

        SortKey: "PropertyWiseID",
        SortKeyOrder: "ASC",

        Searchfor: searchfor,
        PropertyID: $scope.PropertyID,

        Model: $scope.SearchModel
    };

    dataService.getSearchPOS(options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.IsProgress = false;
        },
        function () {
            $scope.IsProgress = false;
            msg("The request failed. Unable to connect to the remote server.");
        });


};
