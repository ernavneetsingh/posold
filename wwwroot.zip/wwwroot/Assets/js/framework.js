﻿
function successMessage(successMsg) {
    if (successMsg != undefined && successMsg != '' && successMsg != "") {
        $('#successStatusShow').empty();
        $('#successStatusShow').show();
        $('#successStatusShow').append(successMsg);
        setTimeout(function () {
            $('#successStatusShow').hide();
            $('#successStatusShow').append("");
        }, 5000);
    }
}

function failureMessage(errorMsg) {
    console.log(errorMsg);
    if (errorMsg != undefined && errorMsg != '' && errorMsg != "") {
        $('#failureStatusShow').empty();
        $('#failureStatusShow').show();
        $('#failureStatusShow').append(errorMsg);
        setTimeout(function () {
            $('#failureStatusShow').hide();
            $('#failureStatusShow').append("");
        }, 5000);
    }
}

function OnlyNumberKey(e) {
    var keys = new Array();
    keys.push(8);
    var keyCode = e.which ? e.which : e.keyCode;
    var ret = ((keyCode >= 48 && keyCode <= 57) || keys.indexOf(keyCode) != -1);
    console.log(keyCode);
    return ret;
}

function ValidateAlpha(evt) {
    var keyCode = (evt.which) ? evt.which : evt.keyCode;
    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
        return false;
    return true;
}

function RestrictSpace() {
    if (event.keyCode === 32) {
        return false;
    }
    return true;
}

function scrollPageOnTop() {
    $("html, body").animate({ scrollTop: 0 }, "slow");
}


function validtimefrmt(id) {
    var txtbox = id;
    var str1 = document.getElementById(txtbox).value;
    var str = new Array();
    str = str1.split(':');
    if (str.length == 1) {
        if (str[0].length == 2) {
            if (parseInt(str[0]) >= 24) {
                str1 = '';
            } else {
                str1 = str[0] + ':';
            }
        }
    } else if (str.length >= 2) {
        //alert(str[1]);
        if (parseInt(str[1]) >= 60) {
            str1 = str[0] + ':';
        } else {
            if (str[1].length == 2) {
                var add1 = "AM";
                if (parseInt(str[0]) > 12) {
                    add1 = "";
                }
                if (parseInt(str[0]) == 12) {
                    add1 = "PM";
                }
                str1 = str[0] + ':' + str[1] + " " + add1;
            }
            if (str[1].length == 1) {
                str1 = str[0] + ':' + str[1];
            }
        }
    }
    if (str[0].length > 2) {
        str1 = '';
    }
    document.getElementById(txtbox).value = str1;
}


function posSuccessMessage(successMessage) {
    if (successMessage != undefined && successMessage != '' && successMessage != "") {
        $('.posSuccessMessage').empty();
        $('.posSuccessMessage').show();
        $('.posSuccessMessage').append(successMessage);
        setTimeout(function () {
            $('.posSuccessMessage').hide();
            $('.posSuccessMessage').append("");
        }, 2000);
    }
}

function posFailureMessage(errorMessage) {
    if (errorMessage != undefined && errorMessage != '' && errorMessage != "") {
        $('.posErrorMessage').empty();
        $('.posErrorMessage').show();
        $('.posErrorMessage').append(errorMessage);
        setTimeout(function () {
            $('.posErrorMessage').hide();
            $('.posErrorMessage').append("");
        }, 2000);
    }
}

function closePosMessage() {
    $('.posErrorMessage').empty();
    $('.posErrorMessage').hide("slow");
    $('.posErrorMessage').append("");
    $('.posSuccessMessage').empty();
    $('.posSuccessMessage').hide("slow");
    $('.posSuccessMessage').append("");
}



function popSuccessMessage(successMessage) {
    if (successMessage != undefined && successMessage != '' && successMessage != "") {
        $('.popSuccessMessage').empty();
        $('.popSuccessMessage').show();
        $('.popSuccessMessage').append(successMessage);
        setTimeout(function () {
            $('.popSuccessMessage').hide();
            $('.popSuccessMessage').append("");
        }, 2000);
    }
}

function popErrorMessage(errorMessage, intervel) {

    if (!intervel)
    {
        intervel = 2000;
    }

    if (errorMessage != undefined && errorMessage != '' && errorMessage != "") {
        $('.popErrorMessage').empty();
        $('.popErrorMessage').show();
        $('.popErrorMessage').append(errorMessage);
        setTimeout(function () {
            $('.popErrorMessage').hide();
            $('.popErrorMessage').append("");
        }, intervel);
    }
}

function closePopMessage() {
    $('.popErrorMessage').empty();
    $('.popErrorMessage').hide("slow");
    $('.popErrorMessage').append("");
    $('.popSuccessMessage').empty();
    $('.popSuccessMessage').hide("slow");
    $('.popSuccessMessage').append("");
}