﻿
app.service('POSMapService', [
    '$http', '$q', function ($http, $q) {
        this.getOutlet = function (propertyId) {
            return httpCaller(apiPath + "PointOfSale/Outlet/allByPropertyIdmin/" + propertyId, $http, $q);
        };
        this.getPOSMap = function (outletId) {
            return httpCaller(apiPath + "Tally/POSMap/GetOutlet/" + outletId, $http, $q);
        };
        //this.getMenuCategory = function (propertyId) {
        //    return httpCaller(apiPath + "PointOfSale/MenuCategory/allByStatus?propertyId=" + propertyId, $http, $q);
        //};
        //this.getTax = function (propertyId) {
        //    return httpCaller(apiPath + "GlobalSetting/RevenueHead/revenuedetails/" + propertyId + "/4", $http, $q);
        //};
        //this.getSettlement = function (propertyId) {
        //    return httpCaller(apiPath + "GlobalSetting/RevenueHead/revenuedetails/" + propertyId + "/5", $http, $q);
        //};
        this.getAccountDump = function (propertyId) {
            return httpCaller(apiPath + "Tally/AccountDump/GetAll?propertyId=" + propertyId, $http, $q);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "Tally/POSMap/Save", $http, $q, model);
        };
    }
]);
