﻿
app.controller("GuestClassTaxExemptionController",
[
    "$scope", "$cookies", "GuestClassTaxExemptionService", "$filter", "localStorageService", function ($scope, $cookies, guestClassTaxExemptionService, $filter, localStorageService) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.Model = {
            Id: "",
            ApplicableFrom: "",
            GuestClassId: "",
            GuestClassName: "1",
            IsRevenueExempt: "",
            IsTaxesExempt: "",
            IsMultiTaxesExempt: "",
            SelectedTaxes: [],
            TaxTypes: [],
            IsActive: true,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName,
            DateFormat: $scope.DateFormat
        };

        $scope.IsReadonly = false;

        $scope.Save = "Save";
        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";
        $scope.TaxExemption = [];
        $scope.SelectedTaxes = [];

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.extraSettings = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true
        };

        $scope.extraSettings = {
            displayProp: 'Name'
        };

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        getTaxTypeDetails();
        getGuestClassDetails();
        getDefaultDetails();

        getData($scope, guestClassTaxExemptionService, localStorageService);
        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, guestClassTaxExemptionService, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, guestClassTaxExemptionService, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, guestClassTaxExemptionService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, guestClassTaxExemptionService, localStorageService);
        }

        $scope.isExist = function () {
            var promiseGet = guestClassTaxExemptionService.getCodeExistBlock($scope.blockCode, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        msg(data.Message);
                        $scope.blockCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.DefaultDetails = function () {
            getDefaultDetails();
        };
        function getDefaultDetails() {
            $("#IsRevenueExemptId").prop("checked", false);
            $("#IsTaxExemptId").prop("checked", false);
            $("#IsMultiTaxExemptId").prop("checked", false);
            if ($scope.Model.GuestClassName == "1") {
                $("#IsRevenueExemptId").prop("disabled", true);
                $("#IsTaxExemptId").prop("disabled", true);
                $("#IsMultiTaxExemptId").prop("disabled", true);
                $("#TaxStructureDetailsId").prop("disabled", true);
                $scope.Model.IsMultiTaxExempt = false;
            }
            else if ($scope.Model.GuestClassName == "2") {

                $("#IsRevenueExemptId").prop("disabled", false);
                $("#IsTaxExemptId").prop("disabled", true);
                $("#IsMultiTaxExemptId").prop("disabled", true);
                $("#TaxStructureDetailsId").prop("disabled", true);
                $scope.Model.IsMultiTaxExempt = false;
            }
            else if ($scope.Model.GuestClassName == "3") {
                $("#IsRevenueExemptId").prop("disabled", true);
                $("#IsTaxExemptId").prop("disabled", true);
                $("#IsMultiTaxExemptId").prop("disabled", false);
                $("#TaxStructureDetailsId").prop("disabled", false);
                $scope.Model.IsMultiTaxExempt = false;
            }
            else {
                $("#IsRevenueExemptId").prop("disabled", true);
                $("#IsTaxExemptId").prop("disabled", false);
                $("#IsMultiTaxExemptId").prop("disabled", true);
                $("#TaxStructureDetailsId").prop("disabled", true);
            }
        };

        function getTaxTypeDetails() {
            var promiseGet = guestClassTaxExemptionService.getTaxTypeData();
            promiseGet.then(function (data, status) {

                $scope.TaxStructureDetails = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        function getGuestClassDetails() {
            var promiseGet = guestClassTaxExemptionService.getGuestClassExemptionData();
            promiseGet.then(function (data, status) {
                $scope.GuestClassDetails = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Model = {};
            $scope.IsActive = true;
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            $scope.search();
        };
        $scope.Save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            var bsObj = new Object();
            bsObj.Id = $scope.Model.Id;
            bsObj.ApplicableFrom = GetServerDate($scope.Model.ApplicableFrom, $scope.DateFormat);
            bsObj.GuestClassName = $scope.Model.GuestClassName;
            bsObj.GuestClassId = $scope.Model.GuestClassName;

            bsObj.IsRevenueExempt = $scope.Model.IsRevenueExempt;
            bsObj.IsTaxesExempt = $scope.Model.IsTaxesExempt;
            bsObj.IsMultiTaxesExempt = $scope.Model.IsMultiTaxesExempt;
            bsObj.TaxTypes = $scope.Model.SelectedTaxes;

            bsObj.IsActive = $scope.Model.IsActive;
            bsObj.PropertyId = $scope.Model.PropertyID;
            bsObj.ModifiedBy = $scope.Model.ModifiedBy;
            bsObj.DateFormat = $scope.Model.DateFormat;

            var promiseGet = guestClassTaxExemptionService.save(bsObj);
            promiseGet.then(function (data, status) {

                getData($scope, guestClassTaxExemptionService, localStorageService);
                $scope.reset();
                msg(data.Message, data.Status);
            }, function (error, status) {
                msg(error.Message);
            });

        };
        $scope.ChangeStatus = function (d) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            d.ModifiedBy = $scope.UserName;
            d.PropertyID = $scope.PropertyID;
            var promiseGet = guestClassTaxExemptionService.changeStaus(d);
            promiseGet.then(function (data, status) {
                getData($scope, guestClassTaxExemptionService, localStorageService);
                msg(data.Message, data.Status);
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.Delete = function (data) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Tax Exemption?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {
                            ret = true;
                            var deleteGuestStatus = guestClassTaxExemptionService.deleteGuestClassTaxExemption(data.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {
                                getData($scope, guestClassTaxExemptionService, localStorageService);
                                msg(d.Message, d.Status);
                            }, function (err) {
                                msg($.parseJSON(err.responseText).Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.Model.Id = record.Id;
            //$scope.Model.ApplicableFrom = record.ApplicableFrom;
            $scope.Model.ApplicableFrom = $filter('date')(record.ApplicableFrom, $scope.DateFormat);
            $scope.Model.GuestClassName = record.GuestClassId.toString();
            $scope.DefaultDetails();
            $scope.Model.IsRevenueExempt = record.IsRevenueExempt;
            $scope.Model.IsTaxesExempt = record.IsTaxesExempt;
            $scope.Model.IsMultiTaxExempt = record.IsMultiTaxExempt;
            $("IsMultiTaxExemptId").prop("checked", record.IsMultiTaxesExempt);
            $scope.Model.SelectedTaxes = record.TaxTypes;
            //$scope.SelectedTaxes = record.MultiTaxExempt;

            $scope.IsActive = record.IsActive;
            $scope.IsReadonly = true;
            $scope.Save = "Update";
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getGuestClassTaxExemption(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
