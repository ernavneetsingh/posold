﻿
(function () {
    function blockService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var linkModule = [];
        var getBlock = function (options) {

            var url = apiPath + "FrontOffice/Block/GetAll?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        //function getBlockData(blockId, propertyId) {

        //    var deferred = $q.defer();
        //    $http({
        //        method: "GET",
        //        url: apiPath + "FrontOffice/Block/GetAllByBlockId/" + blockId + "/" + propertyId,
        //        data: {},
        //        headers: { 'duxtechApiKey': accessToken },
        //        contentType: "application/json; charset=utf-8"
        //    }).success(function (data, status, headers, cfg) {
        //        deferred.resolve(data);
        //    }).error(function (err, status) {
        //        deferred.reject(status);
        //    });
        //    return deferred.promise;
        //};

        function getCodeExistBlock(blockCode, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/Block/IsExist/" + blockCode + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function saveBlock(blockModel) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/Block/Save",
                data: blockModel,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function updateIsActiveBlock(blockId, isActive, propertyId, userName) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/Block/update?blockId=" + blockId + "&isActive=" + isActive + "&propertyId=" + propertyId + "&userName=" + userName,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function deleteBlock(blockId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/Block/delete/" + blockId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                msg(err.Message);
                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function changeStatus(model) {
            return httpPoster(apiPath + "FrontOffice/Block/Status", $http, $q, model);
        };

        var service = {
            changeStatus: changeStatus,
            dataAllData: linkModule,
            getBlock: getBlock,
            getCodeExistBlock: getCodeExistBlock,
            saveBlock: saveBlock,
            //getBlockData: getBlockData,
            updateIsActiveBlock: updateIsActiveBlock,
            deleteBlock: deleteBlock
        };
        return service;
    }

    app.factory("BlockService", ["$http", "$q", blockService]);
})();
