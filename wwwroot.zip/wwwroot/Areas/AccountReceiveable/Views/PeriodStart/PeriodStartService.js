﻿


app.service("periodStartService", function () {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.GetAll = function (propertyId) {
        return httpCaller(apiPath + "AccountReceiveable/PeriodStart/all/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/PeriodStart/all/" + propertyId,
        //    params: {},            
        //    dataType: "json", 
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
                
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.Get = function (propertyId) {
        return httpCaller(apiPath + "AccountReceiveable/PeriodStart/get/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/PeriodStart/get/" + propertyId,
        //    params: {},            
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
                
        //        parent.failureMessage(data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.Save = function (model) {
        return httpPoster(apiPath + "AccountReceiveable/PeriodStart/save", $http, $q, model);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "AccountReceiveable/PeriodStart/save/",
        //    data: JSON.stringify(model),            
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };
});