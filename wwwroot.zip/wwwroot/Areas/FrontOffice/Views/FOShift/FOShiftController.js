﻿apppos.controller("controller", [
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout", "$window", function ($scope, service, $cookies, $filter, localStorageService, $timeout, $window) {

        $scope.IsLoading = false;
        $scope.IsReadonly = false;

        $scope.UserName = $cookies.get('UserName');
        if (!$scope.UserName) {
            $scope.UserName = localStorageService.get('UserName');
        }

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.PropertyName = localStorageService.get('PropertyName');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);

        $scope.timeFormat = "hh:mm:ss a";
        $scope.format = "dd/MMM/yyyy h:mm:ss a";

        $scope.Clock = "loading clock..."; // initialise the time variable
        $scope.tickInterval = 1000 //ms
        var tick = function () {
            $scope.Clock = $filter("date")(new Date, $scope.timeFormat);
            $timeout(tick, $scope.tickInterval); // reset the timer
        }
        // Start the timer
        $timeout(tick, $scope.tickInterval);

        $scope.SelectedShift = false;

        $scope.Model =
            {
                Id: '',
                ShiftNumber: '',
                ShiftDate: '',
                ShiftTime: '',
                ShiftCloseDate: '',
                ShiftCloseTime: '',
                UserId: '',
                UserName: '',
                IsActive: '',
                Outlets: [],
                OpenKOTs: 0,
                OpenFOBills: 0,
                PropertyName: $scope.PropertyName,
                ShiftStatusDescription: '',
                PropertyID: $scope.PropertyID,
                ModifiedBy: $scope.UserName,
                DateFormat: $scope.DateFormat
            };

        $scope.FOShiftOutletViewModel =
            {
                Id: '',
                FOShiftId: '',
                OutletId: '',
                FOUserId: '',
                StatusTypeId: '',
                StatusTypeName: '',
                OutletStatusDescription: '',
                PropertyID: $scope.PropertyID,
                ModifiedBy: $scope.UserName,
                DateFormat: $scope.DateFormat
            };

        $scope.ShiftTimeRun1 = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)

        getShiftDetails();
        function getShiftDetails() {
            $scope.IsLoading = true;
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.UserName = $scope.UserName;
            var promiseGet = service.getShiftDetail($scope.Model);
            promiseGet.then(function (data) {

                if (data.Data != null) {
                    $scope.Model = data.Data;
                    if ($scope.Model.Id) {
                        $scope.Model.ShiftDate = $filter("date")($scope.Model.ShiftDate, $scope.DateFormat);
                    }
                    else {
                        $scope.Model.ShiftDate = $filter("date")($scope.businessDate, $scope.DateFormat);
                    }
                    localStorageService.set('FOShiftId', $scope.Model.Id);
                    localStorageService.set('FOShiftNo', $scope.Model.ShiftNumber);
                    localStorageService.set('FOShiftDate', $scope.Model.ShiftDate);

                    //$cookies.put('FOShiftNo', $scope.Model.ShiftNumber);
                    //$cookies.put('FOShiftDate', $scope.Model.ShiftDate);

                    //
                    //$scope.FOShiftNo = $cookies.get('FOShiftNo');
                    //$scope.FOShiftDate = $cookies.get('FOShiftDate');

                    $scope.GetAllFOCashByFOShiftId();
                }

                $scope.IsLoading = false;
                $('body').removeClass("disablewholepage");
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    if (error.Message == 'Invalid User.') {
                        $timeout(function () { window.location.href = "../../Login.html";; }, 3000);
                    }
                    scrollPageOnTop();
                });
        };

        $scope.IsFOShiftShowTransaction = false;
        $scope.isFOShiftShowTransaction = function () {
            service.getByModuleSettingName($scope.PropertyID, 'IsFOShiftShowTransaction', true)
                .then(function (s) {
                    $scope.IsFOShiftShowTransaction = s.Status && s.Data && s.Data.IsActive;
                }, function (e) {
                    if (showMsg) msg(e.Message);
                });
        };
        $scope.isFOShiftShowTransaction();

        $scope.IsFOShiftCashOUTValidation = false;
        $scope.isFOShiftCashOUTValidation = function () {

            service.getByModuleSettingName($scope.PropertyID, 'IsFOShiftCashOUTValidation', true)
                .then(function (s) {
                    $scope.IsFOShiftCashOUTValidation = s.Status && s.Data && s.Data.IsActive;
                }, function (e) {
                    if (showMsg) msg(e.Message);
                });
        };
        $scope.isFOShiftCashOUTValidation();

        $scope.OpenShiftRequest = function () {

            if ($scope.Model.OpenFOBills > 0) {
                parent.posFailureMessage("Please settle open bills.");
                return;
            }

            if ($scope.Model.TotalClosingCSH > 0 && $scope.IsFOShiftCashOUTValidation) {
                var msg = "Please complete Cash OUT process."
                parent.posFailureMessage(msg);
                scrollPageOnTop();
                return;
            }
            $scope.IsLoading = true;
            var promiseGet = service.isShiftBalance($scope.Model.Id);
            promiseGet.then(function (data) {
                $scope.IsLoading = false;
                if (data.Status) {
                    var msg = "Please complete Cash OUT process."
                    parent.posFailureMessage(msg);
                    scrollPageOnTop();
                    return;
                }

                $scope.shiftAlert;
                if ($scope.Model.IsActive == true) {
                    $scope.shiftAlert = "Are you sure? You want to CLOSE shift.";
                }
                else {
                    $scope.shiftAlert = "Are you sure? You want to OPEN shift.";

                    //FOShiftReport
                    //$scope.FOShiftReport();
                }

                $("#addMsgAlert").modal('show');

            },
                function (error) {
                    $scope.IsLoading = false;
                    $scope.Model.Code = "";
                    parent.failureMessage("Code is already exist");

                    scrollPageOnTop();
                    $scope.focusElement = "Code";
                });
        };

        $scope.YesIWant = function () {

            $scope.Model.UserName = $scope.UserName;
            $scope.Model.ShiftDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
            $scope.Model.ShiftTimeToDisplay = $filter("date")(new Date, 'hh:mm:ss a');
            $scope.Model.ShiftCloseTimeToDisplay = $filter("date")(new Date, 'hh:mm:ss a');

            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            $scope.Model.DateFormat = $scope.DateFormat;

            var promiseGet = service.openShiftRequest($scope.Model);
            promiseGet.then(function (data) {

                $cookies.remove('FOShiftId');
                $cookies.remove('FOShiftNo');
                $cookies.remove('FOShiftDate');

                getShiftDetails();



                parent.posSuccessMessage(data.Message);
                scrollPageOnTop();
                $scope.NoIWant();
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                    $scope.NoIWant();
                });
        };

        $scope.NoIWant = function () {

            $("#addMsgAlert").modal('hide');
            $("#outletAlert").modal('hide');

            $scope.Outlet = {};
            $scope.ShiftId = "";
            $scope.ShiftNumber = "";
            $scope.ShiftStatusDescription = "";
        };

        $scope.LogoutShift = function () {
            //$sessionStorage.$reset();
            window.location.href = Path + "login.html";
        };

        $scope.GoToFODashboard = function () {
            //Store the token information in the SessionStorage
            //So that it can be accessed for other views

            sessionStorage.setItem('FOShiftId', $scope.Model.Id);
            localStorageService.set('FOShiftId', $scope.Model.Id);
            window.location.href = Path + "/FO/Dashboard";
        };

        $scope.ShiftReport = function () {


            var reportId = "3291";
            var foShiftId = $scope.Model.Id;

            if (!foShiftId) {
                var promiseGet = service.getLastShift({PropertyID:$scope.PropertyID, UserName:$scope.ModifiedBy });
                promiseGet.then(function (data) {

                    $scope.LastFOShift = data.Data;
                    var url = Path + "reporter/reportviewer?id=" + reportId + "&pid=" + $scope.LastFOShift.Id;
                    window.open(url, '_blank', 'location=yes,height=600,width=800,scrollbars=yes,status=yes');

                },
                    function (error) {
                        parent.posFailureMessage(error.Data.Message);
                        scrollPageOnTop();
                    });
            }
            else {
                var url = Path + "reporter/reportviewer?id=" + reportId + "&pid=" + foShiftId;
                window.open(url, '_blank', 'location=yes,height=600,width=800,scrollbars=yes,status=yes');
            }



        };

        //FO CASH
        $scope.FOCash = {};
        $scope.Reset = function () {
            $scope.FOCash = {
                Id: '',
                FOCashTypeId: 1,
                FOCashTypeName: 'Cash IN',
                CashDate: $filter("date")(date, $scope.DateFormat),
                CashTime: 0,
                CashTimeToDisplay: $filter("date")(new Date, "HH:mm:ss"),
                FOShiftId: $scope.Model.Id,
                FOShiftNumber: $scope.Model.Id,

                OpeningBalance: 0,
                Amount: 0,
                ClosingBalance: 0,
                Remaks: '',
            };

            $scope.GetAllFOCashByFOShiftId();

            angular.forEach($scope.Denominations, function (item) {

                item.NOs = 0;
                item.Amount = 0;

            })

            $scope.CalculateTotal();
        }

        $scope.SetFOCash = function (posCashTypeName) {

            $scope.Reset();
            if (posCashTypeName == 'IN') {
                $scope.FOCash.FOCashTypeId = 1;
                $scope.FOCash.FOCashTypeName = "Cash IN";
            }
            else {
                $scope.FOCash.FOCashTypeId = 2;
                $scope.FOCash.FOCashTypeName = "Cash OUT";
            }
            $scope.IsLoading = true;
            $scope.FOCash.FOShiftId = $scope.Model.Id;
            //$scope.GetAllFOCashByFOShiftId();

            var promiseGet = service.GetClosingByFOShiftId($scope.FOCash.FOShiftId);
            promiseGet.then(function (data) {

                $scope.FOCash.OpeningBalance = data.Data.OpeningBalance;
                $scope.FOCash.TransactionAmount = data.Data.TransactionAmount;
                $scope.FOCash.OpeningTransaction = data.Data.OpeningTransaction;
                $scope.FOCash.NewTransaction = data.Data.NewTransaction;
                $scope.FOCash.Amount = data.Data.Amount;
                //$scope.FOCash.ClosingBalance = data.Data.ClosingBalance;

                $scope.FOCashChange();
                $scope.IsLoading = false;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                    $scope.IsLoading = false;
                });

        };

        $scope.FOCashChange = function () {


            if ($scope.FOCash.Amount == undefined) {
                $scope.FOCash.Amount = 0;
            }

            if ($scope.FOCash.Amount.length == 0) {
                $scope.FOCash.Amount = 0;
            }
            $scope.FOCash.Amount = parseFloat($scope.FOCash.Amount);

            //$scope.FOCash.ClosingBalance = parseFloat($scope.FOCash.OpeningBalance)  - parseFloat($scope.FOCash.OpeningTransaction);

            //if ($scope.FOCash.FOCashTypeId == 1)
            //{
            //    $scope.FOCash.ClosingBalance = parseFloat($scope.FOCash.ClosingBalance) + parseFloat($scope.FOCash.Amount);
            //}
            //else
            //{
            //    $scope.FOCash.ClosingBalance = parseFloat($scope.FOCash.ClosingBalance) - parseFloat($scope.FOCash.Amount);
            //}

        }

        $scope.SaveFOCash = function (type, form) {

            if ($scope.FOCash.Amount.length == 0) {
                parent.posFailureMessage("Amount should be greater then zero(0).");
                return;
            }

            if ($scope.FOCash.Amount == 0 && $scope.FOCash.TotalCRC == 0 && $scope.FOCash.TotalCHQ == 0 && $scope.FOCash.TotalECP == 0) {
                parent.posFailureMessage("Amount should be greater then zero(0).");
                return;
            }

            //if ($scope.FOCash.ClosingBalance < 0) {
            //    parent.posFailureMessage("Closing cann't be negative.");
            //    return;
            //}

            if ($scope.FOCash.FOCashTypeId == 2 && $scope.IsFOShiftCashOUTValidation) {

                if ($scope.Model.TotalClosingCSH < $scope.FOCash.Amount) {
                    parent.posFailureMessage("Out value should not be greater then closing value.");
                    return;
                }
                if ($scope.Model.TotalClosingCRC < $scope.FOCash.TotalCRC) {
                    parent.posFailureMessage("Out value should not be greater then closing value.");
                    return;
                }
                if ($scope.Model.TotalClosingCHQ < $scope.FOCash.TotalCHQ) {
                    parent.posFailureMessage("Out value should not be greater then closing value.");
                    return;
                }
                if ($scope.Model.TotalClosingECP < $scope.FOCash.TotalECP) {
                    parent.posFailureMessage("Out value should not be greater then closing value.");
                    return;
                }
            }


            if ($scope[form].$valid) {

                $scope.FOCash.CashDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;
                //$scope.FOCash.CashTimeToDisplay = $scope.Model.CashTimeToDisplay;
                $scope.FOCash.FOShiftId = $scope.Model.Id;
                $scope.FOCash.PropertyID = $scope.PropertyID;
                $scope.FOCash.ModifiedBy = $scope.UserName;

                $scope.FOCash.FOCashDenominations = [];

                angular.forEach($scope.Denominations, function (item) {
                    if (item.NOs > 0) {
                        $scope.FOCash.FOCashDenominations.push({
                            DenominationMasterId: item.Id,
                            DenominationName: item.Name,
                            NOs: item.NOs,
                            Amount: item.Amount,
                            Remaks: item.Remaks,
                        });
                    }
                })
                $scope.IsLoading = true;
                var promiseGet = service.saveFOCash($scope.FOCash);
                promiseGet.then(function (data) {
                    getShiftDetails();
                    $scope.Reset();
                    parent.posSuccessMessage(data.Message);
                    $("#foCashBox").modal('hide');
                    scrollPageOnTop();
                },
                    function (error) {
                        $scope.IsLoading = false;
                        parent.posFailureMessage(error.Message);
                        scrollPageOnTop();
                    });
            } else {
                $scope.AddCashMessage = true;
            }
        };

        $scope.GetAllFOCashByFOShiftId = function () {
            $scope.IsLoading = true;
            var promiseGet = service.getAllFOCashByFOShiftId($scope.Model.Id);
            promiseGet.then(function (data) {

                $scope.AllFOCash = data.Collection;
                $scope.IsLoading = false;
            },
                function (error) {
                    parent.posFailureMessage(error.Data.Message);
                    scrollPageOnTop();
                });
        };

        //END FO CASH


        //OLD CODE
        $scope.AddCash = {};

        $scope.CashOut = {};

        $scope.GetFOCashIN = function (posshiftId) {

            $("#addcashbox").show();
            $scope.IsLoading = true;
            var promiseGet = service.addCashRequest(shiftId, shiftNumber, $scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.AddCash = data.Data;
                if ($scope.AddCash.AddCashDate == null || $scope.AddCash.AddCashDate == '' || $scope.AddCash.AddCashDate == undefined) {
                    $scope.AddCash.AddCashDate = $filter("date")(new Date(), $scope.DateFormat);
                    $scope.AddCash.AddCashTime = $filter('date')(new Date(), 'hh:mm:ss a');
                } else {
                    $scope.AddCash.AddCashDate = $filter("date")($scope.AddCash.AddCashDate, $scope.DateFormat);
                    $scope.AddCash.AddCashTime = $filter('date')($scope.AddCash.AddCashTime, 'hh:mm:ss a');
                }
                $("#addcashbox").show();
                $scope.IsLoading = false;
            },
                function (error) {
                    parent.posFailureMessage(error.Data.Message);
                    scrollPageOnTop();
                });
        };

        $scope.CashOutRequest = function (shiftId, shiftNumber) {

            $("#cashoutbox").show();

            var promiseGet = service.cashOutRequest(shiftId, shiftNumber, $scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.CashOut = data.Data;


                if ($scope.CashOut.CashOutDate == null || $scope.CashOut.CashOutDate == '' || $scope.CashOut.CashOutDate == undefined) {
                    $scope.CashOut.CashOutDate = $filter("date")(new Date(), $scope.DateFormat);
                    $scope.CashOut.CashOutTime = $filter('date')(new Date(), 'hh:mm:ss a');
                } else {
                    $scope.CashOut.CashOutDate = $filter("date")($scope.CashOut.CashOutDate, $scope.DateFormat);
                    $scope.CashOut.CashOutTime = $filter('date')($scope.CashOut.CashOutTime, 'hh:mm:ss a');
                }

                $("#cashoutbox").show();
            },
                function (error) {
                    parent.posFailureMessage(error.Data.Message);
                    scrollPageOnTop();
                });
        };

        $scope.AddCashMessage = false;

        $scope.SaveAddCashRequest = function (addCash, form) {
            if ($scope[form].$valid) {
                addCash.PropertyID = $scope.PropertyID;
                addCash.ShiftId = $scope.Model.ShiftId;
                $scope.IsLoading = true;
                var promiseGet = service.saveAddCashRequest(addCash);
                promiseGet.then(function (data) {
                    $scope.AddCash = {};
                    $("#addcashbox").hide();
                    parent.posSuccessMessage(data.Message);
                    $scope.IsLoading = false;
                },
                    function (error) {
                        parent.posFailureMessage(error.Data.Message);
                        scrollPageOnTop();
                    });
            } else {
                $scope.AddCashMessage = true;
            }
        };

        $scope.CashOutMessage = false;

        $scope.SaveCashOutRequest = function (cashOut, form) {
            if ($scope[form].$valid) {
                cashOut.PropertyID = $scope.PropertyID;
                cashOut.ShiftId = $scope.Model.ShiftId;
                var promiseGet = service.saveCashOutRequest(cashOut);
                promiseGet.then(function (data) {
                    $scope.CashOut = {};
                    $("#cashoutbox").hide();
                    parent.posSuccessMessage(data.Message);
                },
                    function (error) {
                        parent.posFailureMessage(error.Data.Message);
                        scrollPageOnTop();
                    });
            } else {
                $scope.CashOutMessage = true;
            }
        };

        $scope.AddCashChange = function (addCash) {
            if (addCash != undefined && addCash != "") {
                $scope.AddCash.AddClossingBalance = parseFloat(addCash);
            }
        };

        $scope.CashOutChange = function (addCash) {
            if (addCash != undefined && addCash != "") {
                $scope.CashOut.CashClossingBalance = parseFloat($scope.CashOut.TotalTransaction) + (parseFloat(addCash));
            }
        };

        $scope.IsShiftBalance = function () {
            var promiseGet = service.isShiftBalance($scope.Model.Id);
            promiseGet.then(function (data) {
            },
                function (error) {

                    $scope.Model.Code = "";
                    parent.failureMessage("Code is already exist");

                    scrollPageOnTop();
                    $scope.focusElement = "Code";
                });
        };

        $scope.Denominations = [];
        $scope.getAllDenominationMaster = function () {

            var promiseGet = service.getAllDenominationMaster($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Denominations = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.Data.Message);
                    scrollPageOnTop();
                });
        };
        $scope.getAllDenominationMaster();

        $scope.GetAmount = function (selectedItem, currencyTypeId) {

            angular.forEach($scope.Denominations, function (item, i) {
                if (!item.Amount) {
                    item.Amount = 0;
                }
                if (!item.NOs) {
                    item.NOs = 0;
                }
                if (selectedItem.Id == item.Id) {
                    item.Amount = parseFloat(item.NOs) * parseFloat(item.Name)
                    item.Amount = $filter('number')(parseFloat(item.Amount), 2);
                }
            });

            $scope.CalculateTotal();
        }

        $scope.CalculateTotal = function () {

            $scope.FOCash.Amount = 0;
            var totalAmount = 0.00;

            if (!$scope.FOCash.TotalCRC) {
                $scope.FOCash.TotalCRC = 0.00;
            }

            if (!$scope.FOCash.TotalCHQ) {
                $scope.FOCash.TotalCHQ = 0.00;
            }

            if (!$scope.FOCash.TotalECP) {
                $scope.FOCash.TotalECP = 0.00;
            }

            angular.forEach($scope.Denominations, function (item) {
                var amount = item.Amount.toString();
                amount = replaceAll(amount, ',', '');
                totalAmount += parseFloat(amount);
            });

            $scope.FOCash.Amount = $filter('number')(parseFloat(totalAmount), 2).replace(/,/g, '');


            if ($scope.FOCash.FOCashTypeId == 1) {

                var closingBalance = parseFloat($scope.FOCash.OpeningBalance)
                    + parseFloat($scope.FOCash.Amount)
                    + parseFloat($scope.FOCash.TotalCRC)
                    + parseFloat($scope.FOCash.TotalCHQ)
                    + parseFloat($scope.FOCash.TotalECP);

            }
            else {
                var closingBalance = parseFloat($scope.FOCash.OpeningBalance)
                    - (parseFloat($scope.FOCash.Amount)
                    + parseFloat($scope.FOCash.TotalCRC)
                    + parseFloat($scope.FOCash.TotalCHQ)
                    + parseFloat($scope.FOCash.TotalECP));

            }

            // $scope.FOCash.ClosingBalance = $filter('number')(parseFloat(closingBalance), 2).replace(/,/g, '');
        };

        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        }

        $scope.greaterThan = function (prop, val) {
            return function (item) {
                return item[prop] > val;
            }
        }

        $scope.PrintCashINVoucher = function (id) {
            service.MapReport($scope.PropertyID, 'CashINVoucherReport')
                .then(function (s) {
                    var pwin = $window.open(Path + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + id, '_blank');
                    pwin.myvar = 'hi';
                    var timer = setInterval(function () {
                        if (pwin.closed) {
                            clearInterval(timer);
                            $scope.html4pdf = pwin.myvar.documentElement;
                            $scope.export($scope.html4pdf);
                        }
                    }, 1000);

                }, function (e) {
                    msg('Error in mapping to print.');
                });
        }
        $scope.PrintCashOUTVoucher = function (id) {
            service.MapReport($scope.PropertyID, 'CashOUTVoucherReport')
                .then(function (s) {
                    var pwin = $window.open(Path + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + id, '_blank');
                    pwin.myvar = 'hi';
                    var timer = setInterval(function () {
                        if (pwin.closed) {
                            clearInterval(timer);
                            $scope.html4pdf = pwin.myvar.documentElement;
                            $scope.export($scope.html4pdf);
                        }
                    }, 1000);

                }, function (e) {
                    msg('Error in mapping to print.');
                });

        }
        $scope.PrintFOShiftReport = function () {
            service.MapReport($scope.PropertyID, 'FOShiftReport')
                .then(function (s) {
                    var pwin = $window.open(Path + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + $scope.Model.Id, '_blank');
                    pwin.myvar = 'hi';
                    var timer = setInterval(function () {
                        if (pwin.closed) {
                            clearInterval(timer);
                            $scope.html4pdf = pwin.myvar.documentElement;
                            $scope.export($scope.html4pdf);
                        }
                    }, 1000);

                }, function (e) {
                    msg('Error in mapping to print.');
                });

        }
    }
]);