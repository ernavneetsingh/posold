﻿
app.service('FOMapService', [
    '$http', '$q', function ($http, $q) {
        
        this.getFOMap = function (GroupId, PropertyID) {
            return httpCaller(apiPath + "Tally/FOMap/GetGroup/" + GroupId + "/" + PropertyID, $http, $q);
        };
        this.getAccountDump = function (propertyId) {
            return httpCaller(apiPath + "Tally/AccountDump/GetAll?propertyId=" + propertyId, $http, $q);
        };
        this.save = function (model) {
            return httpPoster(apiPath + "Tally/FOMap/Save", $http, $q, model);
        };
    }
]);
