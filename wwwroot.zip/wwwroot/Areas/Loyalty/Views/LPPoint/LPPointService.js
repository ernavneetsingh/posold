﻿
app.service('LPPointService', [
    '$http', '$q', function (
        $http, $q) {

        this.getAllLPCard = function (propertyId) {
            return httpCaller(apiPath + "Loyalty/LPCard/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getAllDiscountType = function () {
            return httpCaller(apiPath + "ReferenceConstant/DiscountType/All", $http, $q);
        };
        this.getAllMenuGroupType = function () {
            return httpCaller(apiPath + "ReferenceConstant/MenuGroupType/All", $http, $q);
        };
        this.getAllRevenueHeads = function (propertyId, revenueTypeId) {
            return httpCaller(apiPath + "GlobalSetting/RevenueHead/GetAllByRevenueTypeId/" + propertyId + "/" + revenueTypeId, $http, $q);
        };
        this.getAllWeekDays = function () {
            return httpCaller(apiPath + "ReferenceConstant/WeekDays/All", $http, $q);
        };
        this.getAll = function (options) {
            return httpCaller(apiPath + "Loyalty/LPPoint/GetAll", $http, $q, options);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "Loyalty/LPPoint/Save", $http, $q, model);
        };

    }
]);
