﻿
app.controller("controller", ["$scope", "service", "localStorageService",
    function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = true;

    var sortKeyOrder = {
        key: "",
        order: "",
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    
    
    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 50;
    $scope.recordsPerPage = 50;
    $scope.numberOfPageButtons = 10;

    getData($scope, service, localStorageService);

    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get("sortKeyOrder");
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == "ASC")
                sortKeyOrder.order = "DESC";
            else
                sortKeyOrder.order = "ASC";
            localStorageService.set("sortKeyOrder", sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: "ASC"
            };
            localStorageService.set("sortKeyOrder", sortKeyOrder);
        }
    };
    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };
    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    };
    $scope.Edit = function (item) {
        
        $scope.Model = item;
        scrollPageOnTop();
    };
    $scope.Reset = function () {

        $scope.file = '';
        $scope.Model.IconUrl = '';
        $scope.Model.UploadFile = '';

        $scope.Model = {};
        $scope.Model.IsActive = true;
        //clearForm();
        $scope.searchfor = null;
        $scope.search();
        scrollPageOnTop();
    };

    $scope.ShowErrorMessage = false;

   //-----------------------------
    $scope.APIPath = apiPath;
    $scope.file = "";
    $scope.IsUploading = false;
   //-----------------------------

    $scope.SaveNew = function (model, form) {
       

        if ($scope[form].$valid) {

            //-----------------------------
            var ImageModel = {
                Base64: $scope.file.base64,
                FileName: $scope.file.filename,
                FileSize: $scope.file.filesize,
                FileType: $scope.file.filetype,
                PropertyID: "SPA",
                EntityName: "Module"
            };
            $scope.IsUploading = true;
            model.ImageModel = ImageModel;
            //-----------------------------

            var promiseGet = service.save(model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);

                $scope.IsUploading = false;
                $scope.Reset();
                //clearForm();
                parent.successMessage(data.Message);
                scrollPageOnTop();
            },
                function (error, status) {
                    $scope.IsUploading = false;
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });


        } else {
            $scope.ShowErrorMessage = true;
        }
    };

    $scope.Save = function (model, form) {
        

        if ($scope[form].$valid) {
            if (model.Id == undefined || model.Id == "" || model.Id == null) {
                
                var msg = chechFileValid($scope.SelectedFile);
                if (msg == "success") {
                    var promisePost = service.uploadFile($scope.SelectedFile);
                    promisePost.then(function (d) {
                        model.IconUrl = d.Data;



                        var promiseGet = service.save(model);
                        promiseGet.then(function (data, status) {
                            getData($scope, service, localStorageService);
                            $scope.Reset();
                            //clearForm();
                            parent.successMessage(data.Message);
                            scrollPageOnTop();
                        },
                            function (error, status) {
                                scrollPageOnTop();
                                parent.failureMessage(error.Message);
                            });


                    },
                        function (e) {
                            scrollPageOnTop();
                            parent.failureMessage(e.Message);
                        });
                } else {
                    scrollPageOnTop();
                    parent.failureMessage(msg);
                }
            } else {
                
                if ($scope.SelectedFile != undefined && $scope.SelectedFile != "." &&
                    $scope.SelectedFile != "" &&
                    $scope.SelectedFile != null) {

                    var msg1 = chechFileValid($scope.SelectedFile);
                    if (msg1 == "success") {
                        var promisePost1 = service.uploadFile($scope.SelectedFile);
                        promisePost1.then(function (d) {
                            model.IconUrl = d.Data;
                            var promiseGet2 = service.save(model);
                            promiseGet2.then(function (data, status) {
                                getData($scope, service, localStorageService);
                                $scope.Reset();
                                //clearForm();
                                scrollPageOnTop();
                                parent.successMessage(data.Message);
                            },
                                function (error, status) {
                                    scrollPageOnTop();
                                    parent.failureMessage(error.Message);
                                });
                        },
                            function (e) {
                                scrollPageOnTop();
                                parent.failureMessage(e.Message);
                            });
                    } else {
                        scrollPageOnTop();
                        parent.failureMessage(msg1);
                    }
                } else {
                    
                    var promiseGet3 = service.save(model);
                    promiseGet3.then(function (data, status) {
                        getData($scope, service, localStorageService);
                        $scope.Reset();
                        //clearForm();
                        scrollPageOnTop();
                        parent.successMessage(data.Message);
                    },
                        function (error, status) {
                            scrollPageOnTop();
                            parent.failureMessage(error.Message);
                        });
                }

            }

        } else {
            $scope.ShowErrorMessage = true;
        }
    };

    //$scope.selectFileforUpload = function (file) {
    //    var files = file[0];
    //    $scope.Imagename = files.name;
    //    $scope.Model.IconUrl = $scope.Imagename;
    //    $scope.SelectedFile = file[0];
    //};

    function chechFileValid(file) {
        
        if ($scope.SelectedFile != null) {
            if ((file.type == "image/png" || file.type == "image/gif") && file.size <= (50 * 50)) {
                return "success";
            }
            else if (file.size >= (40 * 41)) {
                return "File size less (40 * 40)";
            } else {
                return "Only PNG/Gif Image can be upload";
            }
        } else {
            return "Module Icon required!";
        }
    };

    //function clearForm() {
        
    //    $scope.Imagename = "";
    //    $scope.Description = "";

    //    angular.forEach(angular.element("input[type='file']"),
    //        function (inputElem) {
    //            angular.element(inputElem).val(null);
    //        });

    //};

    $scope.IsNameExist = function (model) {
        var promiseGet = service.isNameExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.Name = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };
    $scope.IsOrderSNoExist = function (model) {
        
        var promiseGet = service.isOrderSNoExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.OrderSNo = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };

    $scope.ChangeStatus = function (model) {

        var promiseGet = service.changeStatus(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.ClearImage = function () {
        
        $scope.file = '';
        $scope.Model.IconUrl     ='';
        $scope.Model.UploadFile = '';
        scrollPageOnTop();
    };
    $scope.GetFileSize = function () {
        var size = parseFloat($scope.file.filesize) / 1024; //in kb
        size = $filter("number")(size, 2).replace(/,/g, "");
        $scope.fileSize = size.toString() + "KB";
    };
    //-----------------------------------
}
]);

var getData = function ($scope, dataService, localStorageService) {
    
    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "OrderSNo",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getAll(options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};