﻿
app.controller("controller", ["$scope", "service", "localStorageService",
    function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = true;

    var sortKeyOrder = {
        key: "",
        order: "",
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 50;
    $scope.recordsPerPage = 50;
    $scope.numberOfPageButtons = 10;

    //getData($scope, service, localStorageService);

    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get("sortKeyOrder");
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == "ASC")
                sortKeyOrder.order = "DESC";
            else
                sortKeyOrder.order = "ASC";
            localStorageService.set("sortKeyOrder", sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: "ASC"
            };
            localStorageService.set("sortKeyOrder", sortKeyOrder);
        }
    };
    $scope.pageChanged = function () {
        //getData($scope, service, localStorageService);
    };
    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        //getData($scope, service, localStorageService);
    };
    


        //SignalR
    
    $scope.IsHubConnected = false;
    var connection = $.hubConnection(apiPath);
    var eventName = "onMessageListened";
    connection.start().done(function () {
        $scope.IsHubConnected = true;
        //$("#status").text("").prepend("<i>" + eventName + "</i> event is being listened !").prepend("Connected. ").css("color", "green");
    });
    var messageBroadCast = connection.createHubProxy('BroadCastHub');
    messageBroadCast.on(eventName, function (message) {
        //$('#message').append('<li>' + message + '</li>');
    });

    $("#show-all-connections").on("click", function () {

        

        messageBroadCast.getAllActiveConnections().done(function (connections) {
            $.map(connections, function (item) {
                $("#user-list").append("<li>Connection ID : " + item + "</li>");
            });
        });
    });

}
]);
