﻿
app.controller("DriverShiftController", [
    "$scope", "DriverShiftService", "$cookies", "localStorageService", "$filter", "$timeout",
    function ($scope, driverShiftService, $cookies, localStorageService, $filter, $timeout) {

        $scope.ShiftChart = {};
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        $scope.ShiftChart.ShiftDate = $scope.ModifiedDate;// $filter("date")(new Date(), "yyyy-MM-dd");//  "yyyy-MM-dd");
        $scope.Reset = function () {
            $scope.ShiftChart = {};
        };

        getAllDriver();

        $scope.ShowErrorMessage = false;
        $scope.SaveShiftChart = function () {
            if ($scope.ParentShiftChart.length > 0) {
                var promiseGet = driverShiftService.saveShiftChart($scope.ParentShiftChart);
                promiseGet.then(function (data) {
                    $scope.Reset();
                    msg(data.Message, true);
                    //scrollPageOnTop();
                },
                    function (error) {

                        msg(error.responseJSON.Message);
                        //scrollPageOnTop();
                    });
            } else {
                msg("Please Select Shift Datetime in Shift Chart.");
            }
        };

        $scope.MonthlyDays = [];
        $scope.MonthlyTimes = [];
        $scope.CurrentDateTime = [];

        $scope.Drivers = [];

        function getAllDriver() {

            getAllBusinessShift();

            $timeout(function () {
                $scope.Drivers1 = [];
                var businessDate = $filter("date")($scope.ShiftChart.ShiftDate, "yyyy-MM-dd");
                var promiseGet = driverShiftService.getDriverShift($scope.PropertyID, businessDate);
                promiseGet.then(function (data) {

                    $scope.Drivers1 = data.Collection;
                    for (var i = 0; i < $scope.Drivers1.length; i++) {
                        $scope.Drivers1[i].DriverShiftDetails = $scope.CurrentDateTime.Time;
                    }
                    setOccupiadDateTimes();
                }, function (error) {
                    parent.failureMessage(error.Data.Message);
                    scrollPageOnTop();
                });
            }, 10);
        };

        function setOccupiadDateTimes() {
            $scope.Drivers = [];
            angular.forEach($scope.Drivers1, function (driver1) {
                $scope.DemoDriver = angular.copy(driver1);

                angular.forEach($scope.DemoDriver.Occupied, function (occupied) {

                    var start = $filter("date")(occupied.ShiftTimeStart, "yyyy-MM-dd");// $scope.DateFormat);
                    var d = $filter("date")($scope.ShiftChart.ShiftDate, "yyyy-MM-dd");//  $scope.DateFormat);

                    if (start == d) {

                        var startTime = occupied.StartShiftDate.slice(-2);
                        var endTime = occupied.EndShiftDate.slice(-2);

                        var userId = occupied.UserId;
                        if (parseInt(endTime) > parseInt(startTime)) {
                            for (var ii = startTime; ii <= endTime; ii++) {
                                if (userId == $scope.DemoDriver.Id) {
                                    angular.forEach($scope.DemoDriver.DriverShiftDetails, function (selectedTime, index) {
                                        if (ii == parseInt(selectedTime.Time)) {
                                            $scope.DemoDriver.DriverShiftDetails[index].Selected = angular.copy(true);
                                        }
                                    });
                                }
                            }
                        } else {
                            for (var ii = startTime; ii <= 24; ii++) {
                                if (ii == 24) {
                                    for (var j = 0; j < endTime; j++) {
                                        if (userId == $scope.DemoDriver.Id) {
                                            angular.forEach($scope.DemoDriver.DriverShiftDetails, function (selectedTime, index) {
                                                if (j == parseInt(selectedTime.Time)) {
                                                    $scope.DemoDriver.DriverShiftDetails[index].Selected = angular.copy(true);
                                                }
                                            });
                                        }
                                    }
                                } else {
                                    if (userId == $scope.DemoDriver.Id) {
                                        angular.forEach($scope.DemoDriver.DriverShiftDetails, function (selectedTime, index) {
                                            if (ii == parseInt(selectedTime.Time)) {
                                                $scope.DemoDriver.DriverShiftDetails[index].Selected = angular.copy(true);
                                            }
                                        });

                                    }
                                }
                            }
                        }
                    }

                });

                driver1 = angular.copy($scope.DemoDriver);
                $scope.Drivers.push(driver1);
            });
        }

        function setOccupiadDateTimesWeeklyAndMonthly(dateTime) {

            $scope.Drivers = [];
            angular.forEach($scope.Drivers1, function (driver) {
                $scope.DemoDriver = angular.copy(driver);
                angular.forEach($scope.DemoDriver.Occupied, function (occupied) {

                    var start = $filter("date")(occupied.ShiftTimeStart, $scope.DateFormat);
                    var d = $filter("date")(dateTime, $scope.DateFormat);
                    if (start == d) {

                        var startTime = occupied.StartShiftDate.slice(-2);
                        var endTime = occupied.EndShiftDate.slice(-2);

                        var userId = occupied.UserId;
                        if (parseInt(endTime) > parseInt(startTime)) {
                            for (var ii = startTime; ii <= endTime; ii++) {
                                if (userId == $scope.DemoDriver.Id) {
                                    angular.forEach($scope.DemoDriver.DriverShiftDetails, function (selectedTime, index) {
                                        if (ii == parseInt(selectedTime.Time)) {
                                            $scope.DemoDriver.DriverShiftDetails[index].Selected = angular.copy(true);
                                        }
                                    });
                                }
                            }
                        } else {
                            for (var ii = startTime; ii <= 24; ii++) {
                                if (ii == 24) {
                                    for (var j = 0; j < endTime; j++) {
                                        if (userId == $scope.DemoDriver.Id) {
                                            angular.forEach($scope.DemoDriver.DriverShiftDetails, function (selectedTime, index) {
                                                if (j == parseInt(selectedTime.Time)) {
                                                    $scope.DemoDriver.DriverShiftDetails[index].Selected = angular.copy(true);
                                                }
                                            });

                                        }
                                    }
                                } else {
                                    if (userId == $scope.DemoDriver.Id) {
                                        angular.forEach($scope.DemoDriver.DriverShiftDetails, function (selectedTime, index) {
                                            if (ii == parseInt(selectedTime.Time)) {
                                                $scope.DemoDriver.DriverShiftDetails[index].Selected = angular.copy(true);
                                            }
                                        });

                                    }
                                }
                            }
                        }
                    }

                });

                driver = angular.copy($scope.DemoDriver);
                $scope.Drivers.push(driver);
            });
        }

        $scope.GetBussinessDateTimes = function (date) {

            $scope.ShiftChart.ShiftDate = $filter("date")(new Date(date), "yyyy-MM-dd");
            getAllDriver();
        };

        function getAllBusinessShift() {

            if ($scope.ShiftChart.ShiftDate != undefined && $scope.ShiftChart.ShiftDate != null && $scope.ShiftChart.ShiftDate != '') {
                var businessDate = $filter("date")($scope.ShiftChart.ShiftDate, "yyyy-MM-dd");
                var promiseGet = driverShiftService.getBusinessShift(businessDate);
                promiseGet.then(function (data) {

                    console.dir(data);
                    $scope.CurrentDateTime = data.Data.CurrentDateTime;
                    $scope.ShiftDateWeekly = data.Data.ShiftDateWeekly;
                    $scope.ShiftDateMonthly = data.Data.ShiftDateMonthly;

                    $("#currentdatelink").addClass("active");
                    $("#currentDateTime").addClass("selected");
                },
                    function (error) {
                        parent.failureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            } else {
                parent.failureMessage("Please Select Bussiness Date");
                scrollPageOnTop();
            }
        };

        $scope.getMonthDays = function (month, $event) {
            $scope.MonthlyDays = month.MonthlyDate;
            $(".monthwise1 li.selectedDaysTime").removeClass("selectedDaysTime");
            $($event.currentTarget).addClass("selectedDaysTime");
            $scope.ShiftDateMonthlyTime = [];
            for (var i = 0; i < $scope.Drivers.length; i++) {
                $scope.Drivers[i].DriverShiftDetails = [];
            }
        };

        $scope.GetMonthDaysTime = function (month, $event) {
            var date = $filter("date")(month.DateTime, "yyyy-MM-dd");
            var promiseGet = driverShiftService.getMonthDaysTime(date);
            promiseGet.then(function (data) {
                for (var i = 0; i < $scope.Drivers1.length; i++) {
                    $scope.Drivers1[i].DriverShiftDetails = data.Collection;
                }
                $scope.ShiftDateMonthlyTime = data.Collection;
                $(".calendar1 li.selectedDaysTime").removeClass("selectedDaysTime");
                $($event.currentTarget).addClass("selectedDaysTime");

                setOccupiadDateTimesWeeklyAndMonthly(month.DateTime);
            },
                function (error) {
                    parent.failureMessage(error.data.Message);
                    scrollPageOnTop();
                });
        };

        $scope.getWeekly = function (data, $event) {
            console.dir(data);

            $timeout(function () {
            }, 0);

            $(".weekly li.selectedDaysTime").removeClass("selectedDaysTime");
            $($event.currentTarget).addClass("selectedDaysTime");
            for (var i = 0; i < $scope.Drivers1.length; i++) {
                $scope.Drivers1[i].DriverShiftDetails = data.Time;
            }

            setOccupiadDateTimesWeeklyAndMonthly(data.DateTime);
        };

        $scope.SetWeeklyDateTime = function () {
            $timeout(function () {
                $(".weeklyDemo li").eq(0).addClass("selectedDaysTime");
            }, 0);

            for (var i = 0; i < $scope.Drivers.length; i++) {
                $scope.Drivers[i].DriverShiftDetails = $scope.ShiftDateWeekly[0].Time;
            }
        };

        $scope.selection = true;
        $scope.selected = $scope.log = [];

        $scope.selectionStart = function () {
            $scope.log.push(($scope.log.length + 1) + ": selection start!");
        };
        $scope.ParentShiftChart = [];
        $scope.SelectedDateTimes = [];
        $scope.selectionStop = function (selected, id) {

            console.dir(selected);

            $scope.ShiftChart.PropertyID = $scope.PropertyID;
            $scope.ShiftChart.ModifiedBy = $scope.UserName;
            $scope.ShiftChart.DriverShiftDetails = $scope.selected;
            $scope.ShiftChart.DriverId = id;

            angular.forEach($scope.Drivers, function (itm) {
                if (id == itm.Id) {
                    $scope.DirverName = itm.Name;
                }
            });

            //$("#shiftChartSave").show();
            $scope.ParentShiftChart.push($scope.ShiftChart);

            //$scope.SelectedDateTimes = [];

            $scope.log.push(($scope.log.length + 1) + ": items selected: " + selected.length);

            $timeout(function () {
                $scope.SelectedDateTimes = [];
                $scope.selected = $scope.log = [];
            }, 50);
        };

        $scope.openPopup = function (id) {
            //alert(id);
            var setval = id;
        };

        $scope.CancelShiftPopup = function () {
            $("#shiftChartSave").hide();
        };

        $scope.ShiftDateMonthlyTime = [];
        $scope.SetMonthlyDateDateTime = function () {
            angular.forEach($scope.ShiftDateMonthly, function (date) {
                if (date.CurrentMonth) {
                    $scope.MonthlyDays = date.MonthlyDate;
                    $scope.ShiftDateMonthlyTime = date.Times;
                }
            });
            for (var i = 0; i < $scope.Drivers.length; i++) {
                $scope.Drivers[i].DriverShiftDetails = $scope.ShiftDateMonthlyTime;
            }

            //$(".monthwise ul li")
            $(".calendar1 li").unbind("click");
        };
    }
]);
