﻿
app.controller('controller', ['$scope', 'service', 'localStorageService', function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = true;

    var sortKeyOrder = {
        key: '',
        order: '',
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }


 //--------Pagination-------------------------------

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 10;
    $scope.records = "10";
    $scope.recordsPerPage = $scope.records;
    $scope.numberOfPageButtons = 10;

    getData($scope, service, localStorageService);
    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get("sortKeyOrder");
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order === "ASC")
                sortKeyOrder.order = "DESC";
            else
                sortKeyOrder.order = "ASC";
            localStorageService.set("sortKeyOrder", sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: "ASC"
            };
            localStorageService.set("sortKeyOrder", sortKeyOrder);
        }
        getData($scope, service, localStorageService);
    };

    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };

    $scope.search = function (searchfor) {
        
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    }
    $scope.recordsonpage = function (records) {
        $scope.recordsPerPage = records;
        if (records === undefined) {
            $scope.recordsPerPage = 10;
        }
        getData($scope, service, localStorageService);
    }

 //--------------End Pagination--------------------------


    $scope.Reset = function () {
        //$scope.Model = {};
        //$scope.Model.IsActive = false;
        //$scope.ModulesListItem = [];
        //$scope.SubModules = [];
        GetAllSubModules();
        $scope.SelectedModelSubModules = [];
        $scope.SelectedModelModules = [];

    };

    $scope.ShowErrorMessage = false;
    $scope.Save = function (model, form) {
        
        if ($scope[form].$valid) {
            if ($scope.SelectedModelSubModule != null) {

                $scope.Model = $scope.SelectedModelSubModule;
                $scope.Model.Modules = $scope.SelectedModelModules;

                var promiseGet = service.save($scope.Model);
                promiseGet.then(function (data) {
                    getData($scope, service, localStorageService);
                    parent.successMessage(data.Message);
                    $scope.Reset();
                },
                    function (data) {
                        parent.failureMessage(data.Message);
                    });
            } else {
                $('#multiSelectModule').addClass("danger");
            }
        } else {
            $scope.ShowErrorMessage = true;
        }
    };


    $scope.SubModules = [];
    $scope.Modules = [];

    GetAllSubModules();
    GetAllModels();


    function GetAllSubModules() {
        var promiseGet = service.getAllSubModules();
        promiseGet.then(function (data) {
            $scope.SubModules = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
        });
    }

    function GetAllModels() {
        var promiseGet = service.getAllModules();
        promiseGet.then(function (data) {
            $scope.Modules = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
        });
    }


    $scope.SelectedModelSubModule = [];
    $scope.SelectedModelModules = [];
    $scope.MultiSelectSettings = {
        scrollableHeight: '300px',
        scrollable: true,
        enableSearch: true,
        displayProp: 'Name'
    };

    if ($scope.SelectedModelModules.length > 0) {
        //$('#multiSelectModule').removeClass("danger");
    }

    $scope.SubModuleChange = function (selectedModelSubModule) {
        

        $scope.SelectedModelSubModule = [];
        $scope.SelectedModelModules = [];

        if (selectedModelSubModule != null) {
            $scope.SelectedModelSubModule = selectedModelSubModule;
            $scope.SelectedModelModules = selectedModelSubModule.Modules;
        }
    }


}]);


var getData = function ($scope, dataService, localStorageService) {
    
    $scope.data = dataService.dataAllData;
    
    var sortKeyOrder = localStorageService.get('sortKeyOrder');
    if (sortKeyOrder === null) {
        sortKeyOrder = {
            key: 'Name',
            order: 'ASC'
        };
    }

    var searchfor = localStorageService.get('searchfor');
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };

    $scope.showLoader = true;
    dataService.getAll(options)
    .then(function (totalItems) {
        
        $scope.totalItems = totalItems;
        $scope.showLoader = false;
    },
    function () {
        
        parent.failureMessage("The request failed. Unable to connect to the remote server.");
    });

};