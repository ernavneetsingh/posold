﻿
app.controller("ModuleSettingResponseController",
    function ($scope, $http, $filter, moduleSettingResponseService, $window, $cookies, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.MsgNotFound = "";
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
        $scope.ModuleDetails = [];

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "ModuleSettingName") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                return false;
            });

            $scope.currentPage = 0;
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {
            $scope.pagedItems = [];
            $scope.currentPage = 0;
            $scope.itemsPerPage = $scope.filteredItems.length;
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;

        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };

        $scope.getModuleData = function () {
            var getData = moduleSettingResponseService.getModuleData();
            getData.then(function (desigData) {
                //$scope.$apply(function () {
                $scope.ModuleDetails = desigData.Collection;
                //});
            });
        };
        $scope.getModuleData();

        $scope.ModuleChange = function () {

            var getData = moduleSettingResponseService.getAll($scope.PropertyID, $scope.ModuleId);
            getData.then(function (data) {

                $scope.items = data.Collection;
                $scope.search();
            });
        };
        $scope.save = function (form, index) {
            if ($scope[form].$valid) {

                var customData = $scope.items[index];

                customData.PropertyID = $scope.PropertyID;
                customData.ModifiedBy = $scope.ModifiedBy;
                customData.ModifiedDate = $scope.ModifiedDate;

                var saveData = moduleSettingResponseService.save(customData);
                saveData.then(function (data) {


                    parent.successMessage(data.Message);
                    $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                    $scope.ModuleChange();
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.reset = function () {

            $scope.query = '';
            $scope.search();
        };

    });
