﻿
app.service('AccountDumpService', [
    '$http', '$q', function ($http, $q) {
        this.save = function (model) {
            return httpPoster(apiPath + "Tally/AccountDump/Save", $http, $q, model);
        };
    }
]);
