﻿app.service('service', function ($http, $q) {
    
    this.getGetAllTaxType = function () {

        var deferred = $q.defer();
        $http.get(apiPath + 'configuration/TaxType/GetAllTaxType')
            .then(function (result) {
                deferred.resolve(result.data);
            },
            function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;

    };


    this.getAllTaxOn = function () {

        var deferred = $q.defer();

        $http.get(apiPath + 'configuration/TaxOn/getAllTaxOn')
            .then(function (result) {
                deferred.resolve(result.data.Collection);
            },
            function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;
    };

    this.getAllTaxOnTax = function () {

        var deferred = $q.defer();

        $http.get(apiPath + 'configuration/TaxOn/getAllTaxOnTax')
            .then(function (result) {
                deferred.resolve(result.data.Collection);
            },
            function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;
    };

    this.GetTaxOnId = function (id) {

        var deferred = $q.defer();

        $http.get(apiPath + 'configuration/TaxOn/GetTaxOnById/' + id)
            .then(function (result) {
                deferred.resolve(result.data.Collection);
            },
            function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;
    };

    this.GetOutlet = function (propertyId) {
        
        var deferred = $q.defer();
        $http.get(apiPath + 'PointOfSale/Outlet/allByPropertyIdmin/' + propertyId)
            .then(function (result) {
                
                deferred.resolve(result.data.Collection);
            },
            function (data, status, headers, config) {
                
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;
    };

    this.getModule = function () {
        var deferred = $q.defer();
        $http.get(apiPath + 'configuration/Module/all')
            .then(function (result) {
                deferred.resolve(result.data.Collection);
            },
            function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;
    };
    
    this.save = function (model) {

        var url = apiPath + 'GlobalSetting/TaxStructure/save';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);

        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;

    };


    this.changeStatus = function (model) {

        var url = apiPath + 'GlobalSetting/TaxStructure/ChangeStatus';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);

        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    //this.UpdateTaxStructure = function (taxStructureViewModel) {

    //    return $.ajax({
    //        type: "POST",
    //        url: apiPath + 'GlobalSetting/TaxStructure/save',
    //        data: JSON.stringify(taxStructureViewModel),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        headers: { 'duxtechApiKey': accessToken },
    //        success: function (response) { },
    //        error: function (result) {
    //            alert($.parseJSON(result.responseText).Message);
    //        }
    //    });
    //var url = apiPath + 'GlobalSetting/TaxStructure/save';
    //var deferred = $q.defer();
    //$http({
    //    method: 'POST',
    //    url: url,
    //    data:JSON.stringify(taxStructureViewModel)
    //}).success(function (data, status, headers, cfg) {
    //    deferred.resolve(data);

    //}).error(function (data, status, headers, config) {
    //    
    //    deferred.reject(data, status, headers, config);
    //});
    //return deferred.promise;

    //this.validateDate = function (varDate) {
    //    return validateDateformat(varDate);
    //}


    this.getData = function (propertyId) {

        var deferred = $q.defer();
        $http.get(apiPath + 'globalsetting/TaxStructure/' + propertyId)
            .then(function (result) {
                deferred.resolve(result.data.Collection);
            },
            function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });

        return deferred.promise;
    };


    this.delete = function (id) {

        var url = apiPath + 'GlobalSetting/TaxStructure/delete/' + id;
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: {}
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);

        }).error(function (data, status, headers, config) {

            parent.failureMessage("This Tax Structure already in used, Delete operation not possible on this structure.");
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

   

});