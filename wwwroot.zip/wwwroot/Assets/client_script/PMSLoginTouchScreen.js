﻿$(function () {
    var selectoutlet = ('.selectoutletnav li a');
    $(selectoutlet).click(function () {
        $(this).addClass('active');
        $(this).bind('click', function () {
            $(selectoutlet).removeClass('active');
        });
    });

    $('#onetwo').click(function () {
        $('#numericd').show('fast');
        $('#alpha').hide('fast');
    });
    $('#abc').click(function () {
        $('#alpha').show('fast');
        $('#numericd').hide('fast');
    });

    //$('#addcashbtn').click(function () {
    //    $('#addcashbox').show('slow');
    //});
    //$('#addcashcloseicon').click(function () {
    //    $('#addcashbox').hide('slow');
    //});

    //$('#cashoutlink').click(function () {
    //    $('#cashoutbox').show('slow');
    //});
    //$('#cashoutcloseicon').click(function () {
    //    $('#cashoutbox').hide('slow');
    //});

    $('.tablebking_outlethead li a').click(function () {
        $('li a').removeClass('tablebking_outelet-active');
        $(this).addClass('tablebking_outelet-active');
    });

    $('#food').click(function () {
        $('.pagecontent-tblbkng-menutyp ul.horizon-nav').css('width', '100%');
        $('.pagecontent-tblbkng-menutyp ul.horizon-nav li').css('float', 'none').css('margin-bottom', '5px').css('font-size', '12px');
        $('.pagecontent-tblbkng-menutyp ul.horizon-nav li a').css('padding', '13px 10px');
        $('.pagecontent-tblbkng-menutyp .category ul.category-nav').css('width', '86%');
        $('#categorybox').show('slow');
    });

    $('.horizon-nav li a').click(function () {
        $('li a').removeClass('selectmenu');
        $(this).addClass('selectmenu');
    });

    $('.tbl-trnsfr li a').click(function () {
        $('li a').removeClass('tbltrnsfr-active');
        $(this).addClass('tbltrnsfr-active');
    });



    //$('#percentagelink').click(function () {
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav').css('width', '15%');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li').css('float', 'none').css('margin-bottom', '5px').css('font-size', '12px');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li a').css('padding', '13px 8px');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav').css('width', '85%');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav li').css('width', 'auto');
    //    $('#discountBox').show('fast');
    //    $('#taxexemptedbox').hide('fast');
    //    $('#amountdiscountbox').hide('fast');
    //    $('#groupdiscountbox').hide('fast');
    //    $('#splitorderbox').hide('fast');
    //    $('#generatebillbox').hide('fast');

    //});
    //$('#generatebilllink').click(function () {
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav').css('width', '15%');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li').css('float', 'none').css('margin-bottom', '5px').css('font-size', '12px');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li a').css('padding', '13px 8px');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav').css('width', '85%');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav li').css('width', 'auto');
    //    $('#generatebillbox').show('fast');
    //    $('#discountBox').hide('fast');
    //    $('#taxexemptedbox').hide('fast');
    //    $('#amountdiscountbox').hide('fast');
    //    $('#groupdiscountbox').hide('fast');
    //    $('#splitorderbox').hide('fast');

    //});
    //$('#amountdiscountlink').click(function () {
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav').css('width', '15%');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li').css('float', 'none').css('margin-bottom', '5px').css('font-size', '12px');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li a').css('padding', '13px 8px');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav').css('width', '85%');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav li').css('width', 'auto');
    //    $('#amountdiscountbox').show('fast');
    //    $('#taxexemptedbox').hide('fast');
    //    $('#discountBox').hide('fast');
    //    $('#groupdiscountbox').hide('fast');
    //    $('#splitorderbox').hide('fast');
    //    $('#generatebillbox').hide('fast');

    //});
    //$('#groupdiscountlink').click(function () {
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav').css('width', '15%');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li').css('float', 'none').css('margin-bottom', '5px').css('font-size', '12px');;
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li a').css('padding', '13px 8px');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav').css('width', '85%');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav li').css('width', 'auto');
    //    $('#groupdiscountbox').show('fast');
    //    $('#taxexemptedbox').hide('fast');
    //    $('#amountdiscountbox').hide('fast');
    //    $('#discountBox').hide('fast');
    //    $('#splitorderbox').hide('fast');
    //    $('#generatebillbox').hide('fast');
    //});
    //$('#splitorderlink').click(function () {
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav').css('width', '15%');
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li').css('float', 'none').css('margin-bottom', '5px').css('font-size', '12px');;
    //    $('.pagecontent-tblbkng-menutyp ul.horizon-nav li a').css('padding', '13px 8px');
    //    $('.pagecontent-tblbkng-menutyp .category ul.category-nav').css('width', '85%');
    //    $('#splitorderbox').show('fast');
    //    $('#taxexemptedbox').hide('fast');
    //    $('#groupdiscountbox').hide('fast');
    //    $('#amountdiscountbox').hide('fast');
    //    $('#discountBox').hide('fast');
    //    $('#generatebillbox').hide('fast');
    //});

    $('#coverinput').focusin(function () {

        $('#coverbox').show('slow');
    }).focusout(function () {
        $('#coverbox').hide('slow');
    });



});



/*Table Booking Head Navas Show & Hide Divs code starts from here*/

function fadeOut() {
    
    $('#voidkotbox').fadeOut('fast');
    $('#tbletrnsfrtblelnk').fadeOut('fast');
    $('#stewardbox').fadeOut('fast');
    $('#menutypebox').fadeOut('fast');
    $('#openitembox').fadeOut('fast');
    $('#repeatorderbox').fadeOut('fast');
    $('#nckotbox').fadeOut('fast');
    $('#billingbox').fadeOut('fast');

    $('#billreprintbox').fadeOut('fast');
    $('#modifierbox').fadeOut('fast');
    $('#happyhoursbox').fadeOut('fast');
    $('#multirestaurentbox').fadeOut('fast');
    $('#transferlocationbox').fadeOut('fast');
    $('#functionbox').fadeOut('fast');
    $('#combo').fadeOut('combo');
}

function pmsOperation(tabs) {

    fadeOut();

    if (tabs == "combo") {
        $('#combo').fadeIn('combo');
    }

    if (tabs == "steward") {
        $('#stewardbox').fadeIn('fast');
    }
    if (tabs == "menutype") {
        $('#menutypebox').fadeIn('fast');
    }
    if (tabs == "openitem") {
        $('#openitembox').fadeIn('fast');
    }
    if (tabs == "tabletransfertablelink") {
        $('#tbletrnsfrtblelnk').fadeIn('fast');
    }
    if (tabs == "voidkot") {
        $('#voidkotbox').fadeIn('fast');
    }
    if (tabs == "repeatorder") {
        $('#repeatorderbox').fadeIn('fast');
    }
    if (tabs == "nckot") {
        $('#nckotbox').fadeIn('fast');
    }
    if (tabs == "billing") {
        $('#billingbox').fadeIn('fast');
    }
    if (tabs == "addtext") {
        $('#addkotbox').fadeIn('fast');
    }
    if (tabs == "billreprint") {
        $('#billreprintbox').fadeIn('fast');
    }
    if (tabs == "modifier") {
        $('#modifierbox').fadeIn('fast');
    }
    if (tabs == "happyhours") {
        $('#happyhoursbox').fadeIn('fast');
    }
    if (tabs == "multirestaurent") {
        $('#multirestaurentbox').fadeIn('fast');
     }
    if (tabs == "transferlocation") {
        $('#transferlocationbox').fadeIn('fast');
    }
    if (tabs == "function") {
        $('#functionbox').fadeIn('fast');
    }

    $('#closekotstatus').click(function () {
        $('#kotstatusbox').fadeOut('fast');
    });
    $('#closecheckstatus').click(function () {
        $('#checkstatusbox').fadeOut('fast');
    });
    $('#closeshiftransfer').click(function () {
        $('#shifttransferbox').fadeOut('fast');
    });
    $('#closeflashview').click(function () {
        $('#flashviewbox').fadeOut('fast');
    });


}
/* Table Booking Head Navas Show & Hide Divs code Ends here*/