﻿
app.service("deLinkService", function ($http, $q) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.Get = function (propertyId, dateFormat) {
        return httpCaller(apiPath + "AccountReceiveable/Transaction/all/" + propertyId + "/" + dateFormat, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/Transaction/all/" + propertyId + "/" + dateFormat,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {

        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.GetDefaults = function (propertyId, dateFormat) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Transaction/GetDefaults/" + propertyId + "/" + dateFormat,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;

    };
    this.getLinkedBills = function (propertyId, transactionId, dateFormat) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Transaction/GetLinkedBills/" + propertyId + "/" + transactionId + "/" + dateFormat,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.link = function (id, user, billNos, billAmounts, modifiedDate) {

        var deferred = $q.defer();
        var param = { id: id, user: user, billNos: billNos, billAmounts: billAmounts, modifiedDate: modifiedDate };
        $http({
            method: "POST",
            url: apiPath + "AccountReceiveable/Transaction/Link",
            params: param,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {

            msg(err.Message);
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.dLink = function (id, user, bills, modifiedDate) {

        var deferred = $q.defer();
        var param = { id: id, user: user, bills: bills, modifiedDate: modifiedDate };
        $http({
            method: "POST",
            url: apiPath + "AccountReceiveable/Transaction/DLink",
            params: param,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {

            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    //this.getRecentActivity = function (corporateId) {
    //    
    //    var deferred = $q.defer();
    //    var param = { corporateId: corporateId };
    //    $http({
    //        method: "GET",
    //        url: apiPath + "AccountReceiveable/Transaction/Recent",
    //        params: param,
    //        headers: { 'duxtechApiKey': accessToken },
    //        contentType: "application/json; charset=utf-8"
    //    }).success(function (data, status, headers, cfg) {
    //        
    //        deferred.resolve(data);
    //    }).error(function (err, status) {
    //        
    //        deferred.reject(err, status);
    //    });
    //    return deferred.promise;
    //};

});
