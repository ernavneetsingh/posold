﻿
'use strict';

(function () {

    function service($http, $q) {

        var linkItem = [];
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getSearchPOS = function (model) {
            return httpPoster(apiPath + "PointofSale/POSCustomer/Search", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "PointofSale/POSCustomer/Search",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {

            //        angular.copy(data.Collection, linkItem);
            //        deferred.resolve(data.RecordCount);
            //        //deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        linkItem = [];
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        var save = function (model) {
            
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "PointOfSale/MessagePanelPOS/Save",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        return {
            getSearchPOS:getSearchPOS,
            dataAllData: linkItem,
            save:save,
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
