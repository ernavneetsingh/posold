﻿'use strict';

(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var model = [];
        var getAllProduct = function (userid) {

            var url = apiPath + 'configuration/UserProduct/' + userid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAll = function (options) {

            var url = apiPath + "configuration/UserProductPage?userid=" + options.userid + "&" +
                "productid=" + options.productid + "&" +
                "currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                angular.copy(result.Collection, model);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var changeStatus = function (id) {

            var url = apiPath + 'configuration/UserProductPage/status/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);

                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        return {
            dataModel: model,
            getAll: getAll,
            getAllProduct: getAllProduct,
            changeStatus: changeStatus
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
