﻿
app.controller("controller", [
    "$scope", "service", "localStorageService", function ($scope, service, localStorageService) {

        $scope.Model = {};
        $scope.Model.IsActive = true;

        var sortKeyOrder = {
            key: "",
            order: "",
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.IsReadOnly = true;
        $scope.userId = 0;
        $scope.productId = 0;

        //--------Pagination-------------------------------

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        //getData($scope, service, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, service, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };

        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }

        //--------------End Pagination--------------------------


        $scope.Edit = function (item) {

            $scope.Model = item;
            $scope.Model.Name = item.PageName;
            $scope.Model.PageOrderSNo = item.PageOrderSNo;
            $scope.IsReadOnly = false;
            scrollPageOnTop();
        };

        $scope.Reset = function () {

            $scope.Model = {};
            $scope.Model.IsActive = false;

            clearForm();
            $scope.searchfor = null;
            $scope.search();
            scrollPageOnTop();
        };

        $scope.ShowErrorMessage = false;

        function clearForm() {

            $scope.Imagename = "";
            $scope.Description = "";

            angular.forEach(angular.element("input[type='file']"),
                function (inputElem) {
                    angular.element(inputElem).val(null);
                });

        };

        $scope.ChangeStatus = function (model) {

            var promiseGet = service.changeStatus(model.Id);
            promiseGet.then(function (data) {

                parent.successMessage(data.Message);
                getData($scope, service, localStorageService);
                scrollPageOnTop();
            },
                function (error) {

                    parent.failureMessage(error.Message);
                    scrollPageOnTop();
                });
        };

        $scope.Products = [];

        GetAllProduct();

        function GetAllProduct() {
            
            var promiseGet = service.getAllProduct(2);
            promiseGet.then(function (data) {

                $scope.Products = data;
            },
            function (data) {

                parent.failureMessage(data.Message);
            });
        }

        $scope.ProductChange = function (selectedModelProduct) {

            //$scope.data = null;
            $scope.userId = selectedModelProduct.UserId;
            $scope.productId = selectedModelProduct.Id;
            getData($scope, service, localStorageService);
        }

    }
]);

var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "PageDescription",
            order: "ASC"
        },
            sortKeyOrder = {
                key: "ModuleName",
                order: "ASC"
            },
             sortKeyOrder = {
                 key: "PageOrderSNo",
                 order: "ASC"
             };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        userid: $scope.userId,
        productid: $scope.productId,
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getAll(options)
        .then(function (totalItems) {

            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {

                parent.failureMessage("The request failed. Unable to connect to the remote server.");//The request failed. Unable to connect to the remote server.
            });

};