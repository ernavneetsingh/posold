﻿
app.controller("GuestManagementController", [
    "$scope", "GuestManagementService", "localStorageService", "$cookies", "$filter","GuestMessageService", function (
        $scope, guestManagementService, localStorageService, $cookies, $filter,guestMessageService) {

        $scope.guestMessageService= guestMessageService.init($scope);

        $scope.getReservationList = function () {
            guestManagementService.getReservationList($scope.PropertyID,$scope.ModifiedDate)
                .then(function (result) {
                    $scope.ReservationList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getReservationList();
        $("#ReservationSearch").autocomplete({
            source: function (request, response) {
                if (!$scope.ReservationList || $scope.ReservationList.length < 1) {
                    msg('Reservation items not available.');
                    return;
                }
                $scope.ReservationListSearched = [];
                angular.forEach($scope.ReservationList, function (item) {
                    if (item.ReservationNo.indexOf(request.term) > -1) {
                        $scope.ReservationListSearched.push(item);
                    }
                });
                response($.map($scope.ReservationListSearched, function (item) {
                    return {
                        label: item.ReservationNo,
                        val: item
                    };
                }));
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        $scope.loadReservation(ui.item.val.Id);
                    }
                }
            },
            minLength: 1
        });
        $scope.loadReservation = function (id) {
             
            guestManagementService.getReservation($scope.PropertyID, id,$scope.ModifiedDate)
                .then(function (result) {
                              
                    $scope.res = result.Data;
                    $scope.model.MessageToId = $scope.res.Id;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.searchReservation = function (dt) {
            
            if (!$scope.ReservationList || $scope.ReservationList.length < 1) {
                msg('Reservations not available.');
                return;
            }
            $scope.ReservationListSearched = [];
            angular.forEach($scope.ReservationList, function (item) {
           
                if (dateCompare(item.ReservationDate, dt) == 0) {
                    $scope.ReservationListSearched.push(item);
                }
            });

        };

        $scope.getRoomList = function () {
            
            guestManagementService.getRoomList($scope.PropertyID, $scope.ModifiedDate)
                .then(function (result) {
                     
                    $scope.RoomList = [];
                    angular.forEach(result.Collection,function(room){
                        angular.forEach(room.CheckINGuests,function(checkINGuest){
                             
                            $scope.RoomList.push({
                                Id                  : checkINGuest.Id,
                                RoomNumber          : room.RoomNumber,
                                RoomMasterId        : room.RoomMasterId,
                                GuestName           : checkINGuest.GuestNameForDisplay,
                                CheckINDateString   : checkINGuest.CheckINDate,
                                CheckOUTDateString  : checkINGuest.CheckOUTDate,
                                IsRoomOwner         : checkINGuest.IsRoomOwner,
                            });
                        });                  
                    });

                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getRoomList();
        $("#RoomNumberSearch").autocomplete({
            source: function (request, response) {
                 
                if (!$scope.RoomList || $scope.RoomList.length < 1) {
                    msg('Rooms not available.');
                    return;
                }
                
                $scope.$apply(function () {
                    $scope.RoomListSearched = $scope.RoomList.filter(x=>x.RoomNumber.indexOf(request.term) > -1);
                    if($scope.model.MessageTypeId=='5' || $scope.model.MessageTypeId=='6' || $scope.model.MessageTypeId=='7' || $scope.model.MessageTypeId=='8')
                    {
                        $scope.RoomListSearched = $scope.RoomListSearched.filter(x=>x.IsRoomOwner ==true );
                    }

                });
               
                response($.map($scope.RoomListSearched, function (item) {
                    return {
                        label: item.RoomNumber + ':  ' + item.GuestName,
                        val: item
                    };
                }));
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        $scope.loadRoom(ui.item.val);
                    }
                }
            }, 
            minLength: 1
        });
        $scope.loadRoom = function (record) {

            //$scope.res = record;
            //$scope.model.MessageToId = record.Id;

            $scope.$apply(function () {
                $scope.res = record;
                $scope.model.MessageToId = record.Id;
            });
        };

        $scope.getGuestList = function () {
           
            guestManagementService.getGuestList($scope.PropertyID)
                .then(function (result) {
                   
                    $scope.GuestList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getGuestList();
        $("#GuestSearch").autocomplete({
            source: function (request, response) {
                if (!$scope.ReservationList || $scope.ReservationList.length < 1) {
                    msg('Reservation items not available.');
                    return;
                }
                $scope.ReservationListSearched = [];
                angular.forEach($scope.ReservationList, function (item) {
                    if (item.GuestName.indexOf(request.term) > -1) {
                        $scope.ReservationListSearched.push(item);
                    }
                });
                response($.map($scope.ReservationListSearched, function (item) {
                    return {
                        label: item.GuestName + ' ' + item.ReservationNo,
                        val: item
                    };
                }));
                                
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        $scope.loadReservation(ui.item.val.Id);
                    }
                }
            },
            minLength: 1
        });
        $scope.loadGuest = function (record) {
             
            $scope.res = record;
            $scope.res.GuestName = record.Name;
            $scope.model.MessageToId = record.Id;
        };

        $scope.getCorporateList = function () {
          
            guestManagementService.getCorporateList($scope.PropertyID)
                .then(function (result) {
                  
                    $scope.CorporateList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getCorporateList();
        $("#CorporateSearch").autocomplete({
            source: function (request, response) {
                if (!$scope.ReservationList || $scope.ReservationList.length < 1) {
                    msg('Reservation items not available.');
                    return;
                }
                $scope.ReservationListSearched = [];
                angular.forEach($scope.ReservationList, function (item) {
                    if (item.CorporateName.indexOf(request.term) > -1) {
                        $scope.ReservationListSearched.push(item);
                    }
                });
                response($.map($scope.ReservationListSearched, function (item) {
                    return {
                        label: item.CorporateName + ' ' + item.ReservationNo,
                        val: item
                    };
                }));

            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        $scope.loadCorporate(ui.item.val);
                    }
                }
            },
            minLength: 1
        });
        $scope.loadCorporate = function (record) {
             
            $scope.res = record;
            $scope.res.CorporateName = record.Name;
            $scope.model.MessageToId = record.Id;
        };
        $("#GuestSearch2").autocomplete({
            source: function (request, response) {
                if (!$scope.RoomList || $scope.RoomList.length < 1) {
                    msg('Rooms not available.');
                    return;
                }
                $scope.RoomListSearched = [];
                angular.forEach($scope.RoomList, function (item) {
                    if (item.GuestName.toLowerCase().indexOf(request.term.toLowerCase()) > -1) {
                        $scope.RoomListSearched.push(item);
                    }
                });
                response($.map($scope.RoomListSearched, function (item) {
                    return {
                        label: item.GuestName + ' ' + item.RoomNumber,
                        val: item
                    };
                }));

            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        $scope.loadRoom(ui.item.val);
                    }
                }
            },
            minLength: 1
        });
        $("#CorporateSearch2").autocomplete({
            source: function (request, response) {
                 
                if (!$scope.RoomList || $scope.RoomList.length < 1) {
                    msg('Rooms not available.');
                    return;
                }
                $scope.RoomListSearched = [];
                angular.forEach($scope.RoomList, function (item) {
                    if (item.CorporateName.indexOf(request.term) > -1) {
                        $scope.RoomListSearched.push(item);
                    }
                });
                response($.map($scope.RoomListSearched, function (item) {
                    return {
                        label: item.CorporateName + ' ' + item.RoomNumber,
                        val: item
                    };
                }));

            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        $scope.loadRoom(ui.item.val);
                    }
                }
            },
            minLength: 1
        });
        $scope.reset = function () {
            $scope.resetCommon();
            $scope.res = {};
            $scope.model = {MessageTypeId:1,MessageToTypeId:1,MessageDeliveryTime:new Date(1970, 0, 1, 0,0, 0)};
            $scope.getList();
        };
        $scope.resetCommon = function () {
            msg('');
            $scope.ReservationSearch = '';
            $scope.ReservationDateSearch = '';
            $scope.GuestSearch = '';
            $scope.CorporateSearch = '';
            $scope.RoomNumberSearch = '';
            $scope.GuestSearch2 = '';
            $scope.ReservationListSearched = [];
            $scope.RoomListSearched = [];
        };
        $scope.resetMessage = function () {
            $scope.resetCommon();
            $scope.model.MessageFromName = "";
            $scope.model.MessageFromAddress = "";
            $scope.model.MessageFromMobile = "";
            $scope.model.MessageFromEmail = "";

        };
        $scope.resetWakeup = function () {
            $scope.resetCommon();
            $scope.model.MessageDeliveryDate = "";
            $scope.model.MessageDeliveryTime = "";
            $scope.model.MessageDeliveryEx = "";
            $scope.model.IsMessageEveryDay = false;
            $scope.model.MessageDeliveryFood = "";

            $scope.model.MessageFromName = $scope.model.ModifiedBy;
            $scope.model.MessageFromMobile = $scope.model.ModifiedBy;
        };
        
        $scope.save = function () {
            
            if (($scope.model.MessageTypeId == 1 || $scope.model.MessageTypeId == "1") && !$scope['myform'].$valid) {
                $scope.ShowErrorMessage = true;
                msg('');
                return;
            }
            else if (($scope.model.MessageTypeId == 2 || $scope.model.MessageTypeId == "2") && !$scope['myformw'].$valid) {
                $scope.ShowErrorMessageW = true;
                msg('');
                return;
            }
            else if (($scope.model.MessageTypeId == 3 || $scope.model.MessageTypeId == "3") && !$scope['myformc'].$valid) {
                $scope.ShowErrorMessageC = true;
                msg('');
                return;
            }
            if ($scope.model.MessageTypeId == "2"|| $scope.model.MessageTypeId == 4 || $scope.model.MessageTypeId == "4") {
                $scope.model.MessageFromName=$scope.res.GuestName;
                $scope.model.MessageFromMobile=$scope.res.GuestName;
                if ($scope.model.MessageTypeId == "2") 
                    $scope.model.MessageDeliveryTimeForDisplay=timeParser($scope.model.MessageDeliveryTime).substr(0,5);
            }
            if ($scope.model.MessageTypeId == 3 || $scope.model.MessageTypeId == "3") {
                $scope.model.MessageFromId=$scope.res.Id;
                $scope.model.MessageFromName= $scope.res.RoomNumber+': ' +$scope.res.GuestName ;
                $scope.model.MessageFromMobile=$scope.res.GuestName;
            }
            if ($scope.model.MessageTypeId.toString() == "5" || $scope.model.MessageTypeId.toString() == "6" || $scope.model.MessageTypeId.toString() == "7" || $scope.model.MessageTypeId.toString() == "8" ) {
                $scope.model.MessageFromName=$scope.ModifiedBy;
                $scope.model.MessageFromMobile=$scope.ModifiedBy;
            }

            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.MessageOn = $scope.model.MessageAcknowledgeOn = $scope.ModifiedDate;
             
            var promise = guestMessageService.save($scope.model);
            promise.then(function (d) {
                msg(d.Message, d.Status);
                $scope.reset();
            });
        };
        $scope.getList = function () {
             
            if (!$scope.model.MessageTypeId || !$scope.model.MessageToTypeId) return;
            if ($scope.model.MessageTypeId == 1 || $scope.model.MessageTypeId == "1") {
                $scope.resetWakeup();
                if( $scope.model.MessageToTypeId>3)$scope.model.MessageToTypeId = 1;
            }
            else if ($scope.model.MessageTypeId == 2 || $scope.model.MessageTypeId == "2" || $scope.model.MessageTypeId.toString() == "5" || $scope.model.MessageTypeId.toString() == "6" || $scope.model.MessageTypeId.toString() == "7" || $scope.model.MessageTypeId.toString() == "8") {
                $scope.resetMessage();
                $scope.model.MessageToTypeId = 3;
            }
            else if ($scope.model.MessageTypeId == 3 || $scope.model.MessageTypeId == "3") {
                $scope.model.MessageToTypeId = 5;
            }else if ($scope.model.MessageTypeId == 4 || $scope.model.MessageTypeId == "4") {
                $scope.resetWakeup();
                $scope.model.MessageToTypeId = 3;
            }

            guestManagementService.getList($scope.PropertyID, $scope.model.MessageTypeId, $scope.model.MessageToTypeId)
                .then(function (result) {
                    
                    $scope.itemsFull = result.Collection;                    
                    $scope.receiver={MessageTypeId:$scope.model.MessageTypeId, MessageToTypeId:$scope.model.MessageToTypeId,messages : $filter('groupBy')($scope.itemsFull, 'MessageToName', $scope.model.MessageToTypeId == "3" ? 'RoomNumber' :$scope.model.MessageToTypeId == "5" ? 'MessageFromName':'MessageToId')};    
                }, function (err) {
                    msg(err.Message);
                });
        };
      
        $scope.getDepartmentList = function () {
             
            guestManagementService.getDepartmentList($scope.PropertyID)
                .then(function (result) {
                     
                    $scope.DepartmentList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getDepartmentList();
        $scope.filterByDepartment = function () {
             
            $scope.items1 =$scope.itemsFull.filter(x=>x.MessageToId== $scope.DepartmentMessageToId) ;
            $scope.receiver={messages : $filter('groupBy')($scope.items1, 'MessageToName')};
           
        };
        $scope.validateEmail = function (event) {
            if (event.currentTarget.value == "") {
                $(event.currentTarget).removeClass("danger");
                $(event.currentTarget).addClass("success");
                return false;
            }
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (expr.test((event.currentTarget.value)) == false) {
                event.currentTarget.value = "";
                $(event.currentTarget).removeClass("success");
                $(event.currentTarget).addClass("danger");
                return false;
            } else {
                $(event.currentTarget).addClass("success");
                return true;
            }
        };
    
        $scope.reset();

    }
]);
