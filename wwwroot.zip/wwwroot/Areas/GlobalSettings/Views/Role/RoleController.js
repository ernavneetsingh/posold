﻿
app.controller("controller", ["$scope", "service", "$cookies" ,"localStorageService", function ($scope, service, $cookies, localStorageService) {
    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
    $scope.ModifiedBy = $cookies.get('UserName');
    $scope.Model = {
        Id: "",
        Name: "",
        Deprecated: "",
        IsActive: true,
        OrderSNo: "",
        UserProductId: "",
        Users: [],
        RoleModules: [],

        ProductID: '',
        UserProductModules: [],
        PropertyID: '',
        ModifiedBy: ''

    };

    var sortKeyOrder = {
        key: "",
        order: "",
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 20;
    $scope.recordsPerPage = 10;
    $scope.numberOfPageButtons = 20;

    //getData($scope, service, localStorageService);
    //--------------------For Pagination---------------------------------------------------------------------------------------------
    $scope.sort = function (col) {
        
        sortKeyOrder = localStorageService.get("sortKeyOrder");
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == "ASC")
                sortKeyOrder.order = "DESC";
            else
                sortKeyOrder.order = "ASC";
            localStorageService.set("sortKeyOrder", sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: "ASC"
            };
            localStorageService.set("sortKeyOrder", sortKeyOrder);
        }
    };
    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };
    $scope.search = function (searchfor) {
        
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    };
    $scope.recordsonpage = function (records) {
        $scope.recordsPerPage = records;
        if (records === undefined) {
            $scope.recordsPerPage = 10;
        }
        getData($scope, service, localStorageService);
    }
    //------------------------------------------------------------------------------------------------------
    //---------------For Select product------------------------------------
    $scope.UserProducts = [];
    GetAllUserProduct();
    function GetAllUserProduct() {
        var promiseGet = service.getAllUserProduct($scope.ModifiedBy);
        promiseGet.then(function (data, status) {
            $scope.UserProducts = data;
            if($scope.UserProducts.length==1)
            {
                 
                $scope.Model.UserProductId = $scope.UserProducts[0].Id.toString();
                $scope.GetAllModule($scope.Model.UserProductId);
            }
        },
        function (error, status) {
            msg(error.Message);
        });
    };
    //---------------------------For MultiSelect--------------------------------------------------------------
    $scope.Modules = [];
    $scope.SubModules = [];

    $scope.GetAllModule=function(userProductId) {

        $scope.UserProductModules = [];
        $scope.Modules = [];
        $scope.SubModules = [];
        $scope.data = [];
        
        
        if (userProductId != undefined)
        {
            if (userProductId.length>0)
            {
                getData($scope, service, localStorageService);
            }
        }
        

        angular.forEach($scope.UserProducts, function (item) {
            if (userProductId == item.Id) {
                $scope.UserProductModules = item.UserProductModules;
            }
        });
 
        var output = [],
            keys = [];
        var keyname = 'ModuleId';
        angular.forEach($scope.UserProductModules, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                $scope.Modules.push({ Id: item.ModuleId, Name: item.ModuleName });
            }
        });

    }

    $scope.GetAllSubModule = function (moduleId, index) {
       
        $scope.RoleModulePages = [];
        $scope.Index = index;
        $scope.RoleModules[index].SubModuleId = "";
        $scope.RoleModules[index].SubModulesForDisplay = [];
        
        
        angular.forEach($scope.UserProductModules, function (item) {
            if (moduleId == item.ModuleId) {
                $scope.RoleModules[index].SubModulesForDisplay.push({ Id: item.SubModuleId, Name: item.SubModuleName });
            }
        });
    }

    $scope.ModuleId = "";
    $scope.SubModuleId = "";
    $scope.Index = '';
    $scope.RoleModulePages = [];
    
    $scope.GetAllPage = function (moduleid, submoduleid, index) {
        
        var isExist = false;
        angular.forEach($scope.RoleModules, function (item,key) {
            if (item.ModuleId == moduleid && item.SubModuleId == submoduleid && index != key)
            {
                parent.failureMessage("Module and Sub-Module already selected.");
                scrollPageOnTop();
                isExist = true;
            }

            if (index == key && isExist)
            {
                item.ModuleId = "";
                item.SubModuleId = "";
            }
            

        });

        if (isExist == true)
        {
            return;
        }


        $scope.ModuleId = moduleid;
        $scope.SubModuleId = submoduleid;

        


        $scope.Index = index;
        var promiseGet = service.getAllUserProductPage($scope.Model.UserProductId, moduleid, submoduleid, $scope.Model.Id);
        promiseGet.then(function (data, status) {
            
            $scope.RoleModulePages = data;
        },
        function (error, status) {
            msg(error.Message);
        });

    }

    $scope.ViewSelectedPage = function (item,index) {
        
        
        $scope.Index = index;
        $scope.RoleModulePages = [];
        $scope.ModuleId = item.ModuleId;
        $scope.SubModuleId = item.SubModuleId;
        $scope.RoleModulePages = item.RoleModulePages;
        

    }

    //-----------------------------------------------------------------------------------------

    //----------------------For Save Status Edit Reset-------------------------------------------------------------------

    $scope.RoleModule = {
        Id: '',
        RoleId: '',
        RoleName: '',
        ModuleId: '',
        ModuleName: '',
        SubModuleId: '',
        SubModuleName: '',
        OrderSNo: '',
        IsActive: '',
        RoleModulePages: [],
        SubModulesForDisplay:[],
    };

    $scope.RoleModulePages = [];

    $scope.RoleModulePage = {
        Id :'',
        RoleModuleId :'',
        RoleId :'',
        RoleName :'',
        ModuleId :'',
        ModuleName: '',
        SubModuleId :'',
        SubModuleName :'',
        UserProductPageId :'',
        UserProductId :'',
        UserId :'',
        UserName :'',
        ProductId :'',
        ProductName :'',
        PageId :'',
        PageName :'',
        PageDescription :'',
        PageIsActive :'',
        PageOrderSNo :'',
        PageUrl :'',
        IsActive :'',
    };

    $scope.RoleModules = [];
    $scope.RoleModules.push({
        Id: '',
        RoleId: '',
        RoleName: '',
        ModuleId: '',
        ModuleName: '',
        SubModuleId: '',
        SubModuleName: '',
        OrderSNo: 0,
        IsActive: true,
        RoleModulePages: [],
    });

    $scope.AddPage = function () {
        
       
        var roleModuleId = '';
        $scope.SubModulesForDisplay = [];
        angular.forEach($scope.RoleModules, function (item, index) {
            if ($scope.Index == index) {
                roleModuleId = item.Id;
                $scope.SubModulesForDisplay = item.SubModulesForDisplay
            }
        });

        $scope.RoleModule = {
            Id: roleModuleId,
            RoleId: $scope.Model.Id,
            RoleName: '',
            ModuleId: $scope.ModuleId,
            ModuleName: '',
            SubModuleId: $scope.SubModuleId,
            SubModuleName: '',
            OrderSNo: 0,
            IsActive: true,
            RoleModulePages: [],
            SubModulesForDisplay: $scope.SubModulesForDisplay,
            SelectedRoleModulePageCount:0,
        };
        
        angular.forEach($scope.RoleModulePages, function (item) {
            $scope.RoleModule.RoleModulePages.push({
                Id: item.Id,
                RoleModuleId: item.RoleModuleId,
                //RoleId: item.RoleId ,
                //RoleName: item.RoleName ,
                ModuleId: item.ModuleId ,
                //ModuleName: item.ModuleName ,
                SubModuleId: item.SubModuleId ,
                //SubModuleName: item.SubModuleName ,
                UserProductPageId: item.UserProductPageId,
                UserProductId : item.UserProductId.toString(),
                //UserId: item.UserId ,
                //UserName: item.UserName ,
                //ProductId: item.ProductId ,
                //ProductName: item.ProductName ,
                //PageId: item.PageId ,
                PageName: item.PageName ,
                PageDescription: item.PageDescription ,
                ActionMasters:item.ActionMasters,
                //PageIsActive: item.PageIsActive ,
                //PageOrderSNo: item.PageOrderSNo ,
                //PageUrl: item.PageUrl ,
                IsActive: item.IsActive,
            });
        });

        
        angular.forEach($scope.RoleModules, function (item, index) {
            if (index == $scope.Index) {
                //$scope.RoleModules = [];
                //$scope.RoleModules.push($scope.RoleModule);
                $scope.RoleModule.SelectedRoleModulePageCount = $scope.RoleModule.RoleModulePages.filter(x=>x.IsActive==true).length;
                $scope.RoleModules[index] = $scope.RoleModule;
                
            }
        });
        
        $scope.SubModulesForDisplay = [];
        $scope.RoleModule = {};
        $scope.RoleModulePages = [];
        $scope.ModuleId = '';
        $scope.SubModuleId = '';
        scrollPageOnTop();
    };

    $scope.Save = function (model, form) {
        
        if ($scope[form].$valid) {
            if ($scope.RoleModules.length == 0)
            {
                parent.failureMessage("Please select a module.");
                scrollPageOnTop();
                return;
            }
            //else
            //{
            //    if ($scope.RoleModules[0].RoleModulePages.length == 0) {
            //        parent.failureMessage("Please Select Module Pages.");
            //        $scope.ShowErrorMessagegrid = true;
            //        scrollPageOnTop();
            //        return;
            //    }
            //}

            var isZeroSelected=false;
            angular.forEach($scope.RoleModules, function (item,index) {
                if(item.SelectedRoleModulePageCount==0)
                {
                    isZeroSelected=true;
                }
            });
            if (isZeroSelected==true) {
                parent.failureMessage("Please Select Module Pages.");
                $scope.ShowErrorMessagegrid = true;
                scrollPageOnTop();
                return;
            }

            $scope.Model.RoleModules = $scope.RoleModules
            $scope.Model.ModifiedBy = $scope.ModifiedBy;
            
            var promiseGet = service.save($scope.Model);
            promiseGet.then(function (data, status) {
                
                getData($scope, service, localStorageService);
                parent.successMessage(data.Message);
                $scope.Reset();
            },
            function (data, status, headers, config) {
                
                parent.failureMessage(data.Message);
                scrollPageOnTop();

            });
        } else {
            $scope.ErrorMessage = true;
            scrollPageOnTop();
        }
    };

    $scope.ChangeStatus = function (id) {
        
        var promiseGet = service.changeStatus(id);
        promiseGet.then(function (data) {
            
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.ChangeStatus = function (id) {
        
        var promiseGet = service.changeStatus(id);
        promiseGet.then(function (data) {
            
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.removeRow = function (model) {

        var strDelete = DeletePopup("Are you sure you want to delete this Role?");
        var ret;
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $("#fancyconfirm_cancel")
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $("#fancyConfirm_ok")
                    .click(function () {
                        ret = true;
                        var promiseGet = service.deleterow(model.Id);
                        promiseGet.then(function (data) {
                            parent.successMessage(data.Message);
                            getData($scope, service, localStorageService);
                            scrollPageOnTop();
                        },
                            function (error) {
                
                                parent.failureMessage(error.Message);
                                scrollPageOnTop();
                            });
                        $.fancybox.close();
                    });
            }
        });
    };


    $scope.Edit = function (item) {
        
        $scope.RoleModulePages = [];
        $scope.Model = item;
        $scope.Model.UserProductId = item.UserProductId.toString();

        $scope.RoleModules = $scope.Model.RoleModules;

        angular.forEach($scope.RoleModules, function (item,index) {

            item.ModuleId = item.ModuleId.toString();
            //$scope.GetAllSubModule(item.ModuleId, index);
            item.SubModulesForDisplay = item.SubModulesForDisplay;
            item.SubModuleId = item.SubModuleId.toString();
            item.SelectedRoleModulePageCount = item.RoleModulePages.filter(x=>x.IsActive==true).length;
        });

        //$scope.Model.UserProductId = item.UserProductId.toString();       
        //$scope.moduleList = model.DisplayModuleNames;
        ////model.Modules = $scope.moduleList;
        ////$scope.brandList = model.Brands;
        ////$scope.Model.ItemCategoryIdStore = model.ItemCategoryId.toString();
        //$scope.GetAllModule(item.UserProductId);
        scrollPageOnTop();
    };

    $scope.Reset = function () {
        
        $scope.RoleModules = [];
        $scope.RoleModule = {};
        $scope.RoleModulePages = [];
        $scope.ModuleId = '';
        $scope.SubModuleId = '';
        $scope.Model = {
            IsActive: true,
        };
        $scope.Model.UserProductId = '';
        $scope.Model.Name = '';
        $scope.Model.OrderSNo = '';
        $scope.moduleList = [];
        $scope.Module = [];
        //clearForm();

        $scope.searchfor = "";
        localStorageService.set("searchfor", $scope.searchfor);
        getData($scope, service, localStorageService);

        $scope.RoleModules = [];
        $scope.RoleModules.push({
            Id: '',
            RoleId: '',
            RoleName: '',
            ModuleId: '',
            ModuleName: '',
            SubModuleId: '',
            SubModuleName: '',
            OrderSNo: 0,
            IsActive: true,
            RoleModulePages: [],
        });

        if ($scope.UserProducts.length == 1) {
             
            $scope.Model.UserProductId = $scope.UserProducts[0].Id.toString();
            $scope.GetAllModule($scope.Model.UserProductId);
        }
        GetAllUserProduct();

        scrollPageOnTop();
    };

    $scope.ShowErrorMessage = false;

    //function clearForm() {
    //    $scope.Id = "";
    //    $scope.Name = "";
    //};

    $scope.IsRoleExist = function (model) {
        var promiseGet = service.isRoleExist(model);
        promiseGet.then(function (data) {
        },
        function (error) {           
            $scope.Model.Name = "";
            parent.failureMessage(error.Message);
        });
    }

    $scope.IsOrderSNoExist = function (model) {        
        var promiseGet = service.isOrderSNoExist(model);
        promiseGet.then(function (data) {
            
        },
        function (error) {
            
            $scope.Model.OrderSNo = "";
            parent.failureMessage(error.Message);
        });
    }
    
    $scope.IsReadonly = false;

    $scope.addItem = function (d) {
        
         
        $scope.RoleModulePages = [];
        if ($scope.RoleModules.length > 0) {
            if ($scope.RoleModules[$scope.RoleModules.length - 1].ModuleId == undefined || $scope.RoleModules[$scope.RoleModules.length - 1].ModuleId === "") {
                validateFlag = true;
                msg("Please select module.");
                return;
            }
            if ($scope.RoleModules[$scope.RoleModules.length - 1].SubModuleId == undefined || $scope.RoleModules[$scope.RoleModules.length - 1].SubModuleId === "") {
                validateFlag = true;
                msg("Please select sub module.");
                return;
                
            }
        }
        $scope.RoleModules.push({   
            Id: '',
            RoleId: '',
            RoleName: '',
            ModuleId: '',
            ModuleName: '',
            SubModuleId: '',
            SubModuleName: '',
            OrderSNo: 0,
            IsActive: true,
            RoleModulePages: [],
        });

    };
    $scope.removeItem = function (index) {
        if ($scope.RoleModules.length > 1) {
            $scope.RoleModules.splice(index, 1);
            $scope.RoleModulePages = [];
        }
        else
        {
            $scope.RoleModules.splice(index, 1);
            $scope.RoleModulePages = [];

            $scope.RoleModules.push({
                Id: '',
                RoleId: '',
                RoleName: '',
                ModuleId: '',
                ModuleName: '',
                SubModuleId: '',
                SubModuleName: '',
                OrderSNo: 0,
                IsActive: true,
                RoleModulePages: [],
            });
        }
    };

   
    //-----------------------------------------------------------------------------------------------------------------------
}
]);

var getData = function ($scope, dataService, localStorageService) {
    
    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "UserProductName",
            order: "DESC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {      
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        userproductid: $scope.Model.UserProductId
    };
    $scope.showLoader = true;
    dataService.getAll(options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });
};