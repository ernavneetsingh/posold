﻿'use strict';


(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var model = [];


        return {
        
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
