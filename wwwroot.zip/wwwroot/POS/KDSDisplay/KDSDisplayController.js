﻿apppos.controller("kdsDisplayController", [
    "$scope", "service", "$cookies", "$http", "$filter", "$timeout", "$window", "localStorageService", function (
        $scope, service, $cookies, $http, $filter, $timeout, $window, localStorageService) {

        $scope.ModuleId = 3;
        $scope.IsLoading = false;
        $scope.UserName = $cookies.get('UserName');

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        if (!$scope.UserName || !$scope.PropertyID) {
            window.location = "../../loginpos.html";
        }

        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        
        $scope.PropertyName = localStorageService.get('PropertyName');
        $scope.PropertyCity = localStorageService.get('PropertyCity');
        $scope.PropertyStateId = localStorageService.get('PropertyStateId');
        $scope.PropertyCountryId = localStorageService.get('PropertyCountryId');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.businessDate = $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' + $scope.BusinessDate.Day;
        $scope.KOTs = [];
        $scope.OutletId = '';

        $scope.timeFormat = "HH:mm:ss";
        $scope.format = "dd/MMM/yyyy h:mm:ss a";

        $scope.Clock = "loading clock..."; // initialise the time variable
        $scope.tickInterval = 1000 //ms
        var tick = function () {
            $scope.Clock = $filter("date")(new Date, $scope.timeFormat);
            $timeout(tick, $scope.tickInterval); // reset the timer
            //GetLapse();
        }
        // Start the timer
        $timeout(tick, $scope.tickInterval);

        //
        //var url = window.location.href;
        //$scope.OutletId = getParameterByName('outletid', url);
        //function getParameterByName(name, url) {
        //    if (!url) url = window.location.href;
        //    name = name.replace(/[\[\]]/g, "\\$&");
        //    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        //        results = regex.exec(url);
        //    if (!results) return null;
        //    if (!results[2]) return '';
        //    return decodeURIComponent(results[2].replace(/\+/g, " "));
        //}

        $scope.GetAllOutlet = function () {
            $scope.Outlets = [];
            var promiseGet = service.GetAllOutlet($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Outlets = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.data.Message);
                    scrollPageOnTop();
                });

        };
        $scope.GetAllOutlet();

        $scope.GetAllOrderUPByOutletId = function (outletId) {
            $scope.KOTs = [];
            if (outletId) {
                $scope.OutletId = outletId;
                $scope.GetAllPendingKOT(outletId);
                var promiseGet = service.GetAllOrderUPByOutletId(outletId, $scope.businessDate);
                promiseGet.then(function (data) {
                    $scope.KOTs = data.Collection;
                },
                    function (error) {
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };

        $scope.GetAllPendingKOT = function (outletId) {
            $scope.PendingKOTs = [];
            if (outletId) {
                $scope.OutletId = outletId;
                var promiseGet = service.GetAllPendingKOT(outletId, $scope.businessDate);
                promiseGet.then(function (data) {
                    
                    $scope.PendingKOTs = data.Collection;
                },
                    function (error) {
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };


        //SignalR

        $scope.IsHubConnected = false;
        var connection = $.hubConnection(apiPath);
        var eventName = "onMessageListened";
        connection.start().done(function () {
            $scope.IsHubConnected = true;
            //$("#status").text("").prepend("<i>" + eventName + "</i> event is being listened !").prepend("Connected. ").css("color", "green");
        });
        var messageBroadCast = connection.createHubProxy('BroadCastHub');
        messageBroadCast.on(eventName, function (message) {
            var res = message.split("$");
            if (res[0] == "KDS_DISPLAY_STATUS") {
                if (res[1] == $scope.OutletId)
                {
                    $scope.GetAllOrderUPByOutletId(res[1]);
                }
            }
            else if (res[0] == "TABLE_STATUS") {
                if (res[1] == $scope.OutletId) {
                    $scope.GetAllPendingKOT(res[1]);
                }
            }
            else if (res[0] == "SETTLEMENT") {
                if (res[1] == $scope.OutletId) {
                    if (res.length > 2) {
                        $scope.GetAllPendingKOT(res[1]);
                    }
                }
            }
            else if (res[0] == "KOT_VOID") {
                if (res[1] == $scope.OutletId) {
                    $scope.GetAllPendingKOT(res[1]);
                }
            }
            else if (res[0] == "TRANSFER_KOT") {
                if (res[1] == $scope.OutletId) {
                    $scope.GetAllPendingKOT(res[1]);
                }
            }
            else if (res[0] == "TRANSFER_LOCATION") {
                if (res[1] == $scope.OutletId) {
                    $scope.GetAllPendingKOT(res[1]);
                }
                if (res[3] == $scope.OutletId) {  
                    $scope.GetAllPendingKOT(res[1]);
                }
            }

        });

        //end signalR
    }
]).controller;
