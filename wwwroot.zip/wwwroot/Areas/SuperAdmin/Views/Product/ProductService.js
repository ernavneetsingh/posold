﻿'use strict';


(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var model = [];

        var getAll = function (options) {
            var url = apiPath + "configuration/product?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor;

            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: options,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, model);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {
            var url = apiPath + 'configuration/product/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }

        var isNameExist = function (model) {
            
            var url = apiPath + 'configuration/product/exist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isOrderSNoExist = function (model) {
            
            var url = apiPath + 'configuration/product/orderexist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var changeStatus = function (subProductId) {
            
            var url = apiPath + 'configuration/product/status/' + subProductId;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        return {
            dataModel: model,
            getAll : getAll,
            save : save,
            isNameExist: isNameExist,
            isOrderSNoExist: isOrderSNoExist,
            changeStatus: changeStatus
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
