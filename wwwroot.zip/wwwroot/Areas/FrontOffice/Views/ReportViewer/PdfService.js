﻿//(function () {
//    'use strict';
//    app.factory("pdfServiceFactory", pdfServiceFactory);
//    pdfServiceFactory.$inject = ["$rootScope", "$http", "configuration", "$q"];

//    function generateDomForPDF($rootScope, $http, configuration, $q) { }
//    function convertDomToCanvas(numberOfPages) { }
//    function createPdf(pdfFileName, share) { }
//})();
 
app.service('PdfService', [
    "$http", "$q", "$rootScope", //"configuration", 
    function ($http, $q, $rootScope//, configuration
        ) {

        this.generateDomForPDF = function (filename, pdfFileName, dictionary, share) {
            // 1. Get Local HTML file
            var rawFile = new XMLHttpRequest();
            var contents = "";
            rawFile.open(filename, false);
            rawFile.onreadystatechange = function () {
                if (rawFile.readyState === 4) {
                    if (rawFile.status === 200 || rawFile.status == 0) {
                        contents = rawFile.responseText;
                    }
                }
            }

            //2. Get the file add a new element to the calling page and append the HTML Template file to the DOM.
            rawFile.send(null);
            var element = document.createElement("div");
            element.innerHTML = contents;
            //Give the new element the ID of pdf-results so we can find it
            element.id = "pdf-results";
            document.body.appendChild(element);

            //3. Loop through the DOM and add our variable information to the Template's html searching by element ID
            for (var i = 0; i < dictionary.length; i++) {
                document.getElementById(dictionary[i].variable).innerHTML = dictionary[i].value;
            }

            //4. Find each page selector and generate a canvas of that element.
            var promises = [];
            var elements = document.querySelectorAll("[id^='page-']");
            for (var numberOfPages = 1; numberOfPages <= elements.length; numberOfPages++) {
                promises.push(convertDomToCanvas(numberOfPages));
            }

            //5. When all of the page elements have been turned to canvas generated the PDF.
            $q.all(promises).then(function () {
                generatePageOrPdf(pdfFileName, share)
            });
        };
        this.generateCanvas = function (numberOfPages) {
            var deferred = $q.defer();
            html2canvas(document.getElementById("page-" + numberOfPages), {
                logging: true, allowTaint: true, useCORS: true, onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var pageData = {
                        image: data,
                        fit: [510, 761],
                        pageBreak: "after"
                    };
                    docDefinition.content[numberOfPages - 1] = pageData;
                    deferred.resolve();
                }
            });
            return deferred.promise;
        };
        this.generatePageOrPdf = function (pdfFileName, share) {
            if (docDefinition.content[docDefinition.content.length - 1].pageBreak) {
                delete docDefinition.content[docDefinition.content.length - 1].pageBreak;
            }

            pdfMake.createPdf(docDefinition).getBase64(function (base64) {
                var pdf = atob(base64);
                var arr = new Array(pdf.length);
                for (var i = 0; i < pdf.length; i++) {
                    arr[i] = pdf.charCodeAt(i);
                }

                var byteArray = new Uint8Array(arr);
                var blob = new Blob([byteArray], { type: 'application/pdf' });
                folderpath += "//folder/Path";

                var filename = pdfFileName + ".pdf";
                //Write file to disk
                //Open File in Browser from Disk
            });
            document.body.removeChild(document.getElementById("pdf-results"));
        };

    }
]);
