﻿
app.controller('Controller', [
    '$scope', '$window', '$http', '$q', 'localStorageService', '$filter', 'uiGridExporterService', 'uiGridExporterConstants', '$timeout', 'uiGridGroupingService', 'uiGridConstants', function (
        $scope, $window, $http, $q, localStorageService, $filter, uiGridExporterService, uiGridExporterConstants, $timeout, uiGridGroupingService, uiGridConstants) {

        $scope.ReportPath = ReportXPath + "Reporter/Report";
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.UserId = localStorageService.get('UserId');

        var paramstr = $window.location.search.substring(1);
        var params = paramstr.split('=');
        $scope.ReportId = params[1];

        var loadReportHtml = function (reportId, dateFromString, dateToString, dynamicFilters,filterValue) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/LoadHtml", $http, $q, { reportId: reportId, dateFrom: dateFromString, dateTo: dateToString, dynamicFilters: dynamicFilters ,filterValue:filterValue});
        };
        var getReport = function (reportId) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/Get", $http, $q, { reportId: reportId });
        };
        var getAllDynamic = function (table,reportId,filterValue,filterMasterId,filterMasterName, filterAccessTable, filterAccessColumn, filterAccessValue) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/AllDynamic", $http, $q, { table: table,reportId :reportId,filterValue:filterValue, filterMasterId: filterMasterId, filterMasterName: filterMasterName, filterAccessTable: filterAccessTable, filterAccessColumn: filterAccessColumn, filterAccessValue: filterAccessValue  });
        };
        var getAllHeader= function (filterValue) {
            return httpCallerX(ReportXPath + "api/Reporter/Header/All", $http, $q, { filterValue: filterValue });
        };
        var getEnumList = function (path) {
            return httpCallerX(path, $http, $q);
        };
        
        $scope.load = function (reportId,gridOption,dynamicFilters,print) {

            if (!reportId) {
                msg('Please select a report to load.');
                return;
            }
            if($scope.DateFromString.length>1 &&  $scope.DateToString.length>1 && $scope.DateFromString>$scope.DateToString){
                msg('Please select valid dates.');
                return;
            }

            loadReportHtml(reportId, $scope.DateFromString, $scope.DateToString, dynamicFilters,$scope.PropertyID)
                .then(function (result) {

                    if(result.Data.Table && result.Data.Table.length<1){
                        msg('No data found.');
                        return;
                    }

                    $scope.CurrentData =result.Data.Table; 
                    try{
                        var formulaColumns=$scope.HeaderColumns.filter(x=>x.IsFormula===true);
                        formulaColumns.forEach(function(col){
                            var formulaParts=col.Name.split(' ');
                            var formulaValues=[];
                            formulaParts.forEach(function(formulaPart){
                                var found=$scope.HeaderColumns.find(x=>x.DisplayName===formulaPart);
                                if(found) 
                                    formulaValues.push("row['"+formulaPart+"']");
                                else
                                    formulaValues.push(formulaPart);
                            });
                            var value=formulaValues.join(' ');                           
                        
                            $scope.CurrentData.forEach(function(row){
                                row[col.DisplayName]=eval(value);
                            });

                        });
                    }
                    catch(err) {}

                    $scope.CurrentData =$scope.groupNest($scope.CurrentData, $scope.GrouperColumns); 
                    //$scope.CurrentData =$scope.groupNest(result.Data.Table, $scope.GrouperColumns); 
           
                    var dateColumns = [];

                    var obj1 = result.Data.Table[0];
                    Object.keys(obj1).filter(function (key) {
                        if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 && key.toLowerCase().indexOf('date')>-1 ) {
                            dateColumns.push( key);
                        }                        
                    });

                    angular.forEach(result.Data.Table,function(row){           
                        angular.forEach(dateColumns,function(dateColumn){                             
                            row[dateColumn]=$filter('date')(row[dateColumn], $scope.DateFormat);
                        });

                    });

                }).catch(function (err) {
                    msg(err.Message);
                });
        };
        $scope.groupNest=function(data,groupers){
            if(!groupers || groupers.length<1) return data;
            var g1=groupers[0];
            var data1 = $filter('groupBy')(data, g1.DisplayName);//,'filterid');
            var groupers2=groupers.filter(x=>x.DisplayName!=g1.DisplayName);
            Object.values(data1).forEach(function(d){
                d.Totals=[];
                $scope.HeaderColumns.forEach(function(c){
                    if(c.IsTotal) d.Totals[c.DisplayName] = d.items.reduce(function(total,item) {
                        return total + item[c.DisplayName];
                    },0);//.toFixed(2);
                });
                if(groupers2 && groupers2.length>0) d.items=$scope.groupNest(d.items,groupers2);                
            });           
            return data1;
        };
        $scope.reset = function () {
            $scope.DateFromString = "";
            $scope.DateToString = "";
            $scope.Report = [];
            $scope.CurrentData = [];
            $scope.Report.columns = [];
            $scope.IsLoaded = true;
            $scope.IsPrintDesign = false;
            angular.forEach($scope.FilterColumns, function (col) {
                col.MasterId = "";
                col.MasterIds = [];

            });
        };
        $scope.reset();

        $scope.getAllHeader = function () {

            getAllHeader($scope.PropertyID ).then(function (result) {
                if(result.Collection && result.Collection.length>0) $scope.xApiPath=result.Collection[0].ApiPath;
                $scope.Header =result.Collection[0];
                $scope.selectReport();
            }).catch(function (err) {
                msg(err.Message);
            });

        };
        $scope.selectReport = function () {
            if (!$scope.ReportId) return;
            getReport($scope.ReportId)
             .then(function (result) {
                 var report = result.Data;
                 if (!report) return;

                 $scope.title = report.Name;
                 $scope.IsGroupSummary = report.IsGroupSummary;
                 $scope.HeaderColumns = report.ReportColumns.filter(x => x.IsHidden === false);
                 if($scope.HeaderColumns && $scope.HeaderColumns.length>1) {
                     $scope.HeaderColumns.forEach(function(c){
                         if(c.IsTotal)c.align='right';
                     });
                 }
                 $scope.GrouperColumns= report.ReportColumns.filter(x => x.GroupOrder>0);
                 if($scope.GrouperColumns && $scope.GrouperColumns.length>1) {
                     $scope.GrouperColumns = $filter('orderBy')($scope.GrouperColumns, 'GroupOrder');
                     $scope.GrouperColumns.slice().reverse().forEach(function(g){
                         var col=$scope.HeaderColumns.find(x=>x.DisplayName===g.DisplayName);
                         var index=$scope.HeaderColumns.indexOf(col);
                         $scope.HeaderColumns.splice(index, 1);
                         $scope.HeaderColumns.unshift(col);
                     });
                 }
               
                 $scope.FilterColumns = report.ReportColumns.filter(x => x.IsFilter === true);
                 angular.forEach($scope.FilterColumns, function (col) {

                     if (col.FilterMaster){

                         var promise;
                         if(col.IsEnum)
                             promise=getEnumList($scope.xApiPath + col.FilterMaster + '/all');
                         else
                             promise=getAllDynamic(col.FilterMaster, $scope.ReportId,  $scope.PropertyID,col.FilterMasterId,col.FilterMasterName,col.FilterAccessTable,col.FilterAccessColumn, $scope.UserId);
                         promise.then(function (result) {

                             col.Masters = result.Collection;
                             if(col.FilterType===1)
                                 col.Masters.unshift({Name:"ALL",Id:"ALL"});
                             else if(col.FilterType===2){
                                 col.MasterIds=[];
                                 $scope.filterDynamic();
                             }
                         }).catch(function (err) {

                             msg(err.Message);
                         });
                     }
                 });

                 $scope.IsDateRange= report.ReportColumns.find(x => x.IsDateRange === true);
        
             }).catch(function (err) {
                 msg(err.Message);
             });

        };
        $scope.filterDynamic = function (column) {

            $scope.DynamicFilters = "";
            angular.forEach($scope.FilterColumns, function (col) {

                if(col.FilterType===1)
                { 
                    column.MasterIdAll1=JSON.parse(column.MasterIdAll);
                    column.MasterId=column.MasterIdAll1.Id;
                    column.DisplayValue=column.MasterIdAll1.Name;
                    if (col.MasterId && col.MasterId!=="ALL") {
                        if ($scope.DynamicFilters.length > 5) $scope.DynamicFilters += " AND "
                        if(col.IsEnum)
                            $scope.DynamicFilters += " [" + col.FilterMasterId + "].[" + col.FilterMasterName + "]='" + col.MasterId+ "' ";
                        else
                            $scope.DynamicFilters += " [" + col.TableName + "].[" + col.Name + "]='" + col.MasterId+ "' ";
                    }
                }
                else if(col.FilterType===2)
                {
                    if (col.MasterIds) {
                        var multiFilter=col.MasterIds.length>0?"":"null";
                        angular.forEach(col.MasterIds, function (master) {

                            if (multiFilter.length > 5) multiFilter += ","                          
                            multiFilter += "'" + master.Id+ "'";                        
                        });
                        if(col.IsEnum)
                            multiFilter=" [" + col.FilterMasterId + "].[" + col.FilterMasterName + "] IN (" +multiFilter +  ")";
                        else
                            multiFilter=" [" + col.TableName + "].[" + col.Name + "] IN (" +multiFilter +  ")";
                        if ($scope.DynamicFilters.length > 5) $scope.DynamicFilters += " AND "
                        $scope.DynamicFilters +=  multiFilter;
                    }
                }
            });
        };
        $scope.MasterSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
        $scope.myEventListeners = {
            onItemSelect:  $scope.filterDynamic,
            onItemDeselect:  $scope.filterDynamic,
            onSelectAll: $scope.filterDynamic,
            onDeselectAll: $scope.filterDynamic
        };
        $scope.getAllHeader();        
      
        $scope.print= function () {

            var printDiv= document.getElementById('divDesign');
            var printContents = printDiv.outerHTML;
            var popupWin = window.open('', '_blank', 'width=700,height=600');
            popupWin.document.open();
            popupWin.document.write('<!doctype html><html><head><link rel="stylesheet" type="text/css" href="/Content/bootstrap.css" />');
            popupWin.document.write('</head><body onload="window.print()">');//+printContents+ '</body></html>');
           
            popupWin.document.write('<table><tr><td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>');
            popupWin.document.write('<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name+ '<br/>') );
            popupWin.document.write(!$scope.Header ? '' : ($scope.Header.Address + '<br/>'));
            popupWin.document.write((!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State+ ', ' + $scope.Header.Country) + '<br/>');
            popupWin.document.write('<u><i>'+ $scope.title +' Report</i></u></h3></center></td>');
            popupWin.document.write('<td width=20%><br/><br/><br/><div align=right>Report Date: '+($filter('date')($scope.DateFromString, $scope.DateFormat))+'</div></td></tr></table>');
            popupWin.document.write('<hr/><br/>'+printContents +'<hr/><br/>');
            popupWin.document.write('</body></html>');
            
            popupWin.document.close();

        };
        $scope.printPdf= function () {
            var printDiv= document.getElementById('divDesign');
            if(!printDiv) {
                msg('nothing to print');
                return;
            }
            $scope.export(printDiv,'report');
            
            //var printContents = printDiv.outerHTML;
            //var dataToSave ='';//<!doctype html><html><head><link rel="stylesheet" type="text/css" href="/Content/bootstrap.css" />';
            ////dataToSave +='</head><body onload="window.print()">';
           
            //dataToSave +='<table><tr>';//<td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>';
            //dataToSave +='<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name+ '<br/>') ;
            //dataToSave +=!$scope.Header ? '' : ($scope.Header.Address + '<br/>');
            //dataToSave +=(!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State+ ', ' + $scope.Header.Country) + '<br/>';
            //dataToSave +='<u><i>'+ $scope.title +' Report</i></u></h3></center></td>';
            //dataToSave +='<td width=20%><br/><br/><br/><div align=right>Report Date: '+($filter('date')($scope.DateFromString, $scope.DateFormat))+'</div></td></tr></table>';
            //dataToSave +='<hr/><br/>'+printContents +'<hr/><br/>';
            ////dataToSave +='</body></html><canvas></canvas>';
            
            //var newEl=document.createElement("div");
            //var node=document.createTextNode(dataToSave);
            //newEl.appendChild(node);
            //$scope.export(newEl,'report');
          
            //var printContents = printDiv.outerHTML;
            //var popupWin = window.open('', '_blank', 'width=700,height=600');
            //popupWin.document.open();
            //popupWin.document.write('<!doctype html><html><head><link rel="stylesheet" type="text/css" href="/Content/bootstrap.css" />');
            //popupWin.document.write('</head><body onload="window.print()">');//+printContents+ '</body></html>');
           
            //popupWin.document.write('<table><tr><td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>');
            //popupWin.document.write('<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name+ '<br/>') );
            //popupWin.document.write(!$scope.Header ? '' : ($scope.Header.Address + '<br/>'));
            //popupWin.document.write((!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State+ ', ' + $scope.Header.Country) + '<br/>');
            //popupWin.document.write('<u><i>'+ $scope.title +' Report</i></u></h3></center></td>');
            //popupWin.document.write('<td width=20%><br/><br/><br/><div align=right>Report Date: '+($filter('date')($scope.DateFromString, $scope.DateFormat))+'</div></td></tr></table>');
            //popupWin.document.write('<hr/><br/>'+printContents +'<hr/><br/>');
            //popupWin.document.write('</body></html>');
            
            //popupWin.document.close();
            //$timeout(function () {
            //    $window.myvar=popupWin.document.documentElement;
            //    $scope.export($window.myvar,'report');
            //    popupWin.close();
            //}, 900);
           
        };
        $scope.export = function (html,name) {
            html2canvas(html, {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500,
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download(name+".pdf");
                }
            });
        };
        $scope.saveExcel = function () {

            var printDiv= document.getElementById('divDesign');
            if(!printDiv && !printDiv.outerHTML)  {
                msg('Nothing to save');
                return;
            }
            var printContents = printDiv.outerHTML;
            var dataToSave ='<!doctype html><html><head>';
            dataToSave +='</head><body onload="window.print()">';
           
            dataToSave +='<table><tr><td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>';
            dataToSave +='<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name+ '<br/>') ;
            dataToSave +=!$scope.Header ? '' : ($scope.Header.Address + '<br/>');
            dataToSave +=(!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State+ ', ' + $scope.Header.Country) + '<br/>';
            dataToSave +='<u><i>'+ $scope.title +' Report</i></u></h3></center></td>';
            dataToSave +='<td width=20%><br/><br/><br/><div align=right>Report Date: '+($filter('date')($scope.DateFromString, $scope.DateFormat))+'</div></td></tr></table>';
            dataToSave +='<hr/><br/>'+printContents +'<hr/><br/>';
            dataToSave +='</body></html>';
            var blob = new Blob([dataToSave], {              
                type: "application/vnd.ms-excel"
                //type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
            });
            saveAs(blob, 'Report.xls');
        };

        $scope.DateFromString = "2017-10-11";
        $scope.DateToString = "2017-10-11";
       
    }
]);
