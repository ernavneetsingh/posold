﻿
app.controller('controller', ['$scope', 'service','$filter','localStorageService', function ($scope, service,$filter, localStorageService) {

    $scope.Model = {
        Id: '',
        UserName: '',
        FirstName: '',
        LastName: '',
        Email: '',
        Mobile: '',
        Password: '',
        UserProfileId: '',
        UserProfileName: '',
        IsApproved: '',
        IsActive: '',
        IsLocked: '',
        IsDeleted: '',
        IsOnline: '',
        CreatedDate: '',
        LastLoginDate: '',
        LastUpdate: [],
        DisplayRoles: '',
        Roles: [],
        Properties:[],
        UserPages: [],
        RoleNames: '',
        DefaultPropertyName: '',
        DefaultPropertyCity: '',
        CreatedDateForDisplay:'',
        items: []

    };

    $scope.IsReadonly = false;
    //------------------------------------------------
    //page configuration start
    //------------------------------------------------
    //------------------------------------------------
    ////page configuration parameter
    //------------------------------------------------
    $scope.MsgNotFound = "";
    $scope.sortingOrder = "Name";
    $scope.pageSizes = [5, 10, 25, 50, ];
    //$scope.pageAttrs = ["Symbol", "Name"]; //TODO
    $scope.reverse = false;
    $scope.filteredItems = [];
    $scope.groupedItems = [];
    $scope.itemsPerPage = 10;
    $scope.pagedItems = [];
    $scope.currentPage = 0;
    //------------------------------------------------
    
    // init the filtered items
    $scope.search = function () {
        $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
            for (var attr in item) {
                if (attr === "UserName") {
                    if (searchMatch(item[attr], $scope.query))
                        return true;
                }
            }
            
            return false;
        });

        // take care of the sorting order
        if ($scope.sortingOrder !== '') {
            $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
        }
        $scope.currentPage = 0;
        // now group by pages
        $scope.groupToPages();
    };

    var searchMatch = function (haystack, needle) {
        if (!needle) {
            return true;
        }
        return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
    };

    // show items per page
    $scope.perPage = function () {
        $scope.groupToPages();
    };

    // calculate page in place
    $scope.groupToPages = function () {

        $scope.pagedItems = [];
        $scope.currentPage = 0;
        if ($scope.itemsPerPage === "All") {
            $scope.itemsPerPage = $scope.filteredItems.length;
        }
        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage === 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }
        if ($scope.pagedItems.length === 0) {
            $scope.MsgNotFound = "Record Not Found.";
            $scope.pagedItems.length = 1;

        } else {
            $scope.MsgNotFound = "";
        }
    };

    $scope.range = function (start, end) {
        var ret = [];
        if (!end) {
            end = start;
            start = 0;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }
        return ret;
    };

    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };

    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        }
    };

    $scope.firstPage = function () {
        $scope.currentPage = 0;
    }

    $scope.lastPage = function () {
        $scope.currentPage = $scope.pagedItems.length - 1;
    }

    $scope.setPage = function () {
        $scope.currentPage = this.n;
    };

    // change sorting order
    $scope.sort_by = function (newSortingOrder) {
        
        if ($scope.sortingOrder === newSortingOrder)
            $scope.reverse = !$scope.reverse;

        $scope.sortingOrder = newSortingOrder;
    };
    //------------------------------------------------
    //page configuration end
    //------------------------------------------------


    getData();

    function getData() {
        
        var promiseGet = service.getAll(2);
        promiseGet.then(function (data) {
            
            $scope.Model.items = data;
            $scope.search();
        },
           function (data) {
               
               parent.failureMessage(data.Message);
           });

    };


    GetAllProducts();
   
    function GetAllProducts() {
        var promiseGet = service.getAllProducts();
        promiseGet.then(function (data) {
            $scope.Products = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
        });
    }

    GetAllCountry();
    function GetAllCountry() {
        var promiseGet = service.getAllCountry();
        promiseGet.then(function (data) {
            $scope.Countries = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
        });
    }

    $scope.States = [];
    $scope.GetStateByCountry = function (id) {
        
        $scope.RegistrationModel.Country = $("#countyId option:selected").text();
        var promiseGet = service.getAllState(id);
        promiseGet.then(function (data) {
            $scope.States = data.Collection;
        },
            function (error) {
                parent.failureMessage(error.Message);
            });
    };

    $scope.CountryChange = function (selectedModelCountry) {


        $scope.SelectedModelCountry = [];
        $scope.States = [];

        if (selectedModelCountry != null) {
            $scope.SelectedModelCountry = selectedModelCountry;

            var promiseGet = service.getAllState(selectedModelCountry.Id);
            promiseGet.then(function (data) {
                $scope.States = data.Collection;
            },
                function (error) {
                    parent.failureMessage(error.Message);
                });


        }
    };

    $scope.ChangeStatus = function (model) {
        var promiseGet = service.changeStatus(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };
    $scope.ChangeApproved = function (model) {
        var promiseGet = service.changeApproved(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.ChangeLocked = function (model) {
        var promiseGet = service.changeLocked(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.Save = function (model, form) {
        
                if ($scope[form].$valid) {
                    $scope.Model = model;
                    var promiseGet = service.save($scope.Model);
                    promiseGet.then(function (data) {
                        getData($scope, service, localStorageService);
                        parent.successMessage(data.Message);
                        $scope.Reset();
                    },
                        function (data) {
                            parent.failureMessage(data.Message);
                        });
                } else {
                    $scope.ShowErrorMessage = true;
                }
            };
    $scope.IsEmailExist = function (model) {
        var promiseGet = service.isEmailExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.Email = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };

    $scope.IsMobileExist = function (model) {
        var promiseGet = service.isMobileExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.Mobile = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };


}]);
