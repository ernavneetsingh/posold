﻿
"use strict";
app.controller("InventoryAdjustmentController", ["$scope", "inventoryTransactionService", "$cookies", "StoreService", "localStorageService",
    function ($scope, inventoryTransactionService, $cookies, storeService, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        //TODO navneetmanoj
        //$scope.DateFormat = $cookies.get("DateFormat").replace("yyyy", "yy");
        //var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        //$scope.MinDatess = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ("0" + date.getDate()).slice(-2);

        $scope.getOpeningDate = function () {
            var promise = inventoryTransactionService.getAll($scope.PropertyID, $scope.DateFormat, 6);
            promise.then(function (data) {
                if (data.Collection.length < 1) return;
                $scope.MinDate = data.Collection[0].TransactionDateString;
            });
        }
        $scope.getOpeningDate();

        $scope.adjustmentdatalist = [];
        $scope.itemcode = "";
        $scope.itemname = "";
        $scope.grnno = "";
        $scope.grndate = "";
        $scope.batchno = "";
        $scope.expirydate = "";
        $scope.cbqty = "";
        $scope.cbrate = "";
        $scope.cbvalue = "";
        $scope.adjqty = "";
        $scope.adjrate = "";
        $scope.adjvalue = "";
        $scope.Save = "Save";
        $scope.reasonList = [];
        $scope.storeList = [];

        getglobal();
        getReason();

        $scope.getBrands = function () {
            var promise = inventoryTransactionService.getBrands($scope.PropertyID, 1);
            promise.then(function (data, status) {
                $scope.BrandList = data.Collection;
            });
        }
        $scope.getBrands();
        $scope.getItemsToAdjust = function (itemId, brandId, index) {

            for (var i = 0; i < $scope.adjustmentdatalist.length ; i++) {
                if (i == index) continue;
                if ($scope.adjustmentdatalist[i].InventoryItemId === itemId && $scope.adjustmentdatalist[i].BrandId === brandId) {
                    msg("this brand is already taken");
                    $scope.adjustmentdatalist[index].BrandId = "";
                    return;
                }
            }
            if (!$scope.model.TransactionDateString) {
                msg("Please enter adjustment date to get stock");
                return;
            }
            var promise = inventoryTransactionService.getItemStock($scope.PropertyID, itemId, brandId, $scope.model.TransactionDateString);
            promise.then(function (data) {

                if (data.Data === null) return;
                $scope.adjustmentdatalist[index].Balance = data.Data;
            });
        }

        $scope.removeItem = function (index) {

            $scope.adjustmentdatalist.splice(index, 1);
        };
        $scope.addItem = function (form) {
            var flag = false;
            if ($scope.Adjqty === 0) {
                return;
            }
            if ($scope.Adjvalue === 0) {
                return;
            }
            var st = $scope[form].$valid;
            if (st) {

                if ($scope.adjustmentdatalist.length == 0) {
                    $scope.adjustmentdatalist.push({
                        Itemid: $scope.itemid,
                        AdjItemcode: $scope.Itemcode,
                        AdjItemname: $scope.Itemname,
                        Brandname: $scope.Brandname,
                        AdjGrnno: $scope.Grnno,
                        AdjGrndate: $scope.Grndate,
                        AdjBatchno: $scope.Batchno,
                        AdjExpirydate: $scope.Expirydate,
                        AdjCbqty: $scope.Cbqty,
                        AdjCbrate: $scope.Cbrate,
                        AdjCbvalue: $scope.Cbvalue,
                        AdjQty: $scope.Adjqty,
                        AdjRate: $scope.Adjrate,
                        AdjValue: $scope.Adjvalue,
                        ItemTransactionId: $scope.ItemTransactionId,
                        ItemUom: $scope.ItemUom,
                        TaxAmount: $scope.TaxAmount,
                        ItemTaxStructureId: $scope.ItemTaxStructureId,
                        ItemDiscount: $scope.ItemDiscount,
                        ItemDiscountIn: $scope.ItemDiscountIn,
                        ItemReceiptId: $scope.ItemReceiptId,
                        ConsignmentNo: $scope.ConsignmentNo

                    });
                } else {

                    if ($scope.adjustmentdatalist.length > 0) {
                        angular.forEach($scope.adjustmentdatalist, function (value, key) {
                            if (value.AdjItemcode == $scope.Itemcode && value.AdjGrnno == $scope.Grnno) {
                                flag = true;
                                parent.failureMessage("Duplicate item not allowed with same GRN# ");
                                return;
                            }
                        });
                        if (!flag) {
                            $scope.adjustmentdatalist.push({
                                Itemid: $scope.itemid,
                                AdjItemcode: $scope.Itemcode,
                                AdjItemname: $scope.Itemname,
                                Brandname: $scope.Brandname,
                                AdjGrnno: $scope.Grnno,
                                AdjGrndate: $scope.Grndate,
                                AdjBatchno: $scope.Batchno,
                                AdjExpirydate: $scope.Expirydate,
                                AdjCbqty: $scope.Cbqty,
                                AdjCbrate: $scope.Cbrate,
                                AdjCbvalue: $scope.Cbvalue,
                                AdjQty: $scope.Adjqty,
                                AdjRate: $scope.Adjrate,
                                AdjValue: $scope.Adjvalue,
                                ItemTransactionId: $scope.ItemTransactionId,
                                ItemUom: $scope.ItemUom,
                                TaxAmount: $scope.TaxAmount,
                                ItemTaxStructureId: $scope.ItemTaxStructureId,
                                ItemDiscount: $scope.ItemDiscount,
                                ItemDiscountIn: $scope.ItemDiscountIn,
                                ItemReceiptId: $scope.ItemReceiptId,
                                ConsignmentNo: $scope.ConsignmentNo

                                //scope.ItemUom = data.d[0].ItemUom,
                                //scope.TaxAmount = data.d[0].TaxAmount,
                                //scope.ItemTaxStructureId = data.d[0].ItemTaxStructureId,
                                //scope.ItemDiscount = data.d[0].ItemDiscount,
                                //scope.ItemDiscountIn = data.d[0].ItemDiscountIn,
                                //scope.ItemReceiptId = data.d[0].ItemReceiptId,
                                //scope.ConsignmentNo = data.d[0].ConsignmentNo
                            });
                        }
                    }
                }
                if (flag == false) {
                    reset();
                }
            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.reset = function () {
            reset();
        }

        function reset() {

            $scope.Itemcode = "";
            $scope.Itemname = "";
            $scope.Brandname = "";
            $scope.Grnno = "";
            $scope.Grndate = "";
            $scope.Batchno = "";
            $scope.Expirydate = "";
            $scope.Cbqty = "";
            $scope.Cbrate = "";
            $scope.Cbvalue = "";
            $scope.Adjqty = "";
            $scope.Adjrate = "";
            $scope.Adjvalue = "";

        }
        function getReason() {
            var promise = inventoryTransactionService.getReasons($scope.PropertyID, 5, $scope.ModifiedDate);
            promise.then(function (data, status) {
                $scope.reasonList = data.Collection;
            }, function (errorPl) {
                parent.failureMessage("Some Error in Getting Records." + errorPl.responseText);
            });
        };
        function getStore() {
            var promiseGet = storeService.getAll($scope.PropertyID, 1);
            promiseGet.then(function (storedata) {
                //$scope.$apply(function () {

                $scope.storeList = storedata;
                //});
                //$scope.DateFormat = storedata.d.DateFormat;
            },
                function (errorPl) {
                    msg("Error in getting stores " + errorPl);
                });
        };

        $scope.modelOptions = {
            debounce: {
                default: 500,
                blur: 250
            },
            getterSetter: true
        };

        $scope.getvalue = function () {

            if (parseFloat($scope.Adjqty) <= parseFloat($scope.Cbqty)) {
                $scope.Adjvalue = parseFloat($scope.Adjqty) * parseFloat($scope.Adjrate);
            } else {
                $scope.Adjqty = "";
                $scope.Adjvalue = "0"; // parseFloat($scope.Adjqty) * parseFloat($scope.Adjrate);
            }
        };
        $scope.getqty = function () {

            if (parseFloat($scope.Adjvalue) <= parseFloat($scope.Cbvalue)) {
                $scope.Adjqty = parseFloat($scope.Adjvalue) / parseFloat($scope.Adjrate);
            } else {
                $scope.Adjvalue = "";
                $scope.Adjqty = "0"; // parseFloat($scope.Adjvalue) / parseFloat($scope.Adjrate);
            }
        };
        $scope.bindItem = function () {
            inventoryTransactionService.getAutoSuggests($scope.storeListdata, $scope.Itemname);
        };
        $scope.bindGrn = function () {
            inventoryTransactionService.getAutoSuggestsGrn($scope.storeListdata, $scope.brandid, $scope.itemid, $scope.Grnno, $scope.DateFormat);
        };
        $scope.bindBatch = function () {
            inventoryTransactionService.getAutoSuggestsBatchNo($scope.storeListdata, $scope.itemid, $scope.Grnno, $scope.Batchno);
        };

        function getItemData() {

            var promiseGet = inventoryTransactionService.getdatalist($scope.storeListdata);

            promiseGet.then(function (itemdata) {

                $scope.itemList = itemdata.d;
            },
                function (errorPl) {
                    parent.failureMessage("Some Error in Getting Records." + errorPl.responseText);
                });
        };
        function getglobal() {

            //var promiseGet = inventoryTransactionService.getgloballist();

            //promiseGet.then(function (adjdata) {

            //    $scope.PropertyName = adjdata.d.PropertyName;
            //    //$scope.DateFormat = adjdata.d.DateFormat;
            //    $scope.Authorizedby = adjdata.d.LastUser;
            //},
            //    function (errorPl) {
            //        parent.failureMessage("Some Error in Getting Records." + errorPl.responseText);
            //    });
        };

        $scope.bindBrandid = function () {

            var promiseGet = inventoryTransactionService.getAutoSuggestsBrand($scope.itemid, $scope.Brandname);
        };
        $scope.validateDateFormat = function (varDate) {

            var status = inventoryTransactionService.validateDate(varDate);
            status.then(function (validStatus) {
                if (validStatus.d === true && (validStatus.d !== "" && validStatus.d != null)) {
                    return true;
                } else {
                    parent.failureMessage("Please enter valid date.");
                    return false;
                }
            });
        };

        $scope.Save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            var retVal = false;
            if ($scope.adjustmentdatalist.length === 0) {
                msg("Please add items for adjustment.");
                return;
            } else {
                angular.forEach($scope.adjustmentdatalist, function (value, key) {

                    if (value.Quantity === "0" || parseFloat(value.Quantity) === 0) {
                        msg("Adjustment Quantity should not be zero.");
                        retVal = true;
                        return;
                    }
                });
            }
            if (retVal) return;

            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.ModifiedDate = $scope.ModifiedDate;
            $scope.model.GRDate = $scope.ModifiedDate;
            $scope.model.InventoryTransactionItems = $scope.adjustmentdatalist;
            $scope.model.OperationType = 5;

            var promise = inventoryTransactionService.save($scope.model);
            promise.then(function (d) {
                resetall();
                msg("Adjustment Data successfully saved.", true);
            }, function (err) {
                msg(err.Message);
            });
        };
        $scope.resetall = function () {
            resetall();
        };
        function resetall() {


            $scope.model = {};
            $scope.model.ApprovedBy = $scope.ModifiedBy;
            $scope.Adjustmentno = "";
            $scope.adjustmentdate = "";
            $scope.reasonListdata = "";
            $scope.storeListdata = "";
            //$scope.authorizedby = "";
            $scope.adjRemarks = "";
            $scope.adjustmentdatalist = [];

            reset();

            //if ($scope.adjustmentdatalist.length > 0) {
            //    angular.forEach($scope.adjustmentdatalist, function (value, key) {
            //        $scope.adjustmentdatalist.splice(key, 1);
            //    });
            //}
            getglobal();
        }

        $scope.changeAdjustmentDate = function () {
            $scope.adjustmentdatalist = [];
        };

        $scope.checkAdjustmentNo = function () {
            if (!$scope.model.ReferenceNo) return;
            var promise = inventoryTransactionService.getByReference($scope.PropertyID, 5, $scope.model.ReferenceNo);
            promise.then(function (d) {

                if (d.Collection.length > 0) {
                    msg("Adjustment no Already Exists!");
                    $scope.model.ReferenceNo = "";
                }
            }, function (err) {
                if (angular.isUndefined($scope.model.ReferenceNo)) {
                    msg("Adjustment no should not be null!");
                } else {
                    msg(err);
                }
                $scope.model.ReferenceNo = "";

            });

        };
        var datass;
        var check;

        $("#searchItem").autocomplete({
            source: function (request, response) {
                var promise = inventoryTransactionService.getItems($scope.PropertyID, request.term);
                promise.then(function (data, status) {
                    datass = data.Collection;
                    response($.map(data.Collection, function (item) {
                        return {
                            label: item.Name,
                            val: item.Id
                        };
                    }));
                });
            },
            select: function (e, ui) {

                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        var promiseGet = inventoryTransactionService.GetItemById($scope.PropertyID, ui.item.val);
                        promiseGet.then(function (data, status) {

                            data.Data.InventoryItemId = data.Data.Id;
                            data.Data.InventoryItemName = data.Data.Name;
                            $scope.adjustmentdatalist.push(data.Data);
                            $scope.model.Search = "";
                        },
                        function (error, status) {
                            msg(error.Message);
                        });
                    }
                }
            },
            change: function (e, ui) {

                var dd = e.target.value;
                var element = angular.element($("#NewReceipt"));
                var scope = element.scope();
                if (datass) {

                    if (datass.length > 0) {
                        for (var i = 0; i < datass.length; i++) {
                            if (check === false) {
                                if (dd === datass[i].ItemName) {
                                    check = true;
                                    scope.getitemFromStore(datass[i].ItemId);
                                }
                            }
                        }
                        if (check === false) {
                            msg(dd + " Item Not Exist!");
                        }
                    } else {
                        msg(dd + " Item Not Exist!");
                    }
                }
                $("#searchItem").val("");
                $("#searchItem").focus();
            },
            minLength: 1
        });
        resetall();

    }
]);
