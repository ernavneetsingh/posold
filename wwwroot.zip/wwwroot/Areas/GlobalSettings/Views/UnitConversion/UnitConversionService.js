﻿
'use strict';


(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getData = function (propertyId, active) {
            var url = apiPath + "GlobalSetting/UnitConversion/all/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllUnitType = function () {
            var url = apiPath + 'ReferenceConstant/UnitType/all/';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getSelectUnit = function (propertyID, unitTypeId) {
            var url = apiPath + 'GlobalSetting/UnitOfMeasurement/all/' + propertyID + "/" + unitTypeId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (models) {
            
            var url = apiPath + 'GlobalSetting/UnitConversion/save';
            var deferred = $q.defer();
            $http({
                dataType: 'json',
                method: 'POST',
                url: url,
                data: JSON.stringify(models),
                headers: {
                    "Content-Type": "application/json"
                }
                //headers: { 'duxtechApiKey': accessToken },
                //contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var remove = function (id) {
            var url = apiPath + 'GlobalSetting/UnitConversion/delete/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        return {

            getData: getData,
            remove: remove,
            getAllUnitType: getAllUnitType,
            getSelectUnit: getSelectUnit,
            save: save
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
