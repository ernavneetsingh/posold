﻿
app.controller('AgeingController', [
    '$scope', '$filter', '$cookies', 'ageingService', 'localStorageService', function (
        $scope, $filter, $cookies, ageingService, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.reset = function () {

            $scope.model = [];

            $scope.ApplicableFromString = $scope.ModifiedDate;
            $scope.ModuleId = "4";
            $scope.ModuleAgingChange($scope.ModuleId);
            $scope.currentLower = 0;
        };
        function getAging(moduleid) {
        }
        $scope.ModuleAgingChange = function () {
            getAging($scope.ModuleId);
            var promiseGet = ageingService.getagingdata($scope.PropertyID, $scope.ModuleId);
            promiseGet.then(function (agingdata) {

                $scope.model = agingdata.Collection;
                $scope.getNewPeriodRange();

                $scope.lastuserdate = !agingdata.Collection || agingdata.Collection.length < 1 ? "" : agingdata.Collection[0].ModifiedDate;
                $scope.lastuser = !agingdata.Collection || agingdata.Collection.length < 1 ? "" : agingdata.Collection[0].ModifiedBy;
                $scope.ApplicableFromString = !agingdata.Collection || agingdata.Collection.length < 1 ? "" : agingdata.Collection[0].ApplicableFromString;

            });
        }

        $scope.getNewPeriodRange = function (n, order) {
            var l = 0, o = order || 0;
            $scope.newModel = n || { PeriodDisplay: '', Order: ++o };
            if ($scope.model && $scope.model.length > 0) {
                var last = $scope.model[$scope.model.length - 1].PeriodRange.split('-');
                if (last.length > 1) {
                    l = 1 + parseInt(last[1]);
                }
            }
            $scope.currentLower = l;
            $scope.newModel.PeriodRange = l + '-';
        };
        $scope.addItem = function (form) {
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            if ($scope.newModel.PeriodDisplay.length < 1) {
                msg('Please fill Period.')
                return;
            }
            var pr = $scope.newModel.PeriodRange.split('-');
            if (pr.length < 2 || pr[1].length < 1) {
                msg('Please fill upper limit in days range.')
                return;
            }
            if ($scope.currentLower !== parseInt(pr[0])) {
                msg('Please do not change lower limit.')
                return;
            }
            if (parseInt(pr[1]) <= parseInt(pr[0])) {
                msg('Uper limit should be greater than lower.')
                return;
            }
            if (!$scope.model) $scope.model = [];
            $scope.model.push({
                Id: "",
                ModuleId: $scope.ModuleId,
                ApplicableFromString: $scope.ApplicableFromString,
                PeriodRange: $scope.newModel.PeriodRange,
                PeriodDisplay: $scope.newModel.PeriodDisplay,
                Order: $scope.newModel.Order
            });
            $scope.getNewPeriodRange(null, $scope.newModel.Order);
        };
        $scope.deleteItem = function (form) {
            $scope.getNewPeriodRange($scope.model.pop());
        };
        $scope.SaveAgingData = function (form) {

            var st = $scope[form].$valid;
            if (!st) {
                $scope.ShowErrorMessage = true;
                return;
            }
            var agingObj = new Object();
            agingObj.PropertyID = $scope.PropertyID;
            agingObj.ModifiedBy = $scope.ModifiedBy;
            agingObj.ModifiedDate = $scope.ModifiedDate;
            agingObj.ApplicableFromString = $scope.ApplicableFromString;
            agingObj.ModuleId = $scope.ModuleId;
            agingObj.AgeingList = $scope.model;

            ageingService.save(agingObj)
                .then(function (d) {
                    msg(d.Message, d.Status);
                });
        };

        $scope.reset();

    }
]);

app.directive('ageingDays', [
  function () {
      return {
          restrict: 'A',
          require: 'ngModel',
          link: function (scope, element, attr, ngModelCtrl) {
              var pattern = /[^0-9-]/g; // Matches characters that aren't `0-9` or `-`
              function clean(string) {
                  return string.replace(/[^0-9]/g, "");
              }
              function fromUser(text) {

                  var transformedInput = text.replace(pattern, '');
                  var pos = transformedInput.indexOf("-");
                  var result;
                  if (pos !== -1) {
                      var part1 = transformedInput.substr(0, pos);
                      var part2 = transformedInput.substr(pos + 1);
                      result = clean(part1) + "-" + clean(part2);
                  } else {
                      result = transformedInput.replace(/[^0-9-]/g, "");
                  }
                  ngModelCtrl.$setViewValue(result);
                  ngModelCtrl.$render();
                  return transformedInput;
              }
              ngModelCtrl.$parsers.push(fromUser);
          }
      };
  }
]);
