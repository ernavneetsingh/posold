// JavaScript Document


$(document).ready(function () {

    $("select").change(function () {
        $(this).find("option:selected").each(function () {
            var optionValue = $(this).attr("value");
            if (optionValue) {
                $(".res-tab-content-cheque").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else {
                $(".res-tab-content-cheque").hide();
            }
        });
    }).change();
});

$(document).ready(function () {
    $("#contact2").click(function () {
        $("#contectcontent").slideToggle();
        $("#advancecontent").hide();
        $("#discountcontent").hide();
        $("#groupinformation").hide();
        $("#arrangementamenities").hide();
        $("#extrachargenew").hide();
    });
});
$(document).ready(function () {
    $("#advancetab").click(function () {
        $("#advancecontent").slideToggle();

        $("#contectcontent").hide();
        $("#discountcontent").hide();
        $("#groupinformation").hide();
        $("#arrangementamenities").hide();
        $("#extrachargenew").hide();
    });
});

$(document).ready(function () {
    $("#discount").click(function () {
        $("#discountcontent").slideToggle();



        $("#contectcontent").hide();
        $("#advancecontent").hide();
        $("#groupinformation").hide();
        $("#arrangementamenities").hide();
        $("#extrachargenew").hide();
    });
});

$(document).ready(function () {
    $("#groupinfo").click(function () {
        $("#groupinformation").slideToggle();


        $("#contectcontent").hide();
        $("#advancecontent").hide();
        $("#discountcontent").hide();
        $("#arrangementamenities").hide();
        $("#extrachargenew").hide();
    });
});
$(document).ready(function () {
    $("#arrangmenttab").click(function () {
        $("#arrangementamenities").slideToggle();

        $("#contectcontent").hide();
        $("#advancecontent").hide();
        $("#discountcontent").hide();
        $("#groupinformation").hide();
        $("#extrachargenew").hide();
    });
});
$(document).ready(function () {
    $("#extracharge").click(function () {
        $("#extrachargenew").slideToggle();

        $("#contectcontent").hide();
        $("#advancecontent").hide();
        $("#discountcontent").hide();
        $("#groupinformation").hide();
        $("#arrangementamenities").hide();
    });
});

//--------------------------- PopUP Start --------------------- //

$(document).ready(function () {
    $("#guestinfonew2").click(function () {
        $("#guestinformationpopup").slideToggle();
        $("#passportvissapopup").hide();
        $("#pickupdroppopup").hide();
        $("#likedislikepopup").hide();
        $("#vehicleinfopopup").hide();
        $("#documentcenterpopup").hide();
        $("#workdetailpopup").hide();
    });
});

$(document).ready(function () {
    $("#passportvisa").click(function () {
        $("#passportvissapopup").slideToggle();
        $("#guestinformationpopup").hide();
        $("#pickupdroppopup").hide();
        $("#likedislikepopup").hide();
        $("#vehicleinfopopup").hide();
        $("#documentcenterpopup").hide();
        $("#workdetailpopup").hide();
    });
});

$(document).ready(function () {
    $("#pickupdrop").click(function () {
        $("#pickupdroppopup").slideToggle();
        $("#guestinformationpopup").hide();
        $("#passportvissapopup").hide();
        $("#likedislikepopup").hide();
        $("#vehicleinfopopup").hide();
        $("#documentcenterpopup").hide();
        $("#workdetailpopup").hide();
    });
});


$(document).ready(function () {
    $("#likedislike").click(function () {
        $("#likedislikepopup").slideToggle();

        $("#guestinformationpopup").hide();
        $("#passportvissapopup").hide();
        $("#pickupdroppopup").hide();
        $("#vehicleinfopopup").hide();
        $("#documentcenterpopup").hide();
        $("#workdetailpopup").hide();

    });
});

$(document).ready(function () {
    $("#vehicleinfo").click(function () {
        $("#vehicleinfopopup").slideToggle();
        $("#guestinformationpopup").hide();
        $("#passportvissapopup").hide();
        $("#pickupdroppopup").hide();
        $("#likedislikepopup").hide();
        $("#documentcenterpopup").hide();
        $("#workdetailpopup").hide();

    });
});
$(document).ready(function () {
    $("#documentcenter").click(function () {
        $("#documentcenterpopup").slideToggle();
        $("#guestinformationpopup").hide();
        $("#passportvissapopup").hide();
        $("#pickupdroppopup").hide();
        $("#likedislikepopup").hide();
        $("#vehicleinfopopup").hide();
        $("#workdetailpopup").hide();
    });

    $("#workdetail").click(function () {
        $("#workdetailpopup").slideToggle();
        $("#guestinformationpopup").hide();
        $("#passportvissapopup").hide();
        $("#pickupdroppopup").hide();
        $("#likedislikepopup").hide();
        $("#vehicleinfopopup").hide();
        $("#documentcenter").hide();
        
    });

});
//--------------------------- PopUP End --------------------- //


$(document).ready(function () {
    $("#detailinformationnew2").click(function () {
        $("#roomavailabilitynew").show();
        $("#detailinformationnew2").hide();
        $("#detailinformationnew24").show();


    });
});

$(document).ready(function () {
    $("#detailinformationnew24").click(function () {
        $("#roomavailabilitynew").hide();
        $("#detailinformationnew24").hide();
        $("#detailinformationnew2").show();


    });
});

$(document).ready(function () {
    $("#suitroomdown1").click(function () {

        $("#suitroomnew").show();
        $("#suitroomdown1").hide();
        $("#suitroomup1").show();
    });
});

$(document).ready(function () {
    $("#suitroomup1").click(function () {
        $("#suitroomnew").hide();
        $("#suitroomup1").hide();
        $("#suitroomdown1").show();


    });
});


$(document).ready(function () {
    $("#diamondroomdown1").click(function () {
        $("#diamondroomnew").show();
        $("#diamondroomdown1").hide();
        $("#diamondroomup1").show();


    });
});

$(document).ready(function () {
    $("#diamondroomup1").click(function () {
        $("#diamondroomnew").hide();
        $("#diamondroomup1").hide();
        $("#diamondroomdown1").show();


    });
});

//------------------------------  Room Master New -------------------------- //
$(document).ready(function () {
    $("#weekdaysdefinitionnew").click(function () {
        $("#weekdays").slideToggle();


    });
});

$(document).ready(function () {
    $("#superdeluxenewtab1").click(function () {
        $("#superdeluxenewcontent1").show();
        $("#deluxenewcontent1").hide();
        $("#suitnewcontent1").hide();

        $("#superdeluxenewtab1").addClass("tabactivenew1");
        $("#deluxenewtab2").removeClass("tabactivenew1");
        $("#suitnewtab2").removeClass("tabactivenew1");


    });

});
$(document).ready(function () {
    $("#deluxenewtab2").click(function () {
        $("#deluxenewcontent1").show();
        $("#superdeluxenewcontent1").hide();
        $("#suitnewcontent1").hide();

        $("#deluxenewtab2").addClass("tabactivenew1");
        $("#suitnewtab2").removeClass("tabactivenew1");
        $("#superdeluxenewtab1").removeClass("tabactivenew1");
    });

});

$(document).ready(function () {
    $("#suitnewtab2").click(function () {
        $("#suitnewcontent1").show();
        $("#superdeluxenewcontent1").hide();
        $("#deluxenewcontent1").hide();

        $("#suitnewtab2").addClass("tabactivenew1");
        $("#deluxenewtab2").removeClass("tabactivenew1");
        $("#superdeluxenewtab1").removeClass("tabactivenew1");

    });

});

//------------------------------  Room Master Meal Type -------------------------- //

$(document).ready(function () {
    $("#cpmealtab").click(function () {
        $("#cpmealplancontent").show();

        $("#mapmealcontent").hide();
        $("#epmealplancontent").hide();
        $("#apmealcontent").hide();

        $("#cpmealtab").addClass("tabactivemealnew");
        $("#mapmealtab4").removeClass("tabactivemealnew");
        $("#apmealtab3").removeClass("tabactivemealnew");
        $("#epmealtab2").removeClass("tabactivemealnew");

    });
});

$(document).ready(function () {
    $("#epmealtab2").click(function () {
        $("#epmealplancontent").show();

        $("#cpmealplancontent").hide();
        $("#apmealcontent").hide();
        $("#mapmealcontent").hide();


        $("#epmealtab2").addClass("tabactivemealnew");

        $("#mapmealtab4").removeClass("tabactivemealnew");
        $("#apmealtab3").removeClass("tabactivemealnew");
        $("#cpmealtab").removeClass("tabactivemealnew");


    });
});

$(document).ready(function () {
    $("#apmealtab3").click(function () {
        $("#apmealcontent").show();

        $("#cpmealplancontent").hide();
        $("#epmealplancontent").hide();
        $("#mapmealcontent").hide();


        $("#apmealtab3").addClass("tabactivemealnew");

        $("#mapmealtab4").removeClass("tabactivemealnew");
        $("#epmealtab2").removeClass("tabactivemealnew");
        $("#cpmealtab").removeClass("tabactivemealnew");

    });
});

$(document).ready(function () {
    $("#mapmealtab4").click(function () {
        $("#mapmealcontent").show();

        $("#cpmealplancontent").hide();
        $("#epmealplancontent").hide();
        $("#apmealcontent").hide();


        $("#mapmealtab4").addClass("tabactivemealnew");
        $("#apmealtab3").removeClass("tabactivemealnew");
        $("#epmealtab2").removeClass("tabactivemealnew");
        $("#cpmealtab").removeClass("tabactivemealnew");


    });
});



$(document).ready(function () {
    $("#pickuptabnew").click(function () {
        $("#pickupcontentnew").show();
        $("#dropcontentnew").hide();

    });
});
$(document).ready(function () {
    $("#droptabnew").click(function () {

        $("#dropcontentnew").show();
        $("#pickupcontentnew").hide();
    });

});

//--------------------------- Settelment Start --------------------- //

$(document).ready(function () {
    $("#cashbut").click(function () {
        $("#cashtab").show();

        $("#companytab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#cashbut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");

    });

});


$(document).ready(function () {
    $("#cardbut").click(function () {
        $("#cardtab").show();

        $("#cashtab").hide();
        $("#companytab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#cardbut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");

        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#compbut").click(function () {
        $("#companytab").show();


        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#compbut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#chequebut").click(function () {
        $("#chequetab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#chequebut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#mealplanbut").click(function () {
        $("#mealplantab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#mealplanbut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#roombut").click(function () {
        $("#roomtab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#roombut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#complibut").click(function () {
        $("#complimentrytab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#complibut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#voidbut").click(function () {
        $("#voidtab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#voidbut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});
$(document).ready(function () {
    $("#couponbut").click(function () {
        $("#coupontab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#nonchargeabletab").hide();
        $("#feoreignexchangeetab").hide();

        $("#couponbut").addClass("set-button-new-add");

        $("#nonchargebut").removeClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");


    });

});

$(document).ready(function () {
    $("#nonchargebut").click(function () {
        $("#nonchargeabletab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#feoreignexchangeetab").hide();


        $("#nonchargebut").addClass("set-button-new-add");
        $("#foreignbut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");
    });

});

$(document).ready(function () {
    $("#foreignbut").click(function () {
        $("#feoreignexchangeetab").show();

        $("#companytab").hide();
        $("#cashtab").hide();
        $("#cardtab").hide();
        $("#chequetab").hide();
        $("#mealplantab").hide();
        $("#roomtab").hide();
        $("#complimentrytab").hide();
        $("#voidtab").hide();
        $("#coupontab").hide();
        $("#nonchargeabletab").hide();


        $("#foreignbut").addClass("set-button-new-add");
        $("#nonchargebut").removeClass("set-button-new-add");
        $("#couponbut").removeClass("set-button-new-add");
        $("#voidbut").removeClass("set-button-new-add");
        $("#complibut").removeClass("set-button-new-add");
        $("#roombut").removeClass("set-button-new-add");
        $("#mealplanbut").removeClass("set-button-new-add");
        $("#chequebut").removeClass("set-button-new-add");
        $("#compbut").removeClass("set-button-new-add");
        $("#cardbut").removeClass("set-button-new-add");
        $("#cashbut").removeClass("set-button-new-add");

    });

});


//--------------------------- Settelment End --------------------- //

$(document).ready(function () {
    $("#discountid").click(function () {
        $("#selectself").show();
        $("#manualcontent").hide();

    });
});
$(document).ready(function () {
    $("#manualnew").click(function () {
        $("#manualcontent").show();
        $("#selectself").hide();
    });
});

//-----------------------------------    Check In Start ---------------------------//
$(function () {

    

    //$('#guestinfoshow').click(function () {
    //    $('#guestinfo').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#passportinfo, #pickupdropinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox,#historydetailsbox,  #groupinfo, #likedislike, #vehiclenumber, #extrachargesnew,#arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#passportvisashow').click(function () {
    //    $('#passportinfo').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");

    //    $('#guestinfo, #pickupdropinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox, #groupinfo,#historydetailsbox, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#pickdropinfoshow').click(function () {
    //    $('#pickupdropinfo').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox, #groupinfo,#historydetailsbox, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#advanceshow').click(function () {
    //    $('#advance').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo, #discount,#localcontactbox, #extracharges,#visitdetailsbox,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#discountshow').click(function () {
    //    $('#discount').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox, #extracharges,#visitdetailsbox,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#extrachargesshow').click(function () {
    //    $('#extracharges').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox,#visitdetailsbox, #discount,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#groupinformationshow').click(function () {
    //    $('#groupinfo').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox,#visitdetailsbox,#historydetailsbox, #discount, #extracharges, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#likedislikeshow').click(function () {
    //    $('#likedislike').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox, #advance,#visitdetailsbox,#historydetailsbox, #discount, #extracharges, #groupinfo, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#vehicleinformationshow').click(function () {
    //    $('#vehiclenumber').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
    //});

    //$('#arrangementsamenitiesshow').click(function () {
    //    $('#arrangements').slideToggle();
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike, #extrachargesnew,#vehiclenumber,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    //});

    //$('#documentcentershow').click(function () {
    //    $('#documentcenter').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo,#localcontactbox,#visitdetailsbox, #pickupdropinfo,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew,#arrangements,#diplomat').css('display', 'none');
    //});

    //$('#workdetailshow').click(function () {
    //    $('#workdetail').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo,#localcontactbox,#visitdetailsbox, #pickupdropinfo,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew,#arrangements,#diplomat').css('display', 'none');
    //});

    //$('#localcontactshow').click(function () {
    //    $('#localcontactbox').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    //});
    //$('#visitdetails').click(function () {
    //    $('#visitdetailsbox').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#historydetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    //});
    //$('#historyshow').click(function () {
    //    $('#historydetailsbox').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

    //});
    //$('#extraamount').click(function () {
    //    $('#extrachargesnew').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#documentcenter,#historydetailsbox,#diplomat,#workdetail').css('display', 'none');

    //});
    //$('#diplomatshow').click(function () {
    //    $('#diplomat').slideToggle('slow');
    //    $("li a").removeClass("visited")
    //    $(this).addClass("visited");
    //    $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#historydetailsbox,#workdetail').css('display', 'none');

    //});

    //$('.navigation ul li a').click(function () {
    //    $('.navigation ul li a').removeClass('selectedli')
    //    $(this).addClass('selectedli');
    //});
});

//-----------------------------------    Check In End ---------------------------//


//----------------------------   Change Rate Popup --------------------------//
$(function () {

    $('#bd').click(function (bd) {
        if (bd.target.checked) {
            $('#billingdetails').show('slow');
            $('#contdetails').hide('slow');
            $('#partnerdetails').hide('slow');

            $('#condet').removeAttr("checked");
            $('#pdetails').removeAttr("checked");
            $(':checkbox').removeAttr("checked");

        }
        else {
            $('#billingdetails').hide('slow');

        }
    });

    $('#condet').click(function (condet) {
        if (condet.target.checked) {
            $('#contdetails').show('slow');
            $('#billingdetails').hide('slow');
            $('#partnerdetails').hide('slow');



            $('#bd').removeAttr("checked");
            $('#pdetails').removeAttr("checked");

        }
        else {
            $('#contactdetails').hide('slow');

        }
    });

    $('#pdetails').click(function (pdetails) {
        if (pdetails.target.checked) {
            $('#contdetails').hide('slow');
            $('#billingdetails').hide('slow');
            $('#partnerdetails').show('slow');



            $('#bd').removeAttr("checked");
            $('#condet').removeAttr("checked");

        }
        else {
            $('#partnerdetails').hide('slow');

        }
    });
});

$(document).ready(function () {
    $("#walkingcustomer").click(function () {

        $("#showcustomerdata").css("right", "0px");
        $(".sidebarmenu-new20").css("position", "absolute");
        $(".sidebarmenu-new20").css("left", "0px");
        $(".sidebarmenu-new20").css("top", "0px");
    });
});

//-----------------------------16- March- 03  For customer Popup------------------------------------ //
$(document).ready(function () {
    $("#actionid").click(function () {
        $('#actionlist').slideToggle('slow');
    });

});
