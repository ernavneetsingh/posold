﻿
app.controller("MarketSegmentController",
[
    "$scope", "MarketSegmentService", "$cookies", "localStorageService", "$filter", function ($scope, marketSegmentService, $cookies, localStorageService, $filter) {

        $scope.UserName = $cookies.get('UserName');
        //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        //$scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.Model = {
            Id: "",
            Code: "",
            Name: "",
            ShortName: "",
            Description: "",
            IsActive: true,
            IsBanquet: false,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName,
            DateFormat: $scope.DateFormat
        };

        $scope.IsReadonly = false;

        $scope.marketSegmentModel = {};
        $scope.Save = "Save";
        $scope.marketSegmentData = [];
        $scope.marketSegmentDetails = [];

        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";

        var sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        getData($scope, marketSegmentService, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, marketSegmentService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, marketSegmentService, localStorageService);
        };

        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, marketSegmentService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, marketSegmentService, localStorageService);
        }

        $scope.isExist = function () {

            var promiseGet = marketSegmentService.getCodeExistMarketSegment($scope.Model.Code, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        msg(data.Message);
                        $scope.Model.Code = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });

        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Model = { IsBanquet: false, IsActive: true };

            //$scope.Model.Id = "";
            //$scope.Model.Name = "";
            //$scope.Model.ShortName = "";
            //$scope.Model.Code = "";
            //$scope.Model.Description = "";
            //$scope.Model.ApplicableFrom = "";

            //$scope.IsActive = true;
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            $scope.search();
        };

        $scope.saveMarketSegmentData = function (form) {

            if ($scope[form].$valid) {

                //var bsObj = new Object();

                var bsObj = $scope.Model;
                //bsObj.Id = $scope.Model.Id;
                //bsObj.Name = $scope.Model.Name;
                //bsObj.Code = $scope.Model.Code;
                //bsObj.ShortName = $scope.Model.ShortName;
                //bsObj.ApplicableFrom = $scope.Model.ApplicableFrom;
                //bsObj.IsActive = $scope.Model.IsActive;
                bsObj.PropertyId = $scope.PropertyID;
                bsObj.ModifiedBy = $scope.ModifiedBy;
                bsObj.DateFormat = $scope.DateFormat;

                var promiseGet = marketSegmentService.saveMarketSegment(bsObj);
                promiseGet.then(function (data, status) {
                    getData($scope, marketSegmentService, localStorageService);
                    $scope.reset();
                    msg(data.Message, data.Status);
                },
                function (error, status) { msg(error.Message); });
            } else {
                $scope.ShowErrorMessage = true;
            }

        };
        $scope.updateMarketSegmentData = function (bsModel) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var promiseGet = marketSegmentService.updateIsActiveMarketSegment(bsModel.Id, bsModel.IsActive, $scope.PropertyID, $scope.UserName);
            promiseGet.then(function (data, status) {
                getData($scope, marketSegmentService, localStorageService);
                msg(data.Message, data.Status);
            }, function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.removeRow = function (bsModel) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Market Segment?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = marketSegmentService.deleteMarketSegment(bsModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {

                                getData($scope, marketSegmentService, localStorageService);
                                msg("Market Segment deleted Successfully ", d.Status);
                            }, function (error) {

                                msg("Already Used");
                            });
                            $.fancybox.close();
                        });
                }
            });
            scrollPageOnTop();
        };
        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.Model = record;
            //$scope.Model.Id = record.Id;
            //$scope.Model.Name = record.Name;
            //$scope.Model.ShortName = record.ShortName;
            //$scope.Model.Code = record.Code;
            //$scope.Model.IsActive = record.IsActive;
            $scope.Model.ApplicableFrom = $filter('date')(record.ApplicableFrom, $scope.DateFormat);;

            $scope.IsReadonly = true;
            $scope.Save = "Update";
            msg('');
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getMarketSegment(options)
    .then(function (totalItems) {

        $scope.totalItems = totalItems;
        //$scope.data = $scope.totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
