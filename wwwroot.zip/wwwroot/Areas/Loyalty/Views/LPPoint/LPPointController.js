﻿
app.controller("controller",
[
    '$scope', 'LPPointService', '$cookies', '$filter', 'localStorageService', '$timeout', '$http', '$q',
    function ($scope, service, $cookies, $filter, localStorageService, $timeout, $http, $q) {

        initCommon($scope, $http, $q, localStorageService, $cookies);
        $scope.keys=localStorageService.get('ActionKeys');
        $scope.ActionMode="";
        $scope.getAllLPCard = function () {
            $scope.ActionMode=""; 
            service.getAllLPCard($scope.PropertyID)
                .then(function (s) {
                    $scope.LPCards = s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };
        $scope.getAllDiscountType = function () {
            service.getAllDiscountType()
                .then(function (s) {
                    $scope.DiscountTypes = s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };
        $scope.getAll = function () {

            var sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder == null) {
                sortKeyOrder = {
                    key: "Name",
                    order: "ASC"
                };
            }

            var searchfor = localStorageService.get("searchfor");
            $scope.sortKeyOrder = sortKeyOrder;
            var options = {
                propertyId: $scope.PropertyID,
                currentPage: $scope.currentPage,
                recordsPerPage: $scope.recordsPerPage,
                sortKey: sortKeyOrder.key,
                sortOrder: sortKeyOrder.order,
                searchfor: searchfor || ''
            };
            $scope.showLoader = true;
            service.getAll(options)
                  .then(function (s) {
                      $scope.data = s.Collection;
                      $scope.totalItems = s.RecordCount;
                      $scope.showLoader = false;
                  }, function () {
                      parent.failureMessage("The request failed. Unable to connect to the remote server.");
                  });

        };

        $scope.save = function (model, form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            //if (!model.MenuGroupTypes||model.MenuGroupTypes.length<1) {
            //    $scope.ShowErrorMessage = true;
            //    msg('Please select Applicable Groups.');
            //    return;
            //}
            if (!model.RevenueHeads||model.RevenueHeads.length<1) {
                $scope.ShowErrorMessage = true;
                msg('Please select Applicable RevenueHeads.');
                return;
            }
        
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;
            model.LPCardId = $scope.LPCardId;
            service.save(model)
                .then(function (result) {

                    if (result.Status == true) {
                        msg(result.Message, true);
                    }
                    $scope.reset();
                }, function (error) {
                    msg(error.Message);
                });
        }
        $scope.fillRecord = function (record) {
            $scope.ActionMode="Edit"; 
            if(!record) {
                $scope.model = {MenuGroupTypes:[],RevenueHeads:[]};
                return;
            }
            $scope.model = record;
            $scope.LPCardId = record.LPCardId;
            $scope.IsEdit = true;
            msg('');
        };
        $scope.reset = function () {
            $scope.ActionMode=""; 
            $scope.model = {MenuGroupTypes:[],RevenueHeads:[]};
            $scope.IsEdit = false;
            $scope.search();
            $scope.LPPointDay = {};
            $scope.LPCardId = '';
        };

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            $scope.getAll();
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            $scope.getAll();
        };
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            $scope.getAll();
        }

        $scope.changeLPCard = function (LPCardId) {
            if(!$scope.data)return;
            if(!LPCardId)return;

            var card=$scope.data.find(x=>x.LPCardId==LPCardId);

            if(!card) {
                $scope.model = {MenuGroupTypes:[],RevenueHeads:[]};
                return;
            }
            $scope.model = record;
            $scope.LPCardId = record.LPCardId;
            $scope.IsEdit = true;
            msg('');

            //$scope.fillRecord(card);
        };
        $scope.pickFormat = function () {
            $scope.model.CardFormat = $scope.model.f1 + $scope.model.f2 + $scope.model.f3;
        }
        $scope.MasterSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
        $scope.getAllMenuGroupType = function () {
            service.getAllMenuGroupType()
                .then(function (s) {
                    $scope.MenuGroupTypes = s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };
        $scope.getAllRevenueHeads= function () {
            service.getAllRevenueHeads($scope.PropertyID,1)
                .then(function (s) {
                    $scope.RevenueHeads = s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };
        $scope.getAllWeekDays = function () {
            service.getAllWeekDays($scope.PropertyID)
                .then(function (s) {
                    $scope.WeekDaysList = s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        }
        $scope.fillRecordDay = function (record) {

            $scope.LPPointDay = record;
        };
        $scope.addLPPointDay = function (record,form) {
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessageB = true;
                return;
            }
            if (!$scope.model.LPPointDays) $scope.model.LPPointDays = [];
            $scope.model.LPPointDays = $scope.model.LPPointDays.filter(x=>x.WeekDaysId!=record.WeekDaysId);
            //$scope.model.LPPointDays.push(angular.copy(record));
            var w = $scope.WeekDaysList.find(x=>x.Id===record.WeekDaysId);
            var d = angular.extend({},record,{WeekDaysName:w.Name});
            $scope.model.LPPointDays.push(d);
        };
        $scope.removeLPPointDay = function (record) {
            
            if (!$scope.model.LPPointDays) return;
            $scope.model.LPPointDays = $scope.model.LPPointDays.filter(x=>x.WeekDaysId!=record.WeekDaysId);
        };

        $scope.addLPRedemptionTime = function (record,form) {
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessageR = true;
                return;
            }
            if (!$scope.model.LPRedemptionTimes) $scope.model.LPRedemptionTimes = [];
            $scope.model.LPRedemptionTimes = $scope.model.LPRedemptionTimes.filter(x=>x.RedeemHours!=record.RedeemHours);
            $scope.model.LPRedemptionTimes.push(angular.copy(record));
        };
        $scope.removeLPRedemptionTime = function (record) {
            
            if (!$scope.model.LPRedemptionTimes) return;
            $scope.model.LPRedemptionTimes = $scope.model.LPRedemptionTimes.filter(x=>x.RedeemHours!=record.RedeemHours);
        };
        $scope.fillRecordTime= function (record) {

            $scope.LPRedemptionTime = record;
        };
    
        $scope.getAllMenuGroupType();
        $scope.getAllRevenueHeads();
        $scope.getAllLPCard();
        $scope.getAllDiscountType();
        $scope.getAllWeekDays();
        $scope.reset();

    }
]);
