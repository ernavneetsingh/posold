﻿
app.service('DocumentTypeService', function ($http, $q) {

    this.getDocumentForList = function () {
        return httpCaller(apiPath + 'ReferenceConstant/DocumentFor/All', $http, $q);
    };
    this.getAll = function (options) {
        return httpCaller(apiPath + "GlobalSetting/DocumentType/GetAll", $http, $q, options);
    }

    this.save = function (model) {
        return httpPoster(apiPath + "GlobalSetting/DocumentType/save", $http, $q, model);
    };
    this.delete = function (id) {
        return httpCaller(apiPath + "GlobalSetting/DocumentType/delete", $http, $q, { id: id });
    };
    this.changeStatus = function (model) {
        return httpPoster(apiPath + "GlobalSetting/DocumentType/status", $http, $q, model);
    };

});
