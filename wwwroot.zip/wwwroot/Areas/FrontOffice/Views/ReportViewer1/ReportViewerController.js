﻿
app.controller('Controller', [
    '$scope', '$window', '$http', '$q', 'localStorageService', '$filter', '$timeout', '$sce','$compile',function (
        $scope, $window, $http, $q, localStorageService, $filter, $timeout, $sce,$compile ) {

        initCommon($scope, $http, $q, localStorageService);
        $scope.UserId = localStorageService.get('UserId');

        readParam($scope, $window);
        $scope.ReportId = $scope.parameters['id'];
        $scope.DateFromString = $scope.parameters['DateFromString'];
        $scope.DateToString = $scope.parameters['DateToString'];

        var loadReportHtml = function (reportId,userId, dateFromString, dateToString, dynamicFilters,filterValue,parameters) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/LoadHtmlByRole", $http, $q, { reportId: reportId,userId:userId, dateFrom: dateFromString, dateTo: dateToString, dynamicFilters: dynamicFilters ,filterValue:filterValue,parameters:parameters});
        };
        var getReport = function (reportId) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/Get", $http, $q, { reportId: reportId });
        };
        var getDynamicByRole = function (table, id, name) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/GetDynamicByRole", $http, $q, { table: table, id: id, name:name, userId: $scope.UserId });
        };
        var getAllDynamic = function (table,reportId,filterValue,filterMasterId,filterMasterName, filterAccessTable, filterAccessColumn, filterAccessValue) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/AllDynamic", $http, $q, { table: table,reportId :reportId,filterValue:filterValue, filterMasterId: filterMasterId, filterMasterName: filterMasterName, filterAccessTable: filterAccessTable, filterAccessColumn: filterAccessColumn, filterAccessValue: filterAccessValue  });
        };
        var getAllHeader= function (filterValue) {
            return httpCallerX(ReportXPath + "api/Reporter/Header/All", $http, $q, { filterValue: filterValue });
        };
        var getEnumList = function (path) {
            return httpCallerX(path, $http, $q);
        };
        $scope.waitsub=0;
           
        $scope.load = function (reportId,dynamicFilters,sub,close) {

            if (!reportId) {
                msg('Please select a report to load.');
                return;
            }
            if($scope.DateFromString && $scope.DateToString && $scope.DateFromString.length>1 &&  $scope.DateToString.length>1 && $scope.DateFromString>$scope.DateToString){
                msg('Please select valid dates.');
                return;
            }
            var rdesign={},parameters='';
            Object.keys($scope.parameters).forEach(function(name){
                if($scope.parameters[name].indexOf(',')>-1){
                    var mparts=$scope.parameters[name].split(','),jparts='';
                    mparts.forEach(function(mp){
                        if(jparts.length>1) jparts+=',';
                        jparts+='\''+ mp+'\'';
                    });
                    parameters+= name+'='+jparts +' & ';
                }
                else
                    parameters+= name+'=\''+ $scope.parameters[name]+'\' & ';
            });
                 
            return loadReportHtml(reportId,$scope.UserId, $scope.DateFromString, $scope.DateToString, dynamicFilters,$scope.PropertyID,parameters)
                .then(function (result) {

                    if(result.Data.Table && result.Data.Table.length<1){
                        msg('No data found.');
                        return;
                    }
                    var currentData =result.Data.Table; 
                    if(result.Data.rdesign && result.Data.rdesign.length>0)
                        rdesign=JSON.parse(result.Data.rdesign[0].rdesign); 
                    if(!rdesign.sr)rdesign.sr=[];
                    var dateColumns = [], timeColumns = [];
                    var obj1 = result.Data.Table[0];
                    Object.keys(obj1).filter(function (key) {
                        if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 && key.toLowerCase().indexOf('date')>-1 ) {
                            dateColumns.push(key);
                        } else if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 && key.toLowerCase().indexOf('time')>-1 ) {
                            timeColumns.push(key);
                        }                       
                    });
                    angular.forEach(result.Data.Table,function(row){           
                        angular.forEach(dateColumns,function(dateColumn){                             
                            row[dateColumn]=$filter('date')(row[dateColumn], $scope.DateFormat);
                        });
                        angular.forEach(timeColumns,function(timeColumn){                             
                            if(row[timeColumn]) row[timeColumn]=timeParser(row[timeColumn]).substr(0,5);
                        });
                    });      
                    try{
                        var formulaColumns=result.Data.ReportColumn.filter(x=>x.IsFormula==="True");                        
                        formulaColumns.forEach(function(col){
                            var formulaParts=col.Name.split(' ');
                            var formulaValues=[];
                            formulaParts.forEach(function(formulaPart){
                                var found=result.Data.ReportColumn.find(x=>x.DisplayName === formulaPart);                             
                                if(found) 
                                    formulaValues.push("row['"+formulaPart+"']");
                                else
                                    formulaValues.push(formulaPart);
                            });
                            var value=formulaValues.join(' ');   
                            currentData.forEach(function(row){
                                row[col.DisplayName]=eval(value);
                            });
                        });
                    }
                    catch(err) {}
                    
                    $scope.suppress(rdesign.rho);
                    $scope.suppress(rdesign.rhb,true);
                    $scope.suppress(rdesign.rpo);
                    $scope.suppress(rdesign.rpb,true);
                    $scope.suppress(rdesign.rfo);
                    //$scope.suppress(rdesign.rfb,true);
                    $scope.loadFields(rdesign,'h',currentData,dynamicFilters,sub);
                    $scope.loadFields(rdesign,'p',currentData,dynamicFilters,sub);

                    rdesign.rbb.forEach(function(col){
                        if(col.type==='summary'||col.type==='total')
                        {
                            col.running= col.running||{};   
                            col.running[col.DisplayName]=0;   
                        }
                    });
                    var rowHeight= parseFloat(('00'+rdesign.rbo.height).slice(0,-2));
                    rdesign.rgo=$scope.groupNest(currentData, rdesign.rgo[0],rowHeight,rdesign.rbo,0,rdesign.rbb);          
                    $scope.loadFields(rdesign,'f',currentData,dynamicFilters,sub);
                    $scope.suppress(rdesign.rfb,true);
                    if(!sub){ 
                        $scope.rdesign=rdesign;
                        $scope.print(close);
                    }
                    return rdesign;
                }).catch(function (err) {
                    msg(err.Message);
                });
        };
        $scope.groupNest=function(data,rgo,rowHeight,rgb,level,rbb){
            level++;
            var rowTop=0;
            if(!rgo){                                                                              
                rgo={rgd:[]};
                angular.extend(rgo,rgb);
                rgo.display=rgo.suppress===true?'none':'block';
                if(rbb.length>0) data.forEach(function(r){
                    var row={position:'absolute', top:rowTop+'cm'};
                    rbb.forEach(function(col){
                        switch(col.type){
                            case 'summary'  :  
                                //case 'total'    :  col.running[col.DisplayName] = decimalValD(col.running[col.DisplayName] + decimalValD(r[col.DisplayName.substr(8)])); row[col.DisplayName]=col.running[col.DisplayName];   break;
                            case 'total'    :  col.running[col.DisplayName] = decimalValD(parseFloat(col.running[col.DisplayName]) + parseFloat(r[col.DisplayName.substr(8)])); row[col.DisplayName]=col.running[col.DisplayName];   break;
                            case 'image'    :  col.Name=col.DisplayName='<image src=\''+(r[col.src])+'\'>'; break;
                            case 'label'    :  row[col.DisplayName]= col.DisplayName;                       break;
                            case 'db'       :     
                            case 'custom'   : 
                            default         :  row[col.DisplayName]= r[col.DisplayName];                    break;
                        }
                        col.display=col.suppress===true?'none':'block';           
                    });
                    rgo.rgd.push(row);
                    if(rgb.suppress!==true) rowTop+=rowHeight;
                });
                rgo.height=rowTop+'cm';  
                rgo.rbb=rbb;
                return [rgo];    
            }
            else
            {
                var rgoCurrent=angular.copy(rgo);
                rgo=[];
                var rgb1=rgb;
                rgb=rgoCurrent.rgb[0];
                var data1 = $filter('groupBy')(data, rgb.DisplayName);
                var i=0;
                Object.values(data1).forEach(function(r){
                    var rgoNext;
                    if(rgoCurrent.rgo && rgoCurrent.rgo.length>0) rgoNext=angular.copy(rgoCurrent.rgo[0]);   
                    var gheader=angular.copy(rgoCurrent);                               
                    var gfooter=angular.copy(rgoCurrent.rjo);  
                    gheader.display=eval(gheader.suppress)===true?'none':'block';                    
                    gfooter.display=eval(gfooter.suppress)===true?'none':'block';                  
                    var rgoReturned=$scope.groupNest(r.items, rgoNext,rowHeight,rgb1,level,rbb);
                    var groupHeight=0;
                    rgoReturned.forEach(function(rr){
                        groupHeight+=parseFloat(('00'+rr.height).slice(0,-2));
                    });
                    groupHeight+=((gheader.suppress===true?0:parseFloat(('00'+gheader.height).slice(0,-2)))+(gfooter.suppress===true?0:parseFloat(('00'+gfooter.height).slice(0,-2)))); //groupHeight+=(2*rowHeight);
                    rgo[i]={rgo:rgoReturned,rgb:[rgb],position:'relative', height:groupHeight+'cm',top:(level>1?gheader.height:0)+'cm',gheader:gheader,gfooter:gfooter}; 
                    var grp={position:'absolute',rjd:[]},grj={position:'absolute',rjd:[]};
                    $scope.loadGroup(rgoCurrent.rgb,grp,rgb,r);
                    $scope.loadGroup(rgoCurrent.rjb,grj,rgb,r);
                    Object.values(rgo[i].rgo).forEach(function(rc){
                        $scope.calculateGroup(rgoCurrent.rgb,grp,rc);
                        $scope.calculateGroup(rgoCurrent.rjb,grj,rc);
                    });
                    rgo[i].rjd=[];
                    $scope.renderGroup(rgoCurrent.rgb,grp,rgo[i],rgo[i].rgb);
                    $scope.renderGroup(rgoCurrent.rjb,grj,rgo[i],rgo[i].rjd);
                    i++;
                });
                return rgo;            
            }
        };
        $scope.renderGroup= function (rb,grp,rgoi,rjd) {
            rb.forEach(function(col){
                switch(col.type){
                    case 'formula': 
                        var formulaParts=col.Name.split(' ');
                        var formulaValues=[];
                        formulaParts.forEach(function(formulaPart){
                            formulaValues.push(grp[formulaPart]?grp[formulaPart].sum:formulaPart);
                            
                        });
                        var value=formulaValues.join(' ');   
                        try{
                            grp[col.DisplayName]=decimalValD(eval(value));
                        }catch(e){}
                        rgoi[col.DisplayName] = grp[col.DisplayName];
                        break;
                    case 'summary':      
                    case 'total': 
                        rgoi[col.DisplayName] = grp[col.DisplayName];
                        switch(col.summary){
                            case 'count':   rgoi[col.DisplayName] = grp[col.DisplayName].count;                           break;
                            case 'sum':     rgoi[col.DisplayName] = grp[col.DisplayName].sum;                             break;
                            case 'average': rgoi[col.DisplayName] = decimalVal(grp[col.DisplayName].sum/grp[col.DisplayName].count);  break;
                        }
                        break;
                    case 'image'    : rgoi.Name = rgoi[col.Name]=rgoi[col.DisplayName] =grp[col.DisplayName]=grp[col.Name]='<image src=\''+(grp[col.src])+'\'>'; break;
                    case 'db':      
                    case 'label': 
                    default: rgoi[col.DisplayName] = grp[col.DisplayName];break;
                }
                var hrow={};
                angular.extend(hrow, col);                             
                if(col.suppress){
                    try{
                        hrow.display= hrow.suppress===true || eval(rgoi[hrow.DisplayName]  +' '+hrow.suppress)===true?'none':'block';                    
                    }catch(e){}
                }
                rjd.push(hrow);
            });
        };
        $scope.calculateGroup= function (rb,grp,rc) {
            rb.forEach(function(col){
                switch(col.type){
                    case 'summary':      
                    case 'total':      
                    case 'group':
                        if(rc.rgd)
                            rc.rgd.forEach(function(d){
                                grp[col.DisplayName].count += 1;                            
                                //grp[col.DisplayName].sum =decimalValD(grp[col.DisplayName].sum+ parseFloat(d[col.DisplayName])); 
                                grp[col.DisplayName].sum =decimalValD(parseFloat(grp[col.DisplayName].sum)+ parseFloat(d[col.DisplayName])); 
                            });
                        else{
                            grp[col.DisplayName].count += 1;                            
                            grp[col.DisplayName].sum =decimalValD(parseFloat(grp[col.DisplayName].sum) +parseFloat(rc[col.DisplayName]));
                        }
                        break;
                }
            });
        };
        $scope.loadGroup= function (rb,grp,rgb,r) {
            rb.forEach(function(col){
                switch(col.type){
                    case 'summary'  :      
                    case 'total'    : grp[col.DisplayName]={count:0,sum:0};     break;
                    case 'custom'   : 
                    case 'db'       : 
                        if(col.DisplayName===rgb.DisplayName)
                            grp[col.DisplayName]= r.group_name;
                        else if(r.items && r.items.length>0)
                            grp[col.DisplayName]= r.items[0][col.DisplayName];       
                        break;
                    case 'image'    :col.Name=col.DisplayName;grp[col.src]=r.items && r.items.length>0? r.items[0][col.src]:col.src;break;
                    default         : grp[col.DisplayName]=col.DisplayName;     break;
                }
                col.display=col.suppress===true?'none':'block';               
            });
        };

        $scope.Download = function (reportId,dynamicFilters,sub,close) {

            if (!reportId) {
                msg('Please select a report to load.');
                return;
            }
            if($scope.DateFromString && $scope.DateToString && $scope.DateFromString.length>1 &&  $scope.DateToString.length>1 && $scope.DateFromString>$scope.DateToString){
                msg('Please select valid dates.');
                return;
            }
            var rdesign={},parameters='';
            Object.keys($scope.parameters).forEach(function(name){
                if($scope.parameters[name].indexOf(',')>-1){
                    var mparts=$scope.parameters[name].split(','),jparts='';
                    mparts.forEach(function(mp){
                        if(jparts.length>1) jparts+=',';
                        jparts+='\''+ mp+'\'';
                    });
                    parameters+= name+'='+jparts +' & ';
                }
                else
                    parameters+= name+'=\''+ $scope.parameters[name]+'\' & ';
            });
                 
            
            return loadReportHtml(reportId,$scope.UserId, $scope.DateFromString, $scope.DateToString, dynamicFilters,$scope.PropertyID,parameters)
                .then(function (result) {

                    if(result.Data.Table && result.Data.Table.length<1){
                        msg('No data found.');
                        return;
                    }
                    var currentData =result.Data.Table; 
                    if(result.Data.rdesign && result.Data.rdesign.length>0)
                        rdesign=JSON.parse(result.Data.rdesign[0].rdesign); 
                    if(!rdesign.sr)rdesign.sr=[];
                    var dateColumns = [], timeColumns = [];
                    var obj1 = result.Data.Table[0];
                    Object.keys(obj1).filter(function (key) {
                        if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 && key.toLowerCase().indexOf('date')>-1 ) {
                            dateColumns.push(key);
                        } else if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 && key.toLowerCase().indexOf('time')>-1 ) {
                            timeColumns.push(key);
                        }                       
                    });
                    angular.forEach(result.Data.Table,function(row){           
                        angular.forEach(dateColumns,function(dateColumn){                             
                            row[dateColumn]=$filter('date')(row[dateColumn], $scope.DateFormat);
                        });
                        angular.forEach(timeColumns,function(timeColumn){                             
                            if(row[timeColumn]) row[timeColumn]=timeParser(row[timeColumn]).substr(0,5);
                        });
                    });      
                    try{
                        var formulaColumns=result.Data.ReportColumn.filter(x=>x.IsFormula==="True");                        
                        formulaColumns.forEach(function(col){
                            var formulaParts=col.Name.split(' ');
                            var formulaValues=[];
                            formulaParts.forEach(function(formulaPart){
                                var found=result.Data.ReportColumn.find(x=>x.DisplayName === formulaPart);                             
                                if(found) 
                                    formulaValues.push("row['"+formulaPart+"']");
                                else
                                    formulaValues.push(formulaPart);
                            });
                            var value=formulaValues.join(' ');   
                            currentData.forEach(function(row){
                                row[col.DisplayName]=eval(value);
                            });
                        });
                    }
                    catch(err) {}
                    
                    $scope.suppress(rdesign.rho);
                    $scope.suppress(rdesign.rhb,true);
                    $scope.suppress(rdesign.rpo);
                    $scope.suppress(rdesign.rpb,true);
                    $scope.suppress(rdesign.rfo);
                    //$scope.suppress(rdesign.rfb,true);
                    $scope.loadFields(rdesign,'h',currentData,dynamicFilters,sub);
                    $scope.loadFields(rdesign,'p',currentData,dynamicFilters,sub);

                    rdesign.rbb.forEach(function(col){
                        if(col.type==='summary'||col.type==='total')
                        {
                            col.running= col.running||{};   
                            col.running[col.DisplayName]=0;   
                        }
                    });
                    var rowHeight= parseFloat(('00'+rdesign.rbo.height).slice(0,-2));
                    rdesign.rgo=$scope.groupNest(currentData, rdesign.rgo[0],rowHeight,rdesign.rbo,0,rdesign.rbb);          
                    $scope.loadFields(rdesign,'f',currentData,dynamicFilters,sub);
                    $scope.suppress(rdesign.rfb,true);
                    if(!sub){ 
                        $scope.rdesign=rdesign;
                        //$scope.print(close);
                    }

                    var header='';
                    var field='';
                    for(var i=0; i<rdesign.rbb.length; i++)
                    {
                        if(i==0)
                        {
                            field=rdesign.rbb[i].DisplayName;
                        }
                        else
                        {
                            field=field+','+rdesign.rbb[i].DisplayName;
                        }
                    }
                    //if($scope.waitsub===0) 
                    //    $timeout(function () {
                    //        var printDiv= document.getElementById('TabledivReport');
                    //        var printContents = printDiv.innerHTML;
                    //        var a = document.createElement('a');
                    //        //getting data from our div that contains the HTML table
                    //        var data_type = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                
                    //        a.href = data_type + ', ' + printContents;;//table_html;
                    //        //setting the file name
                    //        a.download = 'download.xls';
                    //        //triggering the function
                    //        a.click();
                    //    },900);
                    

                    $('#buttonGroup').table_download({
                        format: "csv",
                        separator: "-",
                        filename: "downloadcsv",
                        linkname: "Export CSV",
                        quotes: "\"",
                        printData: rdesign.rgo,
                        PropertyName: "",
                        PropertyAddress: "",
                        ReportName: '',
                        fields: '',//field,//'View_KOTBill.BillDate,Food,Beverage,Liquor,Tobacco,Other,View_KOTBill.Item_Amount,View_KOTBill.Tax_Amount,View_KOTBill.DiscountAmount_Amount,View_KOTBill.NetAmount',
                        Displayfield: '',//field//",Food,Beverage,Liquor,Tobacco,Other,Amount,Tax,Discount,Net Amount"
                    });
                    return ;
                }).catch(function (err) {
                    msg(err.Message);
                });
        };

        $scope.loadFields = function (rdesign,section,currentData,dynamicFilters,sub) {
            var container,style;
            switch(section){
                case 'h':container=rdesign.rhb;style=rdesign.rho; break;
                case 'p':container=rdesign.rpb;style=rdesign.rpo; break;
                case 'f':container=rdesign.rfb;style=rdesign.rfo; break;
            }
            if(container) container.forEach(function(col){                    
                switch(col.type){
                    case 'formula': 
                        col.DisplayNameF=col.DisplayName;
                        var formulaParts=col.Name.split(' ');
                        var formulaValues=[];
                        formulaParts.forEach(function(formulaPart){                           
                            var found=container.find(x=>x.DisplayNameF === formulaPart);                             
                            if(found) 
                                formulaValues.push(found.DisplayName);
                            else
                                formulaValues.push(formulaPart);
                         
                        });
                        var value=formulaValues.join(' ');   
                        try{
                            col.DisplayName=decimalValD(eval(value));
                        }catch(e){}
                        break;
                    case 'unbound':
                        switch(col.Name){
                            case 'date':
                                col.DisplayName=$filter('date')(new Date(), $scope.DateFormat);
                                break;
                            case 'num2word':
                                var d=container.find(x=>x.DisplayNameF==col.read);
                                col.DisplayName=num2words(parseFloat(d.DisplayName));
                                break;
                        };
                        break;
                    case 'summary':      
                    case 'total':
                        col.DisplayNameF=col.DisplayName;
                        col.DisplayName=currentData.reduce(function(a,b){
                            return decimalValD(parseFloat(a)+b[col.DisplayName]);
                        },0);
                        col['text-align']='right';
                        break;
                    case 'parameter':
                        col.DisplayName='';
                        break;
                    case 'report':
                        $scope.waitsub++;
                        $scope.load(col.id,dynamicFilters,true)
                             .then(function(s){
                                 rdesign.sr[col.DisplayName]=s;  
                                 var reportHeight=$scope.reportHeight(s);
                                 style.height=(parseFloat(('00'+style.height).slice(0,-2))+ reportHeight)+'cm';
                                 container.forEach(function(other){                    
                                     if(other.top>col.top && other.type!=='report') other.top+=(reportHeight*37);
                                 });
                             }).finally(function(){ 
                                 $scope.waitsub--;
                                 $scope.print();
                             });
                        break;
                    case 'image':      
                        col.Name//=col.DisplayName
                            ='<image src=\''+(currentData && currentData.length>0? currentData[0][col.src]:col.src)+'\'>';   
                        break;
                    case 'db':
                    case 'custom':
                        col.DisplayName=currentData && currentData.length>0? currentData[0][col.DisplayName]:col.DisplayName;   
                        break;
                };
            });
        };
        $scope.reportHeight= function (report) {
            var height=0;
            height+=(report.rho.suppress===true?0:parseFloat(('00'+report.rho.height).slice(0,-2)));
            height+=(report.rpo.suppress===true?0:parseFloat(('00'+report.rpo.height).slice(0,-2)));
            height+=(report.rfo.suppress===true?0:parseFloat(('00'+report.rfo.height).slice(0,-2)));            
            report.rgo.forEach(function(g){height+=parseFloat(('00'+g.height).slice(0,-2));});
            return height;
        };
        $scope.suppress = function (section,loop) {
            if(!loop)
                section.display=section.suppress===true?'none':'block';
            else
                section.forEach(function(el){
                    //el.display=el.suppress===true?'none':'block';                 
                    if(el.suppress){
                        try{
                            el.display= el.suppress===true || eval(el.DisplayName  +' '+el.suppress)===true?'none':'block';                    
                        }catch(e){
                            //e.message;
                        }
                    }                
                });
        };
        $scope.reset = function () {
            $scope.DateFromString = "";
            $scope.DateToString = "";
            $scope.Report = [];
            $scope.Report.columns = [];
            $scope.IsLoaded = true;
            angular.forEach($scope.FilterColumns, function (col) {
                col.MasterId = "";
                col.MasterIds = [];
            });
        };

        $scope.selectReport = function () {
            if (!$scope.ReportId) return;
            getReport($scope.ReportId)
             .then(function (result) {
                 var report = result.Data;
                 if (!report) return;
                 
                 $scope.title = report.Name;
                 $scope.IsGroupSummary = report.IsGroupSummary;
                 $scope.HeaderColumns = report.ReportColumns.filter(x => x.IsHidden === false);
                 if($scope.HeaderColumns && $scope.HeaderColumns.length>1) {
                     $scope.HeaderColumns.forEach(function(c){
                         if(c.IsTotal)c.align='right';
                     });
                 }
                 
                 $scope.FilterColumns = report.ReportColumns.filter(x => x.IsFilter === true);
                 angular.forEach($scope.FilterColumns, function (col) {

                     if (col.FilterMaster){
                         var promise;
                         if(col.IsEnum)
                             promise=getEnumList($scope.xApiPath + col.FilterMaster + '/all');
                         else
                             promise=getDynamicByRole(col.FilterMaster, col.FilterMasterId, col.FilterMasterName);                         //promise=getAllDynamic(col.FilterMaster, $scope.ReportId,  $scope.PropertyID,col.FilterMasterId,col.FilterMasterName,col.FilterAccessTable,col.FilterAccessColumn, $scope.UserId);
                         promise.then(function (result) {
                             col.Masters = result.Collection;
                             if(col.FilterType===1)
                                 col.Masters.unshift({Name:"ALL",Id:"ALL"});
                             else if(col.FilterType===2){
                                 col.MasterIds=[];
                                 $scope.filterDynamic();
                             }
                         }).catch(function (err) {
                             msg(err.Message);
                         });
                     }
                 });
                 $scope.IsDateRange= report.ReportColumns.find(x => x.IsDateRange === true);
             }).catch(function (err) {
                 msg(err.Message);
             });
        };
        $scope.filterDynamic = function (column) {
            $scope.DynamicFilters = "";
            angular.forEach($scope.FilterColumns, function (col) {

                if(col.FilterType===1)
                { 
                    column.MasterIdAll1=JSON.parse(column.MasterIdAll);
                    column.MasterId=column.MasterIdAll1.Id;
                    column.DisplayValue=column.MasterIdAll1.Name;
                    if (col.MasterId && col.MasterId!=="ALL") {
                        if ($scope.DynamicFilters.length > 5) $scope.DynamicFilters += " AND "
                        if(col.IsEnum)
                            $scope.DynamicFilters += " [" + col.FilterMasterId + "].[" + col.FilterMasterName + "]='" + col.MasterId+ "' ";
                        else
                            $scope.DynamicFilters += col.Name + "='" + col.MasterId+ "' ";
                        //$scope.DynamicFilters += " [" + col.TableName + "].[" + col.Name + "]='" + col.MasterId+ "' ";
                    }
                }
                else if(col.FilterType===2)
                {
                    if (col.MasterIds) {
                        var multiFilter=col.MasterIds.length>0?"":"null";
                        angular.forEach(col.MasterIds, function (master) {

                            if (multiFilter!=='null' &&  multiFilter.length > 1) multiFilter += ","                          
                            multiFilter += "'" + master.Id+ "'";                        
                        });
                        if(col.IsEnum)
                            multiFilter=" [" + col.FilterMasterId + "].[" + col.FilterMasterName + "] IN (" +multiFilter +  ")";
                        else
                            multiFilter= col.Name + " IN (" +multiFilter +  ")";
                        if ($scope.DynamicFilters.length > 5) $scope.DynamicFilters += " AND "
                        $scope.DynamicFilters +=  multiFilter;
                    }
                }
            });
        };
        $scope.MasterSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
        $scope.myEventListeners = {
            onItemSelect:  $scope.filterDynamic,
            onItemDeselect:  $scope.filterDynamic,
            onSelectAll: $scope.filterDynamic,
            onDeselectAll: $scope.filterDynamic
        };
        $scope.selectReport();
      
        $scope.print= function (close) {
            if($scope.waitsub===0) 
                $timeout(function () {
                    if($scope.debug)
                        $scope.print2();
                    else
                        $scope.print1(close);
                }, 900);
        };
        $scope.print1= function (close) {
            
            //var lblHeading= document.getElementById('lblHeading');
            //lblHeading.val('From '+$scope.DateFromString +' To '+ $scope.DateToString);
            
            var printDiv= document.getElementById('divReport');
            var printContents = printDiv.innerHTML;
            if($scope.DateFromString && $scope.DateToString)
            {
                printContents = printContents.replace('~filterValue~','From '+$scope.DateFromString +' To '+ $scope.DateToString);
            }
            else if($scope.DateFromString && $scope.DateToString==false)
            {
                printContents = printContents.replace('~filterValue~','For '+$scope.DateFromString);
            }
            else if($scope.DateFromString==false && $scope.DateToString)
            {
                printContents = printContents.replace('~filterValue~','For '+$scope.DateToString);
            }
            else
            {
                printContents = printContents.replace('~filterValue~','');
            }
            var popupWin = window.open('', '_blank', 'width=1000,height=700');
            popupWin.document.open();
            popupWin.document.write('<html><head>');           
            popupWin.document.write('</head><body onload="window.print()">');
            popupWin.document.write(printContents );
            popupWin.document.write('<canvas></canvas><link rel="stylesheet" type="text/css" href="../Content/paper.css" />');
            popupWin.document.write('</body></html>');

            popupWin.document.close();
            $scope.marchDoc=popupWin.document;
            $window.myvar=popupWin.document;

            if(close) $window.close();
           
        };
        $scope.print2= function () {
            var printDiv= document.getElementById('divReport');
            var printContents = printDiv.innerHTML;
            var popupWin = window.open('', 'divIrro');
            popupWin.document.open();
            popupWin.document.write('<html><head><style>body {margin: 0;padding:0} .pageBreak { page-break-after: always; }</style>');
            popupWin.document.write('</head><body >');
            popupWin.document.write(printContents );
            popupWin.document.write('</body></html>');
            popupWin.document.close();
            $scope.popupWin=popupWin;
            var popupWinh = window.open('', 'divIrho');
            popupWinh.document.open();
            popupWinh.document.write('<html><head><style>body {margin: 0;padding:0} .pageBreak { page-break-after: always; }</style>');
            popupWinh.document.write('</head><body >');
            popupWinh.document.write(printContents );
            popupWinh.document.write('</body></html>');
            popupWinh.document.close();
            var popupWinp = window.open('', 'divIrpo');
            popupWinp.document.open();
            popupWinp.document.write('<html><head><style>body {margin: 0;padding:0} .pageBreak { page-break-after: always; }</style>');
            popupWinp.document.write('</head><body >');
            popupWinp.document.write(printContents );
            popupWinp.document.write('</body></html>');
            popupWinp.document.close();
            var popupWinf = window.open('', 'divIrfo');
            popupWinf.document.open();
            popupWinf.document.write('<html><head><style>body {margin: 0;padding:0} .pageBreak { page-break-after: always; }</style>');
            popupWinf.document.write('</head><body >');
            popupWinf.document.write(printContents );
            popupWinf.document.write('</body></html>');
            popupWinf.document.close();
        };
        $scope.nopCalculate= function (r) {
            var groupsHeight=0; r.rgo.forEach(function(g){
                groupsHeight+=parseFloat(('00'+g.height).slice(0,-2));
            });
            var rhoHeight=(r.rho.suppress===true?0:parseFloat(('00'+r.rho.height).slice(0,-2))),
                rpoHeight=(r.rpo.suppress===true?0:parseFloat(('00'+r.rpo.height).slice(0,-2))),                    
                rfoHeight=(r.rfo.suppress===true?0:parseFloat(('00'+r.rfo.height).slice(0,-2)));            
            var printHeight=parseFloat(('00'+r.rro.printHeight).slice(0,-2)),
                marginTop=parseFloat(('00'+r.rro['margin-top']).slice(0,-2)),
                marginBottom=parseFloat(('00'+r.rro['margin-bottom']).slice(0,-2));                   
            var pageHeight = printHeight - (marginTop+marginBottom+ rpoHeight),            
                i=1,curHeight=0,curPageHeight=0;
            r.h=[];
            while(groupsHeight>0){
                curPageHeight=pageHeight-(i==1?rhoHeight:0);
                if(r.lastpage) 
                    curHeight=groupsHeight;
                else{
                    curHeight=curPageHeight;
                    if(curPageHeight>=groupsHeight){
                        curPageHeight=curPageHeight-rfoHeight;
                        if(curPageHeight<groupsHeight){
                            r.lastpage=true;
                            curHeight=curPageHeight;
                        }else 
                            curHeight=groupsHeight;
                    }
                }
               
                r.h[i++]=curHeight;
                groupsHeight=groupsHeight-curHeight;
            }
            r.nop=r.h.length-1;
           
        };
        $scope.next=function(r,ahead){
            if(ahead) {
                if(r.nop>r.cp)  r.cp++;
            }else{
                if(r.cp>1)      r.cp--;
            }
            var rhoHeight=(r.rho.suppress===true?0:parseFloat(('00'+r.rho.height).slice(0,-2))),
              rpoHeight=(r.rpo.suppress===true?0:parseFloat(('00'+r.rpo.height).slice(0,-2))),                    
              rfoHeight=(r.rfo.suppress===true?0:parseFloat(('00'+r.rfo.height).slice(0,-2)));            
            var printHeight=parseFloat(('00'+r.rro.printHeight).slice(0,-2)),
                marginTop=parseFloat(('00'+r.rro['margin-top']).slice(0,-2)),
                marginBottom=parseFloat(('00'+r.rro['margin-bottom']).slice(0,-2));                   
      
            var topc=marginTop + marginBottom + rhoHeight + rpoHeight;
            for(var i=1;i<r.cp;i++) topc=topc+r.h[i];         
            var height =r.h[r.cp];
          
            r.rro.topc='-'+topc+'cm';
            r.rro.heightc=topc+height+'cm';
            r.rro.height=height+'cm';
        
            r.rfo.topc='-'+((r.nop==r.cp)?(topc+height):0)+'cm';
            r.rfo.heightc=((r.nop==r.cp)?(topc+height+rfoHeight):0)+'cm';          
        };

        function toDataUrl(src, callback, outputFormat) {
            // Create an Image object
            var img = new Image();
            // Add CORS approval to prevent a tainted canvas
            img.crossOrigin = 'Anonymous';
            img.onload = function() {
                // Create an html canvas element
                var canvas = document.createElement('CANVAS');
                // Create a 2d context
                var ctx = canvas.getContext('2d');
                var dataURL;
                // Resize the canavas to the original image dimensions
                canvas.height = this.naturalHeight;
                canvas.width = this.naturalWidth;
                // Draw the image to a canvas
                ctx.drawImage(this, 0, 0);
                // Convert the canvas to a data url
                dataURL = canvas.toDataURL(outputFormat);
                // Return the data url via callback
                callback(dataURL);
                // Mark the canvas to be ready for garbage 
                // collection
                canvas = null;
            };
            // Load the image
            img.src = src;
            // make sure the load event fires for cached images too
            if (img.complete || img.complete === undefined) {
                // Flush cache
                img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==';
                // Try again
                img.src = src;
            }
        };
        function startPrintProcess(canvasObj, fileName, callback) {
            var pdf = new jsPDF('p', 'pt', 'a4'),
              pdfConf = {
                  pagesplit: false,
                  background: '#fff'
              };
            document.body.appendChild(canvasObj); //appendChild is required for html to add page in pdf
            pdf.addHTML(canvasObj, 0, 0, pdfConf, function() {
                document.body.removeChild(canvasObj);
                pdf.addPage();
                html2canvas(document.getElementById('new-page-dom')).then(function(newCanvasDom) { //render the dom to be printed on the second page
                    document.body.appendChild(newCanvasDom);
                    pdf.addHTML(newCanvasDom, 20, 20, pdfConf, function() {
                        document.body.removeChild(newCanvasDom);
                        pdf.save(fileName + '.pdf');
                        callback();
                    });
                });
            });
        }
        
        $scope.pdfPromise= function (name) {

            var deferred = $q.defer();
            html2canvas($scope.marchDoc.body, {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: '*',
                        }]
                    };
                    //pdfMake.createPdf(docDefinition).download("report.pdf");
                    deferred.resolve(docDefinition);
                }
            });
            return deferred.promise;
        };
        $scope.printPdf= function (name) {

            $scope.pdfPromise(name).then(function(docDefinition){
                //pdfMake.createPdf(docDefinition).open("report.pdf");
                var p=  pdfMake.createPdf(docDefinition);
                p.download("report.pdf");

            });

            //html2canvas(document.getElementById('divReport'), {
            //    onrendered: function (canvas) {
            //        var data = canvas.toDataURL();
            //        var docDefinition = {
            //            content: [{
            //                image: data,
            //                width: 500,
            //            }]
            //        };
            //        pdfMake.createPdf(docDefinition).download("report.pdf");
            //    }
            //});


            //var div = $("#divReport")[0];
            //var rect = div.getBoundingClientRect();

            //var canvas = document.createElement("canvas");
            //canvas.width = rect.width;
            //canvas.height = rect.height;

            //var ctx = canvas.getContext("2d");
            //ctx.translate(-rect.left,-rect.top);

            //html2canvas(div, {
            //    canvas:canvas,
            //    height:rect.height,
            //    width:rect.width,
            //    onrendered: function(canvas) {
            //        var image = canvas.toDataURL("image/png");
            //        var pHtml = "<img src="+image+" />";
            //        $("#parent").append(pHtml);
            //        var docDefinition = {
            //            content:[
            //                {
            //                    layout: 'lightHorizontalLines', // optional
            //                    table: {
            //                        // headers are automatically repeated if the table spans over multiple pages
            //                        // you can declare how many rows should be treated as headers
            //                        headerRows: 1,
            //                        widths: [ '*', 'auto', 100, '*' ],

            //                        body: [
            //                          [ 'First', 'Second', 'Third', 'The last one' ],
            //                          [ 'Value 1', 'Value 2', 'Value 3', 'Value 4' ],
            //                          [ { text: 'Bold value', bold: true }, 'Val 2', 'Val 3', 'Val 4' ]
            //                        ]
            //                    }
            //                }           
            //            ]
            //            //    [{
            //            //    image: pHtml,
            //            //    //text:canvas,
            //            //    width: '10000',
            //            //    //fit: [590, 100000]
            //            //}]
            //        };
            //        var a= pdfMake.createPdf(docDefinition);
            //        a.download("a.pdf");
            //    }
            //});
            //var printDiv= document.getElementById('divReport1');
            //var printContents = printDiv.innerHTML;
            //if(!printDiv) {
            //    msg('nothing to print');
            //    return;
            //}
            //$scope.export(printDiv,'report');
           
        };
        $scope.export = function (html,name) {
            $timeout(function () {
                html2canvas(html, {
                    canvas:canvas,

                    onrendered: function (canvas) {
                        var data = canvas.toDataURL();
                        var docDefinition = {
                            content: [{
                                //image: data,
                                text:canvas,
                                width: '10000',
                                //fit: [590, 100000]
                            }]
                        };
                        var a= pdfMake.createPdf(docDefinition);
                        a.download(name+".pdf");
                        //pdfMake.createPdf(docDefinition).download(name+".pdf");
                    }
                });
            }, 100);
        };
        $scope.saveExcel = function () {

            var printDiv= document.getElementById('divReport');
            if(!printDiv && !printDiv.innerHTML)  {
                msg('Nothing to save');
                return;
            }
            var printContents = printDiv.innerHTML;
            var dataToSave ='<!doctype html><html><head>';
            dataToSave +='</head><body onload="window.print()">';
           
            dataToSave +=printContents ;
            dataToSave +='</body></html>';
            var blob = new Blob([dataToSave], {              
                type: "application/vnd.ms-excel"                //type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
            });
            saveAs(blob, 'Report.xls');
        };
 
        var df=0;
        Object.keys($scope.parameters).forEach(function(name){
            if(name!=='id') df++;
        });
        if(df>0) $scope.load($scope.ReportId,'',false,true);        //$scope.debug =true;
          
    }
]);
   
app.directive('dynamicElement', ['$compile', function ($compile) {
    return { 
        restrict: 'EA', 
        scope: { name: '=', report: '=', col:'=' },       
        replace: true,
        link: function(scope, element, attrs,ctrl) {
            function createLineElement(x, y, length, angle,style) {
                var line = document.createElement("div");
                var styles = 'border: 1px solid black; '
                           + 'width: ' + length + 'px; '                          
                           + '-moz-transform: rotate(' + angle + 'rad); '
                           + '-webkit-transform: rotate(' + angle + 'rad); '
                           + '-o-transform: rotate(' + angle + 'rad); '  
                           + '-ms-transform: rotate(' + angle + 'rad); '  
                           + 'position: absolute; '
                           + 'top: ' + y + 'px; '
                           + 'left: ' + x + 'px; ';
                line.setAttribute('style', styles);  
                return line;
            }
            function createLine(l) {              
                var x1 =parseInt(l.fromX),x2=parseInt(l.toX),y1=parseInt(l.fromY),y2=parseInt(l.toY);
                var a = x1 - x2,
                    b = y1 - y2,
                    c = Math.sqrt(a * a + b * b);
                var sx = (x1 + x2) / 2,
                    sy = (y1 + y2) / 2;
                var x = sx - c / 2,
                    y = sy;
                var alpha = Math.PI - Math.atan2(-b, a);
                return createLineElement(x, y, c, alpha,l);
            }
            if(scope.col && scope.col.type==='canvas')
                element.replaceWith(createLine(scope.col));          
            else 
                scope.$watch('report', function (newValue,oldValue) {                
                    if(!scope.name) return;
                    var html = $compile(scope.name)(scope);
                    element.replaceWith(html);               
                },true);
        },          
    }
}]);
app.directive('iframeSetDimensionsOnload', ['$timeout',function($timeout){
    return {
        restrict: 'A',
        scope:false,
        link: function(scope, element, attrs){
            element.on('load', function(){
                $timeout(function () {
                    element.css('frameBorder', '0'); 
                }, 100);
                switch(element.context.name){
                    case 'divIrho':
                        return;
                    case 'divIrpo':
                        scope.rdesign.rpo.topc='-'+scope.rdesign.rho.height;
                        scope.rdesign.rpo.heightc=(parseFloat(('00'+scope.rdesign.rho.height).slice(0,-2))+parseFloat(('00'+scope.rdesign.rpo.height).slice(0,-2)))+'cm';
                        return;
                    case 'divIrro':
                        scope.rdesign.cp=0;
                        scope.nopCalculate(scope.rdesign);
                        scope.next(scope.rdesign,true);
                        return;
                    case 'divIrfo':
                        return;
                }
            })
        }
    }}]);
