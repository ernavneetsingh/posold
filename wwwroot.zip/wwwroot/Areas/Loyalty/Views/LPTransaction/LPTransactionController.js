﻿
app.controller("controller",
[
    '$scope', 'LPTransactionService', '$cookies', '$filter', 'localStorageService', '$timeout', '$http', '$q',
    function ($scope, service, $cookies, $filter, localStorageService, $timeout, $http, $q) {

        initCommon($scope, $http, $q, localStorageService, $cookies);

        $scope.getAllTransactionType = function () {
            service.getAllTransactionType()
                .then(function (s) {
                    $scope.TransactionTypes = s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };
        $scope.getAll = function () {

            var sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder == null) {
                sortKeyOrder = {
                    key: "Name",
                    order: "ASC"
                };
            }

            var searchfor = localStorageService.get("searchfor");
            $scope.sortKeyOrder = sortKeyOrder;
            var options = {
                propertyId: $scope.PropertyID,
                currentPage: $scope.currentPage,
                recordsPerPage: $scope.recordsPerPage,
                sortKey: sortKeyOrder.key,
                sortOrder: sortKeyOrder.order,
                searchfor: searchfor || ''
            };
            $scope.showLoader = true;
            service.getAll(options)
                  .then(function (s) {
                      $scope.data = s.Collection;
                      $scope.totalItems = s.RecordCount;
                      $scope.showLoader = false;
                  }, function () {
                      parent.failureMessage("The request failed. Unable to connect to the remote server.");
                  });

        };

        $scope.save = function (model, form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            if (model.Id != null || model.TransactionTypeId > 0) {
                msg('Sorry! Only new adjustments can be done.');
                return;
            }
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            service.save(model)
                .then(function (result) {

                    if (result.Status == true) {
                        msg(result.Message, true);
                    }
                    $scope.reset();
                }, function (error) {
                    msg(error.Message);
                });
        };
        $scope.fillRecord = function (record) {

            $scope.model = record;
            $scope.IsEdit = true;
            msg('');
        };
        $scope.reset = function () {

            $scope.model = { TransactionTypeId: '0' };
            $scope.IsEdit = false;
            $scope.records = "10";
            $scope.recordsPerPage = "10";
            $scope.search();
            $scope.LPPointDay = {};
        };

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            $scope.getAll();
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            $scope.getAll();
        };
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            $scope.getAll();
        }

        $scope.getAllTransactionType();
        $scope.reset();

    }
]);
