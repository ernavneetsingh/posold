﻿
app.controller("InventoryTransaction2Controller", [     //"$scope", "$cookies", "$filter", "InventoryTransaction2Service", "localStorageService", "$window", "$timeout", "FreightChargeService", "AfterSaveBoxService",
    "$scope", "InventoryTransaction2Service", "FreightChargeService", "AfterSaveBoxService", "$filter",
    function ($scope, service, freightChargeService, afterSaveBoxService, $filter) {   //function ($scope, $cookies, $filter, service, localStorageService, $window, $timeout, freightChargeService, afterSaveBoxService) {

        $scope.freightChargeService = freightChargeService.init($scope);
        $scope.afterSaveBoxService = afterSaveBoxService.init($scope);

        var pathServer = Path;
        $scope.gridOptions = {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'InventoryTransaction.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: { text: "Inventory Transaction", style: 'headerStyle' },
            exporterPdfFooter: function (currentPage, pageCount) { return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' }; },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope,
                    function (row) {
                        if (row.isExpanded) {
                            row.entity.subGridOptions = {
                                columnDefs: [
                                    {
                                        name: 'StoreName'
                                    },
                                    {
                                        name: 'InventoryItemName'
                                    },
                                    {
                                        name: 'UnitOfMeasurementName'
                                    },
                                    {
                                        name: 'Quantity'
                                    },
                                    {
                                        name: 'Rate'
                                    },
                                    {
                                        name: 'Discount'
                                    },
                                    {
                                        name: 'TaxAmount'
                                    },
                                    {
                                        name: 'NetAmount'
                                    },
                                    {
                                        name: 'ExpiryDateString', displayName: 'Expiry Date', cellFilter: 'date:grid.appScope.DateFormat'
                                    },
                                    {
                                        name: 'CostCenterName'
                                    }
                                ]
                            };

                            row.entity.subGridOptions.data = row.entity.InventoryTransactionItems;

                        }
                    });
            }
        };
        $scope.gridOptions.columnDefs = [
            { name: 'Date', field: 'TransactionDateString', cellFilter: 'date:grid.appScope.DateFormat', sort: { direction: 'desc', priority: 0 } },
            { name: 'Type', field: 'OperationTypeName' },
            {
                name: 'DSNumber', displayName: 'DS Number'
            }
            , {
                name: 'GRNumber', displayName: 'GR Number / Indent No'
            },
            { name: 'GR Date', field: 'GRDateString', cellFilter: 'date:grid.appScope.DateFormat' },
            {
                name: 'Remarks', pinnedLeft: true, displayName: 'Remark'
            }
            , {
                name: 'VendorName', pinnedLeft: true, displayName: 'Vendor'
            }
            , {
                name: 'NetAmount', pinnedLeft: true, displayName: 'Amount'
            },
            {
                name: 'Action',
                cellTemplate: '<img src="/Assets/images/edit.gif" data-ng-click="grid.appScope.Edit(row)" title="Edit" alt="" />' +
                    '<img id="mybutton" src="/Assets/images/Streamline.png" data-ng-click="grid.appScope.Delete(row)" title="Delete" alt="" />'
            }

        ];
        $scope.getAll = function () {
            var promise = service.getAll($scope.PropertyID, $scope.DateFormat, 12);
            promise.then(function (data) {
                $scope.items = data.Collection;
                $scope.search();
            });
        };
        $scope.search = function () {

            $scope.filteredItems = $filter("filter")($scope.items,
                function (item) {
                    for (var attr in item) {

                        if (attr === "VendorName" ||
                            attr === "GRNumber" ||
                            attr === "GRDate" ||
                            attr === "OperationTypeName" ||
                            attr === "Id" ||
                            attr === "PONumber") {
                            var dd = item[attr];

                            if (dd === null || dd === 'undefined' || dd === '') {
                                // do nothing
                            }
                            else {
                                if (searchMatch(item[attr], $scope.query))
                                    return true;
                            }
                        }
                    }
                    return false;
                }
            );
            $scope.gridOptions.data = $scope.filteredItems;
            if ($scope.filteredItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.getAll();

        $scope.ReceivedItems = [];
        $scope.ComplimentoryList = [{ id: false, name: 'N' }, { id: true, name: 'Y' }];
        $scope.DiscountTypes = [{ DiscountId: "1", DiscountName: "Amount" }, { DiscountId: "2", DiscountName: "Percent" }];
        $scope.getVendors = function () {
            service.getVendors($scope.PropertyID).then(function (s) {
                $scope.Vendors = s.Collection;
            });
        };
        $scope.getVendors();
        $scope.changeVendor = function () {

            for (var i = 0; i < $scope.Vendors.length; i++) {
                if ($scope.Vendor === $scope.Vendors[i].Id) {
                    $scope.Address = $scope.Vendors[i].Address1 + '  ' + ($scope.Vendors[i].Address2 ? $scope.Vendors[i].Address2 : '');
                }
            }
        };
        var itemSuggestions = null;
        $("#ItemNameSearch").autocomplete({
            source: function (request, response) {
                service.getItems($scope.PropertyID, request.term).then(function (data) {
                    itemSuggestions = data.Collection;
                    response($.map(data.Collection, function (item) {
                        return {
                            label: item.Name,
                            val: item.Id
                        };
                    }));
                });
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        var element = angular.element($("#NewReceipt"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            scope.itemcollec = ui.item.val;
                            setTimeout(function () {
                                scope.getitemFromStore(ui.item.val);
                            }, 250);
                            check = true;
                        });
                    }
                }
            },
            change: function (e, ui) {
                var dd = e.target.value;
                var element = angular.element($("#NewReceipt"));
                var scope = element.scope();
                if (itemSuggestions) {
                    if (itemSuggestions.length > 0) {
                        for (var i = 0; i < itemSuggestions.length; i++) {
                            if (check === false) {
                                if (dd === itemSuggestions[i].InventoryItemName) {
                                    check = true;
                                    scope.getitemFromStore(itemSuggestions[i].ItemId);
                                }
                            }
                        }
                        if (check === false) {
                            msg(dd + " Item Not Exist!");
                        }
                    } else {
                        msg(dd + " Item Not Exist!");
                    }
                }
                $("#ItemNameSearch").val("");
                $("#ItemNameSearch").focus();
            },
            minLength: 1
        });
        $scope.getitemFromStore = function (itemId) {

            service.GetItemById($scope.PropertyID, itemId).then(function (data, status) {

                if (data.Data) {
                    if (data.Data.IsShowCapitalItem === "True") {
                        data.Data.IsShowCapitalItem = false;
                        data.Data.CapitalItem = "";
                    } else {
                        data.Data.IsShowCapitalItem = true;
                        data.Data.CapitalItem = "NA";
                    }
                    var isComplimentory = $scope.itempocheck;

                    $scope.ReceivedItems.push({
                        InventoryItemId: data.Data.Id,
                        StoreName: data.Data.StoreName,
                        CostCenterId: data.Data.CostCenterId,
                        ItemCode: data.Data.Code,
                        InventoryItemName: data.Data.Name,
                        UnitOfMeasurementId: data.Data.UnitOfMeasurementId,
                        UnitOfMeasurementName: data.Data.UnitOfMeasurementName,
                        UnitOfMeasurementList: data.Data.UnitOfMeasurementList,
                        ConversionUnitOfMeasurementList: data.Data.ConversionUnitOfMeasurementList,
                        RelatedUnitOfMeasurementList: data.Data.RelatedUnitOfMeasurementList,
                        BatchNo: data.Data.BatchNo,
                        ExpiryDate: data.Data.ExpiryDate,
                        ConsignmentNo: data.Data.ConsignmentNo,
                        CapitalItem: data.Data.CapitalItem,
                        Brand: data.Data.BrandName,
                        Rate: data.Data.Rate,
                        Quantity: data.Data.Quantity,
                        Discount: data.Data.Discount,
                        DiscountIn: data.Data.DiscountIn,
                        Tax: data.Data.Tax,
                        Amount: data.Data.Rate * data.Data.Quantity,
                        isDisable: data.Data.ItemTypeId === 1,
                        isBatchNo: data.Data.isBatchNo,
                        IsShowExpiryDate: data.Data.IsShowExpiryDate,
                        IsShowConsignmentNo: data.Data.IsShowConsignmentNo,
                        isConsignmentNo: data.Data.ConsignmentNo,
                        isCapitalItem: data.Data.CapitalItem,
                        //UOM: data.Data.UnitOfMeasurementId,
                        Brands: data.Data.Brands,
                        BrandId: data.Data.BrandId,
                        POItemId: "",
                        GrossAmount: 0,
                        TaxStructureId: data.Data.TaxStructureId,
                        ReceiptID: "",
                        IsComplimentary: isComplimentory,
                        ItemTypeId: data.Data.ItemTypeId

                    });

                    var i = 0;
                    angular.forEach($scope.ReceivedItems, function (item) {

                        if (item.IsComplimentary) {
                            item.Rate = 0;
                            item.isRate = true;
                            item.isTax = true;
                            item.isDiscountIn = true;
                            item.isDiscount = true;
                        }
                        else {
                            if (angular.isUndefined($scope.PONumbers)) {

                                $scope.PONumbers = '';
                            }

                            if ($scope.PONumbers.length == 0) {

                                item.isRate = false;
                                item.isTax = false;
                                item.isDiscountIn = false;
                                item.isDiscount = false;
                            }
                            else {
                                item.isRate = true;
                                item.isTax = true;
                                item.isDiscountIn = true;
                                item.isDiscount = true;
                            }
                        }
                        item.Amount = item.Rate * item.Quantity;
                        item.GrossAmount = $scope.Gross(item.Amount, item.DiscountIn, item.Discount, item.Tax);
                        item.ItemNetAmount = $scope.ItemNetAmount(item.Amount, item.DiscountIn, item.Discount, item.Tax);
                    });
                }
            });
        };
        $scope.Gross = function (amount, DiscountIn, Discount, Tax) {

            var total = 0;

            total = parseFloat(amount) + parseFloat(Tax);
            total = $filter('number')(total, 2);
            return total.replace(/,/g, '');
        };
        $scope.ItemNetAmount = function (amount, DiscountIn, Discount, Tax) {

            var total = 0;
            if (DiscountIn === "Percent") {
                total = parseFloat(amount) + parseFloat(Tax) - parseFloat(((amount) * (Discount)) / 100);
            } else {
                total = parseFloat(amount) + parseFloat(Tax) - parseFloat(Discount);
            }
            total = $filter('number')(total, 2);
            return total.replace(/,/g, '');
        };
        $scope.save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            if ($scope.ReceivedItems.length < 1) {
                msg("Please select at least one item!");
                return;
            }
            var items = $scope.ReceivedItems;
            for (var i = 0; i < $scope.ReceivedItems.length; i++) {
                if ($scope.ReceivedItems[i].BrandId === null) {
                    msg("Please Select Brand");
                    return;
                }
                if (($scope.ReceivedItems[i].Tax === null || $scope.ReceivedItems[i].Tax === "" || $scope.ReceivedItems[i].Tax === 0) && $scope.ReceivedItems[i].Complimentary === false) {
                    msg("Please Apply TaxStructure");
                    return;
                }
                if ($scope.ReceivedItems[i].isDisable === false) {
                    if ($scope.ReceivedItems[i].CostCenterId === null || $scope.ReceivedItems[i].CostCenterId === "") {
                        msg("Please Select CostCenter");
                        return;
                    }
                }
                if ($scope.ReceivedItems[i].Quantity === 0) {
                    msg("Quantity should not be 0. Delete item row.");
                    return;
                }
                if ($scope.ReceivedItems[i].Quantity > $scope.ReceivedItems[i].QuantityToReceive) {
                    msg("Quantity cannot be more than " + $scope.ReceivedItems[i].QuantityToReceive);
                    return;
                }
                if ($scope.ReceivedItems[i].Rate === 0 && !$scope.ReceivedItems[i].IsComplimentary) {
                    msg("Rate should not be 0 for " + $scope.ReceivedItems[i].InventoryItemName);
                    return;
                }
            }
            $scope.IsReceiptSaving = true;
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.InventoryTransactionItems = $scope.ReceivedItems;
            $scope.model.OperationType = 1;
            $scope.model.VendorId = $scope.Vendor;

            $scope.model.InventoryTransactionCharges = $scope.Charges;

            var promise = service.save($scope.model);
            promise.then(function (d) {

                $scope.PONumbers = "";
                if ($scope.ReceivedItems[0].ReceiptID === null || $scope.ReceivedItems[0].ReceiptID === "") {
                    msg("Item Successfully Saved", true);
                }
                else {
                    msg("Received Item Successfully Modified", true);
                }
                var m1 = d.Message.split(" ");
                var idx = m1.indexOf("and");
                var pid = idx > 0 ? m1[idx - 1] : m1.pop();
                var m2 = m1.join(' ');
                if (idx > 0) m2 = m2.replace(pid, "");

                service.MapReport($scope.PropertyID, 'grn')
                    .then(function (s) {
                        fancyPrintConfirm(m2, $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid);
                    }, function (e) {
                        msg('Error in mapping to print.');
                    });

                $scope.resetPO(true);

                $scope.data = d;
                $scope.ReceivedItems = [];
                $scope.PODate = "";
                $scope.ReceiptDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
                $scope.GRNDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
                $scope.Vendor = "";
                $scope.Address = "";
                $scope.DSNumber = "";
                $scope.GRN = "";
                $scope.Remarks = "";
                $scope.freightChargeService.reset();
                test();
            }).finally(function () {
                $scope.IsReceiptSaving = false;
            });
        };
        $scope.resetPO = function (po) {
            $scope.model = {};
            if (po) $("#posearch").val("");
        };
        $scope.calculateAmount = function (qty, index) {

            angular.forEach($scope.ReceivedItems, function (item, i) {

                if (!angular.isUndefined($scope.POdata)) {
                    var oldQty = $scope.POdata[index].Quantity;
                    if (oldQty < item.Quantity) {
                        msg(item.InventoryItemName + " quantity can not be greater then " + oldQty.toString() + ".");
                        item.Quantity = oldQty;//return;
                    }
                }

                if (i === index) {
                    item.Amount = item.Rate * item.Quantity;
                    //item.Amount = $filter('number')(item.Amount, 2);
                    //item.Amount = item.Amount.replace(/,/g, '');
                    for (var n = 0; n < $scope.ReceivedItems.length; n++) {

                        if (!$scope.ReceivedItems[n].TaxStructureId) {
                            if (!$scope.checkDiscount($scope.ReceivedItems[n])) return;
                            $scope.applyDiscount($scope.ReceivedItems[n]);
                            continue;
                        }

                        for (var q = 0; q < $scope.TaxStructure.length; q++) {
                            if ($scope.TaxStructure[q].Id === $scope.ReceivedItems[n].TaxStructureId) {
                                $scope.applyDiscount($scope.ReceivedItems[n]);
                                $scope.TaxStructureDetailsData = $scope.TaxStructure[q].LinkTaxStructures;
                                var calculatetax = 0;
                                $scope.TaxTypeTransaction = [];
                                var invoicedetail = $scope.ReceivedItems[n];
                                var taxData = $scope.TaxStructureDetailsData;
                                for (var p = 0; p < taxData.length; p++) {
                                    if (taxData[p].TaxOnId === 1 || taxData[p].TaxOnId === 3) {
                                        if (taxData[p].TaxInName === "Percent") {
                                            calculatetax = parseFloat(invoicedetail.Amount) * parseFloat(taxData[p].TaxValue) / 100;
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });

                                        } else {
                                            calculatetax = parseFloat(taxData[p].TaxValue);
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        }

                                        calculatetax = 0;
                                    } else if (taxData[p].TaxOnId === 2) {

                                        var discoutedamount = 0;
                                        if (!$scope.checkDiscount(invoicedetail)) return;
                                        if (invoicedetail.DiscountIn === "Percent" || invoicedetail.DiscountIn === "2") {
                                            discoutedamount = parseFloat(invoicedetail.Amount) - (parseFloat(invoicedetail.Amount) * parseFloat(invoicedetail.Discount ? invoicedetail.Discount : 0) / 100);
                                        } else {
                                            discoutedamount = parseFloat(invoicedetail.Amount) - parseFloat(invoicedetail.DiscountAmount ? invoicedetail.DiscountAmount.replace(',', '') : '0');
                                        }
                                        if (taxData[p].TaxInName === "Percent") {
                                            calculatetax = parseFloat(discoutedamount) * parseFloat(taxData[p].TaxValue) / 100;
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        } else {
                                            calculatetax = parseFloat(taxData[p].TaxValue);
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        }
                                        calculatetax = 0;
                                    } else {
                                        if ($scope.TaxTypeTransaction.length > 0) {
                                            var taxontaxdata = taxData[p].TaxAutoId.split("-");
                                            var newautoId = (parseInt(taxontaxdata[0]) - 1) +
                                                "-" +
                                                taxontaxdata[1] +
                                                "-" +
                                                taxontaxdata[2];
                                            for (var t = 0; t < $scope.TaxTypeTransaction.length; t++) {
                                                if (newautoId === $scope.TaxTypeTransaction[t].TaxAutoId) {
                                                    if (taxData[p].TaxInName === "Percent") {
                                                        calculatetax = parseFloat($scope.TaxTypeTransaction[t].TaxAmount) * parseFloat(taxData[p].TaxValue) / 100;
                                                        $scope.TaxTypeTransaction.push({
                                                            TaxAutoId: taxData[p].TaxAutoId,
                                                            TaxAmount: calculatetax
                                                        });

                                                    } else {
                                                        calculatetax = parseFloat(taxData[p].TaxValue);
                                                        $scope.TaxTypeTransaction.push({
                                                            TaxAutoId: taxData[p].TaxAutoId,
                                                            TaxAmount: calculatetax
                                                        });
                                                    }
                                                    calculatetax = 0;
                                                }
                                            }
                                        }

                                        calculatetax = 0;
                                    }
                                }

                                var taxSum = 0;
                                for (var l = 0; l < $scope.TaxTypeTransaction.length; l++) {
                                    taxSum += parseFloat($scope.TaxTypeTransaction[l].TaxAmount);
                                }
                                $scope.ReceivedItems[n].Tax = $filter('number')(taxSum, 2).replace(/,/g, '');
                            }
                        }
                    }

                    $scope.TaxTypeTransactionDetails = [];
                    if ($scope.TaxTypeTransaction) {
                        for (var s = 0; s < $scope.TaxTypeTransaction.length; s++) {
                            $scope.TaxTypeTransactionDetails.push({
                                ItemTransactionId: $scope.ReceivedItems[index].ItemTransactionID,
                                TaxAutoId: $scope.TaxTypeTransaction[s].TaxAutoId,
                                TaxAmount: $scope.TaxTypeTransaction[s].TaxAmount,
                                TaxTransactionId: ""
                            });
                        }
                        $scope.ReceivedItems[index].TaxTransactionDetail = $scope.TaxTypeTransactionDetails;
                    }
                }
            });
        };
        $scope.checkDiscount = function (item) {

            if (!item || !item.Discount || !item.DiscountIn) return true;
            if (item.DiscountIn === "Percent" || item.DiscountIn === "2") {
                if (parseFloat(item.Discount) <= 100) return true;
            }
            else if (parseFloat(item.Discount) <= parseFloat(item.Amount)) return true;

            msg("Discount should be less than 100%");
            item.Discount = 0;
            return false;
        };
        $scope.applyDiscount = function (item) {
            if (!item || (!item.DiscountOriginal && item.DiscountOriginal !== 0) || !item.DiscountIn) return false;
            if (item.DiscountIn === "Percent" || item.DiscountIn === "2") {
                item.DiscountAmount = (parseFloat(item.Amount) * parseFloat(item.DiscountOriginal) / 100);
            }
            else {
                item.Discount = $filter('number')(((parseFloat(item.DiscountOriginal) / parseFloat(item.QuantityOriginal ? item.QuantityOriginal : item.Quantity)) * parseFloat(item.Quantity)), 2);
                item.DiscountAmount = $filter('number')(((parseFloat(item.DiscountOriginal) / parseFloat(item.QuantityOriginal ? item.QuantityOriginal : item.Quantity)) * parseFloat(item.Quantity)), 2);
            }
            return true;
        };



        //       function getReasons() {
        //           var promise = service.getReasons($scope.PropertyID, 5);
        //           promise.then(function (data, status) {
        //               $scope.ReasonDetail = data.Collection;
        //           });
        //       }
        //       getTaxStructures();
        //       getCostCenters();

        //       var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        //       $scope.keys=localStorageService.get('ActionKeys');
        //       $scope.Index = "";
        //       $scope.IsSearch = false;
        //       $scope.ReceiptDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //       $scope.GRNDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //       $scope.getitemFromStore = [];
        //       $scope.itemcollec = [];
        //       $scope.invoices = [];
        //       $scope.itemcostcentre = [];
        //       $scope.Vendors = [];
        //       $scope.ItemBrands = [];
        //       $scope.txtPONumber = [];

        //       $scope.Delete = function (row) {
        //           if (!$scope.keys.IsDelete)
        //           {  
        //               parent.failureMessage("Unauthorized Access !!!");
        //               scrollPageOnTop();
        //               return false;
        //           }
        //           var strDelete = DeletePopup("Are you sure you want to delete this?");
        //           var ret;
        //           $.fancybox({
        //               'modal': true,
        //               'content': strDelete,
        //               'afterShow': function () {
        //                   $("#fancyconfirm_cancel")
        //                       .click(function () {
        //                           ret = false;
        //                           $.fancybox.close();
        //                       });
        //                   $("#fancyConfirm_ok")
        //                       .click(function () {

        //                           ret = true;

        //                           $.fancybox.close();
        //                           var promise = service.delete($scope.PropertyID, row.entity.Id);
        //                           promise.then(function (data, status) {
        //                               msg('GRN Successfully Deleted.', true);
        //                               test();
        //                           });

        //                       });
        //               }
        //           });


        //       };
        //       $scope.Edit = function (row) {
        //           if (!$scope.keys.IsEdit) {
        //               parent.failureMessage("Unauthorized Access !!!");
        //               scrollPageOnTop();
        //               return false;
        //           }
        //           //$('#tabUL').tabs();
        //           if (row.entity.OperationTypeName === "Receipt") {
        //               //$timeout(function () {
        //               //    $('#tabUL a[href="#NewReceipt"]').trigger('click');

        //               //}, 100);
        //               ////$('#NewReceipt').simulateClick('click');
        //               //$('#NewReceipt').mousedown();
        //               //$('#tabUL a[href="#NewReceipt"]').trigger('click');
        //               //$("ul.tabs").tabs($("div.panes > div"), { history: true });
        //               //$("#NewReceipt").tabs().tabs("option", "active", 1);
        //               //$("ul.tabs").tabs().tabs($("div.panes > div"), "active", 2);

        //               //$('#NewReceipt').mousedown();
        //               $('.nav-tabs a[href="#NewReceipt"]').tab('show');

        //               $scope.PODate = $filter("date")(row.entity.PODate, $scope.DateFormat);
        //               $scope.PONumbers = row.entity.PONumber;
        //               $scope.AgainstPO = ($scope.PONumbers) ? 1 : 0;
        //               $scope.Vendor = row.entity.VendorId;
        //               $scope.Address = row.entity.VendorAddress;
        //               $scope.model = row.entity;
        //               $scope.ReceivedItems = row.entity.InventoryTransactionItems;
        //               var index = 0;

        //               $scope.freightChargeService.setCharges(row.entity.InventoryTransactionCharges);

        //               angular.forEach($scope.ReceivedItems, function (item) {

        //                   item.DiscountIn = item.DiscountIn.toString();
        //                   item.isRate = item.IsComplimentary;
        //                   //if (item.IsComplimentary) item.Rate = 0;
        //                   $scope.calculateAmount(0, index++);
        //               });
        //           }
        //           else {
        //               //$("#ReceiptReturn").trigger('click');
        //               //$("#ReceiptReturn").tabs().tabs("option", "active", 1);
        //               $('.nav-tabs a[href="#ReceiptReturn"]').tab('show');

        //               $scope.Vendors = row.entity.VenderId;
        //               $scope.VendorAddress = row.entity.VendorAddress;
        //               $scope.Indent = row.entity.DSNumber;

        //               $scope.GRNNO = row.entity.ReceiptTransactionReceiveId;
        //               $scope.ReturnDate = row.entity.ReceiptDate;
        //               $scope.Remarks = row.entity.Remarks;
        //               $scope.Reason = row.entity.Reason;
        //               $scope.invoices = row.entity.InventoryTransactionItems;
        //           }

        //       };

        //       function getTaxStructures() {

        //           var promise = service.getTaxStructures($scope.PropertyID, 1, 5);
        //           promise.then(function (data, status) {

        //               $scope.TaxStructure = data.Collection;
        //           });
        //       }
        //       function getCostCenters() {

        //           var promise = service.getCostCenters($scope.PropertyID);
        //           promise.then(function (data, status) {
        //               $scope.itemcostcentre = data.Collection;
        //           });
        //       };

        //       getReasons();

        //       var check = false;
        //       var itempo = null;
        //       $scope.itempocheck = false;


        //       $scope.reset = function (po) {
        //           $scope.resetPO(po);
        //           $scope.ReceivedItems = [];
        //           $scope.invoices = [];
        //           $scope.itempocheck = false;
        //           //$scope.PONumbers = "";
        //           $scope.PODate = "";
        //           $scope.ReceiptDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //           $scope.GRNDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //           $scope.Vendor = "";
        //           $scope.Address = "";
        //           $scope.DSNumber = "";
        //           $scope.GRN = "";
        //           $scope.Remarks = "";
        //           scrollPageOnTop();
        //           $scope.freightChargeService.reset();

        //       };
        //       $scope.AgainstPO = 1;
        //       $scope.changeAgainstPO = function (val) {

        //           $scope.reset();
        //           $scope.PONumbers = "";
        //       };
        //       $scope.txtPONumber = function getPOItem(poid) {

        //           var promise = service.getPendingPoItems($scope.PropertyID, poid);
        //           promise.then(function (POdata, status) {

        //               if (POdata.Data.PurchaseOrderItems.length < 1) {
        //                   msg("PONumber already received or not found!");
        //                   $scope.PONumbers = "";
        //                   return;
        //               }
        //               $scope.model.PurchaseOrderId = poid;
        //               $scope.IsSearch = true;
        //               $scope.Vendor = POdata.Data.VendorId;
        //               $scope.VendorDisable = true;
        //               $scope.Address = POdata.Data.VendorAddress;
        //               $scope.model.ItemTerm = POdata.Data.ItemTerm;
        //               $scope.model.DeliveryTerm = POdata.Data.DeliveryTerm;

        //               $scope.PODate = $filter("date")(new Date(POdata.Data.PODate), $scope.DateFormat);

        //               $scope.freightChargeService.setCharges(POdata.Data.PurchaseOrderCharges);
        //               $scope.freightChargeService.total();

        //               $scope.ReceivedItems = [];
        //               for (var i = 0; i < POdata.Data.PurchaseOrderItems.length; i++) {

        //                   if (POdata.Data.PurchaseOrderItems[i].QuantityToReceive === 0) continue;

        //                   if (POdata.Data.PurchaseOrderItems[i].BatchNo === true) {
        //                       POdata.Data.PurchaseOrderItems[i].isBatchNo = false;
        //                       POdata.Data.PurchaseOrderItems[i].BatchNo = "";

        //                   } else {
        //                       POdata.Data.PurchaseOrderItems[i].isBatchNo = true;
        //                       POdata.Data.PurchaseOrderItems[i].BatchNo = "NA";
        //                   }
        //                   if (POdata.Data.PurchaseOrderItems[i].ConsignmentNo == true) {
        //                       POdata.Data.PurchaseOrderItems[i].isConsignmentNo = false;
        //                       POdata.Data.PurchaseOrderItems[i].ConsignmentNo = "";
        //                   } else {
        //                       POdata.Data.PurchaseOrderItems[i].isConsignmentNo = true;
        //                       POdata.Data.PurchaseOrderItems[i].ConsignmentNo = "NA";
        //                   }
        //                   if (POdata.Data.PurchaseOrderItems[i].CapitalItem == true) {
        //                       POdata.Data.PurchaseOrderItems[i].CapitalItem = false;
        //                       POdata.Data.PurchaseOrderItems[i].CapitalItem = "";
        //                   } else {
        //                       POdata.Data.PurchaseOrderItems[i].CapitalItem = true;
        //                       POdata.Data.PurchaseOrderItems[i].CapitalItem = "NA";
        //                   }

        //                   if (POdata.Data.PurchaseOrderItems[i].DiscountIn == null ||
        //                       POdata.Data.PurchaseOrderItems[i].DiscountIn === "" ||
        //                       POdata.Data.PurchaseOrderItems[i].DiscountIn === "1") {
        //                       POdata.Data.PurchaseOrderItems[i].DiscountIn = "Amount";
        //                   }

        //                   $scope.ReceivedItems.push({
        //                       InventoryItemId: POdata.Data.PurchaseOrderItems[i].InventoryItemId,
        //                       StoreName: POdata.Data.PurchaseOrderItems[i].StoreName,
        //                       CostCenterId: POdata.Data.PurchaseOrderItems[i].CostCenterId,
        //                       ItemCode: POdata.Data.PurchaseOrderItems[i].InventoryItemCode,
        //                       InventoryItemName: POdata.Data.PurchaseOrderItems[i].InventoryItemName,
        //                       UnitOfMeasurementId: POdata.Data.PurchaseOrderItems[i].UnitOfMeasurementId,
        //                       UnitOfMeasurementName: POdata.Data.PurchaseOrderItems[i].UnitOfMeasurementName,
        //                       BatchNo: POdata.Data.PurchaseOrderItems[i].BatchNo,
        //                       ExpiryDate: POdata.Data.PurchaseOrderItems[i].ExpiryDate,
        //                       ConsignmentNo: POdata.Data.PurchaseOrderItems[i].ConsignmentNo,
        //                       CapitalItem: POdata.Data.PurchaseOrderItems[i].CapitalItem,
        //                       Brand: POdata.Data.PurchaseOrderItems[i].BrandName,
        //                       Rate: POdata.Data.PurchaseOrderItems[i].Rate,
        //                       QuantityOriginal: POdata.Data.PurchaseOrderItems[i].Quantity,
        //                       QuantityToReceive: POdata.Data.PurchaseOrderItems[i].QuantityToReceive,
        //                       Quantity: POdata.Data.PurchaseOrderItems[i].QuantityToReceive,
        //                       DiscountOriginal: POdata.Data.PurchaseOrderItems[i].Discount,
        //                       Discount: POdata.Data.PurchaseOrderItems[i].Discount,
        //                       DiscountIn: POdata.Data.PurchaseOrderItems[i].DiscountInId.toString(),
        //                       Tax: POdata.Data.PurchaseOrderItems[i].Tax,
        //                       Amount: POdata.Data.PurchaseOrderItems[i].Rate * POdata.Data.PurchaseOrderItems[i].QuantityToReceive,
        //                       isDisable: POdata.Data.PurchaseOrderItems[i].ItemTypeId === 1,//ItemType,
        //                       isBatchNo: POdata.Data.PurchaseOrderItems[i].isBatchNo,
        //                       IsShowExpiryDate: POdata.Data.PurchaseOrderItems[i].IsShowExpiryDate,
        //                       isConsignmentNo: POdata.Data.PurchaseOrderItems[i].ConsignmentNo,
        //                       isCapitalItem: POdata.Data.PurchaseOrderItems[i].CapitalItem,
        //                       UOM: POdata.Data.PurchaseOrderItems[i].UOMId,
        //                       Brands: POdata.Data.PurchaseOrderItems[i].ForDisplayBrands,
        //                       BrandId: POdata.Data.PurchaseOrderItems[i].BrandId,
        //                       POItemId: POdata.Data.PurchaseOrderItems[i].Id, //POItemId
        //                       GrossAmount: 0,
        //                       TaxStructureId: POdata.Data.PurchaseOrderItems[i].TaxStructureId,
        //                       PONumber: POdata.Data.PurchaseOrderItems[i].PONumber,
        //                       ReceiptID: "",
        //                       IsComplimentary: POdata.Data.PurchaseOrderItems[i].IsComplimentary,
        //                       ItemTypeId: POdata.Data.PurchaseOrderItems[i].ItemTypeId,
        //                       ItemType: POdata.Data.PurchaseOrderItems[i].ItemType,

        //                   });
        //               }
        //               for (var n = 0; n < $scope.ReceivedItems.length; n++) {

        //                   $scope.ReceivedItems[n].isRate = true;
        //                   $scope.ReceivedItems[n].isAmount = true;
        //                   $scope.ReceivedItems[n].isDiscountIn = false;
        //                   $scope.ReceivedItems[n].isDiscount = false;
        //                   $scope.ReceivedItems[n].isTax = true;
        //                   $scope.ReceivedItems[n].IsComplimentary = false;
        //                   //$scope.RateChange(n);
        //                   //   $scope.TotalDiscount();
        //                   //if ($scope.ReceivedItems[n].isDisable === true) {
        //                   //    $scope.ReceivedItems[n].CostCenterId = "";
        //                   //}
        //               }
        //               $scope.calculateAmount(0, 0);
        //           });
        //       };
        //       $scope.ChangeData = function () {

        //       };
        //       $("#posearch").autocomplete({
        //           source: function (request, response) {
        //               $scope.reset();
        //               var promise = service.getPOs($scope.PropertyID, request.term);
        //               promise.then(function (data, status) {
        //                   //$scope.reset();
        //                   itempo = data.Collection;
        //                   response($.map(data.Collection, function (item) {
        //                       return {
        //                           label: item.PONumber,
        //                           val: item.Id
        //                       };
        //                   }));
        //               });
        //           },
        //           select: function (e, ui) {

        //               if (ui.item) {
        //                   if (ui.item.PONumber !== "No Record Found!") {
        //                       var element = angular.element($("#NewReceipt"));
        //                       var scope = element.scope();
        //                       scope.txtPONumber(ui.item.val);
        //                       $scope.itempocheck = true;
        //                   }
        //               }
        //           },
        //           change: function (e, ui) {

        //               var dd = e.target.value;
        //               var element = angular.element($("#NewReceipt"));
        //               var scope = element.scope();
        //               if (itempo) {

        //                   if (itempo.length > 0) {
        //                       for (var i = 0; i < itempo.length; i++) {
        //                           if (dd.toLowerCase() === itempo[i].PONumber.toLowerCase()) {
        //                               if ($scope.itempocheck === false) {
        //                                   $scope.itempocheck = true;
        //                                   scope.txtPONumber(itempo[i].POID);
        //                               }
        //                           }
        //                       }
        //                       if ($scope.itempocheck === false) {
        //                           $("#posearch").val("");
        //                           $("#posearch").focus();
        //                           msg(dd + " PO Number Not Exist!");
        //                       }

        //                   } else {
        //                       $("#posearch").val("");
        //                       $("#posearch").focus();
        //                       msg(dd + " PO Number Not Exist!");
        //                   }
        //               }
        //           },
        //           minLength: 1
        //       });


        //       $scope.checkBrandReceipt = function (itemId, brandId, index) {

        //           if ($scope.ReceivedItems[index].IsComplimentary) return;

        //           for (var i = 0; i < $scope.ReceivedItems.length ; i++) {
        //               if (i == index) continue;
        //               if ($scope.ReceivedItems[i].InventoryItemId === itemId && $scope.ReceivedItems[i].BrandId === brandId) {
        //                   msg("this brand is already taken");
        //                   $scope.ReceivedItems[index].BrandId = "";
        //                   break;
        //               }
        //           }
        //       }

        //       $scope.removeItem = function (index) {
        //           $scope.ReceivedItems.splice(index, 1);
        //       };

        //       $scope.RateChange = function (index) {

        //           if ($scope.ReceivedItems[index].IsComplimentary) {
        //               $scope.ReceivedItems[index].Rate = 0;
        //               $scope.ReceivedItems[index].Amount = 0;
        //               $scope.ReceivedItems[index].Discount = 0;
        //               $scope.ReceivedItems[index].GrossAmount = 0;
        //               $scope.ReceivedItems[index].ItemNetAmount = 0;
        //               $scope.ReceivedItems[index].Tax = 0;

        //               $scope.ReceivedItems[index].isRate = true;
        //               $scope.ReceivedItems[index].isAmount = true;
        //               $scope.ReceivedItems[index].isDiscountIn = true;
        //               $scope.ReceivedItems[index].isDiscount = true;
        //               $scope.ReceivedItems[index].isTax = true;
        //           } else {

        //               $scope.ReceivedItems[index].isRate = false;
        //               $scope.ReceivedItems[index].isAmount = false;
        //               $scope.ReceivedItems[index].isDiscountIn = false;
        //               $scope.ReceivedItems[index].isDiscount = false;
        //               $scope.ReceivedItems[index].isTax = false;
        //               $scope.calculateAmount(0, index);
        //           }
        //       }


        //       $scope.changeDiscount = function (index, discount) {

        //           var item = $scope.ReceivedItems[index];
        //           item.DiscountOriginal = discount * (item.QuantityOriginal ? item.QuantityOriginal : item.Quantity) / item.Quantity;
        //           $scope.calculateAmount(discount, index);
        //       }


        //       $scope.TotalAmount = function () {

        //           var total = 0.00;
        //           for (var i = 0; i < $scope.ReceivedItems.length; i++) {
        //               total += parseFloat($scope.ReceivedItems[i].Amount ? $scope.ReceivedItems[i].Amount : 0);
        //           }
        //           total += $scope.freightChargeServiceTotal;

        //           total = $filter('number')(total, 2);
        //           return total.replace(/,/g, '');

        //       };
        //       $scope.TotalDiscount = function () {

        //           var total = 0.00;
        //           for (var i = 0; i < $scope.ReceivedItems.length; i++) {
        //               if ($scope.ReceivedItems[i].DiscountIn === "2") {
        //                   if (!$scope.checkDiscount($scope.ReceivedItems[i])) return 0;
        //                   $scope.ReceivedItems[i].DiscountAmount = parseFloat((parseFloat($scope.ReceivedItems[i].Amount ? $scope.ReceivedItems[i].Amount : 0) * parseFloat($scope.ReceivedItems[i].Discount ? $scope.ReceivedItems[i].Discount : 0)) / 100);
        //                   total += $scope.ReceivedItems[i].DiscountAmount;
        //               } else {
        //                   total += parseFloat($scope.ReceivedItems[i].Discount ? $scope.ReceivedItems[i].Discount.replace(',', '') : 0);
        //               }
        //           }
        //           total = $filter('number')(total, 2);
        //           return total.replace(/,/g, '');
        //       };
        //       $scope.TotalTax = function () {
        //           var total = 0;
        //           for (var i = 0; i < $scope.ReceivedItems.length; i++) {
        //               total += parseFloat($scope.ReceivedItems[i].Tax ? $scope.ReceivedItems[i].Tax : 0);
        //           }
        //           total = $filter('number')(total, 2);
        //           return total.replace(/,/g, '');
        //       };
        //       $scope.NetAmount = function () {
        //           var total = 0;
        //           var discount = 0.00;
        //           for (var i = 0; i < $scope.ReceivedItems.length; i++) {

        //               if ($scope.ReceivedItems[i].DiscountIn === "2") {
        //                   discount += parseFloat((parseFloat($scope.ReceivedItems[i].Amount ? $scope.ReceivedItems[i].Amount : 0) * parseFloat($scope.ReceivedItems[i].Discount ? $scope.ReceivedItems[i].Discount : 0)) / 100);
        //               } else {
        //                   discount += parseFloat($scope.ReceivedItems[i].Discount ? $scope.ReceivedItems[i].Discount : 0);
        //               }
        //               total += (parseFloat($scope.ReceivedItems[i].Amount ? $scope.ReceivedItems[i].Amount : 0) - parseFloat(discount) + parseFloat($scope.ReceivedItems[i].Tax ? $scope.ReceivedItems[i].Tax : 0));
        //               discount = 0.00;
        //           }
        //           total += $scope.freightChargeServiceTotal;

        //           total = $filter('number')(total, 2);
        //           return total.replace(/,/g, '');
        //       };

        //       $scope.taxstructurebox = function (index, item) {


        //           if (angular.isUndefined($scope.PONumbers))
        //           { $scope.PONumbers = ''; }

        //           if ($scope.PONumbers.length > 0) {
        //               return;
        //           }

        //           $scope.Index = index;
        //           $scope.kotItem = item;
        //           $('#taxstructurebox').show('slow');

        //           $scope.TaxStructureId = item.TaxStructureId;
        //           $scope.changeTaxDetails(item.TaxStructureId);
        //           //if ($scope.ReceivedItems[$scope.Index].TaxStructureID != null || $scope.ReceivedItems[$scope.Index].TaxStructureID != "") {
        //           //    $scope.TaxStructureId = $scope.ReceivedItems[$scope.Index].TaxStructureID;
        //           //    if ($scope.TaxStructureId == null || $scope.TaxStructureId === "") {
        //           //        $scope.TaxStructureDetailsData = [];
        //           //    } else {
        //           //        for (var t = 0; t < $scope.TaxStructure.length; t++) {
        //           //            if ($scope.TaxStructure[t].TaxStructureId === $scope.TaxStructureId) {
        //           //                $scope.TaxStructureDetailsData = $scope.TaxStructure[t].TaxStructureDetails;
        //           //            }
        //           //        }
        //           //    }

        //           //}
        //       }
        //       $scope.changeTaxDetails = function (value) {
        //           if (!value) return;
        //           $.each($scope.TaxStructure, function (index, val) {
        //               if (val.Id === value) {
        //                   $scope.ItemTaxStructures = [];
        //                   angular.forEach(val.LinkTaxStructures, function (link, key) {
        //                       //
        //                       $scope.ItemTaxStructures.push({
        //                           TaxTypeId: link.TaxTypeId,
        //                           TaxTypeName: link.TaxTypeName,
        //                           TaxValue: link.TaxValue,
        //                           TaxIn: link.TaxIn,
        //                           TaxOnId: link.TaxOnId,
        //                           TaxOnName: link.TaxOnName,
        //                           Id: link.Id
        //                       });
        //                   });
        //               }
        //           });
        //       };
        //       $scope.TaxtypeStructure = function () {

        //           for (var t = 0; t < $scope.TaxStructure.length; t++) {
        //               if ($scope.TaxStructure[t].TaxStructureId === $scope.TaxStructureId) {
        //                   $scope.TaxStructureDetailsData = $scope.TaxStructure[t].TaxStructureDetails;
        //               }
        //           }
        //       }
        //       $scope.resetTax = function () {

        //           $('#taxstructurebox').hide('slow');
        //           $scope.TaxStructureId = $scope.ReceivedItems[$scope.Index].TaxStructureId = null;
        //           $scope.ReceivedItems[$scope.Index].Tax = 0;
        //           $scope.ItemTaxStructures = [];
        //           $scope.TaxStructureDetailsData = null;
        //       };
        //       $scope.AddTaxValue1 = function () {
        //           $scope.ReceivedItems[$scope.Index].TaxStructureId = $scope.TaxStructureId;
        //           $scope.calculateAmount(0, $scope.Index);
        //           $('#taxstructurebox').hide('slow');
        //       };
        //       $scope.AddTaxValue = function () {//unused
        //           //// old used
        //           var calculatetax = 0;
        //           $scope.TaxTypeTransaction = [];

        //           var invoicedetail = $scope.ReceivedItems[$scope.Index];
        //           var taxData = $scope.ItemTaxStructures;
        //           for (var p = 0; p < taxData.length; p++) {
        //               if (taxData[p].TaxOnId === 1 || taxData[p].TaxOnId === 3) {

        //                   if (taxData[p].TaxInName === "Percent") {
        //                       calculatetax = parseFloat(invoicedetail.Amount) * parseFloat(taxData[p].TaxValue) / 100;
        //                       $scope.TaxTypeTransaction.push({
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax
        //                       });

        //                   } else {
        //                       calculatetax = parseFloat(taxData[p].TaxValue);
        //                       $scope.TaxTypeTransaction.push({
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax
        //                       });
        //                   }

        //                   calculatetax = 0;
        //               }
        //               else if (taxData[p].TaxOnId === 2) {

        //                   var discoutedamount = 0;
        //                   if (invoicedetail.DiscountIn === "Percent") {
        //                       discoutedamount = parseFloat(invoicedetail.Amount) - (parseFloat(invoicedetail.Amount) * parseFloat(invoicedetail.Discount) / 100);
        //                   } else {
        //                       discoutedamount = parseFloat(invoicedetail.Amount) - parseFloat(invoicedetail.Discount ? invoicedetail.Discount : 0);
        //                   }
        //                   if (taxData[p].TaxInName === "Percent") {
        //                       calculatetax = parseFloat(discoutedamount) * parseFloat(taxData[p].TaxValue) / 100;
        //                       $scope.TaxTypeTransaction.push({
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax
        //                       });
        //                   } else {
        //                       calculatetax = parseFloat(taxData[p].TaxValue);
        //                       $scope.TaxTypeTransaction.push({
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax
        //                       });
        //                   }
        //                   calculatetax = 0;
        //               }
        //               else {
        //                   if ($scope.TaxTypeTransaction.length > 0) {
        //                       var taxontaxdata = taxData[p].TaxAutoId.split("-");
        //                       var newautoId = (parseInt(taxontaxdata[0]) - 1) + "-" + taxontaxdata[1] + "-" + taxontaxdata[2];
        //                       for (var t = 0; t < $scope.TaxTypeTransaction.length; t++) {
        //                           if (newautoId === $scope.TaxTypeTransaction[t].TaxAutoId) {
        //                               if (taxData[p].TaxInName === "Percent") {
        //                                   calculatetax = parseFloat($scope.TaxTypeTransaction[t].TaxAmount) * parseFloat(taxData[p].TaxValue) / 100;
        //                                   $scope.TaxTypeTransaction.push({
        //                                       TaxAutoId: taxData[p].TaxAutoId,
        //                                       TaxAmount: calculatetax
        //                                   });

        //                               } else {
        //                                   calculatetax = parseFloat(taxData[p].TaxValue);
        //                                   $scope.TaxTypeTransaction.push({
        //                                       TaxAutoId: taxData[p].TaxAutoId,
        //                                       TaxAmount: calculatetax
        //                                   });
        //                               }

        //                               calculatetax = 0;
        //                           }
        //                       }
        //                   }

        //                   calculatetax = 0;
        //               }
        //           }

        //           var taxSum = 0;
        //           for (var l = 0; l < $scope.TaxTypeTransaction.length; l++) {
        //               taxSum += parseFloat($scope.TaxTypeTransaction[l].TaxAmount);

        //           }
        //           $scope.ReceivedItems[$scope.Index].Tax = $filter('number')(taxSum, 2).replace(/,/g, '');
        //           $scope.ReceivedItems[$scope.Index].TaxStructureId = $scope.TaxStructureId;
        //           $scope.TaxTypeTransactionDetails = [];
        //           for (var s = 0; s < $scope.TaxTypeTransaction.length; s++) {
        //               $scope.TaxTypeTransactionDetails.push({
        //                   ItemTransactionId: $scope.ReceivedItems[$scope.Index].ItemTransactionID,
        //                   TaxAutoId: $scope.TaxTypeTransaction[s].TaxAutoId,
        //                   TaxAmount: $scope.TaxTypeTransaction[s].TaxAmount,
        //                   TaxTransactionId: ""

        //               });
        //           }
        //           $scope.ReceivedItems[$scope.Index].TaxTransactionDetail = $scope.TaxTypeTransactionDetails;
        //           $('#taxstructurebox').hide('slow');
        //       }
        //       $scope.CalculatedTaxValue = function () {

        //           var index = $scope.Index;
        //           var kotItem = $scope.kotItem;

        //           //// new by navneet
        //           var taxData = kotItem.TaxStructureDetails;
        //           var calculatetax = 0;
        //           var taxSum = 0;

        //           kotItem.TaxAmount = 0;

        //           for (var p = 0; p < taxData.length; p++) {
        //               if (taxData[p].TaxOnId === 1 || taxData[p].TaxOnId === 3) {
        //                   if (taxData[p].TaxInName === "Percent") {
        //                       calculatetax = parseFloat(kotItem.Amount) * parseFloat(taxData[p].TaxValue) / 100;
        //                       $scope.TaxTypeTransaction.push({

        //                           Index: index,
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax

        //                       });
        //                   } else {
        //                       calculatetax = parseFloat(taxData[p].TaxValue);
        //                       $scope.TaxTypeTransaction.push({

        //                           Index: index,
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax

        //                       });
        //                   }

        //                   kotItem.TaxAmount += calculatetax;
        //                   calculatetax = 0;
        //               } else if (taxData[p].TaxOnId === 2) {
        //                   var discoutedamount = 0;

        //                   if (kotItem.DiscountIn === "Percent") {
        //                       discoutedamount = parseFloat(kotItem.Amount) - (parseFloat(kotItem.Amount) * parseFloat(kotItem.DiscountValue) / 100);
        //                   } else {
        //                       discoutedamount = parseFloat(kotItem.Rate) - parseFloat(kotItem.DiscountValue);
        //                   }
        //                   if (taxData[p].TaxInName === "Percent") {
        //                       calculatetax = parseFloat(discoutedamount) * parseFloat(taxData[p].TaxValue) / 100;
        //                       $scope.TaxTypeTransaction.push({
        //                           Index: index,
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax
        //                       });
        //                   } else {
        //                       calculatetax = parseFloat(taxData[p].TaxValue);
        //                       $scope.TaxTypeTransaction.push({
        //                           Index: index,
        //                           TaxAutoId: taxData[p].TaxAutoId,
        //                           TaxAmount: calculatetax
        //                       });
        //                   }

        //                   kotItem.TaxAmount += calculatetax;
        //                   calculatetax = 0;

        //               } else {
        //                   if ($scope.TaxTypeTransaction.length > 0) {
        //                       var taxontaxdata = taxData[p].TaxAutoId.split("-");
        //                       var newautoId = (parseInt(taxontaxdata[0]) - 1) + "-" + taxontaxdata[1] + "-" + taxontaxdata[2];
        //                       for (var t = 0; t < $scope.TaxTypeTransaction.length; t++) {
        //                           if (newautoId === $scope.TaxTypeTransaction[t].TaxAutoId) {
        //                               if (taxData[p].TaxInName === "Percent") {
        //                                   calculatetax = parseFloat($scope.TaxTypeTransaction[t].TaxAmount) * parseFloat(taxData[p].TaxValue) / 100;
        //                                   $scope.TaxTypeTransaction.push({
        //                                       Index: index,
        //                                       TaxAutoId: taxData[p].TaxAutoId,
        //                                       TaxAmount: calculatetax
        //                                   });
        //                               } else {
        //                                   calculatetax = parseFloat(taxData[p].TaxValue);
        //                                   $scope.TaxTypeTransaction.push({
        //                                       Index: index,
        //                                       TaxAutoId: taxData[p].TaxAutoId,
        //                                       TaxAmount: calculatetax
        //                                   });
        //                               }
        //                               kotItem.TaxAmount += calculatetax;
        //                               calculatetax = 0;
        //                           }
        //                       }
        //                   }
        //                   kotItem.TaxAmount += calculatetax;
        //                   calculatetax = 0;
        //               }
        //           }

        //           for (var l = 0; l < $scope.TaxTypeTransaction.length; l++) {
        //               taxSum += parseFloat($scope.TaxTypeTransaction[l].TaxAmount);
        //           }

        //           var taxValue = $filter("number")(taxSum, 2).replace(/,/g, "");

        //           $('#taxstructurebox').hide('slow');
        //           return parseFloat(taxValue);
        //       };

        //       $scope.removeReturnItem = function (index) {
        //           $scope.invoices.splice(index, 1);
        //       };

        //       $scope.txtGRNNumber = function (grn) {

        //           if (!grn || grn.length < 1) return;
        //           var promise = service.getByGRNumber($scope.PropertyID, 1, grn);
        //           promise.then(function (data) {

        //               if (data.Collection.length > 0) {
        //                   msg("Error! GRN Already Exists.");
        //                   $scope.model.GRNumber = "";
        //               }
        //           });

        //       };

        //       // //////////////////////////////////////////return receipt
        //       $scope.ReturnDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //       $scope.savereturn = function (form) {

        //           if (!$scope[form].$valid) {
        //               $scope.ShowErrorMessage = true;
        //               return;
        //           }
        //           if ($scope.invoices.length < 1) {
        //               msg("Please select at least one item!");
        //               return;
        //           }
        //           var itemss = $scope.invoices;

        //           for (var i = 0; i < $scope.invoices.length; i++) {
        //               if ($scope.invoices[i].Quantity === 0) {
        //                   msg("Quantity should not be 0.");
        //                   return;
        //               }
        //               itemss[i].ParentId = itemss[i].Id;
        //               itemss[i].VenderId = $scope.Vendors;
        //               itemss[i].Remarks = $scope.Remarks;
        //               itemss[i].TotalAmount = $scope.TotalAmountsRetrun();
        //               itemss[i].TotalDiscount = $scope.TotalDiscountsReturn();
        //               itemss[i].TotalTax = $scope.TotalTaxsReturn();
        //               itemss[i].NetAmount = $scope.NetAmountsReturn();
        //               itemss[i].OperationType = "Receive Return";
        //               itemss[i].ReceiptDate = $scope.ReturnDate;
        //               itemss[i].Reason = $scope.Reason;
        //               itemss[i].GrossAmount = $scope.GrosssReturn((parseFloat($scope.invoices[i].Quantity) * parseFloat($scope.invoices[i].Rate)), $scope.invoices[i].DiscountIn, $scope.invoices[i].Discount, $scope.invoices[i].Tax);
        //               itemss[i].ItemNetAmount = $scope.ItemNetAmountReturn((parseFloat($scope.invoices[i].Quantity) * parseFloat($scope.invoices[i].Rate)), $scope.invoices[i].DiscountIn, $scope.invoices[i].Discount, $scope.invoices[i].Tax);
        //           }

        //           $scope.modelR.PropertyID = $scope.PropertyID;
        //           $scope.modelR.ModifiedBy = $scope.ModifiedBy;
        //           $scope.modelR.InventoryTransactionItems = itemss;
        //           $scope.modelR.OperationType = 2;
        //           //  $scope.modelR.DSNumber = $scope.Indent;

        //           var promise = service.save($scope.modelR);
        //           promise.then(function (data) {

        //               if ($scope.invoices[0].ReceiptID == null || $scope.invoices[0].ReceiptID === "") {
        //                   msg("Receipt Return Successfully Saved.", true);
        //               }
        //               else {
        //                   msg("Receipt Return Successfully Modified.", true);
        //               }

        //               $scope.data = data;
        //               $scope.modelR = {};
        //               $scope.invoices = [];
        //               $scope.Vendors = "";
        //               $scope.VendorAddress = "";
        //               $scope.GRNNO = "";
        //               $scope.Indent = "";
        //               $scope.ReturnDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //               $scope.Remarks = "";
        //               $scope.GRNNumbers = [];
        //               $scope.Remarks = "";
        //               $scope.Reason = "";
        //               test();

        //           });
        //       };
        //       $scope.txtVendorNames = function () {

        //           getGrns($scope.Vendors);
        //           for (var i = 0; i < $scope.Vendors.length; i++) {
        //               if ($scope.Vendors === $scope.Vendors[i].Id) {
        //                   $scope.VendorAddress = $scope.Vendors[i].Address1 + $scope.Vendors[i].City;
        //                   break;
        //               }
        //           }
        //       };

        //       function getGrns(vendorid) {

        //           var promise = service.getGRN($scope.PropertyID, $scope.DateFormat, vendorid);
        //           promise.then(function (data) {

        //               $scope.GRNNumbers = data.Collection;
        //           });
        //       }
        //       $scope.txtGRNNO = function () {

        //           $scope.invoices = [];
        //           var promise = service.get($scope.PropertyID, $scope.DateFormat, $scope.GRNNO);
        //           promise.then(function (data) {
        //               if (!data.Data) {
        //                   msg("Quantity not available for this GRN");
        //                   return;
        //               }
        //               $scope.MinReturnDate = dateAdd(data.Data.TransactionDateString, 'day', -1, $filter);               //$scope.MinReturnDate = $filter("date")(dateAdd(data.Data.TransactionDateString, 'day', -1), "yyyy-MM-dd");
        //               $scope.invoices = data.Data.InventoryTransactionItems;
        //               var index = 0;
        //               angular.forEach($scope.invoices, function (item) {


        //                   item.DiscountInId = item.DiscountIn.toString();
        //                   item.Amount = item.Rate * item.Quantity;
        //                   item.GrossAmount = $scope.GrosssReturn(item.Amount, item.DiscountIn, item.Discount, item.Tax);
        //                   item.ItemNetAmount = $scope.ItemNetAmountReturn(item.Amount ? item.Amount : 0, item.DiscountIn, item.Discount ? item.Discount : 0, item.Tax ? item.Tax : 0);
        //                   item.DiscountOriginal = item.Discount;
        //                   item.QuantityOriginal = item.Quantity;

        //                   $scope.calculateAmountItemReturn(index++);//2017-02-09 10:33
        //               });
        //           });

        //       }
        //       $scope.resetreturn = function () {
        //           $scope.invoices = [];
        //           $scope.Vendors = "";
        //           $scope.VendorAddress = "";
        //           $scope.Indent = "";
        //           $scope.ReturnDate = $filter("date")($scope.ModifiedDate, $scope.DateFormat);
        //           $scope.Remarks = "";
        //           $scope.GRNNumbers = [];
        //           $scope.Remarks = "";
        //           $scope.Reason = "";

        //           scrollPageOnTop();
        //       }

        //       $scope.Grosss = 0;
        //       $scope.GrosssReturn = function (amount, DiscountIn, Discount, Tax) {
        //           $scope.Grosss = parseFloat(amount) + parseFloat(Tax | 0);
        //           $scope.Grosss = $filter('number')($scope.Grosss, 2);
        //           return $scope.Grosss.replace(/,/g, '');
        //       };

        //       $scope.AmountReturns = 0;
        //       $scope.ItemNetAmountReturn = function (amount, DiscountIn, Discount, Tax) {

        //           if (DiscountIn === 2) {
        //               $scope.AmountReturns = parseFloat(amount) + parseFloat(Tax) - parseFloat(((amount) * (Discount)) / 100);
        //           } else {
        //               $scope.AmountReturns = parseFloat(amount) + parseFloat(Tax) - parseFloat(Discount);
        //           }
        //           $scope.AmountReturns = $filter('number')($scope.AmountReturns, 2);
        //           return $scope.AmountReturns.replace(/,/g, '');
        //       };
        //       $scope.TotalAmountsRetrun = function () {
        //           var total = 0.00;
        //           if ($scope.invoices.length > 0) {
        //               angular.forEach($scope.invoices, function (item) {
        //                   total += parseFloat(item.Amount ? item.Amount : 0);
        //               });
        //           }
        //           total = $filter('number')(total, 2);
        //           return total.replace(/,/g, '');
        //       };
        //       $scope.TotalDiscountsReturn = function () {

        //           var total = 0;
        //           angular.forEach($scope.invoices, function (item) {
        //               total += parseFloat(item.DiscountAmount ? item.DiscountAmount : 0);
        //               //if (item.DiscountIn === "Percent" || item.DiscountInId === "2") {
        //               //    total += parseFloat((parseFloat(item.Amount ? item.Amount : 0) * parseFloat(item.Discount ? item.Discount : 0)) / 100);
        //               //} else {
        //               //    total += parseFloat(item.Discount ? item.Discount : 0);
        //               //}
        //           });
        //           total = $filter('number')(total, 2);
        //           $scope.TotalDiscounts = total;
        //           return $scope.TotalDiscounts.replace(/,/g, '');
        //       };
        //       $scope.TotalTaxsReturn = function () {
        //           var total = 0;
        //           angular.forEach($scope.invoices, function (tax) {
        //               //  total += parseFloat(tax.Tax ? tax.Tax : 0);
        //               total += parseFloat(tax.TaxAmount ? tax.TaxAmount : 0);
        //           });
        //           total = $filter('number')(total, 2);
        //           $scope.TotalTaxs = total;
        //           return $scope.TotalTaxs.replace(/,/g, '');
        //       };
        //       $scope.NetAmountsReturn = function () {
        //           //
        //           var total = 0;
        //           angular.forEach($scope.invoices, function (item) {
        //               // total += parseFloat(item.ItemNetAmount ? item.ItemNetAmount : 0);
        //               total += parseFloat(item.NetAmount ? item.NetAmount : 0);               //total += (parseFloat(item.Amount ? item.Amount : 0) - parseFloat(item.Discount ? item.Discount : 0) + parseFloat(item.TaxAmount ? item.TaxAmount : 0));
        //           });
        //           total = $filter('number')(total, 2);
        //           $scope.NetAmounts = total;
        //           return $scope.NetAmounts.replace(/,/g, '');
        //       };

        //       $scope.calculateAmountItemReturn = function (index) {

        //           if ($scope.invoices[index].Quantity > $scope.invoices[index].QuantityOriginal) {
        //               msg("Quantity refund not more than" + $scope.invoices[index].QuantityOriginal);
        //               $scope.invoices[index].Quantity = $scope.invoices[index].QuantityOriginal;
        //           }
        //           angular.forEach($scope.invoices, function (item, i) {

        //               if (i === index) {
        //                   item.Amount = item.Rate * item.Quantity; //1
        //                   item.Amount = $filter('number')(item.Amount, 2);
        //                   item.Amount = item.Amount.replace(/,/g, '');

        //                   if (item.DiscountInName === "Amount") {
        //                       item.Discount = $filter('number')(((parseFloat(item.DiscountOriginal) / parseFloat(item.QuantityOriginal)) * parseFloat(item.Quantity)), 2);
        //                   }
        //                   item.DiscountAmount = item.DiscountInName === "Amount" ? item.Discount : item.Amount * item.Discount * .01;//2
        //                   item.GrossAmount = item.Amount - item.DiscountAmount;//3

        //                   item.TaxAmount = 0;
        //                   for (var q = 0; q < $scope.TaxStructure.length; q++) {
        //                       if ($scope.TaxStructure[q].Id === item.TaxStructureId) {
        //                           var linkedTax = $scope.TaxStructure[q].LinkTaxStructures;
        //                           for (var p = 0; p < linkedTax.length; p++) {
        //                               var taxOn = 0;
        //                               switch (linkedTax[p].TaxOnId) {
        //                                   case 1: taxOn = item.Amount; break;
        //                                   case 2: taxOn = item.GrossAmount; break;
        //                               }
        //                               item.TaxAmount += linkedTax[p].TaxIn == "Amount" ? linkedTax[p].TaxValue : taxOn * linkedTax[p].TaxValue * 0.01;//4
        //                           }
        //                           break;
        //                       }
        //                   }
        //                   item.NetAmount = item.GrossAmount + item.TaxAmount;//5

        //                   $scope.TotalAmountsRetrun();
        //                   $scope.TotalDiscountsReturn();
        //                   $scope.TotalTaxsReturn();
        //                   $scope.NetAmountsReturn();

        //               }
        //           });
        //       };
        //       $scope.changeCostCenter = function (item) {
        //           if (item.cccount)
        //               msg('You are changing cost center.');
        //           item.cccount = true;
        //       };
        //       $scope.send=function(sms){

        //           service.send($scope.PropertyID,$scope.Model.Id,sms)
        //               .then(function (s) {
        //                   if (s) {
        //                       msg(s.Message, true);
        //                   }
        //               }, function (e) {
        //                   msg(e.Message);
        //               });
        //       };

        //       $scope.htmlASBreceive = `<p>
        //           <div class="row">
        //       <div class="col-md-4"><strong>Transaction Type : </strong> <span>Receipt</span> </div>
        //       <div class="col-md-4"><strong>Transaction Date : </strong> <span>{{model.TransactionDateString|date:DateFormat}}</span> </div>
        //       <div class="clearfix"></div>
        //                                <div class="clearfix"></div>
        //                            <div class="clearfix"></div>

        //                            <div class="row margin-top-15">
        //                                <div class="col-md-12">
        //                                    <div class="table-responsive">
        //                                        <table class="table table-hover table-striped" style="width:100% !important;">
        //                                            <thead>
        //                                                <tr>
        //                                                    <th>SNo</th>
        //                                                    <th>Item</th>
        //                                                    <th>Brand</th>
        //                                                    <th>UoM</th>
        //                                                    <th>Qty</th>
        //                                                    <th>Cost Conter</th>
        //                                                </tr>
        //                                            </thead>
        //                                            <tbody>
        //                                                <tr data-ng-repeat="item in invoice">
        //                                                    <td>{{$index+1}}</td>
        //                                                    <td>{{item.InventoryItemName}}</td>
        //                                                    <td>{{item.BrandId}}</td>
        //                                                    <td>{{item.UnitOfMeasurementName}}</td>
        //                                                    <td>{{item.Quantity}}</td>
        //                                                    <td>{{item.CostCenterId}}</td>
        //                                                </tr>
        //                                            </tbody>
        //                                        </table>
        //                                    </div>
        //                                </div>
        //                            </div>
        //                            <div class="clearfix"></div>
        //                            <br /><br />
        //                        </p>`;
    }
]);
