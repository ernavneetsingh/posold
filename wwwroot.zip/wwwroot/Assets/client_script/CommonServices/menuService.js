﻿
(function () {
    'use strict';
    var accesstoken = sessionStorage.getItem('accessToken');

    function manuModuleService($http, $q) {

        var IsProgress = false;
        var linkItem = [];

        function logoutRequest() {
            return httpPoster(apiPath + 'login.aspx/LogoutRequest', $http, $q);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + 'login.aspx/LogoutRequest',
            //    data: {
            //    },
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    success: function (response) {
            //        deferred.resolve(response);
            //    },
            //    error: function (error, status, headers, config) {
            //        deferred.reject(error, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        }

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        function changePassword(model) {
            var url = apiPath + 'Security/ChangePassword';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var getSearch = function (model) {
            return httpPoster(apiPath + "GlobalSetting/Notification/Search", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "GlobalSetting/Notification/Search",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {

            //        angular.copy(data.Collection, linkItem);
            //        deferred.resolve(data.RecordCount);
            //        //deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        linkItem = [];
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;

        };

        var changeStatusNotification = function (model) {

            var url = apiPath + 'GlobalSetting/Notification/ChangeStatus';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;


        };
        var getPageHelp = function (id) {
            return httpCaller(apiPath + "configuration/ModulePageHelp/GetAllByUserProductPageId/" + id, $http, $q);
        };

        var searchByTag = function (tag) {
            return httpCaller(apiPath + "configuration/ModulePageHelp/GetAllByTag", $http, $q, { tag: tag });
        };

        var getPageActionKeys = function (id) {
            return httpCaller(apiPath + "AdminConfiguration/Role/GetPageActionKeysByRoleModulePageId/" + id, $http, $q);
        };

        var service = {
            //moduleRequest: moduleRequest,
            //getPageTitle: getPageTitle,
            //getPages: getPages,
            //getAllModule: getAllModule,

            dataAllData: linkItem,

            logoutRequestFor: logoutRequest,
            changePassword: changePassword,
            getSearch: getSearch,
            changeStatusNotification: changeStatusNotification,

            getProgress: function () {
                return IsProgress;
            },
            setProgress: function (value) {
                IsProgress = value;
            },
            getPageHelp: getPageHelp,
            searchByTag: searchByTag,
            getPageActionKeys: getPageActionKeys
        };

        return service;
    }

    app.factory('manuService', ['$http', '$q', manuModuleService]);
})();
