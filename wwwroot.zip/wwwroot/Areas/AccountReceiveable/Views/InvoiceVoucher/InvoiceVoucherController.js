﻿
app.controller('InvoiceVoucherController',
    function ($scope, $http, $filter, $window, invoiceVoucherService, $cookies, transactionService, localStorageService) {
        //TODO navneetmanoj

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.CurrentDate = $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' + $scope.BusinessDate.Day;

        $scope.resetSearch = function () {
            $scope.Search = {};
        }
        $scope.resetHistory = function () { }
        $scope.resetCompany = function () {
            $scope.Company = {};
        }
        $scope.resetInvoices = function () {
            $scope.Invoices = [];
        }
        $scope.resetBills = function () {
            $scope.Bills = $scope.newBills;
        }
        $scope.resetVouchers = function () {
            $scope.Transactions = [];
        }
        $scope.resetAll = function () {
            $scope.resetSearch();
            $scope.resetHistory();
            $scope.resetCompany();
            $scope.newBills = [];
            $scope.resetBills();
            $scope.resetInvoices();
            $scope.resetVouchers();
        }
        $scope.resetAll();

        $scope.getAutoSuggest = function (item, txt) {
            var promiseSuggest = transactionService.suggest($scope.PropertyID, item, txt);
            promiseSuggest.then(function (data, status) {
                $('#txtSearch' + item).autocomplete({
                    source: function (request, response) {
                        response($.map(data.Data.Suggestions, function (ret) {
                            return {
                                label: ret //.split(':')[0]
                                ,
                                val: ret.split(':')[0]
                            }
                        }));
                    },
                    select: function (e, ui) {

                        if (ui.item) {
                            var promiseSearch = transactionService.search($scope.PropertyID, item, ui.item.val, $scope.DateFormat);
                            promiseSearch.then(function (data, status) {

                                $scope.load(data, item);
                            });
                        }
                    },
                    minLength: 1
                });
            });
        };
        $scope.load = function (data, searchType) {
            if (searchType && searchType !== 'CompanyType') {
                $scope.Company = data.Data;
                $scope.newBills = $scope.Bills = data.Data.UnInvoicedBills;
                $scope.Invoices = data.Data.Invoices;
                $scope.Transactions = data.Data.Transactions;

            }
            $scope.History = data.Data.History;
        };
        $scope.recent = function () {
            $scope.resetBills();
            $scope.resetInvoices();
            var promise = transactionService.search($scope.PropertyID, 'CorporateId', $scope.Company.Id, $scope.DateFormat);
            promise.then(function (data, status) {

                $scope.load(data, 'any');
            });
        };

        $scope.save = function () {
            var billDetail = [];
            for (var i = 0; i < $scope.Bills.length; i++) {
                if ($scope.Bills[i].IsSelectedInInvoice) {
                    billDetail.push($scope.Bills[i]);
                }
            }
            if (billDetail.length < 1) {
                msg('Error! Please select bills to save');
                return;
            }


            var promise = invoiceVoucherService.save(billDetail, $scope.PropertyID, $scope.ModifiedBy, $scope.CurrentDate);
            promise.then(function (data) {

                if (data.Data === '0') {
                    msg('Invoice Successfully Saved!', true);
                } else {
                    msg('Invoice Successfully Modified!', true);
                    $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                }
                $scope.recent();
            });
        };

        $scope.EditInvoice = function (invoiceId) {

            $scope.resetBills();
            var promise = invoiceVoucherService.get(invoiceId, $scope.PropertyID, $scope.DateFormat);
            promise.then(function (data) {

                if (data != null) {

                    $scope.Bills = $scope.newBills.concat(data.Collection);
                    angular.forEach($scope.Bills, function (value, key) {

                        value.InvoiceId = invoiceId;
                    });
                }
            });

        };
        $scope.DeleteInvoice = function (invoiceId) {
            var strDelete = DeletePopup('Are you sure you want to delete this invoice?');
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $('#fancyconfirm_cancel')
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $('#fancyConfirm_ok')
                        .click(function () {
                            ret = true;
                            $.fancybox.close();
                            var promise = invoiceVoucherService.delete(invoiceId, $scope.PropertyID);
                            promise.then(function (data) {
                                if (data != null) {

                                    msg('Record Successfully Deleted', true);
                                    $scope.recent();
                                }
                            });
                        });
                }
            });
        };
        $scope.printInvoice = function (invoiceId) {

            //$scope.resetBills();
            invoiceVoucherService.MapReport($scope.PropertyID, 'invoice_voucher')
                 .then(function (s) {
                     $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + invoiceId, '_blank');
                 }, function (e) {
                     msg('Error in mapping to print.');
                 }).finally(function () {
                     //$scope.reset();
                 });
        };

    });
