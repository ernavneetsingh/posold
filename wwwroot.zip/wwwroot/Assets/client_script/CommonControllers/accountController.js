﻿"use strict";
var registation = registation;

app.controller("accountController", ["$scope", "$cookies", "$filter", "$window", "accountService", "localStorageService",
function ($scope, $cookies, $filter, $window, accountService, localStorageService) {
    RestCookies();
    $scope.Company = {};
    GetCompany();
    function GetCompany() {
        var promise = accountService.getCompany();
        promise.then(function (data, status) {
            $scope.Company = data.Data;
            $cookies.putObject('Company', data.Data);
            $scope.Copyright = "Copyright © 2014-";
        },
        function (error) {
            parent.failureMessage(error.Message);
        });
    };

    $scope.LoginProcessing = false;

    $scope.Model = {
        UserName: "",
        Password: "",
        RememberMe: false
    };

    $scope.LoginShowErrorMessage = false;
    function getUrlParameter(param, dummyPath) {
        var sPageURL = dummyPath || window.location.search.substring(1),
            sURLVariables = sPageURL.split(/[&||?]/),
            res;
        for (var i = 0; i < sURLVariables.length; i += 1) {
            var paramName = sURLVariables[i],
                sParameterName = (paramName || '').split('=');
            if (sParameterName[0] === param) {
                res = sParameterName[1];
            }
        }
        return res;
    }
    $scope.PropertyID = '';
    $scope.LoginPropertys = [];
    $scope.GoToProperty = function (id) {
        
        angular.forEach($scope.LoginPropertys, function (item) {
            if (id == item.Id) {
                localStorageService.set('PropertyId', item.Id);
                localStorageService.set('PropertyName', item.Name);
                localStorageService.set('PropertyCity', item.City);
                localStorageService.set('PropertyStateId', item.StateId);
                localStorageService.set('PropertyCountryId', item.CountryId);
                localStorageService.set('DateFormat', item.DateFormat);
                var mDate = GetMomentDate(item.BusinessDate, 'YYYY-MM-DD')
                var businessDate = {
                    Year: mDate.format('YYYY'),
                    Month: mDate.format('MM'),
                    Day: mDate.format('DD'),
                };
                localStorageService.set('BusinessDate', businessDate);
                localStorageService.set('FOShiftId', item.FOShiftId);
                localStorageService.set('FOShiftNo', item.FOShiftNo);
                localStorageService.set('FOShiftDate', item.FOShiftDate);
            }
        });

        $scope.PropertyID = localStorageService.get('PropertyId');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.IsCashier = localStorageService.get('IsCashier');

        if ($scope.IsCashier == 'true') {
            var promiseGet = accountService.getLastShift({ PropertyID: $scope.PropertyID, UserName: $scope.ModifiedBy });
            promiseGet.then(function (data) {
                if (data.Status) {

                    if (data.Data.IsActive) {
                        window.location.href = "FO/Dashboard"
                    }
                    else {
                        window.location.href = "FO/Operation/FOShift"
                    }
                }
                $scope.LoginProcessing = false;
                return true;
            },
            function (error) {
                $scope.LoginProcessing = false;
                parent.failureMessage(error.Message);
                $scope.LoginShowErrorMessage = true;
            });
            return;
        }
        if ($scope.PropertyID.length > 0) {
            window.location.href = "FO/Dashboard"
        }

    };
    $scope.LoginRequest = function (model, form) {
        //
        //if (($scope.Latitude == "") && ($scope.Longitude == ""))
        //{
        //    parent.failureMessage("Please share your location.");
        //    nearme();
        //    return;
        //}

        if ($scope[form].$valid) {
            $scope.LoginProcessing = true;
            $scope.Model.UserName = model.UserName;
            $scope.Model.Password = model.Password;
            $scope.LoginPropertys = [];

            var promiseGet = accountService.loginRequest($scope.Model);
            promiseGet.then(function (data) {
                if (data.Status) {

                    //store cookies
                    $cookies.put('LoginId', data.Data.LoginId);
                    $cookies.put('UserName', data.Data.UserName);
                    $cookies.put('FirstName', data.Data.FirstName);
                    $cookies.put('LastName', data.Data.LastName);
                    $cookies.put('UserProfile', data.Data.UserProfile);
                    $cookies.put('accessToken', data.Data.access_Token);
                    var jsonObj = JSON.stringify(data.Data.Propertys);
                    localStorageService.set("LoginPropertys", jsonObj);
                    var jsonObjPages = JSON.stringify(data.Data.RoleModulePages);
                    localStorageService.set("RoleModulePages", jsonObjPages);
                    localStorageService.set("UserId", data.Data.LoginId);
                    localStorageService.set("IsCashier", data.Data.IsCashier);
                    //localStorageService.set("UserName", data.Data.UserName);


                    if (data.Data.UserProfile == "1")   //Supper Admin
                    {
                        window.location.href = "/super/admin/configuration/module";
                    }
                    else {
                        if (data.Data.Propertys.length > 1) {
                            $scope.LoginPropertys = data.Data.Propertys;
                            angular.forEach($scope.LoginPropertys, function (item) {

                                var mDate = GetMomentDate(item.BusinessDate, 'YYYY-MM-DD')
                                var businessDate = {
                                    Year: mDate.format('YYYY'),
                                    Month: mDate.format('MM'),
                                    Day: mDate.format('DD'),
                                };
                                localStorageService.set('BusinessDate', businessDate);
                                item.BusinessDateForDisplay = $filter('date')(item.BusinessDate, item.DateFormat);
                            });
                        }
                        else {



                            $scope.LoginPropertys = [];
                            var prop = {
                                //Id: data.Data.Propertys[0].Id,
                                Id: data.Data.Propertys[0].Id,
                                Name: data.Data.Propertys[0].Name,
                                City: data.Data.Propertys[0].City,
                                StateId: data.Data.Propertys[0].StateId.toString(),
                                CountryId: data.Data.Propertys[0].CountryId.toString(),
                                DateFormat: data.Data.Propertys[0].DateFormat,
                                BusinessDate: data.Data.Propertys[0].BusinessDate,

                                FOShiftId: data.Data.Propertys[0].FOShiftId,
                                FOShiftNo: data.Data.Propertys[0].FOShiftNo,
                                FOShiftDate: data.Data.Propertys[0].FOShiftDate,

                            };

                            var mDate = GetMomentDate(prop.BusinessDate, 'YYYY-MM-DD')
                            var businessDate = {
                                Year: mDate.format('YYYY'),
                                Month: mDate.format('MM'),
                                Day: mDate.format('DD'),
                            };
                            localStorageService.set('BusinessDate', businessDate);


                            $scope.LoginPropertys.push(prop);
                            $scope.GoToProperty(data.Data.Propertys[0].Id);

                        }
                    }
                }
                else {
                    parent.failureMessage(data.Message);
                }
                $scope.LoginProcessing = false;
                return true;
            },
            function (error) {
                $scope.LoginProcessing = false;
                parent.failureMessage(error.Message);
                $scope.LoginShowErrorMessage = true;
            });
        } else {
            $scope.LoginShowErrorMessage = true;
        }
    };
    $scope.back = function () {
        var url = Path + "login.html";
        window.location.href = url;
    };
    function RestCookies() {
        localStorageService.clearAll();
        $cookies.remove('LoginId');
        $cookies.remove('UserName');
        $cookies.remove('FirstName');
        $cookies.remove('LastName');
        $cookies.remove('UserProfile');
        $cookies.remove('accessToken');
        $cookies.remove('LoginPropertys');
        $cookies.remove('RoleModulePages');
        $cookies.remove('PropertyId');
        $cookies.remove('PropertyName');
        $cookies.remove('PropertyCity');
        $cookies.remove('PropertyStateId');
        $cookies.remove('PropertyCountryId');

        $cookies.remove('DateFormat');
    };
    var mysrclat = 0; var mysrclong = 0;
    $scope.Latitude = "";
    $scope.Longitude = "";
    $scope.Location = "";
    function nearme() {

        if (navigator.geolocation) {
            parent.failureMessage("Please share your location.");
            navigator.geolocation.getCurrentPosition(function (position) {

                mysrclat = position.coords.latitude;
                mysrclong = position.coords.longitude;
                $scope.Latitude = mysrclat;
                $scope.Longitude = mysrclong;
                $scope.Location = "Your Location - Latitude: " + mysrclat + "  Longitude: " + mysrclong;
                GetAddress();
            });

        }
    };
    function GetAddress() {

        var promise = accountService.getAddress($scope.Latitude, $scope.Longitude);
        promise.then(function (data, status) {

            $scope.Address = data.Data;
            $cookies.putObject('Company', data.Data);
            nearme();
        },
        function (error) {
            parent.failureMessage(error.Message);
        });
    };
    $scope.ForgotRequest = function (forgotModel, form) {

        if ($scope[form].$valid) {
            $scope.Model.Email = forgotModel.Email;
            var promiseGet = accountService.forgotRequest($scope.Model);
            promiseGet.then(function () {
                parent.successMessage("Please reset your password.");
                window.location.href = "login.html";
            },
            function (error) {
                parent.failureMessage(error.Message);
            });
        } else {
            $scope.ForgotErrorMessage = true;
        }
    };

}]);
