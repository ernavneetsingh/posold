﻿
app.controller('DocumentCenterController',
[
    '$scope', '$http', '$q', 'localStorageService', '$cookies', 'DocumentCenterService',
    function ($scope, $http, $q, localStorageService, $cookies, documentCenterService) {

        initCommon($scope, $http, $q, localStorageService, $cookies);

        $scope.getGuestList = function () {
            documentCenterService.getGuestList($scope.PropertyID)
                .then(function (s) {
                    $scope.GuestList = s.Collection;
                });
        };
        $scope.getDocumentTypeList = function () {
            documentCenterService.getDocumentTypeList($scope.PropertyID)
                .then(function (s) {
                    $scope.DocumentTypeList = s.Collection;
                });
        };

        $scope.save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.ExpiryDateString = $scope.model.ExpiryDateString || $scope.ModifiedDate;

            documentCenterService.save($scope.model)
                .then(function (result) {
                    if (result.Status == true) {
                        msg(result.Message, true);
                        $scope.reset();
                    }
                    $scope.Reset();
                }, function (error) {
                    msg(error.Message);
                });
        };
        $scope.getAll = function () {

            var sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder == null) {
                sortKeyOrder = {
                    key: "Name",
                    order: "ASC"
                };
            }

            var searchfor = localStorageService.get("searchfor");
            $scope.sortKeyOrder = sortKeyOrder;
            var options = {
                propertyId: $scope.PropertyID,
                currentPage: $scope.currentPage,
                recordsPerPage: $scope.recordsPerPage,
                sortKey: sortKeyOrder.key,
                sortOrder: sortKeyOrder.order,
                searchfor: searchfor || ''
            };
            $scope.showLoader = true;
            documentCenterService.getAll(options)
                  .then(function (s) {
                      $scope.data = s.Collection;
                      $scope.totalItems = s.RecordCount;
                      $scope.showLoader = false;
                  }, function () {
                      msg("The request failed. Unable to connect to the remote server.");
                  });

        };
        $scope.reset = function () {

            $scope.model = { IsActive: true, IsExpiry: true };
            $scope.IsEdit = false;
            $scope.search();
        };
        $scope.fillRecord = function (record) {

            $scope.model = record;
            $scope.IsEdit = true;
            msg('');
        };
        $scope.remove = function (model) {
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        documentCenterService.delete(model.Id)
                            .then(function (s) {

                                msg("Record Successfully deleted.", true);
                                $scope.reset();
                            });
                        $.fancybox.close();
                    });
                }
            });
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            $scope.getAll();
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            $scope.getAll();
        };
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            $scope.getAll();
        }

        $scope.getGuestList();
        $scope.getDocumentTypeList();
        $scope.reset();
    }
]);
