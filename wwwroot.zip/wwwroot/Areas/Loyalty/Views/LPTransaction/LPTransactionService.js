﻿
app.service('LPTransactionService', [
    '$http', '$q', function (
        $http, $q) {

        this.getAllPOSCustomer = function (propertyId) {
            return httpCaller(apiPath + "Loyalty/POSCustomer/AllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getAllTransactionType = function () {
            return httpCaller(apiPath + "ReferenceConstant/TransactionType/All", $http, $q);
        };
        this.getAll = function (options) {
            return httpCaller(apiPath + "Loyalty/LPTransaction/GetAll", $http, $q, options);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "Loyalty/LPTransaction/Save", $http, $q, model);
        };

    }
]);
