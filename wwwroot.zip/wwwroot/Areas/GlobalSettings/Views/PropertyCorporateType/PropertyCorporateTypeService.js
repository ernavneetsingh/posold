﻿"use strict";


(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var model = [];

        

        var getCorporateTypeDefinition = function () {

            var url = apiPath + 'referencedata/CorporateType';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllPropertyCorporateType = function (propertyId) {

            var url = apiPath + 'GlobalSetting/PropertyCorporateType/GetAll/?propertyId=' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {
            var url = apiPath + 'GlobalSetting/PropertyCorporateType/Save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }

        return {
            dataModel: model,
            getAllPropertyCorporateType: getAllPropertyCorporateType,
            getCorporateTypeDefinition: getCorporateTypeDefinition,
            save: save
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();

