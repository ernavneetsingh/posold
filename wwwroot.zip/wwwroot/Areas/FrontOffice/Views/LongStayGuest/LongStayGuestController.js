﻿
app.controller('LongStayGuestController', [
    '$scope', '$cookies', 'localStorageService', '$timeout', '$window', function (
        $scope, $cookies, localStorageService, $timeout, $window) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        $scope.SelectedProperties = [];
        $scope.MasterSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };

        $scope.loadReport = function (reportId) {
            if (!$scope['myform'].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            //if ($scope.DateFromString.length > 1 && $scope.DateToString.length > 1 && $scope.DateFromString > $scope.DateToString) {
            //    msg('Please select valid dates.');
            //    return;
            //}
            var props = '';
            $scope.SelectedProperties.forEach(function (p) {
                props += p.Id + ",";
            });
            var pwin = $window.open($window.Path + 'Reporter/ReportViewer?id=' + reportId + '&p=1&@props=' + props + '&StayDays=' + $scope.StayDays + '&@criteria=' + $scope.model.Param, '_blank', 'width=1000,height=700');

        };

    }
]);
