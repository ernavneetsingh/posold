﻿ 
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.LoginId = $cookies.get('LoginId');

        
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            UnitOfMeasurementFromId: '',
            UnitOfMeasurementFromName: '',
            UnitOfMeasurementFromUnitTypeId: '',
            UnitOfMeasurementFromUnitTypeName: '',
            UnitOfMeasurementToId: '',
            UnitOfMeasurementToName: '',
            UnitOfMeasurementToUnitTypeId: '',
            UnitOfMeasurementToUnitTypeName: '',
            ConversionValue: '',
            PropertyID: '',
            ModifiedBy: '',
            UnitConversions: []
        };

        $scope.UnitConversions = [];
        $scope.IsVisible = true;

        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        getData();

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "UnitOfMeasurementFromName" || attr === "UnitOfMeasurementToName") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        function getData() {
            $scope.ActionMode = "";
            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Model.items = data;
                $scope.search();
            }, function (data) {
                msg(data.message);
            });
        };

        $scope.UnitTypes = [];
        GetAllUnitType();
        function GetAllUnitType() {

            var temp = $scope.PropertyID;
            var promiseGet = service.getAllUnitType();
            promiseGet.then(function (data) {
                $scope.UnitTypes = data;
            }, function (data) {
                msg(data.message);
            });
        }

        $scope.UnitOfMeasurementFroms = [];
        $scope.GetSelectUnit = function (id) {
            var temp = $scope.PropertyID;
            var promiseGet = service.getSelectUnit($scope.PropertyID, id);
            promiseGet.then(function (data) {
                $scope.UnitOfMeasurementFroms = data;
                $scope.GetUnitOfMeasurementTo(id);
            }, function (data) {
                msg(data.message);
            });
        }
        $scope.UnitOfMeasurementTos = [];
        $scope.GetUnitOfMeasurementTo = function (id) {

            $scope.toList = [];

            angular.forEach($scope.UnitOfMeasurementFroms, function (x) {
                if (id != x.Id)
                    $scope.toList.push(x);
            });
            $scope.UnitOfMeasurementTos = $scope.toList;
        };

        $scope.delete = function () {
            binduomfactoruom();
        };
        $scope.Save = function (model, form) {
            
            if (!$scope.UnitConversions || $scope.UnitConversions.length < 1) {
                msg("Please add some unit conversions");
                return;
            }
            var status = service.save($scope.UnitConversions);
            status.then(function (result) {
                
                if (result.Status == true) {
                    var msg = "Unit Conversion " + result.Message;
                    parent.successMessage(msg);
                    getData();
                }
                $scope.Reset();
            }, function (error) {
                
                scrollPageOnTop();
                msg(error.Message);
            });

            //if ($scope[form].$valid) {

            //} else {
            //    $scope.ShowErrorMessage = true;
            //}

            //$scope.model.ApplicableFromDate = '';
        }
        $scope.Remove = function (model) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            

                            msg("Record Successfully deleted.", true);
                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }

        $scope.SelectedUnitTypeId = "";
        $scope.ActionMode = "";
        $scope.Edit = function (model) {
            $scope.ActionMode = "Edit";
            $scope.Reset();
            $scope.Model.Id = model.Id;
            $scope.Model.UnitTypeId = model.UnitOfMeasurementFromUnitTypeId.toString();
            $scope.GetSelectUnit($scope.Model.UnitTypeId);            //$scope.GetUnitOfMeasurementTo(model.UnitOfMeasurementFromId);
            $scope.Model.ConversionValue = model.ConversionValue;
            $scope.Model.ApplicableFrom = $filter('date')(model.ApplicableFrom, $scope.DateFormat);
            $scope.Model.IsActive = model.IsActive;

            scrollPageOnTop();

            $scope.Model.UnitOfMeasurementFromId = model.UnitOfMeasurementFromId;
            $scope.Model.UnitOfMeasurementToId = model.UnitOfMeasurementToId;
            //$scope.addConversion('form', 'dontCheck');
            //$scope.UnitConversions.push($scope.Model);
        }
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.UnitConversions = [];
            $scope.Model = {};
            $scope.query = "";
            $scope.Model.IsActive = true;
            getData();
            scrollPageOnTop();
        }
        $scope.addConversion = function (form, dontCheck) {
            
            var st = $scope[form].$valid;
            if (dontCheck || st === true) {
                var conversionValue = $scope.Model.ConversionValue;

                if (conversionValue === 0) {
                    scrollPageOnTop();
                    msg('Conversion Value is greater then 0.');
                    return;
                }

                var fromName = "";
                var toName = "";

                var i;
                for (i = 0; i < $scope.UnitOfMeasurementFroms.length; i++) {
                    if ($scope.UnitOfMeasurementFroms[i].Id === $scope.Model.UnitOfMeasurementFromId) {
                        fromName = $scope.UnitOfMeasurementFroms[i].Name;
                    }
                }
                for (i = 0; i < $scope.UnitOfMeasurementTos.length; i++) {
                    if ($scope.UnitOfMeasurementTos[i].Id === $scope.Model.UnitOfMeasurementToId) {
                        toName = $scope.UnitOfMeasurementTos[i].Name;
                    }
                }

                $scope.UnitConversions.push({
                    Id: $scope.Model.Id,
                    UnitOfMeasurementFromId: $scope.Model.UnitOfMeasurementFromId,
                    UnitOfMeasurementFromName: fromName,
                    UnitOfMeasurementToId: $scope.Model.UnitOfMeasurementToId,
                    UnitOfMeasurementToName: toName,
                    ConversionValue: $scope.Model.ConversionValue,
                    PropertyID: $scope.PropertyID,
                    ModifiedBy: $scope.ModifiedBy
                });

                $scope.Model.Id = "";
                $scope.Model.UnitOfMeasurementFromId = "";
                $scope.Model.ConversionValue = "";
                $scope.Model.UnitOfMeasurementToId = "";
            } else {
                $scope.ShowErrorMessage = true;
            }

        };
        $scope.removeConversion = function (index) {
            $scope.UnitConversions.splice(index, 1);
        };

    }
]);
