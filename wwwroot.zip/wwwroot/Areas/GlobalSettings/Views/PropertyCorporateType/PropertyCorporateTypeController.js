﻿
app.controller('CorporateTypeCtrl', function ($scope, $filter, $cookies, $window, service, localStorageService) {

    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedBy = $cookies.get('UserName');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    $scope.LoginId = $cookies.get('LoginId');

    //var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
    //$scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
    //$scope.MinDatess = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
    //$scope.ApplicableFrom = $filter('date')(new Date(), $scope.DateFormat);

    $scope.MsgNotFound = "";
    $scope.sortingOrder = "Name";
    $scope.pageSizes = [5, 10, 25, 50];
    $scope.reverse = false;
    $scope.filteredItems = [];
    $scope.groupedItems = [];
    $scope.itemsPerPage = 10;
    $scope.pagedItems = [];
    $scope.currentPage = 0;
    $scope.items = [];

    $scope.CorporateType = {};
    $scope.CorporateType.ApplicableFrom = $filter('date')($scope.ModifiedDate, $scope.DateFormat);

    getCompanyTypeDefinition();
    getCompanyTypeDetails();

    $scope.ShowErrorMessage = false;

    $scope.save = function (form) {
        
        if (!$scope[form].$valid) {
            $scope.ShowErrorMessage = true;
            return;
        }
        var typeId = $scope.CorporateType.CorporateTypeId;
        var applicableDate = $scope.CorporateType.ApplicableFrom;

        if (applicableDate == null || applicableDate === "") {
            parent.failureMessage("Please select Date ");
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
            return;
        }
        if (typeId == null || typeId === "") {
            parent.failureMessage("Please select Type Code ");
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
            return;
        }

        $scope.CorporateType.ApplicableFrom = GetServerDate($scope.CorporateType.ApplicableFrom, $scope.DateFormat);

        $scope.CorporateType.PropertyID = $scope.PropertyID;
        $scope.CorporateType.ModifiedBy = $scope.ModifiedBy;
        $scope.CorporateType.ModifiedDate = $scope.ModifiedDate;
        $scope.CorporateType.DateFormat = $scope.DateFormat;

        var promiseGet = service.save($scope.CorporateType);

        promiseGet.then(function (data) {
            //$scope.DefaultSetting = data;
            getCompanyTypeDetails();
            parent.successMessage(data.Message);
        },
        function (data) {
            $scope.CorporateType.ApplicableFrom = GetLocalDate($scope.CorporateType.ApplicableFrom, $scope.DateFormat);
            parent.failureMessage(data.Message);
        });
        scrollPageOnTop();
    };
    $scope.reset = function () {
        $scope.CorporateType = "";
        $scope.query = "";
        //$scope.TypeDefinition = "";
        $scope.search();
    };

    $scope.ChangeType = function () {
        for (var i = 0; i < $scope.CompanyTypeMaster.length; i++) {
            if ($scope.CompanyTypeMaster[i].Id == $scope.CorporateType.CorporateTypeId) {
                $scope.CorporateType.TypeDefinition = $scope.CompanyTypeMaster[i].Description;
            }
        }
    };

    function getCompanyTypeDefinition() {
        var promiseGet = service.getCorporateTypeDefinition();
        promiseGet.then(function (data) {

            $scope.CompanyTypeMaster = data;
        },
        function (data) {
            parent.failureMessage(data.Message);
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        });
    }

    function getCompanyTypeDetails() {
        var promiseGet = service.getAllPropertyCorporateType($scope.PropertyID);
        promiseGet.then(function (data) {

            $scope.items = data;
            $scope.search();
        },
        function (data) {
            parent.failureMessage(data.Message);
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        });
    }
    var searchMatch = function (haystack, needle) {
        if (!needle) {
            return true;
        }
        return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
    };

    // init the filtered items
    $scope.search = function () {

        $scope.filteredItems = $filter("filter")($scope.items, function (item) {
            for (var attr in item) {

                if (attr === "CorporateTypeDescription" || attr === "ApplicableFrom" || attr === "CorporateTypeName" || attr === "CompanyType") {
                    if (searchMatch(item[attr], $scope.query))
                        return true;
                }
            }

            return false;

        });

        // take care of the sorting order
        if ($scope.sortingOrder !== '') {
            $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
        }
        $scope.currentPage = 0;
        // now group by pages
        $scope.groupToPages();
    };
    // show items per page
    $scope.perPage = function () {
        $scope.groupToPages();
    };
    // calculate page in place
    $scope.groupToPages = function () {

        $scope.pagedItems = [];
        $scope.currentPage = 0;
        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage === 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }

        if ($scope.pagedItems.length === 0) {
            $scope.MsgNotFound = "Record Not Found.";
            $scope.pagedItems.length = 1;



        } else {
            $scope.MsgNotFound = "";
        }

    };
    $scope.range = function (start, end) {
        var ret = [];
        if (!end) {
            end = start;
            start = 0;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }
        return ret;
    };
    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };
    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        }
    };
    $scope.firstPage = function () {
        $scope.currentPage = 0;
    };
    $scope.lastPage = function () {
        $scope.currentPage = $scope.pagedItems.length - 1;

    };
    $scope.setPage = function () {
        $scope.currentPage = this.n;
    };
    // change sorting order
    $scope.sort_by = function (newSortingOrder) {
        if ($scope.sortingOrder === newSortingOrder)
            $scope.reverse = !$scope.reverse;

        $scope.sortingOrder = newSortingOrder;
    };


});
