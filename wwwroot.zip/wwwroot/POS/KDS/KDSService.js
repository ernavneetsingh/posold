﻿(function () {

    function service($http, $q) {

        var moduleId = 3;

        var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';

        var GetAllKOTItemStatus = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "ReferenceConstant/KOTItemStatus/all")
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var GetAllKitchen = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/Kitchen/GetAllByActive/?propertyId=" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var GetAllPendingKOT = function (kitchenId, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/KDS/GetAllPendingKOTByKitchenId/" + kitchenId + "/" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        
        var GetAllBumpKOT = function (kitchenId, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/KDS/GetAllBumpKOTByKitchenId/" + kitchenId + "/" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var GetKOTById = function (id, kitchenId) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/KDS/KOT/GetById/" + id + "/" + kitchenId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var BumpKOT = function (model) {
            return httpPoster(apiPath + "PointofSale/KDS/BumpKOT", $http, $q, model);
            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "PointofSale/KDS/BumpKOT",
            //    data: JSON.stringify(model),
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    },
            //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
            //});

        };

        var SaveKOTItemStatus = function (model) {
            return httpPoster(apiPath + "PointofSale/KDS/SaveKOTItemStatus", $http, $q, model);
            //return $.ajax({
            //    type: "POST",
            //    url: apiPath + "PointofSale/KDS/SaveKOTItemStatus",
            //    data: JSON.stringify(model),
            //    dataType: "json",
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8",
            //    success: function () {
            //    },
            //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
            //});

        };

        var SaveDisplayBoard = function (id,outletid) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointofSale/KDS/SaveDisplayBoard/" + id + "/" + outletid)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        return {
            GetAllKitchen:GetAllKitchen,
            GetAllPendingKOT: GetAllPendingKOT,
            GetAllBumpKOT:GetAllBumpKOT,
            GetKOTById: GetKOTById,
            GetAllKOTItemStatus: GetAllKOTItemStatus,
            BumpKOT: BumpKOT,
            SaveKOTItemStatus: SaveKOTItemStatus,
            SaveDisplayBoard: SaveDisplayBoard,

        };
    }
    apppos.factory("service", ["$http", "$q", service]);

})();
