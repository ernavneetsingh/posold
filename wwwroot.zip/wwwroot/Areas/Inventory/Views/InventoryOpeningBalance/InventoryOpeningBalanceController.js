﻿
app.controller("InventoryOpeningBalanceController", [
    "$scope", "$cookies", "localStorageService", "$filter", "inventoryTransactionService", function (
        $scope, $cookies, localStorageService, $filter, inventoryTransactionService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        //var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        //$scope.MaxModelDate = $filter('date')(date, $scope.DateFormat);

        $scope.IsReadonly = false;
        $scope.ShowErrorMessage = false;
        $scope.Save = "Save";
        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";
        $scope.ItemData = [];

        var sortKeyOrder = {
            key: "",
            order: ""
        };
        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }
        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;
        $scope.ResetOpeningMaster = function () {
            $scope.model = {};
            $scope.model.RateType = 0;
            $scope.ItemData = [];
            $scope.IsReadonly = false;
            $scope.Save = "Save";
        }
        $scope.ResetOpeningMaster();
        // getData($scope, inventoryOpeningBalanceService, localStorageService);
        $scope.getOpeningBalances = function () {
            var promise = inventoryTransactionService.getByReference($scope.PropertyID, 6, '');
            promise.then(function (data) {

                $scope.items = data.Collection;
                //$scope.search();
            });
        }
        $scope.getOpeningBalancesByRef = function (ref) {
            if (!ref || ref.length < 1) {
                //msg('You have left reference number blank.');
                return;
            }
            var promise = inventoryTransactionService.getByReference($scope.PropertyID, 6, ref);
            $scope.ItemData = [];
            promise.then(function (data) {

                $scope.ItemData = data.Collection[0].InventoryTransactionItems;
            });
        };

        $scope.getOpeningBalance = function (itemId, brandId, index) {

            for (var i = 0; i < $scope.ItemData.length ; i++) {
                if (i == index) continue;
                if ($scope.ItemData[i].InventoryItemId === itemId && $scope.ItemData[i].BrandId === brandId) {
                    msg("this brand is already taken");
                    $scope.ItemData[index].BrandId = "";
                    break;
                }
            }
        }
        $scope.getOpeningBalances();
        $scope.getBrands = function () {
            var promise = inventoryTransactionService.getBrands($scope.PropertyID, 1);
            promise.then(function (data, status) {
                $scope.BrandList = data.Collection;
            });
        }
        $scope.getBrands();

        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, inventoryOpeningBalanceService, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, inventoryOpeningBalanceService, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            //  getData($scope, inventoryOpeningBalanceService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, inventoryOpeningBalanceService, localStorageService);
        }

        $scope.isExist = function (itemId, brandId) {
            var promiseGet = inventoryOpeningBalanceService.getCodeExistOpeningBalance(itemId, brandId, $scope.PropertyID);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        parent.failureMessage(data.Message);
                        $scope.Location.LocationCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
        };
        $scope.removeRow = function (index) {
            $scope.ItemData.splice(index, 1);
        }; 

        $scope.formdata = new FormData();
        $scope.getTheFiles = function ($files, fd) {
            angular.forEach($files, function (value, key) {

                fd.append(key, value);
            });
        };
        $scope.uploadExcel = function (fd) { 
            $scope.IsUploadingExcel = true;
            inventoryTransactionService.saveFromExcel(fd, $scope)
                .then(function () {
                    $scope.getOpeningBalances();
                });
        };

        $scope.ShowErrorMessage = false;
        $scope.SaveOpeningBalance = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            if ($scope.ItemData.length < 1) {
                msg("Please enter at least one item!");
                return;
            }
            for (var i = 0 ; i < $scope.ItemData.length; i++) {
                //angular.forEach($scope.ItemData, function (item) {

                if (!($scope.ItemData[i].Quantity > 0)) {
                    msg("Please enter some Quantity for  item " + $scope.ItemData[i].InventoryItemName);
                    return;
                }
            };

            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.ModifiedDate = $scope.ModifiedDate;
            $scope.model.GRDate = $scope.ModifiedDate;
            $scope.model.InventoryTransactionItems = $scope.ItemData;
            $scope.model.OperationType = 6;

            var promise = inventoryTransactionService.save($scope.model);
            promise.then(function (data, status) {

                $scope.getOpeningBalances();
                //getData($scope, inventoryOpeningBalanceService, localStorageService);
                $scope.ResetOpeningMaster();
                //if (data.Status) {
                msg(data.Message, data.Status);
                //}
            },
            function (error, status) {
                msg(error.Message);
            });
        }

        $scope.bindItem = function (d) {
            $("#searchItem")
                 .autocomplete({
                     source: function (request, response) {
                         var promise = inventoryTransactionService.getItems($scope.PropertyID, d, 1);
                         promise.then(function (data, status) {

                             response($.map(data.Collection,
                                       function (item) {
                                           return {
                                               label: item.Name,
                                               val: item.Id
                                           };
                                       }));
                         });
                     },
                     select: function (e, ui) {
                         if (ui.item) {
                             if (ui.item.value !== "No Record Found!") {
                                 var element = angular.element($("#divItemData"));
                                 var scope = element.scope();
                                 scope.$apply(function () {
                                     var promiseGet = inventoryTransactionService.GetItemById($scope.PropertyID, ui.item.val);
                                     promiseGet.then(function (data, status) {

                                         data.Data.InventoryItemId = data.Data.Id;
                                         data.Data.InventoryItemName = data.Data.Name;
                                         scope.ItemData.push(data.Data);
                                         scope.model.Search = "";
                                     },
                                     function (error, status) {

                                         msg(error.Message);
                                     });
                                 });
                             }
                         }
                     },
                     minLength: 1
                 });
        };

        $scope.CalculateValue = function (a) {
            a.Value = parseFloat(parseFloat(a.Qty) * parseFloat(a.Rate)).toFixed(2);
        }
        $scope.fillData = function (record) {

            $scope.model = record;
            $scope.ItemData = [];
            $scope.IsReadonly = true;
            $scope.Save = "Update";
            $scope.ItemData = record.InventoryTransactionItems;
        };
    }
]);
