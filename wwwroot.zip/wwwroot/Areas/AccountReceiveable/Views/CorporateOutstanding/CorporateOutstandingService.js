﻿
app.service("corporateOutstandingService", function ($http, $q) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getOpeningDate = function (propertyId, corporateId) {
        var params = { propertyId: propertyId, corporateId: corporateId };
        return httpCaller(apiPath + "AccountReceiveable/CorporateOutstanding/GetOpeningDate", $http, $q, params);
    };

    this.save = function (model) {
        return httpPoster(apiPath + "AccountReceiveable/CorporateOutstanding/Save", $http, $q, model);
    };

});
