﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');

        $scope.UserName = $cookies.get('UserName');//"Admin";
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.IsReadonly = false;

        $scope.Model = {
            Id: '',
            Code: '',
            Name: '',
            Description: '',
            IsActive: '',
            BillingInstructionDetails: [],
        };

        $scope.biId = "";
        $scope.Name = "";
        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;
        $scope.Save = "Save";

        $scope.billingInstructionData = [];
        $scope.list = [];

        var sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        getRevenueDetails();
        getData($scope, service, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, service, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };

        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        }

        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }
        function getbillingDetails(billInstructionId) {
            var promiseGet = service.getBillingInstructionData(billInstructionId, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                $scope.list = data.Collection[0].BillingInstructionDetails;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        function getRevenueDetails() {
            var promiseGet = service.getRevenueHead($scope.PropertyID);
            promiseGet.then(function (data, status) {

                $scope.revenueHeadDetails = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.isExist = function () {
            var promiseGet = service.getCodeExistBillingInstruction($scope.biCode, $scope.PropertyID);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        msg(data.Message);
                        //alert("Billing Instruction Code Already Exist");
                        $scope.biCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Model = {};
            $scope.RevenueHeadId = "";
            $scope.RevenueHeadCode = "";
            $scope.biId = "";
            $scope.biName = "";
            $scope.biCode = "";
            $scope.biDescription = "";
            $scope.BillingTypeId = "";
            $scope.BillingTypeName = "";
            $scope.rwbillsplitno = "";
            $scope.list = [];
            $scope.IsActive = true;
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            scrollPageOnTop();
            $scope.searchfor = "";
            $scope.search();
            //getData($scope, service, localStorageService);
        };

        $scope.addItem = function () {

            ////            $scope.$apply(function() {
            if ($scope.rwbillsplitno == "" || $scope.rwbillsplitno == undefined) {
                msg("Please enter bill split no.");
                return;
            }
            if ($scope.BillingTypeId == "" || $scope.BillingTypeId == undefined) {
                msg("Please select Billing Type.");
                return;
            }
            if ($scope.RevenueHeadId == "" || $scope.RevenueHeadId == undefined) {
                msg("Please select revenue code");
                return;
            }
            //    });
            // check same not repeat
            var flag = false;

            if ($scope.list != undefined) {
                var listLenght = $scope.list.length;
                for (var i = 0; i < listLenght; i++) {
                    if ($scope.list[i].BillingTypeId === $scope.BillingTypeId && $scope.list[i].RevenueHeadId === $scope.RevenueHeadId) {
                        msg('This revenue code and Billing Type is already taken.');
                        return;
                    } else if ($scope.list[i].BillSplitNo === $scope.rwbillsplitno
                        && $scope.list[i].BillingTypeId === $scope.BillingTypeId
                        && $scope.list[i].RevenueHeadId === $scope.RevenueHeadId) {
                        break;
                    } else if ($scope.list[i].RevenueHeadId === $scope.RevenueHeadId) {
                        break;
                    } else {
                        if (flag == false) {
                            $scope.list.push({
                                BillSplitNo: $scope.rwbillsplitno,
                                BillingTypeId: $scope.BillingTypeId,
                                BillingTypeName: $("#ddltype option:selected").text(),
                                RevenueHeadCode: $("#ddlrevenuehead option:selected").text(),
                                RevenueHeadId: $scope.RevenueHeadId
                            });
                        }
                        flag = true;
                    }
                }

                if ($scope.list.length === 0) {
                    $scope.list.push({
                        BillSplitNo: $scope.rwbillsplitno,
                        BillingTypeId: $scope.BillingTypeId,
                        BillingTypeName: $("#ddltype option:selected").text(),
                        RevenueHeadCode: $("#ddlrevenuehead option:selected").text(),
                        RevenueHeadId: $scope.RevenueHeadId
                    });
                }
            } else {
                $scope.list = [];
                $scope.list.push({
                    BillSplitNo: $scope.rwbillsplitno,
                    BillingTypeId: $scope.BillingTypeId,
                    BillingTypeName: $("#ddltype option:selected").text(),
                    RevenueHeadCode: $("#ddlrevenuehead option:selected").text(),
                    RevenueHeadId: $scope.RevenueHeadId
                });
            }
            // resert values
            $scope.rwbillsplitno = "";
            $scope.BillingTypeId = "";
            $scope.BillingTypeName = "";
            $scope.RevenueHeadCode = "";
            scrollPageOnTop();
        };
        $scope.removeItem = function (index) {
            $scope.list.splice(index, 1);
        };
        $scope.save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            //if ($scope.biCode == "" || $scope.biCode == undefined) {
            //    msg("Code should not be blank");
            //    return;
            //}
            //if ($scope.biName == "" || $scope.biName == undefined) {
            //    msg("Name should not be blank");
            //    return;
            //}
            if ($scope.list == undefined) {
                msg("There is no billing instruction");
                return;
            }
            if ($scope.list.length == 0) {
                msg("There is no billing instruction");
                return;
            }

            //var biObj = new Object();
            //biObj.Id = $scope.biId;
            //biObj.Name = $scope.biName;
            //biObj.Code = $scope.biCode;
            //biObj.Description = $scope.Model.Description.trim();
            //biObj.IsActive = $scope.IsActive;

            $scope.Model.BillingInstructionDetails = $scope.list;
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            $scope.Model.IsActive = true;

            var promiseGet = service.save($scope.Model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);
                $scope.reset();
                msg(data.Message, data.Status);
            },
            function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.update = function (biModel) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var promiseGet = service.updateIsActiveBillingInstruction(biModel.Id, biModel.IsActive, $scope.PropertyID, $scope.UserName);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);
                msg(data.Message, data.Status);
            }, function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.removeRow = function (biModel) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Billing Instruction?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = service.deleteBillingInstruction(biModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {

                                getData($scope, service, localStorageService);
                                msg(d.Message, d.Status);
                            }, function (err) {

                                msg(err.Message);
                                //alert($.parseJSON(err.responseText).Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
            scrollPageOnTop();
        };
        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.Model = record;
            $scope.biId = record.Id;
            $scope.biName = record.Name;
            $scope.biDescription = record.Description;
            $scope.biCode = record.Code;
            $scope.IsActive = record.IsActive;

            $scope.IsReadonly = true;

            //getbillingDetails(record.Id);

            $scope.list = $scope.Model.BillingInstructionDetails;

            $scope.Save = "Update";
            scrollPageOnTop();
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getBillingInstruction(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
