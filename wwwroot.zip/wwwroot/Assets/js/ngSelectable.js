
(function () {
    'use strict';
    angular.module("ngSelectable", [])
        .directive("selectable", function () {
            return function (scope, element, attr) {
                //
                var options = scope.$eval(attr.selectableOptions) || {};

                if (attr.selectableList && attr.selectableOut) {
                    element.bind("selectablestop", function () {
                        var selectableList = scope.$eval(attr.selectableList),
                            selectableOut = scope.$eval(attr.selectableOut), s;
                        var selected = !selectableList ? [] : element.find('.ui-selected').map(function () {
                            return selectableList[$(this).index()];
                        }).get();
                        scope.$apply(function () {
                            if (selectableOut === undefined)
                                scope[attr.selectableOut] = selectableOut = [];
                            selectableOut.splice(0);
                            while (s = selected.shift())
                                selectableOut.push(s);
                        });
                    });
                }

                scope.$watch(attr.selectable, function (value, old) {
                    //
                    if (value || value === undefined)
                        return element.selectable(options);
                    if (!value && old) {
                        element.selectable("destroy");
                        element.find('.ui-selected').removeClass('ui-selected');
                        if (attr.selectableOut) {
                            scope[attr.selectableOut] = [];
                        }
                    }
                })
            }
        })
        .directive("selectableEvents", ['$parse', function ($parse) {
            return function (scope, element, attr) {
                var selectableEvents = scope.$eval(attr.selectableEvents) || {};

                $.map(selectableEvents, function (callback, eventName) {
                    //
                    element.bind("selectable" + eventName, function (e, ui) {
                        if (e.preventDefault) e.preventDefault();

                        var selectableList = scope.$eval(attr.selectableList);
                        var selected = !selectableList ? [] : element.find('.ui-selected').map(function () {
                            return selectableList[$(this).index()];
                        }).get();

                        var fn = $parse(callback);
                        scope.$apply(function () {
                            fn(scope, {
                                $ui: ui,
                                $event: e,
                                $list: scope.$eval(attr.selectableList),
                                $selected: selected
                            });
                        });
                    });
                });
            }
        }]);
})();


///// made for selection date taking one day ahead :::: conflicting with earlier version above in this file
//(function () {
//    'use strict';

//    angular.module("ngSelectablem", [])
//        .directive("selectablem", function () {
//            return function (scope, element, attr) {
//                var options = scope.$eval(attr.selectablemOptions) || {};
//                //

//                if (attr.selectablemList && attr.selectablemOut) {
//                    element.bind("selectablem", function () {
//                        //
//                        var selectableList = scope.$eval(attr.selectablemList),
//                            selectablemOut = scope.$eval(attr.selectablemOut), s;
//                        var selected = !selectablemList ? [] : element.find('.ui-selectedm').map(function () {
//                            //
//                            return selectablemList[$(this).index() - 1];
//                        }).get();
//                        scope.$apply(function () {
//                            //
//                            if (selectablemOut === undefined)
//                                scope[attr.selectablemOut] = selectablemOut = [];
//                            selectablemOut.splice(0);
//                            while (s = selected.shift())
//                                selectablemOut.push(s);
//                        });
//                    });
//                }

//                scope.$watch(attr.selectablem, function (value, old) {
//                    //
//                    if (value || value === undefined)
//                        return element.selectable(options);
//                    if (!value && old) {
//                        element.selectablem("destroy");
//                        element.find('.ui-selectedm').removeClass('ui-selectedm');
//                        if (attr.selectablemOut) {
//                            scope[attr.selectablemOut] = [];
//                        }
//                    }
//                })
//            }
//        })
//        .directive("selectablemEvents", ['$parse', function ($parse) {
//            return function (scope, element, attr) {
//                var selectablemEvents = scope.$eval(attr.selectablemEvents) || {};

//                $.map(selectablemEvents, function (callback, eventName) {
//                    //
//                    element.bind("selectablem" + eventName, function (e, ui) {
//                        //
//                        if (e.preventDefault) e.preventDefault();

//                        var selectablemList = scope.$eval(attr.selectablemList);
//                        var selected = !selectablemList ? [] : element.find('.ui-selected').map(function () {
//                            return selectablemList[$(this).index() - 1];
//                        }).get();

//                        var fn = $parse(callback);
//                        scope.$apply(function () {
//                            fn(scope, {
//                                $ui: ui,
//                                $event: e,
//                                $list: scope.$eval(attr.selectablemList),
//                                $selected: selected
//                            });
//                        });
//                    });
//                });
//            }
//        }]);
//})();
