﻿
(function () {
    function marketSegmentService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var linkModule = [];
        var getMarketSegment = function (options) {

            var url = apiPath + "FrontOffice/marketSegment/details?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getMarketSegmentData(marketSegmentId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/marketSegment/details/" + marketSegmentId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getCodeExistMarketSegment(marketSegmentCode, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/marketSegment/exist/" + marketSegmentCode + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function saveMarketSegment(bsModel) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/marketSegment/create",
                data: bsModel,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        function updateIsActiveMarketSegment(marketSegmentId, isActive, propertyId, userName) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/marketSegment/update?marketSegmentId=" + marketSegmentId + "&isActive=" + isActive + "&propertyId=" + propertyId + "&userName=" + userName,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function deleteMarketSegment(marketSegmentId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/MarketSegment/delete/" + marketSegmentId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(status);
            });
            return deferred.promise;
        };

        var service = {
            dataAllData: linkModule,
            getMarketSegment: getMarketSegment,
            getCodeExistMarketSegment: getCodeExistMarketSegment,
            saveMarketSegment: saveMarketSegment,
            getMarketSegmentData: getMarketSegmentData,
            updateIsActiveMarketSegment: updateIsActiveMarketSegment,
            deleteMarketSegment: deleteMarketSegment
        };
        return service;
    }

    app.factory("MarketSegmentService", ["$http", "$q", marketSegmentService]);
})();
