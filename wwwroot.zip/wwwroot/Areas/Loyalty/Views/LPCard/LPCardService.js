﻿
app.service('LPCardService', [
    '$http', '$q', function (
        $http, $q) {

        this.getAllLPProgram = function (propertyId) {
            return httpCaller(apiPath + "Loyalty/LPProgram/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };
        this.getAll = function (options) {
            return httpCaller(apiPath + "Loyalty/LPCard/GetAll", $http, $q, options);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "Loyalty/LPCard/Save", $http, $q, model);
        };
        this.delete = function (id) {
            return httpCaller(apiPath + "Loyalty/LPCard/Delete", $http, $q, { id: id });
        };
        this.changeStatus = function (model) {
            return httpPoster(apiPath + "Loyalty/LPCard/Status", $http, $q, model);
        };

    }
]);
