﻿
var isOnGitHub = false;//, url = apiPath + 'configuration/ImageGallery/Save';
app.requires.push('blueimp.fileupload');

app.config([
            '$httpProvider', 'fileUploadProvider',
            function ($httpProvider, fileUploadProvider) {
                delete $httpProvider.defaults.headers.common['X-Requested-With'];
                fileUploadProvider.defaults.redirect = window.location.href.replace(
                    /\/[^\/]*$/,
                    '/cors/result.html?%s'
                );
                angular.extend(fileUploadProvider.defaults, {
                    // Enable image resizing, except for Android and Opera,
                    // which actually support image resizing, but fail to
                    // send Blob objects via XHR requests:
                    disableImageResize: /Android(?!.*Chrome)|Opera/
                        .test(window.navigator.userAgent),
                    maxFileSize: 999000,
                    acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i
                });
            }
]);

app.controller('controller', [
    '$scope', 'ImageGalleryService', 'localStorageService', '$http', function (
        $scope, service, localStorageService, $http) {

        service.init($scope, "PageHelpImage/");
        $scope.formdata1 = new FormData();
        $scope.options = {
            url: apiPath + 'configuration/ImageGallery/Save?pathToUpload=' + service.pathToUpload
        };
        $scope.APIPath = apiPath;

        //$scope.loadingFiles = true;
        //$http.get(url)
        //    .then(
        //        function (response) {
        //            $scope.loadingFiles = false;
        //            $scope.queue = response.data.files || [];
        //        },
        //        function () {
        //            $scope.loadingFiles = false;
        //        }
        //    );

        var sortKeyOrder = {
            key: "",
            order: "",
        };
        $scope.searchfor = { searchfor: '' };
        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;

        getData($scope, service, localStorageService);

        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        };
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }

        $scope.Reset = function () {
            //$scope.model = { IsActive: true, OrderSNo: 0 };
            //clearForm();
            $scope.searchfor.searchfor = "";
            $scope.search();
            scrollPageOnTop();
            //$scope.clear($scope.queue);
            //$scope.queue = [];
            $scope.formdata1 = new FormData();
        };
        //$scope.ShowErrorMessage = false;
        $scope.save = function (model, form) {

            service.file_upload($scope.formdata1).then(function (data, status) {
                getData($scope, service, localStorageService);
                $scope.Reset();
                return true;
            }, function (data, status, headers, config) {
                parent.failureMessage(data.Message);
                return false;
            });
        };

        //$scope.ChangeStatus = function (id) {

        //    var promiseGet = service.changeStatus(id);
        //    promiseGet.then(function (data) {
        //        parent.successMessage(data.Message);
        //        getData($scope, service, localStorageService);
        //        scrollPageOnTop();
        //    },
        //        function (error) {

        //            parent.failureMessage(error.Message);
        //            scrollPageOnTop();
        //        });
        //};

    }
]).controller('FileDestroyController', [
            '$scope', '$http',
            function ($scope, $http) {
                var file = $scope.file,
                    state;

                if (file.url) {
                    file.$state = function () {
                        return state;
                    };
                    file.$destroy = function () {
                        state = 'pending';
                        return $http({
                            url: file.deleteUrl,
                            method: file.deleteType
                        }).then(
                            function () {
                                state = 'resolved';
                                $scope.clear(file);
                            },
                            function () {
                                state = 'rejected';
                            }
                        );
                    };

                } else if (!file.$cancel && !file._index) {
                    file.$cancel = function () {
                        $scope.clear(file);
                    };
                }

                //$scope.clear1 = function (f) {
                //    $scope.clear(f);
                //};
            }
]);

var getData = function ($scope, dataService, localStorageService) {

    //$scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Name",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKey: sortKeyOrder.key,
        sortOrder: sortKeyOrder.order,
        searchfor: searchfor || ''
    };
    $scope.showLoader = true;
    dataService.getAll(options)
          .then(function (s) {
              $scope.data = s.Collection;
              $scope.totalItems = s.RecordCount;
              $scope.showLoader = false;
          }, function () {
              parent.failureMessage("The request failed. Unable to connect to the remote server.");
          });

};
