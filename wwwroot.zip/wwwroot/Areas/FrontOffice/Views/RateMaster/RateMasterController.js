﻿
$(function () {
    $('#rackrate').click(function () {
        $('#rackratesub').slideToggle('20000').css('max-height', '380px');
        $('#corporatesub, #bookingsub, #channelmansub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
    $('#corporate').click(function () {
        $('#corporatesub').slideToggle('20000').css('max-height', '380px');
        $('#rackratesub, #bookingsub, #channelmansub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
    $('#booking').click(function () {
        $('#bookingsub').slideToggle('20000').css('max-height', '380px');
        $('#corporatesub, #rackratesub, #channelmansub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
    $('#channelman').click(function () {
        $('#channelmansub').slideToggle('20000').css('max-height', '380px');
        $('#corporatesub, #bookingsub, #rackratesub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
});

app.controller("controller",[
    "$scope", "rateMasterService", "localStorageService", "$cookies", "$filter",
    function ($scope, rateMasterService, localStorageService, $cookies, $filter) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.MaxDate = $filter("date")(date, $scope.DateFormat);
        $scope.RoomRate = {
            Id: "",
            RateType: 1,
            RateTypeId: "",
            RateTypeDescription: "",
            RateMasterCode: "",
            Description: "",
            Color:"",
            IsActive: true,
            ApplicableFrom: "",
            ApplicableTo: "",
            AdultExtraCharge: 0.00,
            ChildExtraCharge: 0.00,
            AdultExtraChargeMeal: 0.00,
            ChildExtraChargeMeal: 0.00,
            MinimumStay: 0,
            IsMinuteDefault: false,
            IsTariffPlanInclusive: false,//navneet
            IsTariffTAXInclusive: false,//
            IsInclusive: false,//
            RateTaxStructureId: "",
            MealPlanTAXStructureId: "",
            ExtraBedTaxId: "",
            ExtraBedPlanTaxId: "",
            CorporatePartner: "",    //navneet: discussion required
            ChannelPartner: "",
            IsCorporatePartner: false,
            IsChannelPartner: false,
            IsWeekDays: false,

            CorporateRateMasters: [],
            MealPlanRates: [],
            OccupancyTypeRates: [],
            ReservationRoomTypes: [],
            RoomTypeRates: [],
            DefaultSettings: [],

            MinimumStayRates: [],
            RoomTypes: [],
            WeekDaysRates: [],
            DefaultRateViewModels: [],
            TaxStructures: [],

            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName
        };

        $scope.RoomRateParent = {

            BookingEngineRates: [],
            ChannelManagerRates: [],
            RackRates: [],
            TravelAgentRates: [],
        };

        $scope.RoomRateId = "";
        $scope.RateTypes = [];
        GetRateType();
        function GetRateType() {
            var promiseGet = rateMasterService.GetRateType();
            promiseGet.then(function (data) {
                $scope.RateTypes = data;
            }, function (data) {
                msg(data.message);
            });
        }

        $scope.StructureViewModels = [];
        getAllRoomRate();
        function getAllRoomRate() {
            $scope.ActionMode = "";
            var promiseGet = rateMasterService.getAllroomRate($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.RoomRateParent = data.Data;
            }, function (error) {

                msg(error.Message);
                //$("html, body").animate({ scrollTop: 0 }, "slow");
            });
        }
        $scope.getRoomTypeList = function () {
            var promise = rateMasterService.getRoomTypeList($scope.PropertyID);
            promise.then(function (data) {

                $scope.RoomTypeList = data.Collection;
            }, function (error) {
                msg(error.Message);
            });
        }
        $scope.getRoomTypeList();
        $scope.putMealPlanOccupancy = function () {
            angular.forEach($scope.model.RoomTypeRates, function (r) {

                r.OccupancyMealPlanRates = [];
                if (r.OccupancyRates.length > 0) {
                    for (var j = 0; j < r.OccupancyRates[0].OccupancyMealPlanRates.length; j++) {
                        var mpr = new Object();
                        mpr.MealPlanId = r.OccupancyRates[0].OccupancyMealPlanRates[j].MealPlanId;
                        mpr.MealPlanCode = r.OccupancyRates[0].OccupancyMealPlanRates[j].MealPlanCode;
                        mpr.OccupancyRates = [];
                        for (var k = 0; k < r.OccupancyRates.length; k++) {
                            for (var l = 0; l < r.OccupancyRates[k].OccupancyMealPlanRates.length; l++) {
                                if (r.OccupancyRates[0].OccupancyMealPlanRates[j].MealPlanId === r.OccupancyRates[k].OccupancyMealPlanRates[l].MealPlanId) {

                                    r.OccupancyRates[k].OccupancyMealPlanRates[l].OccupancyName = r.OccupancyRates[k].OccupancyName;
                                    r.OccupancyRates[k].OccupancyMealPlanRates[l].OccupancyId = r.OccupancyRates[k].OccupancyId;
                                    mpr.OccupancyRates.push(angular.copy(r.OccupancyRates[k].OccupancyMealPlanRates[l]));
                                    break;
                                }
                            };
                        };
                        r.OccupancyMealPlanRates.push(mpr);
                    };

                }
            });
        };
        $scope.putMealPlanOccupancyO = function () {
            angular.forEach($scope.model.RoomTypeRates, function (r) {
                //
                r.OccupancyMealPlanRates = [];
                if (r.OccupancyRates.length > 0) {
                    //
                    angular.forEach(r.OccupancyRates[0].OccupancyMealPlanRates, function (mpr) {
                        //
                        if (!mpr.OccupancyRates) mpr.OccupancyRates = [];
                        angular.forEach(r.OccupancyRates, function (or) {
                            //
                            or.MealPlanId = mpr.MealPlanId;
                            //or.MealPlanCode = mpr.MealPlanCode;
                            mpr.OccupancyRates.push(angular.copy(or));
                        });
                        r.OccupancyMealPlanRates.push(mpr);
                    });

                }
            });

        };
        $scope.getBlankModel = function () {
            var promise = rateMasterService.getBlankModel($scope.PropertyID);
            promise.then(function (data) {
                
                $scope.model = data.Data;
                $scope.model.RateTypeId = "1";
                $scope.putMealPlanOccupancyO();

            }, function (error) {
                msg(error.Message);
            });
        }
        $scope.getBlankModel();
        $scope.getTaxList = function () {
            var promise = rateMasterService.getTaxList($scope.PropertyID);
            promise.then(function (data) {

                $scope.TaxList = data.Collection;
            }, function (error) {
                msg(error.Message);
            });
        }
        $scope.getTaxList();

        $scope.MinuteWeekDaysDefination = [];

        getAllCorporateDetails();
        $scope.CorporateDetails = [];
        function getAllCorporateDetails() {
            var promiseGet = rateMasterService.getCorporateDetails($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.CorporateDetails = data.Collection;
            },
            function (error) {
                msg(error.Message);
                //$("html, body").animate({ scrollTop: 0 }, "slow");
            });
        }

        getAllChannelDetails();
        $scope.ChannelDetails = [];
        function getAllChannelDetails() {
            var promiseGet = rateMasterService.getChannelDetails($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.ChannelDetails = data.Collection;
            },
            function (error) {
                msg(error.Message);
                //$("html, body").animate({ scrollTop: 0 }, "slow");
            });
        }

        $scope.RoomRateTypeChange = function (item) {

            if (item.Name == "RackRate") {
                $(".channelManageRate").css("display", "none");
                $(".corporateManageRate").css("display", "none");
                $("#corporatedropbox").css("display", "none");
                $("#channeldropbox").css("display", "none");
                $("#channelManageRateChecked").attr("checked", false);
                $("#corporatedropChecked").attr("checked", false);
            }
            else if (item.Name == "TravelAgentRate") {
                $(".corporateManageRate").css("display", "block");
                $("#corporatedropbox").css("display", "none");
                $("#channeldropbox").css("display", "none");
                $(".channelManageRate").css("display", "none");
                $("#channelManageRateChecked").attr("checked", false);
                $("#corporatedropChecked").attr("checked", false);
            }
            else {
                $(".channelManageRate").css("display", "block");
                $(".corporateManageRate").css("display", "none");
                $("#corporatedropbox").css("display", "none");
                $("#channeldropbox").css("display", "none");
                $("#channelManageRateChecked").attr("checked", false);
                $("#corporatedropChecked").attr("checked", false);
            }
        };
        $scope.RoomRateIsChannelPartner = function (event) {
            if (event.target.checked) {
                $("#channeldropbox").show();
            }
            if (!event.target.checked) {
                $("#channeldropbox").hide();
            }
        };
        $scope.LastMinutesDefault = function (event) {
            if (event.target.checked) {
                $("#setlastbox").show("slow");
            }
            if (!event.target.checked) {
                $("#setlastbox").hide("slow");
                $scope.model.ApplicableTimeFrom = "";
                $scope.model.ApplicableTimeTill = "";
            }
        };
        $scope.LastMinutesChannelManager = function (event) {

            if (event.target.checked) {
                $("#channeldropbox2").show();
            }
            if (!event.target.checked) {
                $("#channeldropbox2").hide();
            }
        };
        $scope.CorporateTravelManager = function (event) {

            if (event.target.checked) {
                $("#corporatedropbox").show();
            }
            if (!event.target.checked) {
                $("#corporatedropbox").hide();
            }
        };
        $scope.MinuteDefaultErrorMessage = false;
        $scope.RoomTypeProcessing = false;
        $scope.ShowErrorMessage = false;

        $scope.save = function (form, model) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                msg('');
                return false;
            }
            var checkValid = true;

            if ($scope.model.IsLastMinuteDefault == true) {
                if ($scope.model.ApplicableTimeFrom == undefined ||
                    $scope.model.ApplicableTimeFrom == "" ||
                    $scope.model.ApplicableTimeFrom == null) {
                    checkValid = false;
                }
                if ($scope.model.ApplicableTimeTill == undefined ||
                    $scope.model.ApplicableTimeTill == "" ||
                    $scope.model.ApplicableTimeTill == null) {
                    checkValid = false;
                }

                if (!checkValid) {
                    $scope.MinuteDefaultErrorMessage = true;
                }
                else {
                    model.DefaultRateViewModels = $scope.MinuteWeekDaysDefination;
                    model.MinimumStayViewModels = $scope.MinimumStayViewModel;
                    $scope.RoomTypeProcessing = true;
                    var promiseGet1 = rateMasterService.saveroomRate($scope.PropertyID, $scope.UserName, model);
                    promiseGet1.then(function (data) {
                        msg(data.Message, true);
                        $scope.RoomTypeProcessing = false;
                        getAllRoomRate();
                        $scope.reset();
                    }, function (error) {
                        msg(error.Message);
                        $scope.RoomTypeProcessing = false;
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                        $scope.model = {};
                    });
                }
            } else {
                //navneet
                $scope.RoomTypeProcessing = true;

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.UserName;
                model.IsActive = true;
                if (dateCompare(model.ApplicableFromString, model.ApplicableToString) > 0) {
                    msg("Applicable From date should be less than Applicable To date.");
                    return;
                }

                angular.forEach(model.RoomTypeRates, function (r) {
                    //if (!r.ExtraBedAdultRate || r.ExtraBedAdultRate == "0" || !r.ExtraBedChildRate || r.ExtraBedChildRate == "0" || !r.ExtraBedInfantRate || r.ExtraBedInfantRate == "0") {
                    //    checkValid = false;
                    //}

                    angular.forEach(r.OccupancyRates, function (or) {

                        if (!or.RateDay1 || or.RateDay1 == "0" || !or.RateDay2 || or.RateDay2 == "0" || !or.RateDay3 || or.RateDay3 == "0" || !or.RateDay4 || or.RateDay4 == "0" || !or.RateDay5 || or.RateDay5 == "0" || !or.RateDay6 || or.RateDay6 == "0" || !or.RateDay7 || or.RateDay7 == "0") {
                            checkValid = false;
                        }
                    });

                    if (r.OccupancyMealPlanRates && r.OccupancyMealPlanRates.length > 0) {

                        for (var i = 0; i < r.OccupancyRates.length; i++) r.OccupancyRates[i].OccupancyMealPlanRates = [];
                        angular.forEach(r.OccupancyMealPlanRates, function (mpr) {

                            angular.forEach(mpr.OccupancyRates, function (or) {

                                //if (!or.RateDay1 || or.RateDay1 == "0" || !or.RateDay2 || or.RateDay2 == "0" || !or.RateDay3 || or.RateDay3 == "0" || !or.RateDay4 || or.RateDay4 == "0" || !or.RateDay5 || or.RateDay5 == "0" || !or.RateDay6 || or.RateDay6 == "0" || !or.RateDay7 || or.RateDay7 == "0") {
                                //    checkValid = false;
                                //}

                                for (var i = 0; i < r.OccupancyRates.length; i++) {
                                    if (or.OccupancyId === r.OccupancyRates[i].OccupancyId) {
                                        r.OccupancyRates[i].OccupancyMealPlanRates.push(angular.copy(or));
                                        break;
                                    }
                                }
                            });
                        });

                    }
                });
                if (!checkValid) {
                    msg("Please enter all rates");
                    return;
                }

                angular.forEach($scope.model.RoomTypeRates, function (r) {
                    r.OccupancyMealPlanRates = null;
                });

                var promiseGet = rateMasterService.save(model);
                promiseGet.then(function (data) {

                    msg(data.Message, true);
                    $scope.RoomTypeProcessing = false;
                    getAllRoomRate();
                    $scope.reset();
                }, function (error) {
                    msg(error.Message);
                    $scope.RoomTypeProcessing = false;
                });
            }
        };
        $scope.WeekDaysDefinationEvent = function (event) {
            if (event.target.checked) {
                $(".IsWeekDays").show("slow");
                $(".IsWeekDaysDefination1").show("slow");
            }
            if (!event.target.checked) {
                $(".IsWeekDays").hide("slow");
                $(".IsWeekDaysDefination1").hide("slow");
            }
        };
        $scope.IsRateCodeExist = function (item, id) {

            if (item) {
                var promiseGet = rateMasterService.isRoomRateRateCodeExist(item, $scope.PropertyID, id);
                promiseGet.then(function (data) {

                }, function (error) {

                    msg(error.data.Message);
                    //$("html, body").animate({ scrollTop: 0 }, "slow");
                    $scope.model.Code = "";
                });
            }
        }
        $scope.Remove = function (item) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (item != undefined) {
                                var promiseGet = rateMasterService.remove(item);
                                promiseGet.then(function (data) {
                                    msg(data.Message, true);
                                    $("html, body").animate({ scrollTop: 0 }, "slow");
                                    getAllRoomRate();
                                },
                                    function (error) {
                                        msg(error.Message);
                                        $("html, body").animate({ scrollTop: 0 }, "slow");
                                    });
                            }
                            $.fancybox.close();
                        });
                }
            });
        }
        $scope.getRoomRateDetails = function (rateMasterId) {
            $scope.ActionMode = "Edit";
            var promiseGet = rateMasterService.getRoomRateDefinationDetails(rateMasterId, $scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.model = data.Data;

                $scope.model.ApplicableFrom = $filter("date")(new Date($scope.model.ApplicableFrom), $scope.DateFormat);
                $scope.model.ApplicableTo = $filter("date")(new Date($scope.model.ApplicableTo), $scope.DateFormat);
                $scope.putMealPlanOccupancy();

                if ($scope.model.IsWeekDays) {
                    $(".IsWeekDays").show("slow");
                }
                else {
                    $(".IsWeekDays").hide("slow");
                }
                if (data.Data.RateTypeDescription == "BookingEngineRate" || data.Data.RateTypeDescription == "ChannelManagerRate") {
                    $(".channelManageRate").css("display", "block");
                    $(".corporateManageRate").css("display", "none");
                    $("#corporatedropbox").css("display", "none");
                    $("#channeldropbox").css("display", "none");
                }
                if (data.Data.RateTypeDescription == "RackRate") {
                    $(".channelManageRate").css("display", "none");
                    $(".corporateManageRate").css("display", "none");
                    $("#corporatedropbox").css("display", "none");
                    $("#channeldropbox").css("display", "none");
                }
                if (data.Data.RateTypeDescription == "TravelAgentRate") {
                    $(".corporateManageRate").css("display", "block");
                    $("#corporatedropbox").css("display", "none");
                    $("#channeldropbox").css("display", "none");
                    $(".channelManageRate").css("display", "none");
                }
                if ($scope.RoomTypeList && $scope.RoomTypeList.length > 0) {
                    setTimeout(function () {

                        var rt1 = $('#' + $scope.RoomTypeList[0].Id);
                        rt1.addClass(' in active');
                        var tt1 = $('#t' + $scope.RoomTypeList[0].Id);
                        tt1.tab('show');
                    }, 250);
                }
            }, function (error) {

                msg(error.Message);
            });
        };

        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.getBlankModel();
        }
        $scope.fillAll = function (orate) {
            orate.RateDay7 = orate.RateDay6 = orate.RateDay5 = orate.RateDay4 = orate.RateDay3 = orate.RateDay2 = orate.RateDay1;
        };

    }

]);
