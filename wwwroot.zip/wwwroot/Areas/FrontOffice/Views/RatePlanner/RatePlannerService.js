﻿
(function () {

    function rateMasterService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        //var _roomRateData = [];

        var getAllroomRate = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath +
                    "frontoffice/RateMaster/GetAllRoomTypeRate/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (error) {
                        deferred.reject(error);
                    });
            return deferred.promise;
        };

        //var getRoomRateDefinationDetails = function (id, propertyId) {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "FrontOffice/RateMaster/getById/" + id)// + "/" + propertyId)
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};

        //var getAllroomRateConfiguration = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http.post(apiPath + "FrontOffice/RateMaster/getAllRateConfiguration/" + propertyId)
        //        .then(function (result) {
        //            deferred.resolve(result);
        //        },
        //            function (error) {
        //                deferred.reject(error);
        //            });
        //    return deferred.promise;
        //};
        //var getRoomTypeList = function (propertyId) {
        //    return httpCaller(apiPath + "FrontOffice/RoomType/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        //};
        //var getBlankModel = function (propertyId) {
        //    return httpPoster(apiPath + "FrontOffice/RateMaster/GetBlankModel/" + propertyId, $http, $q);
        //};
        //var getMealPlanList = function (propertyId) {
        //    return httpCaller(apiPath + "referencedata/MealPlan", $http, $q);
        //};
        //var getOccupancyList = function (propertyId) {
        //    return httpCaller(apiPath + "referencedata/Occupancy", $http, $q);
        //};
        //var getTaxList = function (propertyId) {
        //    return httpCaller(apiPath + "GlobalSetting/TaxStructure/1/" + propertyId, $http, $q);
        //};

        var save = function (model) {
            return httpPoster(apiPath + "FrontOffice/RatePlanner/Save", $http, $q, model);
        };

        var remove = function (model) {
            return httpPoster(apiPath + "FrontOffice/RatePlanner/Remove", $http, $q, model);
        };
        
        //var isRoomRateRateCodeExist = function (rateMasterCode, propertyId, id) {
        //    var deferred = $q.defer();
        //    $http.post(apiPath + "FrontOffice/RateMaster/IsExist/" + rateMasterCode + "/" + propertyId + "?id=" + id)
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        }, function (data, status, headers, config) {
        //            deferred.reject(data, status, headers, config);
        //        });
        //    return deferred.promise;
        //};

        //var getChannelDetails = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "GlobalSetting/Corporate/GetAllByCorporateCategoryId/3/" + propertyId)
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};

        //var getCorporateDetails = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http.get(apiPath + "GlobalSetting/Corporate/allByPropertyId/" + propertyId)
        //        .then(function (result) {
        //            deferred.resolve(result.data);
        //        },
        //            function (data, status, headers, config) {
        //                deferred.reject(data, status, headers, config);
        //            });
        //    return deferred.promise;
        //};

        var GetRateType = function () {
            var url = apiPath + 'ReferenceConstant/RateType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };


        var getYearCalendar = function (startdate, numberOfMonths, propertyId, rateTypeId) {
            var deferred = $q.defer();
            $http.get(apiPath + 'FrontOffice/RatePlanner/GetYearCalendar/' + startdate + "/" + numberOfMonths + "/" + rateTypeId + "/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getWeekDay = function (propertyId) {

            var url = apiPath + 'ReferenceData/Calendar/WeekDay/';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };


        return {
            //dataAllData: _roomRateData,
            //getAllroomRateConfiguration: getAllroomRateConfiguration,
            getAllroomRate: getAllroomRate,
            remove: remove,
            save: save,
            //isRoomRateRateCodeExist: isRoomRateRateCodeExist,
            //getRoomRateDefinationDetails: getRoomRateDefinationDetails,
            //getCorporateDetails: getCorporateDetails,
            //getChannelDetails: getChannelDetails,
            GetRateType: GetRateType,
            //getRoomTypeList: getRoomTypeList,
            //getBlankModel: getBlankModel,
            //getMealPlanList: getMealPlanList,
            //getOccupancyList: getOccupancyList,
            //getTaxList: getTaxList,
            getYearCalendar: getYearCalendar,
            getWeekDay: getWeekDay,
        };
    }

    app.factory("ratePlannerService", ["$http", "$q", rateMasterService]);
})();
