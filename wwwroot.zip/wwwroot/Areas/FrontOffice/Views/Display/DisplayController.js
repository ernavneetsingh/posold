﻿
app.controller('Controller', [
    '$scope', '$window', '$http', '$q','localStorageService','$filter','uiGridExporterService','uiGridExporterConstants','$timeout','uiGridGroupingService','uiGridConstants', function (
        $scope, $window, $http, $q, localStorageService,$filter,uiGridExporterService,uiGridExporterConstants,$timeout,uiGridGroupingService,uiGridConstants) {
        
        $scope.ReportPath = ReportXPath + "Reporter/Report";
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.UserId = localStorageService.get('UserId'); 

        $scope.CurrentDate = $filter('date')(new Date(), $scope.DateFormat);
        $scope.CurrentTime= $filter('date')(new Date(), "hh:mm a");

        var paramstr = $window.location.search.substring(1);
        var params = paramstr.split('=');
        $scope.ReportId = params[1];

        $scope.load = function (reportId,gridOption,dynamicFilters,print) {
            
            if (!reportId) {
                msg('Please select a report to load.');
                return;
            }
            if($scope.DateFromString.length>1 &&  $scope.DateToString.length>1 && $scope.DateFromString>$scope.DateToString){
                msg('Please select valid dates.');
                return;
            }
            gridOption.data = [];

            loadReport(reportId, $scope.DateFromString, $scope.DateToString, dynamicFilters,$scope.PropertyID)
                .then(function (result) {
                   
                    if(result.Data.Table && result.Data.Table.length<1){
                        msg('No data found.');
                        return;
                    }
                    $scope.CurrentData=result.Data.Table;
                  
                    if(print) $timeout(function () {
                        var summaryData1=$filter('groupBy')(result.Data.Table, 'DESCRIPTION'); 
                        var summaryData=[];
                        Object.values(summaryData1).forEach(function(g){
                            summaryData.push({
                                summary:g.group_name,
                                amount:g.items.reduce(function(total,item) {
                                    return total + item.DEBIT - item.CREDIT;
                                },0).toFixed(2)
                            });
                        });
                        summaryData.push({
                            summary:'Net Amount ',
                            amount:result.Data.Table[result.Data.Table.length-1].BALANCE.toFixed(2)
                        });
                        $scope.summaryOptions.data =summaryData;
                        
                        Object.keys(summaryData[0]).filter(function (key) {
                            if (summaryData[0].hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 ) {
                                
                                if(key==='amount')
                                {
                                    $scope.summaryOptions.columnDefs.push({name:key, cellTemplate: '<div><div ng-show="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents text-align-right" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>'  });
                                }
                                else
                                    $scope.summaryOptions.columnDefs.push({name:key, cellTemplate: '<div><div ng-show="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>'  });
                            }                        
                        });
                        if(result.Data.Table1 && result.Data.Table1.length>0){
                            var prop=$scope.id.split('-');
                            prop.shift();
                            prop.pop();
                            prop=prop.join('-');
                            $scope.Header=result.Data.Table1.find(x=>x.FilterValue==prop);
                        }

                        //$scope.printPreviewDesign();
                        //$scope.IsPrintDesign=false;
                    }, 900);
                    else
                        $scope.id= $scope.CurrentData[0].Id;

                    $scope.setReport(result.Data.Table);
                    var dateColumns = [];
                     
                    var obj1 =  result.Data.Table[0];
                    Object.keys(obj1).filter(function (key) {
                        if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 && key.toLowerCase().indexOf('date')>-1 ) {
                            dateColumns.push( key);
                        }                        
                    });
                    
                    angular.forEach(result.Data.Table,function(row){           
                        angular.forEach(dateColumns,function(dateColumn){                             
                            row[dateColumn]=$filter('date')(row[dateColumn], $scope.DateFormat);
                        });

                    });
                   
                    gridOption.data = result.Data.Table;
                 
                    //////
                    var cols=['DEBIT','CREDIT'];
                    Object.keys(obj1).filter(function (key) {
                        if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 ) {
                            if(print && cols.indexOf(key)>-1)
                            {
                                gridOption.columnDefs.push({name:key,aggregationType: uiGridConstants.aggregationTypes.sum,aggregationHideLabel:true,cellTemplate: '<div><div ng-show="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents text-align-right" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>'  });
                            }
                            else if(print && key==='BALANCE')
                            {
                                gridOption.columnDefs.push({name:key,aggregationType: uiGridConstants.aggregationTypes.last,aggregationHideLabel:true,cellTemplate: '<div><div ng-show="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents text-align-right" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>'  });
                            }
                            else
                                gridOption.columnDefs.push({name:key , cellTemplate: '<div><div ng-show="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>'  });
                        }                        
                    });
                    ////////
                  
                    gridOption.exporterCsvFilename = $scope.title+' Report.csv' ;
                    if(result.Data.Table1 && result.Data.Table1.length>0 && $scope.id){
                        var prop=$scope.id.split('-');
                        prop.shift();
                        prop.pop();
                        prop=prop.join('-');
                        $scope.Header=result.Data.Table1.find(x=>x.FilterValue==prop);
                    }
                    //$scope.Header=result.Data.Table1[0];
                    
                    gridOption.exporterPdfHeader.columns= [
                        { width: '20%',text:'image'},
                        { width: '60%', fontSize: 12, text: (!$scope.Header ? '' : $scope.Header.Name+  ' \n' +(!$scope.Header ? '' : ($scope.Header.Address + ' \n'))+(!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State + ', ' + $scope.Header.Country) + ' \n'+ $scope.title +' Report' )},
                        { width: '20%', text: ' \nPrint Date: '+$scope.CurrentDate+' '+ $scope.CurrentTime,   fontSize: 6 }
                    ];

                    /////// grouping here
                    $timeout(function () {
                        if(result.Data.Grouper && result.Data.Grouper.length>0){
                            var g=$scope.gridApi.grid;
                            var c= g.columns.find(x=>x.name===result.Data.Grouper[0].Grouper);

                            uiGridGroupingService.groupColumn(g,c);//// then run loop
                        }
                    }, 900);
                    
                }).catch(function (err) {
                    msg(err.Message);
                });
        };
        function toDataURL(src, outputFormat, callback) {
            var img = new Image();
            img.crossOrigin = 'Anonymous';
            img.onload = function() {
                 
                var canvas = document.createElement('CANVAS');
                var ctx = canvas.getContext('2d');
                var dataURL;
                canvas.height = this.naturalHeight;
                canvas.width = this.naturalWidth;
                ctx.drawImage(this, 0, 0);
                dataURL = canvas.toDataURL(outputFormat);
                console.log('RESULT:', dataURL)
                if(callback)
                    callback(dataURL);
                else 
                    $scope.gridOptions.exporterPdfHeader.columns= [
                        { width: '20%',image: dataURL},
                        { width: '60%', fontSize: 12, text: (!$scope.Header ? '' : $scope.Header.Name+  ' \n' +(!$scope.Header ? '' : ($scope.Header.Address + ' \n'))+(!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State + ', ' + $scope.Header.Country) + ' \n'+ $scope.title +' Report' )},
                        { width: '20%', text: ' \nPrint Date: '+$scope.CurrentDate+' '+ $scope.CurrentTime,   fontSize: 6 }
                    ];
                // $scope.gridOptions.exporterPdfHeader.columns[0]= { width: '20%',image:dataURL};
                //    return dataURL;
            };
            img.src = src;
            if (img.complete || img.complete === undefined) {
                img.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
                img.src = src;
            }
        }
        function getBase64Image(img ) {
             
            // Create an empty canvas element
            var canvas = document.createElement("canvas");
            //canvas.width = img.width|100;
            //canvas.height = img.height|100;

            // Copy the image contents to the canvas
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0);

            // Get the data-URL formatted image
            // Firefox supports PNG and JPEG. You could check img.src to
            // guess the original format, but be aware the using "image/jpg"
            // will re-encode the image.
            var dataURL = canvas.toDataURL("image/png");

            return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
        };

        $scope.reset = function () {
            $scope.DateFromString = "";
            $scope.DateToString = "";
            $scope.Report = [];
            $scope.Report.columns = [];
            $scope.IsLoaded = true;
            $scope.IsPrintDesign=false;
            angular.forEach($scope.FilterColumns, function (col) {
                col.MasterId="";
                col.MasterIds=[];
            
            });
        };
        $scope.save = function () {
             
            if (!$scope.GrouperColumn &&( !$scope.Report || !$scope.Report.length || $scope.Report.length < 1)) {
                msg('Nothing to save');
                return;
            }
            var dataToSave ='<table><tr><td colspan=4 align=center>'+$scope.title+'</td></tr><tr><td> </td></tr>';
            if($scope.IsDateRange) dataToSave +='<tr><td>Date From </td><td>'+ $scope.DateFromString+'</td><td> Date To </td><td>'+ $scope.DateToString+'</td></tr>';
            angular.forEach($scope.FilterColumns,function(col){
                dataToSave +='<tr><td>'+col.DisplayName+'</td><td>'+(col.DisplayValue?col.DisplayValue:'')+'</td></tr>';
            });
            dataToSave +='<tr><td> </td></tr></table>';

            dataToSave += document.getElementById('exportable').innerHTML;
            var blob = new Blob([dataToSave], {                //type: "application/vnd.ms-excel"
                type: "application/vnd.ms-excel"
                //type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
            });
            saveAs(blob, 'Report.xls');
        };
        $scope.saveCsv = function () {
             
            if (!$scope.GrouperColumn &&( !$scope.Report || !$scope.Report.length || $scope.Report.length < 1)) {
                msg('Nothing to save');
                return;
            }
            
            var el = document.getElementById('exportable');
            var dataToSave = el.outerText;
            //var dataToSave ="\uFEFF"+ document.getElementById('exportable').outerHTML;
            var blob = new Blob([dataToSave], {                
                // type: "application/json;charset=utf-8"
                type: "text/csv;charset=utf-8"
            });
            saveAs(blob, 'Report.csv');
        };
        $scope.sort = function (newSortingOrder) {
             
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;
            $scope.sortingOrder = newSortingOrder;
            if ($scope.sortingOrder !== '') {
                $scope.setReport($filter("orderBy")($scope.Report, $scope.sortingOrder, $scope.reverse));
            }
        };
        $scope.setReport=function(rpt){
        
            $scope.Report = rpt;
            var obj = rpt[0];
            if (!obj) {
                msg('No data found to display');
                return;
            }
            
            if($scope.GrouperColumn && $scope.GrouperColumn.DisplayName && $scope.GrouperColumn.DisplayName.length>0)
            {
                $scope.Report = $filter('orderBy')($scope.Report, $scope.GrouperColumn.DisplayName, $scope.reverse);
                $scope.Report = $filter('groupBy')($scope.Report, $scope.GrouperColumn.DisplayName);
            }
            $scope.Report.columns = Object.keys(obj).filter(function (key) {
                 
                if (obj.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0
                    //&& $scope.GrouperColumn.DisplayName!==key 
                    ) {
                    return key;
                }
            });
        
        };
        $scope.print = function () {
             
            var printContents = document.getElementById('exportable').innerHTML;
            var popupWin = window.open('', '_blank', 'width=700,height=600');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">');
            popupWin.document.write('<table><tr><td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>');
            popupWin.document.write('<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name+ '<br/>') );
            popupWin.document.write(!$scope.Header ? '' : ($scope.Header.Address + '<br/>'));
            popupWin.document.write((!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State + ', ' + $scope.Header.Country) + '<br/>');
            popupWin.document.write('<u><i>'+ $scope.title +' Report</i></u></h3></center></td>');
            popupWin.document.write('<td width=20%><br/><br/><br/><div align=right>Print Date: '+$scope.CurrentDate+' '+ $scope.CurrentTime +'</div></td></tr></table>');
            popupWin.document.write('<hr/><br/>'+printContents +'<hr/><br/>');
            //angular.forEach($scope.Footer, function(value, key) {
            //     
            //    popupWin.document.write( key + ': ' + value+' ');
            //});

            popupWin.document.write('</body></html>');
            popupWin.document.close();
        };
        $scope.printGrid = function () {
             
            var printContents = document.getElementById('exportable').innerHTML;
            var popupWin = window.open('', '_blank', 'width=700,height=600');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" />');
            popupWin.document.write('<link href="http://ui-grid.info/release/ui-grid.css" rel="stylesheet" type="text/css" /></head><body onload="window.print()">');
            //popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">');
            popupWin.document.write('<table><tr><td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>');
            popupWin.document.write('<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name+ '<br/>') );
            popupWin.document.write(!$scope.Header ? '' : ($scope.Header.Address + '<br/>'));
            popupWin.document.write((!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.State + ', ' + $scope.Header.Country) + '<br/>');
            popupWin.document.write('<u><i>'+ $scope.title +' Report</i></u></h3></center></td>');
            popupWin.document.write('<td width=20%><br/><br/><br/><div align=right>Print Date: '+$scope.CurrentDate+' '+ $scope.CurrentTime +'</div></td></tr></table>');
            popupWin.document.write('<hr/><br/>'+printContents +'<hr/><br/>');
            //angular.forEach($scope.Footer, function(value, key) {
            //     
            //    popupWin.document.write( key + ': ' + value+' ');
            //});

            popupWin.document.write('</body></html>');
            popupWin.document.close();
        };
        $scope.collapse = function () {
             
            angular.forEach($scope.Report, function(reportGroup) {
                 
                reportGroup.showChildren=!reportGroup.showChildren;
            });

        };

        $scope.reset();

        $scope.stringIsNumber=function (str) {
            // 
            var parsed = parseFloat(str);
            var casted = +str;
            return parsed === casted  && !isNaN(parsed) && !isNaN(casted);
            //var x = +s; // made cast obvious for demonstration
            //return x.toString() === s;
        }
        var loadReport = function (reportId, dateFromString, dateToString, dynamicFilters,filterValue) {
            return httpCaller1(ReportXPath + "api/Reporter/Report/Load", $http, $q, { reportId: reportId, dateFrom: dateFromString, dateTo: dateToString, dynamicFilters: dynamicFilters ,filterValue:filterValue});
        };
        var getReport = function (reportId) {
            return httpCaller1(ReportXPath + "api/Reporter/Report/Get", $http, $q, { reportId: reportId });
        };
        var getAllDynamic = function (table,reportId,filterValue,filterMasterId,filterMasterName, filterAccessTable, filterAccessColumn, filterAccessValue) {
            return httpCaller1(ReportXPath + "api/Reporter/Report/AllDynamic", $http, $q, { table: table,reportId :reportId,filterValue:filterValue, filterMasterId: filterMasterId, filterMasterName: filterMasterName, filterAccessTable: filterAccessTable, filterAccessColumn: filterAccessColumn, filterAccessValue: filterAccessValue  });
        };
        var getAllHeader= function (filterValue) {
            return httpCaller1(ReportXPath + "api/Reporter/Header/All", $http, $q, { filterValue: filterValue });
        };
        var getEnumList = function (path) {
            return httpCaller1(path, $http, $q);
        };
        var getDesignData= function (reportId, dateFromString, dateToString, dynamicFilters,filterValue, id) {
            return httpCaller1(ReportXPath + "api/Reporter/Report/GetDesignData", $http, $q, { reportId: reportId , dateFrom: dateFromString, dateTo: dateToString, dynamicFilters: dynamicFilters ,filterValue:filterValue, id: id });
        };
        
        var headers = { 'Accept': 'application/json; charset=utf-8' };
        var httpCaller1 = function (url, $http, $q, params) {
            var config = { headers: headers, params: params };
            var deferred = $q.defer();
            $http.defaults.useXDomain = true;
            try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e4) { }
            $http.get(url, config)
                .then(function (response) {
                    deferred.resolve(response.data);
                })
                .catch(function (ex) {
                     
                    msg(ex.data.Message);
                    deferred.reject(ex.data, status);
                });
            return deferred.promise;
        }

        $scope.getAllHeader = function () {
             
            getAllHeader($scope.PropertyID ).then(function (result) {
                if(result.Collection && result.Collection.length>0) $scope.xApiPath=result.Collection[0].ApiPath;
                $scope.selectReport();
            }).catch(function (err) {
                msg(err.Message);
            });

        };
        $scope.selectReport = function () {
            if (!$scope.ReportId) return;
            getReport($scope.ReportId)
             .then(function (result) {
                 var report = result.Data;
                 if (!report) return;
                  
                 $scope.title = report.Name;
                 $scope.FilterColumns = report.ReportColumns.filter(x => x.IsFilter === true);
                 angular.forEach($scope.FilterColumns, function (col) {
                      
                     if (col.FilterMaster){
                         
                         var promise;
                         if(col.IsEnum)
                             promise=getEnumList($scope.xApiPath + col.FilterMaster + '/all');
                         else
                             promise=getAllDynamic(col.FilterMaster, $scope.ReportId,  $scope.PropertyID,col.FilterMasterId,col.FilterMasterName,col.FilterAccessTable,col.FilterAccessColumn, $scope.UserId);
                         promise.then(function (result) {
                                       
                             col.Masters = result.Collection;
                             if(col.FilterType===1)
                                 col.Masters.unshift({Name:"ALL",Id:"ALL"});
                             else if(col.FilterType===2){
                                 col.MasterIds=[];
                                 $scope.filterDynamic();
                             }
                         }).catch(function (err) {
                                  
                             msg(err.Message);
                         });
                     }
                 });
                  
                 $scope.GrouperColumn= report.ReportColumns.find(x => x.IsGrouper === true);
                 $scope.IsDateRange= report.ReportColumns.find(x => x.IsDateRange === true);
                 $scope.Design = report.Design;
                 //var divDesign = $('#divDesign');
                 //divDesign[0].innerHTML=$scope.Design;

             }).catch(function (err) {
                 msg(err.Message);
             });

        };
        $scope.filterDynamic = function (column) {
           
            $scope.DynamicFilters = "";
            angular.forEach($scope.FilterColumns, function (col) {
                 
                if(col.FilterType===1)
                { 
                    column.MasterIdAll1=JSON.parse(column.MasterIdAll);
                    column.MasterId=column.MasterIdAll1.Id;
                    column.DisplayValue=column.MasterIdAll1.Name;
                    if (col.MasterId && col.MasterId!=="ALL") {
                        if ($scope.DynamicFilters.length > 5) $scope.DynamicFilters += " AND "
                        if(col.IsEnum)
                            $scope.DynamicFilters += " [" + col.FilterMasterId + "].[" + col.FilterMasterName + "]='" + col.MasterId+ "' ";
                        else
                            $scope.DynamicFilters += " [" + col.TableName + "].[" + col.Name + "]='" + col.MasterId+ "' ";
                    }
                }
                else if(col.FilterType===2)
                {
                    if (col.MasterIds) {
                        var multiFilter=col.MasterIds.length>0?"":"null";
                        angular.forEach(col.MasterIds, function (master) {
                             
                            if (multiFilter.length > 5) multiFilter += ","                          
                            multiFilter += "'" + master.Id+ "'";                        
                        });
                        if(col.IsEnum)
                            multiFilter=" [" + col.FilterMasterId + "].[" + col.FilterMasterName + "] IN (" +multiFilter +  ")";
                        else
                            multiFilter=" [" + col.TableName + "].[" + col.Name + "] IN (" +multiFilter +  ")";
                        if ($scope.DynamicFilters.length > 5) $scope.DynamicFilters += " AND "
                        $scope.DynamicFilters +=  multiFilter;
                    }
                }
            });
        };

        $scope.MasterSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
        $scope.myEventListeners = {
            onItemSelect:  $scope.filterDynamic,
            onItemDeselect:  $scope.filterDynamic,
            onSelectAll: $scope.filterDynamic,
            onDeselectAll: $scope.filterDynamic
        };
        $scope.getAllHeader ();        
        $scope.gridOptions = {
            enableFiltering: true,
            enableGroupHeaderSelection: true,
            treeRowHeaderAlwaysVisible: false,
            showColumnFooter: true,
            enableGridMenu: true,
            exporterCsvFilename: 'Report.csv',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfHeader: {margin: [60,30,60,10], style: 'headerStyle',   alignment: 'center',fontSize: 10  },
            exporterPdfTableStyle: { margin: [30, 10, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfFooter: function (currentPage, pageCount) { return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' }; },
            exporterPdfCustomFormatter: function (docDefinition) {
                 
                //docDefinition= {
                //    content: [
                //        { text: 'Dynamic parts', style: 'header' },
                //        table( $scope.gridOptions.data, $scope.gridOptions.columnDefs)
                //    ]
                //};
                
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                docDefinition.pageMargins= [40, 90, 40, 60];
              
                //docDefinition.content[0].table.body.forEach(function (row) {
                //     
                //    row.fillColor = 'red';

                //    //row.forEach(function (cell) {
                //    //     
                //    //    //if (typeof (cell) === 'string' && cell.toLowerCase() === 'target text') {
                //    //        cell.fillColor = 'red';
                //    //    //}
                //    //});
                //});
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            onRegisterApi: function( gridApi ) {
                
                $scope.gridApi = gridApi;
                //$scope.gridApi.grid.registerColumnsProcessor( setGroupValues, 410 );
                $scope.gridApi.selection.on.rowSelectionChanged( $scope, function ( rowChanged ) {
                      
                    if ( typeof(rowChanged.treeLevel) !== 'undefined' && rowChanged.treeLevel > -1 ) {
                        // this is a group header
                        children = $scope.gridApi.treeBase.getRowChildren( rowChanged );
                        children.forEach( function ( child ) {
                            if ( rowChanged.isSelected ) {
                                $scope.gridApi.selection.selectRow( child.entity );
                            } else {
                                $scope.gridApi.selection.unSelectRow( child.entity );
                            }
                        });
                    }
                });
                $scope.gridApi.grouping.on.aggregationChanged($scope, function(col){
                     
                    if ( col.treeAggregation.type ){
                        $scope.lastChange = col.displayName + ' aggregated using ' + col.treeAggregation.type;
                    } else {
                        $scope.lastChange = 'Aggregation removed from ' + col.displayName;
                    }
                }); 
                $scope.gridApi.grouping.on.groupingChanged($scope, function(col){
                     
                    //col.cellTemplate='<div><div ng-if="1===2" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD}}abec</div></div>';
                    //col.cellTemplate='<div><div ng-if="!col.grouping || col.grouping.groupPriority=== undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel ) " >hi</div><div ng-if="!col.grouping || col.grouping.groupPriority=== undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel ) " class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}abec</div></div>';
                    if ( col.grouping.groupPriority ){
                        $scope.lastChange = col.displayName + ' grouped with priority ' + col.grouping.groupPriority;
                        //col.cellTemplate='<div><div ng-if="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>';
                    } else {
                        $scope.lastChange = col.displayName + ' removed from grouped columns';
                    }
                    //angular.forEach($scope.CurrentData,function(row){           
                    //          
                    //        row[col.name]='';
                    //});
                    //$scope.gridOptions.data = $scope.CurrentData;
                });
 
            },
               
        };
        function table(data, columns) {
            return {
                table: {
                    headerRows: 1,
                    body: buildTableBody(data, columns)
                }
            };
        }

        function buildTableBody(data, columns) {
            var body = [];

            body.push(columns);

            data.forEach(function(row) {
                var dataRow = [];

                columns.forEach(function(column) {
                    dataRow.push(row[column.name].toString());
                })

                body.push(dataRow);
            });

            return body;
        }
        var setGroupValues = function( columns, rows ) {
             
            //var mg=$('#mygrid');
            //Object.keys(obj1).filter(function (key) {
            //     
            //    if (obj1.hasOwnProperty(key) && typeof key === 'string' && key.indexOf('$')!==0 ) {
            //        mg[key].cellTemplate='<div><div ng-if="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>';
            //    }                        
            //});

            //$scope.groupingColumns=[];
            columns.forEach( function( column ) {
                //column.cellTemplate='<div><div ng-if="1===2" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD}}abec</div></div>';
                //column.cellTemplate='<div><div ng-if="!col.grouping || col.grouping.groupPriority=== undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel ) " >hi</div><div ng-if="!col.grouping || col.grouping.groupPriority=== undefined || col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel ) " class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}abec</div></div>';
                //    if ( column.grouping && column.grouping.groupPriority > -1 ){
                //        // Put the balance next to all group labels.
                //        column.treeAggregationFn = function( aggregation, fieldValue, numValue, row ) {
                //            if ( typeof(aggregation.value) === 'undefined') {
                //                aggregation.value = 0;
                //            } 
                //            aggregation.value = aggregation.value + row.entity.balance;
                //        };
                //        column.customTreeAggregationFinalizerFn = function( aggregation ) {
                //            if ( typeof(aggregation.groupVal) !== 'undefined') {
                //                //  
                //                aggregation.rendered = aggregation.groupVal + ' (' + $filter('currency')(aggregation.value) + ')';
                //            } else {
                //                aggregation.rendered = null;
                //            }
                //        };
                //        //column.cellTemplate='new value';
                //        $scope.groupingColumns.push(column);
                //    }
            });
            //angular.forEach($scope.CurrentData,function(row){           
            //    angular.forEach($scope.groupingColumns,function(groupingColumn){                             
            //          
            //        row[groupingColumn.name]='';
            //    });
            //});
            //$scope.gridOptions.data = $scope.CurrentData;
            return columns;
        };

        $scope.models = {
            //selected: null,
            //templates: [
            //    { type: "label", id: 2 },
            //    { type: "container", id: 1, columns: [[], []] }
            //],
            dropzones: { "B": [] }
        };       
        $scope.printDesign = function () {
            $scope.IsPrintDesign=true;
            if(!$scope.CurrentData || $scope.CurrentData.length<1 ){
                msg('Please load data first.');
                return;
            }
            msg('Please wait loading ...',true);
            getDesignData($scope.ReportId, $scope.DateFromString, $scope.DateToString, $scope.DynamicFilters, $scope.PropertyID, $scope.id)    
                 .then(function(s){
                     $scope.Design=s.Data.Design;
                     $scope.models.dropzones = angular.fromJson(s.Data.Design);
                     if(s.Data.FilterTable && s.Data.FilterTable.length>0)
                     {
                         var dynamicFilter = s.Data.FilterTable + "='" + $scope.id+ "' ";
                         $scope.load(s.Data.FilterColumn,$scope.subtableOptions,dynamicFilter,true);
                     }
                     else
                         $timeout(function () {
                             $scope.printPreviewDesign();
                         }, 900);
          
                 },function(e){
                     msg(e.Message);
                 });
        };     
        $scope.printPreviewDesign = function () {

            var printDiv= document.getElementById('divDesign');
            var printContents = printDiv.outerHTML;
            var popupWin = window.open('', '_blank', 'width=700,height=600');
            popupWin.document.open();
            popupWin.document.write('<!doctype html><html><head><link rel="stylesheet" type="text/css" href="/Content/bootstrap.css" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="/Content/dndList.css" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="/Content/ui-grid.css" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="http://ui-grid.info/release/ui-grid.css" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="/Content/csv.js" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="/Content/pdfmake.js" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="/Content/vfs_fonts.js" />');
            popupWin.document.write('<link rel="stylesheet" type="text/css" href="/Content/ui-grid.js" />');
            popupWin.document.write('</head><body onload="window.print()">'+printContents+ '</body></html>');
            popupWin.document.close();
           
        };
        $scope.subtableOptions = {
            enableGroupHeaderSelection: true,
            treeRowHeaderAlwaysVisible: false,
            showColumnFooter: true,
            enableGridMenu: true,
            exporterCsvFilename: 'items.csv',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfHeader: {margin: [60,30,60,10], style: 'headerStyle',   alignment: 'center',fontSize: 10  },
            exporterPdfTableStyle: { margin: [30, 10, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfFooter: function (currentPage, pageCount) { return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' }; },
            exporterPdfCustomFormatter: function (docDefinition) {
                              
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                docDefinition.pageMargins= [40, 90, 40, 60];
              
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            onRegisterApi: function( gridApi ) {
                
                $scope.subtablegridApi = gridApi;
                //$scope.subtablegridApi.selection.on.rowSelectionChanged( $scope, function ( rowChanged ) {
                      
                //    if ( typeof(rowChanged.treeLevel) !== 'undefined' && rowChanged.treeLevel > -1 ) {
                //        children = $scope.subtablegridApi.treeBase.getRowChildren( rowChanged );
                //        children.forEach( function ( child ) {
                //            if ( rowChanged.isSelected ) {
                //                $scope.subtablegridApi.selection.selectRow( child.entity );
                //            } else {
                //                $scope.subtablegridApi.selection.unSelectRow( child.entity );
                //            }
                //        });
                //    }
                //});
               
            },
            //treeCustomAggregations:
        };
        $scope.summaryOptions = {
            enableGroupHeaderSelection: true,
            treeRowHeaderAlwaysVisible: false,
            showColumnFooter: true,
            enableGridMenu: true,
            exporterCsvFilename: 'summary.csv',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfHeader: {margin: [60,30,60,10], style: 'headerStyle',   alignment: 'center',fontSize: 10  },
            exporterPdfTableStyle: { margin: [30, 10, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfFooter: function (currentPage, pageCount) { return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' }; },
            exporterPdfCustomFormatter: function (docDefinition) {
                              
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                docDefinition.pageMargins= [40, 90, 40, 60];
              
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            onRegisterApi: function( gridApi ) {
                
                $scope.summarygridApi = gridApi;
                //$scope.summarygridApi.selection.on.rowSelectionChanged( $scope, function ( rowChanged ) {
                      
                //    if ( typeof(rowChanged.treeLevel) !== 'undefined' && rowChanged.treeLevel > -1 ) {
                //        children = $scope.summarygridApi.treeBase.getRowChildren( rowChanged );
                //        children.forEach( function ( child ) {
                //            if ( rowChanged.isSelected ) {
                //                $scope.summarygridApi.selection.selectRow( child.entity );
                //            } else {
                //                $scope.summarygridApi.selection.unSelectRow( child.entity );
                //            }
                //        });
                //    }
                //});
               
            },
               
        };

    }
]);
 