﻿
app.service('service', function ($http, $q) {

    this.AllData = [];

    this.getModuleList = function () {
        return httpCaller(apiPath + "configuration/Module/all", $http, $q);
    };
    this.getPaymentModeList = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/RevenueHead/GetAllBySettlementAndAdvance/" + propertyId, $http, $q);
    };
    this.getOutletList = function (propertyId) {
        return httpCaller(apiPath + 'PointOfSale/Outlet/allByPropertyIdmin/' + propertyId, $http, $q);
    };

    this.getAll = function (propertyId, options) {
        options.propertyId = propertyId;
        return httpCaller(apiPath + "GlobalSetting/SettlementMode/details", $http, $q, options);
    };
    this.getAllByModule = function (propertyId, moduleId) {
        return httpCaller(apiPath + "GlobalSetting/SettlementMode/allByModuleId/" + propertyId + "/" + moduleId, $http, $q);
    };
    this.save = function (model) {
        return httpPoster(apiPath + "GlobalSetting/SettlementMode/Save", $http, $q, model);
    };
    this.delete = function (propertyId, user, id) {
        var params = { propertyId: propertyId, user: user, id: id };
        return httpCaller(apiPath + "GlobalSetting/SettlementMode/Delete", $http, $q, params);
    };

});
