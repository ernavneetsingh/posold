﻿app.controller("VoucherViewController",
[
    "$scope", "VoucherViewService", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');

        $scope.Model = {};
        $scope.VoucherTypes = [];

        $scope.GetAllVoucherType = function () {
            
            service.GetAllVoucherType()
                .then(function (result) {
                    $scope.VoucherTypes = result.Collection;
                    $scope.VoucherTypes.push({ Id: '0', Name: 'ALL', Description: 'ALL' });
                    
                    angular.forEach($scope.VoucherTypes, function (item) {
                        item.Id = item.Id.toString();
                    })
                }, function (error) {
                    msg(error.Message);
                });
        }
        $scope.GetAllVoucherType();

        $scope.AllVouchers = [];
        $scope.IsLoadingAllVoucher = false;

        $scope.GetAllVoucher = function () {
            if (!$scope.VoucherTypeId)
            {
                msg("Please Select Voucher Type.");
                return;
            }
            if (!$scope.FromDate) {
                msg("Please Select From Date.");
                return;
            }
            if (!$scope.FromDate) {
                msg("Please Select From Date.");
                return;
            }
            $scope.AllVouchers = [];

            $scope.TotalDebit = 0;
            $scope.TotalCredit = 0;
            $scope.IsLoadingAllVoucher = true;
            service.GetAllVoucher($scope.VoucherTypeId,GetServerDate($scope.FromDate, $scope.DateFormat), GetServerDate($scope.ToDate, $scope.DateFormat), $scope.PropertyID)
                .then(function (result) {
                    $scope.AllVouchers = result.Collection;
                    var previousId = '';
                    angular.forEach($scope.AllVouchers, function (item) {
                        
                        if (previousId == item.Id)
                        {
                            item.VoucherDate = "";
                            item.PartyName = "";
                            item.VoucherType = "";
                            item.VoucherNo = "";
                            item.Narration = "";
                        }
                        else
                        {
                            previousId = item.Id;
                        }
                    });

                    if($scope.AllVouchers.length==0)
                    {
                        msg("No voucher found.");
                    }
                    $scope.IsLoadingAllVoucher = false;
                }, function (error) {
                    $scope.IsLoadingAllVoucher = false;
                    msg(error.Message);
                });
        }

        $scope.IsLoadingVoucherXML = false;

        $scope.GetVoucherXML = function () {
            if (!$scope.VoucherTypeId) {
                msg("Please Select Voucher Type.");
                return;
            }
            if (!$scope.FromDate) {
                msg("Please Select From Date.");
                return;
            }
            if (!$scope.FromDate) {
                msg("Please Select From Date.");
                return;
            }

            $scope.AllVouchers = [];
            $scope.TotalDebit = 0;
            $scope.TotalCredit = 0;
            $scope.IsLoadingVoucherXML = true;
            service.ExportXML($scope.VoucherTypeId, GetServerDate($scope.FromDate, $scope.DateFormat), GetServerDate($scope.ToDate, $scope.DateFormat), $scope.PropertyID)
                .then(function (result) {
                    $scope.IsLoadingVoucherXML = false;
                    var path = result.Data;
                    window.open(path, '_blank');
                }, function (error) {
                    $scope.IsLoadingVoucherXML = false;
                    msg(error.Message);
                });
        }

        $scope.IsLoadingAllMismatch = false;

        $scope.GetAllMismatch = function () {
            
            if (!$scope.FromDate) {
                msg("Please Select From Date.");
                return;
            }
            if (!$scope.FromDate) {
                msg("Please Select From Date.");
                return;
            }
            $scope.AllVouchers = [];

            $scope.TotalDebit = 0;
            $scope.TotalCredit = 0;
            $scope.IsLoadingAllMismatch = true;
            service.GetAllMismatch(GetServerDate($scope.FromDate, $scope.DateFormat), GetServerDate($scope.ToDate, $scope.DateFormat), $scope.PropertyID)
                .then(function (result) {
                    
                    $scope.AllVouchers = result.Collection;
                    
                    //var previousId = '';
                    //angular.forEach($scope.AllVouchers, function (item) {

                    //    if (previousId == item.Id) {
                    //        item.VoucherDate = "";
                    //        item.PartyName = "";
                    //        item.VoucherType = "";
                    //        item.VoucherNo = "";
                    //        item.Narration = "";
                    //    }
                    //    else {
                    //        previousId = item.Id;
                    //    }
                    //});

                    if ($scope.AllVouchers.length == 0) {
                        msg("No voucher found.");
                    }
                    $scope.IsLoadingAllMismatch = false;
                }, function (error) {
                    $scope.IsLoadingAllMismatch = false;
                    msg(error.Message);
                });
        }


        $scope.getTotalDebit = function(){
            var total = 0;
            angular.forEach($scope.AllVouchers,function(item){
                total += item.Debit;
            });

            //total = $filter("number")(parseFloat(total), 3).replace(/,/g, "");
            return total;
        }
        $scope.getTotalCredit = function(){
            var total = 0;
            angular.forEach($scope.AllVouchers,function(item){
                total += item.Credit;
            });
            //total = $filter("number")(parseFloat(total), 3).replace(/,/g, "");
            return total;
        }

        $scope.Reset = function () {
            $scope.Model = {};
        }

        $scope.SetVoucherType = function (voucherType) {
            $scope.VoucherTypeId = voucherType.Id;
        }
    }
]);
