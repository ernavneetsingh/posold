﻿'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var linkModule = [];

        var GetUser = function (propertyId) {

            var url = apiPath + 'GlobalSetting/Employee/GetAllByUser/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAuthorization = function () {

            var url = apiPath + 'configuration/AuthorizationCategory/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getItems = function (authorizationCategoryId) {

            var url = apiPath + 'configuration/GetAllByAuthorizationCategoryId/all?authorizationCategoryId=' + authorizationCategoryId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getItems = function () {

            var url = apiPath + 'configuration/AuthorizationOption/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getData = function (propertyId, options) {

            var url = apiPath + "PointOfSale/POSUser/all/" + propertyId + "?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order +
                "&searchfor=" + options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                //deferred.resolve(result.Collection);
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {

            var url = apiPath + 'PointOfSale/POSUser/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var remove = function (id) {

            var url = apiPath + 'PointOfSale/POSUser/delete/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                parent.failureMessage(data.Message);
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {

            var url = apiPath + 'PointOfSale/POSUser/status';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        return {
            dataModel: linkModule,
            GetUser: GetUser,
            getAuthorization: getAuthorization,
            getItems: getItems,
            getData: getData,
            save: save,
            remove: remove,
            statusChange: statusChange

        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
