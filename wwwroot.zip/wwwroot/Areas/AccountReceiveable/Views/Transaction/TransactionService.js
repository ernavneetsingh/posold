﻿
app.service("transactionService", function ($http, $window, $q, $filter, periodCloseService) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.suggest = function (propertyId, item, txt) {

        var param = JSON.stringify({ "propertyId": propertyId, "item": item, "txt": txt });
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Transaction/Suggest/" + propertyId + "/" + item + "/" + txt,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.suggestBank = function (txt) {
        //var param = JSON.stringify({ "propertyId": propertyId, "item": item, "txt": txt });
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "referencedata/bank/suggest/" + txt,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.search = function (propertyId, item, txt) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "GlobalSetting/Corporate/Search/" + propertyId + "/" + item + "/" + txt,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {

            deferred.reject(err, status);
            msg(err.Message);
        });
        return deferred.promise;
    }
    this.searchBank = function (txt) {
        //var param = JSON.stringify({ "propertyId": propertyId, "item": item, "txt": txt });
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "referencedata/bankbranch/" + txt,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.getNetworkList = function () {
        return httpCaller(apiPath + "referencedata/CreditCardNetwork", $http, $q);
    };

    this.getBankAccounts = function (propertyId) {
        return httpCaller(apiPath + "Tally/BankAccountMap/GetAllBankAccount/" + propertyId, $http, $q);
    };

    this.getPercentageTypeList = function () {
        return httpCaller(apiPath + "ReferenceConstant/PercentageType/all", $http, $q);
    };

    this.Get = function (propertyId, dateFormat) {
        return httpCaller(apiPath + "AccountReceiveable/Transaction/all/" + propertyId + "/" + dateFormat, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/Transaction/all/" + propertyId + "/" + dateFormat,
        //    params: {},
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    success: function () {
        //    },
        //    error: function (data) {

        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.GetDefaults = function (propertyId, dateFormat) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Transaction/GetDefaults/" + propertyId + "/" + dateFormat,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;

    };
    this.getPaymentModes = function (propertyId, moduleId) {
        return httpCaller(apiPath + "GlobalSetting/SettlementMode/allByModuleId/" + propertyId + "/" + moduleId, $http, $q);
    };
    this.getPendingBills = function (propertyId, corporateId, dateFormat, inv) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Transaction/GetPendingBills/" + propertyId + "/" + corporateId + "/" + dateFormat + "/" + (inv ? inv.Id : "all"),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.save = function (model, billNos, billAmounts) {

        var addUrl = '?billNos=&billAmounts=';
        if (billNos.length > 2) addUrl = '?billNos=' + billNos + '&billAmounts=' + billAmounts;
        var deferred = $q.defer();
        $http({
            method: "POST",
            url: apiPath + "AccountReceiveable/Transaction/Save" + addUrl,
            data: model,
            headers: { 'duxtechApiKey': accessToken }
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            msg(err.Message);
            deferred.reject(status);
        });

        return deferred.promise;
    };
    this.delete = function (id, user, propertyId, modifiedDate) {
        var deferred = $q.defer();
        var param = { "Id": id, "ModifiedBy": user, "PropertyID": propertyId, "modifiedDate": modifiedDate };
        $http({
            method: "POST",
            url: apiPath + "AccountReceiveable/Transaction/Delete",
            data: param,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {

            msg(err.Message);
            deferred.reject(err, status);
            //parent.failureMessage($.parseJSON(result.responseText).Message);
            //$window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        });
        return deferred.promise;
    };

});
