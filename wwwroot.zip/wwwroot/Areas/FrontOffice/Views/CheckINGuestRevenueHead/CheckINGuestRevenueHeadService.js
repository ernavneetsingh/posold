﻿app.service('CheckINGuestRevenueHeadService', ["$http", "$q",
    function ($http, $q) {

        this.getAllGroup = function (propertyId, occupiedStatusId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetAllGroup", $http, $q, { propertyId: propertyId, occupiedStatusId: occupiedStatusId, businessDate: businessDate });
        };
        this.getAllGroupMember = function (checkINGuestId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetAllGroupMember", $http, $q, { checkINGuestId: checkINGuestId, businessDate: businessDate });
        };

        this.getRevenueHeadList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/RevenueHead/GetAllByRevenueTypeId/" + propertyId + "/1", $http, $q);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckINGuest/SaveRevenueHead", $http, $q, model);
        };
    }
]);
