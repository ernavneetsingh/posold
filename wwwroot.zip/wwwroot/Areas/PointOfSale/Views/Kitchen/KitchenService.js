﻿
'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var GetCostCenters = function (propertyId, active) {
            return httpCaller(apiPath + "GlobalSetting/CostCenter/all/?propertyId=" + propertyId + "&active=" + active, $http, $q);
        };

        var getData = function (propertyId) {

            var url = apiPath + 'PointOfSale/Kitchen/allByPropertyId/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {

            var url = apiPath + 'PointOfSale/Kitchen/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var remove = function (id) {

            var url = apiPath + 'PointOfSale/Kitchen/delete/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                parent.failureMessage(data.Message);
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {

            var url = apiPath + 'PointOfSale/Kitchen/status';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var isCodeExist = function (PropertId, code) {

            var url = apiPath + 'PointOfSale/Kitchen/IsCodeExist/' + PropertId + "/" + code;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        return {
            getData: getData,
            save: save,
            remove: remove,
            statusChange: statusChange,
            isCodeExist: isCodeExist,
            GetCostCenters: GetCostCenters

        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
