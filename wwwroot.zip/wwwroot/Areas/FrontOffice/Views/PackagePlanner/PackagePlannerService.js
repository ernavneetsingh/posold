﻿
(function () {

    function rateMasterService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        //var _roomRateData = [];

        var getAllPackage = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath +
                    "frontoffice/Package/details/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (error) {
                        deferred.reject(error);
                    });
            return deferred.promise;
        };

        var save = function (model) {
            return httpPoster(apiPath + "FrontOffice/PackagePlanner/Save", $http, $q, model);
        };

        var remove = function (model) {
            return httpPoster(apiPath + "FrontOffice/PackagePlanner/Remove", $http, $q, model);
        };
        
        var GetRateType = function () {
            var url = apiPath + 'ReferenceConstant/RateType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getYearCalendar = function (startdate, numberOfYears,propertyId,rateTypeId,packageId) {
            var deferred = $q.defer();
            $http.get(apiPath + 'FrontOffice/PackagePlanner/GetYearCalendar/' + startdate + "/" + numberOfYears + "/" + rateTypeId + "/" + packageId + "/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getWeekDay = function (propertyId) {

            var url = apiPath + 'ReferenceData/Calendar/WeekDay/';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };


        return {
            getAllPackage: getAllPackage,
            remove: remove,
            save: save,
            GetRateType: GetRateType,
            getYearCalendar: getYearCalendar,
            getWeekDay: getWeekDay,
        };
    }

    app.factory("packagePlannerService", ["$http", "$q", rateMasterService]);
})();
