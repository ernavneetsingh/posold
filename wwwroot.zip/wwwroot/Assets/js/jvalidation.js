﻿function ValidateEmail(email) {
    var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    return expr.test(email);
}

function chkEmailvalidation(varthismail) {
    var txtEmail = $(varthismail);
    if (ValidateEmail(txtEmail.val()))
        txtEmail.css('border', '1px solid rgb(195, 193, 193)');
    else
        txtEmail.css('border', '1px solid red');
}

function run(field) {
    setTimeout(function () {
        var regex = /\d*\.?\d?\d?/g;
        field.value = regex.exec(field.value);
    }, 0);
}



jQuery(document).ready(function () {
    $(".requiredData").each(function () {

        $(this).focus(function () {
           
            $(this).removeClass("validateClass");
        });
    });
    $(".requiredDropdown").each(function () {

        $(this).focus(function () {
            //alert("Handler for .focus() called.");
            $(this).removeClass("validateClass");
        });
    });
    $(".Specialchar").keypress(function (e) {
        var regex = new RegExp("^[a-zA-Z0-9 ]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            return true;
        }
        e.preventDefault();
        return false;
    });
});



function validateForm() {
    
    
    var counter = 0;
    
    $(".requiredData").each(function () {

        if ($(this).val().trim() == '' || $(this).val() == null) {
            $(this).addClass("validateClass");
            counter++;
          
        }
    });
    
    $(".requiredDropdown").each(function () {
       
        if ($(this).val() == '' || $(this).val() == '0' || $(this).val() == null) {
            $(this).addClass("validateClass");
            counter++;
        }
    });
    if (counter > 0) {
        
        return false;
    }
    else {
        return true;
    }
}


// validation for only decimal and integer values accepts  madan
function isdecimalkey(txt, event) {
    
    var charCode = (event.which) ? event.which : event.keyCode
    if (charCode == 46) {
        if (txt.value.indexOf(".") < 0)
            return true;
        else
            return false;
    }

    if (txt.value.indexOf(".") > 0) {
        var txtlen = txt.value.length;
        var dotpos = txt.value.indexOf(".");
        if ((txtlen - dotpos) > 2)
            return false;
    }

    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}



// mobile validation
function mobileval(id, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    var str = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
    if ($("#" + id).val() == "") {

        var regex = new RegExp("^[1-9]*$");
        if (regex.test(str)) {
            return true;
        }
    }
    else {

        var regex1 = new RegExp("^[0-9]*$");
        if (regex1.test(str)) {
            return true;
        }
    }

    evt.preventDefault();
    return false;

}


function mobileblur(id) {
    var str = $("#" + id).val();
    if (str.indexOf('0') == 0) {
        $("#" + id).val('')
    }
}

  // upload only image file madan 
        $(function () {
            $('.imagevalidation').change(function () {
                var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
                if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1)
                    $('#dialog-confirm').dialog({
                        buttons: {
                            Cancel: function () {

                                $(this).dialog("close");
                                $('input[type=file]').val('');
                                return true;
                            }
                        }
                    });

                return false;

            })
        })
// only integer values
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

            return true;
        }

// email validation  madan
        $(function () {
            jQuery('.emailvalidation').change(function () {
                var $email = this.value;
                validateEmail($email);
            });
            function validateEmail(email) {
                var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                if (!emailReg.test(email)) {
                    $('.error').fadeIn(100);
                }
                else {
                    $('.error').fadeIn(100).hide();
                }
                return false;
            }
        })



        function checkTextAreaMaxLength(textBox, e, length) {

            var mLen = textBox["MaxLength"];
            if (null == mLen)
                mLen = length;

            var maxLength = parseInt(mLen);
            if (!checkSpecialKeys(e)) {
                if (textBox.value.length > maxLength - 1) {
                    if (window.event)//IE
                    {
                        e.returnValue = false;
                        return false;
                    }
                    else//Firefox
                        e.preventDefault();
                }
            }
        }

        function checkSpecialKeys(e) {
            if (e.keyCode != 8 && e.keyCode != 46 && e.keyCode != 35 && e.keyCode != 36 && e.keyCode != 37 && e.keyCode != 38 && e.keyCode != 39 && e.keyCode != 40)
                return false;
            else
                return true;
        }
   