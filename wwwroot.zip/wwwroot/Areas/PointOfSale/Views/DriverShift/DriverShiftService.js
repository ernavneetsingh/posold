﻿
(function () {

    function driverShiftService($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var saveShiftChart = function (model) {
            return httpPoster(apiPath + "PointOfSale/DriverShift/save", $http, $q, model);
            //var deferred = $q.defer();
            //$.ajax({
            //    type: "POST",
            //    url: apiPath + "PointOfSale/DriverShift/save",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    data: JSON.stringify(model),
            //    headers: {
            //        'duxtechApiKey': accessToken
            //    },
            //    success: function (data) {
            //        deferred.resolve(data);
            //    },
            //    error: function (data, status, headers, config) {
            //        deferred.reject(data, status, headers, config);
            //    }
            //});
            //return deferred.promise;
        };

        var getDrivers = function (propertyId) {
            var params = { propertyId: propertyId };
            return httpCaller(apiPath + "PointOfSale/Driver/allByPropertyId", $http, $q, params);
            //var deferred = $q.defer();
            //$http.get(apiPath + "PointOfSale/Driver/allByPropertyId/" + propertyId)
            //    .then(function (result) {
            //        deferred.resolve(result.data);
            //    },
            //        function (data, status, headers, config) {
            //            deferred.reject(data, status, headers, config);
            //        });
            //return deferred.promise;
        };

        var getDriverShift = function (propertyId, date) {

            var params = { propertyId: propertyId, date: date };
            return httpCaller(apiPath + "PointOfSale/DriverShift/all", $http, $q, params);

            //var deferred = $q.defer();
            //$http.get(apiPath + "PointOfSale/DriverShift/all/" + date + "/" + propertyId)
            //    .then(function (result) {
            //        deferred.resolve(result.data);
            //    },
            //        function (data, status, headers, config) {
            //            deferred.reject(data, status, headers, config);
            //        });
            //return deferred.promise;
        };

        var getBusinessShift = function (businessDate) {
            var params = { dateTime: businessDate };
            return httpCaller(apiPath + "PointOfSale/DriverShift/business", $http, $q, params);

            //var deferred = $q.defer();
            //$http.get(apiPath + "PointOfSale/DriverShift/business/?dateTime=" + businessDate)
            //    .then(function (result) {
            //        deferred.resolve(result.data);
            //    },
            //        function (data, status, headers, config) {
            //            deferred.reject(data, status, headers, config);
            //        });
            //return deferred.promise;
        };

        var getMonthDaysTime = function (dateTime) {

            var params = { dateTime: dateTime };
            return httpCaller(apiPath + "PointOfSale/DriverShift/GetMonthDaysTime", $http, $q, params);
            //var deferred = $q.defer();
            //$http.get(apiPath + "PointOfSale/DriverShift/GetMonthDaysTime/" + datetime)
            //    .then(function (result) {
            //        deferred.resolve(result.data);
            //    },
            //        function (data, status, headers, config) {
            //            deferred.reject(data, status, headers, config);
            //        });
            //return deferred.promise;
        };

        return {
            saveShiftChart: saveShiftChart,
            getDrivers: getDrivers,
            getDriverShift: getDriverShift,
            getBusinessShift: getBusinessShift,
            getMonthDaysTime: getMonthDaysTime
        };
    }

    app.factory("DriverShiftService", ["$http", "$q", driverShiftService]);
})();
