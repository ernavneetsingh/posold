﻿
app.service('VoucherViewService', [
    '$http', '$q', function ($http, $q) {
        
        this.GetAllVoucherType = function () {
            return httpCaller(apiPath + "ReferenceConstant/VoucherType/All", $http, $q);
        };

        //FOR All voucherTypeId=0 
        this.GetAllVoucher = function (voucherTypeId,fromDate, toDate, propertyId) {
            return httpCaller(apiPath + "Tally/Voucher/GetAllVoucher/" + voucherTypeId + "/" + fromDate + "/" + toDate + "/" + propertyId, $http, $q);
        };

        this.GetAllMismatch = function (fromDate, toDate, propertyId) {
            return httpCaller(apiPath + "Tally/Voucher/GetAllMismatch/" + fromDate + "/" + toDate + "/" + propertyId, $http, $q);
        };

        this.ExportXML = function (voucherTypeId, fromDate, toDate, propertyId) {
            return httpCaller(apiPath + "Tally/Voucher/ExportXML/" + voucherTypeId+ "/" + fromDate + "/" + toDate + "/" + propertyId, $http, $q);
        };

    }
]);
