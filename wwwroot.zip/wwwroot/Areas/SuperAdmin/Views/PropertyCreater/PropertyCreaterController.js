﻿
app.controller('PropertyCreaterController', ['$scope', 'PropertyCreaterService', 'localStorageService', '$filter',
    function ($scope, service, localStorageService, $filter) {

        $scope.save = function (f) {
            $scope.model.ProductName = "cm";
            service.save($scope.model)
                .then(function (s) {
                    parent.successMessage(s.Message);
                }, function (e) {
                    parent.failureMessage(e.Message);
                });
        };

    }]);
