﻿
app.controller("controller", ["$scope", "service", "localStorageService", function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = false;
    $scope.Model.IsExportToExcel = false;
    var sortKeyOrder = {
        key: "",
        order: "",
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 10;
    $scope.recordsPerPage = 10;
    $scope.numberOfPageButtons = 10;

    getData($scope, service, localStorageService);

    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get("sortKeyOrder");
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == "ASC")
                sortKeyOrder.order = "DESC";
            else
                sortKeyOrder.order = "ASC";
            localStorageService.set("sortKeyOrder", sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: "ASC"
            };
            localStorageService.set("sortKeyOrder", sortKeyOrder);
        }
    };
    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };
    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    };
    $scope.Edit = function (item) {
        
        $scope.Model = item;

        angular.forEach($scope.Modules, function (value, key) {
            
            if (value.Id == item.ModuleId) {
                $scope.selectedModelModule = $scope.Modules[key];
                $scope.ModuleChange($scope.selectedModelModule);
            }
        })

        angular.forEach($scope.selectedModelModule.SubModules, function (value, key) {
            if (value.Id == item.SubModuleId) {
                $scope.selectedModelSubModule = $scope.SubModules[key];
            }
        })

        scrollPageOnTop();
    };

    $scope.Reset = function () {
        $scope.Model = {};
        $scope.Model.IsActive = false;

        clearForm();
        $scope.searchfor = null;
        $scope.search();
        scrollPageOnTop();
    };

    $scope.ShowErrorMessage = false;

    $scope.Save = function (model, form) {
        
        if ($scope[form].$valid) {
            model.ModuleId = $scope.selectedModelModule.Id;
            model.SubModuleId = $scope.selectedModelSubModule.Id;

            var promiseGet = service.save(model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);
                parent.successMessage(data.Message);
                $scope.Reset();
            },
            function (data, status, headers, config) {
                parent.failureMessage(data.Message);
            });
        } else {
            $scope.ErrorMessage = true;
        }
    };

    function clearForm() {
        
        $scope.Imagename = "";
        $scope.Description = "";

        angular.forEach(angular.element("input[type='file']"),
            function (inputElem) {
                angular.element(inputElem).val(null);
            });

    };

    $scope.IsNameExist = function (model) {
        var promiseGet = service.isNameExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.Name = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };
    $scope.IsOrderSNoExist = function (model) {
        
        model.ModuleId = $scope.selectedModelModule.Id;
        var promiseGet = service.isOrderSNoExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.OrderSNo = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };
    $scope.IsUrlExist = function (model) {
        
        var promiseGet = service.isUrlExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.Url = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };

    $scope.ChangeStatus = function (id) {

        var promiseGet = service.changeStatus(id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };


    $scope.Modules = [];

    GetAllModels();

    function GetAllModels() {
        
        var promiseGet = service.getAllModules();
        promiseGet.then(function (data) {
            
            $scope.Modules = data;
        },
        function (data) {
            
            parent.failureMessage(data.Message);
        });
    }

    $scope.ModuleChange = function (selectedModelModule) {
        
        $scope.SubModules = [];

        if (selectedModelModule != null) {

            $scope.SubModules = selectedModelModule.SubModules;
        }
    }

}
]);

var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "OrderSNo",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getAll(options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};