﻿
var FreightChargeService = function ($http, $q, $filter) {

    var service = this;
    var scope;

    service.init = function ($scope,callbackForTotal) {
        scope = $scope;

        service.getFreightRevenueHeads = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/RevenueHead/revenuedetails/" + propertyId + "/8", $http, $q);
        };

        service.loadFreightRevenueHeads = function () {
            service.reset();
            service.getFreightRevenueHeads(scope.PropertyID)
                .then(function (s) {
                    scope.FreightRevenueHeads = s.Collection;
                });
        };
        service.reset = function () {
            scope.Charges = [{}];
            scope.IsFreightCharges = false;
        };
        service.setCharges = function (c) {
            scope.Charges = c;
            scope.Charges.push({});
            scope.IsFreightCharges = true;
        };
        service.addCharge = function (revenueHeadId) {
            scope.FreightRevenueHeads.forEach(function(frh){
                if(revenueHeadId===frh.Id)
                    frh.isDisabled=true;
            });
            scope.Charges.push({});
        };
        service.deleteCharge = function (i) {
            var c= scope.Charges[i];
            scope.Charges.splice(i, 1);
            if (scope.Charges.length <= 0) scope.Charges = [{}];
            service.total();
            scope.FreightRevenueHeads.forEach(function(frh){
                if(c.RevenueHeadId===frh.Id)
                    frh.isDisabled=false;
            });
        };
       
        service.callbackForTotal=callbackForTotal;
        scope.freightChargeServiceTotal=0;
        service.total = function (notFreightCharges) {
            scope.freightChargeServiceTotal=notFreightCharges?0:scope.Charges.reduce((acc,current) => acc + parseFloat(current.Amount?current.Amount:0), 0);
            if(service.callbackForTotal) service.callbackForTotal();
        };
        
        service.loadFreightRevenueHeads();
        return service;
    };

};

app.service('FreightChargeService', ['$http', '$q', '$filter', FreightChargeService]);
