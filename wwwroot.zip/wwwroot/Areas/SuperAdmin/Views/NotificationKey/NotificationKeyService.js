﻿'use strict';
(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var model = [];

        var getAll = function (profileid) {

            var url = apiPath + "configuration/NotificationKey/GetAll/";
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {
            var url = apiPath + 'configuration/NotificationKey/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }

        var changeStatus = function (id) {

            var url = apiPath + 'configuration/NotificationKey/status/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var getAllModules = function () {

            var deferred = $q.defer();

            $http.get(apiPath + 'configuration/module/all')
                .then(function (result) {
                    deferred.resolve(result.data.Collection);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });

            return deferred.promise;
        };

        var getAllModuleOperationTypes = function () {

            var deferred = $q.defer();

            $http.get(apiPath + 'ReferenceConstant/ModuleOperationType/all')
                .then(function (result) {
                    deferred.resolve(result.data.Collection);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });

            return deferred.promise;
        };

        return {
            dataModel: model,
            getAll: getAll,
            save: save,
            changeStatus: changeStatus,
            getAllModules: getAllModules,
            getAllModuleOperationTypes: getAllModuleOperationTypes,
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
