﻿$(function () {
    $("#hideshowcoverbox").css("display", "none");

    $("#cardbox").fadeIn("fast");
    $("#tabelbox").fadeIn("fast");
    $("#roombox").fadeIn("fast");
    $("#posItemBox").fadeIn("fast");
    
    $(".universalkeyboard").hide();
    var selectoutlet = (".selectoutletnav li a");

    $(selectoutlet).click(function () {
        $(this).addClass("active");
        $(this).bind("click", function () {
            $(selectoutlet).removeClass("active");
        });
    });

    $("#onetwo").click(function () {
        $("#numericd").show("fast");
        $("#alpha").hide("fast");
    });

    $("#abc").click(function () {
        $("#alpha").show("fast");
        $("#numericd").hide("fast");
    });

    //$("#addcashbtn").click(function () {
    //    $("#addcashbox").show("slow");
    //});

    //$("#addcashcloseicon").click(function () {
    //    $("#addcashbox").hide("slow");
    //});

    //$("#cashoutlink").click(function () {
    //    $("#cashoutbox").show("slow");
    //});

    //$("#cashoutcloseicon").click(function () {
    //    $("#cashoutbox").hide("slow");
    //});

    $(".tablebking_outlethead li a").click(function () {
        $("li a").removeClass("tablebking_outelet-active");
        $(this).addClass("tablebking_outelet-active");
    });

    $("#food").click(function () {
        $(".pagecontent-tblbkng-menutyp ul.horizon-nav").css("width", "100%");
        $(".pagecontent-tblbkng-menutyp ul.horizon-nav li").css("float", "none").css("margin-bottom", "5px").css("font-size", "12px");
        $(".pagecontent-tblbkng-menutyp ul.horizon-nav li a").css("padding", "13px 10px");
        $(".pagecontent-tblbkng-menutyp .category ul.category-nav").css("width", "86%");
        $("#categorybox").show("slow");
    });

    $("#food").click(function () {
        $(".categorysec ul.horizon-nav").css("width", "100%");
        $(".categorysec ul.horizon-nav li").css("float", "none").css("margin-bottom", "5px").css("font-size", "12px");
        $(".categorysec ul.horizon-nav li a").css("padding", "13px 10px");
        $(".categorysec .category ul.category-nav").css("width", "86%");
        $("#categorybox").show("slow");
    });

    $(".horizon-nav li a").click(function () {
        $("li a").removeClass("selectmenu");
        $(this).addClass("selectmenu");
    });

    $(".tbl-trnsfr li a").click(function () {
        $("li a").removeClass("tbltrnsfr-active");
        $(this).addClass("tbltrnsfr-active");
    });

    //$("#generatebilllink").click(function () {
    //    $(".billingsec ul.horizon-nav").css("width", "15%");
    //    $(".billingsec ul.horizon-nav li").css("float", "none").css("margin-bottom", "5px").css("font-size", "12px");
    //    $(".billingsec ul.horizon-nav li a").css("padding", "13px 8px");
    //    $(".billingsec .category ul.category-nav").css("width", "85%");
    //    $(".billingsec .category ul.category-nav li").css("width", "auto");
    //    $("#generatebillbox").show("fast");
    //    $("#discountBox").hide("fast");
    //    $("#taxexemptedbox").hide("fast");
    //    $("#amountdiscountbox").hide("fast");
    //    $("#groupdiscountbox").hide("fast");
    //    $("#splitorderbox").hide("fast");
    //    $("#billingtablebox").show();
    //});



    $("#closeinput").click(function (e) {
        e.preventDefault();
        $("#hideshowcoverbox").css("display", "none");
    });

    //$("#percetangelabel").click(function () {
    //    $("#billingpercentagebox").show("fast");
    //    $("#amountdiscountbox").hide("fast");
    //    $("#billinggroupdiscountbox").hide("fast");
    //});

    //$("#amountdiscountlabel").click(function () {
    //    $("#billingpercentagebox").hide("fast");
    //    $("#amountdiscountbox").show("fast");
    //    $("#billinggroupdiscountbox").hide("fast");
    //});

    //$("#groundiscountlabel").click(function () {
    //    $("#billingpercentagebox").hide("fast");
    //    $("#amountdiscountbox").hide("fast");
    //    $("#billinggroupdiscountbox").show("fast");
    //});

    $('.ordermenu ul li a').click(function () {
        $('li a').removeClass('active');
        $(this).addClass('active');

    });



});

$.fn.clickOff = function (callback, selfDestroy) {
    var clicked = false;
    var parent = this;
    var destroy = selfDestroy || true;
    parent.click(function () {
        clicked = true;
    });
    $(document).click(function (event) {
        if (!clicked) {
            callback(parent, event);
        }
        if (destroy) {

        };
        clicked = false;
    });
};
$("#closesourcetable1box").click(function () {
    $("#sourcetable1box").hide();
});

$("#closedestinationtablebox").click(function () {
    $("#destinationtablebox").hide();
});


$("#closesourcetablebox").click(function () {
    $("#sourcetablebox").hide();
});

$("#closetableboollinkbox").click(function () {
    $("#tableboollinkbox").hide();
});
/*
$("#hidetab").click(function () {
    $("#sourcetablebox").hide();
});

$("#hidetab2").click(function () {
    $("#tableboollinkbox").hide();
});

$("#hidetab3").click(function () {
    $("#sourcetable1box").hide();
});

$("#hidetab4").click(function () {
    $("#destinationtablebox").hide();
});

$("#tablelink").clickOff(function () {
    $("#tableboollinkbox").slideUp("slow");
});

$("#LinkSourceTableName").clickOff(function () {
    $("#sourcetablebox").slideUp(7000);
});


$("#DestinationTableName").clickOff(function () {
    $("#destinationtablebox").show();
});

$("#SourceTable").clickOff(function () {
    $("#sourcetable1box").slideUp("slow");
});



$("#LocationDestinationTable").clickOff(function () {
    $("#TransferLocation").slideUp("slow");
});
*/

/*Table Booking Head Navas Show & Hide Divs code starts from here*/

function fadeOut() {
    $("#cardbox").fadeOut("fast");
    $("#packagebox").fadeOut("fast");
    $("#tabelbox").fadeOut("fast");
    $("#roombox").fadeOut("fast");
    
    $("#steawardbox").fadeOut("fast");
    $("#menutypebox").fadeOut("fast");
    $("#openitembox").fadeOut("fast");
    $("#tbletrnsfrtblelnk").fadeOut("fast");
    $("#voidkotbox").fadeOut("fast");
    $("#repeatorderbox").fadeOut("fast");
    $("#nckotbox").fadeOut("fast");
    $("#billingbox").fadeOut("fast");
    $("#addkotbox").fadeOut("fast");
    $("#billreprintbox").fadeOut("fast");
    $("#modifierbox").fadeOut("fast");
    $("#happyhoursbox").fadeOut("fast");
    $("#multirestaurentbox").fadeOut("fast");
    $("#transferlocationbox").fadeOut("fast");
    $("#posItemBox").fadeOut("fast");
    $("#subCategorybox").fadeOut("fast");
    $("#categoryboxo").fadeOut("fast");
    $("#functionbox").fadeOut("fast");
    $("#voidbillbox").fadeOut("fast");
    $("#borrowMenu").fadeOut("fast");
    $("#deliverystatusbox").fadeOut("fast");
    $("#Settlemntbox").fadeOut("fast");
    $("#deliverycustomerkot").fadeOut("fast");

}

function pmsOperation(tabs) {


    if (tabs == "cards") {
        fadeOut();
        $("#cardbox").fadeIn("fast");
    }

    if (tabs == "package") {
        fadeOut();
        $("#packagebox").fadeIn("fast");
    }

    if (tabs == "tables") {
        fadeOut();
        $("#tabelbox").fadeIn("fast");
    }
    if (tabs == "rooms") {
        fadeOut();
        $("#roombox").fadeIn("fast");
    }
    if (tabs == "steaward") {
        fadeOut();
        $("#steawardbox").fadeIn("fast");

    }
    if (tabs == "menutype") {
        fadeOut();
        $("#menutypebox").fadeIn("fast");
    }

    if (tabs == "categoryo") {
        fadeOut();
        $("#categoryboxo").fadeIn("fast");
    }

    if (tabs == "subcategory") {
        fadeOut();
        $("#subCategorybox").fadeIn("fast");
    }
    if (tabs == "posItem") {
        fadeOut();
        $("#posItemBox").fadeIn("fast");
    }

    if (tabs == "openitem") {
        fadeOut();
        $("#openitembox").fadeIn("fast");
    }
    if (tabs == "tabletransfertablelink") {
        fadeOut();
        $("#tbletrnsfrtblelnk").fadeIn("fast");
    }
    if (tabs == "voidkot") {
        fadeOut();
        $("#voidkotbox").fadeIn("fast");
    }
    if (tabs == "repeatorder") {
        fadeOut();
        $("#repeatorderbox").fadeIn("fast");
    }
    if (tabs == "nckot") {
        fadeOut();
        $("#nckotbox").fadeIn("fast");
    }
    if (tabs == "billing") {
        fadeOut();
        $("#billingbox").fadeIn("fast");
    }
    
    if (tabs == "billreprint") {
        fadeOut();
        $("#billreprintbox").fadeIn("fast");
    }
    if (tabs == "modifier") {
        fadeOut();
        $("#modifierbox").fadeIn("fast");
    }
    if (tabs == "happyhours") {
        fadeOut();
        $("#happyhoursbox").fadeIn("fast");
    }
    if (tabs == "multirestaurent") {
        fadeOut();
        $("#multirestaurentbox").fadeIn("fast");
    }
    if (tabs == "transferlocation") {
        fadeOut();
        $("#transferlocationbox").fadeIn("fast");
    }
    if (tabs == "function") {
        fadeOut();
        $("#functionbox").fadeIn("fast");
    }
    //if (tabs == "borrowMenu") {
    //    fadeOut();
    //    $('#functionbox').fadeOut('fast');
    //}

    if (tabs == "voidbill") {
        fadeOut();
        $("#voidbillbox").fadeIn("fast");
    }

    if (tabs == "borrowMenu") {
        fadeOut();
        $("#borrowMenu").fadeIn("fast");
    }
    if (tabs == "delivery") {
        fadeOut();
        $("#deliverystatusbox").fadeIn("fast");
    }
    if (tabs == "customerkot") {
        fadeOut();
        $("#deliverycustomerkot").fadeIn("fast");
    }
    if (tabs == "settlement") {
        fadeOut();
        $("#Settlemntbox").fadeIn("fast");
    }
}

$("#closeKOTStatus").click(function () {
    $("#KOTStatusbox").fadeOut("fast");
});

$("#closecheckstatus").click(function () {
    $("#checkstatusbox").fadeOut("fast");
});

$("#closeshiftransfer").click(function () {
    $("#shifttransferbox").fadeOut("fast");
});

$("#closeflashview").click(function () {
    $("#flashviewbox").fadeOut("fast");
});

$('#closesettlement').click(function () {
    $('#settlementbox').fadeOut('fast');
});

function oninputFocus(datatable) {
    
    if (datatable == "sourcetable") {
        $("#sourcetablebox").slideDown("slow");
    }
    if (datatable == "tablelink") {
        $("#tableboollinkbox").slideDown();
    }
    if (datatable == "destinationtable") {
        $("#destinationtablebox").slideDown();
    }
    if (datatable == "sourcetable1") {
        $("#sourcetable1box").slideDown();



    }
    if (datatable == "location") {
        $("#TransferLocation").slideDown("slow");
    }
}

function functionBtn(funcbtns) {
    if (funcbtns == "kotstatus") {
        $("#kotstatusbox").fadeIn("fast");
    }
    if (funcbtns == "checkstatus") {
        $("#checkstatusbox").fadeIn("fast");
    }
    if (funcbtns == "shifttransfer") {
        $("#shifttransferbox").fadeIn("fast");
    }
    if (funcbtns == "flashview") {
        $("#flashviewbox").fadeIn("fast");
    }
    if (funcbtns == "settlement") {
        $("#settlementbox").fadeIn("fast");
    }
}

function qtydynamicPop(qty) {
    if (qty == "1") {
        $("#qtybox").slideToggle("slow");
    }
}

/*End Table Booking Head Navas Show & Hide Divs code starts from here*/