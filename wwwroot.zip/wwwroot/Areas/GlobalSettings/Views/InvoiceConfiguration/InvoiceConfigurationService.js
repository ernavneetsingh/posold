﻿

app.service("InvConfigService", function ($http, $q) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getinvData = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/InvoiceConfiguration/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "GlobalSetting/InvoiceConfiguration/" + propertyId,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.getinitialCode = function (codefor, propertyId) {
        return httpCaller(apiPath + "GlobalSetting/InvoiceInitial/getinitialcode/" + propertyId + "/" + codefor + "?active=1", $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "GlobalSetting/InvoiceInitial/getinitialcode/" + propertyId + "/" + codefor + "?active=1",
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});
    };

    this.getCodeForData = function () {
        return httpCaller(apiPath + "referencedata/InvoiceCode", $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "referencedata/InvoiceCode",
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});
    }

    this.saveinvconfigData = function (invconfigData) {
        return httpPoster(apiPath + "GlobalSetting/invoiceconfiguration/create/modify", $http, $q, invconfigData);
        
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/invoiceconfiguration/create/modify",
        //    data: JSON.stringify(invconfigData),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.statusChange = function (myform) {
        return httpPoster(apiPath + "GlobalSetting/InvoiceConfiguration/status", $http, $q, myform);

        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/InvoiceConfiguration/status",
        //    data: myform,
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});

    };

    this.removeinitialCodeData = function (invoiceconfigData) {
        return httpPoster(apiPath + "GlobalSetting/InvoiceConfiguration/remove/" + invoiceconfigData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "GlobalSetting/invoiceconfiguration/remove/" + invoiceconfigData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };


});
