﻿
app.controller("PropertyChannelManagerController", [
    "$scope", "PropertyChannelManagerService", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, propertyChannelManagerService, $cookies, $filter, localStorageService, $timeout) {

        $scope.getChannelManager = function () {
            var promise = propertyChannelManagerService.getChannelManager($scope.PropertyID);
            promise.then(function (s) {
                if (s.Data) {
                    $scope.model = s.Data;
                    $scope.model.ChannelManagerId = s.Data.ChannelManagerId ? s.Data.ChannelManagerId.toString() : "";
                }
            });
        };
        $scope.getChannelManagerList = function () {
            var promise = propertyChannelManagerService.getChannelManagerList();
            promise.then(function (s) {
                $scope.ChannelManagerList = s.Collection;
                $scope.Reset();
            });
        };

        $scope.Reset = function () {
            $scope.model = { IsActive: true };
            $scope.IsReadonly = false;
            $scope.getChannelManager();
        };
        $scope.Save = function (form) {
            
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            $scope.IsSaving = true;
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;

            var promise = propertyChannelManagerService.save($scope.model);
            promise.then(function (s) {

                if (s.Status == true) {
                    msg(s.Message, true);
                }
                $scope.Reset();
            }, function (e) {
                msg(e.Message);
            }).finally(function () {
                $scope.IsSaving = false;
            });

        };

        $scope.getChannelManagerList();

    }
]);
