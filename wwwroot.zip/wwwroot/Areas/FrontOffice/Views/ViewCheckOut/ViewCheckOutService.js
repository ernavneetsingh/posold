﻿
app.service('ViewCheckOutService', [
    '$http', '$q', function ($http, $q) {

        this.getRoomList = function (propertyId) {
            return httpCaller(apiPath + 'FrontOffice/RoomMaster/GetActive/' + propertyId + '/1', $http, $q);
        };
        this.getBillList = function (propertyId) {
            
            return httpCaller(apiPath + 'FrontOffice/FOBill/GetAllMin', $http, $q, { propertyId: propertyId });
        };
        this.search = function (model) {
            
            return httpPoster(apiPath + "FrontOffice/FOBill/Search", $http, $q, model);
        };
        this.MapReport = function (filterValue, reportName) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
        };

    }
]);
