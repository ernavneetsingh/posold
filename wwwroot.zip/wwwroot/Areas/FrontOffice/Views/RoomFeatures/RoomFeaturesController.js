﻿
app.controller("RoomFeatureController",
[
    "$scope", "RoomFeatureService", "$cookies", "localStorageService", function ($scope, roomFeatureService, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.IsReadonly = false;
        $scope.bsId = "";
        $scope.Name = "";
        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;
        $scope.IsBanquet = false;
        $scope.roomFeatureModel = {};
        $scope.Save = "Save";
        $scope.featureData = [];
        $scope.featureDetails = [];

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        getData($scope, roomFeatureService, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, roomFeatureService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, roomFeatureService, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, roomFeatureService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, roomFeatureService, localStorageService);
        }

        $scope.isExist = function () {

            var promiseGet = roomFeatureService.getCodeExistRoomFeature($scope.featureCode, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        //alert("Room Feature Code Already Exist");
                        msg(data.Message);
                        $scope.featureCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.featureId = "";
            $scope.featureName = "";
            $scope.featureCode = "";
            $scope.featureDescription = "";
            $scope.IsActive = true;
            $scope.IsBanquet = false;
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            $scope.search();
        };

        $scope.savefeatureData = function (form) {

            if ($scope[form].$valid) {

                var bsObj = new Object();
                bsObj.Id = $scope.featureId;
                bsObj.Name = $scope.featureName;
                bsObj.Code = $scope.featureCode;
                bsObj.Description = $scope.featureDescription;
                bsObj.IsActive = $scope.IsActive;
                bsObj.IsBanquet = $scope.IsBanquet;
                bsObj.PropertyId = $scope.PropertyID;
                bsObj.ModifiedBy = $scope.UserName;
                var promiseGet = roomFeatureService.saveRoomFeature(bsObj);
                promiseGet.then(function (data, status) {
                    getData($scope, roomFeatureService, localStorageService);
                    $scope.reset();
                    msg(data.Message, data.Status);
                }, function (error, status) {
                    msg(error.Message);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.updatefeatureData = function (roomFeatureModel) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var promiseGet = roomFeatureService.updateIsActiveRoomFeature(roomFeatureModel.Id, roomFeatureModel.IsActive, $scope.PropertyID, $scope.UserName);
            promiseGet.then(function (data, status) {
                getData($scope, roomFeatureService, localStorageService);
                msg(data.Message, data.Status);
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.removeRow = function (roomFeatureModel) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Room Feature?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = roomFeatureService.deleteRoomFeature(roomFeatureModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {
                                getData($scope, roomFeatureService, localStorageService);
                                msg(d.Message, d.Status);
                            }, function (error) {
                                msg(error.Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.featureId = record.Id;
            $scope.featureName = record.Name;
            $scope.featureDescription = record.Description;
            $scope.featureCode = record.Code;
            $scope.IsActive = record.IsActive;
            $scope.IsBanquet = record.IsBanquet;
            $scope.IsReadonly = true;
            $scope.Save = "Update";
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getRoomFeature(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
