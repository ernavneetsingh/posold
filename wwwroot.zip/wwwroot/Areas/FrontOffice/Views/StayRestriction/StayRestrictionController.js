﻿
app.controller("controller",
[
    "$scope", "PackageService", "localStorageService", "$cookies", "$filter", function ($scope, packageService, localStorageService, $cookies, $filter) {
        $scope.UserName = $cookies.get("UserName");
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        $scope.Model = {
            Code: '',
            Name: '',
            Description: '',
            IsActive: '',
            FromDate: '',
            ToDate: '',
            MinLOS: 0,
            MaxLOS: 0,
            IsCTAMON: false,
            IsCTATUE: false,
            IsCTAWED: false,
            IsCTATHU: false,
            IsCTAFRI: false,
            IsCTASAT: false,
            IsCTASUN: false,
            IsCTDMON: false,
            IsCTDTUE: false,
            IsCTDWED: false,
            IsCTDTHU: false,
            IsCTDFRI: false,
            IsCTDSAT: false,
            IsCTDSUN: false,
            BookingWindowOpenBefore: 0,
            BookingWindowOpenDate: '',
            MaxStayThru: 0,
            MinStayThru: 0,
            StayRestrictionClosedDates:[],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
        }

        $scope.IsReadonly = false;
        $scope.biId = "";
        $scope.Name = "";
        $scope.Color = "";

        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;

        GetTaxStructure();
        $scope.TaxStructures = [];
        $scope.packageData = [];
        $scope.StayRestrictionClosedDates = [];

        $scope.StayRestrictionClosedDates.push({

            Id: '',
            PackageId: '',
            RevenueHeadId: '',
            RevenueHeadCode: '',
            RevenueHeadName: '',
            RevenueINId: '2',
            RevenueINName: 'Percentage',
            RevenueValue: 0,
            Amount: 0,
            TaxStructureId: '',
            TaxStructureName: '',
            TaxAmount: 0,
            BalanceAmount: 0,
            IsTaxInclusive: 'true',
        });

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, packageService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, packageService, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, packageService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, packageService, localStorageService);
        }

        getData($scope, packageService, localStorageService);

        getRevenueDetails();
        getRoomTypeDetails();
        getMealPlanDetails();


        function getRevenueDetails() {
            var promiseGet = packageService.getRevenueHead($scope.PropertyID);
            promiseGet.then(function (data, status) {
                $scope.revenueHeadDetails = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        function getRoomTypeDetails() {
            var promiseGet = packageService.getRoomTypeData($scope.PropertyID);
            promiseGet.then(function (data, status) {
                
                $scope.RoomTypeDetails = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        function getMealPlanDetails() {
            var promiseGet = packageService.getMealPlanData();
            promiseGet.then(function (data, status) {
                $scope.MealPlanDetails = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        function GetTaxStructure() {
            var promiseGet = packageService.getTaxStructure($scope.PropertyID);
            promiseGet.then(function (data, status) {
                $scope.TaxStructures = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        

        //###################################################
        //Tax Calculation By TaxStructureId
        //###################################################
        $scope.ItemTaxStructures = [];
        $scope.SetTaxAmount = function (taxStructureId, amount, discountAmount) {

            var totalTaxAmount = 0.0;

            $scope.ItemTaxStructures = [];
            $scope.LinkTaxStructures = [];
            angular.forEach($scope.TaxStructures, function (tax) {
                if (tax.Id == taxStructureId) {
                    $scope.LinkTaxStructures = tax.LinkTaxStructures;
                }
            });

            angular.forEach($scope.LinkTaxStructures, function (linkTaxStructure, index) {
                taxAmount = $scope.GetTaxAmount($scope.ItemTaxStructures, linkTaxStructure, amount, discountAmount);

                if (isNaN(taxAmount)) {
                    taxAmount = 0;
                }

                taxAmount = $filter("number")(taxAmount, 2).replace(/,/g, "");

                $scope.ItemTaxStructures.push({
                    TaxTypeId: linkTaxStructure.TaxTypeId,
                    TaxOnId: linkTaxStructure.TaxOnId,
                    TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
                    IsTariffOn: linkTaxStructure.IsTariffOn,
                    TaxInId: linkTaxStructure.TaxInId,
                    TaxInName: linkTaxStructure.Name,
                    TaxValue: linkTaxStructure.TaxValue,
                    TaxAmount: taxAmount,
                });

                totalTaxAmount = parseFloat(totalTaxAmount) + parseFloat(taxAmount);
            })

            totalTaxAmount = $filter("number")(totalTaxAmount, 2).replace(/,/g, "");

            return totalTaxAmount
        };
        $scope.GetTaxAmount = function (taxList, tax, itemAmount, discoutAmount) {

            var calculatetax = 0.0;

            var itemTax = tax.TaxValue.toString();
            itemTax = replaceAll(itemTax, ',', '');

            if (tax.TaxOnId === 1 || tax.TaxOnId === 3) {

                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(itemAmount) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            } else if (tax.TaxOnId === 2) {

                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(discoutAmount) * parseFloat(itemTax) / 100;

                } else {
                    calculatetax = parseFloat(itemTax);
                }

            } else {
                //TaxOnTax
                var taxOnTaxTypeId = tax.TaxOnTaxTypeId;
                angular.forEach(taxList, function (item) {
                    if (taxOnTaxTypeId === item.TaxTypeId) {
                        if (tax.TaxInId === 2) {//Percent
                            calculatetax = parseFloat(item.TaxAmount) * parseFloat(itemTax) / 100;
                        } else {
                            //calculatetax = parseFloat(itemTax);
                        }
                    }
                });

            }
            return parseFloat(calculatetax);
        };
        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        }
        //###################################################

        $scope.isExist = function () {

            var promiseGet = packageService.getCodeExistPackage($scope.biCode, $scope.PropertyID);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        //alert("Package Code Already Exist");
                        msg(data.Message);
                        $scope.biCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {

            $scope.Model = {};
            $scope.Model.IsActive = true;
            $scope.Model.PackageAmount = '';
            $scope.Model.MaxPax = '';
            $scope.StayRestrictionClosedDates = [];

            $scope.IsReadonly = false;

            scrollPageOnTop();
            $scope.search();

        };
        

        $scope.addItem = function (d) {

            var validateFlag = false;

            //if ($scope.StayRestrictionClosedDates.length > 0) {
            //    if ($scope.StayRestrictionClosedDates[$scope.StayRestrictionClosedDates.length - 1].RevenueHeadId == undefined ||
            //        $scope.StayRestrictionClosedDates[$scope.StayRestrictionClosedDates.length - 1].RevenueHeadId === "") {
            //        validateFlag = true;
            //        msg("Please Select Revenue Head.");
            //        return;
            //    }
            //    if ($scope.StayRestrictionClosedDates[$scope.StayRestrictionClosedDates.length - 1].RevenueINId == undefined ||
            //        $scope.StayRestrictionClosedDates[$scope.StayRestrictionClosedDates.length - 1].RevenueINId === "") {
            //        validateFlag = true;
            //        msg("Please Select Revenue IN.");
            //        return;
            //    }
            //    if ($scope.StayRestrictionClosedDates[$scope.StayRestrictionClosedDates.length - 1].RevenueValue == undefined ||
            //        $scope.StayRestrictionClosedDates[$scope.StayRestrictionClosedDates.length - 1].RevenueValue === "") {
            //        validateFlag = true;
            //        msg("Please Enter Revenue Value.");
            //        return;
            //    }
            //}

            var flag = false;

            if (validateFlag === false) {

                $scope.StayRestrictionClosedDates.push({

                    Id: '',
                    FromDate: '',
                    ToDate: '',
                });

                $scope.ShowErrorMessagegrid = validateFlag;
            }
        };
        $scope.removeItem = function (index) {
            if ($scope.PackageDetails.length > 1) {
                $scope.PackageDetails.splice(index, 1);
            }
        };
        $scope.Save = function (form) {

            scrollPageOnTop();

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }

            if (!$scope.PackageDetails || $scope.PackageDetails.length < 1 || (!$scope.PackageDetails[0].RevenueValue > 0) || (!$scope.PackageDetails[0].RevenueHeadId)) {
                msg("There is no Record for package distribution.");
                return;
            }

            if (isNaN(parseFloat($scope.PackageDetails[$scope.PackageDetails.length - 1].BalanceAmount)) || parseFloat($scope.PackageDetails[$scope.PackageDetails.length - 1].BalanceAmount) > 0) {
                msg("Please settle balance amount.");
                return;
            }

            $scope.Model.ApplicableFrom = GetServerDate($scope.Model.ApplicableFrom, $scope.DateFormat);
            $scope.Model.ApplicableTo = GetServerDate($scope.Model.ApplicableTo, $scope.DateFormat);

            $scope.Model.PackageDetails = $scope.PackageDetails;
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            $scope.Model.DateFormat = $scope.DateFormat;

            var promiseGet = packageService.savePackage($scope.Model);
            promiseGet.then(function (data, status) {
                getData($scope, packageService, localStorageService);
                $scope.reset();
                msg(data.Message, data.Status);
            }, function (error, status) {

                $scope.Model.ApplicableFrom = GetLocalDate($scope.Model.ApplicableFrom, $scope.DateFormat);
                $scope.Model.ApplicableTo = GetLocalDate($scope.Model.ApplicableTo, $scope.DateFormat);

                msg(error.Message);
            });
        };
        $scope.ChangeStatus = function (model) {
            model.propertyId = $scope.PropertyID;
            model.ModifiedBy = $scope.UserName;
            var promiseGet = packageService.changeStatus(model);//.Id, packageModel.IsActive, $scope.PropertyID, $scope.UserName);
            promiseGet.then(function (data, status) {
                getData($scope, packageService, localStorageService);
                msg(data.Message, data.Status);
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.removeRow = function (packageModel) {
            var strDelete = DeletePopup("Are you sure you want to delete this Package?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = packageService.deletePackage(packageModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {

                                getData($scope, packageService, localStorageService);
                                msg("Package deleted successfully.", d.Status);
                            }, function (error) {

                                msg(error.Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
            scrollPageOnTop();
        };
        $scope.fillData = function (record) {

            $scope.Model = record;

            $scope.Model.ApplicableFrom = $filter("date")(record.ApplicableFrom, $scope.DateFormat);
            $scope.Model.ApplicableTo = $filter("date")(record.ApplicableTo, $scope.DateFormat);
            $scope.Model.MealPlanId = record.MealPlanId.toString();

            getPackageDetails(record.Id);

            scrollPageOnTop();
        };

        function getPackageDetails(packageId) {

            var promiseGet = packageService.getPackageData(packageId, $scope.PropertyID);
            promiseGet.then(function (data, status) {
                $scope.PackageDetails = data.Data.PackageDetails;// data.Collection[0].PackageDetails;

                angular.forEach($scope.PackageDetails, function (val) {

                    val.RevenueINId = val.RevenueINId.toString();
                    val.IsTaxInclusive = val.IsTaxInclusive.toString();

                });

            },
            function (error, status) {
                msg(error.Message);
            });
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataAllData;
    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getPackage(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
