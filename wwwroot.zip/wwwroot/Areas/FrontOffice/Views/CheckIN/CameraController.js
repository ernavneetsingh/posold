﻿(function () {
    'use strict';
    angular.module('webcam').controller('webcamController', webcamController);
    webcamController.$inject = ['$scope', '$log', '$location', '$q', '$http'];
    function webcamController($scope, $log, $location, $q, $http) {

        
        //var key = 'propertyId';
        //var value = window.location.search.substring(window.location.search.indexOf(key) + key.length + 1);

        var url = window.location.href;
        $scope.PropertyID = getParameterByName('propertyId', url);
        $scope.xId = getParameterByName('xId', url);
        $scope.SNo = getParameterByName('SNo', url);
        $scope.Operation = getParameterByName('operation', url);

        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }
        
        /* jshint validthis: true */
        var vm = this;
        vm.config = {
            delay: 2,
            shots: 3,
            countdown: 3,
            flashFallbackUrl: 'Assets/webcamjs/webcam.swf',
            shutterUrl: '../../shutter.mp3',
            flashNotDetectedText: 'Seu browser não atende os requisitos mínimos para utilização da camera. ' +
            'Instale o ADOBE Flash player ou utilize os browsers (Google Chrome, Firefox ou Edge)'
        };

        vm.showButtons = false;
        vm.captureButtonEnable = false;
        vm.progress = 0;

        $scope.Images = [];
        $scope.Image = {
            src: '',
            width: '',
            height: ''
        };

        vm.onCaptureComplete = function (src) {
            
            $log.log('webcamController.onCaptureComplete : ', src);
            vm.progress = 100;
            var el = document.getElementById('result');
            var img = document.createElement('img');
            img.src = src[vm.config.shots - 1];
            img.width = 200;
            img.height = 180;
            el.appendChild(img);

            $scope.Image = {
                src: src[vm.config.shots - 1],
                width: 200,
                height: 180
            };
            $scope.Images.push($scope.Image);

        };
        vm.onError = function (err) {
            $log.error('webcamController.onError : ', err);
            vm.showButtons = false;
        };
        vm.onLoad = function () {
            $log.info('webcamController.onLoad');
            vm.showButtons = true;
        };
        vm.onLive = function () {
            $log.info('webcamController.onLive');
            vm.captureButtonEnable = true;
        };
        vm.onCaptureProgress = function (src, progress) {
            
            vm.progress = progress;
            var result = {
                src: src,
                progress: progress
            }
            var el = document.getElementById('result');
            var img = document.createElement('img');
            img.src = src;
            img.width = 200;
            img.height = 180;
            el.appendChild(img);
            $log.info('webcamController.onCaptureProgress : ', result);

            $scope.Image = {
                src: src,
                width: 200,
                height: 180
            };
            $scope.Images.push($scope.Image);

        };
        vm.capture = function () {

            $scope.$broadcast('ngWebcam_capture');
        };
        vm.on = function () {
            $scope.$broadcast('ngWebcam_on');
        };
        vm.off = function () {
            $scope.$broadcast('ngWebcam_off');
            vm.captureButtonEnable = false;
        };



        $scope.Save = function (img)
        {
            
            var ImageModel = {
                Base64: img.src,
                EntityName: 'Guest',
                PropertyID: $scope.PropertyID,
                xId: $scope.xId,
                SNo: $scope.SNo,
            };
            
            var path = uploadBase64(ImageModel);

        }

        var uploadBase64 = function (model) {
            
            var url = apiPath + 'Upload/FileBase64/';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                //headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                    window.close();
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

    }
})();