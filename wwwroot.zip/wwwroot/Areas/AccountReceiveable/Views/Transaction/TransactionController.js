﻿
app.controller('TransactionController', function ($scope, $filter, $window, $cookies, transactionService, invoiceVoucherService, periodCloseService, corporateOutstandingService, localStorageService, CreditCardService) {

    //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    //$scope.ModifiedBy = $cookies.get('UserName');
    //$scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
    $scope.MaxInvoiceDate = $scope.MinDatess = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
    $scope.chequeMinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() - 2)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
    $('.readonly').find('input, textarea, select').attr('readonly', 'readonly');
    CreditCardService.init($scope);

    $scope.resetSearch = function () {
        $scope.Search = {};
    }
    $scope.resetHistory = function () {
        $scope.History = [];
    }
    $scope.resetCompany = function () {
        $scope.Company = {};
    }
    $scope.resetTransaction = function () {
        $scope.Transaction = {
            TransactionDateString: $scope.ModifiedDate,
            TransactionTypeId: 'Credit',
            RevenueHeadId: '',
            CommissionTypeId: $scope.Company && $scope.Company.CorporateOutstanding && $scope.Company.CorporateOutstanding.CommissionType ? $scope.Company.CorporateOutstanding.CommissionType.toString() : '',
            CommissionApplied: $scope.Company && $scope.Company.CorporateOutstanding ? $scope.Company.CorporateOutstanding.CommissionAmount : 0
        };
        $scope.PaymentMode = {};
        $scope.Invoice = {};
        $scope.PendingBills = [];
        $scope.Bank = {};
        $scope.IsReadonly = false;
    }
    $scope.resetGrid = function () {
        $scope.MsgNotFound = '';
        $scope.sortingOrder = 'Name';
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
    }
    $scope.resetCheque = function () {
        $scope.Transaction.ChequeNo = '';
        $scope.Transaction.ChequeDateString = '';
        $scope.Transaction.ChequeDays = '';
        $scope.Bank = {};
    }
    $scope.resetAll = function () {
        $scope.resetSearch();
        $scope.resetHistory();
        $scope.resetCompany();
        $scope.resetTransaction();
        $scope.resetGrid();
        $scope.resetCheque();
    }
    $scope.resetAll();

    function getDefaults() {
        var promiseGet = transactionService.GetDefaults($scope.PropertyID);
        promiseGet.then(function (data, status) {
            if (data.Status) {
                $scope.defaultData = data.Data;
            }
        },
            function (error, status) {
                msg(error.Message);
            });
    };
    $scope.getPaymentModes = function () {

        var promise = transactionService.getPaymentModes($scope.PropertyID, 4);
        promise.then(function (data, status) {

            if (data.Collection && data.Collection.length > 0)
                $scope.PaymentModes = data.Collection[0].SettlementModeDetails;
        });
    };

    periodCloseService.getStartPeriod($scope);
    getDefaults();
    $scope.getPaymentModes();

    $scope.getOpeningDate = function () {

        var promise = corporateOutstandingService.getOpeningDate($scope.PropertyID, $scope.Company.Id);
        promise.then(function (data, status) {

            var d = new Date(data.Data);
            d.setDate(d.getDate() - 1);
            $scope.MinInvoiceDate = $filter('date')(d, 'yyyy-MM-dd');

            //$scope.MinInvoiceDate = $filter('date')(data.Data, 'yyyy-MM-dd');
        });
    };

    $scope.getAutoSuggest = function (item, txt) {
        var promiseSuggest = transactionService.suggest($scope.PropertyID, item, txt);
        promiseSuggest.then(function (data, status) {

            $('#txtSearch' + item).autocomplete({
                source: function (request, response) {
                    response($.map(data.Data.Suggestions, function (ret) {
                        if (!ret) return;
                        return {
                            label: ret,
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {

                    if (ui.item) {
                        var promiseSearch = transactionService.search($scope.PropertyID, item, ui.item.val);
                        promiseSearch.then(function (data, status) {
                            $scope.load(data, item);
                        });
                    }
                },
                minLength: 1,
                messages: {
                    noResults: '',
                    results: function () { }
                }
            });
        });
    };
    $scope.getRecent = function () {
        var promise = transactionService.search($scope.PropertyID, 'CorporateId', $scope.Company.Id);
        promise.then(function (data, status) {

            $scope.load(data, 'any');
        });
    };
    $scope.load = function (data, searchType) {
        
        if (searchType && searchType !== 'CompanyType') {
            $scope.Company = data.Data;
            $scope.resetTransaction();
            $scope.getOpeningDate();
            $scope.items = data.Data.Transactions;
            $scope.search();
        }
        $scope.History = data.Data.History;
    };

    $scope.closeBox = function () {
        $('#openModalTrans').hide();
    };
    $scope.transactionTypeChange = function (item) {

        var isCredit = item === 'Credit';
        var btn = document.getElementById('btnShow');
        btn.style.display = isCredit ? 'block' : 'none';
        var divPmode = document.getElementById('divPmode');
        divPmode.style.display = isCredit ? 'block' : 'none';
        var lblInvoice = document.getElementById('lblInvoice');
        lblInvoice.innerText = (isCredit ? 'Invoice' : 'Bill') + ' Number';
        var lblInvoiceDate = document.getElementById('lblInvoiceDate');
        lblInvoiceDate.innerText = (isCredit ? 'Invoice ' : 'Bill') + ' Date';
        //var divCommission = document.getElementById('divCommission');
        //divCommission.style.display = isCredit ? 'block' : 'none';
    }
    $scope.save = function (model, form) {
        $scope.IsBankAccountName = false;
        if ($scope.Company === undefined || $scope.Company.Id === undefined || $scope.Company.Id === null) {
            msg('Please select company');
            return;
        }

        if (!$scope[form].$valid) {
            $scope.ShowErrorMessage = true;
            return;
        }
        if ($scope.Transaction.Amount === undefined || $scope.Transaction.Amount <= 0) {
            msg('Error! Please enter some amount.');
            return;
        }
        if ($scope.Transaction.TransactionTypeId === undefined || ($scope.Transaction.TransactionTypeId === 'Credit' && ($scope.Transaction.RevenueHeadId === undefined || $scope.Transaction.RevenueHeadId < 1))) {
            msg('Error! Please select payment mode.');
            return;
        }
        
        if ($scope.PaymentMode && $scope.PaymentMode.RevenueHeadCode === 'CRD') {
            if (!model.CreditCardNetworkId || model.CreditCardNetworkId.length < 1) {
                msg('Error! Please enter valid credit card type.');
                return;
            }
        }
        else if ($scope.PaymentMode && $scope.PaymentMode.RevenueHeadCode === 'CHQ') {
            if (!model.BankAccountName || model.BankAccountName.length < 1) {
                $scope.IsBankAccountName = true;
                $('#openModalCheque').show('slow');
                msg('Error! Please Select A/c Number.');
                return;
            }
        }

        model.CorporateId = $scope.Company.Id;
        model.PropertyID = $scope.PropertyID;
        model.ModifiedBy = $scope.ModifiedBy;
        model.ModifiedDate = $scope.ModifiedDate;
        if ($scope.Transaction.UnmatchedAmount == undefined) $scope.Transaction.UnmatchedAmount = $scope.Transaction.Amount;

        var billno = [];
        var billAmt = [];
        angular.forEach($scope.PendingBills, function (key) {
            if (key.IsSelectedInInvoice && key.Settled > 0) {
                billno.push(key.Id);
                billAmt.push(key.Settled);
            }
        });
        billno = JSON.stringify(billno);
        billAmt = JSON.stringify(billAmt);
        var saveData = transactionService.save(model, billno, billAmt);
        saveData.then(function (data) {

            if (data.Status) {
                parent.successMessage(data.Message);
                $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                $scope.resetTransaction();
                $scope.getRecent();
            }
        });
    };
    $scope.delete = function (record) {

        var ret = false;
        $scope.Transaction = {};
        if (record.TransactionDateString < $scope.MinDate) {
            msg('This transaction cannot be deleted because period is closed.');
            return;
        }
        if (record.IsAuto) {
            msg('This transaction cannot be deleted because it is auto entry.');
            return;
        }
        var strDelete = DeletePopup('Do you want to delete this Transaction?');
        $.fancybox({
            'modal': true,
            'content': strDelete,
            'afterShow': function () {
                $('#fancyconfirm_cancel')
                    .click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                $('#fancyConfirm_ok')
                    .click(function () {
                        ret = true;
                        var promise = transactionService.delete(record.Id, $scope.ModifiedBy, $scope.PropertyID, $scope.ModifiedDate);
                        promise.then(function (data) {

                            parent.successMessage('Transaction deleted successfully, All matched bill would be untagged ....');
                            $scope.getRecent();
                        });
                        $.fancybox.close();
                    });
            }
        });
        return ret;
    }

    var searchMatch = function (haystack, needle) {
        if (!needle) {
            return true;
        }
        return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
    };
    $scope.search = function () {

        $scope.filteredItems = $filter('filter')($scope.items, function (item) {
            for (var attr in item) {
                if (attr === 'TransactionNo' || attr === 'TransactionType') {
                    if (searchMatch(item[attr], $scope.query))
                        return true;
                }
            }
            return false;
        });
        if ($scope.sortingOrder !== '') {
            $scope.filteredItems = $filter('orderBy')($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
        }
        $scope.currentPage = 0;
        $scope.groupToPages();
    };
    $scope.perPage = function () {
        $scope.groupToPages();
    };
    $scope.groupToPages = function () {
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        if ($scope.itemsPerPage === 'All') {
            $scope.itemsPerPage = $scope.filteredItems.length;
        }
        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage === 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }
        if ($scope.pagedItems.length === 0) {
            $scope.MsgNotFound = 'Record Not Found.';
            $scope.pagedItems.length = 1;

        } else {
            $scope.MsgNotFound = '';
        }
    };
    $scope.range = function (start, end) {
        var ret = [];
        if (!end) {
            end = start;
            start = 0;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }
        return ret;
    };
    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };
    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        }
    };
    $scope.firstPage = function () {
        $scope.currentPage = 0;
    };
    $scope.lastPage = function () {
        $scope.currentPage = $scope.pagedItems.length - 1;

    };
    $scope.setPage = function () {
        $scope.currentPage = this.n;
    };
    $scope.sort_by = function (newSortingOrder) {
        if ($scope.sortingOrder === newSortingOrder)
            $scope.reverse = !$scope.reverse;
        $scope.sortingOrder = newSortingOrder;
    };

    $scope.fillData = function (record) {

        $scope.Transaction = {};
        if (record.TransactionDateString < $scope.MinDate) {
            msg('This transaction cannot be edited because period is closed.');
            return;
        }
        if (record.IsAuto) {
            msg('This transaction cannot be edited because it is auto entry.');
            return;
        }

        msg('Linking of this transaction will be removed if you change this transaction.');
        $scope.Transaction = record;
        $scope.PaymentMode = $scope.PaymentModes.find(x => x.RevenueHeadId == $scope.Transaction.RevenueHeadId);
        $scope.IsReadonly = true;
        $scope.transactionTypeChange($scope.Transaction.TransactionTypeId);
        $scope.TransactionDateChange(true);
        $scope.Search.Bank = record.BankBranch ? record.BankBranch.BankName : '';
        $scope.Bank = record.BankBranch;
        $scope.Transaction.CommissionTypeId = record.CommissionTypeId ? record.CommissionTypeId.toString() : '';
        $scope.Transaction.NetAmount = decimalValD(parseFloat($scope.Transaction.Amount) - parseFloat($scope.Transaction.CommissionAmount));
        $scope.Transaction.CreditCardNetworkId = record.CreditCardNetworkId ? record.CreditCardNetworkId.toString() : '';

    };
    $scope.getPendingBills = function () {

        if (!$scope.Transaction || !$scope.Transaction.Amount || $scope.Transaction.Amount <= 0) {
            msg('Please enter amount to credit.');
            return;
        }
        $('#myModal5').modal('show');
        if ($scope.PendingBills.length > 0) return;
        var promise = transactionService.getPendingBills($scope.PropertyID, $scope.Company.Id, $scope.DateFormat, $scope.Invoice);
        promise.then(function (data, status) {

            $scope.PendingBills = data.Data.PendingBills;
            $scope.Transaction.UnmatchedAmount = $scope.Transaction.Amount;
            angular.forEach($scope.PendingBills, function (key) {

                key.NoEdit = key.IsSelectedInInvoice;
                if (key.IsSelectedInInvoice) key.Settled = $scope.Transaction.UnmatchedAmount < key.RemainingBalance ? $scope.Transaction.UnmatchedAmount < 0 ? 0 : $scope.Transaction.UnmatchedAmount : key.RemainingBalance;

                $scope.Transaction.UnmatchedAmount -= key.Settled;
                $scope.settleAmountChange(key);
            });
        });
    };
    $scope.checkAll = function (selected) {

        angular.forEach($scope.PendingBills, function (key) {
            if (!key.NoEdit) {
                key.IsSelectedInInvoice = selected;
                key.RemainingBalanceNow = key.RemainingBalance - key.Settled;
                $scope.settleBills(key);
            }
        });
    };

    $scope.settleBills = function (bill) {

        $scope.UnmatchedAmountCheck();
        var checked = bill.IsSelectedInInvoice;

        bill.Settled = checked ? $scope.Transaction.UnmatchedAmount : 0;
        $scope.settleAmountChange(bill);
        bill.CommissionTypeId = $scope.Transaction.CommissionTypeId;
        bill.CommissionApplied = $scope.Transaction.CommissionApplied;
        bill.CommissionAmount = decimalValD(parseFloat(bill.Settled) * bill.CommissionApplied * 0.01);
        bill.TdsTypeId = $scope.Transaction.TdsTypeId;
        bill.TdsValue= $scope.Transaction.TdsValue;
        bill.TdsAmount = decimalValD(parseFloat(bill.Settled) * bill.TdsValue * 0.01);
    };
    $scope.settleAmountChange = function (bill) {

        if (bill.Settled > bill.RemainingBalance) bill.Settled = bill.RemainingBalance;
        bill.RemainingBalanceNow = bill.RemainingBalance - (bill.Settled ? bill.Settled : 0);
        $scope.UnmatchedAmountCheck();

    };
    $scope.UnmatchedAmountCheck = function () {
        $scope.Transaction.UnmatchedAmount = $scope.Transaction.Amount;
        $scope.settleBillCount = 0;
        angular.forEach($scope.PendingBills, function (key) {

            if (key.IsSelectedInInvoice) {
                $scope.settleBillCount++;
                $scope.Transaction.UnmatchedAmount -= (key.Settled ? key.Settled : 0);
                if ($scope.Transaction.UnmatchedAmount < 0) {
                    key.Settled -= $scope.Transaction.UnmatchedAmount;
                    $scope.Transaction.UnmatchedAmount = 0;
                }
            }
        });
    };

    $scope.changePaymentMode = function (item) {

        $scope.Transaction.RevenueHeadId = item.RevenueHeadId;
        if (item.RevenueHeadCode.toLowerCase() === 'chq') {
            $('#openModalCheque').show('slow');
            $scope.txtChequeDateChange();
        } else if (item.RevenueHeadCode.toLowerCase() === 'crd') {
            $('#modalCc').show('slow');
        }
    };
    $scope.closeChequeModal = function (model) {
        $scope.IsBankAccountName = false;
        if ($scope.PaymentMode && $scope.PaymentMode.RevenueHeadCode === 'CHQ') {
            if (!model.BankAccountName || model.BankAccountName.length < 1) {
                $scope.IsBankAccountName = true;
                msg('Error! Please Select A/c Number.');
                return;
            }
        }
        
        $('#openModalCheque').hide('slow');
    }
    $('#openModalChequeClose').click($scope.closeChequeModal);
    $scope.closeCcModal = function () {

        $('#modalCc').hide('slow');
    }
    $('#modalCcClose').click($scope.closeCcModal);

    $scope.txtChequeDateChange = function () {
        var chequeDate = new Date($scope.Transaction.ChequeDateString);
        var curDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
        var timeDiff = chequeDate.getTime() - curDate.getTime();
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        $scope.Transaction.ChequeDays = diffDays + 90;
    };
    $scope.suggestBank = function (txt) {
        var promiseSuggest = transactionService.suggestBank(txt);
        promiseSuggest.then(function (data, status) {

            $('#txtSearchBank').autocomplete({
                source: function (request, response) {

                    response($.map(data.Collection, function (ret) {
                        return {
                            label: ret.split(':')[1],
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {
                    if (ui.item) {
                        var promiseSearch = transactionService.searchBank(ui.item.val);
                        promiseSearch.then(function (data, status) {

                            $scope.Bank = data.Data;
                            $scope.Transaction.BankBranchId = $scope.Bank.Id;
                        });
                    } else {
                        $scope.Transaction.BankBranchId = {};
                    }
                },
                minLength: 1
            });
        });
    };
    $scope.TransactionDateChange = function (empty) {

        $scope.MaxInvoiceDate = $filter('date')($scope.Transaction.TransactionDateString, 'yyyy-MM-dd');

        if ($scope.Invoice && $scope.Invoice.InvoiceDateString) {
            if (dateCompare($scope.Invoice.InvoiceDateString, $scope.Transaction.TransactionDateString) > 0) {
                msg('Invoice date cannot be greater than transaction date.');
                $scope.Transaction.TransactionDateString = '';
            }
            return;
        }
        if (!empty && $scope.Transaction.InvoiceDateString !== undefined && $scope.Transaction.InvoiceDateString.length > 1) $scope.Transaction.InvoiceDateString = '';
    };
    $scope.suggestInvoice = function (txt) {
        var promiseSuggest = invoiceVoucherService.suggest($scope.PropertyID, txt, $scope.Company.Id);
        promiseSuggest.then(function (data, status) {

            $('#txtInvoiceNo').autocomplete({
                source: function (request, response) {
                    $scope.Transaction.InvoiceDateString = '';
                    response($.map(data.Collection, function (ret) {
                        return {
                            label: ret.split(':')[1],
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {

                    $scope.PendingBills = [];
                    if (ui.item) {
                        var promiseSearch = invoiceVoucherService.getInvoice(ui.item.val, $scope.PropertyID, $scope.DateFormat, $scope.Company.Id);
                        promiseSearch.then(function (data, status) {

                            $scope.Invoice = data.Collection[0];
                            $scope.Transaction.InvoiceNo = $scope.Invoice.InvoiceNo;
                            $scope.Transaction.InvoiceDateString = $scope.Invoice.InvoiceDateString;
                            $scope.Transaction.Amount = $scope.Invoice.TotalAmount;
                            $scope.TransactionDateChange();
                        });
                    } else {
                        $scope.Invoice = {};
                        $scope.Transaction.InvoiceDateString = '';
                    }
                },
                change: function (e, ui) {

                    //$scope.Invoice = null;
                    //$scope.PendingBills = [];
                },
                minLength: 1
            });
        });
    };

    function updateMinTransactionDate(minDates) {

        if (!minDates[0] && (!minDates[1])) return;
        if (!minDates[0]) $scope.MinTransactionDate = minDates[1];
        else if (!minDates[1]) $scope.MinTransactionDate = minDates[0];
        else $scope.MinTransactionDate = dateCompare(minDates[0], minDates[1]) >= 0 ? minDates[0] : minDates[1];
    }
    $scope.$watchGroup(['MinDate', 'MinInvoiceDate'], updateMinTransactionDate);

    $scope.calculateCommission = function () {
        $scope.Transaction.CommissionAmount = decimalValD($scope.Transaction.CommissionTypeId == '1' ?
            $scope.Transaction.Amount * $scope.Transaction.CommissionApplied * 0.01
            : $scope.Transaction.CommissionTypeId == '2' ? $scope.Transaction.CommissionApplied : 0);
        $scope.Transaction.NetAmount = decimalValD(parseFloat($scope.Transaction.Amount) - parseFloat($scope.Transaction.CommissionAmount) - parseFloat(decimalValD($scope.Transaction.TdsAmount)));
        if ($scope.Transaction.CommissionAmount > $scope.Transaction.Amount)
            $scope.calculateCommissionPercent();
    };
    $scope.changeAmount = function () {
        $scope.PendingBills = [];
        $scope.calculateCommission();
    }
    $scope.getPercentageTypeList = function () {

        transactionService.getPercentageTypeList()
            .then(function (data) {
                $scope.PercentageTypeList = data.Collection;
            });
    };
    $scope.getPercentageTypeList();
    $scope.calculateCommissionPercent = function () {
        if ($scope.Transaction.CommissionAmount > $scope.Transaction.Amount) $scope.Transaction.CommissionAmount = $scope.Transaction.Amount;
        if ((parseFloat($scope.Transaction.CommissionAmount)+parseFloat($scope.Transaction.TdsAmount)) > $scope.Transaction.Amount) $scope.Transaction.TdsAmount = $scope.Transaction.Amount-parseFloat($scope.Transaction.CommissionAmount);

        $scope.Transaction.CommissionApplied = decimalValD($scope.Transaction.CommissionTypeId == '1' ?
            $scope.Transaction.CommissionAmount * 100 / $scope.Transaction.Amount
            : $scope.Transaction.CommissionTypeId == '2' ? $scope.Transaction.CommissionAmount : 0);
        $scope.Transaction.TdsValue = decimalValD($scope.Transaction.TdsTypeId == '1' ?
          $scope.Transaction.TdsAmount * 100 / $scope.Transaction.Amount
          : $scope.Transaction.TdsTypeId == '2' ? $scope.Transaction.TdsAmount : 0);
        
        $scope.Transaction.NetAmount = decimalValD(parseFloat($scope.Transaction.Amount) - parseFloat($scope.Transaction.CommissionAmount)- parseFloat(decimalVal($scope.Transaction.TdsAmount)));
    }
    $scope.calculateTds= function () {
        $scope.Transaction.TdsAmount = decimalValD($scope.Transaction.TdsTypeId == '1' ?
            $scope.Transaction.Amount * $scope.Transaction.TdsValue * 0.01
            : $scope.Transaction.TdsTypeId == '2' ? $scope.Transaction.TdsValue: 0);
        $scope.Transaction.NetAmount = decimalValD(parseFloat($scope.Transaction.Amount) - parseFloat($scope.Transaction.CommissionAmount) - parseFloat($scope.Transaction.TdsAmount));
        if ($scope.Transaction.TdsAmount > ($scope.Transaction.Amount-$scope.Transaction.CommissionAmount))
            $scope.calculateCommissionPercent();
    };
    
    $scope.BankAccounts = [];
    $scope.getBankAccounts = function () {
        
        transactionService.getBankAccounts($scope.PropertyID)
            .then(function (data) {
                $scope.BankAccounts = data.Collection;
            });
    };
    $scope.getBankAccounts();

});
