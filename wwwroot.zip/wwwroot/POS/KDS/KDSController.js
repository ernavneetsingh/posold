﻿apppos.controller("kdsController", [
    "$scope", "service", "$cookies", "$http", "$filter", "$timeout", "$window", "localStorageService", function (
        $scope, service, $cookies, $http, $filter, $timeout, $window, localStorageService) {


        $scope.ModuleId = 3;
        $scope.IsLoading = false;
        $scope.UserName = $cookies.get('UserName');

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        if (!$scope.UserName || !$scope.PropertyID) {
            window.location = "../../loginpos.html";
        }

        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        
        $scope.PropertyCity = localStorageService.get('PropertyCity');
        $scope.PropertyStateId = localStorageService.get('PropertyStateId');
        $scope.PropertyCountryId = localStorageService.get('PropertyCountryId');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.businessDate = $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' + $scope.BusinessDate.Day;

        $scope.timeFormat = "HH:mm:ss";
        $scope.format = "dd/MMM/yyyy h:mm:ss a";

        $scope.Clock = "loading clock..."; // initialise the time variable
        $scope.tickInterval = 1000 //ms
        var tick = function () {
            $scope.Clock = $filter("date")(new Date, $scope.timeFormat);
            $timeout(tick, $scope.tickInterval); // reset the timer
            GetLapse();
        }
        // Start the timer
        $timeout(tick, $scope.tickInterval);
        
        function GetLapse() {
            var tempTime = moment($scope.Clock, $scope.timeFormat)
            var currentTime = moment(tempTime).diff(moment().startOf('day'), 'seconds');
            angular.forEach($scope.KOTs, function (item) {
                var eventTime = (item.KOTDuration * 60); // Timestamp - Sun, 21 Apr 2013 13:00:00 GMT
                item.LapseTime = hhmmss(currentTime, eventTime);
            });

            if ($scope.KOT) {
                angular.forEach($scope.KOT.KOTItems, function (item) {
                    var eventTime = (($scope.KOT.KOTTime + item.PresentationTime) * 60);
                    item.LapseTime = hhmmss(currentTime, eventTime);
                });
            }

        }

        function pad(num) {
            return ("0" + num).slice(-2);
        }
        function hhmmss(currentTime, eventTime) {
            var diffTime = eventTime - currentTime;
            var duration = moment.duration(diffTime * 1000, 'milliseconds');
            return duration.hours() + ":" + duration.minutes() + ":" + duration.seconds();
        }

        $scope.IsSaving = false;

        $scope.KOTItemStatuss = [];
        $scope.KOTs = [];
        $scope.BumpKOTs = [];
        $scope.Kitchens = [];
        $scope.KitchenId = '';
        $scope.KOT = {};
        
        $scope.GetAllKOTItemStatus = function () {
            
            var promiseGet = service.GetAllKOTItemStatus($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.KOTItemStatuss = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.data.Message);
                    scrollPageOnTop();
                });

        };
        $scope.GetAllKOTItemStatus();

        $scope.GetAllKitchen = function () {
            $scope.Kitchens = [];
            var promiseGet = service.GetAllKitchen($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Kitchens = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.data.Message);
                    scrollPageOnTop();
                });

        };
        $scope.GetAllKitchen();

        $scope.SelectKitchen = function (kitchenId) {
            $scope.KOT = {};
            $scope.KOTs = [];
            $scope.BumpKOTs = [];
            $scope.SelectedKOTId = '';
            $scope.KitchenId = '';
            $scope.selectedKOTProcessStatusId = ['1', '2'];
            $scope.GetAllPendingKOT(kitchenId);
            //$scope.GetAllBumpKOT(kitchenId);
        }

        $scope.GetAllPendingKOT = function (kitchenId) {
            $scope.KOTs = [];
            if (kitchenId) {
                $scope.KitchenId = kitchenId;
                $scope.GetAllBumpKOT(kitchenId);
                var promiseGet = service.GetAllPendingKOT(kitchenId, $scope.businessDate);
                promiseGet.then(function (data) {
                    $scope.KOTs = data.Collection;
                },
                    function (error) {
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };

        $scope.GetAllBumpKOT = function (kitchenId) {
            $scope.BumpKOTs = [];
            if (kitchenId) {
                $scope.KitchenId = kitchenId;
                var promiseGet = service.GetAllBumpKOT(kitchenId, $scope.businessDate);
                promiseGet.then(function (data) {
                    $scope.BumpKOTs = data.Collection;
                },
                    function (error) {
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }

        };
        $scope.SelectedKOTId = '';
        $scope.IsLoading = false;
        $scope.GetKOTById = function (id) {
            
            $scope.KOT = {};
            if (id) {
                $scope.SelectedKOTId = id;
                $scope.IsLoading = true;
                var promiseGet = service.GetKOTById(id, $scope.KitchenId);
                promiseGet.then(function (data) {
                    $scope.IsLoading = false;
                    $scope.KOT = data.Data;
                    angular.forEach($scope.KOT.KOTItems, function (item) {
                        item.KOTItemStatusId = item.KOTItemStatusId.toString();
                    });
                    scrollPageOnTop();
                    
                },
                    function (error) {
                        $scope.IsLoading = false;
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };

        $scope.BumpKOT = function () {
            if ($scope.KOT.Id) {
                $scope.KOT.ModifiedBy = $scope.UserName;
                $scope.KOT.KitchenId = $scope.KitchenId;
                $scope.IsSaving = true;
                var promiseGet = service.BumpKOT($scope.KOT);
                promiseGet.then(function (data) {
                    $scope.KOT = {};
                    $scope.IsSaving = false;
                    parent.posSuccessMessage(data.Message);
                    scrollPageOnTop();
                    
                },
                    function (error) {
                        $scope.IsSaving = false;
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };

        $scope.SaveKOTItemStatus = function (kotItem,kotItemStatusId) {
            
            if (kotItem.Id) {
                kotItem.KOTItemStatusId = kotItemStatusId;
                kotItem.ModifiedBy = $scope.UserName;
                var promiseGet = service.SaveKOTItemStatus(kotItem);
                promiseGet.then(function (data) {
                    var isStatus = true;
                    angular.forEach($scope.KOT.KOTItems, function (item) {
                        if(item.KOTItemStatusId==1)
                        {
                            isStatus = false;
                        }
                    });
                    if (isStatus)
                    {
                        $scope.KOT = {};
                    }
                    //parent.posSuccessMessage(data.Message);
                    scrollPageOnTop();
                },
                    function (error) {
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };

        $scope.SaveDisplayBoard = function (kot) {
            if (kot.Id) {
                var promiseGet = service.SaveDisplayBoard(kot.Id, kot.OutletId);
                promiseGet.then(function (data) {
                    if (kot.KOTDisplayTypeId == 3)
                    {
                        kot.KOTDisplayTypeId = 4;
                    }
                    else if (kot.KOTDisplayTypeId == 4) {
                        kot.KOTDisplayTypeId = 5;
                    }
                    else
                    {
                        kot.KOTDisplayTypeId = 4;
                    }
                    //kot.IsDisplayBoard = !kot.IsDisplayBoard;
                    //parent.posSuccessMessage(data.Message);
                    scrollPageOnTop();
                },
                    function (error) {
                        parent.posFailureMessage(error.data.Message);
                        scrollPageOnTop();
                    });
            }
        };

        $scope.selectedKOTProcessStatusId = ['1', '2'];
        $scope.filterForKOTProcessStatus = function (kot) {
            
            return ($scope.selectedKOTProcessStatusId.indexOf(kot.KOTProcessStatusId.toString()) !== -1);
        };

        $scope.Pending = function () {
            $scope.selectedKOTProcessStatusId = ['1'];
        };
        $scope.Partial = function () {
            $scope.selectedKOTProcessStatusId = ['2'];
        };

        //$scope.selectedKOTDisplayTypeId = ['1', '2'];
        //$scope.filterForKOTProcessStatus = function (kot) {
        //    return ($scope.selectedKOTDisplayTypeId.indexOf(kot.KOTProcessStatusId.toString()) !== -1);
        //};

        //SignalR

        $scope.IsHubConnected = false;
        var connection = $.hubConnection(apiPath);
        var eventName = "onMessageListened";
        connection.start().done(function () {
            $scope.IsHubConnected = true;
            //$("#status").text("").prepend("<i>" + eventName + "</i> event is being listened !").prepend("Connected. ").css("color", "green");
        });
        
        var messageBroadCast = connection.createHubProxy('BroadCastHub');
        messageBroadCast.on(eventName, function (message) {
            var res = message.split("$");
            
            if (res[0] == "TABLE_STATUS") {
                var kitchens = res[4].split(",");
                angular.forEach(kitchens, function (item) {
                    if (item == $scope.KitchenId) {
                        $scope.GetAllPendingKOT(item);
                        $scope.GetAllBumpKOT(item);
                    }
                });
            }
            else if (res[0] == "SETTLEMENT") {
                if (res.length > 2) {
                    var kitchens = res[4].split(",");
                    angular.forEach(kitchens, function (item) {
                        if (item == $scope.KitchenId) {
                            $scope.GetAllPendingKOT(item);
                            $scope.GetAllBumpKOT(item);
                        }
                    });
                }
            }
            else if (res[0] == "KOT_VOID") {

                //if (res[1] == outlet) {
                //    $scope.GetOutlet();
                //    if ($scope.Outlet.OutletTypeId == 1) {
                //        $scope.GetOccupiedRooms();
                //    }
                //}

                if (res.length > 1) {
                    var kitchens = res[2].split(",");
                    angular.forEach(kitchens, function (item) {
                        if (item == $scope.KitchenId) {
                            $scope.GetAllPendingKOT(item);
                            //$scope.GetAllBumpKOT(item);
                        }
                    });
                }
            }
            else if (res[0] == "BILL_VOID") {

               
            }
            else if (res[0] == "TRANSFER_KOT") {

                //if (res[1] == outlet) {

                //    $scope.GetOutlet();
                //    if ($scope.Outlet.OutletTypeId == 1) {
                //        $scope.GetOccupiedRooms();
                //    }
                //}

                if (res.length > 1) {
                    var kitchens = res[2].split(",");
                    angular.forEach(kitchens, function (item) {
                        if (item == $scope.KitchenId) {
                            $scope.GetAllPendingKOT(item);
                            $scope.GetAllBumpKOT(item);
                        }
                    });
                }
            }
            else if (res[0] == "TRANSFER_LOCATION") {

                if (res.length > 1) {
                    var kitchens = res[2].split(",");
                    angular.forEach(kitchens, function (item) {
                        if (item == $scope.KitchenId) {
                            $scope.GetAllPendingKOT(item);
                            $scope.GetAllBumpKOT(item);
                        }
                    });
                }
            }
        });

        //end signalR
    }
]).controller;
