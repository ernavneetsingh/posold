﻿
app.controller("POSMapController",
[
    "$scope", "POSMapService", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');

        $scope.IsShowUnMapped = false;


        $scope.myPageConfig = {
            valueField: "Name",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: true,
            maxItems: 1
        };


        $scope.Outlets = [];
        $scope.getOutlet = function () {
            service.getOutlet($scope.PropertyID)
                .then(function (data, status) {
                    $scope.Outlets = data.Collection;
                });
        };
        $scope.getOutlet();

        $scope.Model = {};
        $scope.Model.MenuCategorys = [];
        $scope.Model.TaxTypes = [];
        $scope.Model.Settlements = [];
        $scope.Model.AddOnCharges = [];

        $scope.getPOSMap = function () {
            //$scope.Model = {};

            $scope.Model.MenuCategorys = [];
            $scope.Model.TaxTypes = [];
            $scope.Model.Settlements = [];
            $scope.Model.AddOnCharges = [];

            service.getPOSMap($scope.Model.OutletId)
                .then(function (data, status) {
                    $scope.Model = data.Data;
                });
        };

        //$scope.MenuCategorys = [];
        //$scope.getMenuCategory = function () {
        //    $scope.MenuCategorys = [];
        //    service.getMenuCategory($scope.PropertyID)
        //        .then(function (data, status) {
        //            $scope.MenuCategorys = data.Collection;
        //        });
        //};

        //$scope.Taxs = [];
        //$scope.getTax = function () {
        //    $scope.Taxs = [];
        //    service.getTax($scope.PropertyID)
        //        .then(function (data, status) {
        //            $scope.Taxs = data.Collection;
        //        });
        //};

        //$scope.Settlements = [];
        //$scope.getSettlement = function () {
        //    $scope.Settlements = [];

        //    service.getSettlement($scope.PropertyID)
        //        .then(function (data, status) {
        //            $scope.Settlements = data.Collection;
        //        });
        //};

        $scope.AccountDumps = [];
        $scope.getAccountDump = function () {
            $scope.AccountDumps = [];
            service.getAccountDump($scope.PropertyID)
                .then(function (data, status) {
                    $scope.AccountDumps = data.Collection;

                });
        };
        $scope.getAccountDump();
        
        //$scope.FillOutlet = function () {
        //    $scope.getAccountDump();
        //    $scope.getMenuCategory();
        //    $scope.getTax();
        //    $scope.getSettlement();
        //}

        $scope.SetIsShow = function () {

            angular.forEach($scope.Model.MenuCategorys, function (item) {
                if ($scope.IsShowUnMapped)
                {
                    if(!item.AccountName || !item.AllowanceAccountName)
                    {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else
                    {
                        item.IsShow = false;
                    }
                }
                else
                {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.TaxTypes, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.Settlements, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.AddOnCharges, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
        }


        $scope.Save = function () {

            
            if (!$scope.Model.OutletId)
            {
                msg('Please Select Outlet.');
                return;
            }

            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;

            service.save($scope.Model)
                .then(function (result) {
                    if (result.Status == true) {
                        msg(result.Message, true);
                    }
                    $scope.Reset();
                }, function (error) {
                    msg(error.Message);
                });
        }

        $scope.Reset = function () {
            $scope.Model = {};
        }
    }
]);
