﻿
app.controller('controller', [
    '$scope', '$filter', '$cookies', 'service', '$window', 'localStorageService', function (
        $scope, $filter, $cookies, service, $window, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.keys = localStorageService.get('ActionKeys');
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.itemsPerPage = 10;
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];

        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.model.Id = "";
            $scope.model = {};

            $scope.searchFor = "";
            $scope.search();
            //localStorageService.set("searchfor", $scope.searchfor);
            //getData($scope, service, localStorageService);
            $scope.model.SettlementModeDetails = [];
            angular.forEach($scope.PaymentModeList, function (item) {
                item.IsSelected = false;
            });
        };

        $scope.getModuleList = function () {
            var promise = service.getModuleList();
            promise.then(function (data) {
                $scope.ModuleList = data.Collection;
            }, function (error) {
                msg(error);
            });
        };

        $scope.changeModule = function (id) {

            if (id === "3") {
            } else {
                $scope.model.OutletId = "";
            }

            //var promise = service.getAllByModule($scope.PropertyID, id);
            //promise.then(function (data) {
            //    if (data.Collection.length > 0)
            //        $scope.fillRecord(data.Collection[0]);
            //}, function (error) {
            //    msg(error);
            //});


        };

        $scope.getPaymentModeList = function () {
            var promise = service.getPaymentModeList($scope.PropertyID);
            promise.then(function (data) {
                $scope.PaymentModeList = data.Collection;
            }, function (error) {
                msg(error);
            });
        };

        $scope.getModuleList();
        $scope.getPaymentModeList();
        //$scope.reset();
        //getData($scope, service, localStorageService);
        $scope.ActionMode = "";
        $scope.fillRecord = function (record) {
            $scope.ActionMode = "Edit";
            $scope.model = record;
            $scope.model.ModuleId = record.ModuleId.toString();

            angular.forEach($scope.PaymentModeList, function (item) {
                item.IsSelected = false;
                angular.forEach(record.SettlementModeDetails, function (recItem) {
                    if (item.Id == recItem.RevenueHeadId) {
                        item.IsSelected = true;
                    }
                });
            });

            $scope.changeModule($scope.model.ModuleId);
            $scope.model.OutletId = record.OutletId;

            //msg('');
        };
        $scope.save = function (form) {


            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            $scope.model.SettlementModeDetails = [];
            angular.forEach($scope.PaymentModeList, function (item) {

                if (item.IsSelected) {
                    item.RevenueHeadId = item.Id;
                    $scope.model.SettlementModeDetails.push(item);
                }
            });
            if ($scope.model.SettlementModeDetails.length <= 0) {
                msg("Please select at least one settlement mode!");
                return;
            }
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;

            var promise = service.save($scope.model);
            promise.then(function (data) {

                $scope.reset();
                msg(data.Message, true);
                getData($scope, service, localStorageService);
            });

        };
        $scope.remove = function (id) {

            var promise = service.delete($scope.PropertyID, $scope.ModifiedBy, id);
            promise.then(function (data) {

                $scope.reset();
                getData($scope, service, localStorageService);
                msg(data.Message, true);
            });

        };

        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        };
        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, service, localStorageService);

        };
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }

        //var searchMatch = function (haystack, needle) {
        //    if (!needle) {
        //        return true;
        //    }
        //    return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        //};
        //$scope.search = function () {
        //    $scope.filteredItems = $filter("filter")($scope.items, function (item) {
        //        for (var attr in item) {
        //            if (attr === "ModuleSettingName") {
        //                if (searchMatch(item[attr], $scope.query))
        //                    return true;
        //            }
        //        }
        //        return false;
        //    });
        //    
        //    $scope.currentPage = 0;
        //    $scope.groupToPages();
        //};
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            $scope.itemsPerPage = $scope.filteredItems.length;
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }

            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        //$scope.range = function (start, end) {
        //    var ret = [];
        //    if (!end) {
        //        end = start;
        //        start = 0;
        //    }
        //    for (var i = start; i < end; i++) {
        //        ret.push(i);
        //    }
        //    return ret;
        //};
        //$scope.prevPage = function () {
        //    if ($scope.currentPage > 0) {
        //        $scope.currentPage--;
        //    }
        //};
        //$scope.nextPage = function () {
        //    if ($scope.currentPage < $scope.pagedItems.length - 1) {
        //        $scope.currentPage++;
        //    }
        //};
        //$scope.firstPage = function () {
        //    $scope.currentPage = 0;
        //}
        //$scope.lastPage = function () {
        //    $scope.currentPage = $scope.pagedItems.length - 1;

        //}
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };

        function getOutlet() {
            var promiseGet = service.getOutletList($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.OutletList = data.Collection;
            }, function (data) {

                msg(data.message);
            });
        };
        getOutlet();
        $scope.reset();

    }
]);

var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.AllData;
    $scope.ActionMode = "";
    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "ModuleName",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKey: sortKeyOrder.key,
        sortOrder: sortKeyOrder.order,
        searchfor: searchfor == null ? '' : searchfor
    };

    $scope.showLoader = true;
    dataService.getAll($scope.PropertyID, options)
        .then(function (totalItems) {

            angular.copy(totalItems.Collection, dataService.AllData);
            $scope.totalItems = totalItems.RecordCount;
            $scope.showLoader = false;
        }, function (error) {
            scrollPageOnTop();
            parent.failureMessage(error.Message);
        });
};
