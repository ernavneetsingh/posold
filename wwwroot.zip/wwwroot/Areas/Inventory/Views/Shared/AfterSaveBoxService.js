﻿
var AfterSaveBoxService = function ($http, $q, $sce, $interpolate, $compile) {

    var service = this;
    var scope;

    service.init = function ($scope) {
        scope = $scope;

        service.open = function (name, h, s, r) {
            $.fancybox({
                'href': '#afterSaveBox',
                'modal': true,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            $.fancybox.close();
                            r();
                        });
                }
            });
            service.name = name;
            //service.h = $sce.trustAsHtml($interpolate(h)(scope));
            service.send = s;
            service.r = r;

            service.h = $compile(h)(scope);
            angular.element(document.getElementById("acontent")).append(service.h);
        };
        service.close = function () {
            parent.$.fancybox.close();
            $("#afterSaveBox").hide('slow');
            if (service.r) service.r();
        };
        service.sendMethod = function (sms) {

            if (service.send) service.send(sms);
        };

        return service;
    };

};

app.service('AfterSaveBoxService', ['$http', '$q', '$sce', '$interpolate', '$compile', AfterSaveBoxService]);
