﻿
var LPService = function ($http, $q, $filter) {

    var service = this;
    var scope;

    service.init = function ($scope) {
        scope = $scope;

        service.getPointBalanceAmount = function (posCustomerId, amount, date) {
            return httpCaller(apiPath + "Loyalty/LPTransaction/GetPointBalanceAmount", $http, $q, { posCustomerId: posCustomerId, amount: amount, date: date});
        };
        service.getLoyaltyAmountToPoint = function (posCustomerId, amount) {
            return httpCaller(apiPath + "Loyalty/LPTransaction/AmountToPoint", $http, $q, { posCustomerId: posCustomerId, amount: amount });
        };
        service.getLoyaltyPointToAmount = function (posCustomerId, points) {
            return httpCaller(apiPath + "Loyalty/LPTransaction/PointToAmount", $http, $q, { posCustomerId: posCustomerId, points: points });
        };
        service.getAllLPCard = function (propertyId) {
            return httpCaller(apiPath + "Loyalty/LPCard/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        };

        service.getLoyaltyAmountFromPoint = function (customerId) {
            if (!scope.SettlementDetailSelect.RedeemPoints) {
                scope.SettlementDetailSelect.Amount = 0;
                return;
            }
            scope.SettlementDetailSelect.AvailablePoints = parseFloat(scope.SettlementDetailSelect.AllPoints) + parseFloat(scope.SettlementDetailSelect.CurrentBillPointsA);
            if (scope.SettlementDetailSelect.AvailablePoints < scope.SettlementDetailSelect.MinimumPoints) scope.SettlementDetailSelect.AvailablePoints = 0;
            if (scope.SettlementDetailSelect.RedeemPoints > scope.SettlementDetailSelect.AvailablePoints)
                scope.SettlementDetailSelect.RedeemPoints = scope.SettlementDetailSelect.AvailablePoints;
            service.getLoyaltyPointToAmount(customerId, scope.SettlementDetailSelect.RedeemPoints)
                .then(function (pv) {
                    if (pv) {
                        scope.SettlementDetailSelect.Amount = $filter("number")(pv.Data, 2).replace(/,/g, "");
                    }
                    else {
                        scope.SettlementDetailSelect.Amount = 0;
                    }
                    scope.SettlementDetailSelect.Amount = parseFloat(scope.SettlementDetailSelect.Amount);
                });
        };
        service.getLoyaltyPointFromAmount = function (customerId, amount) {
            if (!amount) {
                scope.SettlementDetailSelect.RedeemPoints = 0;
                return;
            }
            service.getLoyaltyAmountToPoint(customerId, amount)
                .then(function (pv) {
                    scope.SettlementDetailSelect.RedeemPoints = pv.Data;
                    service.getLoyaltyAmountFromPoint(customerId);
                });
        };
        service.getLoyaltyBalance = function (customerId) {
            service.getPointBalanceAmount(customerId, scope.SettlementDetailSelect.Amount, scope.ModifiedDate)
                .then(function (s) {
                    scope.SettlementDetailSelect.AllPoints = s.Data;
                    service.getLoyaltyPointFromAmount(customerId, scope.SettlementDetailSelect.Amount);
                    service.getLoyaltyPointToAmount(customerId, scope.SettlementDetailSelect.AllPoints)
                        .then(function (pv) {
                            scope.SettlementDetailSelect.AllAmount = pv.Data;
                        });
                }, function (e) {
                    parent.posFailureMessage(e.Message);
                });
        };
        service.getMinimumRedeemPoints = function (customerId) {
            httpCaller(apiPath + "Loyalty/LPTransaction/GetMinimumRedeemPoints", $http, $q, { posCustomerId: customerId, date: scope.ModifiedDate })// service.getMinimumRedeemPointsH(customerId, scope.ModifiedDate)
                .then(function (s) {
                    scope.SettlementDetailSelect.MinimumPoints = s.Data;
                });
        };
        service.calculateBillPoints = function (billId, moduleId) {
            httpCaller(apiPath + "Loyalty/LPTransaction/CalculateBillPoints", $http, $q, { billId: billId, moduleId: moduleId })
                .then(function (s) {
                    scope.SettlementDetailSelect.CurrentBillPoints = s.Data;
                });
        };
        service.currentBillPoints = function (billId, moduleId) {
            httpCaller(apiPath + "Loyalty/LPTransaction/CurrentBillPoints", $http, $q, { billId: billId, moduleId: moduleId })
                .then(function (s) {
                    scope.SettlementDetailSelect.CurrentBillPointsA = s.Data;
                });
        };
        service.getAllLPCards = function () {
            service.getAllLPCard(scope.PropertyID)
                .then(function (s) {
                    scope.LPCards = s.Collection;
                }, function (e) {
                    parent.posFailureMessage(e.Message);
                });
        };
        service.POSCustomerModify = function () {
            scope.IsPOSCustomerModify = true;
        };

        scope.changeLPCard = function (lpCardId) {
            
            service.POSCustomerModify();
            if (!scope.Customer) return;
            if (!scope.LPCards) return;
            var lpCard= scope.LPCards.find(x=>x.Id==lpCardId);
            if (!lpCard || !lpCard.IsNoAutoGenerate ) return;
            if (!lpCard.CardFormat) return;
       
            scope.Customer.LPCardNumber=lpCard.CardFormat
                .replace('PropertyCode',$scope.PropertyID)//.substr(0,4))
                .replace('PropertyCode',$scope.PropertyID)//.substr(0,4))
                .replace('yyyyMM',$filter("date")(scope.ModifiedDate,'yyyyMM'))
                .replace('yyyyMM',$filter("date")(scope.ModifiedDate,'yyyyMM'))
                .replace('AutoNumber',lpCard.NextAutoNumber)
            ;
            scope.Customer.LPCardIssueDate = $filter("date")(scope.ModifiedDate, scope.DateFormat);
        };

        service.getAllLPCards();

        return service;
    };

};
