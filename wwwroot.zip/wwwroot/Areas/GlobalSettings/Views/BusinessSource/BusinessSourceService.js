﻿
(function () {
    function businessSourceService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var linkModule = [];

        var getBusinessSource = function (options) {
            var url = apiPath + "GlobalSetting/businessSource/details?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getBusinessSourceData(businessSourceId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/businessSource/details/" + businessSourceId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getCodeExistBusinessSource(businessSourceCode, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/businessSource/exist/" + businessSourceCode + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function saveBusinessSource(bsModel) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/businessSource/create",
                data: bsModel,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function updateIsActiveBusinessSource(model) {
            return httpPoster(apiPath + "GlobalSetting/businessSource/changeStatus", $http, $q, model);
            //var deferred = $q.defer();
            //$http({
            //    method: "GET",
            //    url: apiPath + "GlobalSetting/businessSource/changeStatus",
            //    params: model,
            //    headers: { 'duxtechApiKey': accessToken },
            //    contentType: "application/json; charset=utf-8"
            //}).success(function (data, status, headers, cfg) {
            //    deferred.resolve(data);
            //}).error(function (err, status) {
            //    deferred.reject(status);
            //});
            //return deferred.promise;
        };

        function deleteBusinessSource(businessSourceId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/businessSource/delete/" + businessSourceId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                msg(err.Message);
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var service = {
            dataAllData: linkModule,
            getBusinessSource: getBusinessSource,
            getCodeExistBusinessSource: getCodeExistBusinessSource,
            saveBusinessSource: saveBusinessSource,
            getBusinessSourceData: getBusinessSourceData,
            updateIsActiveBusinessSource: updateIsActiveBusinessSource,
            deleteBusinessSource: deleteBusinessSource
        };
        return service;
    }

    app.factory("BusinessSourceService", ["$http", "$q", businessSourceService]);
})();
