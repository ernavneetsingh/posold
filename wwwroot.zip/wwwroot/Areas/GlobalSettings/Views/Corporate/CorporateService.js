﻿
(function () {

    function corporateService($http, $q) {

        function getCorporateTypes(propertyId) {
            var params = { propertyId: propertyId };
            return httpCaller(apiPath + "GlobalSetting/PropertyCorporateType/GetAll", $http, $q, params);
        }
        function getBookerTypes(propertyId) {
            return httpCaller(apiPath + "GlobalSetting/BookerType/allByPropertyId/" + propertyId, $http, $q);
        }
        function getBookers(propertyId, bookerTypeId) {
            return httpCaller(apiPath + "GlobalSetting/Booker/GetAllByBookerTypeId/" + bookerTypeId + "/" + propertyId, $http, $q);
        }
        function getCountryList() {
            return httpCaller(apiPath + "referencedata/country", $http, $q);
        }
        function getStateData(countryId) {
            return httpCaller(apiPath + "referencedata/state/" + countryId, $http, $q);
        }
        function getAmenitiesList(propertyId) {
            return httpCaller(apiPath + "FrontOffice/amenities/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        }
        function getDesignationList(propertyId) {
            return httpCaller(apiPath + "GlobalSetting/designation/GetAllByModuleId/" + propertyId + "/7", $http, $q);
        }
        function getPercentageTypeList() {
            return httpCaller(apiPath + "ReferenceConstant/PercentageType/all", $http, $q);
        }
        function getSalesOfficeList(propertyId) {
            var params = { propertyId: propertyId, all: 1 };
            return httpCaller(apiPath + "GlobalSetting/SalesOffice/GetAllByPropertyId", $http, $q, params);
        }
        function getSalesExecutiveList(propertyId) {
            var params = { propertyId: propertyId, all: 1 };
            return httpCaller(apiPath + "GlobalSetting/SalesExecutive/GetAllByPropertyId", $http, $q, params);
        }
        function getMarketSegmentList(propertyId) {
            return httpCaller(apiPath + "FrontOffice/MarketSegment/details/" + propertyId, $http, $q);
        }
        function getBusinessSourceList(propertyId) {
            return httpCaller(apiPath + "GlobalSetting/businessSource/details/" + propertyId, $http, $q);
        }
        function getRateList(rateTypeId, propertyId) {
            return httpCaller(apiPath + "FrontOffice/RateMaster/GetAllByRateTypeId/" + rateTypeId + "/" + propertyId, $http, $q);
        }
        function getRevenueHeadList(propertyId) {
            return httpCaller(apiPath + "GlobalSetting/RevenueHead/details/" + propertyId, $http, $q);
        }
        function getById(id) {
            return httpCaller(apiPath + "GlobalSetting/Corporate/GetById/" + id, $http, $q);
        }

        var linkModule = [];

        var getCorporate = function (options, propertyId) {

            var deferred = $q.defer();

            $http.get(apiPath + "GlobalSetting/corporate/all/" + propertyId + "?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId)
                .then(function (result) {
                    angular.copy(result.data.Collection, linkModule);
                    deferred.resolve(result.data.RecordCount);
                },
                function () {
                    deferred.reject();
                });

            return deferred.promise;
        };
        function getCorporateDetailsData(propertyId) {
            var params = { propertyId: propertyId };
            return httpCaller(apiPath + "GlobalSetting/corporate/all", $http, $q, params);

            //var deferred = $q.defer();
            //$http({
            //    method: "GET",
            //    url: apiPath + "GlobalSetting/corporate/all" + propertyId,
            //    data: {}
            //}).success(function (data, status, headers, cfg) {
            //    deferred.resolve(data);
            //}).error(function (err, status) {
            //    deferred.reject(status);
            //});
            //return deferred.promise;
        };

        function getCorporateData(corporateId, propertyId) {
            var params = { propertyId: propertyId, corporateId: corporateId };
            return httpCaller(apiPath + "GlobalSetting/corporate/get", $http, $q, params);

            //var deferred = $q.defer();
            //$http({
            //    method: "GET",
            //    url: apiPath + "GlobalSetting/corporate/details/" + corporateId + "/" + propertyId,
            //    data: {}
            //}).success(function (data, status, headers, cfg) {
            //    deferred.resolve(data);
            //}).error(function (err, status) {
            //    deferred.reject(status);
            //});
            //return deferred.promise;
        };

        function getCodeExistCorporate(corporateCode, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/corporate/exist/" + corporateCode + "/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function saveCorporate(corporateModel) {
            return httpPoster(apiPath + "GlobalSetting/corporate/save", $http, $q, corporateModel);

            //var deferred = $q.defer();
            //$http({
            //    method: "POST",
            //    url: apiPath + "GlobalSetting/corporate/create",
            //    data: corporateModel
            //}).success(function (data, status, headers, cfg) {
            //    deferred.resolve(data);
            //}).error(function (err, status) {
            //    deferred.reject(status);
            //});
            //return deferred.promise;
        };

        function updateIsActiveCorporate(model) {
            return httpPoster(apiPath + "GlobalSetting/Corporate/status", $http, $q, model);
        };

        function getRateCodeData(rateMasterId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/corporate/ratedetails/" + rateMasterId + "/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function deleteCorporate(corporateId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/corporate/delete/" + corporateId,//+ "/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var service = {
            getCorporateTypes: getCorporateTypes,
            getBookerTypes: getBookerTypes,
            getBookers: getBookers,
            getCountryList: getCountryList,
            getStateData: getStateData,
            getAmenitiesList: getAmenitiesList,
            getDesignationList: getDesignationList,
            getPercentageTypeList: getPercentageTypeList,
            getSalesOfficeList: getSalesOfficeList,
            getSalesExecutiveList: getSalesExecutiveList,
            getMarketSegmentList: getMarketSegmentList,
            getBusinessSourceList: getBusinessSourceList,
            getRateList: getRateList,
            getRevenueHeadList: getRevenueHeadList,
            getById: getById,

            dataAllData: linkModule,
            getRateCodeData: getRateCodeData,
            getCorporateDetailsData: getCorporateDetailsData,
            getCorporate: getCorporate,
            getCodeExistCorporate: getCodeExistCorporate,
            saveCorporate: saveCorporate,
            getCorporateData: getCorporateData,
            updateIsActiveCorporate: updateIsActiveCorporate,
            deleteCorporate: deleteCorporate
        };
        return service;
    }

    app.factory("CorporateService", ["$http", "$q", corporateService]);
})();
