﻿
app.service("accountDetailsService", function ($http, $q) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.agingHeader = function (propertyId, corporateId, modifiedDate) {
        return httpCaller(apiPath + "AccountReceiveable/AccountDetails/GetAging/" + propertyId + "/" + corporateId, $http, $q, { modifiedDate: modifiedDate });
    };


});
