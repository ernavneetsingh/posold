﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');

        //var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        //$scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            OutletId: '',
            OutletCode: '',
            OutletName: '',
            Code: '',
            Name: '',
            Rate:0,
            IsActive: '',
            IsActive: true,
            PropertyID: '',
            ModifiedBy: '',
        };

        $scope.Items = [];

        $scope.IsReadonly = false;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Items, function (item) {
                for (var attr in item) {
                    if (attr === "Name" || attr == "Code") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {
            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Items = data;
                $scope.search();
            },function (data) {
                parent.failureMessage(data.message);
            });
        };

        GetAllOutLet();
        function GetAllOutLet() {
            var promiseGet = service.getAllOutLet($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Outlets = data;
            });

        }

        $scope.GetAllThali = function (outletId) {

            var promiseGet = service.getAllPOSItem($scope.PropertyID, outletId);
            promiseGet.then(function (data) {
                
                $scope.POSItems = data;
                $scope.Model.ThaliItems.forEach(function(t){
                    $scope.POSItems.forEach(function(p){
                        
                        if(p.Id==t.POSItemId){
                            p.IsThali=true;
                            p.OutletItemRate=t.Rate;
                        }
                    });

                });

                var promiseGet1 = service.getAllThali(outletId);
                promiseGet1.then(function (data) {
                    $scope.Thalis = data;
                });
            });
        }

        $scope.SetPOSItem = function (thaliid) {

            $scope.Thali={
                Rate:0
            };

            $scope.ThaliConfigurations=[];
            $scope.TotalAmount=0;

            angular.forEach($scope.Thalis, function (thali) {

                if(thali.Id==thaliid)
                {
                    $scope.Thali = thali;

                    angular.forEach($scope.POSItems, function (posItem) {
                        posItem.IsThali = false;
                        //posItem.Quantity = 1;

                        angular.forEach(thali.ThaliItems, function (item) {
                            if (posItem.Id == item.POSItemId) {

                                posItem.OutletItemRate = item.Rate;
                                posItem.Quantity = item.Quantity;
                                posItem.IsThali = true;

                            }
                        });
                    });

                    
                }
            });

            $scope.Calculate ();

            

            angular.forEach($scope.Thali.ThaliConfigurations,function(item){
                angular.forEach($scope.ThaliConfigurations,function(thaliConfiguration){
                    if(thaliConfiguration.MenuSubCategoryId == item.MenuSubCategoryId)
                    {
                        thaliConfiguration.ItemLimit = item.ItemLimit;
                        thaliConfiguration.IsItemPrint = item.IsItemPrint;
                    }
                });
            });

            

        }

        $scope.Thali = { Rate: 0 };
        $scope.TotalAmount = 0;
        $scope.BalanceAmount = 0;
        $scope.Calculate = function () {
            $scope.TotalAmount = 0;
            angular.forEach($scope.POSItems, function (posItem) {

                if (posItem.IsThali)
                {
                    if (!posItem.Quantity) {
                        posItem.Quantity = 0;
                    }
                    posItem.Amount = parseFloat(posItem.Quantity) * parseFloat(posItem.OutletItemRate);

                    if (parseFloat($scope.TotalAmount) > parseFloat($scope.Thali.Rate)) {
                        scrollPageOnTop();
                        parent.failureMessage("Package Limit Exceeded");
                    }
                    else {
                        $scope.TotalAmount += posItem.Amount;
                        $scope.BalanceAmount = parseFloat($scope.Thali.Rate) - parseFloat($scope.TotalAmount);
                    }
                }
                else
                {
                    posItem.Amount = "";
                }

            });
            $scope.SetConfiguration();
        }

        $scope.ThaliConfiguration=
            {
                Id                :'',
                ThaliId           :'',
                MenuSubCategoryId :'',
                ItemCount         :0,
                ItemLimit         :0,
                IsItemPrint       :false,
            };
        $scope.ThaliConfigurations=[];
        $scope.SetConfiguration = function () {
            
            $scope.ThaliConfigurations=[];

            var selectedPOSItems = $scope.POSItems.filter(x=>x.IsThali==true);

            var distinct = $scope.GetDistinctCategorys(selectedPOSItems);

            angular.forEach(distinct, function (menuSubCategoryId) {
                var menuSubCategoryName="";
                var isExist =false;
                var ItemCount=0;
                angular.forEach(selectedPOSItems, function (posItem) {
                    if (menuSubCategoryId == posItem.MenuSubCategoryId) {
                        isExist =true;
                        menuSubCategoryName = posItem.MenuSubCategoryName;
                        ItemCount++;
                    }
                });

                $scope.ThaliConfigurations.push({

                    Id                :'',
                    ThaliId           :$scope.Thali.Id,
                    MenuSubCategoryId :menuSubCategoryId,
                    MenuSubCategoryName :menuSubCategoryName,

                    ItemCount         :ItemCount,
                    ItemLimit         :0,
                    IsItemPrint       :false,
                });

            });

            

        }

        $scope.GetDistinctCategorys = function (posItems) {
            var distinct = [];
            var newArr = posItems.filter(function (el) {
                if (distinct.indexOf(el.MenuSubCategoryId) === -1) {
                    // If not present in array, then add it
                    distinct.push(el.MenuSubCategoryId);
                    return true;
                }
                else {
                    // Already present in array, don't add it
                    return false;
                }
            });
            return distinct;
        };

        $scope.Save = function (model, form) {
            
            if ($scope[form].$valid) {

                //if (parseFloat($scope.TotalAmount) != parseFloat($scope.Thali.Rate)) {
                //    scrollPageOnTop();
                //    parent.failureMessage("Combo Rate should be equal to item amount total.");
                //    return;
                //}
                model.ThaliItems=[];

                model.Id=$scope.Thali.Id;
                
                var selectedPOSItems = $scope.POSItems.filter(x=>x.IsThali==true);

                angular.forEach(selectedPOSItems,function(item){
                    model.ThaliItems.push({
                        POSItemId : item.Id,
                        Rate : item.OutletItemRate,
                        Quantity: item.Quantity,
                        Amount : item.Amount,
                    })
                });

                model.ThaliConfigurations=$scope.ThaliConfigurations;

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                model.ModifiedDate = $scope.ModifiedDate;

                var status = service.save(model);
                status.then(function (result) {

                    if (result.Status == true) {
                        var msg = $scope.Thali.Name + " configuration " +  result.Message;
                        parent.successMessage(msg);
                        getData();
                    }
                    $scope.Reset();
                },
                function (error) {
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }

            $scope.model.ApplicableFromDate = '';
        }

        $scope.ChangeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };

        $scope.Edit = function (model) {
           
            $scope.Model = model;
            
            $scope.GetAllThali(model.OutletId);
            
            $scope.IsReadonly = true;
            scrollPageOnTop();
        }
        $scope.Reset = function () {
            $scope.Model = {};
            $scope.query = '';
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;

            $scope.Thali={
                Rate:0
            };
            $scope.POSItems=[];
            $scope.ThaliConfigurations=[];
            $scope.TotalAmount=0;
            getData();
            scrollPageOnTop();
        }
        $scope.IsCodeExist = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.isCodeExist($scope.PropertyID, model.Code);
            promiseGet.then(function (data) {
            },
                function (error) {
                    $scope.Model.Code = "";
                    parent.failureMessage(error.Message);
                    scrollPageOnTop();
                });
        };
       
    }
]);
