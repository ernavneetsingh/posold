﻿
app.controller("menuController",
    function ($scope, $http, $q,  $filter, $cookies, $location, manuService, localStorageService, $timeout,ImageUploadService,$rootScope, $window) {
        
        if (!initCommon($scope, $http, $q, localStorageService, $cookies, $window)) return;
        
        $scope.ImageUploadService= ImageUploadService;

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        if(!$scope.PropertyID ){
            window.location.href = "../../../login.html";
            return;
        }
        $scope.ProductName = $cookies.get('ProductName');
        $scope.LoginId = $cookies.get('LoginId');
        $scope.UserName = $cookies.get('UserName');
        $scope.FirstName = $cookies.get('FirstName');
       
        $scope.FOShiftId = localStorageService.get('FOShiftId'); 
        $scope.FOShiftNo = localStorageService.get('FOShiftNo')
        $scope.FOShiftDate = localStorageService.get('FOShiftDate')

        if ($scope.LoginId == undefined) {
            var url = Path + "login.html";
            window.location.href = url;
        }
        
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.businessDate = $filter('date')(date, $scope.DateFormat);

        setInterval(function(){
            SetAlert();
        }, 6000)

        $scope.ActionKeys={
            IsAdd:false,
            IsEdit:false,
            IsDelete:false,
            IsAuthorize:false
        }
         debugger;
            $scope.ActionKeys.IsAdd = true;
            $scope.ActionKeys.IsEdit = true;
            $scope.ActionKeys.IsDelete = true;
            $scope.ActionKeys.IsAuthorize = true;
            localStorageService.set('ActionKeys', $scope.ActionKeys);
        $scope.SetHelpPage =function(userProductPageId,newUrl, roleModulePageId){
            localStorageService.set('UserProductPageId', userProductPageId);
            $scope.ActionKeys={
                IsAdd:false,
                IsEdit:false,
                IsDelete:false,
                IsAuthorize:false
            }
            debugger;
            $scope.ActionKeys.IsAdd = true;
            $scope.ActionKeys.IsEdit = true;
            $scope.ActionKeys.IsDelete = true;
            $scope.ActionKeys.IsAuthorize = true;
            localStorageService.set('ActionKeys', $scope.ActionKeys);

            if(!newUrl) return;
            var base_url = window.location.host;
            var new_base_url=newUrl.split('/')[2];
            if(!new_base_url) return;
          
            if(base_url === new_base_url){
               
                if(roleModulePageId)
                {
                    var promiseGet =  manuService.getPageActionKeys(roleModulePageId)
                    promiseGet.then(function (data) {
                        if (data.Data) {
                            //angular.forEach(data.Data.ActionMasters, function (key) {

                            //    if (key.Name == "Add") {
                            //        $scope.ActionKeys.IsAdd = key.IsActive;
                            //    }
                            //    else if (key.Name == "Edit") {
                            //        $scope.ActionKeys.IsEdit = key.IsActive;
                            //    }
                            //    else if (key.Name == "Delete") {
                            //        $scope.ActionKeys.IsDelete = key.IsActive;
                            //    }
                            //    else if (key.Name == "Authorization") {
                            //        $scope.ActionKeys.IsAuthorize = key.IsActive;
                            //    }
                            //});

                            $scope.ActionKeys.IsAdd = true;
                            $scope.ActionKeys.IsEdit = true;
                            $scope.ActionKeys.IsDelete = true;
                            $scope.ActionKeys.IsAuthorize = true;


                        }
                            localStorageService.set('ActionKeys', $scope.ActionKeys);
                            window.location.href = newUrl;
                    },
                        function (error, status) {
                           
                            localStorageService.set('ActionKeys', $scope.ActionKeys);
                            window.location.href = newUrl;
                            
                        });                   
                }
                else
                {
                    window.location.href = newUrl;
                }
              
            }
            else{

                window.location.href = newUrl+'?propertyId='+localStorageService.get('PropertyId');
            }
        };
        $scope.ShowPageHelp =function(){
            
            $scope.UserProductPageId = localStorageService.get('UserProductPageId');
            $scope.ShowHelpContent=false;
            $('#HelpBox').modal('show');
            if(!$scope.UserProductPageId)
                msg('UserProductPageId not available');
            else
                manuService.getPageHelp($scope.UserProductPageId)
                    .then(function(s){
                        $scope.ModulePageHelpList=s.Collection;
                        $scope.ModulePageName = s.Collection && s.Collection.length > 0 ? s.Collection[0].ModulePageName : '';
                        $scope.ModulePageModuleName = s.Collection && s.Collection.length > 0 ? s.Collection[0].ModulePageModuleName : '';
                    });
        };
        $scope.showHelpContent=function(item,back){
            $scope.ShowHelpContent=!back;
            $scope.ShowHelpSearch=false;
            $scope.ModulePageModuleName = $scope.ModulePageHelpList && $scope.ModulePageHelpList.length>0? $scope.ModulePageHelpList[0].ModulePageModuleName:'';
            $scope.ModulePageName =$scope.ModulePageHelpList && $scope.ModulePageHelpList.length>0?  $scope.ModulePageHelpList[0].ModulePageName:'';
            if(back)return;
            $scope.HelpTitle=item.Title;
            $scope.HelpDescription=item.Description;
            
            if(item.PageContent && item.PageContent.length>10){
                while(item.PageContent.indexOf('src="apiPath')>-1)
                    item.PageContent=item.PageContent.replace('src="apiPath','src="'+apiPath)
            }
            $scope.HelpPageContent=item.PageContent;// && item.PageContent.length>10? item.PageContent.replace('src=apiPath"','src="'+apiPath):item.PageContent;
            $scope.HelpTags=item.HelpTags;
            $scope.ModulePageHelpSuggests=null;
            $scope.ModulePageModuleName = item.ModulePageModuleName;
            $scope.ModulePageName = item.ModulePageName;
        };
        $scope.searchByTag =function(searchTag){
            manuService.searchByTag(searchTag)
                     .then(function(s){
                         $scope.ModulePageHelpSuggests=$scope.ModulePageHelpSuggestsOriginal=s.Collection;
                         $scope.ShowHelpContent=s.Collection && s.Collection.length<1;
                         $scope.ShowHelpSearch=true;
                         $scope.searchTag=searchTag;
                     });
        };
        $scope.filterTagSearch =function(filterTag){
            $scope.ModulePageHelpSuggests=$scope.ModulePageHelpSuggestsOriginal.filter(x=>x.Title.indexOf(filterTag)>-1);
        };
        $scope.resetSearchTag =function(filterTag){
            $scope.filterTag='';
            $scope.ModulePageHelpSuggests=$scope.ModulePageHelpSuggestsOriginal;
        };

        $scope.Pages = [];
        $scope.MenuModels = [];
        getPropertiesMenu();

        $scope.titles = [];
        $scope.model = [];
        $scope.catg = [];

        $scope.myPageConfig = {
            valueField: "UserProductPageId",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: true,
            maxItems: 1
        };

        $scope.$watch(manuService.getProgress, function (v) {
            
            $scope.IsProgress = v;
        });

        function getPropertiesMenu() {

            $scope.MenuModels = [];

            var roleModulePages = localStorageService.get("RoleModulePages");
            var parsed = roleModulePages;
            var loginPropertys = localStorageService.get("LoginPropertys");
            var test = loginPropertys;

            //Modules
            angular.forEach(parsed, function (item) {
                var IsExist = false;
                for (var i = 0 ; i <= $scope.MenuModels.length - 1; i++) {
                    if (item.ModuleId.toString() == $scope.MenuModels[i].ModuleId.toString()) {
                        IsExist = true;
                        break;
                    }
                }

                if (!IsExist) {
                    if (item.ModuleIconUrl != null && item.ModuleIconUrl != "" && item.ModuleIconUrl != undefined) {
                        item.ModuleIconUrl = apiPath + item.ModuleIconUrl;
                    }
                    else {
                        item.ModuleIconUrl = "";
                    }
                    
                    $scope.MenuModels.push({ ModuleId: item.ModuleId.toString(), ModuleName: item.ModuleName, IconUrl: item.ModuleIconUrl, SubModules: [], ErrorIconUrl: item.ErrorIconUrl });
                    IsExist = false;
                }
            });


            //submodule 
            angular.forEach($scope.MenuModels, function (menuModel) {
                angular.forEach(parsed, function (item) {
                    var IsExist = false;
                    if (menuModel.ModuleId.toString() == item.ModuleId.toString()) {
                        IsExist = false;
                        if (menuModel.SubModules.length > 0) {
                            for (var i = 0 ; i <= menuModel.SubModules.length - 1; i++) {
                                if (menuModel.SubModules[i].SubModuleId == item.SubModuleId.toString()) {
                                    IsExist = true;
                                    break;
                                }
                            }
                        }
                        if (!IsExist) {
                            menuModel.SubModules.push({ SubModuleId: item.SubModuleId.toString(), SubModuleName: item.SubModuleName, SubModulePages: [] });
                        }
                    }
                });
            });

            //pages 
            angular.forEach($scope.MenuModels, function (module) {
                angular.forEach(module.SubModules, function (subModule) {
                    
                    angular.forEach(parsed, function (item) {
                        if ((module.ModuleId == item.ModuleId.toString()) && (subModule.SubModuleId == item.SubModuleId.toString())) {
                            var IsExist = false;
                            if (subModule.SubModulePages.length > 0) {
                                for (var i = 0 ; i <= subModule.SubModulePages.length - 1; i++) {
                                    if ((subModule.SubModulePages[i].UserProductPageId == item.UserProductPageId.toString()) && (module.ModuleId == item.ModuleId.toString()) && (subModule.SubModuleId == item.SubModuleId.toString())) {
                                        IsExist = true;
                                        break;
                                    }
                                }
                            }
                            if (!IsExist) {

                                var path = Path;
                                if( item.BaseUrl)
                                {
                                    path = item.BaseUrl;
                                }
                                subModule.SubModulePages.push({ UserProductPageId: item.UserProductPageId.toString(), Url: path + '' + item.PageUrl, Name: item.PageName, RoleModulePageId:item.RoleModulePageId });
                                $scope.Pages.push({ UserProductPageId: item.UserProductPageId.toString(), Url: path + '' + item.PageUrl, Name: item.PageName, RoleModulePageId:item.RoleModulePageId });
                            }
                        }
                    });
                });
            });
        };
     
        $scope.GoToPageCorporate = function (userProductPageId) {
            $scope.SetHelpPage(userProductPageId);
            var url = "";
            var roleModulePageId="";
            angular.forEach($scope.Pages, function (page) {

                if (page.UserProductPageId == userProductPageId) {
                    url = page.Url;
                    roleModulePageId=page.RoleModulePageId;
                }
            });
            $scope.ActionKeys={
                IsAdd:false,
                IsEdit:false,
                IsDelete:false,
                IsAuthorize:false
            }
            if(roleModulePageId)
            {
                var promiseGet =  manuService.getPageActionKeys(roleModulePageId)
                promiseGet.then(function (data) {
                    if (data.Data) {
                        angular.forEach(data.Data.ActionMasters, function (key) {

                            if (key.Name == "Add") {
                                $scope.ActionKeys.IsAdd = key.IsActive;
                            }
                            else if (key.Name == "Edit") {
                                $scope.ActionKeys.IsEdit = key.IsActive;
                            }
                            else if (key.Name == "Delete") {
                                $scope.ActionKeys.IsDelete = key.IsActive;
                            }
                            else if (key.Name == "Authorization") {
                                $scope.ActionKeys.IsAuthorize = key.IsActive;
                            }
                        });                       
                    }
                    localStorageService.set('ActionKeys', $scope.ActionKeys);
                    if (url.length > 0) {
                        window.location.href = url;
                    }
                },
                    function (error, status) {
                        if (url.length > 0) {

                            window.location.href = url;
                        }
                    });

                   
            }

            

        };

        $scope.logoutRequest = function () {
            var promiseGet = manuService.logoutRequestFor();
            promiseGet.then(function (data) {
                if (data) {
                    window.location.href = apiPath + 'login.aspx';
                }
            },
                function (error, status) {

                });
        };

        $scope.getSubMenu = function (event) {
            $('.mainnavigation-nav ul li ul.submodule').hide();
            var $input = $(event.target);
            var parent = $($input.parents('.mainmodule').get(0));
            parent.find('ul.submodule').show();
            parent.find('ul.submodule').css('background-color', '#222226');
        };

        $scope.getPages = function (subModule) {
            
            $scope.SubModulePages = subModule.SubModulePages;
            $('.submenu-wrap').show();
            $('.submenu-wrap').css('display', 'block', 'z-index', '999');

        };
        $scope.Company = {};
        $scope.LoginPropertys = [];

        $scope.LoginPropertys = localStorageService.get("LoginPropertys");

        $scope.Company = $cookies.getObject('Company');

        GetProperty($scope.PropertyID);
        function GetProperty(id) {
            angular.forEach($scope.LoginPropertys, function (item) {
                if (id == item.Id) {
                    $scope.Property = item;
                }
            });
        }

        function GoToProperty(id) {
           
            angular.forEach($scope.LoginPropertys, function (item) {
                if (id == item.Id) {

                    localStorageService.set('PropertyId', item.Id);
                    localStorageService.set('PropertyName', item.Name);
                    localStorageService.set('DateFormat', item.DateFormat);
                    //localStorageService.set('BusinessDate', item.BusinessDate);
                    var mDate = GetMomentDate(item.BusinessDate, 'YYYY-MM-DD')
                    var businessDate = {
                        Year: mDate.format('YYYY'),
                        Month: mDate.format('MM'),
                        Day: mDate.format('DD'),
                    };
                    localStorageService.set('BusinessDate', businessDate);

                    localStorageService.set('FOShiftId', item.FOShiftId);
                    $cookies.put('FOShiftNo', item.FOShiftNo);
                    $cookies.put('FOShiftDate', item.FOShiftDate);

                    $scope.Property = item;
                }

            });

            $scope.PropertyID = localStorageService.get('PropertyId');
            if ($scope.PropertyID.length > 0) {
                window.location.href = "../../../FO/DashBoard";
            }
            else {
                window.location.href = "../../../login.html";
            }
        }
        $scope.GoToProperty = function (id) {
           
            GoToProperty(id);
        };


        
        $scope.GoToFOShift = function (id) {
           
            window.location.href = "../../../FO/Operation/FOShift"; 
        };


        $scope.IsShowChangePassword = false;

        $scope.ShowChangePassword = function () {
            $scope.IsShowChangePassword = !$scope.IsShowChangePassword;
        }

        $scope.ChangePasswordModel = {
            UserName: '',
            Password: '',
            OldPassword: ''
        };

        $scope.ChangePassword = function (form) {

            if ($scope[form].$valid) {

                $scope.ChangePasswordModel.UserName = $scope.UserName;
                $scope.ChangePasswordModel.PropertyID = $scope.PropertyID;
                $scope.ChangePasswordModel.ModifiedBy = $scope.ModifiedBy;
                var status = manuService.changePassword($scope.ChangePasswordModel);
                status.then(function (result) {
                    if (result.Status == true) {
                        $('#changePassword').modal('hide');
                        parent.successMessage(result.Message);
                    }
                    $scope.ChangePasswordModel = {};
                }, function (error) {
                    parent.posFailureMessage(error.Message);
                });
            } else {
                $scope.ErrorMessage = true;
            }
            scrollPageOnTop();
        }

        //Notification SearchModel

        //-----------------------------------------------------------
        //Paging
        //-----------------------------------------------------------
        
        $scope.SearchNotificationList = [];
        $scope.ModuleOperationTypes = [];
        $scope.UnReadMessases = [];
        $scope.SelectedNotification = {};
        $scope.PopupIsProgress = false;
        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";

        var sortKeyOrder = {
            key: "",
            order: ""
        };
        $scope.SearchModel = {
            Name : $scope.UserName,
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        getNotificationData($scope, manuService, localStorageService);

        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getNotificationData($scope, manuService, localStorageService);
        };
        $scope.pageChanged = function () {
            getNotificationData($scope, manuService, localStorageService);
        };
        $scope.search = function (searchfor) {
            $scope.SearchNotificationList = [];
            $scope.SelectedNotification = {};
            $scope.PopupIsProgress = true;

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);

            getNotificationData($scope, manuService, localStorageService);

        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getNotificationData($scope, manuService, localStorageService);
        }
        //-----------------------------------------------------------

        $scope.ChangeStatusNotification = function (model,IsFromAlert) {
            

            if(model.MessageActionId==3)
            {
                return;
            }
            
            if(IsFromAlert)
            {
                model.MessageActionId=2;
                model.MessageActionName='Read';
            }


            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.UserName;

            var promiseGet = manuService.changeStatusNotification(model);
            promiseGet.then(function (data, status) {

                if(IsFromAlert)
                {
                    model.MessageActionId=3;
                    model.MessageActionName='Acknowledge';
                }

                getNotificationData($scope, manuService, localStorageService);

                

                //angular.forEach($scope.SearchNotificationList, function (notificationList) {
                //    if(notificationList.Id == model.Id)
                //    {
                //        notificationList.MessageActionId=3;
                //        notificationList.MessageActionName='Acknowledge';
                //    }
                //});

                
            },
            function (error, status) {
                parent.popErrorMessage(error.Message); scrollPageOnTop();
            });
            scrollPageOnTop();
        };

        $scope.SelectedModuleOperationType={Id:0, Name:'All'};

        $scope.GetNotificationForSelectedModuleOperationType = function (moduleOperationType) {
            $scope.SelectedNotificationList = $scope.SearchNotificationList;
            if(moduleOperationType.Name!='All')
            {
                $scope.SelectedNotificationList = $scope.SearchNotificationList.filter(x=>x.ModuleOperationTypeName ==moduleOperationType.Name ) ;
            }
        };
        
        $scope.AlertNotificationList=[];
        function SetAlert() {
            
            $scope.AlertNotificationList=[];

            var d = new Date();
            var minutes = d.getHours() * 60 + d.getMinutes() + 10;

            angular.forEach($scope.SearchNotificationList, function (notificationList) {

                if(notificationList.NotificationKeyCode == 'WakeUpCall')
                {
                    var deliverTime = notificationList.DeliverTime;

                    if ((minutes>deliverTime) && (notificationList.MessageActionId.toString() != '3')) {
                        $scope.$apply(function(){
                            
                            notificationList.MessageActionId=2;
                            notificationList.MessageActionName='Read';

                            $scope.AlertNotificationList.push(angular.copy( notificationList));
                        });
                    }
                }
            });

            $scope.ShowValidationMessage();
        }

        $scope.ShowValidationMessage = function () {
            if ($scope.AlertNotificationList.length > 0) {
                
                $("#NotificationPopup").modal('hide');
                $("#NotificationAlert").modal('show');
            }
        }

        $scope.GetUnReadMessases = function (){
            

            $scope.UnReadMessases=[];
            angular.forEach($scope.SearchNotificationList, function (item) {
                if(item.MessageActionName == 'UnRead')
                {
                    $scope.UnReadMessases.push(angular.copy(item));
                }
            });
            
            return $scope.UnReadMessases.length;
        }

        //SignalR
        $scope.IsHubConnected = false;
        var connection = $.hubConnection(apiPath);
        var eventName = "onMessageListened";
        connection.start({ withCredentials: false }).done(function () {
            $scope.$apply(function(){
                $scope.IsHubConnected = true;
            });
        });
        
        
        var messageBroadCast = connection.createHubProxy('BroadCastHub');
        messageBroadCast.on(eventName, function (message) {
                
            var res = message.split("$");
            if (res[0] == "NOTIFICATION") {
                
                if (res[1] == $scope.PropertyID) {
                    $("#NotificationAlert").modal('hide');
                    getNotificationData($scope, manuService, localStorageService);
                }
            }
            //CheckIN Guest Image
            if (res[0] == "UPLOAD_IMAGE_GUEST") {
                
                if (res[1] == $scope.PropertyID) {
                    $scope.childmethod(res[2],res[3],res[4]);
                }
            }
            
            //NIGHTAUDITSTART
            if (res[0] == "NIGHTAUDITSTART") {

                if (res[1] == $scope.PropertyID) {
                    $('#nightAuditStartBox').modal('show');
                }
            }
            //NIGHTAUDITEND
            if (res[0] == "NIGHTAUDITEND") {

                if (res[1] == $scope.PropertyID) {
                    window.location.href = "../../../login.html";
                }
            }

            //CHECKIN_VERIFICATION_SAVE
            if (res[0] == "CHECKIN_VERIFICATION_SAVE") {

                if (res[1] == $scope.PropertyID && res[2] == $scope.UserName) {
                    //$scope.OpenVerification(res[3]);
                }

            }
            if (res[0] == "CHECKIN_VERIFICATION_ACCEPT") {
                if (res[1] == $scope.PropertyID && res[2] == $scope.UserName) {
                    $scope.AcceptCheckINGuest(res[3],res[4],res[5]);
                }
            }
            if (res[0] == "CHECKIN_VERIFICATION_DECLINE") {
                if (res[1] == $scope.PropertyID && res[2] == $scope.UserName) {
                    $scope.DeclineCheckINGuest(res[3]);
                }
            }
            if (res[0] == "DASHBOARD_CHECKIN") {
                if (res[1] == $scope.PropertyID) {
                    $scope.CallDashboardCheckIN();
                    getNotificationData($scope, manuService, localStorageService);
                }
            }
            if (res[0] == "FO_CHECKOUT") {
                if (res[1] == $scope.PropertyID) {
                    $scope.CallDashboardCheckIN();
                    getNotificationData($scope, manuService, localStorageService);
                }
            }
            if (res[0] == "DASHBOARD_RESERVATION") {
                
                if (res[1] == $scope.PropertyID) {
                    $scope.CallDashboardCheckIN();
                    getNotificationData($scope, manuService, localStorageService);
                }
            }
            if (res[0] == "DASHBOARD_NOSHOW") {
                if (res[1] == $scope.PropertyID) {
                    //$scope.CallDashboardNOShow();
                    $scope.CallDashboardCheckIN();
                }
            }
            if (res[0] == "DASHBOARD_RESERVATION_CANCEL") {
                if (res[1] == $scope.PropertyID) {
                    //$scope.CallDashboardReservationCancel();
                    $scope.CallDashboardCheckIN();
                    $("#NotificationAlert").modal('hide');
                    getNotificationData($scope, manuService, localStorageService);
                }
            }

        });

        //DASHBOARD
        $scope.CallDashboardCheckIN = function(guid) {
            $rootScope.$emit("CallDashboardCheckIN", {});
        }
        $scope.DASHBOARDEXPECTEDARRIVAL = function(guid) {
            $rootScope.$emit("CallDASHBOARDEXPECTEDARRIVAL", {});
        }
        $scope.DASHBOARDTODAYCHECKIN = function(guid) {
            $rootScope.$emit("CallDASHBOARDTODAYCHECKIN", {});
        }
        $scope.DASHBOARDTODAYRESERVATION = function(guid) {
            $rootScope.$emit("CallDASHBOARDTODAYRESERVATION", {});
        }
        //

        $scope.childmethod = function(id,sno, url) {
            $rootScope.$emit("CallParentMethod", {
                Id:id,
                SNo:sno,
                UploadImageUrl:url
            });
        }
        $scope.OpenVerification = function(guid) {
            $rootScope.$emit("CallOpenVerification", {
                GUID:guid,
            });
        }
        $scope.AcceptCheckINGuest = function(guid,signatureUrl, imageUrl) {
            $rootScope.$emit("CallAcceptCheckINGuest", {
                GUID:guid,
                SignatureUrl:signatureUrl,
                ImageUrl:imageUrl
            });
        }
        $scope.DeclineCheckINGuest = function(guid) {
            $rootScope.$emit("CallDeclineCheckINGuest", {
                GUID:guid,
            });
        }

        //end signalR

        
    });

var getNotificationData = function ($scope, dataService, localStorageService) {
    $scope.PopupIsProgress = true;

    $scope.SearchNotificationList = dataService.dataAllData;
    $scope.SelectedNotificationList = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Message",
            order: "ASC"
        };
    }
    var searchfor = localStorageService.get("searchfor");

    if (!$scope.SearchModel) {
        $scope.SearchModel = {
            Name: $scope.UserName,
        };
    }
    else {
        
    }

    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        CurrentPage: $scope.currentPage,
        RecordsPerPage: $scope.recordsPerPage,

        SortKey: "Message",
        SortKeyOrder: "ASC",

        Searchfor: searchfor,
        PropertyID: $scope.PropertyID,
        BusinessDate : $scope.BusinessDate.Year +'-'+ $scope.BusinessDate.Month +'-'+ $scope.BusinessDate.Day,
        User: $scope.SearchModel
    };
    
    dataService.getSearch(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
        $scope.UnReadMessases = [];
        $scope.ModuleOperationTypes = [];
        $scope.ModuleOperationTypes.push({ Id: '0', Name: 'All' });

        angular.forEach($scope.SearchNotificationList, function (item) {
            var isExist = false;
            angular.forEach($scope.ModuleOperationTypes, function (moduleOperationType) {
                
                if( moduleOperationType.Name== item.ModuleOperationTypeName)
                {
                    isExist = true;
                }
            });

            if (!isExist)
            {
                $scope.ModuleOperationTypes.push({ Id: item.ModuleOperationTypeId, Name: item.ModuleOperationTypeName });
            }
            $scope.GetUnReadMessases();
        });

        $scope.PopupIsProgress = false;
    },
    function () {
        $scope.PopupIsProgress = false;
        //msg("The request failed. Unable to connect to the remote server.");
    });


};
