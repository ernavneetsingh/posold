﻿

app.service('moduleSettingService', function ($http, $q) {

    this.getModuleData = function () {
        return httpCaller(apiPath + "configuration/Module/all", $http, $q);
    };
    this.getAll = function () {
        return httpCaller(apiPath + "configuration/ModuleSetting/all", $http, $q);
    };
    this.save = function (model) {
        return httpPoster(apiPath + "configuration/ModuleSetting/Save", $http, $q, model);
    };
    this.statusChange = function (model) {
        return httpPoster(apiPath + "configuration/ModuleSetting/Status", $http, $q, model);
    };

});
