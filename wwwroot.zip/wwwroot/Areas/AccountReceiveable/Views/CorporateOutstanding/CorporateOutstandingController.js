﻿
app.controller("CorporateOutstandingController", function ($scope, $http, $filter, $window, $cookies, transactionService, corporateOutstandingService, periodCloseService, localStorageService) {

    $scope.IsCorporatePage = true;

    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedBy = $cookies.get('UserName');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

    $scope.resetSearch = function () {
        $scope.Search = {};
    }
    $scope.resetHistory = function () { }
    $scope.resetCompany = function () {
        $scope.Company = {};
    }
    $scope.resetOutstanding = function () {
        $scope.CorporateOutstanding = {};
    }
    $scope.resetGrid = function () {
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
    }
    $scope.resetAll = function () {
        $scope.IsEditable = true;
        $scope.resetSearch();
        $scope.resetHistory();
        $scope.resetCompany();
        $scope.resetOutstanding();
        $scope.resetGrid();
    }
    $scope.resetAll();

    function getDefaults() {
        var promiseGet = transactionService.GetDefaults($scope.PropertyID);
        promiseGet.then(function (data, status) {
            if (data.Status) {
                $scope.defaultData = data.Data;
            }
        },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
    };
    getDefaults();
    periodCloseService.getStartPeriod($scope);

    $scope.getAutoSuggest = function (item, txt) {
        var promiseSuggest = transactionService.suggest($scope.PropertyID, item, txt);
        promiseSuggest.then(function (data, status) {
            $("#txtSearch" + item).autocomplete({
                source: function (request, response) {
                    response($.map(data.Data.Suggestions, function (ret) {
                        //var partition = ret.indexOf(':');
                        return {
                            label: ret,
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {
                    if (ui.item) {
                        var promiseSearch = transactionService.search($scope.PropertyID, item, ui.item.val, $scope.DateFormat);
                        promiseSearch.then(function (datas) {
                            $scope.load(datas, item);
                        });
                    }
                },
                minLength: 1
            });
        });
    };
    $scope.getRecent = function () {
        var promise = transactionService.search($scope.PropertyID, "CorporateId", $scope.Company.Id, $scope.DateFormat);
        promise.then(function (data, status) {

            $scope.load(data, "any");
        });
    };
    $scope.load = function (data, searchType) {

        if (searchType && searchType !== "CompanyType") {
            $scope.Company = data.Data;
            $scope.items = [];
            $scope.items.push(data.Data.CorporateOutstanding);
            $scope.IsEditable = data.Data.Transactions.length < 1;
            if (data.Data.CorporateOutstanding) {
                $scope.IsEditable = $scope.IsEditable && dateCompare(data.Data.CorporateOutstanding.OpeningDateString, $scope.MinDate) >= 0;
            }

            //$scope.Company = data.Data;
            //$scope.getOpeningDate();
            //$scope.items = data.Data.Transactions;
            //$scope.search();
        }
        $scope.History = data.Data.History;
    };

    $scope.save = function (model, form) {

        if (!$scope[form].$valid) return;
        if (!$scope.IsEditable) return;

        model.CorporateId = $scope.Company.Id;
        model.PropertyID = $scope.PropertyID;
        model.ModifiedBy = $scope.ModifiedBy;
        model.ModifiedDate = $scope.ModifiedDate;
        var saveData = corporateOutstandingService.save(model);
        saveData.then(function (data) {

            if (data.Status) {
                msg(data.Message, true); //                $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                $scope.resetOutstanding();
                $scope.getRecent();
            }
        });
    };
    $scope.fillData = function (record) {

        $scope.CorporateOutstanding = record;
        $scope.CorporateOutstanding.TransactionType = record.TransactionType.toString();
        msg(''); //$window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
    };

});
