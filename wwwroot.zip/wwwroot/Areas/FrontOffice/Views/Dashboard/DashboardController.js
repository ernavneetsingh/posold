﻿
app.controller('DashboardController', [
    '$scope', '$filter', '$cookies', 'DashboardService', 'localStorageService', '$http', '$q','$rootScope', '$timeout', function (
        $scope, $filter, $cookies, service, localStorageService, $http, $q, $rootScope, $timeout) {

        initCommon($scope, $http, $q, localStorageService, $cookies);

        var businessDate = $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' + $scope.BusinessDate.Day;

        $scope.TotalPickUp = 0;
        $scope.TotalTentativeBooking = 0;
        $scope.TotalPreArrival = 0;

        $scope.GetTotalPickUp = function () {
            service.GetTotalPickUp($scope.PropertyID)
                .then(function (data, status) {
                    $scope.TotalPickUp = data.Data;
                });
        };
        $scope.GetTotalTentativeBooking = function () {
            service.GetTotalTentativeBooking($scope.PropertyID)
                .then(function (data, status) {
                    $scope.TotalTentativeBooking = data.Data;
                });
        };
        $scope.GetTotalPreArrival = function () {
            service.GetTotalPreArrival($scope.PropertyID)
                .then(function (data, status) {
                    $scope.TotalPreArrival = data.Data;
                });
        };
        $scope.GetTotalPickUp();
        $scope.GetTotalTentativeBooking();
        $scope.GetTotalPreArrival();

        $scope.GetAllReservation = function () {

            service.GetAllReservation($scope.PropertyID, $scope.ModifiedDate)
                .then(function (data, status) {
                    $scope.DashboardReservationList = data.Collection;
                });
        };
        $scope.GetAllCheckIn = function () {

            service.GetAllCheckIn($scope.PropertyID, $scope.ModifiedDate)
                .then(function (data, status) {
                    $scope.DashboardCheckInList = data.Collection;
                });
        };
        $scope.GetAllArrival = function () {

            service.GetAllArrival($scope.PropertyID, $scope.ModifiedDate)
                .then(function (data, status) {
                    $scope.DashboardArrivalList = data.Collection;
                    angular.forEach($scope.DashboardArrivalList, function (item) {
                        item.IsChecked = false;
                    });
                });
        };
        $scope.GetAllOccupancy = function () {

            service.GetAllOccupancy($scope.PropertyID, $scope.ModifiedDate)
                .then(function (data, status) {
                    $scope.DashboardOccupancyList = data.Collection;
                });
        };

        $scope.IsProgressPickUp = false;
        $scope.IsProgressTentativeBooking = false;
        $scope.IsProgressPreArrival = false;

        $scope.GetAllPickUp = function () {
            $scope.IsProgressPickUp = true;
            //$("TotalPickUpBox").modal('show');
            service.GetAllPickUp($scope.PropertyID)
                .then(function (data, status) {
                    $scope.PickUps = data.Collection;

                    angular.forEach($scope.PickUps, function (item) {
                        var times = item.OnTime.split(":");
                        item.OnTimeForDisplay = times[0] + ":" + times[1];

                        var locationTypeName = "";

                        var locationTypeId = item.LocationTypeId;
                        if (locationTypeId == "1")
                        {
                            locationTypeName = "Airport";
                        }
                        else if (locationTypeId == "2")
                        {
                            locationTypeName = "Bus Stand";
                        }
                        else if (locationTypeId == "3")
                        {
                            locationTypeName = "Railway Station";
                        }
                        else if (locationTypeId == "4")
                        {
                            locationTypeName = "Other";
                        }
                        item.LocationTypeName = locationTypeName;

                        var pickupDropTypeName = "";

                        var pickupDropTypeId = item.PickupDropType.toString();
                        if (pickupDropTypeId == "1") {
                            pickupDropTypeName = "Pick-UP";
                        }
                        else if (pickupDropTypeId == "2") {
                            pickupDropTypeName = "Drop";
                        }

                        item.PickupDropTypeName = pickupDropTypeName;

                    });

                    $scope.IsProgressPickUp = false;
                });
        };
        $scope.GetAllTentativeBooking = function () {
            $scope.IsProgressTentativeBooking = true;
            service.GetAllTentativeBooking($scope.PropertyID)
                .then(function (data, status) {
                    $scope.TentativeBookings = data.Collection;
                    $scope.IsProgressTentativeBooking = false;
                });
        };
        $scope.GetAllPreArrival = function () {
            $scope.IsProgressPreArrival = true;
            service.GetAllPreArrival($scope.PropertyID)
                .then(function (data, status) {
                    $scope.PreArrivals = data.Collection;
                    $scope.IsProgressPreArrival = false;
                });
        };


        $scope.GetAllReservation();
        $scope.GetAllCheckIn();
        $scope.GetAllArrival();
        $scope.GetAllOccupancy();

        $scope.$on("CallDashboardCheckIN", function (event, obj) {
            $scope.GetAllReservation();
            $scope.GetAllCheckIn();
            $scope.GetAllArrival();
            $scope.GetAllOccupancy();
        });

        //SMS
        $scope.IsActiveSMS = false;
        $scope.IsAllChecked = false;
        $scope.SetSMS = function () {
            $scope.IsActiveSMS = !$scope.IsActiveSMS;
            angular.forEach($scope.DashboardArrivalList, function (item) {
                if ($scope.IsActiveSMS) {
                    //item.IsActiveSMS = $scope.IsActiveSMS;
                    item.IsChecked = false;
                }
            });
        }

        $scope.SMSCancel = function () {
            $scope.IsActiveSMS = false;
            $scope.IsAllChecked = false;
            angular.forEach($scope.DashboardArrivalList, function (item) {
                if ($scope.IsActiveSMS) {
                    item.IsChecked = false;
                }
            });
        }
        $scope.SelectedExpectedArrivals = [];
        $scope.SMSSendNow = function () {
            
            $scope.SelectedExpectedArrivals = [];
            angular.forEach($scope.DashboardArrivalList, function (item) {
                if (item.IsChecked) {
                    $scope.SelectedExpectedArrivals.push({ Id: item.Id });
                }
            });
            var TempArrivalViewModel = {
                SelectedExpectedArrivals : $scope.SelectedExpectedArrivals,
            }

            var SMSModel = {
                SMSTemplateTypeId: 20,
                IsSMS: true,
                PropertyID: $scope.PropertyID,
                ModifiedBy: $scope.ModifiedBy,
                BusinessDate: $scope.BusinessDate.Year + '-' + $scope.BusinessDate.Month + '-' + $scope.BusinessDate.Day,
                Ids: $scope.SelectedExpectedArrivals,
            }


            $scope.IsSave = true;
            var promiseGet = service.SMSSendNow(SMSModel);
            promiseGet.then(function (data, status) {

                $scope.IsSave = false;
                $scope.SMSCancel();
                msg(data.Message, data.Status);
            },
            function (error, status) {
                $scope.IsSave = false;
                msg(error.Message);
            });
        }
        $scope.AllChecked = function () {
           
            angular.forEach($scope.DashboardArrivalList, function (item) {
                
                if ($scope.IsActiveSMS) {
                    item.IsChecked = $scope.IsAllChecked;
                }
            });

        }

        $scope.SendPickUpMail = function () {
            
            var reservationRoomTypeGuestId = '';
            angular.forEach($scope.PickUps, function (item) {
                //item.IsSending = false;
                if(item.IsSelected)
                {
                    item.Message = '';
                    item.IsSending = true;
                    reservationRoomTypeGuestId = item.ReservationRoomTypeGuestId;
                }
            });


            
            if (reservationRoomTypeGuestId)
            {
                service.SendMailPickupDrop(reservationRoomTypeGuestId)
                .then(function (data, status) {

                    angular.forEach($scope.PickUps, function (item) {

                        if (reservationRoomTypeGuestId == item.ReservationRoomTypeGuestId)
                        {
                            if (data.Message == 'True') {
                                item.Message = 'Sent';
                                item.IsSelected = false;
                            }
                            else {
                                item.Message = 'Failed';
                            }
                            item.IsSending = false;
                        }
                        
                    });

                    angular.forEach($scope.PickUps, function (item) {
                        if (item.IsSelected) {
                            $scope.SendPickUpMail();
                        }
                    });
                });
            }
            
        }

        $scope.SendMailTentativeBooking = function () {
            var id = '';
            angular.forEach($scope.TentativeBookings, function (item) {
                if (item.IsSelected) {
                    item.Message = '';
                    item.IsSending = true;
                    id = item.Id;
                }
            });

            if (id) {
                service.SendMailTentativeBooking(id, '23', $scope.PropertyID, businessDate)
                .then(function (data, status) {
                    angular.forEach($scope.TentativeBookings, function (item) {
                        if (id == item.Id) {
                            if (data.Message == 'True') {
                                item.Message = 'Sent';
                                item.IsSelected = false;
                            }
                            else {
                                item.Message = 'Failed';
                            }
                            item.IsSending = false;
                        }
                    });

                    angular.forEach($scope.TentativeBookings, function (item) {
                        if (item.IsSelected) {
                            $scope.SendMailTentativeBooking();
                        }
                    });
                });
            }

        }

    }
]);
