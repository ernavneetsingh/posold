﻿
app.service('CreditCardService', [
    '$http', '$q', function (
        $http, $q) {

        var scope;
        this.init = function ($scope) {
            scope = $scope;
            this.getNetworkList = function () {
                httpCaller(apiPath + "referencedata/CreditCardNetwork", $http, $q)
                    .then(function (s) {
                        scope.NetworkList = s.Collection;
                    });
            };
            this.getNetworkList();
            scope.pickCorporateForCard = function (form, model) {

                //model.CreditCardNetworkId = '';
                model.CreditCardNumber = model.CreditCardNumber || scope[form].ccNumber.$viewValue;
                if (isNaN(model.CreditCardNumber)) {
                    model.CreditCardNumber = parseInt(model.CreditCardNumber);
                    parent.posFailureMessage('Please enter digits only in credit card number.');
                    return;
                }
                if (!scope[form].ccNumber.$ccEagerType) {
                    model.CreditCardNumber = '';
                    //parent.posFailureMessage('Please enter correct start digits in credit card number.');
                    return;
                }
                var network = scope.NetworkList.find(x => x.Name.toLowerCase() === scope[form].ccNumber.$ccEagerType.toLowerCase());
                var ccIcon = $('#ccIcon');
                ccIcon.removeClass();
                if (!network) return;
                //model.CreditCardNetworkId = network.Id;
                ccIcon.addClass('fa fa-cc-' + network.Name.toLowerCase());
            };
        };

    }
]);

app.filter('validYesNo', function () {
    return function (boolean) {
        return boolean ? 'Valid' : 'Invalid';
    }
});
