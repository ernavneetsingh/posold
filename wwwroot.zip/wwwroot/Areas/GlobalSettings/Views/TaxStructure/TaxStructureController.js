﻿
'use strict';
app.controller('controller', ['$scope', '$filter', '$window', 'service', '$cookies', 'localStorageService', function ($scope, $filter, $window, service, $cookies, localStorageService) {

    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedBy = $cookies.get('UserName');

    $scope.LoginId = $cookies.get('LoginId');
    $scope.keys = localStorageService.get('ActionKeys');
    var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
    $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

    $scope.Modules = [];
    $scope.Outlets = [];
    $scope.TempVariable = [];
    $scope.Model = {

        Id: "",
        Code: "",
        Name: "",
        ModuleId: "",
        OutletId: "",
        IsSlab: false,
        IsTariffOn: false,
        IsActive: true,
        LinkTaxStructures: [],

        PropertyID: $scope.PropertyID,
    };

    $scope.LinkTaxStructures = [];
    $scope.TaxTypes = [];
    $scope.TaxOns = [];
    $scope.TaxOnTax = [];

    $scope.TaxOnTariffOn = [];
    $scope.TaxOnTariffOff = [];

    $scope.TaxOnList = [];

    $scope.linkTaxStructureForAdd = {
        TaxTypeId: '',
        MinRange: 0,
        MaxRange: 0,

        TaxInId: "2",
        TaxInName: "Percent",

        TaxValue: 0,
        TaxOnId: ''
    };

    $scope.structureListModel = [];
    $scope.TaxOnDetail = [];

    $scope.ShowErrorMessage = false;


    getModule();
    getOutlet();

    //page setting
    $scope.MsgNotFound = "";
    $scope.sortingOrder = "Name";
    $scope.pageSizes = [5, 10, 25, 50];
    $scope.reverse = false;
    $scope.filteredItems = [];
    $scope.groupedItems = [];
    $scope.itemsPerPage = 10;
    $scope.pagedItems = [];
    $scope.currentPage = 0;
    $scope.items = [];
    var searchMatch = function (haystack, needle) {
        if (!needle) {
            return true;
        }
        return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
    };

    // init the filtered items
    $scope.search = function () {

        $scope.filteredItems = $filter("filter")($scope.items, function (item) {
            for (var attr in item) {
                if (attr === "Name" || attr === "ModuleName") {

                    var dd = item[attr];
                    if (dd == null || dd == 'undefined' || dd == '') {
                    } else {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
            }
            return false;
        });

        // take care of the sorting order
        if ($scope.sortingOrder !== "") {
            $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
        }
        $scope.currentPage = 0;
        // now group by pages
        $scope.groupToPages();
    };

    // show items per page
    $scope.perPage = function () {
        $scope.groupToPages();
    };

    // calculate page in place
    $scope.groupToPages = function () {
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage == 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }
        if ($scope.pagedItems.length == 0) {
            $scope.MsgNotFound = "Record Not Found.";
            $scope.pagedItems.length = 1;
        } else {
            $scope.MsgNotFound = "";
        }
    };
    $scope.range = function (start, end) {
        var ret = [];
        if (!end) {
            end = start;
            start = 0;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }
        return ret;
    };
    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };
    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        }
    };
    $scope.firstPage = function () {
        $scope.currentPage = 0;
    }
    $scope.lastPage = function () {
        $scope.currentPage = $scope.pagedItems.length - 1;
    }
    $scope.setPage = function () {
        $scope.currentPage = this.n;
    };
    // change sorting order
    $scope.sort_by = function (newSortingOrder) {
        if ($scope.sortingOrder == newSortingOrder)
            $scope.reverse = !$scope.reverse;

        $scope.sortingOrder = newSortingOrder;
    };

    $scope.OnTariffDisable = true;
    $scope.HeaderDisable = false;

    $scope.DisableTariff = function () {

        $scope.Model.IsTariffOn = false;

        $scope.BindTariff();

        if ($scope.Model.ModuleId === "1") {
            $scope.OnTariffDisable = false;
        } else {
            $scope.OnTariffDisable = true;
            $scope.Model.IsTariffOn = false;
        }
        if ($scope.Model.ModuleId === "3") {
            $scope.IsVisible = true;
        } else {
            $scope.IsVisible = false;
            $scope.Model.OutletId = "";

        }
    };

    function getModule() {
        var promiseGet = service.getModule();
        promiseGet.then(function (modules) {
            $scope.Modules = modules;
        }
        );
    };

    function getOutlet() {

        var promiseGet = service.GetOutlet($scope.PropertyID);
        promiseGet.then(function (data) {

            $scope.Outlets = data;
        },
            function (data) {

                parent.failureMessage(data.message);
            });
    }

    $scope.TaxOn = {
        Id: '',
        Name: ''
    };

    getTaxOn();
    function getTaxOn() {

        var promiseGet = service.getGetAllTaxType();
        promiseGet.then(function (data) {
            $scope.TaxTypes = data.Collection;
        },
            function (data) {

                parent.failureMessage(data.message);

            });

        var promiseGet1 = service.getAllTaxOn();
        promiseGet1.then(function (data) {

            $scope.TaxOns = data;

            $scope.TaxOnTariffOn = [];
            angular.forEach($scope.TaxOns, function (item) {
                if (item.IsTariffOn) {
                    $scope.TaxOnTariffOn.push({
                        Id: item.Id,
                        Name: item.TaxOnName
                    })
                }
            });

            $scope.TaxOnTariffOff = [];
            angular.forEach($scope.TaxOns, function (item) {
                if (!item.IsTariffOn) {
                    $scope.TaxOnTariffOff.push({
                        Id: item.Id,
                        Name: item.TaxOnName
                    })
                }
            });

            $scope.TaxOnList = angular.copy($scope.TaxOnTariffOff);

        },
            function (data) {
                parent.failureMessage(data.message);
            });


        var promiseGet2 = service.getAllTaxOnTax();
        promiseGet2.then(function (data) {

            $scope.TaxOnTax = data;
        },
            function (data) {
                parent.failureMessage(data.message);
            });





        var i;
        if ($scope.Model.IsTariffOn == true) {
            var count = 0;
            if ($scope.TaxOns != undefined) {
                for (i = 0; i < $scope.TaxOns.length; i++) {
                    if (count < 3) {
                        $scope.TaxOns.splice(0, 1);
                    }
                    count++;
                }
            }
        } else {
            if ($scope.TaxOns != undefined) {
                i = 0;
                for (i = 0; i < $scope.TaxOns.length; i++) {
                    if (i > 2) {
                        $scope.TaxOns.splice(i);
                    }
                }
            }
        }
    }
    function getTaxStructure() {
        var taxstructure = service.getTaxTypeList();
        taxstructure.then(function (taxType) {

            $scope.TaxTypes = taxType.Data.taxType;
            $scope.TaxOns = taxType.Data.taxOn;

            var i;
            if ($scope.Model.IsTariffOn == true) {
                var count = 0;
                if ($scope.TaxOns != undefined) {
                    for (i = 0; i < $scope.TaxOns.length; i++) {
                        if (count < 3) {
                            $scope.TaxOns.splice(0, 1);
                        }
                        count++;
                    }
                }
            } else {
                if ($scope.TaxOns != undefined) {
                    i = 0;
                    for (i = 0; i < $scope.TaxOns.length; i++) {
                        if (i > 2) {
                            $scope.TaxOns.splice(i);
                        }
                    }
                }
            }

        },
            function (errorPl) {
                parent.failureMessage('Some Error in Getting Records.', errorPl);
            });
    }

    $scope.gettaxonClass = function (taxclass) {
        var taxes = taxclass;//.split("-");
        if (parseInt(taxes) > 6) {
            return taxclass ? "" : "blue";
        } else {
            return taxclass;
        }

    };

    $scope.BindTariff = function () {

        $scope.TaxOnList = [];

        if ($scope.Model.IsTariffOn == true) {

            $scope.TaxOnList = angular.copy($scope.TaxOnTariffOn);
        }
        else {
            $scope.TaxOnList = angular.copy($scope.TaxOnTariffOff);
        }

    }

    $scope.addItem = function (form) {

        if ($scope[form].$valid) {

            //$scope.HeaderDisable = true;
            var selectedTaxTypeName = "";
            var selectedTaxOnName = "";

            if ($scope.Model.IsSlab) {
                if (parseFloat($scope.linkTaxStructureForAdd.MinRange) > parseFloat($scope.linkTaxStructureForAdd.MaxRange)) {
                    scrollPageOnTop();
                    parent.failureMessage("Min value should not be greater than max value.");
                    return;
                }

            }

            if (parseFloat($scope.linkTaxStructureForAdd.TaxValue) > 0) {
                if ($scope.linkTaxStructureForAdd.TaxInId == "2") {
                    if (parseFloat($scope.linkTaxStructureForAdd.TaxValue) > 100) {
                        scrollPageOnTop();
                        parent.failureMessage("Tax % should not be more than 100%.");
                        return;
                    }
                }
            }
            else {
                scrollPageOnTop();
                parent.failureMessage("Tax value should not be 0.");
                return;
            }



            if ($scope.Model.IsSlab) {
                var isOverlapped = false;
                angular.forEach($scope.LinkTaxStructures, function (item, index) {
                    if (item.TaxTypeId == $scope.linkTaxStructureForAdd.TaxTypeId) {
                        if (parseFloat($scope.linkTaxStructureForAdd.MinRange) >= parseFloat(item.MinRange)) {
                            if (parseFloat($scope.linkTaxStructureForAdd.MinRange) <= parseFloat(item.MaxRange)) {
                                isOverlapped = true;
                            }
                        }
                    }
                });

                if (isOverlapped) {
                    parent.failureMessage("Overlapping min and max range.");
                    //parent.failureMessage("Invalid min and max range.");
                    scrollPageOnTop();
                    return;
                }
            }


            //

            //angular.forEach($scope.TaxOns, function (item) {

            //    if (item.Id == $scope.linkTaxStructureForAdd.TaxOnId) {
            //        selectedTaxOnName = item.TaxOnName;
            //        item.Selected = false;
            //    }
            //    if (item.TaxOnName == selectedTaxTypeName) {
            //        isExists = true;
            //    }

            //});

            //if (isExists == false) {

            //}

            ////TODO : navneet not clear
            //if (isExists == false) {
            //    var isBool = false;

            //    if ($scope.TaxOnDetail.length > 0) {
            //        for (var c = 0; c < $scope.TaxOnDetail.length; c++) {
            //            if ($scope.TaxOnDetail[c].Id == $scope.SelectedtaxType) {
            //                for (var t = 0; t < $scope.taxOntypeModel.length; t++) {
            //                    if ($scope.taxOntypeModel[t].Id == $scope.TaxOnDetail[c].Id) {
            //                        isBool = true;
            //                    };
            //                }
            //                if (isBool == false) {
            //                    $scope.taxOntypeModel.push({
            //                        Id: $scope.TaxOnDetail[c].Id,
            //                        TaxOnName: $scope.TaxOnDetail[c].TaxOnName,
            //                        Selected: $scope.TaxOnDetail[c].Selected
            //                    });
            //                }
            //            }
            //        }
            //    }
            //}

            var isExists = false;
            angular.forEach($scope.TaxTypes, function (item) {
                if (item.Id == $scope.linkTaxStructureForAdd.TaxTypeId) {
                    item.Selected = false;
                    selectedTaxTypeName = item.Name;
                }
            });

            angular.forEach($scope.TaxOnList, function (item) {
                if (item.Id == $scope.linkTaxStructureForAdd.TaxOnId) {
                    selectedTaxOnName = item.Name;
                    item.Selected = false;
                }
                if (item.Name == selectedTaxTypeName) {
                    isExists = true;
                }
            });


            if (isExists == false) {

                angular.forEach($scope.TaxOnTax, function (item) {
                    if (item.TaxOnName == selectedTaxTypeName) {
                        $scope.TaxOnList.push({
                            Id: item.Id,
                            Name: item.TaxOnName
                        });
                    }
                });
            }

            $scope.LinkTaxStructures.push({
                Id: "",
                TaxTypeId: $scope.linkTaxStructureForAdd.TaxTypeId,
                TaxTypeName: selectedTaxTypeName,
                MinRange: $scope.linkTaxStructureForAdd.MinRange,
                MaxRange: $scope.linkTaxStructureForAdd.MaxRange,
                TaxInId: $scope.linkTaxStructureForAdd.TaxInId,
                TaxInName: $scope.linkTaxStructureForAdd.TaxInName,
                TaxValue: $scope.linkTaxStructureForAdd.TaxValue,
                TaxOnId: $scope.linkTaxStructureForAdd.TaxOnId,
                TaxOnName: selectedTaxOnName
            });


            $scope.linkTaxStructureForAdd = {
                TaxTypeId: '',
                MinRange: 0,
                MaxRange: 0,
                TaxInId: "2",
                TaxInName: "Percent",

                TaxValue: 0,
                TaxOnId: ''
            };




        } else {
            $scope.ShowErrorMessage = true;
            scrollPageOnTop();
        }
    };

    function getTaxOnDetail() {
        var promiseGet = service.getTaxonList();
        promiseGet.then(function (ontax) {

            $scope.TaxOnDetail = ontax;

        });
    };
    $scope.ActionMode = "";
    $scope.Edit = function (model) {
        $scope.ActionMode = "Edit";
        $scope.HeaderDisable = true;
        $scope.Model = angular.copy(model);
        $scope.Model.ModuleId = $scope.Model.ModuleId.toString();

        $scope.Model.ApplicableFrom = $filter("date")($scope.Model.ApplicableFrom, $scope.DateFormat);
        if ($scope.Model.ModuleId == "3") {
            $scope.IsVisible = true;
        } else {
            $scope.IsVisible = false;
            $scope.Model.OutletId = "";
        }

        $scope.TaxOnList = [];
        if ($scope.Model.IsTariffOn == true) {

            $scope.TaxOnList = angular.copy($scope.TaxOnTariffOn);
        }
        else {
            $scope.TaxOnList = angular.copy($scope.TaxOnTariffOff);
        }

        var isExists = false;
        angular.forEach(model.LinkTaxStructures, function (item1) {

            angular.forEach($scope.TaxOnList, function (item) {
                if (item1.TaxTypeName == item.TaxOnName) {
                    isExists = true;
                }
            });
            if (isExists == false) {
                angular.forEach($scope.TaxOnTax, function (item) {
                    if (item.TaxOnName == item1.TaxTypeName) {
                        $scope.TaxOnList.push({
                            Id: item.Id,
                            Name: item.TaxOnName
                        });
                    }
                });
            }

            isExists = false;
        });

        $scope.LinkTaxStructures = [];
        $scope.LinkTaxStructures = model.LinkTaxStructures;
        scrollPageOnTop();


        //$scope.taxTypeModel = [];
        //$scope.taxOntypeModel = [];
        ////$scope.taxTypeModel = taxType.Data.taxType;
        ////$scope.taxOntypeModel = taxType.Data.taxOn;
        //var gettaxdata = service.getTaxTypeList();
        //gettaxdata.then(function (taxType) {

        //    $scope.taxTypeModel = taxType.Data.taxType;
        //    $scope.taxOntypeModel = taxType.Data.taxOn;
        //    var i;
        //    if ($scope.Model.IsTariffOn == true) {
        //        var count = 0;
        //        for (i = 0; i < $scope.taxOntypeModel.length; i++) {
        //            if (count < 3) {
        //                $scope.taxOntypeModel.splice(0, 1);
        //            }
        //            count++;
        //        }
        //    } else {
        //        for (i = 0; i < $scope.taxOntypeModel.length; i++) {
        //            if (i > 2) {
        //                $scope.taxOntypeModel.splice(i);
        //            }
        //        }
        //    }

        //    for (var z = 0; z < $scope.Model.LinkTaxStructures.length; z++) {

        //        if ($scope.Model.LinkTaxStructures[z].TaxIn.trim() == "Amount") {
        //            $scope.Model.LinkTaxStructures[z].TaxIn = false;
        //        } else {
        //            $scope.Model.LinkTaxStructures[z].TaxIn = true;
        //        }
        //        $scope.isCheckData = false;

        //        var selectedTaxTypeId = $scope.Model.LinkTaxStructures[z].TaxTypeId;
        //        //check tax type id
        //        for (var s = 0; s < $scope.TaxOnDetail.length; s++) {
        //            if ($scope.TaxOnDetail[s].TaxTypeId === selectedTaxTypeId) {
        //                for (var j = 0; j < $scope.taxOntypeModel.length; j++) {
        //                    if ($scope.taxOntypeModel[j].Id === $scope.TaxOnDetail[s].Id) {
        //                        $scope.isCheckData = true;
        //                    }
        //                }
        //                if ($scope.isCheckData === false) {
        //                    $scope.taxOntypeModel.push({
        //                        Id: $scope.TaxOnDetail[s].Id,
        //                        Name: $scope.TaxOnDetail[s].TaxOnName,
        //                        Selected: $scope.TaxOnDetail[s].Selected
        //                    });
        //                }
        //            }
        //        }
        //    }

        //    for (var p = 0; p < $scope.Model.LinkTaxStructures.length; p++) {
        //        var selectedtaxOnIdd = $scope.Model.LinkTaxStructures[p].TaxOnId;
        //        var selectedtaxTypeIdd = $scope.Model.LinkTaxStructures[p].TaxTypeId;
        //        for (var l = 0; l < $scope.taxOntypeModel.length; l++) {
        //            if ($scope.taxOntypeModel[l].Id == selectedtaxOnIdd) {
        //                $scope.Model.LinkTaxStructures[p].TaxOnName = $scope.taxOntypeModel[l].TaxOnName;
        //                break;
        //            }
        //        }

        //        i = 0;
        //        for (i = 0; i < $scope.taxTypeModel.length; i++) {
        //            if ($scope.taxTypeModel[i].Id == selectedtaxTypeIdd) {
        //                $scope.Model.LinkTaxStructures[p].TaxTypeName = $scope.taxTypeModel[i].Name;
        //                break;
        //            }
        //        }
        //    }
        //});

        //$window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
    }
    $scope.Save = function (form) {

        if ($scope[form].$valid) {

            if ($scope.Model.ModuleId == 3) {
                if ($scope.Model.OutletId == '' || $scope.Model.OutletId == undefined) {
                    parent.failureMessage("Please select Outlet.");
                    scrollPageOnTop();
                    return;
                }
            }

            if ($scope.LinkTaxStructures.length == 0) {
                parent.failureMessage("Add at least on Link Tax Structure.");
                scrollPageOnTop();
                return;
            }
            else if ($scope.Model.IsSlab && $scope.Model.IsSlab === true) {
                var countMaxZero = 0;
                $scope.LinkTaxStructures.forEach(function (l) {
                    if (l.MaxRange <= 0) countMaxZero++;
                });
                if (countMaxZero > 0) {
                    parent.failureMessage("Link Tax Structure max range should be greater than 0.");
                    scrollPageOnTop();
                    return;
                }
            }

        } else {
            $scope.ShowErrorMessage = true;
            scrollPageOnTop();
            return;
        }

        $scope.Model.LinkTaxStructures = [];
        $scope.Model.LinkTaxStructures = $scope.LinkTaxStructures;

        $scope.Model.ApplicableFrom = GetServerDate($scope.Model.ApplicableFrom, $scope.DateFormat);
        $scope.Model.ModifiedBy = $scope.ModifiedBy;
        $scope.Model.PropertyID = $scope.PropertyID;

        var status = service.save($scope.Model);
        status.then(function (result) {

            if (result.Status === true) {
                parent.successMessage($scope.Model.Name + ' ' + result.Message);
                scrollPageOnTop();
                $scope.Reset();
                getData();
                $scope.IsVisible = false;
            }
        },
        function (error, status) {
            $scope.Model.ApplicableFrom = GetLocalDate($scope.Model.ApplicableFrom, $scope.DateFormat);
            parent.failureMessage(error.Message);
        });
        scrollPageOnTop();
    }
    $scope.RemoveItem = function (index) {
        $scope.LinkTaxStructures.splice(index, 1);
    }

    $scope.ChangeStatus = function (model) {
        if (!$scope.keys.IsEdit) {
            parent.failureMessage("Unauthorized Access !!!");
            scrollPageOnTop();
            return false;
        }
        $scope.Model.Id = model.Id;
        $scope.Model.PropertyID = $scope.PropertyID;
        $scope.Model.ModifiedBy = $scope.ModifiedBy;

        var promiseGet = service.changeStatus($scope.Model);
        promiseGet.then(function (data, status) {
            if (data.Status) {
                $scope.Reset();
                scrollPageOnTop();
                parent.successMessage("Status changed successfully.");
                getData();
            }
        },
        function (error, status) {
            $scope.Reset();
            parent.failureMessage(error.Message);
        });
        scrollPageOnTop();
    };

    function Reset() {
        $scope.ActionMode = "";
        $scope.HeaderDisable = false;
        $scope.Model = { IsActive: true, };
        $scope.LinkTaxStructures = [];
        $scope.query = '';
        $scope.search();
        scrollPageOnTop();
    }
    $scope.Reset = function () {
        Reset();
    }

    getData();
    function getData() {
        $scope.ActionMode = "";
        var promiseGet = service.getData($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.items = data;
            $scope.search();
        },
           function (data) {
               msg(data.message);
           });

    };

}
]);