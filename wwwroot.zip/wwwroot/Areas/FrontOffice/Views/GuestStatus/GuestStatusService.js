﻿
(function () {
    function guestStatusService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var linkModule = [];

        var getGuestStatus = function (options) {

            var url = apiPath + "FrontOffice/GuestStatus/GetAll?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        //function getGuestStatusData(blockId, propertyId) {

        //    var deferred = $q.defer();
        //    $http({
        //        method: "GET",
        //        url: apiPath + "FrontOffice/GuestStatus/GetAllByGuestStatusId/" + blockId + "/" + propertyId,
        //        data: {},
        //        headers: { 'duxtechApiKey': accessToken },
        //        contentType: "application/json; charset=utf-8"
        //    }).success(function (data, status, headers, cfg) {
        //        deferred.resolve(data);
        //    }).error(function (err, status) {
        //        deferred.reject(status);
        //    });
        //    return deferred.promise;
        //};

        function isExist(code, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/GuestStatus/IsExist/" + code + "/" + propertyId,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function save(model) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/GuestStatus/Save",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function changeStatus(model) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/GuestStatus/ChangeStatus",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function remove(id) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/GuestStatus/Remove/" + id,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                msg(err.Message);
                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        var service = {
            dataAllData: linkModule,
            getGuestStatus: getGuestStatus,
            isExist: isExist,
            save: save,
            //getGuestStatusData: getGuestStatusData,
            changeStatus: changeStatus,
            remove: remove,
        };
        return service;
    }

    app.factory("GuestStatusService", ["$http", "$q", guestStatusService]);
})();
