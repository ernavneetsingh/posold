﻿

(function () {
    function guestClassTaxExemptionService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var linkModule = [];

        var getGuestClassTaxExemption = function (options) {
            
            var url = apiPath + "FrontOffice/GuestClassTaxExempt/details?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getGuestClassTaxExemptionData(taxexemptionId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/GuestClassTaxExempt/details/" + taxexemptionId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getGuestClassExemptionData() {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "referencedata/GuestClass",
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getTaxTypeData() {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "configuration/TaxType/GetAllTaxType",
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function save(model) {
            
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/GuestClassTaxExempt/create",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                
                deferred.resolve(data);
            }).error(function (err, status) {
                
                deferred.reject(err);
            });
            return deferred.promise;
        };

        function changeStaus(model) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/GuestClassTaxExempt/update",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function deleteGuestClassTaxExemption(taxexemptionId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/GuestClassTaxExempt/delete/" + taxexemptionId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var service = {
            dataAllData: linkModule,
            getTaxTypeData: getTaxTypeData,
            getGuestClassExemptionData: getGuestClassExemptionData,
            getGuestClassTaxExemption: getGuestClassTaxExemption,
            save: save,
            getGuestClassTaxExemptionData: getGuestClassTaxExemptionData,
            changeStaus: changeStaus,
            deleteGuestClassTaxExemption: deleteGuestClassTaxExemption
        };
        return service;
    }

    app.factory("GuestClassTaxExemptionService", ["$http", "$q", guestClassTaxExemptionService]);
})();
