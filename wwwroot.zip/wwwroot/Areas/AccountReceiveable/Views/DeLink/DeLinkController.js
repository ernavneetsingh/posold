﻿
app.controller('DeLinkController', function ($scope, $filter, $window, $cookies, transactionService, deLinkService, localStorageService) {

    //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    //$scope.ModifiedBy = $cookies.get('UserName');
    //$scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

    $('.readonly').find('input, textarea, select').attr('readonly', 'readonly');
    $scope.resetSearch = function () {
        $scope.Search = {};
    }
    $scope.resetHistory = function () { }
    $scope.resetCompany = function () {
        $scope.Company = {};
    }
    $scope.resetDeLinker = function () {
        $scope.TaggedTransactions = [];
        $scope.TaggedTransaction = {};
    }
    $scope.resetLinkedBills = function () {
        $scope.LinkedBills = [];
    }
    $scope.resetLinker = function () {
        $scope.UnTaggedTransactions = [];
    }
    $scope.resetPendingBills = function () {
        $scope.UnTaggedBills = [];
    }
    $scope.resetAll = function () {
        $scope.resetSearch();
        $scope.resetHistory();
        $scope.resetCompany();
        $scope.resetDeLinker();
        $scope.resetLinkedBills();
        $scope.resetLinker();
        $scope.resetPendingBills();
    }
    $scope.resetAll();

    $scope.link = function () {

        if ($scope.Company === undefined || $scope.Company.Id === undefined || $scope.Company.Id === null) {
            msg('Please select company');
            return;
        }
        if ($scope.currentTransaction === undefined || $scope.currentTransaction.Id === undefined) {
            msg('Please select a transaction to link');
            return;
        }
        var model = $scope.currentTransaction;
        model.PropertyID = $scope.PropertyID;
        model.ModifiedBy = $scope.ModifiedBy;
        model.ModifiedDate = $scope.ModifiedDate;

        var billno = [];
        var billAmt = [];
        angular.forEach($scope.PendingBills, function (key) {
            if (key.IsSelectedInInvoice && key.Settled > 0) {
                billno.push(key.Id);
                billAmt.push(key.Settled);
            }
        });
        if (billno.length < 1) {
            msg('Error! Please select some bills to link');
            return;
        }

        billno = JSON.stringify(billno);
        billAmt = JSON.stringify(billAmt);

        var saveData = deLinkService.link(model.Id, $scope.ModifiedBy, billno, billAmt, $scope.ModifiedDate);
        saveData.then(function (data) {

            if (data.Status) {
                msg(data.Message, true);
                $scope.getRecent();
            }
        });
    };
    $scope.dLink = function () {

        if ($scope.Company === undefined || $scope.Company.Id === undefined || $scope.Company.Id === null) {
            msg('Please select company');
            return;
        }
        if ($scope.TaggedTransaction === undefined || $scope.TaggedTransaction.Id === undefined) {
            msg('Please select a transaction to de-link');
            return;
        }

        var tDate = formatDMYDate($scope.TaggedTransaction.TransactionDateString);
        var minDate = new Date($scope.MinDate);
        if (tDate.getTime() < minDate.getTime()) {
            msg('This Transaction cannot be delinked because period is closed.');
            return;
        }

        var billno = '';
        angular.forEach($scope.LinkedBills, function (key) {

            if (key.IsSelectedInInvoice) {
                if (billno === '') {
                    billno = key.Id;
                }
                else {
                    billno = billno + '~' + key.Id;
                }
            }
        });
        if (billno.length < 1) {
            msg('Error! Please select some bills to delink');
            return;
        }

        var saveData = deLinkService.dLink($scope.TaggedTransaction.Id, $scope.ModifiedBy, billno, $scope.ModifiedDate);
        saveData.then(function (data) {

            if (data.Status) {
                parent.successMessage(data.Message);
                $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                $scope.getRecent();
            }
        });
    };

    $scope.getAutoSuggest = function (item, txt) {
        var promiseSuggest = transactionService.suggest($scope.PropertyID, item, txt);
        promiseSuggest.then(function (data, status) {
            $('#txtSearch' + item).autocomplete({
                source: function (request, response) {
                    response($.map(data.Data.Suggestions, function (ret) {
                        return {
                            label: ret,
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {
                    if (ui.item) {
                        if (txt !== 'Bank') {
                            var promiseSearch = transactionService.search($scope.PropertyID, item, ui.item.val, $scope.DateFormat);
                            promiseSearch.then(function (data, status) {

                                $scope.load(data, item);
                            });
                            //} else {
                            //    Get_BankDetail(ui.item.value, txt);
                        }
                    }
                },
                minLength: 1
            });
        });
    };
    $scope.getRecent = function () {
        $scope.resetLinkedBills();
        var promise = transactionService.search($scope.PropertyID, 'CorporateId', $scope.Company.Id, $scope.DateFormat);
        promise.then(function (data, status) {

            $scope.load(data, 'any');
        });
    };
    $scope.load = function (data, searchType) {
        if (searchType && searchType !== 'CompanyType') {
            $scope.Company = data.Data;
            $scope.TaggedTransactions = data.Data.TaggedTransactions;
            $scope.UnTaggedTransactions = data.Data.UnTaggedTransactions;
            $scope.PendingBills = data.Data.UnTaggedBills;
        }
        $scope.History = data.Data.History;
    };

    $scope.checkTT = function (item) {

        var selected = item.IsSelectedInInvoice;
        angular.forEach($scope.TaggedTransactions, function (key) {
            key.IsSelectedInInvoice = false;
        });
        item.IsSelectedInInvoice = selected;
        $scope.selectAllT = false;
        $scope.fillData(item);
    };
    $scope.checkAllT = function (selected) {

        angular.forEach($scope.LinkedBills, function (key) {
            key.IsSelectedInInvoice = selected;
        });
    };

    $scope.settleTransaction = function (item) {

        var selected = item.IsSelectedInInvoice;
        angular.forEach($scope.UnTaggedTransactions, function (key) {
            key.IsSelectedInInvoice = false;
        });
        $scope.checkAll(false);
        item.IsSelectedInInvoice = selected;

        $scope.UnmatchedAmount = item.UnmatchedAmount;
        $scope.currentTransaction = item.IsSelectedInInvoice ? item : {};
        $scope.UnmatchedAmountCheck();
    };
    $scope.checkAll = function (selected) {

        angular.forEach($scope.PendingBills, function (key) {
            key.IsSelectedInInvoice = selected;
            key.RemainingBalanceNow = key.RemainingBalance - key.Settled;
            $scope.settleBills(key);
        });
    };
    $scope.settleBills = function (bill) {

        var checked = bill.IsSelectedInInvoice;
        bill.Settled = checked ? $scope.RemainingBalanceNow : 0;
        $scope.settleAmountChange(bill);
        if ($scope.currentTransaction) {
            bill.CommissionTypeId = $scope.currentTransaction.CommissionTypeId;
            bill.CommissionApplied = $scope.currentTransaction.CommissionApplied;
            bill.CommissionAmount = decimalValD(parseFloat(bill.Settled) * bill.CommissionApplied * 0.01);

            bill.TdsTypeId = $scope.currentTransaction.TdsTypeId;
            bill.TdsValue = $scope.currentTransaction.TdsValue;
            bill.TdsAmount = decimalValD(parseFloat(bill.Settled) * bill.TdsValue * 0.01);
        }
    };
    $scope.settleAmountChange = function (bill) {

        if (bill.Settled > bill.RemainingBalance) bill.Settled = bill.RemainingBalance;
        bill.RemainingBalanceNow = bill.RemainingBalance - parseFloat(bill.Settled);
        bill.RemainingBalanceNow = isNaN(bill.RemainingBalanceNow) ? bill.RemainingBalance : bill.RemainingBalanceNow;
        $scope.UnmatchedAmountCheck();
    };
    $scope.UnmatchedAmountCheck = function () {
        $scope.RemainingBalanceNow = $scope.currentTransaction ? $scope.currentTransaction.UnmatchedAmount : 0;
        var countChecked = 0;
        angular.forEach($scope.PendingBills, function (key) {

            if (key.IsSelectedInInvoice) {
                $scope.RemainingBalanceNow -= key.Settled;
                if ($scope.RemainingBalanceNow < 0) {
                    key.Settled -= $scope.RemainingBalanceNow;
                    $scope.RemainingBalanceNow = 0;
                }
                countChecked++;
            }
        });
        if (countChecked === 0) $scope.selectAll = false;
    }

    $scope.fillData = function (record) {
        $scope.TaggedTransaction = record;
        var promise = deLinkService.getLinkedBills($scope.PropertyID, record.Id, $scope.DateFormat);
        promise.then(function (data, status) {
            $scope.LinkedBills = data.Data.LinkedBills;
        });
    };

    $scope.unCheck = function () {
        var countChecked = 0;
        angular.forEach($scope.LinkedBills, function (key) {

            if (key.IsSelectedInInvoice) {
                countChecked++;
            }
        });
        if (countChecked === 0) $scope.selectAllT = false;
    }

});
