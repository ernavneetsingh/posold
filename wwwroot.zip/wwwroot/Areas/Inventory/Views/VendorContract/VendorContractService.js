﻿
app.service('VendorContractService', ['$http', '$q', function ($http, $q) {

    this.getAllCategory = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/ItemCategory/all", $http, $q, { propertyId: propertyId });
    };
    this.getCategoryVendors = function (propertyId, itemCategoryId) {
        return httpCaller(apiPath + "Inventory/VendorContract/GetCategoryVendors", $http, $q, { propertyId: propertyId, itemCategoryId: itemCategoryId });
    };
    this.getCategoryItemContracts = function (propertyId, itemCategoryId, date) {
        return httpCaller(apiPath + "Inventory/VendorContract/GetCategoryItemContracts", $http, $q, { propertyId: propertyId, itemCategoryId: itemCategoryId, date: date });
    };

    this.save = function (model) {
        return httpPoster(apiPath + "Inventory/VendorContract/Save", $http, $q, model);
    };

}]);
