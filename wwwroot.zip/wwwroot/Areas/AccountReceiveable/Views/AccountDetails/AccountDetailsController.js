﻿
app.controller("AccountDetailsController", function ($scope, $http, $filter, $window, $cookies, transactionService, accountDetailsService, localStorageService) {

    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    $scope.HeaderAging = [];

    $scope.resetSearch = function () {
        $scope.Search = {};
    }
    $scope.resetHistory = function () {
        $scope.History = [];
    }
    $scope.resetCompany = function () {
        $scope.Company = {};
    }
    $scope.resetDebit = function () {
        $scope.Debit = [];
        $scope.DebitTotal = 0;
    }
    $scope.resetCredit = function () {
        $scope.Credits = [];
        $scope.Credit = [];
        $scope.CreditTotal = 0;
    }
    $scope.resetAdjustment = function () {
        $scope.AdjustmentsAll = [];
        $scope.Adjustments = [];
        $scope.AdjustmentTotal = 0;
    }
    $scope.resetAging = function () {
        $scope.Aging = [];
        $scope.AgingBills = [];
    }
    $scope.resetAll = function () {
        $scope.resetSearch();
        $scope.resetHistory();
        $scope.resetCompany();
        $scope.resetDebit();
        $scope.resetCredit();
        $scope.resetAdjustment();
        $scope.resetAging();
    }
    $scope.resetAll();

    $scope.getAutoSuggest = function (item, txt) {
        var promiseSuggest = transactionService.suggest($scope.PropertyID, item, txt);
        promiseSuggest.then(function (data, status) {
            $("#txtSearch" + item).autocomplete({
                source: function (request, response) {
                    response($.map(data.Data.Suggestions, function (ret) {
                        return {
                            label: ret,
                            val: ret.split(':')[0]
                        }
                    }));
                },
                select: function (e, ui) {

                    if (ui.item) {
                        var promiseSearch = transactionService.search($scope.PropertyID, item, ui.item.val, $scope.DateFormat);
                        promiseSearch.then(function (datas, status) {
                            $scope.load(datas);
                        });
                    }
                },
                minLength: 1
            });
        });
    }
    function agingHeader() {

        var promise = accountDetailsService.agingHeader($scope.PropertyID, $scope.Company.Id, $scope.ModifiedDate);
        promise.then(function (data) {

            $scope.Aging = data.Collection;
        });

    };
    $scope.load = function (data) {
        $scope.Company = data.Data;
        $scope.History = data.Data.History;
        $scope.DebitTotal = 0;
        $scope.CreditTotal = 0;

        angular.forEach(data.Data.Transactions, function (key) {

            if (key.TransactionTypeId === "Debit") {
                $scope.Debit.push(key);
                $scope.DebitTotal += key.Amount;
            } else {
                $scope.Credit.push(key);
                $scope.CreditTotal += key.Amount;
            }
        });

        $scope.Debits = $scope.Debit;
        $scope.Credits = $scope.Credit;

        $scope.Adjustments = data.Data.Adjustments;
        $scope.AdjustmentsAll = $scope.Adjustments;
        angular.forEach($scope.Adjustments, function (key) {

            $scope.AdjustmentTotal += key.Amount;
        });

        agingHeader();

    };
    $scope.showAgingBills = function (item) {

        $scope.AgingBills = item.Bills;
        $('#openModalMy').fadeIn('fast');//$('#openModalInvoice').fadeIn('fast');//window.location.assign('#openModalInvoice');

    };
    $scope.getRecentDebit = function (count) {

        $scope.Debit = $scope.Debits.slice(0, count);
    };
    $scope.getRecentCredit = function (count) {

        $scope.Credit = $scope.Credits.slice(0, count);
    };
    $scope.getAdjustments = function (count) {

        $scope.Adjustments = $scope.AdjustmentsAll.slice(0, count);
    };

    $("#close").click(function () {
        $('#openModalMy').hide('slow');//$('#openModalInvoice').hide('slow');
    });

});
