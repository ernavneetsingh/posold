﻿
app.service('IndentService', ['$http', '$q', '$filter', function ($http, $q, $filter) {

    this.getReasons = function (propertyId, moduleId) {
        return httpCaller(apiPath + "GlobalSetting/Reason/all", $http, $q, { propertyId: propertyId, moduleId: moduleId, active: 1 });
    };
    this.getCostCenters = function (propertyId) {
        return httpCaller(apiPath + "GlobalSetting/CostCenter/all", $http, $q, { propertyId: propertyId, active: 1 });
    };

    this.getItemSearch = function (searchTxt, propertyId) {

        $("#searchItem")
            .autocomplete({
                source: function (request, response) {

                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: apiPath + 'Inventory/InventoryItem/AllBySearchTxt?searchTxt=' + searchTxt + "&propertyId=" + propertyId,
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.Name,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {

                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();

                            scope.$apply(function () {
                                var promiseGet = getSearchitemsDetails(ui.item.val, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.InventoryItem = data.Data;
                                    if ((scope.InventoryItem != null) && scope.InventoryItem != '') {

                                        scope.IndentItem = {};
                                        scope.IndentItem.Id = '';
                                        scope.IndentItem.IndentId = '';
                                        //scope.IndentItem.StoreId = scope.InventoryItem.StoreId;
                                        //scope.IndentItem.StoreName = scope.InventoryItem.StoreName;
                                        scope.IndentItem.CostCenterId = '';
                                        scope.IndentItem.CostCenterName = '';
                                        scope.IndentItem.InventoryItemId = scope.InventoryItem.Id;
                                        scope.IndentItem.InventoryItemName = scope.InventoryItem.Name;
                                        scope.IndentItem.InventoryItemCode = scope.InventoryItem.Code;
                                        //$scope.IndentItem.ItemType: '',
                                        scope.IndentItem.ItemTypeId = scope.InventoryItem.ItemTypeId;
                                        scope.IndentItem.ItemTypeName = scope.InventoryItem.ItemTypeName;
                                        scope.IndentItem.BrandId = '';
                                        scope.IndentItem.BrandName = '';
                                        scope.IndentItem.UnitOfMeasurementId = scope.InventoryItem.UnitOfMeasurementId;
                                        scope.IndentItem.UnitOfMeasurementName = scope.InventoryItem.UnitOfMeasurementName;
                                        scope.IndentItem.Rate = scope.InventoryItem.Rate;
                                        scope.IndentItem.Quantity = 1;
                                        //$scope.IndentItem.QuantityReceived: '',
                                        scope.IndentItem.RequiredDate = scope.ModifiedDate;// scope.SelectedDeliveryDate;

                                        //scope.IndentItem.CostCenters = scope.InventoryItem.CostCenters;
                                        scope.IndentItem.ForDisplayBrands = scope.InventoryItem.Brands;

                                        if (scope.IndentItem.ForDisplayBrands.length == 1) {
                                            scope.IndentItem.BrandId = scope.IndentItem.ForDisplayBrands[0].Id;
                                            scope.getDuplicateItem(scope.IndentItem);
                                        }

                                        //scope.IndentItem.ForDisplayCostCenters = scope.InventoryItem.ForDisplayCostCenters;
                                        //if (scope.IndentItem.ForDisplayCostCenters.length == 1) {
                                        //    scope.IndentItem.CostCenterId = scope.IndentItem.ForDisplayCostCenters[0].Id;
                                        //}

                                        scope.IndentItem.PropertyID = scope.PropertyID;
                                        scope.IndentItem.ModifiedBy = scope.ModifiedBy;
                                        scope.IndentItem.DateFormat = scope.DateFormat;

                                        scope.model.IndentItems.push(scope.IndentItem);

                                    }

                                    scope.Search = "";
                                },
                                    function (error, status) {

                                        parent.failureMessage(error.Message);
                                    });
                            });
                        }
                    }
                },
                minLength: 1
            });
    };
    function getSearchitemsDetails(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "Inventory/InventoryItem/GetItemById?propertyId=" + propertyId + "&id=" + itemId,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getAll = function (propertyId, statusTypeId, searchText, searchType) {
        return httpCaller(apiPath + "Inventory/Indent/all/", $http, $q, { propertyId: propertyId, statusTypeId: statusTypeId, searchText: searchText, searchType: searchType });
    };
    this.save = function (model) {
        var params = { model: model };
        return httpPoster(apiPath + "Inventory/Indent/Save", $http, $q, model);
    };

    this.getIndentSearch = function (poStatusTypeId, searchTxt, propertyId) {

        $("#searchIndent")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/Indent/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.IndentNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {
                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            if (ui.item.value === "No Records Found") {
                                ui.item.value = "";
                            } else {
                                var promiseGet = getIndentDetails(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.model = data.Data;
                                    scope.model.IndentItems.forEach(function (item) {
                                        scope.getDuplicateItem(item);

                                    });
                                }, function (error, status) {
                                    msg(error.Message);
                                });
                            }
                        });

                    }
                },
                minLength: 1
            });
    };
    function getIndentDetails(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + 'Inventory/Indent/exist/' + itemId + "/" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getIndentSearchMO = function (poStatusTypeId, searchTxt, propertyId, control) {

        $("#modifiedIndentDetails")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/Indent/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.IndentNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        //if (ui.item.value !== "No Records Found") {
                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            if (ui.item.value === "No Records Found") {
                                ui.item.value = "";
                            }
                            else {
                                var promiseGet = getIndentDetailsMO(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.model = data.Data;
                                    scope.model.IndentItems.forEach(function (item) {
                                        scope.getDuplicateItem(item);
                                    });

                                }, function (error, status) {

                                    parent.failureMessage(error.Message);
                                });
                            }
                        });
                        //}
                    }
                },
                minLength: 1
            });

    };
    function getIndentDetailsMO(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + 'Inventory/Indent/exist/' + itemId + "/" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getItemSearch1 = function (searchTxt, propertyId) {
        $("#search_item-mo")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: apiPath + 'Inventory/InventoryItem/AllBySearchTxt?searchTxt=' + searchTxt + "&propertyId=" + propertyId,
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.Name,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();
                            scope.$apply(function () {
                                var promiseGet = getSearchitemsDetails1(ui.item.val, propertyId);
                                promiseGet.then(function (data, status) {

                                    scope.InventoryItem = data.Data;
                                    if ((scope.InventoryItem != null) && scope.InventoryItem != '') {

                                        scope.IndentItem = {};
                                        scope.IndentItem.Id = '';
                                        scope.IndentItem.IndentId = '';
                                        scope.IndentItem.StoreId = scope.InventoryItem.StoreId;
                                        scope.IndentItem.StoreName = scope.InventoryItem.StoreName;
                                        scope.IndentItem.InventoryItemId = scope.InventoryItem.Id;
                                        scope.IndentItem.InventoryItemName = scope.InventoryItem.Name;
                                        scope.IndentItem.InventoryItemCode = scope.InventoryItem.Code;
                                        scope.IndentItem.ItemTypeId = scope.InventoryItem.ItemTypeId;
                                        scope.IndentItem.ItemTypeName = scope.InventoryItem.ItemTypeName;
                                        scope.IndentItem.BrandId = '';
                                        scope.IndentItem.BrandName = '';
                                        scope.IndentItem.UnitOfMeasurementId = scope.InventoryItem.UnitOfMeasurementId;
                                        scope.IndentItem.UnitOfMeasurementName = scope.InventoryItem.UnitOfMeasurementName;
                                        scope.IndentItem.Rate = scope.InventoryItem.Rate;
                                        scope.IndentItem.Quantity = 1;
                                        scope.IndentItem.RequiredDate = '';
                                        scope.IndentItem.ForDisplayBrands = scope.InventoryItem.Brands;
                                        scope.IndentItem.PropertyID = scope.PropertyID;
                                        scope.IndentItem.ModifiedBy = scope.ModifiedBy;
                                        if (scope.IndentItem.ForDisplayBrands.length == 1) {
                                            scope.IndentItem.BrandId = scope.IndentItem.ForDisplayBrands[0].Id;
                                            scope.getDuplicateItem(scope.IndentItem);
                                        }
                                        scope.model.IndentItems.push(scope.IndentItem);

                                    }

                                    scope.Search1 = "";

                                }, function (error, status) {

                                    parent.failureMessage(error.Message);
                                });
                            });
                        }
                    }
                },
                minLength: 1
            });

    };
    function getSearchitemsDetails1(itemId, propertyId) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "Inventory/InventoryItem/GetItemById?propertyId=" + propertyId + "&id=" + itemId,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.getIndentSearchCancel = function (poStatusTypeId, searchTxt, propertyId) {

        $("#cancelIndentDetails")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/Indent/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.IndentNumber = '';
                        scope.model = {};
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.IndentNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {

                    if (ui.item) {
                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            if (ui.item.value === "No Records Found") {
                                ui.item.value = '';
                                scope.IndentNumber = '';
                            }
                            else {
                                var promiseGet = getIndentDetailsCancel(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {
                                    scope.model = data.Data;
                                }, function (error, status) {

                                    parent.failureMessage(error.Message);
                                });
                            }
                        });
                    }
                },
                minLength: 1
            });

    };
    function getIndentDetailsCancel(itemId, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + 'Inventory/Indent/exist/' + itemId + "/" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.cancelIndent = function (model) {

        var deferred = $q.defer();
        var url = apiPath + 'Inventory/Indent/SaveCancel';
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    this.getIndentSearchClose = function (poStatusTypeId, searchTxt, propertyId) {

        $("#closeIndentDetails")
            .autocomplete({
                source: function (request, response) {

                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/Indent/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {

                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.IndentNumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {

                    if (ui.item) {

                        //if (ui.item.value !== "No Record Found!") {
                        var element = angular.element($("#divMain"));
                        var scope = element.scope();
                        scope.$apply(function () {
                            if (ui.item.value === "No Records Found") {
                                ui.item.value = "";
                            }
                            else {
                                var promiseGet = getIndentDetailsClose(ui.item.value, propertyId);
                                promiseGet.then(function (data, status) {

                                    //var ReceiveItems = [];
                                    scope.model = data.Data;

                                }, function (error, status) {

                                    parent.failureMessage(error.Message);
                                });
                            }
                        });
                        //}
                    }
                },
                minLength: 1
            });
    };
    function getIndentDetailsClose(poid, propertyId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: (apiPath + "Inventory/Indent/GetPendingPoItems?poId=" + poid + "&propertyId=" + propertyId),
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };
    this.closeIndent = function (model) {

        var deferred = $q.defer();
        var url = apiPath + 'Inventory/Indent/SaveClose';
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    this.getIndentSearchAuthorized = function (poStatusTypeId, searchTxt, propertyId) {

        $("#authorization_search_po")
            .autocomplete({
                source: function (request, response) {
                    var deferred = $q.defer();
                    $http({
                        method: "GET",
                        url: (apiPath + 'Inventory/Indent/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                        data: {},
                        headers: { 'duxtechApiKey': accessToken },
                        contentType: "application/json; charset=utf-8"
                    }).success(function (data, status, headers, cfg) {
                        deferred.resolve(data);
                        if (data.Collection.length > 0) {
                            response($.map(data.Collection,
                                function (item) {
                                    return {
                                        label: item.PONumber,
                                        val: item.Id
                                    };
                                }));
                        } else {
                            response([{ label: "No Records Found", val: -1 }]);
                        }
                    }).error(function (err, status) {

                        deferred.reject(err, status);
                    });
                    return deferred.promise;

                },
                select: function (e, ui) {
                    if (ui.item) {

                        if (ui.item.value !== "No Record Found!") {
                            var element = angular.element($("#divMain"));
                            var scope = element.scope();
                            scope.$apply(function () {

                                scope.Indents = [];

                                var promiseGet = getIndentDetailsAuthorized(ui.item.value, propertyId);

                                promiseGet.then(function (data, status) {

                                    //angular.forEach(data.Data.IndentItems, function (val) {
                                    //    val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);;
                                    //    val.DiscountInId = val.DiscountInId.toString();
                                    //});

                                    scope.model = data.Data;
                                    //scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                    scope.Indents.push(scope.model);

                                },
                                    function (error, status) {

                                        parent.failureMessage(error.Message);
                                    });
                            });
                        }
                    }
                },
                minLength: 1
            });
        //});
    };
    this.getUnauthorizedList = function (propertyId) {
        var url = apiPath + "Inventory/Indent/GetAllNotApproved/" + propertyId;
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result.Collection);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;

    };
    this.saveAuthorization = function (Indents) {

        var deferred = $q.defer();
        var url = apiPath + 'Inventory/Indent/SaveAuthorization';
        $http({
            dataType: 'json',
            method: 'POST',
            url: url,
            data: JSON.stringify(Indents),
            headers: {
                "duxtechApiKey": accessToken,
                "Content-Type": "application/json"
            }
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    this.getItemStock = function (propertyId, itemId, brandId, date) {
        var params = { propertyId: propertyId, date: date, itemId: itemId, brandId: brandId };
        return httpCaller(apiPath + "Inventory/InventoryTransactionItem/Stock", $http, $q, params);
    };
    //this.getItemAverageConsumption = function (propertyId, itemId, brandId, date) {
    //    var params = { propertyId: propertyId, date: date, itemId: itemId, brandId: brandId };
    //    return httpCaller(apiPath + "Inventory/InventoryTransactionItem/Stock", $http, $q, params);
    //};

    this.MapReport = function (filterValue, reportName) {
        return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
    };

}]);
