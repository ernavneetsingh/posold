﻿

(function () {
    function roomFeatureService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var linkModule = [];

        var getRoomFeature = function (options) {

            var url = apiPath + "FrontOffice/roomfeatures/details?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getRoomFeatureData(featureId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roomfeatures/details/" + featureId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getCodeExistRoomFeature(featureCode, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/roomfeatures/exist/" + featureCode + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function saveRoomFeature(roomFeatureModel) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/roomfeatures/create",
                data: roomFeatureModel,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function updateIsActiveRoomFeature(featureId, isActive, propertyId, userName) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/roomfeatures/update?featureId=" + featureId + "&isActive=" + isActive + "&propertyId=" + propertyId + "&userName=" + userName,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function deleteRoomFeature(featureId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/roomfeatures/delete/" + featureId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var service = {
            dataAllData: linkModule,
            getRoomFeature: getRoomFeature,
            getCodeExistRoomFeature: getCodeExistRoomFeature,
            saveRoomFeature: saveRoomFeature,
            getRoomFeatureData: getRoomFeatureData,
            updateIsActiveRoomFeature: updateIsActiveRoomFeature,
            deleteRoomFeature: deleteRoomFeature
        };
        return service;
    }

    app.factory("RoomFeatureService", ["$http", "$q", roomFeatureService]);
})();
