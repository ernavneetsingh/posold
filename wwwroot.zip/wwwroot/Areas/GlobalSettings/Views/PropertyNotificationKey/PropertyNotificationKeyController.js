﻿
app.controller('controller', function ($scope, $filter, $cookies, $window, service, localStorageService) {

    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
    $scope.ModifiedBy = $cookies.get('UserName');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    $scope.LoginId = $cookies.get('LoginId');
    $scope.keys=localStorageService.get('ActionKeys');
    $scope.ShowErrorMessage = false;

    //GetAllNotificationKey();

    $scope.Save = function (form) {
        
        $scope.Model={};
        $scope.Model.PropertyID = $scope.PropertyID;
        $scope.Model.ModifiedBy = $scope.ModifiedBy;
        $scope.Model.ModifiedDate = $scope.ModifiedDate;
        $scope.Model.PropertyNotificationKeys = $scope.NotificationKeys;

        var promiseGet = service.save($scope.Model);

        promiseGet.then(function (data) {
            GetAllNotificationKey();
            parent.successMessage("Notification Keys " +data.Message);
        },
        function (data) {

            parent.failureMessage(data.Message);
        });
        scrollPageOnTop();
    };

    $scope.Reset = function () {
        GetAllNotificationKey();
    };

    function GetAllNotificationKey() {
        var promiseGet = service.getNotificationKeys($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.NotificationKeys = data;
            angular.forEach($scope.NotificationKeys, function (item) {
                
                item.AllRoles = $scope.Roles;
                //item.SelectedRoles=[];
                //angular.forEach(item.Roles, function (role) {
                //    item.SelectedRoles.push(role);
                //});
            });

        },
        function (data) {
            parent.failureMessage(data.Message);
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        });
    }

    $scope.RoleListSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };
    $scope.Roles = [];
    
    GetAllRole();
    function GetAllRole() {
        
        var promiseGet = service.getAllRole($scope.PropertyID);
        promiseGet.then(function (data) {
            $scope.Roles = data.filter(x=>x.IsActive);
            GetAllNotificationKey();
        },
            function (data) {
                parent.failureMessage(data.message);
            });
    }
});
