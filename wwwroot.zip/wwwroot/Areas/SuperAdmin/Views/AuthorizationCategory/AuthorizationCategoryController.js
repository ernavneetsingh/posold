﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.Model = {
            Id: '',
            ModuleId: '',
            ModuleName: '',
            Name: '',
            items: []
        };

        $scope.IsReadonly = false;
        //------------------------------------------------
        ////page configuration parameter
        //------------------------------------------------
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        //------------------------------------------------

        //------------------------------------------------
        //page configuration start
        //------------------------------------------------
        // init the filtered items
        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "Name"||attr==="ModuleName") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };

        // show items per page
        $scope.perPage = function () {
            $scope.groupToPages();
        };

        // calculate page in place
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };

        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };

        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };

        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };

        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }

        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }

        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };

        // change sorting order
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };
        //------------------------------------------------
        //page configuration end
        //------------------------------------------------


        getData();

        function getData() {
            
            var promiseGet = service.getData();
            promiseGet.then(function (data) {
                
                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   parent.failureMessage(data.message);
               });

        };

        $scope.Modules = [];
        GetAllModels();
        function GetAllModels() {
            
            var promiseGet = service.getAllModules();
            promiseGet.then(function (data) {
                
                $scope.Modules = data;
            },
            function (data) {
                parent.failureMessage(data.Message);
            });
        }

        $scope.Save = function (model, form) {
            
            if (model.Name === "") {
                parent.successMessage("Please Select Name");
            }
            else {
                if ($scope[form].$valid) {
                    var status = service.save(model);

                    status.then(function (result) {
                        
                        if (result.Status == true) {
                            var msg = model.Name + result.Message;
                            parent.successMessage(msg);
                            getData();
                        }

                        $scope.Reset();

                    },
                    function (error) {
                        
                        scrollPageOnTop();
                        parent.failureMessage(error.Message);
                    });

                } else {
                    $scope.ShowErrorMessage = true;
                }
            }
           
        }

        $scope.Remove = function (model) {
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            

                            parent.successMessage("Record Successfully deleted.");

                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }

        $scope.Edit = function (model) {
            
            $scope.Model.Id = model.Id;
            $scope.Model.Name = model.Name;
            $scope.Model.ModuleId = model.ModuleId.toString();
            $scope.IsReadonly = true;

            $scope.Model.IsActive = model.IsActive;
            scrollPageOnTop();
        }

        $scope.Reset = function () {
            $scope.Model = {};
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            getData();
            scrollPageOnTop();
        }

    }
]);
