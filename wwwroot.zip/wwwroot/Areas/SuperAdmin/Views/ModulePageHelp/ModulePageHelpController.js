﻿
app.controller("controller", [
    "$scope", "ModulePageHelpService", "localStorageService", function (
        $scope, service, localStorageService) {

        var sortKeyOrder = {
            key: "",
            order: "",
        };
        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;

        getData($scope, service, localStorageService);

        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        };
        $scope.EditModule = function (item) {
            angular.forEach($scope.Modules, function (value, key) {
                if (value.Id == item.ModuleId) {
                    $scope.selectedModelModule = $scope.Modules[key];
                    $scope.ModuleChange($scope.selectedModelModule);
                }
            })
            angular.forEach($scope.selectedModelModule.SubModules, function (value, key) {
                if (value.Id == item.SubModuleId) {
                    $scope.selectedModelSubModule = $scope.SubModules[key];
                    $scope.SubModuleChange($scope.selectedModelModule, $scope.selectedModelSubModule, item);
                }
            })
            //angular.forEach($scope.SubModulePages, function (value, key) {
            //    if (value.Id == item.Id) {
            //        $scope.selectedModelPage = $scope.SubModulePages[key];
            //    }
            //})
            scrollPageOnTop();
        };
        $scope.Reset = function () {
            $scope.Model = { IsActive: true, OrderSNo: 0, HelpTags: [] };
            clearForm();
            $scope.searchfor = "";
            $scope.search();
            scrollPageOnTop();
            $scope.Tag= '';
        };
        $scope.ShowErrorMessage = false;
        $scope.Save = function (model, form) {

            if ($scope[form].$valid) {
                model.ModuleId = $scope.selectedModelModule.Id;
                model.SubModuleId = $scope.selectedModelSubModule.Id;
                model.ModulePageId = $scope.selectedModelPage.Id;

                if (model.PageContent && model.PageContent.length > 0) model.PageContent = model.PageContent.replace(apiPath, 'apiPath');

                service.save(model).then(function (data, status) {
                    getData($scope, service, localStorageService);
                    msg(data.Message, true);
                    //$scope.Reset();
                    $scope.changePage($scope.selectedModelPage);
                },
               function (data, status, headers, config) {
                   parent.failureMessage(data.Message);
               });
            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        function clearForm() {

            $scope.Imagename = "";
            $scope.Description = "";

            angular.forEach(angular.element("input[type='file']"),
                function (inputElem) {
                    angular.element(inputElem).val(null);
                });

        };

        $scope.IsNameExist = function (model) {
            var promiseGet = service.isNameExist(model);
            promiseGet.then(function (data) {
            },
                function (error) {
                    $scope.Model.Name = "";
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });
        };
        $scope.IsOrderSNoExist = function (model) {

            model.ModuleId = $scope.selectedModelModule.Id;
            var promiseGet = service.isOrderSNoExist(model);
            promiseGet.then(function (data) {
            },
                function (error) {
                    $scope.Model.OrderSNo = "";
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });
        };
        $scope.IsUrlExist = function (model) {

            var promiseGet = service.isUrlExist(model);
            promiseGet.then(function (data) {
            },
                function (error) {
                    $scope.Model.Url = "";
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });
        };
        $scope.ChangeStatus = function (id) {

            var promiseGet = service.changeStatus(id);
            promiseGet.then(function (data) {
                parent.successMessage(data.Message);
                $scope.changePage($scope.selectedModelPage);
                scrollPageOnTop();
            }, function (error) {

                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
        };

        $scope.Modules = [];
        GetAllModels();
        function GetAllModels() {

            var promiseGet = service.getAllModules();
            promiseGet.then(function (data) {

                $scope.Modules = data;
            },
            function (data) {

                parent.failureMessage(data.Message);
            });
        }

        $scope.ModuleChange = function (selectedModelModule) {

            $scope.SubModules = [];

            if (selectedModelModule != null) {

                $scope.SubModules = selectedModelModule.SubModules;
            }
        };
        $scope.SubModuleChange = function (selectedModelModule, selectedModelSubModule, item) {
            $scope.SubModulePages = [];
            if (!selectedModelModule || !selectedModelSubModule) return;
            service.getAllPageByModuleId(selectedModelModule.Id, selectedModelSubModule.Id)
                .then(function (s) {
                    $scope.SubModulePages = s;
                    if (item)
                        angular.forEach($scope.SubModulePages, function (value, key) {
                            if (value.Id == item.Id) {
                                $scope.selectedModelPage = $scope.SubModulePages[key];
                                $scope.changePage($scope.selectedModelPage);
                            }
                        });
                }, function (e) {
                    msg(e.Message);
                });

        };
        $scope.changePage = function (selectedModelPage) {
            if (!selectedModelPage) return;
            $scope.Reset();
            service.getAllByPageIdActive(selectedModelPage.Id)
                .then(function (s) {
                    $scope.pages = s.Collection;
                    if ($scope.Model && s.Collection && s.Collection.length > 0) $scope.Model.Url = s.Collection[0].Url;
                });

        };
        $scope.Edit = function (item) {

            $scope.Model = item;

            angular.forEach($scope.Modules, function (value, key) {

                if (value.Id == item.ModuleId) {
                    $scope.selectedModelModule = $scope.Modules[key];
                    $scope.ModuleChange($scope.selectedModelModule);
                }
            })

            angular.forEach($scope.selectedModelModule.SubModules, function (value, key) {
                if (value.Id == item.SubModuleId) {
                    $scope.selectedModelSubModule = $scope.SubModules[key];
                }
            })

            scrollPageOnTop();
            //not tested
            if ($scope.Model.PageContent && $scope.Model.PageContent.length > 0)
            {
                while(model.PageContent.indexOf('apiPath')>-1)
                    $scope.Model.PageContent = model.PageContent.replace('apiPath',apiPath);
            }
        };
        $scope.delete = function (model) {
            //var strDelete = DeletePopup("Are you sure to delete " + model.Title);
            //var ret;
            //$.fancybox({
            //    'modal': true,
            //    'content': strDelete,
            //    'afterShow': function () {
            //        $("#fancyconfirm_cancel").click(function () {
            //            ret = false;
            //            $.fancybox.close();
            //        });
            //        $("#fancyConfirm_ok").click(function () {
            //            ret = true;
            service.remove(model.Id)
                .then(function (s) {

                    msg("Record Successfully deleted.", true);
                    $scope.Reset();
                });
            //            $.fancybox.close();
            //        });
            //    }
            //});
        };

        $scope.addTag = function (t) {
            if(!$scope.Model.Title) return;
            if (!$scope.Model.HelpTags) $scope.Model.HelpTags = [];
            var found = $scope.Model.HelpTags.find(x=>x.Name==t);
            if(found) return;
            $scope.Model.HelpTags.push({Name:t});
        };
        $scope.deleteTag = function (t) {
            if(!t || !$scope.Model.HelpTags) return;
            $scope.Model.HelpTags = $scope.Model.HelpTags.filter(x=>x.Name!=t.Name);
        };
        $scope.changeTag = function (t) {
            if(!t) return;
            service.searchTag(t).then(function(s){

                $('#Tag').autocomplete({
                    source: function (request, response) {
                        response($.map(s.Collection, function (ret) {

                            if (!ret) return;
                            return {
                                label: ret.Name,
                                val: ret//.split(':')[0]
                            }
                        }));
                    },
                    minLength: 1,
                    //messages: {
                    //    noResults: '',
                    //    results: function () { }
                    //}
                });
            });
                     
        };
       
        $scope.Reset();
    }
]);

var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "OrderSNo",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getAll(options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};
