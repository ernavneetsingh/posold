﻿
app.controller("InventoryMapController",
[
    "$scope", "InventoryMapService", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');

        $scope.IsShowUnMapped = false;
        $scope.myPageConfig = {
            valueField: "Name",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: true,
            maxItems: 1
        };

        $scope.Stores = [];
        $scope.getStore = function () {
            service.getStore($scope.PropertyID)
                .then(function (data, status) {
                    $scope.Stores = data.Collection;
                });
        };
        $scope.getStore();

        $scope.Model = {};
        $scope.Model.ItemCategorys = [];
        $scope.Model.TaxTypes = [];
        $scope.Model.Vendors = [];
        $scope.Model.CostCenters = [];
        $scope.Model.AddOnCharges = [];

        $scope.getInventoryMap = function () {
            //$scope.Model = {};
            $scope.Model.ItemCategorys = [];
            $scope.Model.TaxTypes = [];
            $scope.Model.Vendors = [];
            $scope.Model.CostCenters = [];
            $scope.Model.AddOnCharges = [];
            service.getInventoryMap($scope.Model.StoreId)
            .then(function (data, status) {
                $scope.Model = data.Data;
            });
        };

        $scope.AccountDumps = [];
        $scope.getAccountDump = function () {
            $scope.AccountDumps = [];
            service.getAccountDump($scope.PropertyID)
                .then(function (data, status) {
                    $scope.AccountDumps = data.Collection;
                });
        };
        $scope.getAccountDump();
        
        $scope.SetIsShow = function () {
            angular.forEach($scope.Model.ItemCategorys, function (item) {
                if ($scope.IsShowUnMapped)
                {
                    if(!item.AccountName || !item.AllowanceAccountName)
                    {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else
                    {
                        item.IsShow = false;
                    }
                }
                else
                {
                    item.IsShow = true;
                }
            })
            angular.forEach($scope.Model.TaxTypes, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.Vendors, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }
            })
            angular.forEach($scope.Model.CostCenters, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.AddOnCharges, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
        }

        $scope.Save = function () {
            if (!$scope.Model.StoreId)
            {
                msg('Please Select Store.');
                return;
            }
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            service.save($scope.Model)
                .then(function (result) {
                    if (result.Status == true) {
                        msg(result.Message, true);
                    }
                    $scope.SetIsShow();
                    $scope.Reset();
                }, function (error) {
                    msg(error.Message);
                });
        }

        $scope.Reset = function () {
            $scope.Model = {};
        }
    }
]);
