﻿
app.controller("InventoryIssueController", [
    "$scope", "$http", "$filter", "$cookies", "$window", "inventoryTransactionService", 'localStorageService',
    function ($scope, $http, $filter, $cookies, $window, service, localStorageService) {

        $scope.itemdiscount = [
             { DiscountId: "Amount", DiscountName: "Amount" },
             { DiscountId: "Percent", DiscountName: "Percent" }
        ];
        $scope.IssueDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat);
        $scope.ItemBrandDetails = [];
        $scope.ItemDetailsMaster = [];
        $scope.stockIndex = 0;
        $scope.itemConfig = {
            valueField: "InventoryItemId",
            labelField: "InventoryItemName",
            searchField: ["InventoryItemName"],
            sortField: "InventoryItemName",
            create: false,
            maxItems: 1
        }
        $scope.brandConfig = {
            valueField: "BrandId",
            labelField: "BrandName",
            searchField: ["BrandName"],
            sortField: "BrandName",
            create: false,
            maxItems: 1
        }
        $scope.TaxStructure = [];
        $scope.invoice = [];
        $scope.itemcostcentre = [];
        $scope.ItemBrands = [];

        function taxStructureData() {
            var promise = service.getTaxStructures($scope.PropertyID, 1, 5);
            promise.then(function (data, status) {

                $scope.TaxStructure = data.Collection;
            });
        }
        function getBrand() {
            var promise = service.getBrands($scope.PropertyID, 1);
            promise.then(function (data, status) {

                $scope.ItemBrands = data.Collection;
            });
        };
        function getitemcostcentre() {
            var promise = service.getCostCenters($scope.PropertyID);
            promise.then(function (data, status) {
                $scope.itemcostcentre = data.Collection;
            });

        };
        $scope.getOpeningDate = function () {

            var promise = service.getAll($scope.PropertyID, $scope.DateFormat, 6);
            promise.then(function (data) {
                if (data.Collection.length < 1) return;
                $scope.MinDate = dateAdd(data.Collection[0].TransactionDateString, 'day', -1, $filter);

            });
        }

        $scope.getOpeningDate();
        taxStructureData();
        getBrand();
        getitemcostcentre();

        $scope.itemTransc = [];
        $scope.items = [];
        $scope.StockDetails = [];
        function GetIssueReceiptDetails() {
            var promise = service.getAll($scope.PropertyID, $scope.DateFormat, 34);
            promise.then(function (data) {

                $scope.items = data.Collection;
                $scope.search();
            });
        }
        $scope.BindItemData = function (date) {
            $scope.reset();
            $scope.model.TransactionDateString = date;
            var promise = service.getAllItemStock($scope.PropertyID, date);
            promise.then(function (data) {

                $scope.StockDetails = data.Collection;
                $scope.ItemDetailsMaster = data.Collection;
            });
        }

        GetIssueReceiptDetails();

        $scope.ClearSelectedItem = function ($event) {
            $scope.ItemMaster = "";
            $scope.ItemBrand = "";
            $scope.qtys = 000;
        }
        $scope.ItemMasterChange = function () {

            var r=false;
            $scope.ItemBrand = "";
            $scope.qtys = 000;
            $scope.ItemBrandDetails = [];
            for (var g = 0; g < $scope.StockDetails.length; g++) {
                if ($scope.StockDetails[g].InventoryItemId === $scope.ItemMaster) {
                    r=true;
                    $scope.ItemBrandDetails.push($scope.StockDetails[g]);
                }
            }
            if(!r) {
                $scope.ItemMaster='';
                $scope.IsIndentIssue=false;
            }
            return r;
        }
        $scope.ItemBrandChange = function () {

            $scope.qtys = 000;
            $scope.stockIndex = -1;
            for (var g = 0; g < $scope.StockDetails.length; g++) {
                if ($scope.StockDetails[g].InventoryItemId === $scope.ItemMaster && $scope.StockDetails[g].BrandId === $scope.ItemBrand) {
                    $scope.qtys = $scope.StockDetails[g].Quantity;
                    $scope.stockIndex = g;
                    break;
                }
            }
            $scope.qtyso= $scope.qtys;
        }
        $scope.ItemQuantityChange = function () {
             
            if ($scope.stockIndex < 0) {
                msg("Sorry! item not in stock ");
                return false;
            }
            var original = $scope.StockDetails[$scope.stockIndex].Quantity;
            var current = $scope.qtys;
            var items = $scope.ItemMaster;
            var brands = $scope.ItemBrand;
            var costcenter = $scope.CostCentreIds;
            if (current > original) {
                var curItemName = $scope.StockDetails[$scope.stockIndex].InventoryItemName;
                var curBrandName = $scope.StockDetails[$scope.stockIndex].BrandName;
                msg('Entered quantity should not be greater than ' + original+' for '+curItemName+' brand '+curBrandName);
                $scope.IsIndentIssue=false;
                $scope.qtys = 0;
                if ($scope.invoice.length > 0) {
                    for (var k = 0; k < $scope.invoice.length; k++) {
                        var invitems = $scope.invoice[k].InventoryItemId;
                        var invbrands = $scope.invoice[k].BrandId;                     
                        if (invitems === items && invbrands === brands) {
                            $scope.invoice.splice(k, 1);
                            k--;
                        }
                    }
                }
                return false;
            }
            var found = false;
            if ($scope.invoice.length > 0) {
                for (var k = 0; k < $scope.invoice.length; k++) {
                    var invitems = $scope.invoice[k].InventoryItemId;
                    var invbrands = $scope.invoice[k].BrandId;                      
                    if (invitems === items && invbrands === brands) {
                        $scope.invoice.splice(k, 1);
                        k--;
                        found = true;
                    }
                }
            }

            if ($scope.qtys > 0) {
                if (angular.isUndefined($scope.CostCentreIds)) {
                    msg("Please Select Cost Center");
                } else {
                    $scope.btnItemClick();
                }
            } else {

                var item = $scope.ItemMaster;
                var brand = $scope.ItemBrand;
                var costcenter = $scope.CostCentreIds;

                if ($scope.invoice.length > 0) {
                    //for (var i = 0; i < $scope.invoice.length; i++) {
                    //    var invitem = $scope.invoice[i].ItemId;
                    //    var invbrand = $scope.invoice[i].BrandId;
                    //    var invcostcenter = $scope.invoice[k].CostCentre;

                    //    if (invitems === items && invbrands === brands && invcostcenter === costcenter) {
                    //        $scope.invoice.splice(i, 1);
                    //        i--;
                    //    }
                    //}
                } else {
                    $scope.invoice = [];
                }
            }
            return true;
        }
        $scope.ItemInvoiceDetail = [];
        $scope.sum = function (items, prop) {

            return items.reduce(function (a, b) {
                return a + b[prop];
            }, 0);
        };

        $scope.btnItemClick = function () {

            var promise = service.getItemsToIssue($scope.PropertyID, $scope.ItemMaster, $scope.ItemBrand, $scope.qtys);
            promise.then(function (data, status) {

                var qty = 0;
                angular.forEach(data.Collection, function (item) {
                    qty += item.Quantity;
                    $scope.invoice.push(item);
                });
                if (qty < $scope.qtys) msg('Quantity remaining in stock is only ' + qty);

                $scope.data = data;
                var sum = 0;

                var itemdetails = $scope.data.Collection;

                angular.forEach($scope.invoice, function (item) {

                    if (item.DiscountIn === "Amount") {
                        item.Discount = $filter('number')(((parseFloat(item.Discount) / parseFloat(item.Quantity)) * parseFloat(item.Quantityremaining)), 2).replace(/,/g, '');
                    }

                    for (var n = 0; n < $scope.invoice.length; n++) {
                        $scope.invoice[n].Amount = $filter('number')(($scope.invoice[n].Rate * $scope.invoice[n].Quantity), 2).replace(/,/g, '');
                        for (var q = 0; q < $scope.TaxStructure.length; q++) {
                            if ($scope.TaxStructure[q].Id === $scope.invoice[n].TaxStructureId) {
                                $scope.TaxStructureDetailsData = $scope.TaxStructure[q].LinkTaxStructures;

                                var calculatetax = 0;
                                $scope.TaxTypeTransaction = [];

                                var invoicedetail = $scope.invoice[n];
                                var taxData = $scope.TaxStructureDetailsData;
                                for (var p = 0; p < taxData.length; p++) {
                                    if (taxData[p].TaxOn === "1" || taxData[p].TaxOn === "3") {

                                        if (taxData[p].TaxInName === "Percent") {
                                            calculatetax =
                                                parseFloat(invoicedetail.Amount) *
                                                parseFloat(taxData[p].TaxValue) /
                                                100;
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });

                                        } else {
                                            calculatetax = parseFloat(taxData[p].TaxValue);
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        }

                                        calculatetax = 0;
                                    } else if (taxData[p].TaxOn === "2") {
                                        var discoutedamount = 0;
                                        if (invoicedetail.DiscountIn === "Percent") {
                                            discoutedamount =
                                                parseFloat(invoicedetail.Amount) -
                                                (parseFloat(invoicedetail.Amount) *
                                                    parseFloat(invoicedetail.Discount) /
                                                    100);
                                        } else {
                                            discoutedamount =
                                                parseFloat(invoicedetail.Amount) -
                                                parseFloat(invoicedetail.Discount);
                                        }
                                        if (taxData[p].TaxInName === "Percent") {
                                            calculatetax =
                                                parseFloat(discoutedamount) * parseFloat(taxData[p].TaxValue) / 100;
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        } else {
                                            calculatetax = parseFloat(taxData[p].TaxValue);
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        }
                                        calculatetax = 0;
                                    } else {
                                        if ($scope.TaxTypeTransaction.length > 0) {
                                            var taxontaxdata = taxData[p].TaxAutoId.split("-");
                                            var newautoId =
                                                (parseInt(taxontaxdata[0]) - 1) +
                                                    "-" +
                                                    taxontaxdata[1] +
                                                    "-" +
                                                    taxontaxdata[2];
                                            for (var t = 0; t < $scope.TaxTypeTransaction.length; t++) {
                                                if (newautoId === $scope.TaxTypeTransaction[t].TaxAutoId) {
                                                    if (taxData[p].TaxInName === "Percent") {
                                                        calculatetax =
                                                            parseFloat($scope.TaxTypeTransaction[t].TaxAmount) *
                                                            parseFloat(taxData[p].TaxValue) /
                                                            100;
                                                        $scope.TaxTypeTransaction.push({
                                                            TaxAutoId: taxData[p].TaxAutoId,
                                                            TaxAmount: calculatetax
                                                        });

                                                    } else {
                                                        calculatetax = parseFloat(taxData[p].TaxValue);
                                                        $scope.TaxTypeTransaction.push({
                                                            TaxAutoId: taxData[p].TaxAutoId,
                                                            TaxAmount: calculatetax
                                                        });
                                                    }

                                                    calculatetax = 0;
                                                }
                                            }
                                        }

                                        calculatetax = 0;
                                    }
                                }

                                var taxSum = 0;
                                for (var l = 0; l < $scope.TaxTypeTransaction.length; l++) {
                                    taxSum += parseFloat($scope.TaxTypeTransaction[l].TaxAmount);
                                }
                                $scope.invoice[n].Tax = $filter('number')(taxSum, 2).replace(/,/g, '');
                                $scope.invoice[n].TaxTransactionDetail = $scope.TaxTypeTransaction;
                            }
                        }
                    }
                    ///////
                });
          
                if($scope.IsIndentIssue){
                     
                    var indBal=0;
                    var invBal=0;
                    $scope.IndentItemIssues.forEach(function (indItem) {
                        indBal+=indItem.Quantity;
                        $scope.invoice.forEach(function (invItem) {
                            if(indItem.InventoryItemId===invItem.InventoryItemId && indItem.BrandId===invItem.BrandId){
                                invItem.IndentItemIssues=[];
                            }
                        });
                        $scope.invoice.forEach(function (invItem) {
                            if(indItem.InventoryItemId===invItem.InventoryItemId && indItem.BrandId===invItem.BrandId){
                                if(!invItem.bal)invItem.bal=invItem.Quantity;
                                if(invItem.bal>0){
                                    invBal+=invItem.bal;
                                    if(!invItem.IndentItemIssues)invItem.IndentItemIssues=[];
                                    if(indBal>=invBal){
                                        invItem.IndentItemIssues.push({
                                            IndentItemId:indItem.IndentItemId,
                                            UnitOfMeasurementId: indItem.UnitOfMeasurementId,
                                            Quantity:invBal,
                                        });
                                        indBal-=invBal;
                                        invItem.bal=0;
                                        invBal=0;
                                    }
                                    else{
                                        invItem.IndentItemIssues.push({
                                            IndentItemId:indItem.IndentItemId,
                                            UnitOfMeasurementId: indItem.UnitOfMeasurementId,
                                            Quantity:indBal,
                                        });
                                        invItem.bal-=indBal;
                                    }
                                }
                            }
                        });
                    });
                }
            });
        };

        var searchMatch = function (haystack, needle) {

            if (!needle) {

                return true;

            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {

            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {

                    if (attr === "Id" || attr === "OperationType" || attr === "gridOptions") {
                        var dd = item[attr];
                        if (dd == null || dd == 'undefined' || dd == '') {
                        } else {
                            if (searchMatch(item[attr], $scope.query))
                                return true;
                        }
                    }
                }
                return false;
            });

            $scope.gridOptions.data = $scope.filteredItems;

            if ($scope.filteredItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";

            } else {
                $scope.MsgNotFound = "";
            }
        };

        var pathServer = Path;
        $scope.gridOptions = {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: {
                text: "Issue Details", style: 'headerStyle'
            },
            exporterPdfFooter: function (currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22, bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10, bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {

                    if (row.isExpanded) {
                        row.entity.subGridOptions = {
                            columnDefs: [
                                    {
                                        name: 'InventoryItemName', displayName: 'ItemName'
                                    },
                                    {
                                        name: 'StoreName'
                                    },
                                     {
                                         name: 'BrandName', displayName: 'Brand'
                                     },
                                {
                                    name: 'UnitOfMeasurementName', displayName: 'Uom'
                                },
                                     {
                                         name: 'Quantity', displayName: 'Qty'
                                     },
                                      {
                                          name: 'Rate'
                                      },

                        {
                            name: 'ExpiryDateString', displayName: 'Expiry Date', cellFilter: 'date:grid.parent.appScope.DateFormat'
                        },
                        { name: 'CostCenterName' },
                        {
                            name: 'BatchNo'
                        }
                            ]
                        };
                        row.entity.subGridOptions.data = row.entity.InventoryTransactionItems;

                    }
                });
            }
        }

        $scope.gridOptions.columnDefs = [
            { name: 'GRNumber', pinnedLeft: true, displayName: 'Indent /Reference No' },
            { name: 'TransactionDateString', displayName: 'Date', cellFilter: 'date:grid.appScope.DateFormat', sort: { direction: 'desc', priority: 0 } },
            { name: 'NetAmount' },
            { name: 'OperationTypeName', displayName: 'Operation Type' }
        ];

        $scope.save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            $scope.invoices = [];
            if ($scope.invoice.length < 1) {
                msg("Please select at least one item!");
                return;
            }
            $scope.IsSaving = true;

            var itemss = $scope.invoice;
            var expiredItems='';
            for (var i = 0; i < $scope.invoice.length; i++) {
                $scope.invoice[i].parentId = $scope.invoice[i].Id;
                $scope.invoice[i].CostCenterId = $scope.CostCentreIds;

                itemss[i].IndentNo = $scope.IndentNo;
                itemss[i].GRNDATE = $scope.IssueDate;
                itemss[i].Remarks = $scope.Remark;
                itemss[i].TotalAmount = $scope.TotalAmount();
                itemss[i].TotalDiscount = $scope.TotalDiscount();
                itemss[i].TotalTax = $scope.TotalTax();
                itemss[i].NetAmount = $scope.NetAmount();
                itemss[i].OperationType = "Issue";
                itemss[i].GrossAmount = $scope.Gross((parseFloat($scope.invoice[i].Quantityremaining) * parseFloat($scope.invoice[i].Rate)), $scope.invoice[i].DiscountIn, $scope.invoice[i].Discount, $scope.invoice[i].Tax);
                itemss[i].ItemNetAmount = $scope.ItemNetAmount((parseFloat($scope.invoice[i].Quantityremaining) * parseFloat($scope.invoice[i].Rate)), $scope.invoice[i].DiscountIn, $scope.invoice[i].Discount, $scope.invoice[i].Tax);
                itemss[i].CostCentreId = itemss[i].CostCentre;

                if(itemss[i].IsShowExpiryDate && itemss[i].ExpiryDateString<$scope.ModifiedDate)expiredItems += itemss[i].InventoryItemName+', ';
            }
            if(expiredItems.length>1){
                expiredItems=expiredItems.substr(0,expiredItems.length-2)+' expired.';
                msg(expiredItems);
                wait(5000);
            }

            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.ModifiedDate = $scope.ModifiedDate;
            $scope.model.GRDate = $scope.ModifiedDate;
            $scope.model.InventoryTransactionItems = $scope.invoice;
            $scope.model.OperationType = 3;
            $scope.model.GRNumber = $scope.IndentNo;
            //$scope.model.IssueDate = $scope.IssueDate;
            $scope.model.CostCenterId = $scope.CostCentreIds;
            $scope.model.Quantity = $scope.qtys;
            $scope.model.Remarks = $scope.Remark;

            var promise = service.save($scope.model);
            promise.then(function (data, status) {
                $scope.data = data.Collection;

                msg("Item Successfully Issued "+expiredItems, true); 
                $scope.reset();
                $scope.getIndentNo();
                GetIssueReceiptDetails();
                $scope.model.TransactionDateString=$scope.ModifiedDate;
                $scope.BindItemData($scope.model.TransactionDateString);
                $scope.getAllIndents(34, 'All', 'All');
            }).finally(function(){
                $scope.IsSaving = false;
            });
        };
        function wait(milliseconds) {
            var start = new Date().getTime();
            for (var i = 0; i < 1e7; i++) {
                if ((new Date().getTime() - start) > milliseconds){
                    break;
                }
            }
        }
        $scope.reset = function () {
            var issueDate=$scope.model.TransactionDateString;
            $scope.model = {};
            $scope.model.TransactionDateString=issueDate;
            $scope.invoice = [];
            $scope.CostCentreIds = "";
            $scope.IndentNo = "";
            $scope.IsIndentIssue=false;
            $scope.IssueDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat);
            $scope.Remark = "";
            $scope.ItemBrand = "";
            $scope.ItemMaster = "";
            $scope.qtys = "";
          
        };
        $scope.BindItemData($scope.ModifiedDate);
        
        $scope.TotalAmount = function () {

            var total = 0;
            for (var i = 0; i < $scope.invoice.length; i++) {
                total += parseFloat($scope.invoice[i].Amount);
            }
            total = $filter('number')(total, 2).replace(/,/g, '');
            return total;

        };
        $scope.TotalDiscount = function () {

            var total = 0;
            for (var i = 0; i < $scope.invoice.length; i++) {
                if ($scope.invoice[i].DiscountIn == "Percent") {
                    total += parseFloat((($scope.invoice[i].Amount) * ($scope.invoice[i].Discount)) / 100);
                } else {
                    total += parseFloat($scope.invoice[i].Discount);
                }

            }
            total = $filter('number')(total, 2).replace(/,/g, '');
            return total;
        };
        $scope.TotalTax = function () {

            var total = 0;
            for (var i = 0; i < $scope.invoice.length; i++) {
                total += parseFloat($scope.invoice[i].Tax);
            }
            total = $filter('number')(total, 2).replace(/,/g, '');
            return total;
        };
        $scope.NetAmount = function () {
            var total = 0;
            for (var i = 0; i < $scope.invoice.length; i++) {

                if ($scope.invoice[i].DiscountIn === "Percent") {
                    total += (parseFloat($scope.invoice[i].Amount ? $scope.invoice[i].Amount : 0) - parseFloat((($scope.invoice[i].Amount ? $scope.invoice[i].Amount : 0) * ($scope.invoice[i].Discount ? $scope.invoice[i].Discount : 0)) / 100) + parseFloat($scope.invoice[i].Tax ? $scope.invoice[i].Tax : 0));
                } else {
                    total += (parseFloat($scope.invoice[i].Amount ? $scope.invoice[i].Amount : 0) - parseFloat($scope.invoice[i].Discount ? $scope.invoice[i].Discount : 0) + parseFloat($scope.invoice[i].Tax ? $scope.invoice[i].Tax : 0));
                }
            }
            total = $filter('number')(total, 2).replace(/,/g, '');
            return total;
        };
        $scope.Gross = function (amount, DiscountIn, Discount, Tax) {

            var total = 0;

            total = parseFloat(amount) + parseFloat(Tax);
            total = $filter('number')(total, 2).replace(/,/g, '');
            return total;
        };
        $scope.ItemNetAmount = function (amount, DiscountIn, Discount, Tax) {

            var total = 0;

            if (DiscountIn === "Percent") {
                total = parseFloat(amount) + parseFloat(Tax) - parseFloat(((amount) * (Discount)) / 100);
            } else {
                total = parseFloat(amount) + parseFloat(Tax) - parseFloat(Discount);
            }
            total = $filter('number')(total, 2).replace(/,/g, '');
            return total;
        };

        $scope.CostCentreName = function (costids) {
            var costname = "";
            if ($scope.itemcostcentre.length > 0) {
                for (var i = 0; i < $scope.itemcostcentre.length; i++) {
                    if ($scope.itemcostcentre[i].CostId === costids) {
                        costname = $scope.itemcostcentre[i].CostName;
                    }
                }
            }
            return costname;
        }
        $scope.removeItem = function (index) {

            var curItem = $scope.invoice[index].ItemId;
            var curbrand = $scope.invoice[index].BrandId;
            var costcenter = $scope.invoice[index].CostCentreName;

            for (var i = 0; i < $scope.invoice.length; i++) {
                var invitem = $scope.invoice[i].ItemId;
                var invbrand = $scope.invoice[i].BrandId;
                var invcostcenter = $scope.invoice[i].CostCentreName;

                if (invitem === curItem && invbrand === curbrand && invcostcenter === costcenter) {
                    $scope.invoice.splice(i, 1);
                    i--;
                }
            }
            $scope.ItemBrandChange();
        };

        function GetReason() {
            var promise = service.getReasons($scope.PropertyID, 5);
            promise.then(function (data, status) {
                $scope.ReasonDetails = data.Collection;
            });
        }
        $scope.txtGRNNumber = function () {

            if (!$scope.IndentNo || $scope.IndentNo.length < 1) return;
            var promise = service.getByGRNumber($scope.PropertyID, 3, $scope.IndentNo);
            promise.then(function (data, status) {

                if (data.Collection.length > 0) {
                    $scope.data = data.Collection[0];
                    msg("Indent Already Exists!");
                    $scope.IndentNo = "";
                }
            });
        };

        $scope.ReturnDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat);
        $scope.getIndentNo= function (date) {
            var promise = service.getByGRNumber($scope.PropertyID, 3, '', 1,date);
            promise.then(function (data, status) {

                if (data.Collection.length > 0) {
                    $scope.data = data.Collection;
                    $scope.IndentNumber = data.Collection;
                }
            });
        };
        $scope.getIndentNo($scope.ModifiedDate);
        GetReason();
        $scope.savereturn = function (form) {
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessageR = true;
                return;
            }
            if ($scope.invoices.length < 1) {
                msg("Please at least one item!");
                return;
            }
            var itemss = $scope.invoices;
            for (var i = 0; i < $scope.invoices.length; i++) {
                if ($scope.invoices[i].Quantity === 0) {
                    msg("Quantity should not be zero.");
                    return;
                }
                $scope.invoices[i].ParentId = $scope.invoices[i].Id;
                itemss[i].IndentNo = $scope.Indent;
                itemss[i].GRNDATE = $scope.ReturnDate;
                itemss[i].Remarks = $scope.Remarks;
                itemss[i].TotalAmount = $scope.TotalAmountsRetrun();
                itemss[i].TotalDiscount = $scope.TotalDiscountsReturn();
                itemss[i].TotalTax = $scope.TotalTaxsReturn();
                itemss[i].NetAmount = $scope.NetAmountsReturn();
                itemss[i].OperationType = "Issue Return";
                itemss[i].ReferenceNo = $scope.Reference;
                itemss[i].ReasonID = $scope.Reason;
                itemss[i].GrossAmount = $scope.GrosssReturn((parseFloat($scope.invoices[i].Quantity) * parseFloat($scope.invoices[i].Rate)), $scope.invoices[i].DiscountIn, $scope.invoices[i].Discount, $scope.invoices[i].Tax);
                itemss[i].ItemNetAmount = $scope.ItemNetAmountReturn((parseFloat($scope.invoices[i].Quantity) * parseFloat($scope.invoices[i].Rate)), $scope.invoices[i].DiscountIn, $scope.invoices[i].Discount, $scope.invoices[i].Tax);
            }
            $scope.modelR.PropertyID = $scope.PropertyID;
            $scope.modelR.ModifiedBy = $scope.ModifiedBy;
            $scope.modelR.ModifiedDate = $scope.ModifiedDate;
            $scope.modelR.GRDate = $scope.ModifiedDate;
            $scope.modelR.InventoryTransactionItems = $scope.invoices;
            $scope.modelR.OperationType = 4;

            var promise = service.save($scope.modelR);
            promise.then(function (data, status) {

                msg("Item Successfully Returned", true);
                $scope.ItemBrandDetails = [];
               
                $scope.BindItemData($scope.modelR.TransactionDateString);
                $scope.resetreturn();
                $scope.   getIndentNo($scope.modelR.TransactionDateString);
                GetIssueReceiptDetails();
            });
        };

        $scope.removeItems = function (index) {

            $scope.invoices.splice(index, 1);
            $scope.TotalAmountsRetrun();
            $scope.TotalDiscountsReturn();
            $scope.TotalTaxsReturn();
            $scope.NetAmountsReturn();
        };

        $scope.Grosss = 0;
        $scope.GrosssReturn = function (amount, DiscountIn, Discount, Tax) {

            $scope.Grosss = parseFloat(amount) + parseFloat(Tax);
            return $filter('number')($scope.Grosss, 2).replace(/,/g, '');
        };

        $scope.ItemNetAmountReturn = function (amount, DiscountIn, Discount, Tax) {

            if (DiscountIn == "Percent") {
                $scope.Grosss = parseFloat(amount) + parseFloat(Tax) - parseFloat(((amount) * (Discount)) / 100);
            } else {
                $scope.Grosss = parseFloat(amount) + parseFloat(Tax) - parseFloat(Discount);
            }
            return $filter('number')($scope.Grosss, 2).replace(/,/g, '');
        };
        $scope.GrosssTotalAmounts = 0;
        $scope.TotalAmounts = 0;
        $scope.TotalAmountsRetrun = function () {

            var total = 0;

            if ($scope.invoices.length > 0) {
                angular.forEach($scope.invoices, function (item) {
                    total += parseFloat(item.Amount);
                });
            }
            total = $filter('number')(total, 2).replace(/,/g, '');
            $scope.TotalAmounts = total;
            return $scope.TotalAmounts;
        };

        $scope.TotalDiscounts = 0;
        $scope.TotalDiscountsReturn = function () {

            var total = 0;
            angular.forEach($scope.invoices, function (item) {
                if (item.DiscountIn == "Percent") {
                    total += parseFloat(((item.Amount) * (item.Discount)) / 100);
                } else {
                    total += parseFloat(item.Discount);
                }
            });
            total = $filter('number')(total, 2).replace(/,/g, '');
            $scope.TotalDiscounts = total;
            return $scope.TotalDiscounts;
        };

        $scope.TotalTaxs = 0;
        $scope.TotalTaxsReturn = function () {

            var total = 0;
            angular.forEach($scope.invoices, function (tax) {
                total += parseFloat(tax.Tax ? tax.Tax : 0);
            });
            total = $filter('number')(total, 2).replace(/,/g, '');
            $scope.TotalTaxs = total;
            return $scope.TotalTaxs;
        };

        $scope.NetAmounts = 0;
        $scope.NetAmountsReturn = function () {

            var total = 0;
            angular.forEach($scope.invoices, function (item) {
                total += (parseFloat(item.Amount ? item.Amount : 0) - parseFloat(item.Discount ? item.Discount : 0) + parseFloat(item.Tax ? item.Tax : 0));
            });
            total = $filter('number')(total, 2).replace(/,/g, '');
            $scope.NetAmounts = total;
            return $scope.NetAmounts;
        };

        $scope.txtGRNNumbers = function () {

            $scope.invoices = [];
            var promise = service.get($scope.PropertyID, 3, $scope.modelR.GRId);
            promise.then(function (data) {

                if (!data.Data) {
                    msg("Quantity not available for this GRN");
                    return;
                }
                $scope.invoices = data.Data.InventoryTransactionItems;
                 
                $scope.MinDate = $filter('date')(new Date(data.Data.GRDateString), $scope.DateFormat);
                if(!$scope.modelR.TransactionDateString || $scope.modelR.TransactionDateString<data.Data.GRDateString)   $scope.modelR.TransactionDateString=data.Data.GRDateString;//$filter('date')(data.Data.GRDateString, $scope.DateFormat);

                angular.forEach($scope.invoices, function (item) {
                    item.Amount = $filter('number')((item.Rate * item.Quantity), 2).replace(/,/g, '');
                    item.QuantityOriginal = item.Quantity;
                    item.DiscountOriginal = item.Discount;

                });

                $scope.TotalAmountsRetrun();
                $scope.TotalDiscountsReturn();
                $scope.TotalTaxsReturn();
                $scope.NetAmountsReturn();

            });
        };
        $scope.resetreturn = function () {
            $scope.modelR = {};
            $scope.invoices = [];
            $scope.Indent = "";
            $scope.ReturnDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat);
            $scope.Remarks = "";
            $scope.Reason = "";
            $scope.Reference = "";
            $scope.TotalAmountsRetrun();
            $scope.TotalDiscountsReturn();
            $scope.TotalTaxsReturn();
            $scope.NetAmountsReturn();
        };

        $scope.calculateAmountItemReturn = function (i, index) {

            if ($scope.invoices[index].Quantity > $scope.invoices[index].QuantityOriginal) {
                msg("Quantity refund not more than " + $scope.invoices[index].QuantityOriginal);
                $scope.invoices[index].Quantity = $scope.invoices[index].QuantityOriginal;//$window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
            }
            angular.forEach($scope.invoices, function (item, i) {

                if (i === index) {
                    item.Amount = item.Rate * item.Quantity;
                    item.Amount = $filter('number')(item.Amount, 2);
                    item.Amount = item.Amount.replace(/,/g, '');
                    if (item.DiscountIn === 2) {
                        item.Discount = $filter('number')(((parseFloat(item.DiscountOriginal) / parseFloat(item.QuantityOriginal)) * parseFloat(item.Quantity)), 2);
                    }

                    for (var n = 0; n < $scope.invoices.length; n++) {
                        for (var q = 0; q < $scope.TaxStructure.length; q++) {

                            if ($scope.TaxStructure[q].Id === $scope.invoices[n].TaxStructureId) {
                                $scope.TaxStructureDetailsData = $scope.TaxStructure[q].LinkTaxStructures;

                                var calculatetax = 0;
                                $scope.TaxTypeTransaction = [];

                                var invoicedetail = $scope.invoices[n];
                                var taxData = $scope.TaxStructureDetailsData;
                                for (var p = 0; p < taxData.length; p++) {
                                    if (taxData[p].TaxOnId === 1 || taxData[p].TaxOnId === 3) {

                                        if (taxData[p].TaxInName === "Percent") {
                                            calculatetax =
                                                parseFloat(invoicedetail.Amount) *
                                                parseFloat(taxData[p].TaxValue) /
                                                100;
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });

                                        } else {
                                            calculatetax = parseFloat(taxData[p].TaxValue);
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        }

                                        calculatetax = 0;
                                    } else if (taxData[p].TaxOnId === 2) {
                                        var discoutedamount = 0;
                                        if (invoicedetail.DiscountIn === 2) {//"Percent"
                                            discoutedamount = parseFloat(invoicedetail.Amount) - (parseFloat(invoicedetail.Amount) * parseFloat(invoicedetail.Discount) / 100);
                                        } else {
                                            discoutedamount = parseFloat(invoicedetail.Amount) - parseFloat(invoicedetail.Discount);
                                        }
                                        if (taxData[p].TaxInName === "Percent") {
                                            calculatetax = parseFloat(discoutedamount) * parseFloat(taxData[p].TaxValue) / 100;
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        } else {
                                            calculatetax = parseFloat(taxData[p].TaxValue);
                                            $scope.TaxTypeTransaction.push({
                                                TaxAutoId: taxData[p].TaxAutoId,
                                                TaxAmount: calculatetax
                                            });
                                        }
                                        calculatetax = 0;
                                    } else {
                                        if ($scope.TaxTypeTransaction.length > 0) {
                                            var taxontaxdata = taxData[p].TaxAutoId.split("-");
                                            var newautoId =
                                                (parseInt(taxontaxdata[0]) - 1) +
                                                    "-" +
                                                    taxontaxdata[1] +
                                                    "-" +
                                                    taxontaxdata[2];
                                            for (var t = 0; t < $scope.TaxTypeTransaction.length; t++) {
                                                if (newautoId === $scope.TaxTypeTransaction[t].TaxAutoId) {
                                                    if (taxData[p].TaxInName === "Percent") {
                                                        calculatetax =
                                                            parseFloat($scope.TaxTypeTransaction[t].TaxAmount) *
                                                            parseFloat(taxData[p].TaxValue) /
                                                            100;
                                                        $scope.TaxTypeTransaction.push({
                                                            TaxAutoId: taxData[p].TaxAutoId,
                                                            TaxAmount: calculatetax
                                                        });

                                                    } else {
                                                        calculatetax = parseFloat(taxData[p].TaxValue);
                                                        $scope.TaxTypeTransaction.push({
                                                            TaxAutoId: taxData[p].TaxAutoId,
                                                            TaxAmount: calculatetax
                                                        });
                                                    }

                                                    calculatetax = 0;
                                                }
                                            }
                                        }

                                        calculatetax = 0;
                                    }
                                }

                                var taxSum = 0;
                                for (var l = 0; l < $scope.TaxTypeTransaction.length; l++) {
                                    taxSum += parseFloat($scope.TaxTypeTransaction[l].TaxAmount);

                                }
                                $scope.invoices[n].Tax = $filter('number')(taxSum, 2);
                                $scope.invoices[index].TaxTransactionDetail = $scope.TaxTypeTransaction;
                            }
                        }
                    }
                    $scope.TotalAmountsRetrun();
                    $scope.TotalDiscountsReturn();
                    $scope.TotalTaxsReturn();
                    $scope.NetAmountsReturn();
                }
            });
        };
        $scope.calculateTotalDiscountReturn = function (i, index) {
            $scope.TotalDiscountsReturn();
            $scope.NetAmountsReturn();
        };
        $scope.calculateTotalTaxReturn = function (i, index) {
            $scope.TotalTaxsReturn();
            $scope.NetAmountsReturn();
        };

        $scope.showIndents = function (item, index) {
            $("#indentbox").show('slow');
             
            if (!$scope.indents) $scope.getAllIndents(34, 'All', 'All');
            $(window).resize();
        };
        $scope.getAllIndents= function (statusTypeId, searchText, searchType) {
            service.getAllIndents($scope.PropertyID, statusTypeId, searchText, searchType)
                .then(function (result) {
                    result.Collection.forEach(function(row){
                        row.IndentItems.forEach(function (subRow) {                        
                            subRow.QuantityOriginal=subRow.Quantity;
                            subRow.CostCenterId=row.CostCenterId;
                        });
                    });
                    $scope.gridOptionsIndent.data = $scope.indents = result.Collection;
                });
        };
        $scope.useIndent= function (item, index) {
            $scope.closeIndentBox();
            $scope.invoice=[];
            $scope.IndentItemIssues=[];
            var isIndentNo=true;
            $scope.IsIndentIssue=true;
            $scope.gridOptionsIndent.data.forEach(function (row) {
                if(row.Selected===row.Id){
                    //$scope.IndentItemIssues=[];
                    row.IndentItems.forEach(function (subRow) {
                        if (subRow.IsSelected)
                        {                     
                            $scope.IndentItemIssues.push({
                                IndentItemId:subRow.Id,
                                UnitOfMeasurementId: subRow.UnitOfMeasurementId,
                                Quantity:subRow.Quantity,
                                InventoryItemId:subRow.InventoryItemId,
                                BrandId:subRow.BrandId
                            });
                            var found = $scope.invoice.find(x=>x.InventoryItemId==subRow.InventoryItemId && x.BrandId==subRow.BrandId);
                            if(found) {
                                found.Quantity+=subRow.Quantity;
                                $scope.IndentItemIssues.forEach(function(ipo){
                                    found.IndentItemIssues.push(ipo);                           
                                });
                            }
                            else
                                found = angular.copy( subRow);

                            $scope.ItemMaster = found.InventoryItemId;
                            $scope.ItemMasterChange();
                            $scope.ItemBrand = found.BrandId;
                            $scope.ItemBrandChange();
                            $scope.qtys = found.Quantity;
                            //if(!$scope.ItemQuantityChange()) subRow.Quantity=0;
                            var iqc=$scope.ItemQuantityChange();
                            if(!iqc){
                                subRow.Quantity=0;
                                isIndentNo=iqc;
                            }
                        }
                    });
               
                    if(!$scope.IndentNo||$scope.IndentNo.length<1) $scope.IndentNo = row.Selected;
                }
            });
            //$scope.IsIndentIssue=true;
            if(!isIndentNo) $scope.IndentNo = '';

        };
        $scope.closeIndentBox = function () {
            $("#indentbox").hide('slow');
        };
        $scope.gridOptionsIndent= {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: {
                text: "Indent",
                style: 'headerStyle'
            },
            exporterPdfFooter: function (currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(),
                    style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22,
                    bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10,
                    bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),

            columnDefs : [
                {
                    name: 'IsSelected', displayName: 'Select', pinnedLeft: true, type: 'boolean', cellTemplate: '<input type="radio" name="selected" ng-model="row.entity.Selected" value="{{row.entity.Id}}" ng-click="grid.appScope.selectAllPRItem(row.entity)" >'
                },
                {
                    name: 'IndentNumber', pinnedLeft: true
                },       {
                    name: 'IndentDate', cellFilter: 'date:grid.appScope.DateFormat'
                },      {
                    name: 'CostCenterName', displayName: 'Cost Center'
                },      {
                    name: 'ApprovedByName', displayName: 'Approved By'
                },      {          name: 'IndentStatusTypeName', displayName: 'Status'
                }            ],

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {

                    if (row.isExpanded) {

                        row.entity.subGridOptions = {
                            appScopeProvider: $scope.subGridScope,
                            columnDefs: [
                            {
                                name: 'IsSelected', displayName: 'Select', pinnedLeft: true, type: 'boolean', cellTemplate: '<input type="checkbox" ng-model="row.entity.IsSelected" ng-disabled="row.entity.Disabled" >'
                            },
                            {
                                name: 'Quantity',displayName:'Order Quantity', cellClass: 'grid-align-right', cellTemplate: '<input type="text" ng-model="row.entity.Quantity" maxlength="12" positive-decimal ng-change="grid.appScope.keepBelowOriginal(row.entity)" >'
                            },
                            {
                                name: 'StoreName'
                            },
                            {
                                name: 'InventoryItemName'
                            },
                            {
                                name: 'BrandName'
                            },
                            {
                                name: 'ItemTypeName'
                            },
                            {
                                name: 'QuantityOriginal',displayName:'Quantity', cellClass: 'grid-align-right'
                            },
                             {
                                 name: 'UnitOfMeasurementName', displayName: 'UOM', cellClass: 'grid-align-right'
                             },                            
                            {
                                name: 'RequiredDate', cellFilter: 'date:' + $scope.DateFormat
                            }
                            ]
                        };
                        row.entity.subGridOptions.data = row.entity.IndentItems;
                    }
                });
            }
        };
        $scope.selectAllPRItem = function (row) {
            $scope.IndentNo     =  row.Selected;
            $scope.CostCentreIds=  row.CostCenterId;
            $scope.indents.forEach(function (indent) {
                var checked=    row.Selected===indent.Id;
                indent.IndentItems.forEach(function (subRow) {
                    subRow.IsSelected = checked;
                    subRow.Disabled = !checked;
                });
            });
        };
       
        $scope.subGridScope = {
            keepBelowOriginal: function(entity){
                if(entity.Quantity>entity.QuantityOriginal) entity.Quantity=entity.QuantityOriginal;
            }
        };
        $scope.changeCostCenter = function () {
            if ($scope.cccount && $scope.invoice && $scope.invoice.length>0)
                msg('You are changing cost center.' );
            $scope.cccount = true;

        };        

    }
]);
