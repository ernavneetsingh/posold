﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');

        $scope.LoginId = $cookies.get('LoginId');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            TaxStructureId: '',
            TaxStructureName: '',
            MenuCategoryId: '',
            MenuCategoryCode: '',
            MenuCategoryName: '',
            MenuSubCategoryId: '',
            MenuSubCategoryCode: '',
            MenuSubCategoryName: '',
            KitchenId: '',
            KitchenCode: '',
            KitcheNName: '',
            MenuGroupType: '',
            MenuGroupTypeId: '',
            MenuGroupTypeName: '',
            IsDiscountAllowed: 'false',
            CostingPercentage: '',
            IsActive: true,
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
        };

        //------------------------------------------------
        ////page configuration parameter
        //------------------------------------------------
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "OutletName";
        $scope.pageSizes = [5, 10, 25, 50];
        //$scope.pageAttrs = ["Symbol", "Name"]; //TODO
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        // init the filtered items
        $scope.search = function () {

            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "OutletName") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };

        // show items per page
        $scope.perPage = function () {
            $scope.groupToPages();
        };

        // calculate page in place
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };

        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };

        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };

        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };

        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }

        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }

        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };

        // change sorting order
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };
        //------------------------------------------------
        //page configuration end
        //------------------------------------------------

        getData();

        function getData() {
            var promiseGet = service.getData($scope.PropertyID, 2);
            promiseGet.then(function (data) {
                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {
                   parent.failureMessage(data.message);
               });

        };

        $scope.Save = function (model, form) {

            if ($scope[form].$valid) {
                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                var status = service.save(model);
                status.then(function (result) {
                    if (result.Status == true) {
                        $scope.Reset();
                        parent.successMessage(result.Message);
                        getData();
                        scrollPageOnTop();
                    }
                }, function (error) {
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
        }
        $scope.Edit = function (model) {

            $scope.Model = model;
            $scope.Model.MenuGroupTypeId = model.MenuGroupTypeId.toString();
            $scope.Model.IsDiscountAllowed = model.IsDiscountAllowed.toString();
            $scope.getMenuCategory(model.MenuGroupTypeId.toString());
            $scope.getMenuSubCategory(model.MenuCategoryId);
        }
        $scope.Reset = function () {
            $scope.Model = {
                IsDiscountAllowed: 'false',
                CostingPercentage: 0,
                IsActive: true,
            };
            $scope.query = '';
            getData();
        }
        $scope.Remove = function (model) {
            var strDelete = DeletePopup("Are you sure to delete " + model.OutletName);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove($scope.PropertyID, model.Id);
                        status.then(function (model) {
                            parent.successMessage("Record Successfully deleted.");
                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };

        $scope.MenuGroupType = [];
        getMenuGroup();
        function getMenuGroup() {
            var promiseGet = service.GetMenuGroup();
            promiseGet.then(function (data) {
                $scope.MenuGroupType = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.Outlets = [];
        GetAllOutlet();
        function GetAllOutlet() {
            var promiseGet = service.getAllOutlet($scope.PropertyID); //3=PointOfSale
            promiseGet.then(function (data) {
                $scope.Outlets = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.TaxStructures = [];

        $scope.GetAllByOutletId = function (outletId) {
            var promiseGet = service.getAllByOutletId(outletId, $scope.PropertyID); //3=PointOfSale
            promiseGet.then(function (data) {
                $scope.TaxStructures = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

        $scope.MenuCategorys = [];
        //getMenuCategory();
        $scope.getMenuCategory = function (menuGroupTypeId) {

            $scope.MenuCategorys = [];
            $scope.MenuSubGroupCategory = [];

            var promiseGet = service.getAllByMenuGroupType(menuGroupTypeId, $scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.MenuCategorys = data;
                //$scope.Model.MenuCategoryId = $scope.Model.MenuCategoryId

                //$scope.Model.MenuSubCategoryId = $scope.Model.ItemCategoryIdStore;
                //$scope.Model.ItemCategoryIdStore = '';
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }
        $scope.MenuSubCategorys = [];
        $scope.getMenuSubCategory = function (id) {

            var promiseGet = service.GetMenuSubCategory(id, $scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.MenuSubCategorys = data;
                //$scope.Model.MenuSubCategoryId = $scope.Model.MenuSubCategoryId;

            },
                function (data) {

                    parent.failureMessage(data.message);
                });
        }

        $scope.KitchenCode = [];
        getKitchen();
        function getKitchen() {
            var promiseGet = service.GetKitchen($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.KitchenCode = data;
            },
                function (data) {
                    parent.failureMessage(data.message);
                });
        }

    }
]);
