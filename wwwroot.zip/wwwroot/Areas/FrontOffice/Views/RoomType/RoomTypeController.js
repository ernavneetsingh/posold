﻿
app.controller("RoomTypesController",
    [
    "$scope", "$http", "$filter", "service", "$window", "$cookies", "localStorageService", function ($scope, $http, $filter, service, $window, $cookies, localStorageService) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.MsgNotFound = "";
        $scope.IsActive = true;

        var sortKeyOrder = {
            key: "Name",
            order: "ASC"
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }
        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        getData($scope, service, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, service, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        };
        $scope.recordsonpage = function (records) {

            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, service, localStorageService);
        }


        //$scope.sortingOrder = "OrderSNo";
        //$scope.pageSizes = [5, 10, 25, 50];
        //$scope.reverse = false;
        //$scope.filteredItems = [];
        //$scope.groupedItems = [];
        //$scope.itemsPerPage = 10;
        //$scope.pagedItems = [];
        //$scope.currentPage = 0;
        //$scope.items = [];
        //getRoomTypeData();

        //var searchMatch = function (haystack, needle) {
        //    if (!needle) {
        //        return true;
        //    }
        //    return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        //};
        //$scope.search = function () {
        //    $scope.filteredItems = $filter("filter")($scope.items, function (item) {
        //        for (var attr in item) {
        //            if (attr === "Code" || attr === "Name") {
        //                if (searchMatch(item[attr], $scope.query))
        //                    return true;
        //            }
        //        }
        //        return false;
        //    });

        //    // take care of the sorting order
        //    if ($scope.sortingOrder !== '') {
        //        $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
        //    }
        //    $scope.currentPage = 0;
        //    // now group by pages
        //    $scope.groupToPages();
        //};
        //$scope.perPage = function () {
        //    $scope.groupToPages();
        //};
        //$scope.groupToPages = function () {

        //    $scope.pagedItems = [];
        //    $scope.currentPage = 0;
        //    if ($scope.itemsPerPage === "All") {
        //        $scope.itemsPerPage = $scope.filteredItems.length;
        //    }
        //    for (var i = 0; i < $scope.filteredItems.length; i++) {
        //        if (i % $scope.itemsPerPage === 0) {
        //            $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
        //        } else {
        //            $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
        //        }
        //    }
        //    if ($scope.pagedItems.length === 0) {
        //        $scope.MsgNotFound = "Record Not Found.";
        //        $scope.pagedItems.length = 1;

        //    } else {
        //        $scope.MsgNotFound = "";
        //    }
        //};
        //$scope.range = function (start, end) {
        //    var ret = [];
        //    if (!end) {
        //        end = start;
        //        start = 0;
        //    }
        //    for (var i = start; i < end; i++) {
        //        ret.push(i);
        //    }
        //    return ret;
        //};
        //$scope.prevPage = function () {
        //    if ($scope.currentPage > 0) {
        //        $scope.currentPage--;
        //    }
        //};
        //$scope.nextPage = function () {
        //    if ($scope.currentPage < $scope.pagedItems.length - 1) {
        //        $scope.currentPage++;
        //    }
        //};
        //$scope.firstPage = function () {
        //    $scope.currentPage = 0;
        //}
        //$scope.lastPage = function () {
        //    $scope.currentPage = $scope.pagedItems.length - 1;
        //}
        //$scope.setPage = function () {
        //    $scope.currentPage = this.n;
        //};
        //$scope.sort_by = function (newSortingOrder) {
        //    if ($scope.sortingOrder === newSortingOrder)
        //        $scope.reverse = !$scope.reverse;

        //    $scope.sortingOrder = newSortingOrder;
        //};


        //Save/Update room type
        $scope.Save = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            if (!$scope.Order_asc || $scope.Order_asc == "0") {
                msg('Display sequence should not be 0.');
                return;
            }
            if ($scope.Advance && parseFloat($scope.Advance) > 100) {
                msg('Advance should not be greater than 100%.');
                return;
            }
            var roomtypeData = new Object();
            roomtypeData.Code = $scope.TypeCode;
            roomtypeData.Id = $scope.Id;
            roomtypeData.Name = $scope.Name;
            roomtypeData.Description = $scope.Description;
            roomtypeData.TotalRoom = $scope.TotalRoom;
            roomtypeData.OverBooking = $scope.OverBooking;
            roomtypeData.MaxPax = $scope.MaxPax;
            roomtypeData.Advance = $scope.Advance;
            roomtypeData.OrderSNo = $scope.Order_asc;
            roomtypeData.IsActive = $scope.IsActive;
            roomtypeData.PropertyID = $scope.PropertyID;
            roomtypeData.ModifiedBy = $scope.UserName;
            roomtypeData.RoomTypeId = $scope.RoomTypeId;
            var saveData = service.saveroomtypeData(roomtypeData);
            saveData.then(function (data) {
                $scope.Id = "";
                $scope.TypeCode = "";
                $scope.Name = "";
                $scope.Description = "";
                $scope.TotalRoom = "";
                $scope.OverBooking = "";
                $scope.MaxPax = "";
                $scope.Advance = "";
                $scope.Order_asc = "";
                $scope.IsActive = true;
                $scope.RoomTypeId = "";
                $scope.IsReadonly = false;
                getRoomTypeData();
                msg(data.Message, true);
            });

        };
        //Reset All Feild
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.Id = "";
            $scope.TypeCode = "";
            $scope.Name = "";
            $scope.Description = "";
            $scope.TotalRoom = "";
            $scope.OverBooking = "";
            $scope.MaxPax = "";
            $scope.Advance = "";
            $scope.Order_asc = "";
            $scope.IsActive = true;
            $scope.RoomTypeId = "";
            $scope.IsReadonly = false;
            $scope.query = "";
            $scope.search();
        };

        //Get All room type Data
        function getRoomTypeData() {

            var getData = service.getroomtypseData($scope.PropertyID);
            getData.then(function (roomtypeData) {
                $scope.$apply(function () {
                    $scope.items = roomtypeData.Collection;
                    $scope.search();
                });
            });
        };

        //Change room type Status
        $scope.activeRow = function (id) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var roomtypeData = new Object();

            roomtypeData.Id = id;
            roomtypeData.PropertyID = $scope.PropertyID;
            roomtypeData.ModifiedBy = $scope.UserName;

            var statusData = service.statusroomtypeData(roomtypeData);

            statusData.then(function (data) {
                getRoomTypeData();
                msg(data.Message, true);
            });
        };

        //Delete Record
        $scope.removeRow = function (roomtypeData) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (roomtypeData != undefined) {

                                var removeData = service.removeroomtypeData(roomtypeData);
                                removeData.then(function (data) {

                                    msg(data.Message, true);
                                    //$("html, body").animate({ scrollTop: 0 }, "slow");
                                    getRoomTypeData();

                                },
                                    function (error) {
                                        msg(error.Message);
                                        //$("html, body").animate({ scrollTop: 0 }, "slow");
                                    });
                            }
                            $.fancybox.close();
                        });
                }
            });

        };

        //Check existing room type Code
        $scope.txtTypeCodeCodes = function () {

            var roomTypeCode = service.roomtypeDataExists($scope.TypeCode);
            roomTypeCode.then(function (data) {

            }, function (error) {
                //error handler function

                $scope.$apply(function () {
                    $scope.TypeCode = "";
                });

            });
        };
        //Check Display Sequence
        $scope.txtTypeSequence = function () {
            var txtSequence = service.txtTypeSequenceData($scope.PropertyID, $scope.Order_asc, $scope.Id);
            txtSequence.then(function (data) {

            }, function (error) {
                msg('Display sequence should not be duplicate.');
                //$scope.$apply(function () {

                $scope.Order_asc = "";
                //});

            });

        }
        //Fill room type Data
        $scope.fillroomtypeData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.TypeCode = record.Code;
            $scope.Id = record.Id;
            $scope.Name = record.Name;
            $scope.Description = record.Description;
            $scope.TotalRoom = record.TotalRoom;
            $scope.OverBooking = record.OverBooking;
            $scope.MaxPax = record.MaxPax;
            $scope.Advance = record.Advance;
            $scope.Order_asc = record.OrderSNo;
            $scope.IsActive = record.IsActive;
            $scope.RoomTypeId = record.RoomTypeId;
            $scope.IsReadonly = true;
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        };
    }
    ]);



var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Name",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getRoomType(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    }, function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};