﻿
// var
var dateFormat;
var decimalPlaces = 2;
var filter = null;
var getDefaultSetting = function ($http, $q, propertyId, setting) {
    return httpCaller(apiPath + "GlobalSetting/DefaultSetting/Get", $http, $q, { propertyId: propertyId, setting: setting });
};
var initCommon = function ($scope, $http, $q, localStorageService, $cookies, $window, $filter) {
    $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');

    if (!$scope.PropertyID) {
        window.location.href = Path + "login.html";
        return false;
    } else if ($window) {
        readParam($scope, $window);
        var propertyParam = $scope.parameters['propertyId'];
        if (propertyParam && propertyParam.length > 0) {// && propertyParam !== $scope.PropertyID) {
            window.location.href = Path + "login.html";
            return false;
        }
    }

    if ($cookies) $scope.ModifiedBy = $cookies.get('UserName');
    $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
    getDefaultSetting($http, $q, $scope.PropertyID, "CurrencydecimalPlaces").then(function (s) { decimalPlaces = s.Data; });
    dateFormat = $scope.DateFormat;
    if ($filter) filter = $filter;
    return true;
};
var readParam = function ($scope, $window) {
    var paramstr = $window.location.search.substring(1);
    var params = paramstr.split('&');
    $scope.parameters = {};
    params.forEach(function (p) {
        var parts = p.split('=');
        $scope.parameters[parts[0]] = parts[1];
    });
};

// message 
function msg(message, success) {
    if (success)
        parent.successMessage(message);
    else
        parent.failureMessage(message);

    scrollPageOnTop();  //  parent.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);

};
function msgInPopup(message, success) {
    if (message != undefined && message != '' && message != "") {
        if (success) {
            $('#successPopupShow').empty();
            $('#successPopupShow').show();
            $('#successPopupShow').append(message);
            setTimeout(function () {
                $('#successPopupShow').hide();
                $('#successPopupShow').append("");
            }, 5000);
        }
        else {
            console.log(message);
            if (message != undefined && message != '' && message != "") {
                $('#failurePopupShow').empty();
                $('#failurePopupShow').show();
                $('#failurePopupShow').append(message);
                setTimeout(function () {
                    $('#failurePopupShow').hide();
                    $('#failurePopupShow').append("");
                }, 5000);
            }
        }
    }

}

// http
var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
var headers = { 'duxtechApiKey': accessToken, 'Accept': 'application/json; charset=utf-8' };
var httpCaller = function (url, $http, $q, params, error_suppress) {
    var config = { headers: headers, params: params };
    var deferred = $q.defer();
    $http.get(url, config)
        .success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        })
        .error(function (err, status) {
            if (err) {
                if (!error_suppress) msg(err.Message);
                deferred.reject(err, status);
            }
            else {
                msg('Undefined error!');
                deferred.reject(err, status);
            }

        });
    return deferred.promise;
}
var httpPoster = function (url, $http, $q, params, error_suppress) {
    var config = { headers: headers };
    var deferred = $q.defer();
    $http.post(url, params, config)
        .success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        })
        .error(function (err, status) {
            if (!error_suppress) msg(err.Message);
            deferred.reject(err, status);
        });
    return deferred.promise;
}
var httpCallerX = function (url, $http, $q, params) {

    var config = { headers: headers, params: params };
    var deferred = $q.defer();
    $http.defaults.useXDomain = true;
    try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e4) { }
    $http.get(url, config)
        .then(function (response) {
            deferred.resolve(response.data);
        })
        .catch(function (ex) {

            if (ex && ex.data) msg(ex.data.Message);
            deferred.reject(ex.data, status);
        });
    return deferred.promise;
}

// date
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function formatDMYDate(dateString) {
    var parts = dateString.split('-');
    var month = months.indexOf(parts[1]);
    return new Date('20' + parts[2], month, parts[0]);
};
var ymdFormatter = function (value) {
    if (!value) return null;
    if (value === "1900-01-01") return "";

    var parts = value.indexOf('-') !== -1 ? value.split('-') : value.split('/');    //var parts = value.split('-');
    var idxT = 0;
    if (parts.length > 2) idxT = parts[2].indexOf('T');
    if (idxT > 0) parts[2] = parts[2].substring(0, idxT);
    switch (dateFormat) {
        case "d-M-yy":
            return parts[2] + "-" + parts[1] + "-" + parts[0];
        case "dd-MM-yyyy":
        case "dd-MM-yy":
        case "dd/MM/yyyy":
        case "dd/MM/yy":
        case "d-M-yy":
        case "d/M/yy":
            return ('0' + parts[2]).slice(-2) + "-" + ('0' + parts[1]).slice(-2) + "-" + parts[0];
        case "dd/MMM/yy":
            return parts[2] + "/" + months[parts[1] - 1] + "/" + parts[0].substring(2);
        case "dd-MMM-yyyy":
        case "dd-MMM-yy":
            return parts[2] + "-" + months[parts[1] - 1] + "-" + parts[0];
        case "MM/dd/yyyy":
            return parts[1] + "/" + parts[2] + "/" + parts[0];
        case "MM/dd/yy":
            return parts[1] + "/" + parts[2] + "/" + parts[0].substring(2);
        case "MM-dd-yy":
            return parts[1] + "-" + parts[2] + "-" + parts[0];
        case "M-d-yy":
            return parts[1] + "-" + parts[2] + "-" + parts[0];
        case "MMyyyy":
            return value;
        default:
            return parts[0] + "-" + parts[1] + "-" + parts[2];
    }
};
var ymdParser = function (value) {
    if (!value) return null;

    var parts = value.indexOf('-') !== -1 ? value.split('-') : value.split('/');
    var yearPart = (parts[2].length === 4 ? parts[2] : parts[2] < 60 ? "20" + parts[2] : "19" + parts[2]);
    switch (dateFormat) {
        case "dd-MM-yyyy":
        case "dd/MM/yyyy":
        case "dd-MM-yy":
        case "dd/MM/yy":
        case "d-M-yy":
        case "d/M/yy":
            return yearPart + "-" + parts[1] + "-" + parts[0];
        case "dd-MMM-yyyy":
        case "dd-MMM-yy":
            return yearPart + "-" + ("0" + (months.indexOf(parts[1]) + 1).toString()).slice(-2) + "-" + parts[0];
        case "M-d-yy":
            return yearPart + "-" + parts[0] + "-" + parts[1];
        case "MMyyyy":
            return parts[1] + parts[0];
        default:
            return parts[0] + "-" + parts[1] + "-" + parts[2];
    }
};
function dateCompare(date1, date2) {
    var d1 = new Date(date1);
    var d2 = new Date(date2);
    //return d1.getDate() - d2.getDate();
    //var timeDiff = Math.abs(d1.getTime() - d2.getTime());
    var timeDiff = d1.getTime() - d2.getTime();
    var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    return diffDays;
}
function dateAdd(date, add, count, $filter) {
    var d1 = new Date(date);
    switch (add) {
        case 'day':
            d1.setDate(d1.getDate() + count);
            break;
        case 'month':
            d1.setMonth(d1.getMonth() + count);
            break;
        case 'year':
            d1.setFullYear(d1.getFullYear() + count);
            break;
    }
    if ($filter) return $filter("date")(d1, "yyyy-MM-dd");
    return d1;
}
//if(!app) return;
if (typeof (app) != "undefined") {
    app.directive('ymdFormatter', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, controller) {
                dateFormat = scope.DateFormat;
                controller.$formatters.push(ymdFormatter);
                controller.$parsers.push(ymdParser);
            }
        }
    });
    app.directive('momentFormatter', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, controller) {
                dateFormat = scope.DateFormat;
                controller.$formatters.push(function (value) {
                    // 
                    if (!value) return null;
                    return GetLocalDate(value, dateFormat);
                });
                controller.$parsers.push(function (value) {
                    // 
                    if (!value) return null;
                    return GetServerDate(value, dateFormat);
                });
            }
        }
    });
    app.directive('ccDate', [
       function () {
           return {
               restrict: 'A',
               require: 'ngModel',
               link: function (scope, element, attr, ngModelCtrl) {
                   var pattern = /[^0-9-]/g;   // Matches characters that aren't `0-9`, `.`, `+`, or `-`
                   function clean(str) {
                       return str.replace(/[^0-9-]/g, "");
                   }
                   function fromUser(text) {

                       //var rep = /[+]/g;  // find + symbol (globally)
                       //var rem = /[-]/g;  // find - symbol (globally)
                       //rep.exec(text);
                       //rem.exec(text);
                       //var indexp = rep.lastIndex;
                       //var indexm = rem.lastIndex;
                       //text = text.replace(/[+-]/g, '');
                       //if (indexp > 0 || indexm > 0) {// Are there signs?
                       //    if (indexp > indexm) { // plus sign typed later?
                       //        text = "+" + text;
                       //    } else text = "-" + text;
                       //}
                       var transformedInput = text.replace(pattern, '');
                       var pos = transformedInput.indexOf("-");
                       var result;
                       if (pos !== -1) {
                           var part1 = transformedInput.substr(0, pos);
                           if (part1 > 12) part1 = "12";
                           var part2 = transformedInput.substr(pos + 1);
                           if (part2 > 2100) part2 = "2100";
                           result = clean(part1) + "-" + clean(part2);
                       } else {
                           result = clean(transformedInput);
                       }
                       ngModelCtrl.$setViewValue(result);
                       ngModelCtrl.$render();
                       return transformedInput;
                   }
                   ngModelCtrl.$parsers.push(fromUser);
               }
           };
       }
    ]);
}
// js
function showDiv(divName, show) {
    var div = document.getElementById(divName);
    if (div) {
        div.style.display = show ? '' : 'none';
    }
    return !show;
};
function isObj(obj) {
    return obj && obj !== 'null' && obj !== 'undefined';
};

// search
var searchMatch = function (haystack, needle) {
    if (!needle) return true;
    return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
};
var groupToPages = function ($scope) {
    $scope.pagedItems = [];
    $scope.currentPage = 0;
    if (!$scope.itemsPerPage) $scope.itemsPerPage = 10;
    if (!$scope.filteredItems) $scope.filteredItems = [];
    if ($scope.itemsPerPage === "All") {
        $scope.itemsPerPage = $scope.filteredItems.length;
    }
    for (var i = 0; i < $scope.filteredItems.length; i++) {
        if (i % $scope.itemsPerPage === 0) {
            $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
        } else {
            $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
        }
    }
    if ($scope.pagedItems.length === 0) {
        $scope.MsgNotFound = "Record Not Found.";
        $scope.pagedItems.length = 1;

    } else {
        $scope.MsgNotFound = "";
    }
};

// number
if (typeof (app) != "undefined") {
    app.directive('creditFormatter', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, controller) {
                controller.$formatters.push(function (value) {
                    if (value === 0) return 0;
                    if (!value) return null;
                    if (value < 0) return '(' + (0 - value) + ')';
                    return value.toFixed(2);
                });
            }
        }
    });
    app.directive('negativeDecimal', [
      function () {
          return {
              restrict: 'A',
              require: 'ngModel',
              link: function (scope, element, attr, ngModelCtrl) {
                  var pattern = /[^.0-9+-]/g;   // Matches characters that aren't `0-9`, `.`, `+`, or `-`
                  function clean(string) {
                      return string.replace(/[^0-9-]/g, "");
                  }
                  function fromUser(text) {

                      var rep = /[+]/g;  // find + symbol (globally)
                      var rem = /[-]/g;  // find - symbol (globally)
                      rep.exec(text);
                      rem.exec(text);
                      var indexp = rep.lastIndex;
                      var indexm = rem.lastIndex;
                      text = text.replace(/[+-]/g, '');
                      if (indexp > 0 || indexm > 0) {// Are there signs?
                          if (indexp > indexm) { // plus sign typed later?
                              text = "+" + text;
                          } else text = "-" + text;
                      }
                      var transformedInput = text.replace(pattern, '');
                      var pos = transformedInput.indexOf(".");
                      var result;
                      if (pos !== -1) {
                          var part1 = transformedInput.substr(0, pos);
                          var part2 = transformedInput.substr(pos + 1, 2);
                          result = clean(part1) + "." + clean(part2);
                      } else {
                          result = clean(transformedInput);
                      }
                      ngModelCtrl.$setViewValue(result);
                      ngModelCtrl.$render();
                      return transformedInput;
                  }
                  ngModelCtrl.$parsers.push(fromUser);
              }
          };
      }
    ]);
    app.directive('positiveDecimal', function () {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, element, attr, ctrl) {
                function inputValue(val) {

                    if (!val) {
                        ctrl.$setViewValue(0);
                        ctrl.$render();
                    } else {
                        val = val.trim();
                        if (val.length < 1) {
                            ctrl.$setViewValue(undefined);
                            ctrl.$render();
                        }

                        var digits = val.replace(/[^0-9.]/g, '');

                        if (digits.split('.').length > 2) {
                            digits = digits.substring(0, digits.length - 1);
                        }
                        var pos = digits.indexOf(".");
                        var result;
                        if (pos !== -1) {
                            var part1 = digits.substr(0, pos);
                            var part2 = digits.substr(pos + 1, decimalPlaces);
                            digits = part1 + "." + part2;
                        }
                        if (digits !== val) {
                            ctrl.$setViewValue(digits);
                            ctrl.$render();
                        }
                        return parseFloat(digits);
                    }
                    return undefined;
                }
                ctrl.$parsers.push(inputValue);
            }
        };
    });
    app.directive('onlyDigit', function () {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, element, attr, ctrl) {
                function inputValue(val) {
                    if (val) {

                        var digits = val.replace(/[^0-9.]/g, '');

                        if (digits.split('.').length > 1) {
                            digits = digits.substring(0, digits.length - 1);
                        }

                        if (digits !== val) {
                            ctrl.$setViewValue(digits);
                            ctrl.$render();
                        }
                        return parseFloat(digits);
                    }
                    return undefined;
                }
                ctrl.$parsers.push(inputValue);
            }
        };
    });
}
var intVal = function (i) {
    return typeof i === 'string' ?
        i.replace(/[\$,]/g, '') * 1 :
        typeof i === 'number' ?
        i : 0;
};
var decimalVal = function (n, p) {
    return parseFloat(n).toFixed(p ? p : decimalPlaces);
};
var decimalValD = function (n, p) {
    var d = parseFloat(decimalVal(n, p));
    return isNaN(d) ? 0 : decimalVal(n, p);
};
var decimalValF = function (n, p) {
    if (filter) filter('number')(n ? n : 0, p ? p : decimalPlaces);
    return n;
};
var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

function num2words(num) {
    if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
    return str;
}

// time 
var timeFormatter = function (value) {
    if (!value) return null;
    var parts = value.split(':');
    return new Date(1970, 0, 1, parts[0], parts[1], parts[2]);
};
var timeParser = function (value) {
    if (!value) return null;
    var dd;
    if (Number.isInteger(value))
        dd = new Date((value + new Date().getTimezoneOffset()) * 60 * 1000);
    else
        dd = new Date(value);
    var tt = ('0' + dd.getHours()).slice(-2) + ":" + ('0' + dd.getMinutes()).slice(-2) + ":" + ('0' + dd.getSeconds()).slice(-2);
    return tt;
};
if (typeof (app) != "undefined") {
    app.directive('timeFormatter', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, controller) {
                controller.$formatters.push(timeFormatter);
                controller.$parsers.push(timeParser);
            }
        }
    });
}
function timeCompare(date1, date2) {
    var d1 = new Date(date1);
    var d2 = new Date(date2);
    return d1.getTime() - d2.getTime();
}

if (typeof (app) != "undefined") {
    // grouper
    app.filter('groupBy', ['$parse', function ($parse) {

        return function (collection, key, id) {

            if (!collection) return null;
            if (!key) return collection;
            var result = {};
            var indexes;
            indexes = [];

            angular.forEach(collection, function (item) {
                var group_name = item[key];
                var group_id = item[id];
                var index = indexes.indexOf(group_name);

                if (index == -1) {
                    index = pad(indexes.push(group_name) - 1, 4);
                    result[index] = {};
                    result[index].group_name = group_name;
                    result[index].group_id = group_id;
                    result[index].items = [];
                } else {
                    index = pad(index, 4);
                }

                result[index].items.push(item);
            });
            return result;
        };
        //return function (collection, key) {

        //    if (!collection) return null;
        //    if (!key) return collection;
        //    //return _groupBy(collection, property);
        //    //function _groupBy(collection, key) {
        //    var result = {};
        //    var indexes;
        //    indexes = [];

        //    angular.forEach(collection, function (item) {

        //        var group_name = item[key];
        //        //var group_id = item[key];
        //        var index = indexes.indexOf(group_name);

        //        if (index == -1) {
        //            index = pad(indexes.push(group_name) - 1, 4);
        //            result[index] = {};
        //            result[index].group_name = group_name;
        //            result[index].items = [];
        //        } else {
        //            index = pad(index, 4);
        //        }

        //        result[index].items.push(item);
        //    });
        //    return result;
        //};
        function pad(number, length) {
            var str = '' + number;
            while (str.length < length) {
                str = '0' + str;
            }
            return str;
        }
        //};
    }]);

    // file
    app.directive('ngFiles', ['$parse', function ($parse) {

        function fn_link(scope, element, attrs) {
            var onChange = $parse(attrs.ngFiles);
            element.on('change', function (event) {
                onChange(scope, { $files: event.target.files });
            });
        };

        return {
            link: fn_link
        }
    }]);

    // multi select disable
    app.directive('ngDropdownMultiselectDisabled', function () {
        return {
            restrict: 'A',
            controller: ['$scope', '$element', '$attrs', function ($scope, $element, $attrs) {
                var $btn;
                $btn = $element.find('button');
                return $scope.$watch($attrs.ngDropdownMultiselectDisabled, function (newVal) {
                    return $btn.attr('disabled', newVal);
                });
            }]
        };
    });

    // fancy box print button
    function fancyPrintConfirm(msg, $window, url) {
        $.fancybox({
            'modal': true,
            'content': "<div style=\"margin:1px;width:350px;text-align: center;padding: 13px 0 0 0;\"> " + msg
                + " <div style=\"text-align:center;margin-top:20px;\">"
                + " <input id=\"fancyconfirm_cancel\" class=\"fancyboxConfirmCancel\" type=\"button\" Value=\"Close\">"
                + " <input id=\"fancyconfirm_print\" class=\"fancyboxConfirmCancel\" type=\"button\" Value=\"Print\"></div></div>",
            'afterShow': function () {
                $("#fancyconfirm_cancel").click(function () {
                    ret = false;
                    $.fancybox.close();
                    return ret;
                });
                $("#fancyconfirm_print").click(function () {

                    ret = true;
                    $.fancybox.close();
                    $window.open(origin + url, '_blank');
                    return ret;
                });
            }
        });
    };

    //character display in html
    app.filter('character', function () {
        return function (input) {
            return String.fromCharCode(64 + parseInt(input, 10));
        };
    });

    // cm'r
    function checkNumber(sNum) {
        var pattern = /^\d+(\.\d{1,2})?$/;
        return pattern.test(sNum);
    }

    // unused yet
    angular.module('app').config(['$provide', function ($provide) {
        $provide.decorator('$locale', ['$delegate', function ($delegate) {
            if ($delegate.id === 'en-us') {
                $delegate.NUMBER_FORMATS.PATTERNS[1].negPre = '(\u00A4';
                $delegate.NUMBER_FORMATS.PATTERNS[1].negSuf = ')';
            }
            return $delegate;
        }]);
    }]);


    //Navneet
    Array.prototype.max = function () {
        return Math.max.apply(null, this);
    };

    Array.prototype.min = function () {
        return Math.min.apply(null, this);
    };

    function replaceAll(str, find, replace) {
        return str.replace(new RegExp(find, 'g'), replace);
    }
}


function GET_TAX_STRUCTURE(linkTaxStructures, OriginalRate, ChangeRate) {
    
    var LinkTaxStructures = [];
    var TaxAmount = 0;
    var i = 1;
    angular.forEach(linkTaxStructures, function (linkTaxStructure) {

        var taxAmount = GET_TAX_AMOUNT(LinkTaxStructures, linkTaxStructure, parseFloat(OriginalRate), parseFloat(ChangeRate));
        if (isNaN(taxAmount)) {
            taxAmount = 0;
        }

        LinkTaxStructures.push({
            SNo: i,
            TaxTypeId: linkTaxStructure.TaxTypeId,
            TaxTypeCode: linkTaxStructure.TaxTypeCode,
            TaxOnId: linkTaxStructure.TaxOnId,
            TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
            IsTariffOn: linkTaxStructure.IsTariffOn,
            TaxInId: linkTaxStructure.TaxInId,
            TaxInName: linkTaxStructure.TaxInName,
            TaxValue: linkTaxStructure.TaxValue,
            TaxAmount: parseFloat(taxAmount),
        });
        i = 1 + i;
        TaxAmount = parseFloat(TaxAmount) + parseFloat(taxAmount);

    });

    return {
        LinkTaxStructures: LinkTaxStructures,
        TaxAmount: TaxAmount,
    };
}

function GET_TAX_AMOUNT(linkTaxStructures, tax, OriginalRate, ChangeRate) {

    var calculatetax = 0.0;
    var itemTax = tax.TaxValue.toString();
    itemTax = replaceAll(itemTax, ',', '');

    if (tax.TaxOnId === 1) {
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(OriginalRate);
            }
        }
    } else if (tax.TaxOnId === 2) {//Discounted For MealPlan
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(ChangeRate) && parseFloat(tax.MaxRange) >= parseFloat(ChangeRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(itemTax);
            }
        }
    }
    else if (tax.TaxOnId === 5) {
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(itemTax);
            }
        }
    }
    else if (tax.TaxOnId === 6) {
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(ChangeRate) && parseFloat(tax.MaxRange) >= parseFloat(ChangeRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(itemTax);
            }
        }
    }
    else {
        if (linkTaxStructures.length > 0) {
            angular.forEach(linkTaxStructures, function (item) {
                if (tax.TaxOnTaxTypeId == item.TaxTypeId) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(item.TaxAmount) * parseFloat(itemTax) / 100;
                    } else {
                        calculatetax = parseFloat(itemTax);
                    }
                }
            });
        }
    }
    return parseFloat(calculatetax);
};

// aNUSH - Bill Allowance calculation
function GET_TAX_STRUCTURE_ALLOWANCE(linkTaxStructures, OriginalRate, ChangeRate) {
    
    var LinkTaxStructures = [];
    var TaxAmount = 0;
    var i = 1;
    angular.forEach(linkTaxStructures, function (linkTaxStructure) {

        var taxAmount = GET_TAX_AMOUNT_ALLOWANCE(LinkTaxStructures, linkTaxStructure, parseFloat(OriginalRate), parseFloat(ChangeRate));
        if (isNaN(taxAmount)) {
            taxAmount = 0;
        }

        LinkTaxStructures.push({
            SNo: i,
            TaxTypeId: linkTaxStructure.TaxTypeId,
            TaxTypeCode: linkTaxStructure.TaxTypeCode,
            TaxOnId: linkTaxStructure.TaxOnId,
            TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
            IsTariffOn: linkTaxStructure.IsTariffOn,
            TaxInId: linkTaxStructure.TaxInId,
            TaxInName: linkTaxStructure.TaxInName,
            TaxValue: linkTaxStructure.TaxValue,
            TaxAmount: parseFloat(taxAmount),
        });
        i = 1 + i;
        TaxAmount = parseFloat(TaxAmount) + parseFloat(taxAmount);

    });

    return {
        LinkTaxStructures: LinkTaxStructures,
        TaxAmount: TaxAmount,
    };
}

function GET_TAX_AMOUNT_ALLOWANCE(linkTaxStructures, tax, OriginalRate, ChangeRate) {

    var calculatetax = 0.0;
    var itemTax = tax.TaxValue.toString();
    itemTax = replaceAll(itemTax, ',', '');

    if (tax.TaxOnId === 1) {
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(ChangeRate);
            }
        }
    } else if (tax.TaxOnId === 2) {//Discounted For MealPlan
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(itemTax);
            }
        }
    }
    else if (tax.TaxOnId === 5) {
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(itemTax);
            }
        }
    }
    else if (tax.TaxOnId === 6) {
        if (tax.IsSlab) {
            if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (tax.TaxInId === 2) {//Percent
                calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
            } else {
                calculatetax = parseFloat(itemTax);
            }
        }
    }
    else {
        if (linkTaxStructures.length > 0) {
            angular.forEach(linkTaxStructures, function (item) {
                if (tax.TaxOnTaxTypeId == item.TaxTypeId) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(item.TaxAmount) * parseFloat(itemTax) / 100;
                    } else {
                        calculatetax = parseFloat(itemTax);
                    }
                }
            });
        }
    }
    return parseFloat(calculatetax);
};

function IS_TAX_INCLUSIVE(model) {
    
    if (!model.IsTaxInclusive) {
        model.Amount = model.TotalAmount;
        //calculateRoomRateTax();
        return GET_TAX_STRUCTURE(model.LinkTaxStructures, model.Amount, model.Amount);
    }

    var i = 1;
    model.TaxAmount = 0;
    model.TotalAmount = 0;
    model.LinkTaxStructures = [];

    var chargeAmount = model.Amount;
    var totalTaxPercent = 0.0;

    if(!model.OnValue)
    {
        model.OnValue = model.Amount;
    }
    if(!model.OnDiscounted)
    {
        model.OnDiscounted = model.Amount;
    }
    
    var onValue = model.OnValue;
    var onDiscounted = model.OnDiscounted;

    var totalOnValuePercent = 0;

    var totalOnValuePercent = 0;
    var totalOnDiscountedPercent = 0;

    var TaxOnTaxTypeIds = GetDistinctTaxOnTaxTypeId(model.TaxStructure.LinkTaxStructures);
    angular.forEach(TaxOnTaxTypeIds, function (taxOnTaxTypeId) {
        var linkTaxStructures = model.TaxStructure.LinkTaxStructures.filter(x=>x.TaxOnTaxTypeId ==taxOnTaxTypeId );
        angular.forEach(linkTaxStructures, function (linkTaxStructure, index) {
            if (!linkTaxStructure.TaxOnTaxTypeId) {
                                    
                if (linkTaxStructure.IsSlab) {
                    if (parseFloat(linkTaxStructure.MinRange) <= parseFloat(onValue) && parseFloat(linkTaxStructure.MaxRange) >= parseFloat(onValue)) {
                        totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                    }
                }
                else {
                    totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                }
            }
            else {
                angular.forEach(model.TaxStructure.LinkTaxStructures, function (item) {
                    if (linkTaxStructure.TaxOnTaxTypeId == item.TaxTypeId) {
                        totalTaxPercent = parseFloat(totalTaxPercent) + ( (parseFloat(item.TaxValue) * parseFloat(linkTaxStructure.TaxValue))/ 100);
                    }
                });
            }
        });
    });

    var totalOnValue = (onValue * 100) / (100 + totalTaxPercent);
    //var totalOnValue = (onValue * 100) / (100 + totalOnValuePercent);
    var totalOnDiscounted = (onDiscounted * 100) / (100 + totalOnDiscountedPercent);

    var links = [];
    angular.forEach(model.TaxStructure.LinkTaxStructures, function (linkTaxStructure, index) {

        var tax = 0;
        if (!linkTaxStructure.TaxOnTaxTypeId) {
            if (linkTaxStructure.IsSlab) {
                if (parseFloat(linkTaxStructure.MinRange) <= parseFloat(chargeAmount) && parseFloat(linkTaxStructure.MaxRange) >= parseFloat(chargeAmount))
                    tax = (parseFloat(totalOnValue) * parseFloat(linkTaxStructure.TaxValue)) / 100;
            }
            else {
                tax = (parseFloat(totalOnValue) * parseFloat(linkTaxStructure.TaxValue)) / 100;
            }
        }
        else {
            if (links.length > 0) {
                angular.forEach(links, function (item) {
                    if (linkTaxStructure.TaxOnTaxTypeId == item.TaxTypeId) {
                        if (linkTaxStructure.TaxInId === 2) {//Percent
                            tax = parseFloat(item.TaxAmount) * parseFloat(linkTaxStructure.TaxValue) / 100;
                        } else {
                            tax = parseFloat(linkTaxStructure.TaxValue);
                        }
                    }
                });
            }
        }

        //tax = tax.ToString("0.##"));
        if(tax>0)
        {
            links.push({
                Id: linkTaxStructure.Id,
                TaxTypeId: linkTaxStructure.TaxTypeId,
                TaxOnId: linkTaxStructure.TaxOnId,
                IsTariffOn: linkTaxStructure.IsTariffOn,
                TaxInId: linkTaxStructure.TaxInId,
                TaxValue: linkTaxStructure.TaxValue,
                TaxAmount: tax,
            });
        }
        
    });

    model.LinkTaxStructures = [];

    //foreach (var link in links)
    model.TaxAmount =0.0;
    angular.forEach(links, function (link) {
        model.LinkTaxStructures.push(link);
        model.TaxAmount += link.TaxAmount;
    });

    model.OnValue = onValue;
    model.OnDiscounted = totalOnDiscounted - (onValue - totalOnValue);
    model.TotalAmount = onDiscounted;

    return model;

};

function GetDistinctTaxOnTaxTypeId(list) {
    var distinct = [];
    var newArr = list.filter(function (el) {
        if (distinct.indexOf(el.TaxOnTaxTypeId) === -1) {
            // If not present in array, then add it
            distinct.push(el.TaxOnTaxTypeId);  
            return true;
        }
        else {
            // Already present in array, don't add it
            return false;
        }
    });
    return distinct;
};

