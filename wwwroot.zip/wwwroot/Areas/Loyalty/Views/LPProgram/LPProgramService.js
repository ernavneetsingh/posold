﻿
app.service('LPProgramService', [
    '$http', '$q', function (
        $http, $q) {

        this.getAllDiscountType = function () {
            return httpCaller(apiPath + "ReferenceConstant/DiscountType/All", $http, $q);
        };
        this.getAllRoundOffType = function () {
            return httpCaller(apiPath + "ReferenceConstant/RoundOffType/All", $http, $q);
        };
        this.getAll = function (options) {
            return httpCaller(apiPath + "Loyalty/LPProgram/GetAll", $http, $q, options);
        };

        this.save = function (model) {
            return httpPoster(apiPath + "Loyalty/LPProgram/Save", $http, $q, model);
        };
        this.delete = function (id) {
            return httpCaller(apiPath + "Loyalty/LPProgram/Delete", $http, $q, { id: id });
        };
        this.changeStatus = function (model) {
            return httpPoster(apiPath + "Loyalty/LPProgram/Status", $http, $q, model);
        };

    }
]);
