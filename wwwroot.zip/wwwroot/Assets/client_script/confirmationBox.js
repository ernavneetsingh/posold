﻿//app.directive('ngReallyClick', [function () {
//    return {
//        restrict: 'A',
//        link: function (scope, element, attrs) {
//            element.bind('click', function () {
//                var message = attrs.ngReallyMessage;
//                if (message && confirm(message)) {
//                    scope.$apply(attrs.ngReallyClick);
//                }
//            });
//        }
//    }
//}]);

//app.directive('ngConfirmClick', [
//          function () {
//              return {
//                  link: function (scope, element, attr) {
//                      var msg = attr.ngConfirmClick || "Are you sure?";
//                      var clickAction = attr.confirmedClick;
//                      element.bind('click', function (event) {
//                          if (window.confirm(msg)) {
//                              scope.$eval(clickAction)
//                          }
//                      });
//                  }
//              };
//          }])



function alertMessage(confirmMsg) {
    $.fancybox({
        'modal': true,
        'content': "<div style=\"margin:1px;width:350px;text-align: center;padding: 13px 0 0 0;\"> " +
            confirmMsg
            + " <div style=\"text-align:center;margin-top:20px;\">" +
            "<input id=\"fancyconfirm_cancel\" class=\"fancyboxConfirmCancel\" type=\"button\" Value=\"Close\"></div></div>",
        'afterShow': function () {
            $("#fancyconfirm_cancel").click(function () {
                ret = false;
                $.fancybox.close();

                return ret;
            });
        }
    });

}

function alertErrorMessage(confirmMsg) {
    $.fancybox({
        'modal': true,
        'content': "<div style=\"margin:1px;width:350px;text-align: center;padding: 13px 0 0 0;\"> <p style=\"color:red\">Error: " +
            confirmMsg
            + "</p> <div style=\"text-align:center;margin-top:20px;\">" +
            "<input id=\"fancyconfirm_cancel\" class=\"fancyboxConfirmErrorCancel\" type=\"button\" Value=\"Close\"></div></div>",
        'afterShow': function () {
            $("#fancyconfirm_cancel").click(function () {
                ret = false;
                $.fancybox.close();
                return ret;
            });
        }
    });
}

function DeletePopup(confirmMsg) {
    var strPopUp = '';
    strPopUp = "<div style=\"margin:1px;width:350px;text-align: center;padding: 13px 0 0 0;\"> " +
            confirmMsg
            + " <div style=\"text-align:center;margin-top:20px;\">" +

            "<input id=\"fancyConfirm_ok\" class=\"fancyboxConfirmButton\" type=\"button\" Value=\"Ok\">" +
    "<input id=\"fancyconfirm_cancel\" class=\"fancyboxConfirmCancel\" type=\"button\" Value=\"Cancel\"></div></div>";
    return strPopUp;
}

function validateDateformat(varDate) {

    return jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "http://localhost:1487/Inventory/Setting/Globalvalidation.aspx/validateDate",
        data: "{'strDate':'" + varDate + "'}",
        dataType: "json",
        success: function (response) { },
        error: function (result) {

            alertMessage($.parseJSON(result.responseText).Message);

        }
    });
}
