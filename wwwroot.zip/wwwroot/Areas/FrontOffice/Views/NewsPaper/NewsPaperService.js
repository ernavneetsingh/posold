﻿

var propertyId;
var currentUser;
app.service("newsService", function () {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getNewspaperData = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/NewsPaper/all/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "FrontOffice/NewsPaper/all/" + propertyId,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.saveNewspaperData = function (newspaperData) {
        return httpPoster(apiPath + "FrontOffice/newspaper/create/modify", $http, $q, newspaperData);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/newspaper/create/modify",
        //    data: JSON.stringify(newspaperData),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.removeNewspaperData = function (newspaperData) {
        return httpPoster(apiPath + "FrontOffice/newspaper/remove/" + newspaperData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/newspaper/remove/" + newspaperData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.statusNewspaperData = function (newspaperData, currentUser) {
        return httpPoster(apiPath + "FrontOffice/newspaper/changestatus/" + currentUser + "/" + newspaperData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/newspaper/changestatus/" + currentUser + "/" + newspaperData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});

    };

    this.newspaperExists = function (propertyId, newspaperData, language) {
        return httpPoster(apiPath + "FrontOffice/NewsPaper/existcode/" + propertyId + "/" + newspaperData + "/" + language, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/NewsPaper/existcode/" + propertyId + "/" + newspaperData + "/" + language,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    }
        //    ,
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);

        //    }
        //});

    };


});
