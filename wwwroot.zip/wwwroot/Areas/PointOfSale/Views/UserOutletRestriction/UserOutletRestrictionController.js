﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        
        $scope.LoginId = $cookies.get('LoginId');

        
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            Name: '',
            UserId: '',
            UserName: '',
            FirstName: '',
            LastName: '',
            Email: '',
            IsActive: true,
            AuthorizationOptions: [],
            RestrictedOutlets: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: []
        };

        var sortKeyOrder = {
            key: "",
            order: "",
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;

        getData($scope, service, localStorageService);

        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);

        };
        //------------------------------------------------------

        $scope.Users = [];
        getUser();
        function getUser() {
            
            var promiseGet = service.GetUser($scope.PropertyID);
            promiseGet.then(function (data) {
                 
                $scope.Users = data;
            }, function (data) {
                
                msg(data.message);
            });
        }

        $scope.Outlets = [];
        getOutlets();
        function getOutlets() {
            
            var promiseGet = service.GetOutlets($scope.PropertyID);
            promiseGet.then(function (data) {
                
                $scope.Outlets = data;
            }, function (data) {
                
                msg(data.message);
            });
        }


        //checklist-model------------------------------------------------------------------------------------

        $scope.Outlets = [];
        $scope.SelectedOutlet = {
            Outlets: []
        };
        $scope.checkAllOutlet = function () {
            $scope.SelectedOutlet.Outlets = $scope.Outlets.map(function (item) { return item.Id; });
        };
        $scope.uncheckAllOutlet = function () {
            $scope.SelectedOutlet.Outlets = [];
        };
        $scope.checkFirstOutlet = function () {
            $scope.SelectedOutlet.Outlets.splice(0, $scope.SelectedOutlet.Outlets.length);
            $scope.SelectedOutlet.Outlets.push(1);
        };

        //end checklist-model------------------------------------------------------------------------------------

        //-----------------For Table----------------------------------------------------

        $scope.Model.RestrictedOutlets = [];
        $scope.isCheckedOutlet = function (id) {
            
            var match = false;
            for (var i = 0 ; i < $scope.Model.RestrictedOutlets.length; i++) {
                if ($scope.Model.RestrictedOutlets[i].Id == id) {
                    match = true;
                }
            }
            //$scope.rAll = $scope.Model.Outlets.length === $scope.Outlets.length;
            return match;
        };
        $scope.syncOutlet = function (bool, item) {
            
            if (bool) {
                $scope.Model.Outlets.push(item);
            } else {
                for (var i = 0 ; i < $scope.Model.Outlets.length; i++) {
                    if ($scope.Model.Outlets[i].Id == item.Id) {
                        $scope.Model.Outlets.splice(i, 1);
                    }
                }
            }
            $scope.rAll = $scope.Model.Outlets.length === $scope.Outlets.length;
        };
        $scope.checkedAllOutlet = function ($event) {
            
            if ($event.target.checked) {
                angular.forEach($scope.Outlets, function (itm) {
                    $scope.Model.Outlets.push({ Id: itm.Id });
                });
            }
            if (!$event.target.checked) {
                $scope.Model.Outlets = [];
            }
        };

        $scope.Save = function (model, form) {
            
            

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }

            
            
            $scope.Model.RestrictedOutlets = [];
            angular.forEach($scope.SelectedOutlet.Outlets, function (id, key) {
                $scope.Model.RestrictedOutlets.push(
                    {
                        Id: id,
                    });
            });

            
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.ModifiedBy;
            
            var status = service.save($scope.Model);

            status.then(function (result) {
                if (result.Status == true) {
                    
                    var msg1 = "Outlet Restriction " + result.Message;
                    msg(msg1, true);
                    //scrollPageOnTop();
                    getData($scope, service, localStorageService);
                }
                
                $scope.Reset();
                $scope.Model.RestrictedOutlets = [];
            }, function (error) {
                
                //scrollPageOnTop();
                msg(error.Message);
            });
        }
        $scope.Reset = function () {
            $scope.Model = {};
            $scope.Model.RestrictedOutlets = [];
            $scope.Model.AuthorizationOptions = [];
            $scope.SelectedOutlet.Outlets = [];
            $("#checkedAllOutlet").prop("checked", false);
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            $scope.Model.DiscountTypeId = "Amount";
            getData();
            scrollPageOnTop();
        }
        $scope.Edit = function (model) {
            
            
            $scope.Model.Id = model.Id;
            $scope.Model.UserId = model.Id.toString();
            $scope.Model.RestrictedOutlets = model.RestrictedOutlets;

            $scope.SelectedOutlet.Outlets = [];
            angular.forEach($scope.Model.RestrictedOutlets, function (item) {
                $scope.SelectedOutlet.Outlets.push(item.Id);
            });

            scrollPageOnTop();

        }
        $scope.IsUserExist = function (model) {
            
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.isUserExist($scope.PropertyID, model.UserId);
            promiseGet.then(function (data) {
            }, function (error) {
                
                $scope.Model.Code = "";
                msg(error.Message);
                //scrollPageOnTop();
            });
        };

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    
    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "UserName",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getData($scope.PropertyID, options)
        .then(function (totalItems) {
            
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        }, function () {
            msg("The request failed. Unable to connect to the remote server.");
        });

};
