﻿
"use strict";

app.controller("occupationController",
[
    "$scope", "occupationService", "localStorageService", "$cookies", function ($scope, occupationService, localStorageService, $cookies) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.Occupation = {};
        $scope.Occupation.IsActive = true;

        var sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;

        getData($scope, occupationService, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, occupationService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData($scope, occupationService, localStorageService);
        };

        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, occupationService, localStorageService);
        };
        $scope.recordsonpage = function (records) {

            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, occupationService, localStorageService);
        };
        $scope.editOccupation = function (item) {
            $scope.ActionMode = "Edit";
            $scope.Occupation = item;
            $scope.IsReadOnly = true;
            scrollPageOnTop();
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Occupation = {};
            $scope.IsReadOnly = false;
            $scope.Occupation.IsActive = true;
            $scope.search();
        };
        $scope.ShowErrorMessage = false;

        $scope.SaveOccupation = function (model, form) {

            if ($scope[form].$valid) {
                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.UserName;
                var promiseGet = occupationService.saveOccupation(model);
                promiseGet.then(function (data, status) {

                    getData($scope, occupationService, localStorageService);
                    $scope.reset();
                    parent.successMessage(data.Message);
                },
                    function (error, status) {

                        parent.failureMessage(error.Message);
                    });
            } else {
                $scope.ShowErrorMessage = true;
            }
            scrollPageOnTop();
        };
        $scope.removeOccupation = function (occupationId) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Occupation?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteOccupation = occupationService.deleteOccupation(occupationId);
                            deleteOccupation.then(function (data) {
                                getData($scope, occupationService, localStorageService);
                                if (data.Status) {
                                    parent.successMessage(data.Message);
                                }
                            }, function (err) {
                                parent.failureMessage(err.Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.changeOccupationStatus = function (occupationId) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var deleteOccupation = occupationService.updateOccupationStatus(occupationId, $scope.UserName);
            deleteOccupation.then(function (data) {

                getData($scope, occupationService, localStorageService);
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
                function (err) {

                    parent.failureMessage(err.Message);
                });
            scrollPageOnTop();
        };
    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };

    $scope.showLoader = true;
    dataService.getAllOccupation($scope.PropertyID, options)
        .then(function (totalItems) {

            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};
