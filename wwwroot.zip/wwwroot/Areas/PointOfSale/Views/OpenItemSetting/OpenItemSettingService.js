﻿
'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getData = function (propertyId) {

            var url = apiPath + "PointOfSale/OpenItemSetting/GetAllByPropertyId/?propertyId=" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var save = function (model) {
            
            var url = apiPath + 'PointOfSale/OpenItemSetting/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        var remove = function (propertyId, id) {
            var url = apiPath + 'PointOfSale/OpenItemSetting/delete/' + propertyId + "/" + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                msg(data.Message);
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {
            var url = apiPath + 'PointOfSale/OpenItemSetting/status';

            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var getOpenItemSetting = function (propertyId) {
            
            var url = apiPath + 'PointOfSale/OpenItemSetting/GetByPropertyId?propertyId=' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                deferred.resolve(result.Data);
            }).error(function (err) {
                
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetMenuGroup = function () {
            var url = apiPath + 'ReferenceConstant/MenuGroupType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllOutlet = function (propertyId) {
            var url = apiPath + 'PointOfSale/Outlet/allByPropertyIdmin/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllByOutletId = function (outletId, propertyId) {
            var url = apiPath + 'GlobalSetting/TaxStructure/GetAllByOutletId/' + outletId + "/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllByMenuGroupType = function (menuGroupTypeId, propertyId) {
            var url = apiPath + 'PointOfSale/MenuCategory/allByMenuGroupType/' + menuGroupTypeId + '/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetMenuSubCategory = function (menuCategoryId, propertyId) {
            var url = apiPath + 'PointOfSale/MenuSubCategory/allByMenuCategoryId/' + menuCategoryId + '/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var GetKitchen = function (propertyId) {
            var url = apiPath + 'PointOfSale/Kitchen/allByPropertyId/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        return {
            getData :getData ,
            save: save,
            remove:remove,
            statusChange:statusChange,
            getOpenItemSetting: getOpenItemSetting,
            GetMenuGroup: GetMenuGroup,
            getAllOutlet:getAllOutlet,
            getAllByOutletId: getAllByOutletId,
            getAllByMenuGroupType: getAllByMenuGroupType,
            GetMenuSubCategory: GetMenuSubCategory,
            GetKitchen: GetKitchen
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
