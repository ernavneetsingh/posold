﻿
'use strict';
app.controller('Controller', [
    '$scope', 'IndentService', '$cookies', '$filter', 'localStorageService', '$window',
    function ($scope, service, $cookies, $filter, localStorageService, $window) {

        $scope.LoginId = $cookies.get('LoginId');

        //setTimeout(function () {
        $scope.Status = "All";
        //}, 300);

        //Common
        $scope.CostCenters = [];
        $scope.getCostCenters = function () {
            service.getCostCenters($scope.PropertyID)
                .then(function (data) {
                    $scope.CostCenters = data.Collection;
                });
        };
        $scope.getCostCenters();

        $scope.myConfig = {
            valueField: "Id",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: false,
            maxItems: 1
        }

        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        }
        $scope.Clearmodel = function (list) {

            if (list) {
                $scope.getAll(6, 'All', 'All');
                return;
            }
            //$scope.model = {};
            $scope.model.IndentItems = [];
            $scope.IndentItem = {};
            $scope.IndentNumber = '';
            $scope.query = '';
            Reset();
        };

        //TAB: 1

        var pathServer = Path;
        // var pathServer = apiPath.substr(0, apiPath.indexOf('/api'));
        $scope.gridOptions = {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: {
                text: "Indent Details",
                style: 'headerStyle'
            },
            exporterPdfFooter: function (currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(),
                    style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22,
                    bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10,
                    bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {

                    if (row.isExpanded) {

                        row.entity.subGridOptions = {
                            columnDefs: [
                            {
                                name: 'StoreName'
                            },
                            {
                                name: 'InventoryItemName'
                            },
                            {
                                name: 'BrandName'
                            },
                            {
                                name: 'ItemTypeName'
                            },
                            {
                                name: 'Quantity',
                                cellClass: 'grid-align-center'
                            },
                             {
                                 name: 'UnitOfMeasurementName', displayName: 'UOM',
                                 cellClass: 'grid-align-right'
                             },
                             //{
                             //    name: 'CostCenterName'
                             //},
                            {
                                name: 'RequiredDate', cellFilter: 'date:' + $scope.DateFormat
                            }
                            ]
                        };
                        row.entity.subGridOptions.data = row.entity.IndentItems;

                    }
                });
            }

        }
        $scope.gridOptions.columnDefs = [
        {
            name: 'IndentNumber',
            pinnedLeft: true
        },
        {
            name: 'IndentDate', cellFilter: 'date:grid.appScope.DateFormat'
        },
        {
            name: 'CostCenterName'
        },
        {
            name: 'ApprovedByName'
        },
        {
            name: 'IndentStatusTypeName', displayName: 'Status'
        }
        ];

        $scope.getAll = function (statusTypeId, searchText, searchType) {
            service.getAll($scope.PropertyID, statusTypeId, searchText, searchType)
                .then(function (result) {
                    $scope.items = result.Collection;
                    $scope.search();
                });
        };
        $scope.getAll(6, 'All', 'All');

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {

            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "CostCenterName" || attr === "IndentNumber" || attr === "IndentDate") {
                        var dd = item[attr];
                        if (dd == null || dd === 'undefined' || dd === '') {
                        } else {
                            if (searchMatch(item[attr], $scope.query))
                                return true;
                        }
                    }
                }
                return false;

            });
            $scope.gridOptions.data = $scope.filteredItems;
            if ($scope.filteredItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
            } else {
                $scope.MsgNotFound = "";
            }
        };

        //TAB: 2 Create Indent

        $scope.isCreateIndent = true;
        $scope.clickCopyButton = function () {
            $scope.isCreateIndent = false;
            if ($scope.IndentNumber != undefined && $scope.IndentNumber != null && $scope.IndentNumber != "") {
                $scope.showErrorCopyMsg = false;
            } else {
                $scope.showErrorCopyMsg = true;
            }
        };

        $scope.GetItemSearch = function (txt) {
            service.getItemSearch(txt, $scope.PropertyID);
        };
        $scope.GetIndentSearch = function (txt) {
            service.getIndentSearch(6, txt, $scope.PropertyID);// 6 for All in POStatus
        };

        $scope.Reasons = [];
        GetReason();
        function GetReason() {

            var promiseGet = service.getReasons($scope.PropertyID, 5);
            promiseGet.then(function (data) {

                $scope.Reasons = data.Collection;
            }, function (data) {
                parent.failureMessage(data.message);
                scrollpageontop();
            });
        };

        $scope.Save = function (formName) {

            if ($scope.IndentNumber == "No Records Found") {
                $scope.IndentNumber = "";
            }

            if (formName == 'modifyForm') {
                if (angular.isUndefined($scope.IndentNumber) || $scope.IndentNumber === "" || $scope.IndentNumber === null) {
                    parent.failureMessage("Please Select Indent Number.");
                    scrollpageontop();
                    return;
                }
            }

            if (formName == 'createForm') {
                if ($scope.model.IndentItems.length === 0) {
                    parent.failureMessage("Please Select Item.");
                    scrollPageOnTop();
                    return;
                }
            }

            if ((!$scope.model.CostCenterId) || $scope.model.CostCenterId.length < 0) {
                parent.failureMessage("Please Select Cost Center.");
                scrollPageOnTop();
                return;
            }

            for (var g = 0; g < $scope.model.IndentItems.length; g++) {

                if (!$scope.model.IndentItems[g].Quantity || $scope.model.IndentItems[g].Quantity <= 0) {
                    parent.failureMessage("Invalid item quantity.");
                    scrollPageOnTop();
                    return;
                }

                //$scope.RequiredDate = new Date($scope.model.IndentItems[g].RequiredDate);
                //if ($scope.IndentDate > $scope.RequiredDate) {
                if ($scope.model.IndentDate > $scope.model.IndentItems[g].RequiredDate) {
                    parent.failureMessage("Required Date should not be less then Indent Create Date.");
                    scrollPageOnTop();
                    return;
                }
            }

            if (formName == 'createForm') {
                $scope.model.Id = null;
            }
            else {
                if (angular.isUndefined($scope.model.ReasonId) || $scope.model.ReasonId === "" || $scope.model.ReasonId === null) {
                    parent.failureMessage("Please Select Reason.");
                    scrollPageOnTop();
                    return;
                }
            }

            if (!$scope[formName].$valid) {
                $scope.showErrorMsg = true;
            } else {

                $scope.model.PropertyID = $scope.PropertyID;
                $scope.model.ModifiedBy = $scope.ModifiedBy;
                $scope.IsSaving = true;

                var promiseGet = service.save($scope.model);
                promiseGet.then(function (d) {

                    parent.successMessage("Indent successfully saved.");
                    service.MapReport($scope.PropertyID, 'indent')
                             .then(function (s) {
                                 var m1 = d.Message.split(" ");
                                 //var idx = m1.indexOf("and");
                                 var pid = //idx > 0 ? m1[idx - 1] :
                                     m1.pop();
                                 var m2 = m1.join(' ');
                                 //if (idx > 0) m2 = m2.replace(pid, "");

                                 fancyPrintConfirm(m2, $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid);
                             }, function (e) {
                                 msg('Error in mapping to print.');
                             });
                    Reset();
                    scrollPageOnTop();

                },
                function (xhr) {
                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                })
                .finally(function () {
                    $scope.IsSaving = false;
                });
            }
            scrollPageOnTop();
        };
        $scope.getDuplicateItem = function (item, index) {//Id, brandId, costCenterId, index) {

            var itemId = item.InventoryItemId;
            var brandId = item.BrandId;
            var costCenterId = item.CostCenterId;
            $scope.GetAmount();
            service.getItemStock($scope.PropertyID, itemId, brandId, $scope.model.IndentDate)
                .then(function (result) {

                    item.QuantityAvailable = result.Data;

                });
            //service.getItemAverageConsumption($scope.PropertyID, itemId, brandId)
            //    .then(function (result) {

            //        item.AverageConsumption = result.Data;

            //    });
            if (!index) return;

            for (var i = 0; i < $scope.model.IndentItems.length; i++) {
                if (index != i) {
                    if (($scope.model.IndentItems[i].InventoryItemId.length > 0) && ($scope.model.IndentItems[i].BrandId.length > 0) && ($scope.model.IndentItems[i].CostCenterId.length > 0)) {
                        if ($scope.model.IndentItems[i].InventoryItemId === itemId && $scope.model.IndentItems[i].BrandId === brandId && $scope.model.IndentItems[i].CostCenterId === costCenterId) {
                            parent.failureMessage("Same Item with duplicate Brand and Cost Center.");
                            item.CostCenterId = "";
                            //$scope.model.IndentItems[index].CostCenterId = "";
                            scrollPageOnTop();
                            break;
                        }
                    }
                }
            }
        }
        $scope.RemoveCreate = function (index) {
            $scope.model.IndentItems.splice(index, 1);
            $scope.GetAmount(index);
        };

        Reset();
        function Reset() {

            $scope.model = {
                Id: '',
                IndentDate: $scope.ModifiedDate,
                IndentNumber: '',
                POStatusType: '',
                POStatusTypeId: 6,
                POStatusTypeName: '',
                PaymentTerms: '',
                Remarks: '',
                ApplyDiscount: '',
                TotalAmount: 0,
                TotalTax: 0,
                TotalDiscount: 0,
                GrossAmount: 0,
                RequiredDate: '',
                ReasonId: '',
                ReasonName: '',
                ModificationRemarks: '',
                IsApproved: '',
                ApprovedBy: '',
                ApprovedByName: '',
                ApprovedDate: '',
                IndentItems: [],
                PropertyID: '',
                ModifiedBy: '',
                DateFormat: '',
                items: []
            };
            //$scope.model = {};
            //$scope.model.IndentItems = [];
            $scope.model.PODate = $scope.ModifiedDate;// $filter('date')(date, $scope.DateFormat);
            $scope.Indents = [];
            $scope.IndentItems = [];

            $scope.AuthorizationIndents = [];
            $scope.model.Remarks = "";
            $("#authorizationSearch").val("");

            $scope.IndentNumber = "";
            $scope.Search = "";

            scrollPageOnTop();
        }
        $scope.GetAmount = function (index) {

            angular.forEach($scope.model.IndentItems, function (item, i) {

                //if (item.Discount == undefined) {
                //    item.Discount = 0;
                //}

                //if (i === index) {

                //$scope.Model.ApplyDiscount = "";
                //if (item.DiscountInId == '2') {
                //    if (parseFloat(item.Discount) > 100) {
                //        parent.failureMessage(item.InventoryItemName + " Percent(%) value can not be more then 100");
                //        item.Discount = 0.00;
                //        scrollPageOnTop();
                //    }
                //} else {

                //    var itemvalue = item.Amount.toString();
                //    itemvalue = replaceAll(itemvalue, ',', '');

                //    if (parseFloat(item.Discount) > parseFloat(itemvalue)) {
                //        parent.failureMessage(item.InventoryItemName + " discount value can not be more then " + item.Amount);
                //        item.Discount = 0.00;
                //        scrollPageOnTop();
                //    }
                //}

                //if (item.DiscountInId == '2') {
                //    item.DiscountAmount = parseFloat(item.Rate) * parseFloat(item.Quantity) * item.Discount * 0.01;
                //}
                //else {
                //    item.DiscountAmount = item.Discount;
                //}
                item.Amount = parseFloat(item.Rate) * parseFloat(item.Quantity);//- parseFloat(item.DiscountAmount);
                item.Amount = $filter('number')(parseFloat(item.Amount), 2);
                //}
            });

            $scope.Index = index;
            //$scope.CalculateTAX($scope.Model.PurchaseOrderItems);
            $scope.CalculateTotal();
        }
        $scope.CalculateTotal = function () {

            var totalDiscount = 0.00;
            //var totalTaxAmount = 0.00;
            var grossAmount = 0.00;
            var netAmount = 0.00;

            angular.forEach($scope.model.IndentItems, function (item) {

                var amount = item.Amount.toString();
                amount = replaceAll(amount, ',', '');

                //var discount = item.Discount.toString();
                //discount = replaceAll(discount, ',', '');

                //var taxAmount = item.TaxAmount ? item.TaxAmount.toString() : "0";
                //taxAmount = replaceAll(taxAmount, ',', '');

                //if (item.DiscountInId === '2') {

                //    totalDiscount += parseFloat((parseFloat(amount) * parseFloat(discount)) / 100);

                //}
                //else {
                //    totalDiscount += parseFloat(discount);

                //}

                grossAmount += parseFloat(amount);
                //totalTaxAmount += parseFloat(taxAmount);

            });

            //netAmount = grossAmount + totalTaxAmount - totalDiscount;

            //$scope.Model.TotalAmount = $filter('number')(parseFloat(netAmount), 2).replace(/,/g, '');
            //$scope.Model.TotalTax = $filter('number')(parseFloat(totalTaxAmount), 2).replace(/,/g, '');
            //$scope.Model.TotalDiscount = $filter('number')(parseFloat(totalDiscount), 2).replace(/,/g, '');
            $scope.model.GrossAmount = $filter('number')(parseFloat(grossAmount), 2).replace(/,/g, '');

        };

        //----for Tab-3-----

        $scope.GetItemSearch1 = function (txt) {
            service.getItemSearch1(txt, $scope.PropertyID);
        };
        $scope.GetIndentSearchMO = function (txt) {
            service.getIndentSearchMO(3, txt, $scope.PropertyID);   // 3 for Pending in POStatus
        };

        //------For Tab-4-------

        $scope.GetIndentSearchCancel = function (txt) {

            service.getIndentSearchCancel(3, txt, $scope.PropertyID);   // 3 for Pending in POStatus
        };
        $scope.CancelIndent = function (formName) {

            if (angular.isUndefined($scope.IndentNumber) || $scope.IndentNumber === "" || $scope.IndentNumber === null) {
                parent.failureMessage("Please Select Indent Number.");
                scrollpageontop();
                return;
            }

            if (angular.isUndefined($scope.model.ReasonId) || $scope.model.ReasonId === "" || $scope.model.ReasonId === null) {
                parent.failureMessage("Please Select Reason.");
                scrollPageOnTop();
                return;
            }

            if ($scope[formName].$valid) {

                $scope.model.PropertyID = $scope.PropertyID;
                $scope.model.ModifiedBy = $scope.ModifiedBy;

                var promiseGet = service.cancelIndent($scope.model);
                promiseGet.then(function (details) {
                    parent.successMessage("Indent canceled successfully.");
                    Reset();
                    scrollPageOnTop();

                }, function (xhr) {
                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };

        //----For Tab-5----

        $scope.GetIndentSearchClose = function (txt) {
            service.getIndentSearchClose(4, txt, $scope.PropertyID);    // 4 for partial in POStatus
        };
        $scope.CloseIndent = function (formName) {
            if (angular.isUndefined($scope.IndentNumber) || $scope.IndentNumber === "" || $scope.IndentNumber === null) {
                parent.failureMessage("Please Select IndentNumber.");
                scrollPageOnTop();
                return;
            }
            if (angular.isUndefined($scope.model.ReasonId) || $scope.model.ReasonId === "" || $scope.model.ReasonId === null) {
                parent.failureMessage("Please Select Reason.");
                scrollPageOnTop();
                return;
            }

            if ($scope[formName].$valid) {

                $scope.model.PropertyID = $scope.PropertyID;
                $scope.model.ModifiedBy = $scope.ModifiedBy;
                //$scope.model.DateFormat = $scope.DateFormat;

                var promiseGet = service.closeIndent($scope.model);
                promiseGet.then(function (details) {

                    parent.successMessage("Indent Closed successfully.");
                    Reset();
                    scrollPageOnTop();
                },
                function (xhr) {

                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };

        //---For Tab-6-----

        $scope.AuthorizationIndents = [];

        $scope.checkAllAuthorizationPO = function () {
            if ($scope.selectedAllAuthorization) {
                angular.forEach($scope.Indents, function (value, key) {
                    value.IsApproved = true;
                    $scope.AuthorizationIndents.push(value);
                });
                $scope.selectedAllAuthorization = true;
            } else {
                angular.forEach($scope.Indents, function (value, key) {
                    value.IsApproved = false;
                });
                $scope.AuthorizationIndents = [];
                $scope.selectedAllAuthorization = false;
            }
        };

        $scope.toggleSelection = function (itm) {
            var idx = $scope.AuthorizationIndents.indexOf(itm);
            if (idx > -1) {
                $scope.AuthorizationIndents.splice(idx, 1);
            } else {
                $scope.AuthorizationIndents.push(itm);
            }
        };

        $scope.GetIndentSearchAuthorized = function (txt) {
            // 3 for Pending in POStatus
            service.getIndentSearchAuthorized(3, txt, $scope.PropertyID);
        };

        $scope.Indents = [];

        $scope.GetUnauthorizedList = function () {
            $scope.Indents = [];
            $scope.model.IndentItems = [];

            var promiseGet = service.getUnauthorizedList($scope.PropertyID);
            promiseGet.then(function (data) {


                $scope.Indents = data;
            },
            function (data) {
                parent.failureMessage(data.message);
                scrollpageontop();
            });
        };

        $scope.SaveAuthorization = function () {

            if ($scope.model.Remarks == undefined)
                $scope.model.Remarks = "";

            if ($scope.AuthorizationIndents.length == 0) {
                parent.failureMessage("Please select at least one Indent.");
                scrollpageontop();
                return;
            }

            angular.forEach($scope.AuthorizationIndents, function (value, key) {
                value.ModificationRemarks = $scope.model.Remarks;
                value.ApprovedDate = $scope.ModifiedDate;
                value.PropertyID = $scope.PropertyID;
                value.ModifiedBy = $scope.ModifiedBy;
            });

            var promiseGet = service.saveAuthorization($scope.AuthorizationIndents);
            promiseGet.then(function (details) {
                msg("Authorization successfully saved.", true);
                //parent.successMessage("Authorization successfully saved.");
                //scrollpageontop();
                $scope.GetUnauthorizedList();
                Reset();

            }, function (xhr) {
                var errorMessage = $.parseJSON(xhr.responseText);
                msg(errorMessage.Message);
                //parent.failureMessage(errorMessage.Message);
                //scrollPageOnTop();
            });
            scrollPageOnTop();
        };


    }]);
