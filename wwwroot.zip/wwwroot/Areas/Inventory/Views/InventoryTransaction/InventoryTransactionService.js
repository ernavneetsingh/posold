﻿
app.service("inventoryTransactionService", function ($q, $http) {

    this.getTaxStructures = function (propertyId, active, moduleId) {
        var params = { propertyId: propertyId, active: active, moduleId: moduleId };
        return httpCaller(apiPath + "GlobalSetting/TaxStructure/all", $http, $q, params);
    };
    this.getCostCenters = function (propertyId) {
        var params = { propertyId: propertyId, active: 1 };
        return httpCaller(apiPath + "GlobalSetting/CostCenter/all", $http, $q, params);
    };
    this.getVendors = function (propertyId) {
        var params = { propertyId: propertyId, searchValue: '', active: 1 };
        return httpCaller(apiPath + "Inventory/Vendor/all", $http, $q, params);
    };
    this.getReasons = function (propertyId, moduleId, date) {
        var params = { propertyId: propertyId, moduleId: moduleId, active: 1, date: date };
        return httpCaller(apiPath + "GlobalSetting/Reason/all", $http, $q, params);
    };
    this.getItems = function (propertyId, searchTxt, itemType) {
        var params = { searchTxt: searchTxt, propertyId: propertyId, itemType: itemType };
        return httpCaller(apiPath + "Inventory/InventoryItem/AllBySearchTxt", $http, $q, params);
    };
    this.GetItemById = function (propertyId, itemId) {
        var params = { propertyId: propertyId, id: itemId };
        return httpCaller(apiPath + "Inventory/InventoryItem/GetItemById/", $http, $q, params);
    };
    this.getPOs = function (propertyId, searchTxt) {
        var params = { propertyId: propertyId, poStatusTypeId: 34, poNumber: searchTxt };
        return httpCaller(apiPath + "Inventory/PurchaseOrder/GetByMultiStatus", $http, $q, params);
    };

    this.getPendingPoItems = function (propertyId, poId) {
        var params = { propertyId: propertyId, poId: poId };
        return httpCaller(apiPath + "Inventory/PurchaseOrder/GetPendingPoItems", $http, $q, params);
    };
    this.getGRN = function (propertyId, dateFormat, vendorId) {
        var params = { propertyId: propertyId, vendorId: vendorId };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/getGRN", $http, $q, params);
    };
    this.getByGRNumber = function (propertyId, all, grn, pending, date) {
        var params = { propertyId: propertyId, all: all, grn: grn, pending: pending, date: date };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/getByGRN", $http, $q, params);
    };
    this.getByReference = function (propertyId, all, ref) {
        var params = { propertyId: propertyId, all: all, reference: ref };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/getByReference", $http, $q, params);
    };
    this.getBrands = function (propertyId, all) {
        var params = { propertyId: propertyId, all: all };
        return httpCaller(apiPath + "GlobalSetting/brand/all", $http, $q, params);
    };

    this.getAll = function (propertyId, dateFormat, all) {
        var params = { propertyId: propertyId, all: all };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/all/", $http, $q, params);
    };
    this.getAllItemStock = function (propertyId, date) {
        var params = { propertyId: propertyId, date: date };
        return httpCaller(apiPath + "Inventory/InventoryTransactionItem/stock/", $http, $q, params);
    };
    this.getItemStock = function (propertyId, itemId, brandId, date) {
        var params = { propertyId: propertyId, date: date, itemId: itemId, brandId: brandId };
        return httpCaller(apiPath + "Inventory/InventoryTransactionItem/Stock", $http, $q, params);
    };

    this.get = function (propertyId, dateFormat, id) {
        var params = { propertyId: propertyId, id: id };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/get/", $http, $q, params);

    };
    this.getByItem = function (propertyId, operationType, itemId) {
        var params = { propertyId: propertyId, operationType: operationType, itemId: itemId };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/getByItem/", $http, $q, params);
    };
    this.getItemsToIssue = function (propertyId, itemId, brandId, qty) {
        var params = { propertyId: propertyId, itemId: itemId, brandId: brandId, qty: qty };
        return httpCaller(apiPath + "Inventory/InventoryTransactionItem/GetItemsToIssue", $http, $q, params);
    };

    this.save = function (model) {
        var params = { model: model };
        return httpPoster(apiPath + "Inventory/InventoryTransaction/Save", $http, $q, model);
    };
    this.delete = function (propertyId, id) {
        var params = { propertyId: propertyId, id: id };
        return httpCaller(apiPath + "Inventory/InventoryTransaction/delete", $http, $q, params);
    };

    this.getAllIndents = function (propertyId, statusTypeId, searchText, searchType) {
        return httpCaller(apiPath + "Inventory/Indent/all/", $http, $q, { propertyId: propertyId, statusTypeId: statusTypeId, searchText: searchText, searchType: searchType, takeDisplay: true });
    };

    this.MapReport = function (filterValue, reportName) {
        return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
    };
    this.send = function (propertyId, id, sms) {
        return httpPoster(apiPath + "Inventory/InventoryTransaction/Send", $http, $q, { propertyId: propertyId, id: id, sms: sms });
    };
    this.saveFromExcel = function (fd, waiter) {

        var deferred = $q.defer();
        $http.post(apiPath + 'Inventory/InventoryTransaction/SaveFromExcel', fd, {
            withCredentials: false,
            headers: { 'Content-Type': undefined, 'duxtechApiKey': accessToken },
            transformRequest: angular.identity
        }).then(function (d) {

            waiter.IsUploadingExcel = false;
            msg(d.data.Message, d.data.Status);
            deferred.resolve(d.data);
        }).catch(function (e) {

            waiter.IsUploadingExcel = false;
            msg('Upload upto ' + (e.data ? e.data.Message : ''));
            deferred.reject(e.data);
        });
        return deferred.promise;

    }
});
