﻿
app.controller('controller', ['$scope', 'service', 'localStorageService', function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = false;

    var sortKeyOrder = {
        key: '',
        order: '',
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 10;
    $scope.recordsPerPage = 20;
    $scope.numberOfPageButtons = 10;
    $scope.ShowErrorMessage = false;

    getData($scope, service, localStorageService);

    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get('sortKeyOrder');
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == 'ASC')
                sortKeyOrder.order = 'DESC';
            else
                sortKeyOrder.order = 'ASC';
            localStorageService.set('sortKeyOrder', sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: 'ASC'
            };
            localStorageService.set('sortKeyOrder', sortKeyOrder);
        }
    };

    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };

    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    }

    $scope.ChangeStatus = function (model) {
        var promiseGet = service.changeStatus(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.ChangeApproved = function (model) {
        
        var promiseGet = service.changeApproved(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.ChangeLocked = function (model) {
        var promiseGet = service.changeLocked(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

    $scope.Model = {};
    $scope.SelectUserProduct = function (userProduct) {
        

        var promiseGet = service.getGetById(userProduct.Id);
        promiseGet.then(function (data) {
            $scope.Model = data.Data;
        },
                function (error) {
                    msg(error.Message);
                });

        scrollPageOnTop();
    };


    $scope.Save = function (model, form) {

        
        if ($scope[form].$valid) {
            $scope.showLoader2 = true;
            var promiseGet = service.save($scope.Model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);

                parent.successMessage(data.Message);
                $scope.Model = {};
                
                scrollPageOnTop();
            },
            function (data, status, headers, config) {
                parent.failureMessage(data.Message);
            });
        } else {
            $scope.ErrorMessage = true;
            scrollPageOnTop();
        }
    };


}]);


var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get('sortKeyOrder');
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: 'UserName',
            order: 'ASC'
        };
    }

    var searchfor = localStorageService.get('searchfor');
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };

    $scope.showLoader = true;
    dataService.getAll(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
        $scope.showLoader = false;
    },
    function () {
        alert("The request failed. Unable to connect to the remote server.");
    });

};