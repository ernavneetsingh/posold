﻿
app.controller('HelpController', [
    '$scope', 'HelpService', '$window', 'localStorageService', function (
        $scope, helpService, $window, localStorageService) {

        $scope.UserProductPageId = localStorageService.get('UserProductPageId');// //$scope.parameters['uppi'];//  //readParam($scope, $window);
        $scope.IsHelpNotModal = true;
        if (!$scope.UserProductPageId)
            msg('UserProductPageId not available');
        else
            helpService.getPageHelp($scope.UserProductPageId)
                .then(function (s) {
                    $scope.ModulePageHelpList = s.Collection;
                    $scope.ModulePageName = s.Collection && s.Collection.length > 0 ? s.Collection[0].ModulePageName : '';
                    $scope.ModulePageModuleName = s.Collection && s.Collection.length > 0 ? s.Collection[0].ModulePageModuleName : '';
                });

    }
]);
