﻿
app.controller("FOMapController",
[
    "$scope", "FOMapService", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');

        $scope.IsShowUnMapped = false;
        $scope.myPageConfig = {
            valueField: "Name",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: true,
            maxItems: 1
        };

        $scope.Model = {};

        $scope.Model.Systems = [];
        $scope.Model.TaxTypes = [];
        $scope.Model.Settlements = [];
        $scope.Model.UserDefineds = [];
        $scope.Model.Advances = [];
        $scope.Model.Outlets = [];
        $scope.Model.Laundrys = [];
        $scope.Model.AddOnCharges = [];

        $scope.Groups = [];

        $scope.Groups.push({ Id: '1', Code: '1', Name: 'Reservation' });
        $scope.Groups.push({ Id: '2', Code: '2', Name: 'CheckIN' });
        $scope.Groups.push({ Id: '3', Code: '3', Name: 'ChargePost' });
        $scope.Groups.push({ Id: '4', Code: '4', Name: 'Settlement' });
        $scope.Groups.push({ Id: '5', Code: '5', Name: 'Employee' });
        $scope.Groups.push({ Id: '6', Code: '6', Name: 'Outlet' });
        $scope.Groups.push({ Id: '7', Code: '7', Name: 'Laundry' });
        $scope.Groups.push({ Id: '8', Code: '8', Name: 'Outsider'});

        $scope.getFOMap = function () {
            
            //$scope.Model = {};
            $scope.Model.Systems = [];
            $scope.Model.TaxTypes = [];
            $scope.Model.Settlements = [];
            $scope.Model.UserDefineds = [];
            $scope.Model.Advances = [];
            $scope.Model.Outlets = [];
            $scope.Model.Laundrys = [];
            $scope.Model.AddOnCharges = [];
            service.getFOMap($scope.GroupId,$scope.PropertyID)
            .then(function (data, status) {
                $scope.Model = data.Data;
            });
        };

        $scope.AccountDumps = [];
        $scope.getAccountDump = function () {
            $scope.AccountDumps = [];
            service.getAccountDump($scope.PropertyID)
                .then(function (data, status) {
                    $scope.AccountDumps = data.Collection;
                });
        };
        $scope.getAccountDump();
        
        $scope.SetIsShow = function () {
            angular.forEach($scope.Model.ItemCategorys, function (item) {
                if ($scope.IsShowUnMapped)
                {
                    if(!item.AccountName || !item.AllowanceAccountName)
                    {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else
                    {
                        item.IsShow = false;
                    }
                }
                else
                {
                    item.IsShow = true;
                }
            })
            angular.forEach($scope.Model.TaxTypes, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.Vendors, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }
            })
            angular.forEach($scope.Model.CostCenters, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
            angular.forEach($scope.Model.AddOnCharges, function (item) {
                if ($scope.IsShowUnMapped) {
                    if (!item.AccountName || !item.AllowanceAccountName) {
                        item.IsShow = $scope.IsShowUnMapped;
                    }
                    else {
                        item.IsShow = false;
                    }
                }
                else {
                    item.IsShow = true;
                }

            })
        }

        $scope.Save = function () {
            
            $scope.Model.GroupId = $scope.GroupId;
            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;

            service.save($scope.Model)
                .then(function (result) {
                    if (result.Status == true) {
                        msg(result.Message, true);
                    }
                    $scope.SetIsShow();
                    $scope.Reset();
                }, function (error) {
                    msg(error.Message);
                });
        }

        $scope.Reset = function () {
            $scope.Model = {};
        }
    }
]);
