﻿"use strict";


(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        //var model = [];

        var getAll = function (profileid) {

            var url = apiPath + "configuration/User/all/" + profileid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllProducts = function (propertyId) {
            var url = apiPath + 'configuration/product/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllCountry = function () {
            var url = apiPath + 'referencedata/country';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,                
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
      
        function getAllState(id) {
            var url = apiPath + 'referencedata/state/' + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var changeStatus = function (id) {
            
            var url = apiPath + 'configuration/user/status/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var changeApproved = function (id) {
            
            var url = apiPath + 'configuration/user/approved/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        var changeLocked = function (id) {
            
            var url = apiPath + 'configuration/user/locked/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isEmailExist = function (model) {
            
            var url = apiPath + 'configuration/user/email/exist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isMobileExist = function (model) {
            
            var url = apiPath + 'configuration/user/mobile/exist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var save = function (module) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: apiPath + 'security/registration',
                data: module,
                  headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        return {           
            getAll: getAll,
            save:save,
            getAllProducts: getAllProducts,
            getAllCountry: getAllCountry,
            getAllState: getAllState,
            changeStatus: changeStatus,
            changeApproved: changeApproved,
            changeLocked: changeLocked,
            isMobileExist: isMobileExist,
            isEmailExist: isEmailExist
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();


















































