﻿
(function () {

    function invoiceInitialService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var _invoiceInitialData = [];

        var getAllinvoiceInitial = function (propertyId, options) {

            var url = apiPath +
                    "GlobalSetting/invoiceInitial/details/" +
                    propertyId +
                    "/?currentPage=" +
                    options.currentPage +
                    "&" +
                    "recordsPerPage=" +
                    options.recordsPerPage +
                    "&" +
                    "sortKey=" +
                    options.sortKeyOrder.key +
                    "&" +
                    "sortOrder=" +
                    options.sortKeyOrder.order +
                    "&searchfor=" +
                    options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, _invoiceInitialData);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllinvoiceInitialConfiguration = function (propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "referencedata/InvoiceCode",
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var saveinvoiceInitial = function (module) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/invoiceInitial/create",
                data: module,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        var updateinvoiceInitialStatus = function (invoiceInitialId, userName) {

            var url = apiPath + "GlobalSetting/invoiceInitial/status/" + invoiceInitialId + "?userName=" + userName;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var deleteinvoiceInitial = function (invoiceInitialId) {

            var url = apiPath + "GlobalSetting/invoiceInitial/remove/" + invoiceInitialId;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getinitialcode = function (propertyId, invoiceInitialId) {
            //var params = { propertyId: propertyId, invoiceInitialId: invoiceInitialId };
            return httpCaller(apiPath + "GlobalSetting/invoiceInitial/getinitialcode/" + propertyId + "/" + invoiceInitialId, $http, $q);
        };

        return {
            getAllinvoiceInitialConfiguration: getAllinvoiceInitialConfiguration,
            dataAllData: _invoiceInitialData,
            getAllinvoiceInitial: getAllinvoiceInitial,
            updateinvoiceInitialStatus: updateinvoiceInitialStatus,
            deleteinvoiceInitial: deleteinvoiceInitial,
            saveinvoiceInitial: saveinvoiceInitial,
            getinitialcode: getinitialcode
        };
    }

    app.factory("invoiceInitialService", ["$http", "$q", invoiceInitialService]);
})();
