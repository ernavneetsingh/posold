﻿
'use strict';
(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var alldata = [];

        var getData = function (propertyId, options) {

            var url = apiPath + "PointOfSale/POSItem/all/" + propertyId + "?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order +
                "&searchfor=" + options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                //deferred.resolve(result.Collection);
                angular.copy(result.Collection, alldata);
                deferred.resolve(result.RecordCount);

            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getGetById = function (id, propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/POSItem/getById/" + id)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getTaxStructure = function (propertyId) {

            var url = apiPath + 'GlobalSetting/TaxStructure/3/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getCourseMealType = function () {

            var url = apiPath + 'ReferenceConstant/CourseMealType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getMenuGroupType = function () {

            var url = apiPath + 'ReferenceConstant/ItemGroupType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getMenuCategory = function (menuGroupTypeId, propertyId) {

            var url = apiPath + 'PointOfSale/MenuCategory/allByMenuGroupType/' + menuGroupTypeId + "/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getMenuSubCategory = function (menuCategoryId, propertyId) {

            var url = apiPath + 'PointOfSale/MenuSubCategory/allByMenuCategoryId/' + menuCategoryId + "/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getUnitOfMeasurement = function (propertyId) {

            var url = apiPath + 'GlobalSetting/UnitOfMeasurement/all/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getKitchen = function (propertyId) {

            var url = apiPath + 'PointOfSale/Kitchen/allByPropertyId/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getMenuCard = function (propertyId) {

            var url = apiPath + 'PointOfSale/MenuCard/allByPropertyId/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getModifierGroup = function (propertyId) {

            var url = apiPath + 'PointOfSale/ModifierGroup/allByPropertyId/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getStore = function (propertyId) {

            var url = apiPath + 'Inventory/Store/all/?propertyId=' + propertyId + '&active=1';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getInventoryItem = function (id, propertyId) {

            var url = apiPath + 'Inventory/InventoryItem/all/' + propertyId + "/" + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getOutlet = function (propertyId) {

            var url = apiPath + 'PointOfSale/Outlet/allByPropertyIdmin/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getRelatedUnitOfMeasurement = function (id, propertyId) {

            var url = apiPath + 'GlobalSetting/UnitOfMeasurement/GetRelated/' + propertyId + "/" + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {

            var url = apiPath + 'PointOfSale/POSItem/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        var status = function (model) {
            return httpPoster(apiPath + "PointOfSale/POSItem/Status", $http, $q, model);
        }
        var remove = function (id) {
            return httpPoster(apiPath + "PointOfSale/POSItem/delete/" + id, $http, $q);
        }

        var saveFromExcel = function (fd, waiter) {

            var deferred = $q.defer();
            $http.post(apiPath + 'PointOfSale/POSItem/SaveFromExcel', fd, {
                withCredentials: false,
                headers: { 'Content-Type': undefined, 'duxtechApiKey': accessToken },
                transformRequest: angular.identity
            }).then(function (d) {

                waiter.IsUploadingExcel = false;
                msg(d.data.Message, d.data.Status);
                deferred.resolve(d.data);
            }).catch(function (e) {
                
                waiter.IsUploadingExcel = false;
                msg('Upload upto ' + (e.data ? e.data.Message : ''));
                deferred.reject(e.data);
            });
            return deferred.promise;

        }

        return {
            alldata: alldata,
            getGetById: getGetById,
            getData: getData,
            getTaxStructure: getTaxStructure,
            getCourseMealType: getCourseMealType,
            getMenuGroupType: getMenuGroupType,
            getMenuCategory: getMenuCategory,
            getMenuSubCategory: getMenuSubCategory,
            getUnitOfMeasurement: getUnitOfMeasurement,
            getKitchen: getKitchen,
            getMenuCard: getMenuCard,
            getModifierGroup: getModifierGroup,
            getStore: getStore,
            getInventoryItem: getInventoryItem,
            getOutlet: getOutlet,
            getRelatedUnitOfMeasurement: getRelatedUnitOfMeasurement,
            save: save,
            status: status,
            remove: remove,
            saveFromExcel: saveFromExcel

        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
