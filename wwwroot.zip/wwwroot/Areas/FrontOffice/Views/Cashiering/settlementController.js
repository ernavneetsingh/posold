﻿
app.controller("settlementController", [
    "$scope", "settlementService", "service", "$cookies", "$filter", "$timeout", "$window", "localStorageService", function ($scope, settlementService, service, $cookies, $filter, $timeout, $window, localStorageService) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.UserName = $cookies.get('UserName');

        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month, $scope.BusinessDate.Day);

        $scope.IsProgress = false;
        $scope.SettlementDetailSelect = {
            RevenueHeadCode: 'CSH',
            NoOfCheckINGuest: 0
        };

        $scope.Model = {

            ModuleId: 1,
            OutletId: outlet,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName,
            BusinessDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
            DateFormat: $scope.DateFormat,
        };

        $scope.Settlement = {
            Id: '',
            SettlementDate: '',
            ModuleId: '',
            ModuleName: '',
            BillId: '',
            CustomerName: '',
            RoomNumber: '',
            MobileNo: '',
            Email: '',
            TotalNetAmount: 0,
            BalanceAmount: 0,

            BillNo: '',
            BillDate: '',
            TableId: '',

            TableName: '',


            SettlementDetails: []
        };

        $scope.SettlementDetail = {
            SNo: 1,
            SettlementId: '',
            RevenueHeadId: '',
            RevenueHeadName: '',
            RevenueHeadCode: '',
            Amount: 0,
            Remark: '',
            TipAmount: 0,
            CreditCardNumber: '',
            CreditCardNetworkId: '',
            CreditCardNetworkName: '',
            GuestName: '',
            CorporateId: '',
            CorporateCode: '',
            CorporateName: '',
            ChequeNo: '',
            BankName: '',
            BankBranch: '',
            CheckINGuestId: '',
            CheckINGuestName: '',
            CheckINGuestRoom: '',
            CheckINGuestMobile: '',
            AuthorizedBy: '',
            CouponType: '',
            CouponId: '',
            NCDepartmentId: '',
            NCDepartmentName: '',
            CurrencyId: '',
            CurrencyCode: '',
            CurrencyName: '',
            ExchangeRate: '',
            CurrencyAmount: '',
            CurrencyPaidOut: '',
        };

        $scope.KOTBills = [];
        $scope.SettlementModes = [];

        $scope.GetAllBillByStatus = function (status) {

            if (status == "Pending") {
                $scope.Model.BillStatusId = 3;  //Pending 
            }
            else {
                $scope.Model.BillStatusId = 1;  //Settlement 
            }

            $scope.IsLoading = true;
            var promiseGet = settlementService.getAllBillByStatus($scope.Model);

            promiseGet.then(function (data) {

                $scope.KOTBills = data.Collection;
                $scope.IsLoading = false;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                });
        }
        $scope.GetBill = function (bill) {

            if (bill.BillStatusId == 1) {
                parent.posFailureMessage("Bill is already Settled.");
                scrollPageOnTop();
                return;
            }

            $scope.IsLoading = true;
            $scope.Settlement = {};
            $scope.SettlementDetail = {};
            $scope.SettlementDetailSelect = {};
            $scope.Settlement.SettlementDetails = [];

            var promiseGet = service.getKOTBillById(bill.Id, $scope.PropertyID);
            promiseGet.then(function (data) {
                var kotbill = data.Data;

                $scope.Settlement = {
                    Id: '',
                    SettlementDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
                    ModuleId: '',
                    ModuleName: '',
                    BillId: kotbill.Id,
                    CustomerName: kotbill.CustomerName,
                    RoomNumber: kotbill.RoomNo,
                    MobileNo: '',
                    Email: '',
                    TotalNetAmount: kotbill.TotalNetAmount,
                    BalanceAmount: 0,
                    BillNo: kotbill.BillNo,
                    BillDate: $filter('date')(kotbill.BillDate, $scope.DateFormat),
                    TableId: kotbill.TableId,
                    TableName: kotbill.TableName,
                    SettlementDetails: []
                };

                //set CASH as default
                $scope.SettlementDetail = {
                    SNo: 1,
                    SettlementId: '',
                    RevenueHeadId: '',
                    RevenueHeadName: 'Cash',
                    RevenueHeadCode: 'CSH',
                    Amount: kotbill.TotalNetAmount,
                    Remark: '',
                    TipAmount: 0,
                    CreditCardNumber: '',
                    CreditCardNetworkId: '',
                    CreditCardNetworkName: '',
                    GuestName: '',
                    CorporateId: '',
                    CorporateCode: '',
                    CorporateName: '',
                    ChequeNo: '',
                    BankName: '',
                    BankBranch: '',
                    CheckINGuestId: '',
                    CheckINGuestName: '',
                    CheckINGuestRoom: '',
                    CheckINGuestMobile: '',
                    AuthorizedBy: '',
                    CouponType: '',
                    CouponId: '',
                    NCDepartmentId: '',
                    NCDepartmentName: '',
                    CurrencyId: '',
                    CurrencyCode: '',
                    CurrencyName: '',
                    ExchangeRate: '',
                    CurrencyAmount: '',
                    CurrencyPaidOut: '',
                };

                $scope.Settlement.SettlementDetails.push($scope.SettlementDetail);

                $scope.Total();

                $scope.IsLoading = false;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                });

        }
        $scope.Total = function () {

            $scope.Settlement.SettlementAmount = 0;
            $scope.Settlement.BalanceAmount = 0;

            if ($scope.Settlement.SettlementDetails.length > 0) {
                angular.forEach($scope.Settlement.SettlementDetails, function (item) {

                    if (item.Amount > 0) {
                        $scope.Settlement.SettlementAmount = parseFloat($scope.Settlement.SettlementAmount) + parseFloat(item.Amount);
                    }
                });
            }

            $scope.Settlement.BalanceAmount = parseFloat($scope.Settlement.TotalNetAmount) - parseFloat($scope.Settlement.SettlementAmount)
        }
        $scope.GetBalanceAmount = function (changeamount) {

        }

        $scope.GetAllSettlementMode = function () {
            GetAllSettlementMode();
        };
        GetAllSettlementMode();
        function GetAllSettlementMode() {

            $scope.IsLoading = true;
            var promiseGet = settlementService.getAllSettlementMode($scope.PropertyID, outlet, 5);
            promiseGet.then(function (data) {

                $scope.SettlementMode = data.Data;
                $scope.IsLoading = false;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                });
        }


        $scope.Save = function () {
            if ($scope.Settlement.BillId == undefined || $scope.Settlement.BillId == "" || $scope.Settlement.BillId == null) {
                parent.posFailureMessage("Please Select Bill for Settlement.");
            }
            $scope.Settlement.ModuleId = $scope.ModuleId;
            $scope.Settlement.PropertyID = $scope.PropertyID;
            $scope.Settlement.ModifiedBy = $scope.UserName;
            $scope.IsProgress = true;
            var promiseGet = settlementService.saveSettlement($scope.Settlement);
            promiseGet.then(function (data) {
                removeTableList($scope.BillList, $scope.Settlement.BillId);
                //Table Vacant
                if ($scope.Settlement.TableId) {
                    angular.forEach($scope.Tables, function (table, index) {
                        if (table.Id == $scope.Settlement.TableId) {
                            table.KOTStatusId = 0;//VACANT
                            $scope.Tables[index] = table;
                            $scope.VacantTables.push(table);
                        }
                    });
                }

                $scope.IsProgress = false;
                parent.posSuccessMessage("successfully saved.");

                $scope.Settlement = {};

                angular.forEach($scope.KOTBills, function (item) {
                    if (item.Id == $scope.Settlement.BillId) {
                        item.BillStatusId = 1;  //Settlement
                    }
                })


            },
                function (error) {
                    $scope.IsProgress = false;
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });

        };

        function removeTableList(tables, tableId) {
            angular.forEach(tables, function (b, index) {
                if (tableId == b.Id) {
                    tables.splice(index, 1);
                }
            });
        };

        $scope.SaveSettlementDetail = function () {

            if ($scope.SettlementDetailSelect.SNo != 0 && $scope.SettlementDetailSelect.SNo != undefined) {
                if ($scope.Settlement.SettlementDetails.length > 0) {
                    angular.forEach($scope.Settlement.SettlementDetails, function (item) {
                        if ($scope.SettlementDetailSelect.SNo == item.SNo) {

                            item.SNo = $scope.SettlementDetailSelect.SNo;
                            item.SettlementId = $scope.SettlementDetailSelect.SettlementId;
                            item.RevenueHeadId = $scope.SettlementDetailSelect.RevenueHeadId;
                            item.RevenueHeadName = $scope.SettlementDetailSelect.RevenueHeadName;
                            item.RevenueHeadCode = $scope.SettlementDetailSelect.RevenueHeadCode;
                            item.Amount = $scope.SettlementDetailSelect.Amount;
                            item.Remark = $scope.SettlementDetailSelect.Remark;
                            item.TipAmount = $scope.SettlementDetailSelect.TipAmount;
                            item.CreditCardNumber = $scope.SettlementDetailSelect.CreditCardNumber;
                            item.CreditCardNetworkId = $scope.SettlementDetailSelect.CreditCardNetworkId;
                            item.CreditCardNetworkName = $scope.SettlementDetailSelect.CreditCardNetworkName;
                            item.GuestName = $scope.SettlementDetailSelect.GuestName;
                            item.CorporateId = $scope.SettlementDetailSelect.CorporateId;
                            item.CorporateCode = $scope.SettlementDetailSelect.CorporateCode;
                            item.CorporateName = $scope.SettlementDetailSelect.CorporateName;
                            item.ChequeNo = $scope.SettlementDetailSelect.ChequeNo;
                            item.BankName = $scope.SettlementDetailSelect.BankName;
                            item.BankBranch = $scope.SettlementDetailSelect.BankBranch;
                            item.CheckINGuestId = $scope.SettlementDetailSelect.CheckINGuestId;
                            item.CheckINGuestName = $scope.SettlementDetailSelect.CheckINGuestName;
                            item.CheckINGuestRoom = $scope.SettlementDetailSelect.CheckINGuestRoom;
                            item.CheckINGuestMobile = $scope.SettlementDetailSelect.CheckINGuestMobile;
                            item.AuthorizedBy = $scope.SettlementDetailSelect.AuthorizedBy;
                            item.CouponType = $scope.SettlementDetailSelect.CouponType;
                            item.CouponId = $scope.SettlementDetailSelect.CouponId;
                            item.NCDepartmentId = $scope.SettlementDetailSelect.NCDepartmentId;
                            item.NCDepartmentName = $scope.SettlementDetailSelect.NCDepartmentName;
                            item.CurrencyId = $scope.SettlementDetailSelect.CurrencyId;
                            item.CurrencyCode = $scope.SettlementDetailSelect.CurrencyCode;
                            item.CurrencyName = $scope.SettlementDetailSelect.CurrencyName;
                            item.ExchangeRate = $scope.SettlementDetailSelect.ExchangeRate;
                            item.CurrencyAmount = $scope.SettlementDetailSelect.CurrencyAmount;
                            item.CurrencyPaidOut = $scope.SettlementDetailSelect.CurrencyPaidOut;

                        }
                    });
                }
            }
            else {
                var max = 1;
                angular.forEach($scope.Settlement.SettlementDetails, function (item) {
                    if (max < item.SNo) {
                        max = item.SNo;
                    }
                });
                max = max + 1;
                $scope.SettlementDetailSelect.SNo = max;
                $scope.SettlementDetailSelect.RevenueHeadName = $scope.GetRevenueName($scope.SettlementDetailSelect.RevenueHeadCode);
                $scope.Settlement.SettlementDetails.push($scope.SettlementDetailSelect);
            }

            $scope.Total();
            $scope.Reset();
        };
        $scope.GetSettlementDetail = function (sno, code) {
            if ($scope.Settlement.SettlementDetails.length > 0) {
                //$scope.Settlement.SettlementAmount = 0;
                angular.forEach($scope.Settlement.SettlementDetails, function (item) {

                    if (sno == item.SNo) {
                        $scope.SettlementDetailSelect = {

                            SNo: item.SNo,
                            SettlementId: item.SettlementId,
                            RevenueHeadId: item.RevenueHeadId,
                            RevenueHeadName: item.RevenueHeadName,
                            RevenueHeadCode: item.RevenueHeadCode,
                            Amount: item.Amount,
                            Remark: item.Remark,
                            TipAmount: item.TipAmount,
                            CreditCardNumber: item.CreditCardNumber,
                            CreditCardNetworkId: item.CreditCardNetworkId,
                            CreditCardNetworkName: item.CreditCardNetworkName,
                            GuestName: item.GuestName,
                            CorporateId: item.CorporateId,
                            CorporateCode: item.CorporateCode,
                            CorporateName: item.CorporateName,
                            ChequeNo: item.ChequeNo,
                            BankName: item.BankName,
                            BankBranch: item.BankBranch,
                            CheckINGuestId: item.CheckINGuestId,
                            CheckINGuestName: item.CheckINGuestName,
                            CheckINGuestRoom: item.CheckINGuestRoom,
                            CheckINGuestMobile: item.CheckINGuestMobile,
                            AuthorizedBy: item.AuthorizedBy,
                            CouponType: item.CouponType,
                            CouponId: item.CouponId,
                            NCDepartmentId: item.NCDepartmentId,
                            NCDepartmentName: item.NCDepartmentName,
                            CurrencyId: item.CurrencyId,
                            CurrencyCode: item.CurrencyCode,
                            CurrencyName: item.CurrencyName,
                            ExchangeRate: item.ExchangeRate,
                            CurrencyAmount: item.CurrencyAmount,
                            CurrencyPaidOut: item.CurrencyPaidOut,

                        };
                    }
                });
            }
        };
        $scope.Delete = function (sno) {
            var index = 0;
            angular.forEach($scope.Settlement.SettlementDetails, function (item, key) {
                if (sno == item.SNo) {
                    index = key;
                }
            });

            $scope.Settlement.SettlementDetails.splice(index, 1);
            $scope.Total();
        };
        $scope.Reset = function () {
            //$scope.SettlementDetailSelect = {};
            //var sno = $scope.SettlementDetailSelect.SNo;
            var revenueHeadCode = $scope.SettlementDetailSelect.RevenueHeadCode;
            $scope.SettlementDetailSelect = {};
            $scope.SettlementDetailSelect.SNo = 0;
            $scope.SettlementDetailSelect.RevenueHeadCode = revenueHeadCode;
        };

        $scope.CRD = {};
        $scope.GetCRD = function (sno) {

            angular.forEach($scope.Settlement.SettlementDetails, function (item) {
                if (sno == item.SNo) {

                    $scope.CRD.SNo = item.SNo;
                    $scope.CRD.SettlementId = item.SettlementId;
                    $scope.CRD.RevenueHeadId = item.RevenueHeadId;
                    $scope.CRD.RevenueHeadName = item.RevenueHeadName;
                    $scope.CRD.RevenueHeadCode = item.RevenueHeadCode;
                    $scope.CRD.Amount = item.Amount;
                    $scope.CRD.Remark = item.Remark;
                    $scope.CRD.TipAmount = item.TipAmount;
                    $scope.CRD.CreditCardNumber = item.CreditCardNumber;
                    $scope.CRD.CreditCardNetworkId = item.CreditCardNetworkId;
                    $scope.CRD.CreditCardNetworkName = item.CreditCardNetworkName;
                    $scope.CRD.GuestName = item.GuestName;
                    $scope.CRD.CorporateId = item.CorporateId;
                    $scope.CRD.CorporateCode = item.CorporateCode;
                    $scope.CRD.CorporateName = item.CorporateName;
                    $scope.CRD.ChequeNo = item.ChequeNo;
                    $scope.CRD.BankName = item.BankName;
                    $scope.CRD.BankBranch = item.BankBranch;
                    $scope.CRD.CheckINGuestId = item.CheckINGuestId;
                    $scope.CRD.CheckINGuestName = item.CheckINGuestName;
                    $scope.CRD.CheckINGuestRoom = item.CheckINGuestRoom;
                    $scope.CRD.CheckINGuestMobile = item.CheckINGuestMobile;
                    $scope.CRD.AuthorizedBy = item.AuthorizedBy;
                    $scope.CRD.CouponType = item.CouponType;
                    $scope.CRD.CouponId = item.CouponId;
                    $scope.CRD.NCDepartmentId = item.NCDepartmentId;
                    $scope.CRD.NCDepartmentName = item.NCDepartmentName;
                    $scope.CRD.CurrencyId = item.CurrencyId;
                    $scope.CRD.CurrencyCode = item.CurrencyCode;
                    $scope.CRD.CurrencyName = item.CurrencyName;
                    $scope.CRD.ExchangeRate = item.ExchangeRate;
                    $scope.CRD.CurrencyAmount = item.CurrencyAmount;
                    $scope.CRD.CurrencyPaidOut = item.CurrencyPaidOut;

                }
            });
        };
        $scope.CRDConfirm = function () {


        }

        $scope.SetRevenueHead = function (mode) {
            
            $scope.SettlementDetailSelect = {};
            $scope.SettlementDetailSelect.RevenueHeadCode = mode.RevenueHeadCode;
            $scope.SettlementDetailSelect.RevenueHeadName = mode.RevenueHeadName;
            $scope.SettlementDetailSelect.Amount = $scope.Settlement.BalanceAmount;
            $scope.SettlementDetailSelect.SNo = 0;

            if (code == 'GUST') {
                $scope.GetOccupiedRooms();
            }
            else if (code == 'COM') {
                $scope.GetCorporate();
            }
            
        };
        $scope.GetRevenueName = function (code) {
            var revenueHeadCode = '';
            angular.forEach($scope.SettlementMode.SettlementModeDetails, function (item) {

                if (code == item.RevenueHeadCode) {
                    revenueHeadCode = item.RevenueHeadName;
                }
            });
            return revenueHeadCode;
        };

        $scope.Corporates = [];
        $scope.GetCorporate = function () {
            
            var promiseGet = settlementService.getCorporate($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Corporates = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });

            $scope.GetOccupiedRooms();
            $scope.GetCurrency();
        };
        $scope.GetOccupiedRooms = function () {

            var promiseGet = settlementService.getOccupiedRooms($scope.PropertyID, $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day);
            promiseGet.then(function (data) {
                $scope.OccupiedRooms = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        };
        $scope.CheckINGuests = [];
        $scope.GetCheckINGuest = function (roomId) {

            $scope.CheckINGuests = [];
            angular.forEach($scope.OccupiedRooms, function (item) {

                if (roomId == item.RoomMasterId) {
                    $scope.CheckINGuests = angular.copy(item.CheckINGuests);

                }
            });
        };
        $scope.Currencys = [];
        $scope.GetCurrency = function () {

            var promiseGet = settlementService.getCurrency();
            promiseGet.then(function (data) {
                $scope.Currencys = data.Collection;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                    scrollPageOnTop();
                });
        };
        $scope.GetCheckINGuestDetail = function (checkINGuestId) {

            $scope.CheckINGuest = {};
            angular.forEach($scope.CheckINGuests, function (item) {
                if (checkINGuestId == item.Id) {

                    $scope.SettlementDetailSelect.GuestName = item.Name;

                    $scope.SettlementDetailSelect.CheckINGuestId = item.Id;
                    $scope.SettlementDetailSelect.CheckINGuestCheckINNo = item.CheckINNo;
                    $scope.SettlementDetailSelect.CheckINGuestFolio = item.FolioNo;
                    $scope.SettlementDetailSelect.CheckINGuestName = item.Name;
                    $scope.SettlementDetailSelect.CheckINGuestRoom = item.CheckINGuestRoom.RoomNumber;

                    $scope.SettlementDetailSelect.BillingInstructionName = item.BillingInstructionName;
                    $scope.SettlementDetailSelect.SpecialInstructions = item.SpecialInstructions;

                }
            });
        };
     
    }
]);
