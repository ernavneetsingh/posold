﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.CurrentDate = $filter("date")(new Date(), $scope.DateFormat);

        $scope.Model = {
            Id: '',
            Name: '',
            Description: '',
            Price: '',
            IsActive: true,
            ModifierGroups: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: [],
            items: []
        };

        $scope.IsReadonly = false;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {

                for (var attr in item) {
                    if (attr === "Code" || attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {

            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {

                   msg(data.message);
               });

        };

        //checklist-model------------------------------------------------------------------------------------

        $scope.ModifierGroups = [];
        $scope.SelectedModifierGroup = {
            ModifierGroups: []
        };
        $scope.checkAllModifierGroup = function () {
            $scope.SelectedModifierGroup.ModifierGroups = $scope.ModifierGroups.map(function (item) { return item.Id; });
        };
        $scope.uncheckAllModifierGroup = function () {
            $scope.SelectedModifierGroup.ModifierGroups = [];
        };
        $scope.checkFirstModifierGroup = function () {
            $scope.SelectedModifierGroup.ModifierGroups.splice(0, $scope.SelectedModifierGroup.ModifierGroups.length);
            $scope.SelectedModifierGroup.ModifierGroups.push(1);
        };

        //end checklist-model------------------------------------------------------------------------------------

        getModifierGroup();
        $scope.ModifierGroups = [];
        function getModifierGroup() {
            $scope.SelectedModifierGroup.ModifierGroups = [];
            var promiseGet = service.getModifierGroupItem($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.ModifierGroups = data.Collection;
                //$scope.CheckedModels = [];
            }, function (error) {
                msg(error.data.Message);
                scrollPageOnTop();
            });
        };

        $scope.isCheckedModifiers = function (id) {

            var match = false;
            for (var i = 0 ; i < $scope.Model.ModifierGroups.length; i++) {
                if ($scope.Model.ModifierGroups[i].Id === id) {
                    match = true;
                }
            }
            return match;
        };
        $scope.syncModifiers = function (bool, item) {

            if (bool) {
                $scope.Model.ModifierGroups.push(item);
            } else {
                for (var i = 0 ; i < $scope.Model.ModifierGroups.length; i++) {
                    if ($scope.Model.ModifierGroups[i].Id == item.Id) {
                        $scope.Model.ModifierGroups.splice(i, 1);
                    }
                }
            }
        };

        $scope.Save = function (model, form) {
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }

            model.ModifierGroups = [];
            angular.forEach($scope.SelectedModifierGroup.ModifierGroups, function (id, key) {
                model.ModifierGroups.push(
                    {
                        Id: id,
                    });
            });

            if (model.ModifierGroups.length === 0) {
                msg("Please Select at least one Modifier Group.");
                scrollPageOnTop();
                return;
            }

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;


            var status = service.save(model);
            status.then(function (result) {
                
                if (result.Status == true) {
                    var msg1 = model.Name + ' ' + result.Data.Message;
                    msg(msg1, result.Status);
                    getData();
                    scrollPageOnTop();
                }
                $scope.Reset();
            }, function (error) {

                scrollPageOnTop();
                msg(error.Message);
            });
        }
        $scope.Reset = function () {
            $scope.Model.ModifierGroups = [];
            $scope.SelectedModifierGroup.ModifierGroups = [];

            $scope.Model = {};
            $scope.Model.ModifierGroups = [];
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            $scope.query = "";
            getData();
            scrollPageOnTop();
        }
        $scope.Edit = function (model) {

            $scope.Model = angular.copy(model);

            //$scope.Model.Id = model.Id;
            //$scope.Model.Name = model.Name;
            //$scope.Model.Description = model.Description;
            //$scope.Model.Price = model.Price;

            //$scope.Model.ModifierGroups = [];
            //angular.forEach(model.ModifierGroups, function (itm) {
            //    $scope.Model.ModifierGroups.push({ Id: itm.Id });
            //});
            $scope.SelectedModifierGroup.ModifierGroups = [];
            angular.forEach($scope.Model.ModifierGroups, function (item) {
                $scope.SelectedModifierGroup.ModifierGroups.push(item.Id);
            });
            $scope.Model.ModifierGroups = [];

            $scope.IsReadonly = true;
            $scope.Model.IsActive = model.IsActive;
            scrollPageOnTop();
        }
        $scope.Remove = function (model) {

            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {


                            parent.successMessage("Record Successfully deleted.");

                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                msg(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.IsNameExist = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.isNameExist($scope.PropertyID, model.Name);
            promiseGet.then(function (data) {
            },
                function (error) {

                    $scope.Model.Name = "";
                    msg("Modifier Name already Exists");
                    scrollPageOnTop();
                });
        };

    }
]);
