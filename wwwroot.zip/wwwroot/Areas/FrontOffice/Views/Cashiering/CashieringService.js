﻿
app.service('CashieringService', [
    "$http", "$q", function (
        $http, $q) {

        //TODO: Navneet2.0
        this.getOccupiedRoomsNew = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuestRoom/GetCheckINGuestRoom?propertyId=" + propertyId, $http, $q, {});
        };

        //TODO: Navneet2.0
        this.GetCheckINGuestCashiering = function (checkINGuestId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetCheckINGuestCashiering?checkINGuestId=" + checkINGuestId, $http, $q, {});
        };

        this.GetAllCheckINGuest = function (roomMasterId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetAllCheckINGuest?roomMasterId=" + roomMasterId, $http, $q, {});
        };

        this.GetFPCashiering = function (propertyId) {
            return httpCaller(apiPath + "Banquet/FunctionProspectus/GetFPCashiering/" + propertyId, $http, $q, {});
        };

        this.GetFPById = function (id) {
            return httpCaller(apiPath + "Banquet/FunctionProspectus/GetById", $http, $q, { id: id });
        };

        this.GetBillByFunctionProspectusId = function (id,businessDate) {
            return httpCaller(apiPath + "Banquet/BanquetBill/GetBillByFunctionProspectusId/" + id +"/" + businessDate, $http, $q, {  });
        };

        this.BanquetBillPostRevenue = function (model, error_suppress) {
            return httpPoster(apiPath + "Banquet/BanquetBill/PostRevenue", $http, $q, model, error_suppress);
        };
        this.GetBanquetCancelBill = function (eventId) {
            return httpCaller(apiPath + "Banquet/BanquetBill/Cancel", $http, $q, { reservationId: reservationId, billStatusId: 3 });
        };

        //TODO: NAVNEET
        this.getOccupiedRooms1 = function (propertyId, error_suppress) {
            var model = { PropertyID: propertyId }
            return httpPoster(apiPath + "FrontOffice/RoomChart/GetRoomChartCheckINGuest", $http, $q, model, error_suppress);
        };

        this.getOccupiedRooms = function (propertyId, date) {
            return httpCaller(apiPath + "FrontOffice/RoomStatus/GetAllByOccupiedRoom", $http, $q, { propertyId: propertyId, businessDate: date });
        };

        this.getReservations = function (model) {
            return httpPoster(apiPath + "FrontOffice/Reservation/SearchExact", $http, $q, model);
        };
        this.getMiscellaneousOld = function (propertyId, date) {
            return httpCaller(apiPath + "FrontOffice/RevenuePost/GetAllByChargePostToByDate", $http, $q, { propertyId: propertyId, chargePostToId: 7, date: date });
        };

        //this.getMiscellaneous = function (propertyId, date) {
        //    return httpCaller(apiPath + "FrontOffice/ChargePost/GetAllByPropertyId", $http, $q, { propertyId: propertyId, date: date });
        //};

        this.getMiscellaneous = function (propertyId, date) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetAllByPropertyId?propertyId=" + propertyId + "&chargePostTypeId=4" + "&postDate=" + date, $http, $q, {});
        };
        this.getHotelPaidOUT = function (propertyId, date) {

            return httpCaller(apiPath + "FrontOffice/ChargePost/GetAllHotelPaidOUTByPropertyId?propertyId=" + propertyId + "&postDate=" + date, $http, $q, {});
        };

        this.getRevenueHeadList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/RevenueHead/details/" + propertyId, $http, $q);
        };
        this.getCurrencyList = function () {
            return httpCaller(apiPath + "referencedata/currency", $http, $q);
        };
        this.getDefaultSettings = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/DefaultSetting/Details/" + propertyId, $http, $q);
        };

        this.getTaxStructure = function (id) {
            return httpCaller(apiPath + "GlobalSetting/TaxStructure/Get", $http, $q, { id: id });
        };

        this.getFOTaxStructures = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/TaxStructure/all", $http, $q, { propertyId:propertyId, active:1, moduleId: 1 });
        };

        this.getTaxStructureByRevenue = function (propertyId, revenueHeadCode, revenuePostId, id) {
            return httpCaller(apiPath + "GlobalSetting/TaxStructure/GetByRevenue", $http, $q, { propertyId: propertyId, revenueHeadCode: revenueHeadCode, revenuePostId: revenuePostId, id: id });
        };
        this.getGuestHistory = function (propertyId, guestId) {
            return httpCaller(apiPath + "FrontOffice/Guest/GetById/" + guestId, $http, $q);
        };

        //this.getTaxAmount = function (taxStructureId, netAmount, discountAmount, isInclusive) {
        //    return httpPoster(apiPath + "GlobalSetting/TaxStructure/GetTaxAmount", $http, $q, { Id: taxStructureId, NetAmount: netAmount, DiscountAmount: discountAmount, IsInclusive: isInclusive });
        //};

        this.IsNewReference = function (propertyId, reference) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/IsNewReference", $http, $q, { propertyId: propertyId, reference: reference });
        };
        this.save = function (model, error_suppress) {
            return httpPoster(apiPath + "FrontOffice/ChargePost/Save", $http, $q, model, error_suppress);
        };
        this.saveMulti = function (model) {
            return httpPoster(apiPath + "FrontOffice/ChargePost/SaveMulti", $http, $q, model);
        };
        this.getTransactions = function (propertyId, chargePostToId, chargePostId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetAllByChargePostTo", $http, $q, { propertyId: propertyId, chargePostToId: chargePostToId, chargePostId: chargePostId });
        };

        this.getReceiptList = function (propertyId, chargePostToId, chargePostId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetReceipts", $http, $q, { propertyId: propertyId, chargePostToId: chargePostToId, chargePostId: chargePostId });
        };
        this.getBillList = function (propertyId, chargePostId, revenueHeadId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetBills", $http, $q, { propertyId: propertyId, chargePostToId: 1, chargePostId: chargePostId, revenueHeadId: revenueHeadId });
        };
        this.getBillTotal = function (propertyId, chargePostId, revenueHeadId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetBillTotal", $http, $q, { propertyId: propertyId, chargePostToId: 1, chargePostId: chargePostId, revenueHeadId: revenueHeadId });
        };
        this.GetById = function (id) {
            
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetById", $http, $q, { id: id });
        };

        this.GetByChargePostDetailId = function (chargePostDetailId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetByChargePostDetailId", $http, $q, { chargePostDetailId: chargePostDetailId });
        };

        this.deleteTransaction = function (model) {
            return httpPoster(apiPath + "FrontOffice/ChargePost/Remove", $http, $q, model);
        };

        //this.getSetup = function (propertyId) {
        //    return httpCaller(apiPath + "FrontOffice/CheckIN/GetSetup/" + propertyId, $http, $q);
        //};


        //TODO: Navneet2.0
        this.GetConstantByPropertyId = function (propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckIN/GetConstantByPropertyId/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        //TODO: Navneet2.0
        this.GetSetup = function (propertyId, id) {
            return httpCaller(apiPath + "FrontOffice/CheckIN/GetSetup/" + propertyId, $http, $q);
        };



        this.saveSplitFolio = function (models) {

            var url = apiPath + 'FrontOffice/CheckINGuest/ChangeFolio';
            var deferred = $q.defer();
            $http({
                dataType: 'json',
                method: 'POST',
                url: url,
                data: JSON.stringify(models),
                headers: {
                    "Content-Type": "application/json"
                }
                //headers: { 'duxtechApiKey': accessToken },
                //contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        this.savePAXCheckOUT = function (models) {

            var url = apiPath + 'FrontOffice/CheckINGuest/PAXCheckOUT';
            var deferred = $q.defer();
            $http({
                dataType: 'json',
                method: 'POST',
                url: url,
                data: JSON.stringify(models),
                headers: {
                    "Content-Type": "application/json"
                }
                //headers: { 'duxtechApiKey': accessToken },
                //contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        this.getReason = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/Reason/AllByModuleId", $http, $q, { propertyId: propertyId, moduleId: 1 });
        };

        this.saveTransferRevenue = function (model) {
            return httpPoster(apiPath + "FrontOffice/RevenuePost/TransferRevenue", $http, $q, model);
        };

        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        this.getRevenuePost = function (propertyId, chargePostId, chargePostToId) {
            return httpCaller(apiPath + "FrontOffice/RevenuePostGroup/GetAllRevenuePostByGroup", $http, $q, { propertyId: propertyId, chargePostId: chargePostId, chargePostToId: chargePostToId });
        };
        this.getCheckOUT = function(propertyId, checkINGuestRoomId, businessDate, functionProspectusId) {

            if (!functionProspectusId) {
                return httpCaller(apiPath + "FrontOffice/CheckOUT/GetByCheckINGuestRoomId", $http, $q, { propertyId: propertyId, checkINGuestRoomId: checkINGuestRoomId, businessDate: businessDate });
            }
            else {
                return httpCaller(apiPath + "FrontOffice/CheckOUT/GetByFunctionProspectusId", $http, $q, { functionProspectusId: functionProspectusId });
            }
        };
        
        this.GetReservationCancelBill = function (reservationId) {
            return httpCaller(apiPath + "FrontOffice/FOBill/GetAllReservationCancelBill", $http, $q, { reservationId: reservationId, billStatusId: 3 });
        };
        this.getGroupCheckOUT = function (propertyId, checkINGuestId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckOUT/GetByGroupCheckINGuestId", $http, $q, { propertyId: propertyId, checkINGuestId: checkINGuestId, businessDate: businessDate });
        };
        this.getSplitRevenuePost = function (propertyId, chargePostId) {
            return httpCaller(apiPath + "FrontOffice/SplitRevenuePost/GetAllByGroup", $http, $q, { propertyId: propertyId, chargePostId: chargePostId });
        };

        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        this.saveSplitRevenuePost = function (model) {
            return httpPoster(apiPath + "FrontOffice/SplitRevenuePost/Save", $http, $q, model);
        };
        this.saveFOBill = function(model) {
            if (model.ChargePostToId == '1') {
                return httpPoster(apiPath + "FrontOffice/FOBill/Save", $http, $q, model);
            }
            else if (model.ChargePostToId == '10') {
                return httpPoster(apiPath + "FrontOffice/FOBill/SaveBanquet", $http, $q, model);
            }
        };
        this.getAllFOBill = function (propertyId, checkINGuestId, chargePostToId) {
            return httpCaller(apiPath + "FrontOffice/FOBill/GetAllByCheckINGuestId", $http, $q, { propertyId: propertyId, checkINGuestId: checkINGuestId, billStatusId: 3, chargePostToId: chargePostToId});
        };
        this.billCancel = function (model) {
            return httpPoster(apiPath + "FrontOffice/FOBill/BillCancel", $http, $q, model);
        };

        //settlement
        this.getAllBillByStatus = function (settlementModel) {
            return httpCaller(apiPath + "FrontOffice/FOBill/GetAllByCheckINGuestId", $http, $q, { propertyId: settlementModel.PropertyID, checkINGuestId: settlementModel.CheckINGuestId, billStatusId: settlementModel.BillStatusId, chargePostToId: settlementModel.ChargePostToId });
        };
        this.getAllSettlementMode = function (propertyId, moduleId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/SettlementMode/allByModuleId/" + propertyId + "/" + moduleId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };
        
        this.getCorporate = function (propertyId) {

            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/Corporate/GetAllByPropertyIdMin/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };
        this.getCurrency = function () {

            var deferred = $q.defer();
            $http.get(apiPath + "referencedata/currency")
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };
        this.saveSettlement = function (model) {

            var url = apiPath + 'GlobalSetting/Settlement/Save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };
        //end settlement

        //Room LINK
        this.getByCheckINGuestRoomId = function (propertyId, checkINGuestRoomId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuestRoomLink/GetByCheckINGuestRoomId", $http, $q, { propertyId: propertyId, checkINGuestRoomId: checkINGuestRoomId });
        };
        this.saveRoomLink = function (model) {

            var url = apiPath + 'frontoffice/CheckINGuestRoomLink/Save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        this.SendOTP = function (id) {
            return httpCaller(apiPath + "frontoffice/FOBill/GenerateOTP/" + id, $http, $q);

        };




        //Room Rate
        this.getCheckINGuest = function (checkINGuestId, businessDate) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckINGuest/GetCheckINGuest/" + checkINGuestId + "/" + businessDate,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };
        //end 

        //day end
        this.getAllChargePost = function (propertyID, businessDate, checkINGuestId) {

            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/NightAudit/GetAllChargePost/?propertyId=" + propertyID + "&businessDate=" + businessDate + "&checkINGuestId=" + checkINGuestId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        //dayClose
        this.guestDayClose = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/NightAudit/GuestDayClose",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        this.getGuestById = function (id) {
            return httpCaller(apiPath + "FrontOffice/Guest/GetById/" + id, $http, $q);
        };
        this.getCheckInGuestById = function (id) {
            return httpCaller(apiPath + "FrontOffice/CheckInGuest/GetById", $http, $q, { id: id });
        };
        this.saveCheckInGuest = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckInGuest/Save", $http, $q, model);
        };
        this.saveGuest = function (model) {
            return httpPoster(apiPath + "FrontOffice/Guest/Save", $http, $q, model);
        };

        this.saveAcknowledge = function (model) {
            return httpPoster(apiPath + "FrontOffice/Messenger/SaveAcknowledge", $http, $q, model);
        };

        this.getStateList = function (countryId) {
            return httpCaller(apiPath + "referencedata/state/" + countryId, $http, $q);
        };
        this.getTravelTypeList = function () {
            return httpCaller(apiPath + "ReferenceConstant/TravelType/all", $http, $q);
        };
        this.getVisitTypeList = function () {
            return httpCaller(apiPath + "ReferenceConstant/VisitType/all", $http, $q);
        };
        //this.getGuestStatuss = function () {
        //    return httpCaller(apiPath + "apiNotFound", $http, $q);
        //};

        this.getReasons = function (propertyId, moduleId, date) {
            var params = { propertyId: propertyId, moduleId: moduleId, active: 1, date: date };
            return httpCaller(apiPath + "GlobalSetting/Reason/all", $http, $q, params);
        };
        this.getBookingTypeList = function () {
            return httpCaller(apiPath + "ReferenceConstant/BookingType/All", $http, $q);
        };
        this.getPickupDropTypes = function () {
            return httpCaller(apiPath + "ReferenceConstant/PickupDropType/All", $http, $q);
        };
        this.getLocationTypes = function () {
            return httpCaller(apiPath + "ReferenceConstant/LocationType/All", $http, $q);
        };

        this.MapReport = function (filterValue, reportName) {
            return httpCaller1(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
        };
        var httpCaller1 = function (url, $http, $q, params) {

            var config = { headers: headers, params: params };
            var deferred = $q.defer();
            $http.defaults.useXDomain = true;
            try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e4) { }
            $http.get(url, config)
                .then(function (response) {
                    deferred.resolve(response.data);
                })
                .catch(function (ex) {
                    if (ex.data) {
                        msg(ex.data.Message);
                        deferred.reject(ex.data, status);
                    }
                    else {
                        msg('Undefined error!');
                        deferred.reject(ex.data, status);
                    }

                });
            return deferred.promise;
        }
        this.getNetworkList = function (propertyId) {
            //url: apiPath + "GlobalSetting/CorporateCreditCardNetwork/GetAllActiveByPropertyId/" + propertyId,
            return httpCaller(apiPath + "GlobalSetting/CorporateCreditCardNetwork/GetAllActiveByPropertyId/" + propertyId, $http, $q);
        };

        this.getByParentId = function (propertyId, chargePostToId, chargePostId, parentId) {
            return httpCaller(apiPath + "FrontOffice/ChargePost/GetByParentId", $http, $q, { propertyId: propertyId, chargePostToId: chargePostToId, chargePostId: chargePostId, parentId: parentId });
        };

        this.getCheckInDiscount = function (propertyId, checkINGuestId, revenueHeadId) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuestDiscount/Get", $http, $q, { propertyId: propertyId, checkINGuestId: checkINGuestId, revenueHeadId: revenueHeadId });
        };

        this.getAllByMessageTypeId = function (messageTypeId, messageToTypeId, messageToId) {
            return httpCaller(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId", $http, $q, { messageTypeId: messageTypeId, messageToTypeId: messageToTypeId, messageToId: messageToId });
        };
        this.showHistoryComplaints = function (propertyId, checkINGuestId) {
            return httpCaller(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId", $http, $q, { propertyId: propertyId, messageTypeId: '3', messageToTypeId: 5, messageToId: checkINGuestId });
        };

        this.getAllGroup = function (propertyId, occupiedStatusId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetAllGroup", $http, $q, { propertyId: propertyId, occupiedStatusId: occupiedStatusId, businessDate: businessDate });
        };

        this.getOccupiedGroupLeaderRooms = function (propertyId, date, checkINGuestId) {
            return httpCaller(apiPath + "FrontOffice/RoomStatus/GetAllByGroupLeaderOccupied", $http, $q, { propertyId: propertyId, businessDate: date, checkINGuestId: checkINGuestId });
        };

        this.getKOTBillIdBySettlementDetailId = function (settlementDetailId) {
            return httpCaller(apiPath + "PointOfSale/KOTBill/GetKOTBillIdBySettlementDetailId/" + settlementDetailId, $http, $q, {});
        };
        this.GetLaundryBillIdBySettlementDetailId = function (settlementDetailId) {
            return httpCaller(apiPath + "HouseKeeping/LaundryBill/GetLaundryBillIdBySettlementDetailId/" + settlementDetailId, $http, $q, {});
        };


        this.POSBillPrintingGetByBillId = function (kotBillId,propertyID) {
            return httpCaller(apiPath + "PointOfSale/POSBillPrinting/GetByBillId/" + kotBillId + '/' + propertyID, $http, $q, {});
        };

        this.GetAllFOBillByCheckINGuestId = function (propertyID,checkINGuestId) {
            return httpCaller(apiPath + "FrontOffice/FOBill/GetAllFOBillByCheckINGuestId/" + propertyID + '/' + checkINGuestId, $http, $q, {});
        };

        this.getCurrentRoomGuests = function (checkINGuestRoomId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/GetAllGuestByCheckINGuestRoomId?checkINGuestRoomId=" + checkINGuestRoomId + "&businessDate=" + businessDate, $http, $q, {});
        };

        this.GetAllSettledBill = function (propertyId, date) {
            return httpCaller(apiPath + "FrontOffice/FOBill/GetAllByPropertyId?propertyId=" + propertyId + "&businessDate=" + date, $http, $q, {});
        };

        this.DeleteSettledBill = function (billId) {
            return httpCaller(apiPath + "GlobalSetting/Settlement/DeleteByBillId?moduleId=1&billId=" + billId, $http, $q, {});
        };
        this.GetFOBillById = function (billId) {
            return httpCaller(apiPath + "FrontOffice/FOBill/GetById/" + billId, $http, $q, {});
        };

        this.UpdateRoomStatus = function (checkINGuestId, businessDate) {
            return httpCaller(apiPath + "FrontOffice/CheckINGuest/UpdateRoomStatusByCheckINGuestId/" + checkINGuestId + "/" + businessDate, $http, $q, {});
        };

        this.GetAllInterPropertyPropertyGroup = function (propertyId) {
            return httpCaller(apiPath + "Admin/Property/GetAllInterPropertyPropertyGroup/" + propertyId, $http, $q, {});
        };

        this.SaveCheckINGuestRoomInterPropertyTransfer = function (model) {
            return httpPoster(apiPath + "FrontOffice/CheckINGuestRoomInterPropertyTransfer/Save", $http, $q, model);
        };

    }
]);
