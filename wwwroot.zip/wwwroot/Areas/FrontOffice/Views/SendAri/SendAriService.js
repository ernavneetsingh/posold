﻿
app.service('SendAriService', function ($http, $q) {

    this.getPropertyChannelManager = function (propertyId) {
        return httpCaller(apiPath + "Admin/PropertyChannelManager/Get", $http, $q, { propertyId: propertyId });
    };
    this.getRoomTypes = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/RoomType/GetAllByPropertyId/?propertyId=" + propertyId, $http, $q);
    };
    this.getRateTypes = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/RateMaster/GetAllByPropertyId/" + propertyId, $http, $q);
    };

    this.save = function (model) {
        return httpPoster(apiPath + "Admin/PropertyChannelManager/PostAri", $http, $q, model);
    };

});
