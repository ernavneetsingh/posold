﻿
'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getData = function (propertyId) {

            var url = apiPath + "GlobalSetting/Reason/all/?propertyId=" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var GetDepartment = function (userid) {
            
            var url = apiPath + 'configuration/UserProduct/' + userid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {

            var url = apiPath + 'GlobalSetting/Reason/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var remove = function (propertyId, id) {
            var url = apiPath + 'GlobalSetting/Reason/delete/' + propertyId + "/" + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {

            var url = apiPath + 'GlobalSetting/Reason/status';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;


        };

        var isSymbolExist = function (propertyId, code) {
            
            var url = apiPath + 'GlobalSetting/Reason/existcode/' + propertyId + "/" + code;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };
        return {
            getData: getData,
            save: save,
            remove: remove,
            GetDepartment: GetDepartment,
            statusChange: statusChange,
            isSymbolExist: isSymbolExist
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
