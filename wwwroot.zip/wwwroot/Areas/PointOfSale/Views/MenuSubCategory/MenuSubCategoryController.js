﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        //$scope.ModifiedBy = $cookies.get('UserName');
        $scope.LoginId = $cookies.get('LoginId');
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            MenuCategoryId: '',
            MenuCategoryCode: '',
            MenuCategoryName: '',
            Code: '',
            Description: '',
            IsActive: true,
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            itema: []
        };

        //-----------------------------
        $scope.APIPath = apiPath;
        $scope.file = "";
        $scope.IsUploading = false;

        $scope.ClearImage = function () {
            $scope.file = { filesize: 0 };
            $scope.Model.ImageUrl = '';
            $scope.Model.UploadFile = '';
            scrollPageOnTop();
            document.getElementById("uploadCaptureInputFile").value = "";
        };
        $scope.GetFileSize = function () {
            var ftype = $scope.file.filetype.split('/')[0];
            if (ftype !== 'image' || $scope.file.filesize > 1048576) {
                msg('Please select image file of size less than 1 MB.');
                $scope.ClearImage();
            }
            var size = parseFloat($scope.file.filesize) / 1024; //in kb
            size = $filter("number")(size, 2).replace(/,/g, "");
            $scope.fileSize = size.toString() + "KB";
        };
        //-----------------------------

        $scope.IsReadonly = false;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.Model.items, function (item) {
                for (var attr in item) {
                    if (attr === "Code" || attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {

            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {

            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Model.items = data;
                $scope.search();
            },
               function (data) {

                   parent.failureMessage(data.message);
               });

        };

        $scope.ManuCategories = [];
        getMenuGroup();
        function getMenuGroup() {

            var promiseGet = service.GetMenuGroup($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.ManuCategories = data;
            },
                function (data) {

                    parent.failureMessage(data.message);
                });
        }
        $scope.changeCategory = function () {
            var c= $scope.ManuCategories.find(x=>x.Id==$scope.Model.MenuCategoryId);
            if(c) $scope.CategoryName= c.IsBanquet?'Banquet':'Point Of Sale';
        };

        $scope.Save = function (model, form) {
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }

            var ImageModel = {
                Base64: $scope.file.base64,
                FileName: $scope.file.filename,
                FileSize: $scope.file.filesize,
                FileType: $scope.file.filetype,
                PropertyID: $scope.PropertyID,
                EntityName: "MenuSubCategory"
            };
            if (ImageModel.Base64) {
                $scope.IsUploading = true;
                model.ImageModel = ImageModel;
            }

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;
            var status = service.save(model);
            status.then(function (result) {

                if (result.Status == true) {
                    var msg = model.Name + result.Message;
                    parent.successMessage(msg);
                    $scope.IsUploading = false;
                    getData();
                    scrollPageOnTop();
                }
                $scope.Reset();
            }, function (error) {

                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });

        }
        $scope.Reset = function () {
            $scope.ClearImage();
            $scope.Model = {};
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            $scope.query = "";
            getData();
            scrollPageOnTop();
        };
        $scope.Edit = function (model) {
            $scope.Model = model;

            $scope.Model.Id = model.Id;
            $scope.Model.Name = model.Name;
            $scope.Model.Code = model.Code;
            $scope.Model.MenuCategoryId = model.MenuCategoryId.toString();
            $scope.IsReadonly = true;
            $scope.Model.IsActive = model.IsActive;
            scrollPageOnTop();
        }
        $scope.Remove = function (model) {

            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {


                            parent.successMessage("Record Successfully deleted.");

                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.IsCodeExist = function (model) {
            if (model.Code.toString().length > 0) {
                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;

                var promiseGet = service.isCodeExist($scope.PropertyID, model.Code);
                promiseGet.then(function (data) {
                },
                    function (error) {

                        $scope.Model.Code = "";
                        parent.failureMessage("Code is already exist");

                        scrollPageOnTop();
                        $scope.focusElement = "Code";
                    });
            }
        };
    }
]);
