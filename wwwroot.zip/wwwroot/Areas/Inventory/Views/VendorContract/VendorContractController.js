﻿
app.controller("VendorContractController", ["$scope", "VendorContractService",
   function ($scope, service) {

       $scope.getAllCategory = function () {

           service.getAllCategory($scope.PropertyID)
               .then(function (s) {
                   $scope.ItemCategorys = s.Collection;
               }, function (e) {
                   msg(e.Message);
               });
       };
       $scope.getAllCategory();

       $scope.getCategoryVendors = function () {

           service.getCategoryVendors($scope.PropertyID, $scope.itemCategoryId)
               .then(function (s) {
                   $scope.CategoryVendors = s.Collection;
                   $scope.getCategoryItemContracts();
               }, function (e) {
                   msg(e.Message);
               });
       };
       $scope.getCategoryItemContracts = function () {
           $scope.CategoryItemContracts = [];

           service.getCategoryItemContracts($scope.PropertyID, $scope.itemCategoryId, $scope.ModifiedDate)
               .then(function (s) {
                   $scope.CategoryItemContracts = s.Collection;
               }, function (e) {
                   msg(e.Message);
               });
       };
       $scope.save = function () {

           service.save({ PropertyID: $scope.PropertyID, ModifiedBy: $scope.ModifiedBy, CategoryItemContracts: $scope.CategoryItemContracts })
               .then(function (s) {
                   msg(s.Message, true);

               }, function (e) {
                   msg(e.Message);
               });
       };
   }
]);

//function addRow(event) {
//    let isDisabled = document.querySelector('form button:disabled');
//    if (isDisabled) {
//        isDisabled.removeAttribute('disabled');
//        isDisabled.classList.add('enabled');
//    }
//    let domHtml = event.target.parentNode.previousElementSibling;
//    event.target.parentNode.before(domHtml.cloneNode(true));
//}
//function deleteRow(event) {
//    event.target.parentNode.parentNode.parentNode.remove();
//    let isEnabled = document.querySelectorAll('form button.enabled');
//    if (isEnabled.length === 1) {
//        document.querySelector('form button.enabled').setAttribute('disabled', 'disabled');
//    }
//}
