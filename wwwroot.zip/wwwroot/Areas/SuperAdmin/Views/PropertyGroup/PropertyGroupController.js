﻿
app.controller("controller", ["$scope", "service", "localStorageService",
    function ($scope, service, localStorageService) {

        $scope.IsShow = false;

    $scope.Model = {};
    $scope.Model.IsActive = true;

    var sortKeyOrder = {
        key: "",
        order: "",
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }
    
    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 50;
    $scope.recordsPerPage = 50;
    $scope.numberOfPageButtons = 10;

    getData($scope, service, localStorageService);

    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get("sortKeyOrder");
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == "ASC")
                sortKeyOrder.order = "DESC";
            else
                sortKeyOrder.order = "ASC";
            localStorageService.set("sortKeyOrder", sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: "ASC"
            };
            localStorageService.set("sortKeyOrder", sortKeyOrder);
        }
    };
    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };
    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    };
    $scope.Edit = function (item) {
        
        $scope.IsReadonly = true;
        $scope.IsShow = true;

        angular.forEach($scope.Propertys, function (item) {
            item.IsSelected = false;
        })

        $scope.Model = item;

        angular.forEach($scope.Propertys, function (property) {
            angular.forEach($scope.Model.Propertys, function (item) {
                if(property.Id == item.Id)
                {
                    property.IsSelected = true;
                }
            })
        })


        scrollPageOnTop();
    };
    $scope.Reset = function () {
        $scope.file = '';
        $scope.Model.IconUrl = '';
        $scope.Model.UploadFile = '';
        $scope.IsReadonly = false;
        $scope.Model = {};
        $scope.Model.IsActive = true;
        $scope.searchfor = null;
        $scope.search();
        scrollPageOnTop();
    };

    $scope.ShowErrorMessage = false;

    $scope.Propertys = [];

    $scope.GetAllProperty = function () {
        var promiseGet = service.GetAllProperty();
        promiseGet.then(function (data) {
            $scope.Propertys = data;
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };
    $scope.GetAllProperty();

    $scope.Save  = function (model, form) {

        
        if ($scope[form].$valid) {
            model.Propertys = [];
            
            angular.forEach($scope.Propertys, function (item) {
                if (item.IsSelected)
                {
                    model.Propertys.push({ Id: item.Id });
                }
            })

            var promiseGet = service.save(model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);
                $scope.Reset();
                parent.successMessage(data.Message);
                scrollPageOnTop();
            },
                function (error, status) {
                    $scope.IsUploading = false;
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });


        } else {
            $scope.ShowErrorMessage = true;
        }
    };

    $scope.IsNameExist = function (model) {
        var promiseGet = service.isNameExist(model);
        promiseGet.then(function (data) {
        },
            function (error) {
                $scope.Model.Name = "";
                scrollPageOnTop();
                parent.failureMessage(error.Message);
            });
    };
    
    $scope.ChangeStatus = function (model) {

        var promiseGet = service.changeStatus(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

}
]);

var getData = function ($scope, dataService, localStorageService) {
    
    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Name",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getAll(options)
        .then(function (totalItems) {
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};