﻿app.service('checkINCommonService', ["$http", "$q","$filter", function ($http, $q,$filter) {

    //Common Method
    var CalculateCheckINRoom = function (scope, roomRate) {
        
        if (roomRate) {
            if (parseFloat(roomRate.RateDiscountValue) > 0) {
                if (parseFloat(roomRate.RateDiscountInId) == 1) {//amount
                    if (parseFloat(roomRate.RateDiscountValue) > parseFloat(roomRate.DayRate)) {

                        parent.posFailureMessage("Discount amount cann't be more then Rack Rate.");
                        roomRate.RateDiscountValue = 0;
                    }
                }
                else if (parseFloat(roomRate.RateDiscountInId) == 2) {//percentage
                    if (parseFloat(roomRate.RateDiscountValue) > 100) {

                        parent.posFailureMessage("Discount cann't be more then 100.");
                        roomRate.RateDiscountValue = 0;
                    }
                }
            }
        }

        angular.forEach(scope.CheckINGuestRooms, function (room) {
            
            if (!room.IsInclusive) {
                room.TotalDayRate = 0;
                room.TotalDayRateAmount = 0;
                room.TotalTariffTAXAmount = 0;
                room.TotalTariff = 0;
                room.TotalMealPlanDayRateAmount = 0;
                room.TotalMealPlanTAXAmount = 0;
                room.TotalMealPlan = 0;
                room.TotalNetDayAmount = 0;

                angular.forEach(room.CheckINGuestRoomRates, function (rate) {
                    var i = 1;

                    rate.IsRateDisabled = room.RateTypeId == '2' ? true : false;
                    
                    var bdate = scope.BusinessDate.Year + '-' + scope.BusinessDate.Month + '-' + scope.BusinessDate.Day;
                    var chargeDate = GetMomentDate($filter('date')(rate.ChargeDate, scope.DateFormat), scope.DateFormat);
                    var currentDate = GetMomentDate(bdate, 'YYYY-MM-DD');
                    if (chargeDate.isBefore(currentDate)) {
                        rate.IsRateDisabled = true;
                    }
                    
                    if (!rate.IsRateDisabled || !rate.Id)
                    {
                        rate.FolioNo = room.FolioNo;
                        rate.TariffTAXAmount = 0;
                        rate.MealPlanTAXAmount = 0;

                        if(room.IsInclusive)
                        {
                            rate.RateDiscountAmount = 0;
                            rate.RateDiscountValue = 0;
                            rate.RateDiscountValue = parseFloat(rate.DayRate) - parseFloat(rate.DayRateAmount);
                        }
                        else
                        {
                            
                        }
                        
                        //rate.DayRateAmount = 0;   //ChargeRate
                        rate.NetDayAmount = 0;

                        rate.CheckINGuestRoomRateTaxs = [];

                        //discount rate
                        if (parseFloat(rate.RateDiscountValue) == 0) {
                            if (parseFloat(rate.DayRateAmount) <= parseFloat(rate.DayRate)) {
                                rate.DayRateAmount = parseFloat(rate.DayRate);
                            }
                        }
                        
                        if (parseFloat(rate.RateDiscountValue) > 0) {

                            if (parseFloat(rate.RateDiscountInId) == 1) {//amount
                                rate.RateDiscountAmount = parseFloat(rate.RateDiscountValue);
                                rate.DayRateAmount = parseFloat(rate.DayRate) - parseFloat(rate.RateDiscountValue);
                            }
                            else if (parseFloat(rate.RateDiscountInId) == 2) {//percentage
                                rate.RateDiscountAmount = parseFloat(rate.DayRate) * parseFloat(rate.RateDiscountValue) * .01;
                                rate.DayRateAmount = parseFloat(rate.DayRate) - parseFloat(rate.RateDiscountAmount);
                            }

                            var rateDayRateAmount = $filter("number")(parseFloat(rate.DayRateAmount), 2).replace(/,/g, "");
                            var rateMealPlanDayRateAmount = $filter("number")(parseFloat(rate.MealPlanDayRateAmount), 2).replace(/,/g, "");

                            if (parseFloat(rateDayRateAmount) < parseFloat(rateMealPlanDayRateAmount)) {
                                
                                rate.RateDiscountInId = '1';
                                rate.RateDiscountValue = 0;
                                rate.DayRateAmount = parseFloat(rate.DayRate);
                            }
                        }

                        //Tariff
                        var taxAmount = 0.0;
                        if(parseFloat(rate.DayRate)>0)
                        {
                            angular.forEach(room.TariffLinkTaxStructures, function (linkTaxStructure, index) {

                                taxAmount = GetTaxAmount(rate.CheckINGuestRoomRateTaxs, linkTaxStructure, parseFloat(rate.DayRate), parseFloat(rate.DayRateAmount));
                                if (isNaN(taxAmount)) {
                                    taxAmount = 0;
                                }
                                taxAmount = $filter("number")(taxAmount, 2).replace(/,/g, "");

                            
                                rate.CheckINGuestRoomRateTaxs.push({
                                    CheckINGuestRoomRateId: '',
                                    RoomItemTypeId: '1',  //1=Tariff, 2=MP and 3=EB
                                    SNo: i,
                                    TaxTypeId: linkTaxStructure.TaxTypeId,
                                    TaxTypeCode: linkTaxStructure.TaxTypeCode,
                                    TaxOnId: linkTaxStructure.TaxOnId,
                                    TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
                                    IsTariffOn: linkTaxStructure.IsTariffOn,
                                    TaxInId: linkTaxStructure.TaxInId,
                                    TaxInName: linkTaxStructure.TaxInName,
                                    TaxValue: linkTaxStructure.TaxValue,
                                    TaxAmount: parseFloat(taxAmount),
                                });
                                i = 1 + i;
                                rate.TariffTAXAmount = parseFloat(rate.TariffTAXAmount) + parseFloat(taxAmount);
                            })
                        }
                        
                        rate.TariffTAXAmount = $filter("number")(parseFloat(rate.TariffTAXAmount), 2).replace(/,/g, "");
                        rate.TotalTariff = $filter("number")(parseFloat(rate.DayRateAmount) + parseFloat(rate.TariffTAXAmount), 2).replace(/,/g, "");

                        //MP
                        taxAmount = 0.0;
                        if(parseFloat(rate.MealPlanDayRate)>0)
                        {
                            angular.forEach(room.MealPlanLinkTaxStructures, function (linkTaxStructure, index) {

                                if (room.IsInclusive) {
                                    rate.MealPlanDayRate = parseFloat(rate.MealPlanDayRateAmount);
                                }
                                                              
                                taxAmount = GetTaxAmount(rate.CheckINGuestRoomRateTaxs, linkTaxStructure, parseFloat(rate.MealPlanDayRate), parseFloat(rate.MealPlanDayRateAmount));
                                if (isNaN(taxAmount)) {
                                    taxAmount = 0;
                                }
                                taxAmount = $filter("number")(taxAmount, 3).replace(/,/g, "");

                                rate.CheckINGuestRoomRateTaxs.push({
                                    CheckINGuestRoomRateId: '',
                                    RoomItemTypeId: '2', //1=Tariff, 2=MP and 3=EB
                                    SNo: i,
                                    TaxTypeId: linkTaxStructure.TaxTypeId,
                                    TaxTypeCode: linkTaxStructure.TaxTypeCode,
                                    TaxOnId: linkTaxStructure.TaxOnId,
                                    TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
                                    IsTariffOn: linkTaxStructure.IsTariffOn,
                                    TaxInId: linkTaxStructure.TaxInId,
                                    TaxInName: linkTaxStructure.TaxInName,
                                    TaxValue: linkTaxStructure.TaxValue,
                                    TaxAmount: parseFloat(taxAmount),
                                });
                                i = 1 + i;
                                rate.MealPlanTAXAmount = parseFloat(rate.MealPlanTAXAmount) + parseFloat(taxAmount);
                            })
                        }
                        
                        rate.MealPlanTAXAmount = $filter("number")(parseFloat(rate.MealPlanTAXAmount), 2).replace(/,/g, "");
                        rate.TotalMealPlan = $filter("number")(parseFloat(rate.MealPlanDayRateAmount) + parseFloat(rate.MealPlanTAXAmount), 2).replace(/,/g, "");


                        //Extra Bed ------------------------------------------------------------------------
                        rate.TotalExtraBed = 0.0;
                        rate.ExtraBedTAXAmount = 0.0;
                        var extraBedTaxAmount = 0.0;
                        if(parseFloat(rate.ExtraBedAmount)>0)
                        {
                            angular.forEach(room.TariffLinkTaxStructures, function (linkTaxStructure, index) {

                                //var RackRate = 0;
                                //var ChargeRate = rate.ExtraBedAmount;
                                //var DiscountRate =0;
                                //var MealPlanDayRate=0;

                                extraBedTaxAmount = GetTaxAmount(rate.CheckINGuestRoomRateTaxs, linkTaxStructure, parseFloat(rate.ExtraBedAmount), parseFloat(rate.ExtraBedAmount));
                                if (isNaN(extraBedTaxAmount)) {
                                    extraBedTaxAmount = 0;
                                }
                                extraBedTaxAmount = $filter("number")(parseFloat(extraBedTaxAmount), 3).replace(/,/g, "");

                                rate.CheckINGuestRoomRateTaxs.push({
                                    CheckINGuestRoomRateId: '',
                                    RoomItemTypeId: '3', //1=Tariff, 2=MP and 3=EB
                                    SNo: i,
                                    TaxTypeId: linkTaxStructure.TaxTypeId,
                                    TaxTypeCode: linkTaxStructure.TaxTypeCode,
                                    TaxOnId: linkTaxStructure.TaxOnId,
                                    TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
                                    IsTariffOn: linkTaxStructure.IsTariffOn,
                                    TaxInId: linkTaxStructure.TaxInId,
                                    TaxInName: linkTaxStructure.TaxInName,
                                    TaxValue: linkTaxStructure.TaxValue,
                                    TaxAmount: parseFloat(extraBedTaxAmount),
                                });
                                i = 1 + i;
                                rate.ExtraBedTAXAmount = parseFloat(rate.ExtraBedTAXAmount) + parseFloat(extraBedTaxAmount);
                            })
                        }
                       
                        rate.ExtraBedTAXAmount = $filter("number")(parseFloat(rate.ExtraBedTAXAmount), 2).replace(/,/g, "");
                        rate.TotalExtraBed = $filter("number")(parseFloat(rate.ExtraBedAmount) + parseFloat(rate.ExtraBedTAXAmount), 2).replace(/,/g, "");

                        //Extra Bed MP
                        var extraBedMPTaxAmount = 0.0;
                        rate.ExtraBedMealPlanTAXAmount = 0.0;
                        rate.TotalExtraBedMealPlan = 0.0;
                        
                        if(parseFloat(rate.ExtraBedMealPlanDayRate)>0)
                        {
                            angular.forEach(room.MealPlanLinkTaxStructures, function (linkTaxStructure, index) {
                                extraBedMPTaxAmount = GetTaxAmount(rate.CheckINGuestRoomRateTaxs, linkTaxStructure, parseFloat(rate.ExtraBedMealPlanDayRate), parseFloat(rate.ExtraBedMealPlanDayRate));
                                if (isNaN(extraBedMPTaxAmount)) {
                                    extraBedMPTaxAmount = 0;
                                }
                                extraBedMPTaxAmount = $filter("number")(parseFloat(extraBedMPTaxAmount), 3).replace(/,/g, "");
                                rate.CheckINGuestRoomRateTaxs.push({
                                    CheckINGuestRoomRateId: '',
                                    RoomItemTypeId: '4', //4=ExtraBedMealPlan
                                    SNo: i,
                                    TaxTypeId: linkTaxStructure.TaxTypeId,
                                    TaxTypeCode: linkTaxStructure.TaxTypeCode,
                                    TaxOnId: linkTaxStructure.TaxOnId,
                                    TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
                                    IsTariffOn: linkTaxStructure.IsTariffOn,
                                    TaxInId: linkTaxStructure.TaxInId,
                                    TaxInName: linkTaxStructure.TaxInName,
                                    TaxValue: linkTaxStructure.TaxValue,
                                    TaxAmount: parseFloat(extraBedMPTaxAmount),
                                });
                                i = 1 + i;
                                rate.ExtraBedMealPlanTAXAmount = parseFloat(rate.ExtraBedMealPlanTAXAmount) + parseFloat(extraBedMPTaxAmount);
                            })
                        }
                        
                        
                        rate.ExtraBedMealPlanTAXAmount = $filter("number")(parseFloat(rate.ExtraBedMealPlanTAXAmount), 2).replace(/,/g, "");
                        rate.TotalExtraBedMealPlan = parseFloat(rate.ExtraBedMealPlanDayRate) + parseFloat(rate.ExtraBedMealPlanTAXAmount);
                        rate.TotalExtraBedMealPlan = $filter("number")(parseFloat(rate.TotalExtraBedMealPlan), 2).replace(/,/g, "");

                        //formatting
                        rate.DayRateAmount = $filter("number")(parseFloat(rate.DayRateAmount), 2).replace(/,/g, "");

                        //discount MP
                        //rate.MealPlanDayRateAmount = rate.MealPlanDayRate;
                        if (rate.MealPlanDiscountValue > 0) {
                            //TariffTAXAmount
                            if (rate.MealPlanDiscountInId == 1) {//amount
                                rate.MealPlanDiscountAmount = parseFloat(rate.MealPlanDiscountValue);
                                rate.MealPlanDayRateAmount = parseFloat(rate.MealPlanDayRate) - parseFloat(rate.MealPlanDiscountValue);
                            }
                            else if (rate.MealPlanRateDiscountInId == 2) {//percentage
                                rate.MealPlanDiscountAmount = parseFloat(rate.MealPlanDayRate) * parseFloat(rate.MealPlanDiscountValue) * .01;
                                rate.MealPlanDayRateAmount = parseFloat(rate.MealPlanDayRate) - parseFloat(rate.MealPlanDayRate) * parseFloat(rate.MealPlanDiscountValue) * .01;
                            }
                        }
                        //formatting
                        try {
                            rate.MealPlanDayRateAmount = $filter("number")(parseFloat(rate.MealPlanDayRateAmount), 2).replace(/,/g, "");
                        } catch (e) { }

                        //NetDayAmount
                        //rate.NetDayAmount = parseFloat(rate.DayRateAmount) + parseFloat(rate.TariffTAXAmount) + parseFloat(rate.MealPlanDayRateAmount) +parseFloat(rate.MealPlanTAXAmount);

                        rate.NetDayAmount = parseFloat(rate.TotalTariff) + parseFloat(rate.TotalMealPlan);
                        rate.NetDayAmount = $filter("number")(parseFloat(rate.NetDayAmount), 2).replace(/,/g, "");

                        rate.NetDayExtraBedAmount = parseFloat(rate.TotalExtraBed) + parseFloat(rate.TotalExtraBedMealPlan);
                        rate.NetDayExtraBedAmount = $filter("number")(parseFloat(rate.NetDayExtraBedAmount), 2).replace(/,/g, "");

                        rate.TotalDayAmount = parseFloat(rate.NetDayAmount) + parseFloat(rate.NetDayExtraBedAmount);
                        rate.TotalDayAmount = $filter("number")(rate.TotalDayAmount, 2).replace(/,/g, "");
                    }

                });

                //Update CheckINGuestRoom
                angular.forEach(scope.Model.CheckINGuests, function (guest) {
                    if (guest.CheckINGuestRoom) {
                        if (guest.CheckINGuestRoom.RoomMasterId == room.RoomMasterId && guest.FolioNo == room.FolioNo) {
                            guest.CheckINGuestRoom = room;
                        }
                    }
                    else {
                        guest.CheckINGuestRoom = {};
                    }
                });
            }

        });

        GetTotal(scope);
    };
    function GetTaxAmount(reservationRoomTypeRateTaxs, tax, OriginalRate, ChangeRate) {

        var calculatetax = 0.0;
        var itemTax = tax.TaxValue.toString();
        itemTax = replaceAll(itemTax, ',', '');

        if (tax.TaxOnId === 1) {
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(OriginalRate) && parseFloat(tax.MaxRange) >= parseFloat(OriginalRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                    } else {
                        calculatetax = parseFloat(itemTax);
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(OriginalRate);
                }
            }
        } else if (tax.TaxOnId === 2) {//Discounted For MealPlan
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(ChangeRate) && parseFloat(tax.MaxRange) >= parseFloat(ChangeRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                    } else {
                        calculatetax = parseFloat(itemTax);
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else if (tax.TaxOnId === 5) {
            if (tax.IsSlab) {
                if ((parseFloat(tax.MinRange) <= parseFloat(OriginalRate)) && (parseFloat(tax.MaxRange) >= parseFloat(OriginalRate))) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                    } else {
                        calculatetax = parseFloat(itemTax);
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(OriginalRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else if (tax.TaxOnId === 6) {
            if (tax.IsSlab) {
                if (parseFloat(tax.MinRange) <= parseFloat(ChangeRate) && parseFloat(tax.MaxRange) >= parseFloat(ChangeRate)) {
                    if (tax.TaxInId === 2) {//Percent
                        calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                    } else {
                        calculatetax = parseFloat(itemTax);
                    }
                }
            }
            else {
                if (tax.TaxInId === 2) {//Percent
                    calculatetax = parseFloat(ChangeRate) * parseFloat(itemTax) / 100;
                } else {
                    calculatetax = parseFloat(itemTax);
                }
            }
        }
        else {
            if (reservationRoomTypeRateTaxs.length > 0) {
                angular.forEach(reservationRoomTypeRateTaxs, function (item) {
                    if (tax.TaxOnTaxTypeId == item.TaxTypeId) {
                        if (tax.TaxInId === 2) {//Percent
                            calculatetax = parseFloat(item.TaxAmount) * parseFloat(itemTax) / 100;
                        } else {
                            calculatetax = parseFloat(itemTax);
                        }
                    }
                });
            }
        }
        return parseFloat(calculatetax);
    };
    var GetTotal = function (scope) {


        angular.forEach(scope.CheckINGuestRooms, function (room) {

            room.TotalDayRate = 0;
            room.TotalDayRateAmount = 0;
            room.TotalTariffTAXAmount = 0;
            room.TotalTariff = 0;

            room.TotalNumberOfAdultExtraBed = 0;
            room.TotalNumberOfChildExtraBed = 0;
            room.TotalNumberOfInfantExtraBed = 0;
            room.TotalExtraBedNumber = 0,
                room.TotalExtraBedAmount = 0;
            room.TotalExtraBedTAXAmount = 0;
            room.TotalExtraBed = 0;
            room.TotalAdultExtraBedAmount = 0;
            room.TotalChildExtraBedAmount = 0;
            room.TotalInfantExtraBedAmount = 0;

            room.TotalExtraBedMealPlanDayRate = 0;
            room.TotalExtraBedMealPlanTAXAmount = 0;
            room.TotalExtraBedMealPlan = 0;
            room.NetDayExtraBedAmount = 0;
            room.TotalDayAmount = 0;

            room.TotalMealPlanDayRate = 0;
            room.TotalMealPlanDayRateAmount = 0;
            room.TotalMealPlanTAXAmount = 0;
            room.TotalMealPlan = 0;

            room.TotalNetDayAmount = 0;

            //Total
            //Tariff
            angular.forEach(room.CheckINGuestRoomRates, function (item) {

                //Tariff
                room.TotalDayRate = parseFloat(room.TotalDayRate) + parseFloat(item.DayRate);
                room.TotalDayRateAmount = parseFloat(room.TotalDayRateAmount) + parseFloat(item.DayRateAmount);
                room.TotalTariffTAXAmount = parseFloat(room.TotalTariffTAXAmount) + parseFloat(item.TariffTAXAmount);


                //test 
                //item.TotalTariff =parseFloat(item.DayRateAmount) + parseFloat(item.TariffTAXAmount);

                room.TotalTariff = parseFloat(room.TotalTariff) + (parseFloat(item.DayRateAmount) + parseFloat(item.TariffTAXAmount));

                //MP
                if (item.MealPlanDayRateAmount == undefined) {
                    item.MealPlanDayRateAmount = 0;
                }
                else {
                    item.MealPlanDayRateAmount = $filter("number")(item.MealPlanDayRateAmount).replace(/,/g, "");;
                }
                room.TotalMealPlanDayRate = parseFloat(room.TotalMealPlanDayRate) + parseFloat(item.MealPlanDayRate);
                room.TotalMealPlanDayRateAmount = parseFloat(room.TotalMealPlanDayRateAmount) + parseFloat(item.MealPlanDayRateAmount);
                room.TotalMealPlanTAXAmount = parseFloat(room.TotalMealPlanTAXAmount) + parseFloat(item.MealPlanTAXAmount);

                room.TotalMealPlan = parseFloat(room.TotalMealPlan) + (parseFloat(item.MealPlanDayRateAmount) + parseFloat(item.MealPlanTAXAmount));

                //Extra Bed  

                if (!item.NumberOfAdultExtraBed) {
                    item.NumberOfAdultExtraBed = 0;
                }
                if (!item.NumberOfChildExtraBed) {
                    item.NumberOfChildExtraBed = 0;
                }
                if (!item.NumberOfInfantExtraBed) {
                    item.NumberOfInfantExtraBed = 0;
                }
                room.TotalNumberOfAdultExtraBed = parseFloat(room.TotalNumberOfAdultExtraBed) + parseFloat(item.NumberOfAdultExtraBed);
                room.TotalNumberOfChildExtraBed = parseFloat(room.TotalNumberOfChildExtraBed) + parseFloat(item.NumberOfChildExtraBed);
                room.TotalNumberOfInfantExtraBed = parseFloat(room.TotalNumberOfInfantExtraBed) + parseFloat(item.NumberOfInfantExtraBed);

                //item.ExtraBedNumber=  parseFloat(item.NumberOfAdultExtraBed)  +  parseFloat(item.NumberOfChildExtraBed) + parseFloat(item.NumberOfInfantExtraBed); 

                room.TotalExtraBedNumber = parseFloat(room.TotalExtraBedNumber) + parseFloat(item.ExtraBedNumber);

                room.TotalAdultExtraBedAmount = parseFloat(room.TotalAdultExtraBedAmount) + parseFloat(item.AdultExtraBedAmount);
                room.TotalChildExtraBedAmount = parseFloat(room.TotalChildExtraBedAmount) + parseFloat(item.ChildExtraBedAmount);
                room.TotalInfantExtraBedAmount = parseFloat(room.TotalInfantExtraBedAmount) + parseFloat(item.InfantExtraBedAmount);

                //item.ExtraBedAmount =  parseFloat(item.AdultExtraBedAmount) + parseFloat(item.ChildExtraBedAmount) + parseFloat(item.InfantExtraBedAmount);

                room.TotalExtraBedAmount = parseFloat(room.TotalExtraBedAmount) + parseFloat(item.ExtraBedAmount);
                room.TotalExtraBedTAXAmount = parseFloat(room.TotalExtraBedTAXAmount) + parseFloat(item.ExtraBedTAXAmount);
                room.TotalExtraBed = parseFloat(room.TotalExtraBed) + (parseFloat(item.ExtraBedAmount) + parseFloat(item.ExtraBedTAXAmount));
                
                room.TotalExtraBedMealPlanDayRate = parseFloat(room.TotalExtraBedMealPlanDayRate) + parseFloat(item.ExtraBedMealPlanDayRate);
                room.TotalExtraBedMealPlanTAXAmount = parseFloat(room.TotalExtraBedMealPlanTAXAmount) + parseFloat(item.ExtraBedMealPlanTAXAmount);

                room.TotalExtraBedMealPlan = parseFloat(room.TotalExtraBedMealPlan) + (parseFloat(item.ExtraBedMealPlanDayRate) + parseFloat(room.TotalExtraBedMealPlanTAXAmount));
                room.NetDayExtraBedAmount = parseFloat(room.TotalExtraBed) + parseFloat(room.TotalExtraBedMealPlan);

                room.TotalNetDayAmount = parseFloat(room.TotalNetDayAmount) + parseFloat(item.NetDayAmount);// + parseFloat(room.NetDayExtraBedAmount);

                //room.TotalDayAmount = parseFloat(room.TotalDayAmount) + (parseFloat(room.TotalNetDayAmount) + parseFloat(room.NetDayExtraBedAmount));
            });

            room.TotalDayAmount = (parseFloat(room.TotalNetDayAmount) + parseFloat(room.NetDayExtraBedAmount));
            room.TotalDayAmount = $filter("number")(parseFloat(room.TotalDayAmount), 2).replace(/,/g, "");

            room.TotalDayRate = $filter("number")(parseFloat(room.TotalDayRate), 2).replace(/,/g, "");
            room.TotalDayRateAmount = $filter("number")(parseFloat(room.TotalDayRateAmount), 2).replace(/,/g, "");
            room.TotalTariffTAXAmount = $filter("number")(parseFloat(room.TotalTariffTAXAmount), 2).replace(/,/g, "");
            room.TotalTariff = $filter("number")(parseFloat(room.TotalTariff), 2).replace(/,/g, "");

            //room.ExtraBedNumber = $filter("number")(parseFloat(room.ExtraBedNumber), 0).replace(/,/g, ""); 
            room.TotalExtraBedNumber = $filter("number")(parseFloat(room.TotalExtraBedNumber), 0).replace(/,/g, "");
            room.TotalExtraBedAmount = $filter("number")(parseFloat(room.TotalExtraBedAmount), 2).replace(/,/g, "");
            room.TotalExtraBedTAXAmount = $filter("number")(parseFloat(room.TotalExtraBedTAXAmount), 2).replace(/,/g, "");
            room.TotalExtraBed = $filter("number")(parseFloat(room.TotalExtraBed), 2).replace(/,/g, "");

            room.TotalMealPlanDayRateAmount = $filter("number")(parseFloat(room.TotalMealPlanDayRateAmount), 2).replace(/,/g, "");
            room.TotalMealPlanTAXAmount = $filter("number")(parseFloat(room.TotalMealPlanTAXAmount), 2).replace(/,/g, "");
            room.TotalMealPlan = $filter("number")(parseFloat(room.TotalMealPlan), 2).replace(/,/g, "");
            room.TotalNetDayAmount = $filter("number")(parseFloat(room.TotalNetDayAmount), 2).replace(/,/g, "");

        });

        var totalDayRateAmount = 0.0;
        var totalDayRate = 0.0;
        var totalNetAmount = 0.0;
        var totalAdvanceAmount = 0.0;

        angular.forEach(scope.CheckINGuestRooms, function (item) {
            totalDayRateAmount = parseFloat(totalDayRateAmount) + parseFloat(item.TotalDayRateAmount);
            totalDayRate = parseFloat(totalDayRate) + parseFloat(item.TotalDayRate);
        });

        angular.forEach(scope.CheckINGuestRooms, function (item) {
            totalNetAmount = parseFloat(totalNetAmount) + parseFloat(item.TotalDayAmount);
        });

        totalDayRateAmount = $filter("number")(parseFloat(totalDayRateAmount), 2).replace(/,/g, "");
        totalDayRate = $filter("number")(parseFloat(totalDayRate), 2).replace(/,/g, "");

        var totalDiscount = parseFloat(totalDayRateAmount) - parseFloat(totalDayRate);

        //TotalAdvance

        angular.forEach(scope.Model.CheckINGuests, function (item) {
            
            totalAdvanceAmount = parseFloat(totalAdvanceAmount) + parseFloat(item.CheckINAdvance ? item.CheckINAdvance : 0);

        });

        var totalAdvance=0.0;
        if(scope.Reservation)
        {
            if (scope.Reservation.TotalAdvance != undefined)
            {
                totalAdvance = parseFloat(scope.Reservation.TotalAdvance)
            }
        }
      
        scope.Model.TotalAdvance = $filter("number")(parseFloat(totalAdvanceAmount) +  parseFloat(totalAdvance) , 2).replace(/,/g, "") ;
        scope.Model.TotalNetAmount = $filter("number")(parseFloat(totalNetAmount), 2).replace(/,/g, "");

    };
    
    var IsInclusive = function (scope, selectedRoom) {
        if (selectedRoom.IsInclusive == false) {
            if (selectedRoom.CheckINGuestId) {
                angular.forEach(scope.Model.CheckINGuests, function (checkINGuest) {
                    if (checkINGuest.Id == selectedRoom.CheckINGuestId) {
                        if (checkINGuest.ReservationRoomTypeRates) {
                            SetReservationRoomTypeRate(checkINGuest);
                        }
                        else {
                            SetRate(scope, selectedRoom);
                        }
                        CalculateCheckINRoom(scope);
                    }
                });
            }
            else {
                SetRate(scope, selectedRoom);
            }
            return;
        }
        angular.forEach(scope.CheckINGuestRooms, function (room) {
            if (room.RoomMasterId == scope.CheckINGuestRoom.RoomMasterId && room.FolioNo == scope.CheckINGuestRoom.FolioNo) {
                room.TotalDayRate = 0;
                room.TotalDayRateAmount = 0;
                room.TotalTariffTAXAmount = 0;
                room.TotalTariff = 0;
                room.TotalMealPlanDayRateAmount = 0;
                room.TotalMealPlanTAXAmount = 0;
                room.TotalMealPlan = 0;
                room.TotalNetDayAmount = 0;

                var bdate = scope.BusinessDate.Year + '-' + scope.BusinessDate.Month + '-' + scope.BusinessDate.Day;

                angular.forEach(room.CheckINGuestRoomRates, function (rate) {

                    var chargeDate = GetMomentDate($filter('date')(rate.ChargeDate, scope.DateFormat), scope.DateFormat);
                    var currentDate = GetMomentDate(bdate, 'YYYY-MM-DD');

                    if (!chargeDate.isBefore(currentDate)) {

                        var i = 1;
                        rate.FolioNo = room.FolioNo;
                        rate.IsRateDisabled = selectedRoom.IsInclusive;

                        rate.TariffTAXAmount = 0;
                        rate.MealPlanTAXAmount = 0;
                        rate.NetDayAmount = 0;
                        rate.CheckINGuestRoomRateTaxs = [];
                        var totalTariff = 0.0;
                        var totalTaxPercent = 0.0;
                        var chargeAmount = chargeAmount = parseFloat(rate.DayRateAmount) - parseFloat(rate.MealPlanDayRateAmount);

                        var TaxOnTaxTypeIds = GetDistinctTaxOnTaxTypeId(room.TariffLinkTaxStructures);
                        angular.forEach(TaxOnTaxTypeIds, function (taxOnTaxTypeId) {
                            var roomTariffLinkTaxStructures = room.TariffLinkTaxStructures.filter(x=>x.TaxOnTaxTypeId ==taxOnTaxTypeId );
                            angular.forEach(roomTariffLinkTaxStructures, function (linkTaxStructure, index) {
                                if (!linkTaxStructure.TaxOnTaxTypeId) {
                                    
                                    if (linkTaxStructure.IsSlab) {
                                        if (parseFloat(linkTaxStructure.MinRange) <= parseFloat(chargeAmount) && parseFloat(linkTaxStructure.MaxRange) >= parseFloat(chargeAmount)) {
                                            totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                                        }
                                    }
                                    else {
                                        totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                                    }
                                }
                                else {
                                    angular.forEach(room.TariffLinkTaxStructures, function (item) {
                                        if (linkTaxStructure.TaxOnTaxTypeId == item.TaxTypeId) {
                                            totalTaxPercent = parseFloat(totalTaxPercent) + ( (parseFloat(item.TaxValue) * parseFloat(linkTaxStructure.TaxValue))/ 100);
                                        }
                                    });
                                }
                            });
                        });
                        totalTariff = (parseFloat(chargeAmount) * 100) / (100 + parseFloat(totalTaxPercent));

                        angular.forEach(room.TariffLinkTaxStructures, function (linkTaxStructure, index) {
                            var tax = 0;
                            if (!linkTaxStructure.TaxOnTaxTypeId) {
                                if (linkTaxStructure.IsSlab) {
                                    if (parseFloat(linkTaxStructure.MinRange) <= parseFloat(chargeAmount) && parseFloat(linkTaxStructure.MaxRange) >= parseFloat(chargeAmount))
                                        tax = (parseFloat(totalTariff) * parseFloat(linkTaxStructure.TaxValue)) / 100;
                                }
                                else {
                                    tax = (parseFloat(totalTariff) * parseFloat(linkTaxStructure.TaxValue)) / 100;
                                }
                            }
                            else {
                                if (rate.CheckINGuestRoomRateTaxs.length > 0) {
                                    angular.forEach(rate.CheckINGuestRoomRateTaxs, function (item) {
                                        if (linkTaxStructure.TaxOnTaxTypeId == item.TaxTypeId) {
                                            if (linkTaxStructure.TaxInId === 2) {//Percent
                                                tax = parseFloat(item.TaxAmount) * parseFloat(linkTaxStructure.TaxValue) / 100;
                                            } else {
                                                tax = parseFloat(linkTaxStructure.TaxValue);
                                            }
                                        }
                                    });
                                }
                            }

                            if (tax > 0) {
                                rate.CheckINGuestRoomRateTaxs.push({
                                    Id: '',
                                    CheckINGuestRoomRateId: rate.Id,
                                    RoomItemTypeId: '1',
                                    SNo: index + 1,
                                    TaxTypeId: linkTaxStructure.TaxTypeId,
                                    TaxTypeCode: linkTaxStructure.TaxTypeCode,
                                    TaxOnId: linkTaxStructure.TaxOnId,
                                    IsTariffOn: linkTaxStructure.IsTariffOn,
                                    TaxInId: linkTaxStructure.TaxInId,
                                    TaxInName: linkTaxStructure.TaxInName,
                                    TaxValue: linkTaxStructure.TaxValue,
                                    TaxAmount: tax
                                });
                            }
                        });
                        //
                        rate.DayRateAmount = parseFloat(totalTariff);
                        rate.TariffTAXAmount = parseFloat(chargeAmount) - parseFloat(totalTariff);
                        rate.TotalTariff = parseFloat(rate.DayRateAmount) + parseFloat(rate.TariffTAXAmount);

                        rate.DayRateAmount = $filter("number")(parseFloat(rate.DayRateAmount), 2).replace(/,/g, "");
                        rate.TariffTAXAmount = $filter("number")(parseFloat(rate.TariffTAXAmount), 2).replace(/,/g, "");
                        rate.TotalTariff = $filter("number")(parseFloat(rate.TotalTariff), 2).replace(/,/g, "");

                        var discountValue = parseFloat(rate.DayRate) - parseFloat(rate.DayRateAmount);
                        rate.RateDiscountInId = "2";
                        rate.RateDiscountValue = (parseFloat(discountValue) * 100) / parseFloat(rate.DayRate);
                        if (parseFloat(rate.RateDiscountValue) < 0) {
                            
                            rate.RateDiscountInId = "1";
                            rate.RateDiscountValue = 0;
                        }
                        rate.RateDiscountValue = $filter("number")(parseFloat(rate.RateDiscountValue), 3).replace(/,/g, "");
                        //MP
                        var mpAmount = rate.MealPlanDayRateAmount;
                        totalTaxPercent = 0.0;
                        var totalMP = 0.0;
                        var TaxOnTaxTypeIds = GetDistinctTaxOnTaxTypeId(room.MealPlanLinkTaxStructures);
                        angular.forEach(TaxOnTaxTypeIds, function (taxOnTaxTypeId) {
                            var roomTariffLinkTaxStructures = room.MealPlanLinkTaxStructures.filter(x=>x.TaxOnTaxTypeId ==taxOnTaxTypeId );
                            angular.forEach(roomTariffLinkTaxStructures, function (linkTaxStructure, index) {
                                if (!linkTaxStructure.TaxOnTaxTypeId) {
                                    
                                    if (linkTaxStructure.IsSlab) {
                                        if (parseFloat(linkTaxStructure.MinRange) <= parseFloat(mpAmount) && parseFloat(linkTaxStructure.MaxRange) >= parseFloat(mpAmount)) {
                                            totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                                        }
                                    }
                                    else {
                                        totalTaxPercent = parseFloat(totalTaxPercent) + parseFloat(linkTaxStructure.TaxValue);
                                    }
                                }
                                else {
                                    angular.forEach(room.MealPlanLinkTaxStructures, function (item) {
                                        if (linkTaxStructure.TaxOnTaxTypeId == item.TaxTypeId) {
                                            totalTaxPercent = parseFloat(totalTaxPercent) + ( (parseFloat(item.TaxValue) * parseFloat(linkTaxStructure.TaxValue))/ 100);
                                        }
                                    });
                                }
                            });
                        });
                        totalMP = (parseFloat(mpAmount) * 100) / (100 + parseFloat(totalTaxPercent));
                        angular.forEach(room.MealPlanLinkTaxStructures, function (linkTaxStructure, index) {
                            var tax = 0;
                            if (!linkTaxStructure.TaxOnTaxTypeId) {
                                if (linkTaxStructure.IsSlab) {
                                    if (parseFloat(linkTaxStructure.MinRange) <= parseFloat(mpAmount) && parseFloat(linkTaxStructure.MaxRange) >= parseFloat(mpAmount))
                                        tax = (parseFloat(totalMP) * parseFloat(linkTaxStructure.TaxValue)) / 100;
                                }
                                else {
                                    tax = (parseFloat(totalMP) * parseFloat(linkTaxStructure.TaxValue)) / 100;
                                }
                            }
                            else {
                                if (rate.CheckINGuestRoomRateTaxs.length > 0) {
                                    angular.forEach(rate.CheckINGuestRoomRateTaxs, function (item) {
                                        if (linkTaxStructure.TaxOnTaxTypeId == item.TaxTypeId) {
                                            if (linkTaxStructure.TaxInId === 2) {//Percent
                                                tax = parseFloat(item.TaxAmount) * parseFloat(linkTaxStructure.TaxValue) / 100;
                                            } else {
                                                tax = parseFloat(linkTaxStructure.TaxValue);
                                            }
                                        }
                                    });
                                }
                            }

                            if (tax > 0) {
                                rate.CheckINGuestRoomRateTaxs.push({
                                    Id: '',
                                    CheckINGuestRoomRateId: rate.Id,
                                    RoomItemTypeId: '2',
                                    SNo: index + 1,
                                    TaxTypeId: linkTaxStructure.TaxTypeId,
                                    TaxTypeCode: linkTaxStructure.TaxTypeCode,
                                    TaxOnId: linkTaxStructure.TaxOnId,
                                    IsTariffOn: linkTaxStructure.IsTariffOn,
                                    TaxInId: linkTaxStructure.TaxInId,
                                    TaxInName: linkTaxStructure.TaxInName,
                                    TaxValue: linkTaxStructure.TaxValue,
                                    TaxAmount: tax
                                });
                            }
                        });
                        //
                        rate.MealPlanDayRateAmount = totalMP;
                        rate.MealPlanTAXAmount = parseFloat(mpAmount) - parseFloat(totalMP);
                        rate.TotalMealPlan = parseFloat(rate.MealPlanDayRateAmount) + parseFloat(rate.MealPlanTAXAmount);

                        rate.MealPlanDayRateAmount = $filter("number")(rate.MealPlanDayRateAmount, 2).replace(/,/g, "");
                        rate.MealPlanTAXAmount = $filter("number")(rate.MealPlanTAXAmount, 2).replace(/,/g, "");
                        rate.TotalMealPlan = $filter("number")(rate.TotalMealPlan, 2).replace(/,/g, "");

                        rate.NetDayAmount = parseFloat(rate.TotalTariff) + parseFloat(rate.TotalMealPlan);
                        rate.NetDayAmount = $filter("number")(rate.NetDayAmount, 2).replace(/,/g, "");

                        rate.TotalDayAmount = parseFloat(rate.NetDayAmount) + parseFloat(rate.NetDayExtraBedAmount);
                        rate.TotalDayAmount = $filter("number")(rate.TotalDayAmount, 2).replace(/,/g, "");

                    }


                });
            }

        });

        GetTotal(scope);
    };
    function GetDistinctTaxOnTaxTypeId(list) {
        var distinct = [];
        var newArr = list.filter(function (el) {
            if (distinct.indexOf(el.TaxOnTaxTypeId) === -1) {
                // If not present in array, then add it
                distinct.push(el.TaxOnTaxTypeId);
                return true;
            }
            else {
                // Already present in array, don't add it
                return false;
            }
        });
        return distinct;
    };

    
    var ChangeRateDiscountValue = function (scope, roomRate, index) {
        
        scope.CheckINGuestRoom.IsInclusive = false;
        if (roomRate.RateDiscountInId == '2') {
            if (roomRate.RateDiscountValue > 100) {
                parent.posFailureMessage("Discount value cann't be more then 100.");
                roomRate.RateDiscountValue = 0;
            }
        }
        else {
            if (roomRate.RateDiscountValue > roomRate.DayRate) {
                parent.posFailureMessage("Discount amount cann't be more then Rack Rate.");
                roomRate.RateDiscountValue = 0;
            }
        }

        //var newDayRate = parseFloat(roomRate.DayRate);
        var newValue = roomRate.RateDiscountValue;
        var newDiscountInId = roomRate.RateDiscountInId;

        
        var room = scope.CheckINGuestRooms.find(x=>x.RoomMasterId == scope.CheckINGuestRoom.RoomMasterId && x.FolioNo == scope.CheckINGuestRoom.FolioNo);
        if(room)
        {
            angular.forEach(room.CheckINGuestRoomRates, function (rate, key) {
                if (index <= key) {
                    //rate.DayRate = parseFloat(newDayRate);
                    rate.RateDiscountInId = newDiscountInId;
                    rate.DayRateAmount = $filter("number")(parseFloat(rate.DayRate), 2).replace(/,/g, "");
                    rate.RateDiscountValue = $filter("number")(parseFloat(newValue), 3).replace(/,/g, "");
                }
            });
        }
        //angular.forEach(scope.CheckINGuestRooms, function (room) {
        //    if (room.RoomMasterId == scope.CheckINGuestRoom.RoomMasterId && room.FolioNo == scope.CheckINGuestRoom.FolioNo) {
        //        angular.forEach(room.CheckINGuestRoomRates, function (rate, key) {
        //            if (index <= key) {
        //                //rate.DayRate = parseFloat(newDayRate);
        //                rate.RateDiscountInId = newDiscountInId;
        //                rate.DayRateAmount = $filter("number")(parseFloat(rate.DayRate), 2).replace(/,/g, "");
        //                rate.RateDiscountValue = $filter("number")(parseFloat(newValue), 3).replace(/,/g, "");
        //            }
        //        });
        //    }
        //});

        CalculateCheckINRoom(scope,roomRate);
    };
    var CalculateDiscount = function (scope, roomRate, index) {
        
        //ChangeRateDiscountValue(scope, roomRate, index);

        if (!scope.IsExtraBed) {
            if (parseFloat(roomRate.DayRateAmount) < parseFloat(roomRate.MealPlanDayRateAmount)) {
                parent.posFailureMessage("Meal Plan cann't be greater then Charge Rate.");
                roomRate.MealPlanDayRateAmount = 0;
            }
        }
        scope.CheckINGuestRoom.IsInclusive = false;

        var newDayRate = parseFloat(roomRate.DayRate);

        if (roomRate.RateDiscountInId == '1') {
            if(parseFloat(roomRate.DayRate) < parseFloat(roomRate.DayRateAmount))
            {
                roomRate.RateDiscountInId == '2'
            }
        }

        //if (roomRate.RateDiscountInId == '1') {
        //    roomRate.RateDiscountValue = parseFloat(roomRate.DayRate) - parseFloat(roomRate.DayRateAmount);
        //    roomRate.DayRate = $filter("number")(parseFloat(newDayRate), 2).replace(/,/g, "");
        //}
        //else {
            
        //}

        var newRate = parseFloat(roomRate.DayRateAmount);
        var newMPRate = parseFloat(roomRate.MealPlanDayRateAmount);
        var newEBRate = parseFloat(roomRate.ExtraBedAmount);
        var newEBMPRate = parseFloat(roomRate.ExtraBedMealPlanDayRate);
        
        var room = scope.CheckINGuestRooms.find(x=>x.RoomMasterId == scope.CheckINGuestRoom.RoomMasterId && x.FolioNo == scope.CheckINGuestRoom.FolioNo);
        if (room) {
            angular.forEach(room.CheckINGuestRoomRates, function (rate, key) {
                if (index <= key) {

                    rate.IsRateDisabled = room.RateTypeId == '2' ? true : false;

                    //Tarif
                    rate.DayRate = $filter("number")(parseFloat(newDayRate), 2).replace(/,/g, "");
                            
                    if (parseFloat(rate.DayRate) >= parseFloat(newRate)) {
                        rate.DayRateAmount = parseFloat(newRate);

                        if (roomRate.RateDiscountInId == '1') {
                            rate.RateDiscountValue = parseFloat(rate.DayRate) - parseFloat(rate.DayRateAmount);
                            //rate.RateDiscountValue = $filter("number")(parseFloat(rate.RateDiscountValue), 2).replace(/,/g, "");
                        }
                        else {
                                    
                            rate.RateDiscountInId = "2";
                            rate.RateDiscountValue = 0.0;
                            rate.RateDiscountValue = 100 * ((parseFloat(rate.DayRate) - parseFloat(rate.DayRateAmount)) / (parseFloat(rate.DayRate)));
                        }
                    }
                    else {
                                
                        //rate.RateDiscountInId = "2";
                        rate.RateDiscountValue = 0.0;
                        rate.DayRateAmount = $filter("number")(parseFloat(newRate), 2).replace(/,/g, "");
                    }

                    rate.RateDiscountValue = $filter("number")(parseFloat(rate.RateDiscountValue), 3).replace(/,/g, "");

                    //MP
                    rate.MealPlanDayRateAmount = $filter("number")(parseFloat(newMPRate), 2).replace(/,/g, "");

                    //EB
                    rate.ExtraBedAmount = $filter("number")(parseFloat(newEBRate), 2).replace(/,/g, "");
                            
                    //EB MP
                    rate.ExtraBedMealPlanDayRate = $filter("number")(parseFloat(newEBMPRate), 2).replace(/,/g, "");
                }
            });
        }

        CalculateCheckINRoom(scope);
    };

    var ChangeDayRate = function (scope, roomRate, index) {
        
        var newDayRate = parseFloat(roomRate.DayRate);

        var room = scope.CheckINGuestRooms.find(x=>x.RoomMasterId == scope.CheckINGuestRoom.RoomMasterId && x.FolioNo == scope.CheckINGuestRoom.FolioNo )
        if(room)
        {
            angular.forEach(room.CheckINGuestRoomRates, function (rate, key) {
                if (index <= key) {
                    //Tarif
                    rate.DayRate = $filter("number")(parseFloat(newDayRate), 2).replace(/,/g, "");
                }
            });
        }
        CalculateCheckINRoom(scope);
    };

    var GetChangeRate = function (scope, fromId) {

        if (!scope.CheckINGuestRoom) {
            scope.CheckINGuestRoom = {};
        }
        scope.CheckINGuestRoom.IsInclusive = false;
        scope.CheckINGuestRoom.PackageId = '';
        scope.CheckINGuestRoomPackages = [];
        scope.CheckINGuestRoomPackageDetails = [];

        scrollPageOnTop();
        if (fromId == '1') {
            scope.IsMultiRate = "1";
            ResetRateForNormalRate(scope);
        }
        else if (fromId == '2') {
            scope.IsMultiRate = "2";
            ResetRateForMultiRate(scope);
        }
        else if (fromId == '3') {
            scope.IsMultiRate = "3";
            angular.forEach(scope.Packages, function (item) {
                if (item.RoomTypeId == scope.CheckINGuestRoom.RoomTypeId) {
                    scope.CheckINGuestRoomPackages.push(item);
                }
            });
        }
    };
    function ResetRateForNormalRate(scope) {

        scope.CheckINGuestRoom.IsMultiRate = false;
        angular.forEach(scope.CheckINGuestRoom.CheckINGuestRoomRates, function (item) {

            //item.IsRateDisabled = false;
            if (!item.IsRateDisabled)
            {
                item.RateDiscountInId = '2';
                item.RateDiscountValue = 0;

                item.DayRate = $filter("number")(scope.CheckINGuestRoom.Tariff, 2).replace(/,/g, "");
                item.DayRateAmount = $filter("number")(scope.CheckINGuestRoom.Tariff, 2).replace(/,/g, "");

                item.MealPlanDiscountInId = '2';
                item.MealPlanDiscountValue = 0;

                item.MealPlanDayRate = $filter("number")(scope.CheckINGuestRoom.MealPlanRate, 2).replace(/,/g, "");
                item.MealPlanDayRateAmount = $filter("number")(scope.CheckINGuestRoom.MealPlanRate, 2).replace(/,/g, "");
            }
            
        });

        CalculateCheckINRoom(scope);

    };
    function ResetRateForMultiRate(scope) {
        scope.CheckINGuestRoom.IsMultiRate = true;
        angular.forEach(scope.CheckINGuestRoom.RoomTypeRates, function (rate, index) {
                if (scope.CheckINGuestRoom.RateMasterId == rate.RateMasterId) {
                    var occupancy = parseFloat(scope.CheckINGuestRoom.NumberOfAdult) + parseFloat(scope.CheckINGuestRoom.NumberOfChild) + parseFloat(scope.CheckINGuestRoom.NumberOfInfant);
                    angular.forEach(rate.OccupancyRates, function (occupancyRate, index) {

                        if (occupancy == occupancyRate.OccupancyId) {
                            //RoomRate
                            angular.forEach(scope.CheckINGuestRoom.CheckINGuestRoomRates, function (item) {

                                if (!item.IsRateDisabled) {

                                    var arrivalDate = moment(item.ChargeDate, scope.DateFormat.toUpperCase());
                                    var i = moment(arrivalDate).isoWeekday(); //

                                    var dayRate = 0;
                                    switch (i) {
                                        case 1:
                                            dayRate = occupancyRate.RateDay1;
                                            break;
                                        case 2:
                                            dayRate = occupancyRate.RateDay2;
                                            break;
                                        case 3:
                                            dayRate = occupancyRate.RateDay3;
                                            break;
                                        case 4:
                                            dayRate = occupancyRate.RateDay4;
                                            break;
                                        case 5:
                                            dayRate = occupancyRate.RateDay5;
                                            break;
                                        case 6:
                                            dayRate = occupancyRate.RateDay6;
                                            break;
                                        case 7:
                                            dayRate = occupancyRate.RateDay7;
                                            break;

                                        default:
                                            dayRate = occupancyRate.RateDay1;
                                    }

                                    item.IsRateDisabled = false;
                                    item.DayRate = $filter("number")(dayRate, 2).replace(/,/g, "");
                                    item.RateDiscountValue = 0;
                                    item.DayRateAmount = $filter("number")(dayRate, 2).replace(/,/g, "");

                                    //MealPlanId
                                    var dayMealRate = 0;
                                    angular.forEach(rate.OccupancyRates, function (occupancyMealPlanRate, index) {
                                        if (occupancy == occupancyMealPlanRate.OccupancyId)    //OccupancyId=this is number of guest in a room
                                        {
                                            angular.forEach(occupancyMealPlanRate.OccupancyMealPlanRates, function (mealplan, index) {
                                                if (scope.CheckINGuestRoom.MealPlanId == mealplan.MealPlanId) {
                                                    scope.CheckINGuestRoom.MealPlanCode = mealplan.MealPlanCode;
                                                    scope.CheckINGuestRoom.MealPlanRate = mealplan.RateDay1;
                                                    switch (i) {
                                                        case 1:
                                                            dayMealRate = mealplan.RateDay1;
                                                            break;
                                                        case 2:
                                                            dayMealRate = mealplan.RateDay2;
                                                            break;
                                                        case 3:
                                                            dayMealRate = mealplan.RateDay3;
                                                            break;
                                                        case 4:
                                                            dayMealRate = mealplan.RateDay4;
                                                            break;
                                                        case 5:
                                                            dayMealRate = mealplan.RateDay5;
                                                            break;
                                                        case 6:
                                                            dayMealRate = mealplan.RateDay6;
                                                            break;
                                                        case 7:
                                                            dayMealRate = mealplan.RateDay7;
                                                            break;

                                                        default:
                                                            dayMealRate = mealplan.RateDay1;
                                                    }
                                                }
                                            });
                                        }

                                    });

                                    item.MealPlanDayRate = $filter("number")(dayMealRate, 2).replace(/,/g, "");
                                    item.MealPlanDayRateAmount = $filter("number")(dayMealRate, 2).replace(/,/g, "");

                                    //extra bed meal plan
                                    dayEBMealRate = 0;

                                    var numberExtraBed = parseFloat(scope.CheckINGuestRoom.NumberExtraBed);

                                    angular.forEach(rate.OccupancyRates, function (occupancyMealPlanRate, index) {

                                        if (numberExtraBed == occupancyMealPlanRate.OccupancyId)    //OccupancyId=this is number of guest in a room
                                        {
                                            angular.forEach(occupancyMealPlanRate.OccupancyMealPlanRates, function (mealplan, index) {
                                                if (scope.CheckINGuestRoom.MealPlanId == mealplan.MealPlanId) {

                                                    switch (i) {
                                                        case 1:
                                                            dayEBMealRate = mealplan.RateDay1;
                                                            break;
                                                        case 2:
                                                            dayEBMealRate = mealplan.RateDay2;
                                                            break;
                                                        case 3:
                                                            dayEBMealRate = mealplan.RateDay3;
                                                            break;
                                                        case 4:
                                                            dayEBMealRate = mealplan.RateDay4;
                                                            break;
                                                        case 5:
                                                            dayEBMealRate = mealplan.RateDay5;
                                                            break;
                                                        case 6:
                                                            dayEBMealRate = mealplan.RateDay6;
                                                            break;
                                                        case 7:
                                                            dayEBMealRate = mealplan.RateDay7;
                                                            break;

                                                        default:
                                                            dayEBMealRate = mealplan.RateDay1;

                                                    }

                                                }
                                            });
                                        }

                                    });
                                    
                                    item.ExtraBedMealPlanDayRate = dayEBMealRate;
                                    item.ExtraBedMealPlanDayRate = $filter("number")(item.ExtraBedMealPlanDayRate, 2).replace(/,/g, "");

                                }
                            });
                        }
                    });
                }
                
        });

        CalculateCheckINRoom(scope);

    };
    
    var SetReservationRoomTypeRate = function (scope, checkINGuest) {
        var businessDateStr = scope.BusinessDate.Year + "-" + scope.BusinessDate.Month + "-" + scope.BusinessDate.Day;
        //ReservationRoomTypeRates                        
        if (checkINGuest.ReservationRoomTypeRates.length > 0) {
            checkINGuest.CheckINGuestRoom.CheckINGuestRoomRates = [];
            angular.forEach(checkINGuest.ReservationRoomTypeRates, function (item) {

                extraBedAmount = item.ExtraBedAmount;
                if (checkINGuest.IsExtraBed == true) {
                    //TODO Navneet
                }

                var isRateDisable = false;
                var chargeDate = GetMomentDate($filter('date')(item.ChargeDate, scope.DateFormat), scope.DateFormat);
                var currentDate = GetMomentDate(businessDateStr, 'YYYY-MM-DD');
                if (chargeDate.isBefore(currentDate)) {
                    isRateDisable = true;
                }

                var extraBedNumber = 0;
                var extraBedAmount = 0;
                var extraBedTAXAmount = 0;
                var totalExtraBed = 0;

                var extraBedMealPlanDayRate = 0;
                var ExtraBedMealPlanTAXAmount = 0;
                var TotalExtraBedMealPlan = 0;
                var NetDayExtraBedAmount = 0;
                
                checkINGuest.CheckINGuestRoom.CheckINGuestRoomRates.push({
                    IsRateDisabled: isRateDisable,
                    CheckINGuestRoomId: item.CheckINGuestRoomId,
                    ChargeDate: $filter('date')(item.ChargeDate, scope.DateFormat),
                    DayRate: parseFloat(item.DayRate) / parseFloat(checkINGuestRoom.TotalFolio),
                    
                    RateDiscountInId:  item.RateDiscountInId.toString(),
                    RateDiscountValue: parseFloat(item.RateDiscountValue),
                    DayRateAmount: parseFloat(item.DayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio),
                    TariffTAXAmount: parseFloat(item.TariffTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio),

                    MealPlanDayRate: parseFloat(item.MealPlanDayRate) / parseFloat(checkINGuestRoom.TotalFolio),
                    MealPlanDayRateAmount: parseFloat(item.MealPlanDayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio),
                    MealPlanDiscountInId: item.MealPlanDiscountInId.toString(),
                    MealPlanDiscountValue: parseFloat(item.MealPlanDiscountValue),
                    MealPlanDayRateAmount: parseFloat(item.MealPlanDayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio),
                    MealPlanTAXAmount: parseFloat(item.MealPlanTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio),
                    ExtraBedNumber: extraBedNumber,
                    ExtraBedAmount: extraBedAmount,
                    ExtraBedTAXAmount: 0,
                    TotalExtraBed: 0,
                    ExtraBedMealPlanDayRate: extraBedMealPlanDayRate,
                    ExtraBedMealPlanTAXAmount: 0,
                    TotalExtraBedMealPlan: 0,
                    NetDayExtraBedAmount: 0,

                    TotalDayAmount: parseFloat(item.DayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio) + parseFloat(item.TariffTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio)
                    + parseFloat(item.MealPlanDayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio) + parseFloat(item.MealPlanTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio),

                    TotalTariff: parseFloat(item.DayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio) + parseFloat(item.TariffTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio),
                    NetDayAmount: parseFloat(item.DayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio) + parseFloat(item.TariffTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio)
                    + parseFloat(item.MealPlanDayRateAmount) / parseFloat(checkINGuestRoom.TotalFolio) + parseFloat(item.MealPlanTAXAmount) / parseFloat(checkINGuestRoom.TotalFolio),

                    NumberOfAdultExtraBed: 0,
                    NumberOfChildExtraBed: 0,
                    NumberOfInfantExtraBed: 0,


                    EarlyArrivalCharge: 0,
                    LateDepartureCharge: 0,
                    TotalFolio: parseFloat(checkINGuestRoom.TotalFolio),
                });

            });
        }
    }

    var SetInterPropertyTransferRate = function (scope, checkINGuestRoom) {
        scope.CheckINGuestRoomRates = [];
        var localid = 1;
        for (var i = 0; i <= checkINGuestRoom.Nights - 1; i++) {

            SetExtraBedAmount(checkINGuestRoom);

            var numberOfAdultExtraBed = checkINGuestRoom.NumberOfAdultExtraBed;
            var adultExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfAdultExtraBed) * parseFloat(checkINGuestRoom.ExtraBedAdultRate);
            var numberOfChildExtraBed = parseFloat(checkINGuestRoom.NumberOfChildExtraBed);
            var childExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfChildExtraBed) * parseFloat(checkINGuestRoom.ExtraBedChildRate);
            var numberOfInfantExtraBed = parseFloat(checkINGuestRoom.NumberOfInfantExtraBed);
            var infantExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfInfantExtraBed) * parseFloat(checkINGuestRoom.ExtraBedInfantRate);
            var extraBedNumber = parseFloat(checkINGuestRoom.ExtraBedNumber);
            var extraBedAmount = parseFloat(adultExtraBedAmount) + parseFloat(childExtraBedAmount) + parseFloat(infantExtraBedAmount);

            var businessDate = $filter('date')(scope.ModifiedDate, scope.DateFormat);
            var nexDate = GetJavaScriptDate(businessDate, scope.DateFormat, i);
            scope.CheckINGuestRoomRates.push({
                IsRateDisabled: checkINGuestRoom.RateTypeId == '2' ? true : false,
                id: localid, //localid
                checkINGuestRoomId: checkINGuestRoom.id,
                Id: '',
                RoomTypeId: checkINGuestRoom.RoomTypeId,
                RoomTypeName: checkINGuestRoom.RoomTypeName,

                CheckINGuestRoomId: '',
                CheckINGuestId: '',
                CheckINId: '',

                ChargeDate: $filter("date")(nexDate, scope.DateFormat),
                DayRate: checkINGuestRoom.Tariff,
                RateDiscountInId: '2',
                RateDiscountInName: '',

                RateDiscountValue: 0,

                DayRateAmount: checkINGuestRoom.Tariff,
                TariffTAXAmount: 0,
                TotalTariff: 0,
                MealPlanId: checkINGuestRoom.MealPlanId,
                MealPlanCode: checkINGuestRoom.MealPlanCode,

                MealPlanDayRate: checkINGuestRoom.MealPlanRate,
                MealPlanDiscountInId: 2,
                MealPlanDiscountInName: '',
                MealPlanDiscountValue: 0,
                MealPlanDayRateAmount: checkINGuestRoom.MealPlanRate,
                MealPlanTAXAmount: 0,
                
                NumberOfAdultExtraBed: numberOfAdultExtraBed,
                AdultExtraBedAmount: adultExtraBedAmount,

                NumberOfChildExtraBed: numberOfChildExtraBed,
                ChildExtraBedAmount: childExtraBedAmount,

                NumberOfInfantExtraBed: numberOfInfantExtraBed,
                InfantExtraBedAmount: infantExtraBedAmount,
                
                ExtraBedNumber: checkINGuestRoom.ExtraBedNumber ?checkINGuestRoom.ExtraBedNumber : checkINGuestRoom.ExtraBedNumber,
                ExtraBedAmount: checkINGuestRoom.ExtraBedAmount ? checkINGuestRoom.ExtraBedAmount : 0,

                ExtraBedTAXAmount: 0,
                TotalExtraBed: 0,

                ExtraBedMealPlanDayRate: checkINGuestRoom.ExtraBedMealPlanDayRate ? checkINGuestRoom.ExtraBedMealPlanDayRate :0 ,
                ExtraBedMealPlanTAXAmount: 0,
                TotalExtraBedMealPlan: 0,
                NetDayExtraBedAmount: 0,
                TotalDayAmount: 0,
                EarlyArrivalCharge: 0,
                LateDepartureCharge: 0,

                CheckINGuestRoomRateTaxs: [],
                RateTaxStructureId: checkINGuestRoom.RateTaxStructureId,
                MealPlanTaxStructureId: checkINGuestRoom.MealPlanTaxStructureId,
                MealPlanTAXStructureName: checkINGuestRoom.MealPlanTAXStructureName,
                MealPlanTAXAmount: 0,

                PropertyID: scope.PropertyID,
                ModifiedBy: scope.ModifiedBy,
                DateFormat: scope.DateFormat,
            });
            localid++;
        }
        
        checkINGuestRoom.CheckINGuestRoomRates = angular.copy(scope.CheckINGuestRoomRates);
        CalculateCheckINRoom(scope);
        GetTotal(scope);
    }

    var SetRate = function (scope, checkINGuestRoom) {
        if (checkINGuestRoom) {
            var checkINGuest = '';
            angular.forEach(scope.Model.CheckINGuests, function (item) {
                if (checkINGuestRoom.SNo == item.SNo && checkINGuestRoom.FolioNo == item.FolioNo) {
                    checkINGuest = item;
                }
            });

            if (checkINGuest.ReservationRoomType) {
                SetTax(scope, checkINGuestRoom);
                SetReservationRoomTypeRate(scope, checkINGuest);
                CalculateCheckINRoom(scope);
            }
            else {
                SetTariff(scope, checkINGuestRoom);
                SetNight(scope, checkINGuestRoom);
            }
        }
    }
    var SetTax = function (scope, checkINGuestRoom) {
        
        checkINGuestRoom.TariffLinkTaxStructures=[];
        checkINGuestRoom.MealPlanLinkTaxStructures = [];

        if(checkINGuestRoom.RateTaxStructureId)
        {
            if (scope.DefaultSetting.ExemptRackRateTAXStayLength>0 && scope.DefaultSetting.ExemptRackRateTAXStayLength <= checkINGuestRoom.Nights)
            {
                checkINGuestRoom.IsExemptRackRateTAXStay = true;
                checkINGuestRoom.RateTaxStructureId='';
                checkINGuestRoom.TariffLinkTaxStructures = [];
                msg("Rack Rate TAX Exempted. Because Stay Length Exceeded From " + scope.DefaultSetting.ExemptRackRateTAXStayLength  + ' Days.', true);
            }
            else
            {
                var linkTaxStructures = scope.LinkTaxStructures.filter(x=>x.TaxStructureId == checkINGuestRoom.RateTaxStructureId);
                checkINGuestRoom.IsExemptRackRateTAXStay = false;
                checkINGuestRoom.TariffLinkTaxStructures = angular.copy(linkTaxStructures);
            }

            //angular.forEach(scope.TaxStructures, function (tax) {
            //    if (checkINGuestRoom.RateTaxStructureId == tax.Id) {
            //        if (scope.DefaultSetting.ExemptRackRateTAXStayLength>0 && scope.DefaultSetting.ExemptRackRateTAXStayLength <= checkINGuestRoom.Nights)
            //        {
            //            checkINGuestRoom.IsExemptRackRateTAXStay = true;
            //            checkINGuestRoom.RateTaxStructureId='';
            //            checkINGuestRoom.TariffLinkTaxStructures = [];
            //            msg("Rack Rate TAX Exempted. Because Stay Length Exceeded From " + scope.DefaultSetting.ExemptRackRateTAXStayLength  + ' Days.', true);
            //        }
            //        else
            //        {
            //            checkINGuestRoom.IsExemptRackRateTAXStay = false;
            //            checkINGuestRoom.TariffLinkTaxStructures = angular.copy(tax.LinkTaxStructures);
            //        }
            //    }
            //});

        }

        if(checkINGuestRoom.MealPlanTaxStructureId)
        {
            var linkTaxStructures = scope.LinkTaxStructures.filter(x=>x.TaxStructureId == checkINGuestRoom.MealPlanTaxStructureId);
            checkINGuestRoom.MealPlanLinkTaxStructures = angular.copy(linkTaxStructures);

            //angular.forEach(scope.TaxStructures, function (tax) {
            //    if (checkINGuestRoom.MealPlanTaxStructureId == tax.Id) {
            //        checkINGuestRoom.MealPlanLinkTaxStructures = angular.copy(tax.LinkTaxStructures);
            //    }
            //});
        }
    }
    function SetTariff(scope, checkINGuestRoom) {

        
        checkINGuestRoom.Amount = 0;
        checkINGuestRoom.TotalAmount = 0;

        
        if(checkINGuestRoom.RateMasterId)
        {
            var rates = checkINGuestRoom.RoomTypeRates.filter(x=>x.RateMasterId == checkINGuestRoom.RateMasterId && x.RoomTypeId == checkINGuestRoom.RoomTypeId );
            angular.forEach(rates, function (rate, index) {
                //angular.forEach(scope.RateMasters, function (rateMaster, index) {
                //    if (rateMaster.Id == checkINGuestRoom.RateMasterId) {
                //        checkINGuestRoom.RateTypeId = rateMaster.RateTypeId;
                //    }
                //});

                checkINGuestRoom.RateTypeId = rate.RateTypeId;
                checkINGuestRoom.RateMasterCode = rate.RateMasterCode;
                checkINGuestRoom.IsTariffPlanInclusive = rate.IsTariffPlanInclusive;
                checkINGuestRoom.IsTariffTAXInclusive = rate.IsTariffTAXInclusive;
                checkINGuestRoom.RateTaxStructureId = rate.RateTaxStructureId;
                checkINGuestRoom.MealPlanTaxStructureId = rate.MealPlanTAXStructureId;
                checkINGuestRoom.TotalDayRate = 0;
                checkINGuestRoom.TotalDayRateAmount = 0;
                checkINGuestRoom.TotalTariffTAXAmount = 0;
                checkINGuestRoom.TotalMealPlanDayRateAmount = 0;
                checkINGuestRoom.TotalMealPlanTAXAmount = 0;
                checkINGuestRoom.TotalNetDayAmount = 0;

                //ExtraBed
                checkINGuestRoom.ExtraBedAdultRate = 0;
                checkINGuestRoom.ExtraBedChildRate = 0;
                checkINGuestRoom.ExtraBedInfantRate = 0;
                checkINGuestRoom.ExtraBedMealPlanDayRate = 0;
                checkINGuestRoom.TotalExtraBedAmount = 0;
                checkINGuestRoom.TotalExtraBedTAXAmount = 0;
                checkINGuestRoom.TotalMealPlanDayRateAmount = 0;
                checkINGuestRoom.TotalMealPlanTAXAmount = 0;
                checkINGuestRoom.TotalNetDayAmount = 0;

                var occupancy = parseFloat(checkINGuestRoom.NumberOfAdult) + parseFloat(checkINGuestRoom.NumberOfChild) + parseFloat(checkINGuestRoom.NumberOfInfant);
                var extraBedOccupancy = parseFloat(checkINGuestRoom.NumberOfAdultExtraBed) + parseFloat(checkINGuestRoom.NumberOfChildExtraBed) + parseFloat(checkINGuestRoom.NumberOfInfantExtraBed);
                if (extraBedOccupancy) {
                    occupancy = parseFloat(occupancy) - parseFloat(extraBedOccupancy);
                }
                SetTax(scope, checkINGuestRoom);

                //Tarif
                angular.forEach(scope.OccupancyRates, function (occupancyRate, index) {
                    if (occupancy == occupancyRate.OccupancyId && checkINGuestRoom.RateMasterId ==  occupancyRate.RateMasterId && checkINGuestRoom.RoomTypeId ==  occupancyRate.RoomTypeId) {
                        checkINGuestRoom.Tariff = parseFloat(occupancyRate.RateDay1);
                        var occupancyMealPlanRate = scope.OccupancyMealPlanRates.find(x=>x.OccupancyRateId == occupancyRate.OccupancyRateId && x.MealPlanId == checkINGuestRoom.MealPlanId && x.RateMasterId ==  occupancyRate.RateMasterId && x.RoomTypeId ==  occupancyRate.RoomTypeId);
                        if(occupancyMealPlanRate)
                        {
                            checkINGuestRoom.MealPlanCode = occupancyMealPlanRate.MealPlanCode;
                            checkINGuestRoom.MealPlanRate = occupancyMealPlanRate.RateDay1;
                        }
                    }
                    else if (occupancy == 0) {
                        checkINGuestRoom.Tariff = 0;
                        checkINGuestRoom.MealPlanRate = 0;
                    }
                });

                //Extra Bed
                //var occupancyRate = scope.OccupancyRates.find(x=>x.OccupancyId==checkINGuestRoom.ExtraBedNumber);
                var occupancyRate = scope.OccupancyRates.find(x=>x.OccupancyId==checkINGuestRoom.ExtraBedNumber && x.RoomTypeId==checkINGuestRoom.RoomTypeId  && x.RateMasterId==checkINGuestRoom.RateMasterId);
                if(occupancyRate)
                {
                    checkINGuestRoom.ExtraBedAdultRate = parseFloat(occupancyRate.ExtraBedAdultRate);
                    checkINGuestRoom.ExtraBedChildRate = parseFloat(occupancyRate.ExtraBedChildRate);
                    checkINGuestRoom.ExtraBedInfantRate = parseFloat(occupancyRate.ExtraBedInfantRate);

                    var occupancyMealPlanRate = scope.OccupancyMealPlanRates.find(x=>x.OccupancyRateId == occupancyRate.OccupancyRateId && x.MealPlanId == checkINGuestRoom.MealPlanId);
                    if(occupancyMealPlanRate)
                    {
                        checkINGuestRoom.ExtraBedMealPlanCode = occupancyMealPlanRate.MealPlanCode;
                        checkINGuestRoom.ExtraBedMealPlanDayRate = occupancyMealPlanRate.RateDay1;
                    }
                }

                //angular.forEach(scope.OccupancyRates, function (occupancyRate, index) {
                //    if (checkINGuestRoom.ExtraBedNumber == occupancyRate.OccupancyId) 
                //    {
                //        angular.forEach(scope.OccupancyMealPlanRates, function (occupancyMealPlanRate, index) {
                //            if (checkINGuestRoom.MealPlanId == occupancyMealPlanRate.MealPlanId) {
                //                checkINGuestRoom.ExtraBedMealPlanCode = occupancyMealPlanRate.MealPlanCode;
                //                checkINGuestRoom.ExtraBedMealPlanDayRate = occupancyMealPlanRate.RateDay1;
                //            }
                //        });
                //    }
                //});
            });
        }
        
    }
    var SetNight = function (scope, checkINGuestRoom) {
        var businessDateStr = scope.BusinessDate.Year + "-" + scope.BusinessDate.Month + "-" + scope.BusinessDate.Day;
        if (checkINGuestRoom.CheckINGuestId) {
            angular.forEach(checkINGuestRoom.CheckINGuestRoomRates, function (checkINGuestRoomRate) {

                checkINGuestRoom.Nights = checkINGuestRoom.CheckINGuestRoomRates.length;

                //for (var i = 0; i <= checkINGuestRoom.Nights - 1; i++) {
                
                for (var i = 0; i <= checkINGuestRoom.CheckINGuestRoomRates.length - 1; i++) {
                    
                    if (!checkINGuestRoom.CheckINGuestRoomRates[i].IsRateDisabled) {
                        if (checkINGuestRoom.RateTypeId == '2')//For Corporate Rate
                        {
                            checkINGuestRoomRate.IsRateDisabled = true;
                        }

                        var chargeDate = GetMomentDate(checkINGuestRoomRate.ChargeDate, scope.DateFormat);
                        var nextDate = GetMomentDate(businessDateStr, 'YYYY-MM-DD');
                        nextDate = nextDate.add(i, 'days');

                        if (chargeDate.isSame(nextDate)) {
                            var occupancy = parseFloat(checkINGuestRoom.NumberOfAdult) + parseFloat(checkINGuestRoom.NumberOfChild) + parseFloat(checkINGuestRoom.NumberOfInfant);
                            checkINGuestRoomRate.OccupancyId = occupancy;

                            checkINGuestRoomRate.DayRate = checkINGuestRoom.Tariff;
                            checkINGuestRoomRate.RateDiscountInId = checkINGuestRoom.IsInclusive ? checkINGuestRoomRate.RateDiscountInId : '2';
                            checkINGuestRoomRate.RateDiscountInName = '';
                            checkINGuestRoomRate.RateDiscountValue = checkINGuestRoom.IsInclusive ? checkINGuestRoomRate.RateDiscountValue : 0;
                            checkINGuestRoomRate.DayRateAmount = checkINGuestRoom.IsInclusive ? checkINGuestRoomRate.DayRateAmount : checkINGuestRoom.Tariff;

                            checkINGuestRoomRate.MealPlanDayRate = checkINGuestRoom.MealPlanRate;
                            checkINGuestRoomRate.MealPlanDiscountInId = checkINGuestRoom.IsInclusive ? checkINGuestRoomRate.MealPlanDiscountInId : '2';
                            checkINGuestRoomRate.MealPlanDiscountInName = '';
                            checkINGuestRoomRate.MealPlanDiscountValue = checkINGuestRoom.IsInclusive ? checkINGuestRoomRate.MealPlanDiscountValue : 0;
                            checkINGuestRoomRate.MealPlanDayRateAmount = checkINGuestRoom.IsInclusive ? checkINGuestRoomRate.MealPlanDayRateAmount : checkINGuestRoom.MealPlanRate;

                        }
                        
                        SetExtraBedAmount(checkINGuestRoom);
                        checkINGuestRoomRate.ExtraBedNumber = checkINGuestRoom.ExtraBedNumber;
                        checkINGuestRoomRate.ExtraBedAmount = checkINGuestRoom.ExtraBedAmount;
                        checkINGuestRoomRate.ExtraBedMealPlanDayRate = checkINGuestRoom.ExtraBedMealPlanDayRate;
                    }
                }
                GetChangeRate(scope, scope.IsMultiRate);

            });
        }
        else {
            scope.CheckINGuestRoomRates = [];
            var localid = 1;
            for (var i = 0; i <= checkINGuestRoom.Nights - 1; i++) {

                SetExtraBedAmount(checkINGuestRoom);

                var numberOfAdultExtraBed = checkINGuestRoom.NumberOfAdultExtraBed;
                var adultExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfAdultExtraBed) * parseFloat(checkINGuestRoom.ExtraBedAdultRate);
                var numberOfChildExtraBed = parseFloat(checkINGuestRoom.NumberOfChildExtraBed);
                var childExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfChildExtraBed) * parseFloat(checkINGuestRoom.ExtraBedChildRate);
                var numberOfInfantExtraBed = parseFloat(checkINGuestRoom.NumberOfInfantExtraBed);
                var infantExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfInfantExtraBed) * parseFloat(checkINGuestRoom.ExtraBedInfantRate);
                var extraBedNumber = parseFloat(checkINGuestRoom.ExtraBedNumber);
                var extraBedAmount = parseFloat(adultExtraBedAmount) + parseFloat(childExtraBedAmount) + parseFloat(infantExtraBedAmount);

                var businessDate = $filter('date')(scope.ModifiedDate, scope.DateFormat);
                var nexDate = GetJavaScriptDate(businessDate, scope.DateFormat, i);
                
                scope.CheckINGuestRoomRates.push({
                    IsRateDisabled: checkINGuestRoom.RateTypeId == '2' ? true : false,
                    id: localid, //localid
                    checkINGuestRoomId: checkINGuestRoom.id,
                    Id: '',
                    RoomTypeId: checkINGuestRoom.RoomTypeId,
                    RoomTypeName: checkINGuestRoom.RoomTypeName,

                    CheckINGuestRoomId: '',
                    CheckINGuestId: '',
                    CheckINId: '',

                    ChargeDate: $filter("date")(nexDate, scope.DateFormat),
                    DayRate: checkINGuestRoom.Tariff,
                    RateDiscountInId: '2',
                    RateDiscountInName: '',

                    RateDiscountValue: 0,

                    DayRateAmount: checkINGuestRoom.Tariff,
                    TariffTAXAmount: 0,
                    TotalTariff: 0,
                    MealPlanId: checkINGuestRoom.MealPlanId,
                    MealPlanCode: checkINGuestRoom.MealPlanCode,

                    MealPlanDayRate: checkINGuestRoom.MealPlanRate,
                    MealPlanDiscountInId: 2,
                    MealPlanDiscountInName: '',
                    MealPlanDiscountValue: 0,
                    MealPlanDayRateAmount: checkINGuestRoom.MealPlanRate,
                    MealPlanTAXAmount: 0,

                    //TotalMealPlan :          0,
                    //NetDayAmount :           0,

                    NumberOfAdultExtraBed: numberOfAdultExtraBed,
                    AdultExtraBedAmount: adultExtraBedAmount,

                    NumberOfChildExtraBed: numberOfChildExtraBed,
                    ChildExtraBedAmount: childExtraBedAmount,

                    NumberOfInfantExtraBed: numberOfInfantExtraBed,
                    InfantExtraBedAmount: infantExtraBedAmount,

                    ExtraBedNumber: checkINGuestRoom.ExtraBedNumber,
                    ExtraBedAmount: checkINGuestRoom.ExtraBedAmount,

                    ExtraBedTAXAmount: 0,
                    TotalExtraBed: 0,

                    ExtraBedMealPlanDayRate: checkINGuestRoom.ExtraBedMealPlanDayRate,
                    ExtraBedMealPlanTAXAmount: 0,
                    TotalExtraBedMealPlan: 0,
                    NetDayExtraBedAmount: 0,
                    TotalDayAmount: 0,
                    EarlyArrivalCharge: 0,
                    LateDepartureCharge: 0,

                    CheckINGuestRoomRateTaxs: [],
                    RateTaxStructureId: checkINGuestRoom.RateTaxStructureId,
                    MealPlanTaxStructureId: checkINGuestRoom.MealPlanTaxStructureId,
                    MealPlanTAXStructureName: checkINGuestRoom.MealPlanTAXStructureName,
                    MealPlanTAXAmount: 0,

                    PropertyID: scope.PropertyID,
                    ModifiedBy: scope.ModifiedBy,
                    DateFormat: scope.DateFormat,
                });
                localid++;
            }
            
            checkINGuestRoom.CheckINGuestRoomRates = angular.copy(scope.CheckINGuestRoomRates);
            GetChangeRate(scope, scope.IsMultiRate);
        }

    };
    var SetExtraBedAmount = function (checkINGuestRoom) {

        var numberOfAdultExtraBed = checkINGuestRoom.NumberOfAdultExtraBed;
        var adultExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfAdultExtraBed) * parseFloat(checkINGuestRoom.ExtraBedAdultRate);
        var numberOfChildExtraBed = parseFloat(checkINGuestRoom.NumberOfChildExtraBed);
        var childExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfChildExtraBed) * parseFloat(checkINGuestRoom.ExtraBedChildRate);
        var numberOfInfantExtraBed = parseFloat(checkINGuestRoom.NumberOfInfantExtraBed);
        var infantExtraBedAmount = parseFloat(checkINGuestRoom.NumberOfInfantExtraBed) * parseFloat(checkINGuestRoom.ExtraBedInfantRate);
        checkINGuestRoom.ExtraBedNumber = parseFloat(checkINGuestRoom.ExtraBedNumber);
        checkINGuestRoom.ExtraBedAmount = parseFloat(adultExtraBedAmount) + parseFloat(childExtraBedAmount) + parseFloat(infantExtraBedAmount);

    };
    //CheckINGuestRooms
    var SetPaxAndEB = function (checkINGuestRooms,checkINGuests) {

        angular.forEach(checkINGuestRooms, function (checkINGuestRoom) {
            if (checkINGuestRoom.FolioNo) {
                checkINGuestRoom.NumberOfPax = 0;
                checkINGuestRoom.NumberOfAdult = 0;
                checkINGuestRoom.NumberOfChild = 0;
                checkINGuestRoom.NumberOfInfant = 0;

                checkINGuestRoom.ExtraBedNumber = 0;
                checkINGuestRoom.NumberOfAdultExtraBed = 0;
                checkINGuestRoom.NumberOfChildExtraBed = 0;
                checkINGuestRoom.NumberOfInfantExtraBed = 0;

                angular.forEach(checkINGuests, function (item) {
                    if (checkINGuestRoom.RoomMasterId == item.RoomMasterId && checkINGuestRoom.FolioNo == item.FolioNo) {

                        checkINGuestRoom.NumberOfPax++;

                        if (item.PaxTypeId == '1') {
                            checkINGuestRoom.NumberOfAdult++;
                        }
                        else if (item.PaxTypeId == '2') {
                            checkINGuestRoom.NumberOfChild++;
                        }
                        else if (item.PaxTypeId == '3') {
                            checkINGuestRoom.NumberOfInfant++;
                        }

                        if (item.IsExtraBed) {
                            if (item.PaxTypeId == '1') {
                                checkINGuestRoom.NumberOfAdultExtraBed++;
                            }
                            else if (item.PaxTypeId == '2') {
                                checkINGuestRoom.NumberOfChildExtraBed++;
                            }
                            else if (item.PaxTypeId == '3') {
                                checkINGuestRoom.NumberOfInfantExtraBed++;
                            }

                            checkINGuestRoom.ExtraBedNumber++;
                        }
                    }
                });
            }
        });

        //Remove NumberOfPax=0 Room
        angular.forEach(checkINGuestRooms, function (checkINGuestRoom, index) {
            if (checkINGuestRoom.NumberOfPax == 0) {
                checkINGuestRooms.splice(index, 1);
            }
        });
    }
    //filters for Posting
    var selectedRateTypeRackRate = ['1'];
    var selectedRateTypeAll = ['1', '2'];
    var filterForRateType = function (scope, rate) {
        
        if (!scope.CheckINGuestRoom) {
            return;
        }
        if (!scope.CheckINGuestRoom.CorporateId) {

            scope.CheckINGuestRoom.CorporateId = "";
        }
        
        if (scope.CheckINGuestRoom.CorporateId.length > 0) {
            return (selectedRateTypeAll.indexOf(rate.RateTypeId.toString()) !== -1);
        }
        else {
            return (selectedRateTypeRackRate.indexOf(rate.RateTypeId.toString()) !== -1);
        }
    };

    var GetLinkTaxStructure = function(linkTaxStructures){
        
        var TaxStructures={

            LinkTaxStructures:[],
            TAXAmount:0,
        };

        angular.forEach(linkTaxStructures, function (linkTaxStructure, index) {

            taxAmount = GetTaxAmount(rate.CheckINGuestRoomRateTaxs, linkTaxStructure, parseFloat(rate.DayRate), parseFloat(rate.DayRateAmount));
            if (isNaN(taxAmount)) {
                taxAmount = 0;
            }
            taxAmount = $filter("number")(taxAmount, 2).replace(/,/g, "");
                
            rate.CheckINGuestRoomRateTaxs.push({
                CheckINGuestRoomRateId: '',
                RoomItemTypeId: '1',  //1=Tariff, 2=MP and 3=EB
                SNo: i,
                TaxTypeId: linkTaxStructure.TaxTypeId,
                TaxTypeCode: linkTaxStructure.TaxTypeCode,
                TaxOnId: linkTaxStructure.TaxOnId,
                TaxOnTaxTypeId: linkTaxStructure.TaxOnTaxTypeId,
                IsTariffOn: linkTaxStructure.IsTariffOn,
                TaxInId: linkTaxStructure.TaxInId,
                TaxInName: linkTaxStructure.TaxInName,
                TaxValue: linkTaxStructure.TaxValue,
                TaxAmount: parseFloat(taxAmount),
            });
            i = 1 + i;
            rate.TariffTAXAmount = parseFloat(rate.TariffTAXAmount) + parseFloat(taxAmount);
        })

    }

    return {
        CalculateCheckINRoom: CalculateCheckINRoom,
        GetTotal: GetTotal,
        IsInclusive: IsInclusive,
        ChangeRateDiscountValue: ChangeRateDiscountValue,
        CalculateDiscount: CalculateDiscount,
        GetChangeRate: GetChangeRate,
        SetReservationRoomTypeRate: SetReservationRoomTypeRate,
        SetInterPropertyTransferRate:SetInterPropertyTransferRate,
        SetRate: SetRate,
        SetTax: SetTax,
        SetNight: SetNight,
        SetExtraBedAmount: SetExtraBedAmount,
        filterForRateType: filterForRateType,
        SetPaxAndEB: SetPaxAndEB,
        ChangeDayRate:ChangeDayRate,
    };
}
]);