﻿
'use strict';
(function () {
    function service($http, $q, $filter) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getAllPOVendor = function (poStatusTypeId, searchText, searchType, propertyId) {

            var url = apiPath + "Inventory/PurchaseOrder/GetAllPOVendor?poStatusTypeId=" + poStatusTypeId + "&searchText=" + searchText + "&searchType=" + searchType + "&propertyId=" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var save = function (model) {

            var deferred = $q.defer();
            var url = apiPath + 'Inventory/PurchaseOrder/save';
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };
        var getAllVendor = function (propertyId) {

            var url = apiPath + 'Inventory/Vendor/all?searchValue=' + "" + '&propertyId=' + propertyId + '&active=1';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getAllTaxStructure = function (moduleId, propertyId) {
            var url = apiPath + 'GlobalSetting/TaxStructure/' + moduleId + "/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getReason = function (propertyId) {
            var url = apiPath + 'GlobalSetting/Reason/all/?propertyId=' + propertyId + '&moduleId=5&active=1';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getAllPR = function (propertyId, statusTypeId, searchText, searchType) {
            return httpCaller(apiPath + "Inventory/PurchaseRequisition/all", $http, $q, { propertyId: propertyId, statusTypeId: statusTypeId, searchText: searchText, searchType: searchType, takeDisplay: true });
        };
        var MapReport = function (filterValue, reportName) {
            return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
        };
        var getItemRate = function (propertyId, itemId, brandId) {
            if (!brandId) brandId = "0";
            var params = { propertyId: propertyId, itemId: itemId, brandId: brandId };
            return httpCaller(apiPath + "Inventory/InventoryTransactionItem/LastRate", $http, $q, params);
        };

        function getItemSearch(searchTxt, propertyId, vendorId, date) {

            $("#searchItem")
                .autocomplete({
                    source: function (request, response) {

                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: apiPath + 'Inventory/InventoryItem/AllBySearchTxt?searchTxt=' + searchTxt + "&propertyId=" + propertyId,
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {
                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.Name,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {

                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();

                                scope.$apply(function () {
                                    var promiseGet = getSearchitemsDetails(ui.item.val, propertyId, vendorId, date);
                                    promiseGet.then(function (data, status) {

                                        scope.InventoryItem = data.Data;
                                        if ((scope.InventoryItem != null) && scope.InventoryItem != '') {

                                            scope.PurchaseOrderItem = {};
                                            scope.PurchaseOrderItem.Id = '';
                                            scope.PurchaseOrderItem.PurchaseOrderId = '';
                                            scope.PurchaseOrderItem.StoreId = scope.InventoryItem.StoreId;
                                            scope.PurchaseOrderItem.StoreName = scope.InventoryItem.StoreName;
                                            scope.PurchaseOrderItem.CostCenterId = '';
                                            scope.PurchaseOrderItem.CostCenterName = '';
                                            scope.PurchaseOrderItem.InventoryItemId = scope.InventoryItem.Id;
                                            scope.PurchaseOrderItem.InventoryItemName = scope.InventoryItem.Name;
                                            scope.PurchaseOrderItem.InventoryItemCode = scope.InventoryItem.Code;
                                            scope.PurchaseOrderItem.ItemTypeId = scope.InventoryItem.ItemTypeId;
                                            scope.PurchaseOrderItem.ItemTypeName = scope.InventoryItem.ItemTypeName;
                                            scope.PurchaseOrderItem.BrandId = '';
                                            scope.PurchaseOrderItem.BrandName = '';
                                            scope.PurchaseOrderItem.UnitOfMeasurementId = scope.InventoryItem.UnitOfMeasurementId;
                                            scope.PurchaseOrderItem.UnitOfMeasurementName = scope.InventoryItem.UnitOfMeasurementName;
                                            scope.PurchaseOrderItem.Rate = scope.InventoryItem.Rate;
                                            scope.PurchaseOrderItem.Quantity = 0;
                                            scope.PurchaseOrderItem.Amount = 0;
                                            scope.PurchaseOrderItem.Discount = 0;
                                            scope.PurchaseOrderItem.DiscountIn = '',
                                            scope.PurchaseOrderItem.DiscountInId = '1';
                                            scope.PurchaseOrderItem.DiscountInName = '',
                                            scope.PurchaseOrderItem.TaxAmount = 0;
                                            scope.PurchaseOrderItem.TaxStructureId = '';
                                            scope.PurchaseOrderItem.DeliveryDate = scope.ModifiedDate;// .SelectedDeliveryDate;

                                            scope.PurchaseOrderItem.CostCenters = scope.InventoryItem.CostCenters;
                                            scope.PurchaseOrderItem.ForDisplayBrands = scope.InventoryItem.Brands;

                                            if (scope.PurchaseOrderItem.ForDisplayBrands.length == 1) {
                                                scope.PurchaseOrderItem.BrandId = scope.PurchaseOrderItem.ForDisplayBrands[0].Id;
                                                scope.getDuplicateItem(scope.PurchaseOrderItem.InventoryItemId, scope.PurchaseOrderItem.BrandId, scope.PurchaseOrderItem.CostCenterId, scope.Model.PurchaseOrderItems.length);
                                            }

                                            scope.PurchaseOrderItem.ForDisplayCostCenters = scope.InventoryItem.ForDisplayCostCenters;
                                            if (scope.PurchaseOrderItem.ForDisplayCostCenters.length == 1) {
                                                scope.PurchaseOrderItem.CostCenterId = scope.PurchaseOrderItem.ForDisplayCostCenters[0].Id;
                                            }

                                            scope.PurchaseOrderItem.ForDisplayDiscountTypes = scope.InventoryItem.ForDisplayDiscountTypes;
                                            scope.PurchaseOrderItem.PropertyID = scope.PropertyID;
                                            scope.PurchaseOrderItem.ModifiedBy = scope.ModifiedBy;
                                            scope.PurchaseOrderItem.DateFormat = scope.DateFormat;

                                            scope.Model.PurchaseOrderItems.push(scope.PurchaseOrderItem);
                                        }
                                        scope.Search = "";
                                    }, function (error, status) {

                                        parent.failureMessage(error.Message);
                                    });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
        };
        function getSearchitemsDetails(itemId, propertyId, vendorId, date) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "Inventory/InventoryItem/GetItemById?propertyId=" + propertyId + "&id=" + itemId + "&vendorId=" + vendorId + "&date=" + date,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function getPODetails(itemId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: (apiPath + 'Inventory/PurchaseOrder/exist/' + itemId + "/" + propertyId),
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function getPOSearch(poStatusTypeId, searchTxt, propertyId) {

            $("#searchPO")
                .autocomplete({
                    source: function (request, response) {
                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: (apiPath + 'Inventory/PurchaseOrder/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {
                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.PONumber,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {
                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();
                                scope.isLoding = true;
                                scope.$apply(function () {
                                    var promiseGet = getPODetails(ui.item.value, propertyId);
                                    promiseGet.then(function (data, status) {

                                        angular.forEach(data.Data.PurchaseOrderItems, function (val) {

                                            val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);
                                            val.PODate = $filter('date')(val.PODate, val.DateFormat);
                                            val.DiscountInId = val.DiscountInId.toString();
                                        });

                                        scope.Model = data.Data;
                                        scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);
                                        scope.freightChargeService.setCharges(scope.Model.PurchaseOrderCharges);
                                        scope.paymentTermsService.set(scope.Model.PurchaseOrderTerms);

                                    }, function (error, status) {

                                        parent.failureMessage(error.Message);
                                    }).finally(function () {
                                        scope.isLoding = false;
                                    });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
        };

        //-----Tab-3-------
        function getItemSearch1(searchTxt, propertyId) {
            $("#search_item-mo")
                .autocomplete({
                    source: function (request, response) {
                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: apiPath + 'Inventory/InventoryItem/AllBySearchTxt?searchTxt=' + searchTxt + "&propertyId=" + propertyId,
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {
                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.Name,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {
                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();
                                scope.$apply(function () {
                                    var promiseGet = getSearchitemsDetails1(ui.item.val, propertyId);
                                    promiseGet.then(function (data, status) {

                                        scope.InventoryItem = data.Data;
                                        if ((scope.InventoryItem != null) && scope.InventoryItem != '') {

                                            scope.PurchaseOrderItem = {};
                                            scope.PurchaseOrderItem.Id = '';
                                            scope.PurchaseOrderItem.PurchaseOrderId = '';
                                            scope.PurchaseOrderItem.StoreId = scope.InventoryItem.StoreId;
                                            scope.PurchaseOrderItem.StoreName = scope.InventoryItem.StoreName;
                                            scope.PurchaseOrderItem.CostCenterId = '';
                                            scope.PurchaseOrderItem.CostCenterName = '';
                                            scope.PurchaseOrderItem.InventoryItemId = scope.InventoryItem.Id;
                                            scope.PurchaseOrderItem.InventoryItemName = scope.InventoryItem.Name;
                                            scope.PurchaseOrderItem.InventoryItemCode = scope.InventoryItem.Code;
                                            //$scope.PurchaseOrderItem.ItemType: '',
                                            scope.PurchaseOrderItem.ItemTypeId = scope.InventoryItem.ItemTypeId;
                                            scope.PurchaseOrderItem.ItemTypeName = scope.InventoryItem.ItemTypeName;
                                            scope.PurchaseOrderItem.BrandId = '';
                                            scope.PurchaseOrderItem.BrandName = '';
                                            scope.PurchaseOrderItem.UnitOfMeasurementId = scope.InventoryItem.UnitOfMeasurementId;
                                            scope.PurchaseOrderItem.UnitOfMeasurementName = scope.InventoryItem.UnitOfMeasurementName;
                                            scope.PurchaseOrderItem.Rate = 0;
                                            scope.PurchaseOrderItem.Quantity = 0;
                                            //$scope.PurchaseOrderItem.QuantityReceived: '',
                                            scope.PurchaseOrderItem.Amount = 0;
                                            scope.PurchaseOrderItem.Discount = 0;
                                            scope.PurchaseOrderItem.DiscountIn = '',
                                            scope.PurchaseOrderItem.DiscountInId = '';
                                            scope.PurchaseOrderItem.DiscountInName = '',
                                            scope.PurchaseOrderItem.TaxAmount = 0;
                                            scope.PurchaseOrderItem.TaxStructureId = '';
                                            scope.PurchaseOrderItem.DeliveryDate = '',
                                            //$scope.PurchaseOrderItem.PurchaseOrderItemTaxs: '',
                                            //scope.PurchaseOrderItem.Brands = scope.InventoryItem.Brands;
                                            scope.PurchaseOrderItem.CostCenters = scope.InventoryItem.CostCenters;
                                            scope.PurchaseOrderItem.ForDisplayBrands = scope.InventoryItem.Brands;
                                            scope.PurchaseOrderItem.ForDisplayCostCenters = scope.InventoryItem.ForDisplayCostCenters;
                                            scope.PurchaseOrderItem.ForDisplayDiscountTypes = scope.InventoryItem.ForDisplayDiscountTypes;
                                            scope.PurchaseOrderItem.PropertyID = scope.PropertyID;
                                            scope.PurchaseOrderItem.ModifiedBy = scope.ModifiedBy;
                                            scope.PurchaseOrderItem.DateFormat = scope.DateFormat;
                                            scope.Model.PurchaseOrderItems.push(scope.PurchaseOrderItem);

                                        }

                                        scope.Search1 = "";

                                    },
                                        function (error, status) {

                                            parent.failureMessage(error.Message);
                                        });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
            //});
        };
        function getSearchitemsDetails1(itemId, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "Inventory/InventoryItem/GetItemById?propertyId=" + propertyId + "&id=" + itemId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        function getPODetailsMO(itemId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: (apiPath + 'Inventory/PurchaseOrder/exist/' + itemId + "/" + propertyId),
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function getPOSearchMO(poStatusTypeId, searchTxt, propertyId, control) {

            $("#modifiedPODetails")
                .autocomplete({
                    source: function (request, response) {
                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: (apiPath + 'Inventory/PurchaseOrder/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {
                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.PONumber,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {
                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();
                                scope.$apply(function () {

                                    var promiseGet = getPODetailsMO(ui.item.value, propertyId);
                                    promiseGet.then(function (data, status) {

                                        angular.forEach(data.Data.PurchaseOrderItems, function (val) {

                                            val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);;
                                            val.DiscountInId = val.DiscountInId.toString();
                                        });

                                        scope.Model = data.Data;
                                        scope.Model.VendorId = scope.Model.VendorId.toString();
                                        scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                        scope.freightChargeService.setCharges(scope.Model.PurchaseOrderCharges);
                                        scope.paymentTermsService.set(scope.Model.PurchaseOrderTerms);
                                    }, function (error, status) {

                                        parent.failureMessage(error.Message);
                                    });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
        };

        //-----Tab-4------
        function getPODetailsCancel(itemId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: (apiPath + 'Inventory/PurchaseOrder/exist/' + itemId + "/" + propertyId),
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function getPOSearchCancel(poStatusTypeId, searchTxt, propertyId) {

            $("#cancelPODetails")
                .autocomplete({
                    source: function (request, response) {
                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: (apiPath + 'Inventory/PurchaseOrder/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {
                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.PONumber,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {

                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();
                                scope.$apply(function () {
                                    var promiseGet = getPODetailsCancel(ui.item.value, propertyId);
                                    promiseGet.then(function (data, status) {
                                        angular.forEach(data.Data.PurchaseOrderItems, function (val) {

                                            val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);;
                                            val.DiscountInId = val.DiscountInId.toString();
                                        });

                                        scope.Model = data.Data;
                                        scope.Model.VendorId = scope.Model.VendorId.toString();
                                        scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                        scope.freightChargeService.setCharges(scope.Model.PurchaseOrderCharges);
                                        scope.paymentTermsService.set(scope.Model.PurchaseOrderTerms);

                                    },
                                        function (error, status) {

                                            parent.failureMessage(error.Message);
                                        });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
        };
        var cancelPO = function (model) {

            var deferred = $q.defer();
            var url = apiPath + 'Inventory/PurchaseOrder/SaveCancelPO';
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };

        //---For Tab-5----
        function getPODetailsClose(poid, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: (apiPath + "Inventory/PurchaseOrder/GetPendingPoItems?poId=" + poid + "&propertyId=" + propertyId),
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function getPOSearchClose(poStatusTypeId, searchTxt, propertyId) {

            $("#closePODetails")
                .autocomplete({
                    source: function (request, response) {

                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: (apiPath + 'Inventory/PurchaseOrder/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {

                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.PONumber,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {

                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();
                                scope.$apply(function () {
                                    var promiseGet = getPODetailsClose(ui.item.value, propertyId);
                                    promiseGet.then(function (data, status) {

                                        var ReceiveItems = [];
                                        angular.forEach(data.Data.PurchaseOrderItems, function (item) {

                                            item.DeliveryDate = $filter('date')(item.DeliveryDate, item.DateFormat);;
                                            item.DiscountInId = item.DiscountInId.toString();

                                            if (item.QuantityToReceive != 0) {
                                                ReceiveItems.push(item);
                                            }
                                        });

                                        scope.Model = data.Data;
                                        scope.Model.PurchaseOrderItems = [];
                                        scope.Model.PurchaseOrderItems = ReceiveItems;
                                        scope.Model.VendorId = scope.Model.VendorId.toString();
                                        scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                        scope.freightChargeService.setCharges(scope.Model.PurchaseOrderCharges);
                                        scope.paymentTermsService.set(scope.Model.PurchaseOrderTerms);

                                    },
                                        function (error, status) {

                                            parent.failureMessage(error.Message);
                                        });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
        };
        var closePO = function (model) {

            var deferred = $q.defer();
            var url = apiPath + 'Inventory/PurchaseOrder/SaveClosePO';
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };

        //---For Tab-6-----
        function getPOSearchAuthorized(poStatusTypeId, searchTxt, propertyId) {

            $("#authorization_search_po")
                .autocomplete({
                    source: function (request, response) {
                        var deferred = $q.defer();
                        $http({
                            method: "GET",
                            url: (apiPath + 'Inventory/PurchaseOrder/GetAllByStatusMin?poStatusTypeId=' + poStatusTypeId + "&poNumber=" + searchTxt + "&propertyId=" + propertyId),
                            data: {},
                            headers: { 'duxtechApiKey': accessToken },
                            contentType: "application/json; charset=utf-8"
                        }).success(function (data, status, headers, cfg) {
                            deferred.resolve(data);
                            if (data.Collection.length > 0) {
                                response($.map(data.Collection,
                                    function (item) {
                                        return {
                                            label: item.PONumber,
                                            val: item.Id
                                        };
                                    }));
                            } else {
                                response([{ label: "No Records Found", val: -1 }]);
                            }
                        }).error(function (err, status) {

                            deferred.reject(err, status);
                        });
                        return deferred.promise;

                    },
                    select: function (e, ui) {
                        if (ui.item) {

                            if (ui.item.value !== "No Record Found!") {
                                var element = angular.element($("#divMain"));
                                var scope = element.scope();
                                scope.$apply(function () {

                                    scope.PurchaseOrders = [];

                                    var promiseGet = getPODetailsAuthorized(ui.item.value, propertyId);

                                    promiseGet.then(function (data, status) {

                                        angular.forEach(data.Data.PurchaseOrderItems, function (val) {
                                            val.DeliveryDate = $filter('date')(val.DeliveryDate, val.DateFormat);;
                                            val.DiscountInId = val.DiscountInId.toString();
                                        });

                                        scope.Model = data.Data;
                                        scope.Model.PODate = $filter('date')(scope.Model.PODate, scope.DateFormat);

                                        scope.PurchaseOrders.push(scope.Model);

                                    },
                                        function (error, status) {

                                            parent.failureMessage(error.Message);
                                        });
                                });
                            }
                        }
                    },
                    minLength: 1
                });
            //});
        };
        var getUnauthorizedList = function (propertyId) {
            var url = apiPath + "Inventory/PurchaseOrder/GetAllNotApproved/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var saveAuthorization = function (purchaseOrders) {

            var deferred = $q.defer();
            var url = apiPath + 'Inventory/PurchaseOrder/SaveAuthorization';
            $http({
                dataType: 'json',
                method: 'POST',
                url: url,
                data: JSON.stringify(purchaseOrders),
                headers: {
                    //"Content-Type": "application/json"
                    "duxtechApiKey": accessToken,
                    "Content-Type": "application/json"
                }
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        };
        var send = function (propertyId, id, sms) {
            return httpCaller(apiPath + "Inventory/PurchaseOrder/Send", $http, $q, { propertyId: propertyId, id: id, sms: sms });
        };

        return {
            send: send,
            getItemRate: getItemRate,
            getAllPOVendor: getAllPOVendor,
            save: save,
            getAllVendor: getAllVendor,
            getAllTaxStructure: getAllTaxStructure,
            getReason: getReason,
            getItemSearch: getItemSearch,
            getPODetails: getPODetails,
            getPOSearch: getPOSearch,
            getItemSearch1: getItemSearch1,
            getPOSearchMO: getPOSearchMO,
            getPOSearchCancel: getPOSearchCancel,
            cancelPO: cancelPO,
            getPOSearchClose: getPOSearchClose,
            closePO: closePO,
            getUnauthorizedList: getUnauthorizedList,
            saveAuthorization: saveAuthorization,
            getPOSearchAuthorized: getPOSearchAuthorized,
            getAllPR: getAllPR,
            MapReport: MapReport,

        };

    }

    app.factory('service', ['$http', '$q', '$filter', service]);
})();
