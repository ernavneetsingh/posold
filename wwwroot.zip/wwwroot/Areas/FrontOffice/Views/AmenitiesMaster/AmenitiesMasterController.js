﻿app.controller("AmenitiesController",
    function ($scope, $http, $filter, service, $window, $cookies, localStorageService) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";

        //model
        $scope.AmenitiesData = {
            Id: "",
            Code: "",
            Name: "",
            Description: "",
            AmenityTypeId: 1,
            AmenityTypeName: 'Room',
            IsActive: true,
            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName
        };

        //------------------------------------------------
        //page configuration start
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        var searchMatch = function (haystack, needle) {

            if (!needle) {

                return true;

            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {

            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {

                    if (attr === "Id" || attr === "Code" || attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;

            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {
            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;
            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            // var sss = $scope.pagedItems.length;
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;

        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        $scope.items = [];
        getData();

        function getData() {
            debugger;
            $scope.ActionMode = "";
            var getData = service.getData($scope.PropertyID);
            getData.then(function (amenities) {
                $scope.items = amenities.Collection;
                $scope.search();

                //$scope.$apply(function () {
                    
                //});
            }
            )
        };

        $scope.RevenueHeads = [];
        $scope.getRevenueHeadList = function () {
            $scope.RevenueHeads = [];

            service.GetRevenueHead($scope.PropertyID)
                .then(function (result) {

                    $scope.RevenueHeads = result.Collection;
                    angular.forEach($scope.RevenueHeads, function (item) {
                        item.RevenueForId = item.RevenueForId.toString();
                        item.RevenueTypeId = item.RevenueTypeId.toString();
                        item.RevenueClassificationTypeId = item.RevenueClassificationTypeId.toString();

                    })

                }, function (err) {
                    msg(err.Message);
                });

        };
        $scope.getRevenueHeadList();

        $scope.Save = function (amenitiesData, form) {

            if ($scope[form].$valid) {

                amenitiesData.PropertyID = $scope.PropertyID;
                amenitiesData.ModifiedBy = $scope.UserName;

                var saveData = service.save(amenitiesData);
                saveData.then(function (data) {
                    $scope.AmenitiesData.Code = "";
                    $scope.AmenitiesData.Name = "";
                    $scope.AmenitiesData.Description = "";
                    $scope.AmenitiesData.AmenityTypeId = 1;
                    $scope.AmenitiesData.IsActive = true;
                    $scope.AmenitiesData.Rate = 0;
                    $scope.AmenitiesData.RevenueHeadId = "";
                    $scope.AmenitiesData.IsInclusive = false;

                    $scope.IsReadonly = false;
                    parent.successMessage(data.Message);
                    getData();
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        //Reset All Feild
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.AmenitiesData.AmenityTypeId = 1;
            $scope.AmenitiesData.Code = "";
            $scope.AmenitiesData.Name = "";
            $scope.AmenitiesData.Description = "";
            $scope.AmenitiesData.IsActive = true;
            $scope.IsReadonly = false;
            $scope.AmenitiesData.Id = "";
            $scope.query = "";
            $scope.search();
        };
        //Change Amenities Status
        $scope.activeRow = function (amenities) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var statusData = service.status(amenities, $scope.UserName);
            statusData.then(function (data) {
                getData();
                parent.successMessage(data.Message);
                scrollPageOnTop();
            });
        };
        //Delete Record
        $scope.removeRow = function (amenities) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (amenities) {

                                var removeData = service.remove(amenities);
                                removeData.then(function (data) {

                                    parent.successMessage(data.Message);
                                    $("html, body").animate({ scrollTop: 0 }, "slow");
                                    getData();
                                },
                                    function (error) {

                                        parent.failureMessage(error.Message);
                                        $("html, body").animate({ scrollTop: 0 }, "slow");
                                    });
                            }
                            $.fancybox.close();
                        });
                }
            });
        };
        //Check existing Amenities Code
        $scope.txtAmenitiesCodes = function () {
            var amenitiesCode = service.codeExists($scope.AmenitiesData.Code, $scope.PropertyID);
            amenitiesCode.then(function (data) {

            }, function (error) {
                //error handler function
                $scope.$apply(function () {
                    $scope.AmenitiesData.Code = "";
                });
            });
        };
        //Fill Amenities Data
        $scope.fillAmenitiesData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.AmenitiesData = record;

            $scope.AmenitiesData.Code = record.Code;
            $scope.AmenitiesData.Name = record.Name;
            $scope.AmenitiesData.Description = record.Description;
            $scope.AmenitiesData.IsActive = record.IsActive;
            $scope.AmenitiesData.Id = record.Id;
            $scope.AmenitiesData.AmenityTypeId = record.AmenityTypeId;

            $scope.IsReadonly = true;
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);

        };

        $scope.AmenitieTypes = [];
        $scope.getAmenitieType = function () {
            var promise = service.getAmenitieType();
            promise.then(function (data) {

                $scope.AmenitieTypes = data.Collection;
            }, function (error) {
                msg(error.Message);
            });
        }
        $scope.getAmenitieType();
    });