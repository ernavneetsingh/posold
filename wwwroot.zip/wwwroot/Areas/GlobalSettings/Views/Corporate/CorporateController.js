﻿
app.controller("CorporateController",
[
    "$scope", "CorporateService", "$cookies", "localStorageService", "$filter",
    function ($scope, corporateService, $cookies, localStorageService,$filter) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.UserName = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        var businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = businessDate.getFullYear() + '/' + ('0' + (businessDate.getMonth() + 1)).slice(-2) + '/' + ('0' + businessDate.getDate()).slice(-2);
        $scope.keys=localStorageService.get('ActionKeys');
        $scope.AmenitiesSettings = {
            scrollableHeight: '300px',
            scrollable: true,
            enableSearch: true,
            displayProp: 'Name'
        };

        $scope.IsReadonly = false;
        $scope.bsId = "";
        $scope.Name = "";
        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;
        $scope.IsBlackList = false;
        $scope.Save = "Save";
        $scope.corporateData = [];
        $scope.corporateDetails = [];

        $scope.sortType = "";
        $scope.sortReverse = true;
        $scope.searchText = "";
        var sortKeyOrder = {
            key: "",
            order: ""
        };
        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }
        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        $scope.getCorporateTypes = function () {
            var promise = corporateService.getCorporateTypes($scope.PropertyID);
            promise.then(function (data) {
                $scope.CompanyTypeList = data.Collection;
            });
        };
        $scope.getCorporateTypes();
        $scope.getCountryList = function () {
            var promise = corporateService.getCountryList();
            promise.then(function (data) {
                $scope.CountryList = data.Collection;
            });
        };
        $scope.getCountryList();
        $scope.getStateDetails = function (countryId, stateId) {
            var promiseGet = corporateService.getStateData(countryId);
            promiseGet.then(function (data, status) {
                $scope.StateList = data.Collection;
                if (stateId) $scope.model.StateId = stateId;
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.getStateBillingDetails = function (countryId, stateId) {
            if(countryId)
            {
                var promiseGet = corporateService.getStateData(countryId);
                promiseGet.then(function (data, status) {
                    $scope.StateBillingList = data.Collection;
                    if (stateId) $scope.model.BillingStateId = stateId;
                },
                function (error, status) {
                    msg(error.Message);
                });
            }
        };

        $scope.getBookerTypes = function () {

            var promise = corporateService.getBookerTypes($scope.PropertyID);
            promise.then(function (data) {

                $scope.BookerTypeList = data.Collection.filter(x=>x.IsActive);
            });
        };
        $scope.getBookerTypes();
        $scope.getAmenitiesList = function () {

            var promise = corporateService.getAmenitiesList($scope.PropertyID);
            promise.then(function (data) {
                $scope.AmenitiesList = data.Collection;
            });
        };
        $scope.getAmenitiesList();
        $scope.getDesignationList = function () {

            var promise = corporateService.getDesignationList($scope.PropertyID);
            promise.then(function (data) {
                $scope.DesignationList = data.Collection;
            });
        };
        $scope.getDesignationList();
        $scope.getPercentageTypeList = function () {

            var promise = corporateService.getPercentageTypeList();
            promise.then(function (data) {
                $scope.PercentageTypeList = data.Collection;
            });
        };
        $scope.getPercentageTypeList();
        $scope.getSalesOfficeList = function () {

            var promise = corporateService.getSalesOfficeList($scope.PropertyID);
            promise.then(function (data) {
                $scope.SalesOfficeList = data.Collection;
            });
        };
        $scope.getSalesOfficeList();
        $scope.getSalesExecutiveList = function () {

            var promise = corporateService.getSalesExecutiveList($scope.PropertyID);
            promise.then(function (data) {
                $scope.SalesExecutiveList = data.Collection;
            });
        };
        $scope.getSalesExecutiveList();
        $scope.getMarketSegmentList = function () {

            var promise = corporateService.getMarketSegmentList($scope.PropertyID);
            promise.then(function (data) {
                $scope.MarketSegmentList = data.Collection;
            });
        };
        $scope.getMarketSegmentList();
        $scope.getBusinessSourceList = function () {

            var promise = corporateService.getBusinessSourceList($scope.PropertyID);
            promise.then(function (data) {
                $scope.BusinessSourceList = data.Collection;
            });
        };
        $scope.getBusinessSourceList();
        $scope.getRateList = function () {

            var rateTypeId = 2;//
            var promise = corporateService.getRateList(rateTypeId, $scope.PropertyID);
            promise.then(function (data) {
                $scope.RateList = data.Collection;
            });
        };
        $scope.getRateList();
        $scope.getRevenueHeadList = function () {

            var promise = corporateService.getRevenueHeadList($scope.PropertyID);
            promise.then(function (data) {
                $scope.RevenueHeadList = data.Collection;
            });
        };
        $scope.getRevenueHeadList();

        $scope.saveCorporateData = function (form, f2) {
            
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                scrollPageOnTop();
                if (f2 && !$scope[f2].$valid) $scope.ShowErrorMessageI = true;
                return;
            }

            if ($scope.model.CorporateCategoryId) {
                if (parseFloat($scope.model.CorporateCategoryId) < 1) {
                    msg("Please Select Corporate Category.");
                    scrollPageOnTop();
                    return;
                }
            }
            else {
                msg("Please Select Corporate Category.");
                scrollPageOnTop();
                return;
            }

            $scope.model.RateMasters = [];
            $scope.model.RateMasters = $scope.RateMasters;
            
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.UserName;
            $scope.model.ModifiedDate = $scope.ModifiedDate;
            //if($scope.model.CorporateOutstanding.IsCreditAllowed)
            //{
            //    if (parseFloat($scope.model.CorporateOutstanding.CreditDays) < 1) {
            //        msg("Please Select Corporate Credit Days.");
            //        scrollPageOnTop();
            //        return;
            //    }
            //    if (parseFloat($scope.model.CorporateOutstanding.CreditLimit) < 1) {
            //        msg("Please Select Corporate Credit Limit.");
            //        scrollPageOnTop();
            //        return;
            //    } }
     
            var saveModel = angular.copy($scope.model);

            if(saveModel.ContractValidityDate)
            {
                saveModel.ContractValidityDate = GetServerDate(saveModel.ContractValidityDate,$scope.DateFormat);
            }
            //CorporateDocuments
            if(saveModel.CorporateContacts)
            {
                angular.forEach(saveModel.CorporateContacts,function(item){
                    item.DOB = GetServerDate(item.DOB,$scope.DateFormat);
                });
            }
            if(saveModel.RateMasters)
            {
                angular.forEach(saveModel.RateMasters,function(item){
                    item.ApplicableFrom = GetServerDate(item.ApplicableFrom,$scope.DateFormat);
                    item.ApplicableTo = GetServerDate(item.ApplicableTo,$scope.DateFormat);
                });
            }
           
            var promiseGet = corporateService.saveCorporate(saveModel);
            promiseGet.then(function (data, status) {
                getData($scope, corporateService, localStorageService);
                $scope.reset();
                if (data.Status) { msg(data.Message, true); }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.ActionMode=""; 
        $scope.fillData = function (record) {
            $scope.ActionMode="Edit"; 
            scrollPageOnTop();
            var promise = corporateService.getById(record.Id);
            promise.then(function (data) {

                $scope.model = data.Data;
                $scope.model.CountryId = $scope.model.CountryId.toString();
                $scope.getStateDetails($scope.model.CountryId, $scope.model.StateId.toString());
                $scope.model.BillingCountryId = $scope.model.BillingCountryId.toString();
                $scope.getStateBillingDetails($scope.model.BillingCountryId, $scope.model.BillingStateId.toString());

                $scope.RateMasters = $scope.model.RateMasters;
                angular.forEach($scope.model.Bookers, function (key) {
                    $scope.changeBookerType(key.BookerTypeId, key);
                });
                
                if($scope.model.CorporateOutstanding)
                {
                    $scope.model.CorporateOutstanding.CommissionTypeId = $scope.model.CorporateOutstanding.CommissionTypeId.toString();
                    //if ($scope.model.CorporateDiscount.CorporateDiscountRevenueHeads.length === 0 || $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads == undefined) {
                    //    $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads.push({
                    //        RevenueHeadId: "",
                    //        DiscountTypeId: "",
                    //        DiscountValue: ""
                    //    });
                    //};
                }
                
                if($scope.model.ContractValidityDate)
                {
                    $scope.model.ContractValidityDate = $filter('date')($scope.model.ContractValidityDate,$scope.DateFormat);
                }
                //CorporateDocuments
                if($scope.model.CorporateContacts)
                {
                    angular.forEach($scope.model.CorporateContacts,function(item){
                        item.DOB = $filter('date')(item.DOB,$scope.DateFormat);
                    });
                }
                if($scope.model.RateMasters)
                {
                    angular.forEach($scope.model.RateMasters,function(item){
                        item.ApplicableFrom = $filter('date')(item.ApplicableFrom,$scope.DateFormat);
                        item.ApplicableTo = $filter('date')(item.ApplicableTo,$scope.DateFormat);
                    });
                }
                if($scope.model.CorporateDiscounts)
                {
                    $scope.model.CorporateDiscounts.forEach(function(d){
                        d.CorporateDiscountRevenueHeads.forEach(function(r){
                            r.DiscountTypeId =!r.DiscountTypeId?'':r.DiscountTypeId.toString() ;
                        });
                    });
                }

                $scope.IsReadonly = true;
                $scope.Save = "Update";
                msg('');

            });

        };
        $scope.reset = function () {
            $scope.ActionMode=""; 
            $scope.model = { "CorporateCategoryId": 1, };
            $scope.query = "";
            msg('');
            $scope.IsReadonly = false;
            if ($scope.Save !== "Save") { $scope.Save = "Save"; }
            $scope.model.Bookers = [];

            $scope.model.CorporateContacts = [];
            $scope.model.RateMasters = [];

            $scope.model.Amenities = [];
            $scope.model.CorporateDiscount = {};
            $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads = [];
            $scope.model.CorporateOutstanding ={
                CommissionTypeId:'',
                IsCreditAllowed: false,
                CreditDays: 0,
                CreditLimit: 0,
                Outstanding: 0,
            };

            $scope.RateMasters = [];
            $scope.SelectedRateMaster="";
            $scope.search();
        };
        $scope.changeCommission = function () {

            if ($scope.model.CorporateOutstanding.CommissionTypeId == 1 && $scope.model.CorporateOutstanding.CommissionAmount > 100)
                $scope.model.CorporateOutstanding.CommissionAmount = 100;
        };

        $scope.AddMultipleBooker = function () {

            var rows = $scope.model.Bookers.length;
            if (rows > 0)
            {
                if($scope.model.Bookers[rows - 1].BookerTypeId && $scope.model.Bookers[rows - 1].Id)
                {
                    $scope.model.Bookers.push({
                        BookerTypeId:"",
                        Id: "",
                        Code: "",
                        Name: "",
                        BookerList: $scope.BookerList
                    });
                }
            }
            else
            {

                $scope.model.Bookers.push({
                    BookerTypeId: "",
                    Id: "",
                    Code: "",
                    Name: "",
                    BookerList: $scope.BookerList

                });
            }

        };
        $scope.removeBooker = function (index) {

            $scope.model.Bookers.splice(index, 1);
        };
        $scope.changeBookerType = function (bookerTypeId, d) {

            var promise = corporateService.getBookers($scope.PropertyID, bookerTypeId);
            promise.then(function (data) {
                
                d.BookerList = data.Collection.filter(x=>x.IsActive) ;
            });

        };

        $scope.AddCorporateContact = function () {

            var rows = $scope.model.CorporateContacts.length;
            if (rows > 0)
            {
                if($scope.model.CorporateContacts[rows - 1].Name)
                {
                    $scope.model.CorporateContacts.push({
                        Name: "",
                        Designation: "",
                        DOB: "",
                        Email: "",
                        PhoneNo: "",
                        Ext: "",
                        Mobile1: ""
                    });
                }
            }
            else
            {

                $scope.model.CorporateContacts.push({
                    Name: "",
                    Designation: "",
                    DOB: "",
                    Email: "",
                    PhoneNo: "",
                    Ext: "",
                    Mobile1: ""

                });
            }



        };
        $scope.removeContact = function (index) {
            $scope.model.CorporateContacts.splice(index, 1);
        };

        $scope.AddMultipleDiscount = function () {

            
            
            var index = $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads ? $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads.length : 0;
            if (index < 1) 
            {
                $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads=[];
            };

            if(index>0)
            {
                if ($scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[index - 1].RevenueHeadId == "") {
                    $scope.showDiscountMsgs = true; return;
                }
                if ($scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[index - 1].DiscountTypeId == "") { $scope.showDiscountMsgs = true; return; }
                if ($scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[index - 1].DiscountValue == "") { $scope.showDiscountMsgs = true; return; }
            }
            
            $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads.push({
                RevenueHeadId: "",
                DiscountTypeId: "",
                DiscountValue: ""
            });
        };
        $scope.removeDiscount = function (index) {
            $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads.splice(index, 1);
        };

        $scope.removeRate = function (index) {
            $scope.RateMasters.splice(index, 1);
        };

        $scope.CorporateDiscountDetailsView = [];
        $scope.CorporateDiscountDetailsView.CorporateDiscountDetailsChild = [];
        $scope.AddFinalDiscount = function (d) {
            
            if(!$scope.model.CorporateDiscounts)$scope.model.CorporateDiscounts=[];
            $scope.model.CorporateDiscounts.push(d);
            //if (!d.Code ) { $scope.showDiscountMsgs = true; return; }
            //if (d.ValidFrom == "") { $scope.showDiscountMsgs = true; return; }
            //if (d.ValidTill == "") { $scope.showDiscountMsgs = true; return; }

            //for (var i = 0; i < $scope.CorporateDiscountDetailsView.length; i++) {
            //    if ($scope.CorporateDiscountDetailsView[i].DiscountCode == d.DiscountCode) {
            //        $scope.CorporateDiscountDetailsView[i].CorporateDiscountDetailsId = d.CorporateDiscountDetailsId;
            //        $scope.CorporateDiscountDetailsView[i].DiscountCode = d.DiscountCode;
            //        $scope.CorporateDiscountDetailsView[i].Description = d.Description;
            //        $scope.CorporateDiscountDetailsView[i].ValidFrom = d.ValidFrom;
            //        $scope.CorporateDiscountDetailsView[i].ValidTill = d.ValidTill;
            //        $scope.CorporateDiscountDetailsView[i].CorporateDiscountDetailsChild = d.CorporateDiscountDetailsChild;
            //        break;
            //    } else {
            //        $scope.CorporateDiscountDetailsView.push({
            //            Code: d.Code,
            //            Description: d.Description,
            //            ValidFrom: d.ValidFrom,
            //            ValidTill: d.ValidTill,
            //            CorporateDiscountDetailsChild: d.CorporateDiscountDetailsChild
            //        });
            //    }
            //}

            //if ($scope.CorporateDiscountDetailsView.length == 0) {
            //    $scope.CorporateDiscountDetailsView.push({
            //        Code: d.Code,
            //        Description: d.Description,
            //        ValidFrom: d.ValidFrom,
            //        ValidTill: d.ValidTill,
            //        CorporateDiscountDetailsChild: d.CorporateDiscountDetailsChild
            //    });
            //};

            //$scope.CorporateDiscountDetails = [];
        };
        $scope.IsDiscountReadOnly = false;
        $scope.EditFinalDiscount = function (d) {
            $scope.model.CorporateDiscount=d;
            //$scope.IsDiscountReadOnly = true;
            //$scope.CorporateDiscountDetailsId = d.CorporateDiscountDetailsId;
            //$scope.CorporateDiscountDetails.DiscountCode = d.DiscountCode;
            //$scope.CorporateDiscountDetails.Description = d.Description;
            //$scope.CorporateDiscountDetails.ValidFrom = d.ValidFrom;
            //$scope.CorporateDiscountDetails.ValidTill = d.ValidTill;
            //$scope.model.CorporateDiscount.CorporateDiscountRevenueHeads = d.CorporateDiscountDetailsChild;

            //for (var i = 0; i < $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads.length; i++) {

            //    $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[i].RevenueHeadId = $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[i].RevenueId;
            //    $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[i].DiscountType = $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[i].DiscountType.toString();
            //    $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[i].DiscountValue = $scope.model.CorporateDiscount.CorporateDiscountRevenueHeads[i].DiscountValue;


            //}
        };

        $scope.reset();
        getData($scope, corporateService, localStorageService);

        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, corporateService, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, corporateService, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, corporateService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, corporateService, localStorageService);
        }

        $scope.CorporateBillingDetails = [];
        $scope.IsSameBillingDetails = function () {

            
            if (!$scope.model.IsBillingAddress) return;

            $scope.model.BillingAddress1 = $scope.model.Address1;
            $scope.model.BillingCity = $scope.model.City;
            $scope.model.BillingCountryId = $scope.model.CountryId;
            $scope.model.BillingStateId = $scope.model.StateId;
            $scope.getStateBillingDetails($scope.model.BillingCountryId, $scope.model.BillingStateId.toString());
            $scope.model.BillingPIN = $scope.model.PIN;
            $scope.model.BillingPhoneNo = $scope.model.PhoneNo;
            $scope.model.BillingMobile1 = $scope.model.Mobile1;
            $scope.model.BillingFaxNo = $scope.model.FaxNo;
            $scope.model.BillingEmail= $scope.model.Email;
            
        };

        $scope.CorporateModel = {};
        $scope.CorporateDetails = [];
        $scope.CorporateBusinessDetails = [];
        $scope.RateMasters = [];

        $scope.AddRateMasters = function () {


            if ($scope.SelectedRateMaster) {
                $scope.RateMasters.push({

                    Id: $scope.SelectedRateMaster.Id,
                    Code: $scope.SelectedRateMaster.Code,
                    Description: $scope.SelectedRateMaster.Description,

                    ApplicableFrom: $scope.SelectedRateMaster.ApplicableFrom,
                    ApplicableTo: $scope.SelectedRateMaster.ApplicableTo

                });
            }
            $scope.SelectedRateMaster = {};
        };

        function getCorporateDetailsData() {

            var promiseGet = corporateService.getCorporateDetailsData($scope.PropertyID);
            promiseGet.then(function (data, status) {

                $scope.CorporateDetails = data;
                $scope.CorporateModel.CompanyTypeData = data.Data.CompanyTypeData;
                $scope.CorporateModel.CountryData = data.Data.CountryData;
                $scope.CorporateModel.DesignationData = data.Data.DesignationData;
                $scope.CorporateModel.AminitiesData = data.Data.AminitiesData;
                $scope.CorporateModel.BookerTypeData = data.Data.BookerTypeData;
                $scope.CorporateModel.BusinessSourceData = data.Data.BusinessSourceData;
                $scope.CorporateModel.MarketSegmentData = data.Data.MarketSegmentData;
                $scope.CorporateModel.RatedefinitionData = data.Data.RatedefinitionData;
                $scope.CorporateModel.RevenueHeadData = data.Data.RevenueHeadData;
                $scope.CorporateModel.SalesOfficeData = data.Data.SalesOfficeData;
                $scope.CorporateModel.UserMasterData = data.Data.UserMasterData;
                $scope.CategoryType = data.Data.CategoryType;
                $scope.CorporateCountry = data.Data.CorporateCountry.toString();
                $scope.CorporateBusinessDetails.BusinessSourceid = data.Data.DefaultBusinessSource.toString();
                $scope.CorporateBusinessDetails.MarketSegmentId = data.Data.DefaultMarketSegment.toString();
                $scope.getStateDetails(data.Data.CorporateCountry);
                $scope.CorporateState = data.Data.CorporateState.toString();

                $scope.RateMasterId = data.Data.DefaultRateMaster.trim().toString();
                $scope.getRateCodeDetails($scope.RateMasterId, $scope.PropertyID);
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        //getCorporateDetailsData();

        $scope.getRateCodeDetails = function (rateMasterId, propertyId) {

            var promiseGet = corporateService.getRateCodeData(rateMasterId, propertyId);
            promiseGet.then(function (data, status) {

                $scope.ApplicableTo = data.Data.RateValidFrom;
                $scope.ApplicableFrom = data.Data.RateValidTo;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.isExist = function () {

            var promiseGet = corporateService.getCodeExistCorporate($scope.CorporateCode, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        msg(data.Message);
                        $scope.CorporateCode = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.updateCorporateData = function (corporateModel) {
            if (!$scope.keys.IsEdit)
            {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            $scope.model.Id = corporateModel.Id;
            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.UserName;

            var promiseGet = corporateService.updateIsActiveCorporate($scope.model);
            promiseGet.then(function (data, status) {
                getData($scope, corporateService, localStorageService);
                msg(data.Message, data.Status);
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.removeRow = function (corporateModel) {
            if (!$scope.keys.IsDelete)
            {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Corporate?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = corporateService.deleteCorporate(corporateModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {
                                msg(d.Message,true);
                                getData($scope, corporateService, localStorageService);
                                if (data.Status) { alert(data.Message); }
                            }, function (e) {
                                msg(e.Message);
                                alert($.parseJSON(err.responseText).Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };

        $scope.model = {
            "Id": "",
            "PropertyCorporateTypeId": "",
            "PropertyCorporateTypeCode": "",
            "PropertyCorporateTypeName": "",
            "PropertyCorporateTypeDescription": "",
            "CorporateCategory": 1,
            "CorporateCategoryId": 1,
            "CorporateCategoryName": "",
            "CorporateCategoryDescription": "",
            "Code": "",
            "Name": "",
            "ContractPerson": "",
            "Address1": "",
            "Address2": "",
            "City": "",
            "StateId": "",
            "StateName": "",
            "CountryId": "",
            "CountryName": "",
            "PIN": "",
            "Mobile1": "",
            "Mobile2": "",
            "Email": "",
            "PhoneNo": "",
            "FaxNo": "",
            "IsBillingAddress": false,
            "BillingAddress1": "",
            "BillingAddress2": "",
            "BillingCity": "",
            "BillingStateId": 0,
            "BillingStateName": "",
            "BillingCountryId": 0,
            "BillingCountryName": "",
            "BillingPIN": "",
            "BillingMobile1": "",
            "BillingMobile2": "",
            "BillingEmail": "",
            "BillingPhoneNo": "",
            "BillingFaxNo": "",
            "WebSite": "",
            "IsActive": true,
            "CreditLimit": 0,
            "Outstanding": 0,
            "LastPaymentAmount": 0,
            "LastBillAmount": 0,
            "LastInvoiceAmount": 0,
            "Invoices": [
              {
                  //"$id": "2",
                  //"Id": "",
                  "PropertyID": "",
                  "ModifiedBy": "",
                  "InvoiceNo": "",
                  "InvoiceDate": "",
                  "InvoiceDateString": "",
                  "CorporateId": "",
                  "CorporateName": "",
                  "TotalAmount": 0
                  //},
                  //{
                  //    "$ref": "2"
              }
            ],
            "Bookers": [
              //{
              //    //"$id": "3",
              //    //"Id": "",
              //    "BookerTypeId": "",
              //    "BookerTypeCode": "",
              //    "BookerTypeName": "",
              //    "Code": "",
              //    "Name": "",
              //    "Address1": "",
              //    "Address2": "",
              //    "City": "",
              //    "StateMaster": {
              //        //"$id": "4",
              //        "StateName": "",
              //        "CountryMaster": {
              //            //"$id": "5",
              //            "ISOCode2": "",
              //            "ISOCode3": "",
              //            "CountryName": "",
              //            "CountryISD": "",
              //            "Nationality": "",
              //            "States": [
              //              {
              //                  //    "$ref": "4"
              //                  //},
              //                  //{
              //                  //    "$ref": "4"
              //              }
              //            ],
              //            //"Id": 6
              //        },
              //        //"Id": 2
              //    },
              //    "StateId": 0,
              //    "PIN": "",
              //    "Mobile1": "",
              //    "Mobile2": "",
              //    "Email": "",
              //    "IsActive": true,
              //    "Corporates": [
              //      {
              //          //    "$ref": "1"
              //          //},
              //          //{
              //          //    "$ref": "1"
              //      }
              //    ],
              //    "PropertyID": "",
              //    "ModifiedBy": ""
              //    //},
              //    //{
              //    //    "$ref": "3"
              //}
            ],
            "Amenities": [
              {
                  //"$id": "6",
                  //"Id": "",
                  "Code": "",
                  "Name": "",
                  "Description": "",
                  "IsActive": true,
                  "Corporates": [
                    {
                        //    "$ref": "1"
                        //},
                        //{
                        //    "$ref": "1"
                    }
                  ],
                  "PropertyID": "",
                  "ModifiedBy": ""
                  //},
                  //{
                  //    "$ref": "6"
              }
            ],
            "CorporateDocuments": [
              {
                  //"$id": "7",
                  "CorporateId": "",
                  "CorporateCode": "",
                  "CorporateName": "",
                  "DocumentTypeId": 0,
                  "DocumentTypeName": 0,
                  "ValidUpto": "",
                  "Number": "",
                  "ParentCompany": "",
                  "PropertyID": "",
                  "ModifiedBy": "",
                  "DateFormat": ""
                  //},
                  //{
                  //    "$ref": "7"
              }
            ],
            "CorporateContacts": [
              //{
              //    //"$id": "8",
              //    //"Id": "",
              //    "CorporateId": "",
              //    "Name": "",
              //    "Designation": "",
              //    "DOB": "",
              //    "Mobile1": "",
              //    "Mobile2": "",
              //    "Email": "",
              //    "PhoneNo": "",
              //    "Ext": "0",
              //    "PropertyID": "",
              //    "ModifiedBy": "",
              //    "DateFormat": ""
              //    //},
              //    //{
              //    //    "$ref": "8"
              //}
            ],
            "CorporateOutstanding": {
                //"$id": "9",
                //"Id": "",
                "CorporateId": "",
                "CorporateCode": "",
                "CorporateName": "",
                "IsCreditAllowed": false,
                "CreditDays": 0,
                "CreditLimit": 0,
                "Outstanding": 0,
                "OpeningDate": "",
                "OpeningDateString": "",
                "OpeningAmount": 0,
                "TransactionType": 0,
                "TransactionTypeId": 0,
                "TransactionTypeName": "",
                "ReferenceNo": "",
                "CommissionType": 0,
                "CommissionTypeId": "",
                "CommissionTypeName": "",
                "CommissionAmount": 0,
                "PropertyID": "",
                "ModifiedBy": "",
                "DateFormat": ""
            },
            "CorporateDiscount": {
                //"$id": "10",
                //"Id": "",
                "CorporateId": "",
                "CorporateCode": "",
                "CorporateName": "",
                "Code": "",
                "Description": "",
                "ValidFrom": "",
                "ValidTill": "",
                "CorporateDiscountRevenueHeads": [
                  //{
                  //    //"$id": "11",
                  //    "CorporateDiscountId": "",
                  //    "CorporateDiscountCode": "",
                  //    "RevenueHeadId": "",
                  //    "RevenueHeadCode": "",
                  //    "RevenueHeadName": "",
                  //    "DiscountType": 0,
                  //    "DiscountTypeId": 0,
                  //    "DiscountTypeName": "",
                  //    "DiscountValue": 0
                  //    //},
                  //    //{
                  //    //    "$ref": "11"
                  //}
                ],
                "PropertyID": "",
                "ModifiedBy": "",
                "DateFormat": ""
            },
            "RateMasters": [{
                //"$id": "12",
                //"Id": "",
                "CorporateId": "",
                "CorporateCode": "",
                "CorporateName": "",
                "RateMasterId": "",
                "RateMasterCode": "",
                "RateMasterDescription": "",
                "RateType": 0,
                "RateTypeId": 0,
                "RateTypeName": "",
                "RateTypeDescription": "",
                "ApplicableFrom": "",
                "ApplicableTo": "",
                "PropertyID": "",
                "ModifiedBy": ""
            }],
            "CorporateBusinessDetail": {
                //"$id": "13",
                //"Id": "",
                "CorporateId": "",
                "SalesOfficeId": "",
                "SalesOfficeCode": "",
                "SalesOfficeName": "",
                "SalesExecutiveId": "",
                "SalesExecutiveCode": "",
                "SalesExecutiveName": "",
                "MarketSegmentId": "",
                "MarketSegmentCode": "",
                "MarketSegmentName": "",
                "BusinessSourceId": "",
                "BusinessSourceCode": "",
                "BusinessSourceName": "",
                "IsBlackList": false,
                "PropertyID": "",
                "ModifiedBy": "",
                "DateFormat": ""
            },
            "Transactions": [
              {
                  //"$id": "14",
                  //"Id": "",
                  "PropertyID": "",
                  "ModifiedBy": "",
                  "TransactionNo": "",
                  "TransactionDate": "",
                  "TransactionDateString": "",
                  "InvoiceNo": "",
                  "Amount": 0,
                  "UnmatchedAmount": 0,
                  "CorporateId": "",
                  "CorporateName": "",
                  "BillFrom": 0,
                  "BillFromId": "",
                  "BillFromName": "",
                  "TransactionType": 0,
                  "TransactionTypeId": "",
                  "TransactionTypeName": "",
                  "PaymentModeId": "",
                  "PaymentModeName": "",
                  "Description": "",
                  "ChequeNo": "",
                  "ChequeDate": "",
                  "BankBranchId": 0,
                  "BankBranchName": "",
                  "CommissionType": 0,
                  "CommissionTypeName": "",
                  "CommissionApplied": 0,
                  "CommissionAmount": 0,
                  "BillId": "",
                  "BillNo": "",
                  "InvoiceDate": "",
                  "InvoiceDateString": "",
                  "TransactionTypes": [
                    {
                        //"$id": "15",
                        //"Id": "",
                        "Name": "",
                        "Description": ""
                        //},
                        //{
                        //    "$ref": "15"
                    }
                  ],
                  "BillFroms": [
                    {
                        //    "$ref": "15"
                        //},
                        //{
                        //    "$ref": "15"
                    }
                  ],
                  "PaymentModes": [
                    {
                        //"$id": "16",
                        //"Id": 1,
                        "Name": "",
                        "Description": "",
                        "IsActive": true,
                        "OrderSNo": 0
                        //},
                        //{
                        //    "$ref": "16"
                    }
                  ],
                  "Suggestions": [
                    "",
                    ""
                  ]
                  //},
                  //{
                  //    "$ref": "14"
              }
            ],
            "UnTaggedBills": [
              {
                  //"$id": "17",
                  //"Id": "",
                  "PropertyID": "",
                  "ModifiedBy": "",
                  "BillNo": "",
                  "BillDate": "",
                  "BillDateString": "",
                  "CorporateId": "",
                  "CorporateName": "",
                  "CheckINId": "",
                  "CheckINName": "",
                  "BillFrom": 0,
                  "BillFromName": "",
                  "Amount": 0,
                  "AmountReceived": 0,
                  "RemainingBalance": 0,
                  "IsInvoiceGenerated": false,
                  "InvoiceId": "",
                  "IsSelectedInInvoice": false
                  //},
                  //{
                  //    "$ref": "17"
              }
            ],
            "TaggedTransactions": [
              {
                  //    "$ref": "14"
                  //},
                  //{
                  //    "$ref": "14"
              }
            ],
            "UnTaggedTransactions": [
              {
                  //    "$ref": "14"
                  //},
                  //{
                  //    "$ref": "14"
              }
            ],
            "Adjustments": [
              {
                  //    "$ref": "14"
                  //},
                  //{
                  //    "$ref": "14"
              }
            ],
            "UnInvoicedBills": [
              {
                  //    "$ref": "17"
                  //},
                  //{
                  //    "$ref": "17"
              }
            ],
            "History": [
              {
                  //"$id": "18",
                  "CorporateName": "",
                  "DateString": "",
                  "BillId": "",
                  "BillNo": "",
                  "Type": "",
                  "Amount": 0
                  //},
                  //{
                  //    "$ref": "18"
              }
            ],
            "RecentDebit": [
              {
                  //"$id": "19",
                  "Type": "",
                  "DebitCreditDate": "",
                  "Amount": 0,
                  "Description": "",
                  "TransactionType": "",
                  "MOP": "",
                  "Bank": "",
                  "DebitDate": "",
                  "BillNo": "",
                  "Date": ""
                  //},
                  //{
                  //    "$ref": "19"
              }
            ],
            "RecentCredit": [
              {
                  //    "$ref": "19"
                  //},
                  //{
                  //    "$ref": "19"
              }
            ],
            "PropertyID": "",
            "ModifiedBy": "",
            "DateFormat": ""
        };
    }
]);

var getData = function ($scope, dataService, localStorageService) {
    
    $scope.ActionMode=""; 
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "Code",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getCorporate(options, $scope.PropertyID)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    },
    function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
