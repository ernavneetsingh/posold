﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.LoginId = $cookies.get('LoginId');


        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            UserName: '',
            Password: '',
            OldPassword: ''
        };

        $scope.Save = function (form) {
            if ($scope[form].$valid) {
                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                var status = service.save(model);
                status.then(function (result) {
                    if (result.Status == true) {
                        parent.successMessage(result.Message);
                    }
                    $scope.Model = {};
                }, function (error) {
                    parent.failureMessage(error.Message);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
            scrollPageOnTop();
        }
    }
]);
