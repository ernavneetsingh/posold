﻿
app.service('PropertyChannelManagerService', function ($http, $q) {

    this.getChannelManagerList = function () {
        return httpCaller(apiPath + "Admin/PropertyChannelManager/GetAll", $http, $q);
    };
    this.getChannelManager = function (propertyId) {
        return httpCaller(apiPath + "Admin/PropertyChannelManager/Get", $http, $q, { propertyId: propertyId });
    };

    this.save = function (model) {
        return httpPoster(apiPath + "Admin/PropertyChannelManager/save", $http, $q, model);
    };

});
