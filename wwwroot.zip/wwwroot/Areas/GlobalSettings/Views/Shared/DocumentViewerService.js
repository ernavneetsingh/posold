﻿
app.service('DocumentViewerService', [
    '$http', '$q', function (
        $http, $q) {

        var service = this;
        var scope;
        service.init = function ($scope) {
            scope = $scope;

            service.showViewer = function (doc, docs) {

                $('#modalDocumentViewer').modal('show');
                service.doc = doc;
                service.docs = docs;
                service.docs.forEach(function (d) {
                    d.PathThumb = d.Path.replace('_large.', '_thumb.');
                });
            };

            return service;
        };

    }
]);
