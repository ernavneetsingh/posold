﻿'use strict';


(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var model = [];
           
        var getAll = function (options) {
            
            var deferred = $q.defer();           
            $http.get(apiPath + "AdminConfiguration/Role?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&UserProductId=" + options.userproductid)
                .then(function (result) {
                    
                    angular.copy(result.data.Collection, model);
                    deferred.resolve(result.data.RecordCount);
                },
                function () {
                    
                    deferred.reject();
                });

            return deferred.promise;
        };

        var getAllUserProduct = function (username) {
            
            var url = apiPath + 'configuration/UserProduct/';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: { 'UserName': username },
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                deferred.resolve(result.Collection);
            }).error(function (err) {
                
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllUserProductPage = function (userproductid, moduleId, subModuleId,roleid) {

            var url = apiPath + 'Admin/RoleModulePage/GetAllRoleModulePage';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: { 'UserProductId': userproductid, 'RoleId': roleid, 'ModuleId': moduleId, 'SubModuleId': subModuleId },
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllModule = function (userProductId) {
            
            var url = apiPath + 'configuration/UserProductModule/all/' + userProductId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                deferred.resolve(result.Collection);
            }).error(function (err) {
                
                deferred.reject(err);
            });
            return deferred.promise;

        };      

        var save = function (model) {
            
            var url = apiPath + 'AdminConfiguration/Role/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            }).success(function (data, status, headers, cfg) {
                
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }

        var changeStatus = function (id) {
            
            var url = apiPath + 'AdminConfiguration/Role/status/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {}
            })
                .success(function (data) {
                    
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var deleterow = function (id) {

            var url = apiPath + 'AdminConfiguration/Role/Delete/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {}
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isRoleExist = function (model) {
            
            var url = apiPath + 'AdminConfiguration/Role/exist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            })
                .success(function (data) {
                    
                    deferred.resolve(data);
                })
                .error(function (err, status) {
                    
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var isOrderSNoExist = function (model) {
            
            var url = apiPath + 'AdminConfiguration/Role/orderexist';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            })
                .success(function (data) {
                    
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        return {
            dataModel: model,
            getAll: getAll,
            getAllUserProduct: getAllUserProduct,
            deleterow:deleterow,
            getAllModule: getAllModule,
            getAllUserProductPage: getAllUserProductPage,
            save: save,
            changeStatus: changeStatus,
            isRoleExist: isRoleExist,
            isOrderSNoExist: isOrderSNoExist
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
