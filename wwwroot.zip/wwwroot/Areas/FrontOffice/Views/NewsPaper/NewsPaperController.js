﻿
app.controller("NewsController",
    function ($scope, $http, $filter, newsService, $window, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.IsActive = true;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "PaperName";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];
        getNewspaperData();

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                
                for (var attr in item) {
                    if (attr === "Name") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {
            
            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;

        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        $scope.Save = function (form) {
            
            if ($scope[form].$valid) {

                var newspaperData = new Object();
                newspaperData.Name = $scope.PaperName;
                newspaperData.LanguageType = $scope.LanguageType;
                newspaperData.IsActive = $scope.IsActive;
                newspaperData.PropertyID = $scope.PropertyID;
                newspaperData.ModifiedBy = $scope.UserName;
                newspaperData.Id = $scope.NewsPaperId;
                var saveData = newsService.saveNewspaperData(newspaperData);
                saveData.then(function (data) {
                    
                    $scope.PaperName = "";
                    $scope.LanguageType = "";
                    $scope.IsActive = true;
                    $scope.NewsPaperId = "";
                    $scope.IsReadonly = false;
                    getNewspaperData();
                    parent.successMessage(data.Message);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }


        };
        $scope.Reset = function () {
            $scope.ActionMode = "";
            $scope.PaperName = "";
            $scope.LanguageType = "";
            $scope.IsActive = true;
            $scope.NewsPaperId = "";
            $scope.IsReadonly = false;
            $scope.query = "";
            $scope.search();
        };
        function getNewspaperData() {
            $scope.ActionMode = "";
            var getData = newsService.getNewspaperData($scope.PropertyID);
            getData.then(function (newsdata) {
                
                $scope.$apply(function () {
                    
                    $scope.items = newsdata.Collection;
                    $scope.search();
                });
            });
        };
        $scope.activeRow = function (newspaper) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var statusData = newsService.statusNewspaperData(newspaper, $scope.UserName);
            statusData.then(function (data) {
                getNewspaperData();
                parent.successMessage(data.Message);
            });
            scrollPageOnTop();
        };

        $scope.removeRow = function (newspaper) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            if (newspaper != undefined) {

                                var removeData = newsService.removeNewspaperData(newspaper);
                                removeData.then(function (data) {
                                    parent.successMessage(data.Message);
                                    $("html, body").animate({ scrollTop: 0 }, "slow");
                                    getNewspaperData();

                                },
                                    function (error) {
                                        parent.failureMessage(error.Message);
                                        $("html, body").animate({ scrollTop: 0 }, "slow");
                                    });
                            }
                            $.fancybox.close();
                        });
                }
            });
        };

        //Check existing newpaper Code
        $scope.txtNewspaperCodes = function () {
            
            var newspaperCode = newsService.newspaperExists($scope.PropertyID, $scope.PaperName, $scope.LanguageType);
            newspaperCode.then(function (data) {
                
            }, function (error) {
                
                //error handler function 
                $scope.$apply(function () {
                    $scope.PaperName = "";
                });
            });
        };

        //Fill newpaper Data 
        $scope.fillNewsPaperData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.PaperName = record.Name;
            $scope.LanguageType = record.LanguageType;
            $scope.IsActive = record.IsActive;
            $scope.NewsPaperId = record.Id;
            $scope.IsReadonly = true;
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        };
    });
