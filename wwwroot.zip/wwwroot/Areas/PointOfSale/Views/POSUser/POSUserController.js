﻿app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.LoginId = $cookies.get('LoginId');
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);
        
        $scope.Model = {
            Id: '',
            Name: '',
            UserId: '',
            UserName: '',
            FirstName: '',
            LastName: '',
            Email: '',
            IsActive: true,
            AuthorizationOptions: [],
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: [],
            AuthorizationCategoryId:'0',
        };

        //var sortKeyOrder = {
        //    key: "Name",
        //    order: "ASC",
        //};

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.recordsPerPage = 10;
        $scope.numberOfPageButtons = 10;

        getData($scope, service, localStorageService);

        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order == "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
        };
        $scope.pageChanged = function () {
            getData($scope, service, localStorageService);
        };
        $scope.search = function (searchfor) {
            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, service, localStorageService);
        };
        //------------------------------------------------------
        $scope.AuthorizationCategory = [];
        GetAuthorization();
        function GetAuthorization() {

            var promiseGet = service.getAuthorization();
            promiseGet.then(function (data) {

                $scope.AuthorizationCategory = data;
            },
            function (data) {

                parent.failureMessage(data.Message);
            });
        }

        $scope.Users = [];
        getUser();
        function getUser() {

            var promiseGet = service.GetUser($scope.PropertyID);
            promiseGet.then(function (data) {

                $scope.Users = data;
            },
                function (data) {

                    parent.failureMessage(data.message);
                });
        }
        //-------------------------------------------------
        $scope.Save = function (model, form) {
            
            if ($scope[form].$valid) {

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                model.AuthorizationOptions = $scope.Model.AuthorizationOptions;
                model.UserId = $scope.Model.User.UserId;
                model.Name = $scope.Model.User.NameForDisplay;

                var status = service.save(model);
                status.then(function (result) {
                    if (result.Status == true) {

                        var msg = model.Name + result.Message;
                        parent.successMessage(msg);
                        $scope.Model.AuthorizationOptions = [];
                        getData($scope, service, localStorageService);
                        scrollPageOnTop();
                    }
                    $scope.Reset();

                },
             function (error) {

                 scrollPageOnTop();
                 parent.failureMessage(error.Message);
             });

                //if (model.AuthorizationOptions.length > 0) {

                //} else {
                //    scrollPageOnTop();
                //    parent.failureMessage("Plese checked atleast one Option name.");
                //}

            } else {
                scrollPageOnTop();
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.Reset = function () {

            $scope.Model = { Id: '', AuthorizationCategoryId: '0'};
            $("#checkedAllUserAuthorization").attr("checked", false);
            //$scope.UserAuthorizationData = [];
            $scope.Model.AuthorizationOptions = [];
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            $scope.Model.DiscountTypeId = "Amount";
            $scope.search();//  getData();
            scrollPageOnTop();
        }
        $scope.Remove = function (model) {

            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            parent.successMessage("Record Successfully deleted.");

                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {

            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;
            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {

                    parent.successMessage(data.Message);
                }
            },
            function (error, status) {

                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };

        $scope.SelectedUnitTypeId = "";

        //----------DONE----------------------ForTable--------------------------------------
        
        
        function GetAllModels()
        {
            $scope.GetAllModels();
        }

        $scope.GetAllModels = function () {

            //var items = service.getItems(id);
            var items = service.getItems();
            items.then(function (data) {
                $scope.UserAuthorizationData = data;
            },
                function (err) {

                    parent.failureMessage(err.data.Message);
                    scrollPageOnTop();
                });


        }
        //-----------------------------------------------------------------------------------

        $scope.Edit = function (model) {
            
            $scope.Model = angular.copy(model);
            //$scope.Model.Id = model.Id;
            $scope.Model.AuthorizationOptions=[];

            //$scope.Model.User.UserId = model.UserId.toString();

            $("#checkedAllUserAuthorization").attr("checked", true);
            $scope.Model.UserGroup = "User";
            angular.forEach(model.AuthorizationOptions, function (itm) {

                $scope.Model.AuthorizationCategoryId = itm.AuthorizationCategoryId.toString();
            });

            angular.forEach($scope.Users, function (value, key) {

                if (value.UserId == model.UserId) {

                    $scope.Model.User = $scope.Users[key];
                }
            })
            $scope.GetAllModels(model.AuthorizationCategoryId);

            angular.forEach(model.AuthorizationOptions, function (itm) {

                $scope.Model.AuthorizationOptions.push(itm);
            });
        }

        $scope.Model.AuthorizationOptions = [];

        $scope.isCheckedUserAuthorization = function (id) {

            var match = false;
            for (var i = 0 ; i < $scope.Model.AuthorizationOptions.length; i++) {

                if ($scope.Model.AuthorizationOptions[i].Id == id) {
                    match = true;
                }
            }
            return match;
        };

        $scope.syncUserAuthorization = function (bool, item) {
            
            if (bool) {
                $scope.Model.AuthorizationOptions.push(item);
            } else {
                for (var i = 0 ; i < $scope.Model.AuthorizationOptions.length; i++) {
                    if ($scope.Model.AuthorizationOptions[i].Id == item.Id) {
                        $scope.Model.AuthorizationOptions.splice(i, 1);
                    }
                }
            }
        };

        $scope.checkedAllUserAuthorization = function ($event) {

            $scope.Model.AuthorizationOptions = [];
            if ($event.target.checked) {

                angular.forEach($scope.UserAuthorizationData, function (itm) {
                    $scope.Model.AuthorizationOptions.push(itm);
                });
            }
            if (!$event.target.checked) {
                $scope.Model.AuthorizationOptions = [];
            }
            console.log($scope.Model.AuthorizationOptions);
        };
        //---------------------------------------------------------------------------
        GetAllModels();
    }
]);

var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "UserName",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };
    $scope.showLoader = true;
    dataService.getData($scope.PropertyID, options)
        .then(function (totalItems) {
            
            $scope.totalItems = totalItems;
            $scope.showLoader = false;
        },
            function () {
                parent.failureMessage("The request failed. Unable to connect to the remote server.");
            });

};