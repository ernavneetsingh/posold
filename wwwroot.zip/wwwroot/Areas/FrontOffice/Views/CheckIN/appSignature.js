﻿angular.module('appSignature', ['signature', 'ngCookies']);

angular.module('appSignature').controller('AppCtrl', function ($scope, $q, $http, $sce, $window, $cookies) {
    $scope.boundingBox = {
        width: 800,
        height: 250
    };
    var EMPTY_IMAGE = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjgAAADcCAQAAADXNhPAAAACIklEQVR42u3UIQEAAAzDsM+/6UsYG0okFDQHMBIJAMMBDAfAcADDATAcwHAAwwEwHMBwAAwHMBzAcAAMBzAcAMMBDAcwHADDAQwHwHAAwwEMB8BwAMMBMBzAcADDATAcwHAADAcwHADDAQwHMBwAwwEMB8BwAMMBDAfAcADDATAcwHAAwwEwHMBwAAwHMBzAcAAMBzAcAMMBDAcwHADDAQwHwHAAwwEwHMBwAMMBMBzAcAAMBzAcwHAADAcwHADDAQwHMBwAwwEMB8BwAMMBDAfAcADDATAcwHAAwwEwHMBwAAwHMBzAcCQADAcwHADDAQwHwHAAwwEMB8BwAMMBMBzAcADDATAcwHAADAcwHMBwAAwHMBwAwwEMBzAcAMMBDAfAcADDAQwHwHAAwwEwHMBwAAwHMBzAcAAMBzAcAMMBDAcwHADDAQwHwHAAwwEMB8BwAMMBMBzAcADDATAcwHAADAcwHMBwAAwHMBwAwwEMB8BwAMMBDAfAcADDATAcwHAAwwEwHMBwAAwHMBzAcAAMBzAcAMMBDAcwHADDAQwHwHAAwwEMB8BwAMMBMBzAcADDkQAwHMBwAAwHMBwAwwEMBzAcAMMBDAfAcADDAQwHwHAAwwEwHMBwAMMBMBzAcAAMBzAcwHAADAcwHADDAQwHMBwAwwEMB8BwAMMBMBzAcADDATAcwHAADAcwHMBwAAwHMBwAwwEMBzAcAMMBDAegeayZAN3dLgwnAAAAAElFTkSuQmCC';
    $scope.UserName = $cookies.get('UserName');

    //SignalR
    $scope.IsHubConnected = false;
    var connection = $.hubConnection(apiPath);
    var eventName = "onMessageListened";
    connection.start({ withCredentials: false }).done(function () {
        $scope.$apply(function () {
            $scope.IsHubConnected = true;
        });
    });
    var messageBroadCast = connection.createHubProxy('BroadCastHub');
    messageBroadCast.on(eventName, function (message) {
        var res = message.split("$");
        //CHECKIN_VERIFICATION_SAVE
        if (res[0] == "CHECKIN_VERIFICATION_SAVE") {

            if (res[2] == $scope.UserName) {
                $scope.OpenVerification(res[3]);
            }
        }
        if (res[0] == "CHECKIN_VERIFICATION_ACCEPT") {
            if (res[2] == $scope.UserName) {
                alert("Thankyou! :)");
                $scope.clear();
                $scope.ShowGuestInfo = true;
                $scope.ShowTermsConditions = true;
                $scope.CheckINGuestVerification = {};
                $('#signaturepad').hide('slow');
                $window.location.reload();
            }
        }
        if (res[0] == "CHECKIN_VERIFICATION_DECLINE") {
            if (res[2] == $scope.UserName) {
                alert("You Decline the Info! :(");
                $scope.clear();
                $scope.ShowGuestInfo = true;
                $scope.ShowTermsConditions = true;
                $scope.CheckINGuestVerification = {};
                $('#signaturepad').hide('slow');
                $window.location.reload();
            }
        }
    });
    //end signalR

    $scope.OpenVerification = function (GUID) {

        
        $scope.CheckINGuestVerification = {};
        var promiseGet = getCheckINGuestVerification(GUID);
        promiseGet.then(function (data, status) {

            $scope.CheckINGuestVerification = data.Data;
            $scope.ShowGuestInfo = true;
            $scope.ShowTermsConditions = false;
            $('#signaturepad').hide('slow');

        },
            function (error, status) {
                parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
            });
    };

    function getCheckINGuestVerification(guid) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/CheckINVerification/GetByGUID/" + guid,
            data: {}
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;

    }

    //Verfication
    $scope.ShowGuestInfo = true;
    $scope.ShowTermsConditions = true;
    $scope.CheckINGuestVerification = {};
    $scope.ShowCheckINGuestVerificationNext = function () {
        $scope.ShowGuestInfo = false;
        $scope.ShowTermsConditions = true;
        $('#signaturepad').show('slow');
    }

    $scope.content = "This text is <em>html capable</em> meaning you can have <a href=\"#\">all</a> sorts <b>of</b> html in here.";
    $scope.getHtml = function (html) {
        return $sce.trustAsHtml(html);
    };

    $scope.back = function () {
        $scope.ShowGuestInfo = true;
        $scope.ShowTermsConditions = false;
        $('#signaturepad').hide('slow');
    }
    

    $scope.IsEmpty = function () {

        return $scope.dataurl === EMPTY_IMAGE || !$scope.dataurl;
    };

    signature = {};
    $scope.Accept = function () {

        
        signature = {
            isEmpty: $scope.dataurl === EMPTY_IMAGE || !$scope.dataurl,
            dataUrl: $scope.dataurl
        };
        Accept();
    };
    function Accept() {
        //var signature = $scope.accept();
        //Save
        var ImageModel = {
            Base64: signature.dataUrl,
            EntityName: 'Guest',
            PropertyID: $scope.CheckINGuestVerification.PropertyID,
        };

        var promiseGet = uploadBase64(ImageModel);
        promiseGet.then(function (data, status) {
            var path = data.Data;
            $scope.CheckINGuestVerification.SignatureUrl = path;
            var promiseGet1 = setAccept($scope.CheckINGuestVerification);
            promiseGet1.then(function (data, status) {
                //ShowThanks MSG
            },
                function (error, status) {
                    parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
                });

        },
            function (error, status) {
                parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
            });
    }
    var uploadBase64 = function (model) {

        var url = apiPath + 'Upload/FileBase64/';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            //headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        })
            .success(function (data) {
                deferred.resolve(data);
//                window.close();
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    function setAccept(model) {

        var url = apiPath + 'FrontOffice/CheckINVerification/Save/';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            contentType: "application/json; charset=utf-8"
        })
            .success(function (data) {
                deferred.resolve(data);
                window.close();
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
        return deferred.promise;

    }

    $scope.Decline = function () {
       
        var promiseGet = Decline($scope.CheckINGuestVerification);
        promiseGet.then(function (data, status) {
            var path = data.Data;
            $scope.CheckINGuestVerification.SignatureUrl = path;
            var promiseGet1 = setAccept($scope.CheckINGuestVerification);
            promiseGet1.then(function (data, status) {
                //ShowThanks MSG
            },
                function (error, status) {
                    parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
                });

        },
            function (error, status) {
                parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
            });
    };
    function Decline(model) {
        
        var url = apiPath + 'FrontOffice/CheckINVerification/Decline/';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            contentType: "application/json; charset=utf-8"
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
        return deferred.promise;
    }
});

angular.module('appSignature').filter('html', function ($sce) {
    return function (val) {
        return $sce.trustAsHtml(val);
    };
});