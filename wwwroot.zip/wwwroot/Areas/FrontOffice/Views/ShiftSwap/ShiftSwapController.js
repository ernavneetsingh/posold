﻿
app.controller("ShiftSwapController", [
    "$scope", "shiftSwapService", "$cookies", "$filter", "localStorageService", function (
        $scope, shiftSwapService, $cookies, $filter, localStorageService) {
        
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        
        $scope.LoginId = $cookies.get('LoginId');
        
        
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.CurDate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);//"2017-03-23";// 

        $scope.model = {};
        $scope.model.RoomExitTypeId = 1;

        $scope.roomtransfershow = function () {
            $scope.model.RoomExitTypeId = 1;
        }
        $scope.swaproomshow = function () {
            $scope.model.RoomExitTypeId = 2;
        }

        $scope.getOccupiedRoomList = function () {
            shiftSwapService.getOccupiedRoomList($scope.PropertyID, $scope.CurDate)
                .then(function (result) {

                    $scope.OccupiedRoomList = angular.copy(result.Collection);
                    $scope.OccupiedRoomListSearched = $scope.OccupiedRoomList;
                    $scope.SwapRoomList = angular.copy(result.Collection);
                    $scope.SwapRoomListSearchedTemp = $scope.SwapRoomListSearched = $scope.SwapRoomList;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getOccupiedRoomList();
        $scope.loadOccupiedRoom = function (record) {
            
            angular.forEach($scope.OccupiedRoomListSearched, function (d) { d.IsSelected = false; });
            record.IsSelected = true;
            record.RoomExitTypeId = $scope.model.RoomExitTypeId;
            $scope.model = record;
            $scope.model.FromCheckINGuestRoomId = record.CheckINGuestRoomId;

            $scope.SwapRoomListSearched = [];
            angular.forEach($scope.SwapRoomListSearchedTemp, function (item) {

                if (item.Id != record.Id) {
                    $scope.SwapRoomListSearched.push(item);
                }
            });

        };
        $scope.searchShiftOccupied = function (room) {

            $scope.OccupiedRoomListSearched = [];
            angular.forEach($scope.OccupiedRoomList, function (item) {

                if (item.RoomNumber.indexOf(room) > -1) {
                    $scope.OccupiedRoomListSearched.push(item);
                }
            });
            $scope.SwapRoomListSearchedTemp = $scope.SwapRoomListSearched;
        };

        //$scope.getVacantRoomList = function () {
        //     
        //    shiftSwapService.getVacantRoomList($scope.PropertyID)
        //        .then(function (result) {
        //             
        //            $scope.VacantRoomList = result.Collection;
        //            $scope.VacantRoomListSearched = result.Collection;
        //        }, function (err) {
        //            msg(err.Message);
        //        });
        //};
        //$scope.getVacantRoomList();
        $scope.loadVacantRoom = function (record) {

            angular.forEach($scope.VacantRoomListSearched, function (d) { d.IsSelected = false; });
            record.IsSelected = true;
            $scope.transfer = record;
            //$scope.model.ToId = record.CheckINGuestRoomId;
            $scope.model.ToId = record.RoomMasterId;

        };
        $scope.searchShiftVacant = function (room) {

            $scope.VacantRoomListSearched = [];
            angular.forEach($scope.VacantRoomList, function (item) {

                if (item.RoomNumber.indexOf(room) > -1) {
                    $scope.VacantRoomListSearched.push(item);
                }
            });
        };

        $scope.loadSwapRoom = function (record) {
            angular.forEach($scope.SwapRoomListSearched, function (d) { d.IsSelected = false; });
            record.IsSelected = true;
            $scope.swap = record;
            $scope.model.ToId = record.CheckINGuestRoomId;
        };
        $scope.searchSwapOccupied = function (room) {

            $scope.SwapRoomListSearched = [];
            angular.forEach($scope.SwapRoomList, function (item) {

                if (item.RoomNumber.indexOf(room) > -1) {
                    $scope.SwapRoomListSearched.push(item);
                }
            });
        };

        $scope.RoomFeatures = [];
        $scope.Floors = [];
        $scope.Blocks = [];
        $scope.RoomTypes = [];
        $scope.RoomFeatureSettings = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true,
            displayProp: 'Name'
        };
        $scope.getRoomTypeList = function () {
            shiftSwapService.getRoomTypeList($scope.PropertyID)
                 .then(function (result) {

                     $scope.RoomTypeList = result.Collection;
                 }, function (err) {

                     msg(err.Message);
                 });
        };
        $scope.getRoomTypeList();
        $scope.getRoomFeatureList = function () {
            shiftSwapService.getRoomFeatureList($scope.PropertyID)
                 .then(function (result) {
                     $scope.RoomFeatureList = result.Collection;
                 }, function (err) {
                     msg(err.Message);
                 });
        };
        $scope.getRoomFeatureList();
        $scope.getFloorList = function () {
            shiftSwapService.getFloorList($scope.PropertyID)
                 .then(function (result) {
                     $scope.FloorList = result.Collection;
                 }, function (err) {
                     msg(err.Message);
                 });
        };
        $scope.getFloorList();
        $scope.getBlockList = function () {
            shiftSwapService.getBlockList($scope.PropertyID)
                 .then(function (result) {
                     $scope.BlockList = result.Collection;
                 }, function (err) {
                     msg(err.Message);
                 });
        };
        $scope.getBlockList();
        $scope.myEventListeners = {
            onItemSelect: onItemSelect,
            onItemDeselect: onItemSelect,
            onSelectAll: onItemSelect,
            onDeselectAll: onItemSelect
        };
        function onItemSelect(property) {

            $scope.search();
        }
        $scope.search = function () {
            var featureId = "";
            angular.forEach($scope.RoomFeatures, function (feature) {
                featureId += feature.Id + ",";
            });
            var floorId = "";
            angular.forEach($scope.Floors, function (floor) {
                floorId += floor.Id + ",";
            });
            var blockId = "";
            angular.forEach($scope.Blocks, function (block) {
                blockId += block.Id + ",";
            });
            var roomTypeId = "";
            angular.forEach($scope.RoomTypes, function (roomType) {
                roomTypeId += roomType.Id + ",";
            });            //roomTypeId = roomTypeId.substr(0, roomTypeId.length - 1);
            $scope.getRoomList(featureId, floorId, blockId, roomTypeId);
        };
        $scope.getRoomList = function (featureId, floorId, blockId, roomTypeId) {

            shiftSwapService.getRoomList($scope.PropertyID, featureId, floorId, blockId, roomTypeId)
                .then(function (result) {

                    $scope.VacantRoomList = result.Collection;
                    $scope.VacantRoomListSearched = result.Collection;

                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getReasonList = function () {
            shiftSwapService.getReasonList($scope.PropertyID)
                 .then(function (result) {
                     $scope.ReasonList = result.Collection;
                 }, function (err) {
                     msg(err.Message);
                 });
        };
        $scope.getReasonList();

        $scope.save = function () {
            
            if (!$scope.model.FromCheckINGuestRoomId) {
                msg('Please select from room.')
                return;
            }
            if (!$scope.model.ToId) {
                msg('Please select to room.')
                return;
            }

            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;//CurDate;

            shiftSwapService.save($scope.model)
                .then(function (d) {
                    msg(d.Message, d.Status);
                    $scope.reset();
                });
        };

        $scope.search();
    }
]);
