﻿
app.controller('NightAuditOutletDetailController', [
    '$scope', 'localStorageService', 'NightAuditOutletDetailService', '$filter', function (
        $scope, localStorageService, service, $filter) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        $scope.title = 'Sales Summary by Outlet';

        $scope.getAll = function (date1) {
            $scope.IsLoading = true;
            $scope.items = [];
            service.getAll($scope.PropertyID, date1)
                .then(function (s) {
                    $scope.items = s.Collection;
                    //$scope.itemsgroup = $filter('groupBy')($scope.items, 'RevenueTypeName');
                    //angular.forEach($scope.itemsgroup,function (g) {
                    //    g.Amount = g.items.reduce((sum,item)=>sum+item.Amount,0).toFixed(2) ;
                    //    g.Allowance = g.items.reduce((sum,item)=>sum+item.Allowance,0).toFixed(2) ;
                    //    g.Net = g.items.reduce((sum,item)=>sum+item.Net,0).toFixed(2) ;
                    //    g.AmountMonth = g.items.reduce((sum,item)=>sum+item.AmountMonth,0).toFixed(2) ;
                    //    g.AllowanceMonth = g.items.reduce((sum,item)=>sum+item.AllowanceMonth,0).toFixed(2) ;
                    //    g.NetMonth = g.items.reduce((sum,item)=>sum+item.NetMonth,0).toFixed(2) ;

                    //});
                    //$scope.items.Amount=0;
                    //$scope.items.Allowance=0;
                    //$scope.items.Net=0;
                    //$scope.items.AmountMonth=0;
                    //$scope.items.AllowanceMonth=0;
                    //$scope.items.NetMonth=0;
                    //angular.forEach($scope.itemsgroup,function (g) {
                    //    if(g.group_name){ 
                    //        if(g.group_name==='Collection')
                    //        {   
                    //            $scope.items.Amount+=parseFloat(g.Amount);
                    //            $scope.items.Allowance+=parseFloat(g.Allowance);
                    //            $scope.items.Net+=parseFloat(g.Net);
                    //            $scope.items.AmountMonth+=parseFloat(g.AmountMonth);
                    //            $scope.items.AllowanceMonth+=parseFloat(g.AllowanceMonth);
                    //            $scope.items.NetMonth+=parseFloat(g.NetMonth);
                    //        }   else
                    //        {
                    //            $scope.items.Amount-=parseFloat(g.Amount);
                    //            $scope.items.Allowance-=parseFloat(g.Allowance);
                    //            $scope.items.Net-=parseFloat(g.Net);
                    //            $scope.items.AmountMonth-=parseFloat(g.AmountMonth);
                    //            $scope.items.AllowanceMonth-=parseFloat(g.AllowanceMonth);
                    //            $scope.items.NetMonth-=parseFloat(g.NetMonth);
                    //        }}
                    //});
                    //$scope.items.Amount=parseFloat($scope.items.Amount).toFixed(2);
                    //$scope.items.Allowance=parseFloat($scope.items.Allowance).toFixed(2);
                    //$scope.items.Net=parseFloat($scope.items.Net).toFixed(2);
                    //$scope.items.AmountMonth=parseFloat($scope.items.AmountMonth).toFixed(2);
                    //$scope.items.AllowanceMonth=parseFloat($scope.items.AllowanceMonth).toFixed(2);
                    //$scope.items.NetMonth=parseFloat($scope.items.NetMonth).toFixed(2);

                    $scope.IsLoading = false;
                }, function (e) {
                    msg(e.Message);
                    $scope.IsLoading = false;
                });
        };
        $scope.reset = function () {
            $scope.IsLoading = false;
            $scope.items = [];
            //$scope.itemsgroup = [];
            $scope.DateFromString = '';
            //$scope.DateToString = '';

        };
        $scope.print = function () {

            var printContents = document.getElementById('printable').innerHTML;
            var popupWin = window.open('', '_blank', 'width=700,height=600');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">');
            popupWin.document.write('<table><tr><td width=20%><img src=' + (!$scope.Header ? '' : $scope.Header.Logo) + ' /></td>');
            popupWin.document.write('<td width=60%><center><h3>' + (!$scope.Header ? '' : $scope.Header.Name + '<br/>'));
            popupWin.document.write(!$scope.Header ? '' : ($scope.Header.Address1 + '<br/>'));
            //popupWin.document.write(!$scope.Header ? '' : (($scope.Header.Address?$scope.Header.Address:'') + '<br/>'));
            popupWin.document.write((!$scope.Header ? '' : $scope.Header.City + ', ' + $scope.Header.StateName + ', ' + $scope.Header.CountryName) + '<br/>');
            popupWin.document.write('<u><i>' + $scope.title + ' Report</i></u></h3></center></td>');
            //popupWin.document.write('<td width=20%><br/><br/><br/><div align=right>Print Date: '+$scope.CurrentDate+' '+ $scope.CurrentTime +'</div></td></tr></table>');
            popupWin.document.write('<td width=20%><br/><br/><br/><div align=right>Report Date: ' + ($filter('date')($scope.DateFromString, $scope.DateFormat)) + '</div></td></tr></table>');
            popupWin.document.write('<hr/><br/>' + printContents + '<hr/><br/>');

            popupWin.document.write('</body></html>');
            popupWin.document.close();
        };
        $scope.getCompanyInfo = function () {
            $scope.IsLoading = true;
            service.getCompanyInfo($scope.PropertyID)
                .then(function (s) {
                    msg(s.Message, true);
                    $scope.Header = s.Data;
                    $scope.IsLoading = false;
                }, function (e) {
                    msg(e.Message);
                    $scope.IsLoading = false;
                });
        };

        $scope.getCompanyInfo();

    }
]);
