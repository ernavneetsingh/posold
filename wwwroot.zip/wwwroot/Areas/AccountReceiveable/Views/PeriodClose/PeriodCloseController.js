﻿
app.controller('PeriodCloseController',
    function ($scope, $http, $filter, periodCloseService, $window, $cookies, periodStartService, $timeout, localStorageService) {
        //TODO navneetmanoj
        //$scope.DateFormatDisplay = $cookies.get('DateFormat').replace('yyyy', 'yy');
        //$scope.MaxDatess = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormatG = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        //var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.DateFormat = 'MMyyyy';

        if (angular.isUndefined($scope.PropertyID) || $scope.PropertyID === null || $scope.PropertyID === '') {
            $window.location.href = apiPath + 'login.html';
        }
        $scope.PeriodClose = {};
        $scope.PeriodClose.ModifiedDate = $scope.ModifiedDate;
        $scope.MsgNotFound = '';
        $scope.sortingOrder = 'CloseOn';
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;
        $scope.items = [];

        periodCloseService.getStartPeriod($scope);
        getAll();
        $scope.save = function (form, model) {
            
            if ($scope[form].$valid) {

                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                model.ModifiedDate = $scope.ModifiedDate;
                var saveData = periodCloseService.Save(model);
                saveData.then(function (data) {
                    $scope.Reset();
                    getAll();
                    msg(data.Message, true);
                    periodCloseService.getStartPeriod($scope);
                    //$window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
                });

            } else {
                $scope.ShowErrorMessage = true;
            }
        };
        $scope.Reset = function () {
            $scope.PeriodClose = {};
            $scope.Code = '';
            $scope.Name = '';
            $scope.Description = '';
            $scope.IsActive = true;
            $scope.IsReadonly = false;
            $scope.Id = '';
            $scope.query = '';
            getAll();
        };
        function getAll() {
            var getData = periodCloseService.GetAll($scope.PropertyID);
            getData.then(function (data) {
                $scope.$apply(function () {
                    var list = data.Collection;
                    if (list.length > 0) {
                        $scope.items = list;
                        angular.forEach($scope.items, function (item) { item.CloseOnSort = item.CloseOn.substr(2) + item.CloseOn.substr(0, 2); });
                        $scope.search();
                        $scope.PeriodClose.PropertyName = list[0].PropertyName;
                        $scope.PeriodClose.ModifiedDate = list[0].ModifiedDate;
                    }
                });
            });
        };
        $scope.fillModel = function (record) {

            $scope.PeriodClose = record;
            $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);

        };

        //////////////////

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {
            

            $scope.filteredItems = $filter('filter')($scope.items, function (item) {
                for (var attr in item) {

                    if (attr === 'PeriodStartOn' || attr === 'CloseOn') {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }

                return false;

            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter('orderBy')($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        // show items per page
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        // calculate page in place
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }

            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = 'Record Not Found.';
                $scope.pagedItems.length = 1;
            } else {
                $scope.MsgNotFound = '';
            }

        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };

        $scope.sort_by = function (newSortingOrder) {
            
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        function updateset(minDate) {

            $scope.dateset = $filter('date')(dateAdd(minDate, 'day', 1), 'yyyy-MM-dd');
        }
        $scope.$watch('MinDate', updateset);
    });
