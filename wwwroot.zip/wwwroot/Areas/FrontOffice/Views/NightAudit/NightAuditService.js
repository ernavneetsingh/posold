﻿
(function () {
    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

       var GetConstantByPropertyId = function (propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckIN/GetConstantByPropertyId/" + propertyId,
                data: {}
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getSetup = function (propertyId, id) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/CheckIN/GetSetup/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getNightAudit = function (propertyID, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/NightAudit/GetNightAudit/?propertyId=" + propertyID + "&businessDate=" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getCheckINGuestRoomRate = function (id) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/CheckINGuestRoomRate/GetById/" + id)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        //Room Rate
        var getCheckINGuestRoom = function (id) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckINGuestRoom/GetById/" + id,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };
        //end 

        var getPendingKOTs = function (propertyID, outletid) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/KOT/GetAllKOTStatus/" + propertyID + "/" + outletid + "/1")
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getPendingKOTBills = function (propertyID, outletid) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/KOTBill/GetAllPending/" + propertyID + "/" + outletid)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getAllUnBill = function (propertyID) {
            var deferred = $q.defer();
            $http.get(apiPath + "HouseKeeping/LaundryEntry/GetAllUnBill/" + propertyID)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getAllUnSettled = function (propertyID) {
            var deferred = $q.defer();
            $http.get(apiPath + "HouseKeeping/LaundryBill/GetAllUnSettled/?propertyId=" + propertyID)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getNightAuditMessage = function (messageTypeId, propertyID, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/Messenger/GetAllByMessageTypeId/?messageTypeId=" + messageTypeId + "&propertyId=" + propertyID + "&businessDate=" + businessDate + "&numberofdays=0" )
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        //POST
        var resetDayRate = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/CheckINGuestRoomRate/ResetDayRate",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        var saveCheckINGuestRoom = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/CheckINGuestRoom/Save",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        //change arrival date
        var changeArrivalDate = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/ReservationRoomType/ChangeArrivalDate",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        //no show
        var noShow = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/NightAudit/NOShow",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        //no show
        var noShowGuest = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/NightAudit/NOShowGuest",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        function ChangeRoomOutDate(checkINGuestId, newRoomOutDate, businessDate) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/CheckINGuest/ChangeRoomOutDate/" + checkINGuestId + "/" + newRoomOutDate + "/" + businessDate,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err.Message);
            });
            return deferred.promise;
        };

        //day end
        var getAllChargePost = function (propertyID, businessDate) {

            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/NightAudit/GetAllChargePost/?propertyId=" + propertyID + "&businessDate=" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        //dayClose
        var dayClose = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/NightAudit/DayClose",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };
        
        var saveAcknowledge = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/Messenger/SaveAcknowledge",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);
            }).error(function (err, status) {

                deferred.reject(err, status);
            });
            return deferred.promise;
        };

        var getRoomType = function (propertyId) {
            return httpCaller(apiPath + "FrontOffice/RoomType/GetAllByPropertyIdMin", $http, $q, { propertyId: propertyId });
        };

        var GetReason = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/Reason/AllByModuleId", $http, $q, { propertyId: propertyId, moduleId: 1 });
        };

        return {
            GetReason:GetReason,
            getSetup: getSetup,
            GetConstantByPropertyId:GetConstantByPropertyId,
            changeArrivalDate: changeArrivalDate,
            //changeDepartureDate :changeDepartureDate ,
            ChangeRoomOutDate:ChangeRoomOutDate,
            noShow:noShow,
            getNightAudit: getNightAudit,
            getCheckINGuestRoomRate: getCheckINGuestRoomRate,
            getPendingKOTs: getPendingKOTs,
            getPendingKOTBills: getPendingKOTBills,
            getAllUnBill: getAllUnBill,
            getAllUnSettled: getAllUnSettled,
            resetDayRate: resetDayRate,
            getAllChargePost: getAllChargePost,
            dayClose: dayClose,
            getNightAuditMessage: getNightAuditMessage,
            saveAcknowledge: saveAcknowledge,
            getCheckINGuestRoom: getCheckINGuestRoom,
            getRoomType: getRoomType,
            saveCheckINGuestRoom: saveCheckINGuestRoom,
            noShowGuest: noShowGuest,
        };

    }
    app.factory("service", ["$http", "$q", service]);
})();

