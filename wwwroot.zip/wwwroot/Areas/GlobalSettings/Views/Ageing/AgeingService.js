﻿
app.service('ageingService', function ($http, $q) {

    this.getmoduledata = function () {
        return httpCaller(apiPath + "configuration/Module/all", $http, $q);
    };
    this.getagingdata = function (propertyId, moduleId) {
        var params = { propertyId: propertyId, moduleId: moduleId };
        return httpCaller(apiPath + "GlobalSetting/Ageing/All", $http, $q, params);
    };
    this.save = function (model) {
        return httpPoster(apiPath + "GlobalSetting/Ageing/Save", $http, $q, model);
    };

});