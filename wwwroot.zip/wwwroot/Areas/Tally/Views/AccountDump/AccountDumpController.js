﻿
app.controller("AccountDumpController",
[
    "$scope", "AccountDumpService", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');

        $scope.Model = {};
        $scope.Save = function () {

            
            $scope.Model.PropertyID = $scope.PropertyID;
            service.save($scope.Model)
                .then(function (result) {
                    if (result.Status == true) {
                        msg(result.Message, true);
                    }
                    $scope.Reset();
                }, function (error) {
                    msg(error.Message);
                });
        }

        $scope.Reset = function () {
            $scope.Model = {};
        }
    }
]);
