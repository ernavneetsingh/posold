﻿'use strict';

(function () {

    function service($http, $q) {

        var model = [];

        var getAll = function (options) {

            var deferred = $q.defer();

            $http.get(apiPath + "configuration/modulepage?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor)
                .then(function (result) {
                    angular.copy(result.data.Collection, model);
                    deferred.resolve(result.data.RecordCount);
                },
                function () {
                    deferred.reject();
                });
            return deferred.promise;
        };
        var getAllByPageIdActive = function (id) {
            return httpCaller(apiPath + "configuration/ModulePageHelp/GetAllByPageIdActive", $http, $q, { pageid: id });
        };

        var save = function (model) {

            var url = apiPath + 'configuration/ModulePageHelp/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var getAllModules = function () {

            var deferred = $q.defer();

            $http.get(apiPath + 'configuration/module/all')
                .then(function (result) {
                    deferred.resolve(result.data.Collection);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });

            return deferred.promise;
        };

        var getAllPages = function () {

            var deferred = $q.defer();

            $http.get(apiPath + 'configuration/modulepage/all')
                .then(function (result) {
                    deferred.resolve(result.data.Collection);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });

            return deferred.promise;
        };

        var getAllPageByModuleId = function (moduleid, submoduleid) {

            var deferred = $q.defer();

            $http.get(apiPath + 'configuration/modulepage/all/' + moduleid + '/' + submoduleid)
                .then(function (result) {
                    deferred.resolve(result.data.Collection);
                },
                function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });

            return deferred.promise;
        };

        //var isNameExist = function (model) {

        //    var url = apiPath + 'configuration/modulepage/exist';
        //    var deferred = $q.defer();
        //    $http({
        //        method: 'POST',
        //        url: url,
        //        data: model
        //    })
        //        .success(function (data) {
        //            deferred.resolve(data);
        //        })
        //        .error(function (err, status) {
        //            deferred.reject(err);
        //        });
        //    return deferred.promise;
        //};

        //var isOrderSNoExist = function (model) {

        //    var url = apiPath + 'configuration/modulepage/orderexist';
        //    var deferred = $q.defer();
        //    $http({
        //        method: 'POST',
        //        url: url,
        //        data: model
        //    })
        //        .success(function (data) {
        //            deferred.resolve(data);

        //        })
        //        .error(function (err, status) {
        //            deferred.reject(err);
        //        });
        //    return deferred.promise;
        //};

        //var isUrlExist = function (model) {

        //    var url = apiPath + 'configuration/modulepage/urlexist';
        //    var deferred = $q.defer();
        //    $http({
        //        method: 'POST',
        //        url: url,
        //        data: model
        //    })
        //        .success(function (data) {
        //            deferred.resolve(data);

        //        })
        //        .error(function (err, status) {
        //            deferred.reject(err);
        //        });
        //    return deferred.promise;
        //};

        var changeStatus = function (id) {

            var url = apiPath + 'configuration/ModulePageHelp/ChangeStatus/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {}
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        var remove = function (id) {
            return httpCaller(apiPath + "configuration/ModulePageHelp/Delete", $http, $q, { id: id });
        };
        var searchTag = function (tagName) {
            return httpCaller(apiPath + "configuration/HelpTag/Search", $http, $q, { tagName: tagName });
        };

        return {
            searchTag: searchTag,
            remove: remove,
            dataModel: model,
            getAll: getAll,
            save: save,
            getAllModules: getAllModules,
            getAllPages: getAllPages,
            getAllPageByModuleId: getAllPageByModuleId,
            //isNameExist: isNameExist,
            //isOrderSNoExist: isOrderSNoExist,
            //isUrlExist: isUrlExist,
            changeStatus: changeStatus,
            getAllByPageIdActive: getAllByPageIdActive
        };
    }

    app.factory('ModulePageHelpService', ['$http', '$q', service]);
})();
