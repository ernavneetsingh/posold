﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout", "$rootScope",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout, $rootScope) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.Model = {

            Id: '',
            SMSTemplateTypeId: '',
            ActionTypeId: '',
            SenderName: '',
            Subject: '',
            Template: '',
            CC: '',
            BCC: '',
            IsActive: true,

            EMailTemplates: [],

            PropertyID: '',
            ModifiedBy: '',

        };

        $scope.ReservationAdd = {};
        $scope.ReservationEdit = {};
        $scope.ReservationCancel = {};
        $scope.CheckINAdd = {};
        $scope.CheckOUTAdd = {};
        $scope.PurchaseOrderAdd = {};
        $scope.CashieringAdd = {};
        $scope.SendLinkAdd = {};
        $scope.BirthdayAdd = {};
        $scope.AnniversaryAdd = {};
        $scope.PromotionalAdd = {};

        $scope.ReservationGuestPickupDrop = {};
        $scope.ReservationBookingEngineAdd = {};
        $scope.PreArrival = {};
        $scope.TentativeBooking = {};

        function GetAllByPropertyId() {

            var promiseGet = service.getAllByPropertyId($scope.PropertyID);
            promiseGet.then(function (data) {

                angular.forEach(data.Collection, function (item) {

                    
                    if (item.SMSTemplateTypeName == "Reservation" && item.ActionTypeName == "Add") {
                        $scope.ReservationAdd = item;
                    }
                    else if (item.SMSTemplateTypeName == "Reservation" && item.ActionTypeName == "Edit") {
                        $scope.ReservationEdit = item;
                    }
                    else if (item.SMSTemplateTypeName == "Reservation" && item.ActionTypeName == "Cancel") {
                        $scope.ReservationCancel = item;
                    }
                    else if (item.SMSTemplateTypeName == "CheckIN" && item.ActionTypeName == "Add") {
                        $scope.CheckINAdd = item;
                    }
                    else if (item.SMSTemplateTypeName == "CheckOUT" && item.ActionTypeName == "Add") {
                        $scope.CheckOUTAdd = item;
                    }
                    else if (item.SMSTemplateTypeName == "PurchaseOrder" && item.ActionTypeName == "Add") {
                        $scope.PurchaseOrderAdd = item;
                    } else if (item.SMSTemplateTypeName == "SendLink" && item.ActionTypeName == "Add") {
                        $scope.SendLinkAdd = item;
                    } else if (item.SMSTemplateTypeName == "Birthday" && item.ActionTypeName == "Add") {
                        $scope.BirthdayAdd = item;
                    } else if (item.SMSTemplateTypeName == "Anniversary" && item.ActionTypeName == "Add") {
                        $scope.AnniversaryAdd = item;
                    } else if (item.SMSTemplateTypeName == "Promotional" && item.ActionTypeName == "Add") {
                        $scope.PromotionalAdd = item;
                    } else if (item.SMSTemplateTypeName == "ReservationBookingEngine" && item.ActionTypeName == "Add") {
                        $scope.ReservationBookingEngineAdd = item;
                    } else if (item.SMSTemplateTypeName == "ReservationGuestPickupDrop" && item.ActionTypeName == "Add") {
                        $scope.ReservationGuestPickupDrop = item;
                    } else if (item.SMSTemplateTypeName == "TentativeBooking" && item.ActionTypeName == "Add") {
                        $scope.TentativeBooking = item;
                    } else if (item.SMSTemplateTypeName == "PreArrival" && item.ActionTypeName == "Add") {
                        $scope.PreArrival = item;
                    }

                });

            },
                function (error) {
                    $scope.Model = {};
                    msg(error.Message);
                    scrollPageOnTop();
                });
        };
        GetAllByPropertyId();

        $scope.Save = function (form) {
            
            $scope.Model.EMailTemplates = [];

            if ($scope[form].$valid) {
                
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 1, ActionTypeId: 1, Template: $scope.ReservationAdd.Template, IsActive: $scope.ReservationAdd.IsActive, SenderName: $scope.ReservationAdd.SenderName, CC: $scope.ReservationAdd.CC, Subject: $scope.ReservationAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 1, ActionTypeId: 2, Template: $scope.ReservationEdit.Template, IsActive: $scope.ReservationEdit.IsActive, SenderName: $scope.ReservationEdit.SenderName, CC: $scope.ReservationEdit.CC, Subject: $scope.ReservationEdit.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 1, ActionTypeId: 3, Template: $scope.ReservationCancel.Template, IsActive: $scope.ReservationCancel.IsActive, SenderName: $scope.ReservationCancel.SenderName, CC: $scope.ReservationCancel.CC, Subject: $scope.ReservationCancel.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 2, ActionTypeId: 1, Template: $scope.CheckINAdd.Template, IsActive: $scope.CheckINAdd.IsActive, SenderName: $scope.CheckINAdd.SenderName, CC: $scope.CheckINAdd.CC, Subject: $scope.CheckINAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 3, ActionTypeId: 1, Template: $scope.CheckOUTAdd.Template, IsActive: $scope.CheckOUTAdd.IsActive, SenderName: $scope.CheckOUTAdd.SenderName, CC: $scope.CheckOUTAdd.CC, Subject: $scope.CheckOUTAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 4, ActionTypeId: 1, Template: $scope.PurchaseOrderAdd.Template, IsActive: $scope.PurchaseOrderAdd.IsActive, SenderName: $scope.PurchaseOrderAdd.SenderName, CC: $scope.PurchaseOrderAdd.CC, Subject: $scope.PurchaseOrderAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 5, ActionTypeId: 1, Template: $scope.CashieringAdd.Template, IsActive: $scope.CashieringAdd.IsActive, SenderName: $scope.CashieringAdd.SenderName, CC: $scope.CashieringAdd.CC, Subject: $scope.CashieringAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 6, ActionTypeId: 1, Template: $scope.SendLinkAdd.Template, IsActive: $scope.SendLinkAdd.IsActive, SenderName: $scope.SendLinkAdd.SenderName, CC: $scope.SendLinkAdd.CC, Subject: $scope.SendLinkAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 16, ActionTypeId: 1, Template: $scope.BirthdayAdd.Template, IsActive: $scope.BirthdayAdd.IsActive, SenderName: $scope.BirthdayAdd.SenderName, CC: $scope.BirthdayAdd.CC, Subject: $scope.BirthdayAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 17, ActionTypeId: 1, Template: $scope.AnniversaryAdd.Template, IsActive: $scope.AnniversaryAdd.IsActive, SenderName: $scope.AnniversaryAdd.SenderName, CC: $scope.AnniversaryAdd.CC, Subject: $scope.AnniversaryAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 18, ActionTypeId: 1, Template: $scope.PromotionalAdd.Template, IsActive: $scope.PromotionalAdd.IsActive, SenderName: $scope.PromotionalAdd.SenderName, CC: $scope.PromotionalAdd.CC, Subject: $scope.PromotionalAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 19, ActionTypeId: 1, Template: $scope.ReservationBookingEngineAdd.Template, IsActive: $scope.ReservationBookingEngineAdd.IsActive, SenderName: $scope.ReservationBookingEngineAdd.SenderName, CC: $scope.ReservationBookingEngineAdd.CC, Subject: $scope.ReservationBookingEngineAdd.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 21, ActionTypeId: 1, Template: $scope.ReservationGuestPickupDrop.Template, IsActive: $scope.ReservationGuestPickupDrop.IsActive, SenderName: $scope.ReservationGuestPickupDrop.SenderName, CC: $scope.ReservationGuestPickupDrop.CC, Subject: $scope.ReservationGuestPickupDrop.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 22, ActionTypeId: 1, Template: $scope.TentativeBooking.Template, IsActive: $scope.TentativeBooking.IsActive, SenderName: $scope.TentativeBooking.SenderName, CC: $scope.TentativeBooking.CC, Subject: $scope.TentativeBooking.Subject });
                $scope.Model.EMailTemplates.push({ SMSTemplateTypeId: 23, ActionTypeId: 1, Template: $scope.PreArrival.Template, IsActive: $scope.PreArrival.IsActive, SenderName: $scope.PreArrival.SenderName, CC: $scope.PreArrival.CC, Subject: $scope.PreArrival.Subject });

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                $scope.Model.ModifiedDate = $scope.ModifiedDate;

                var status = service.save($scope.Model);
                status.then(function (result) {
                    if (result.Status == true) {

                        GetAllByPropertyId();
                        msg("EMail Template " + result.Message, true);

                    }
                },
                function (error) {
                    scrollPageOnTop();
                    msg(error.Message);
                });
            }
            else {
                $scope.ShowErrorMessage = true;
            }
        }

        $scope.SaveNew = function (form, templateTypeName, actionType) {
            $scope.Model.EMailTemplates = [];

            if ($scope[form].$valid) {
                var ActionTypeId = 0;
                var SMSTemplateTypeId = 0;
                if (actionType == 'Add') {
                    ActionTypeId = 1;
                }
                if (templateTypeName == 'CheckIN')
                {
                    $scope.Model = { SMSTemplateTypeId: 2, ActionTypeId: 1, Template: $scope.CheckINAdd.Template, IsActive: $scope.CheckINAdd.IsActive, SenderName: $scope.CheckINAdd.SenderName, CC: $scope.CheckINAdd.CC, Subject: $scope.CheckINAdd.Subject };
                }
                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                $scope.Model.ModifiedDate = $scope.ModifiedDate;
                var status = service.save($scope.Model);
                status.then(function (result) {
                    if (result.Status == true) {
                        GetAllByPropertyId();
                        msg("EMail Template " + result.Message, true);
                    }
                },
                function (error) {
                    scrollPageOnTop();
                    msg(error.Message);
                });
            }
            else {
                $scope.ShowErrorMessage = true;
            }
        }
        $scope.InsertField = function (cntr, value) {

            if (cntr == 'txtReservationAdd') {
                $scope.ReservationAdd.Template += value;
            }
            if (cntr == 'txtReservationEdit') {
                $scope.ReservationEdit.Template += value;
            }
            if (cntr == 'txtReservationCancel') {
                $scope.ReservationCancel.Template += value;
            }
            if (cntr == 'txtBirthdayAdd') {
                $scope.BirthdayAdd.Template += value;
            }
            if (cntr == 'txtBirthdayAdd') {
                $scope.BirthdayAdd.Template += value;
            }
            if (cntr == 'txtAnniversaryAdd') {
                $scope.AnniversaryAdd.Template += value;
            }
            if (cntr == 'txtPromotionalAdd') {
                $scope.PromotionalAdd.Template += value;
            }
            if (cntr == 'txtSendLinkAdd') {
                $scope.SendLinkAdd.Template += value;
            }
            if (cntr == 'txtReservationBookingEngineAdd') {
                $scope.ReservationBookingEngineAdd.Template += value;
            }
            if (cntr == 'txtCheckINAdd') {
                $scope.CheckINAdd.Template += value;
            }
            if (cntr == 'txtCheckOUTAdd') {
                $scope.CheckOUTAdd.Template += value;
            }
            if (cntr == 'txtReservationGuestPickupDrop') {
                $scope.ReservationGuestPickupDrop.Template += value;
            }
            if (cntr == 'txtTentativeBooking') {
                $scope.TentativeBooking.Template += value;
            }
            if (cntr == 'txtPreArrival') {
                $scope.PreArrival.Template += value;
            }
            //txtCheckINAdd

        }

    }
]);
