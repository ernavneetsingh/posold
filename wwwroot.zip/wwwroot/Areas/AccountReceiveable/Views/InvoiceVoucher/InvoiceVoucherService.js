﻿
app.service("invoiceVoucherService", function ($http, $q) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.get = function (invoiceId, propertyId, dateFormat) {

        var param = JSON.stringify({ "invoiceId": invoiceId, "propertyId": propertyId, "dateFormat": dateFormat });
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Invoice/Get/" + invoiceId + "/" + propertyId + "/" + dateFormat,
            //data: param,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {

            msg("Error!\n" + err.Message);
            deferred.reject(err, status);
        });
        return deferred.promise;

    };
    this.getInvoice = function (invoiceId, propertyId, dateFormat, corporateId) {
        var param = JSON.stringify({ "invoiceId": invoiceId, "propertyId": propertyId, "dateFormat": dateFormat });
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Invoice/all/" + invoiceId + "/" + propertyId + "/" + dateFormat + "/" + corporateId,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {

            msg("Error!\n" + err.Message);
            deferred.reject(err, status);
        });
        return deferred.promise;

    };
    this.suggest = function (propertyId, txt, corporateId) {
        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "AccountReceiveable/Invoice/suggest/" + propertyId + "/" + txt + "/" + corporateId,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    this.save = function (billDetail, propertyId, user, invoiceDate) {
        var param = { BillDetails: billDetail, PropertyId: propertyId, ModifiedBy: user, InvoiceDate: invoiceDate };
        return httpPoster(apiPath + "AccountReceiveable/Invoice/Save", $http, $q, param);
        //var deferred = $q.defer();
        //$http.post(
        //     path + "AccountReceiveable/Invoice/Save"
        //     , param
        //).success(function (data, status, headers, cfg) {
        //    deferred.resolve(data);
        //}).error(function (err, status) {
        //    msg(err.Message);
        //    deferred.reject(err, status);
        //});

        //var jsonData = angular.toJson(billDetail);
        //var objectToSerialize = { 'model': jsonData };
        //var deferred = $q.defer();
        //$http({
        //    dataType: 'json',
        //    method: 'POST',
        //    url: apiPath + "AccountReceiveable/Invoice/Save",
        //    data:param,// JSON.stringify(billDetail),
        //    headers: {
        //        "Content-Type": "application/json"
        //    }
        //}).success(function (data, status, headers, cfg) {
        //    deferred.resolve(data);
        //}).error(function (data, status, headers, config) {
        //    
        //    msg(data.Message);
        //    deferred.reject(data, status, headers, config);
        //});
        //return deferred.promise;

        //$http({
        //    method: "POST",
        //    url: apiPath + "AccountReceiveable/Invoice/Save/" + propertyId + "/" + user,
        //    dataType: 'json',
        //    data: param,
        //    //data: $.param(objectToSerialize),
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8"
        //}).success(function (data, status, headers, cfg) {
        //    
        //    deferred.resolve(data);
        //}).error(function (err, status) {
        //    
        //    deferred.reject(err, status);
        //});
        //return deferred.promise;

        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "AccountReceiveable/Invoice/Save/" + propertyId + "/" + user,
        //    data: JSON.stringify(billDetail),
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };
    this.delete = function (id, propertyId) {

        var deferred = $q.defer();
        //var param = JSON.stringify({ "id": id, "propertyId": propertyId, "user": user });
        $http({
            method: "POST",
            url: apiPath + "AccountReceiveable/Invoice/Delete/" + id + "/" + propertyId,
            //data: param,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {

            deferred.reject(err, status);
            msg(err.Message);
        });
        return deferred.promise;
    };
    this.MapReport = function (filterValue, reportName) {
        return httpCallerX(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
    };

});
