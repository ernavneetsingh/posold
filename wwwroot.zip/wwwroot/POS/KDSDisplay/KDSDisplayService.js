﻿(function () {

    function service($http, $q) {

        var moduleId = 3;

        var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';

        var GetAllOutlet = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/Outlet/allByPropertyIdmin/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var GetAllOrderUPByOutletId = function (outletId, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/ODS/GetAllOrderUPByOutletId/" + outletId + "/" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        
        var GetAllPendingKOT = function (outletId, businessDate) {
            var deferred = $q.defer();
            $http.get(apiPath + "PointOfSale/ODS/GetAllPendingKOTByOutletId/" + outletId + "/" + businessDate)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        return {
            GetAllOutlet:GetAllOutlet,
            GetAllOrderUPByOutletId: GetAllOrderUPByOutletId,
            GetAllPendingKOT: GetAllPendingKOT,
        };
    }
    apppos.factory("service", ["$http", "$q", service]);

})();
