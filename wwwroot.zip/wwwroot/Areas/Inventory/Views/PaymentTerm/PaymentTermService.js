﻿
app.service('PaymentTermService', ['$http', '$q', function ($http, $q) {

    this.save = function (model) {
        return httpPoster(apiPath + "Inventory/PaymentTerm/Save", $http, $q, model);
    };

    this.getAllPaymentTerms = function (propertyId) {
        return httpCaller(apiPath + "Inventory/PaymentTerm/GetAll", $http, $q, { propertyId: propertyId, active: 2 });
    };
    this.changeStatus = function (model) {
        return httpPoster(apiPath + "Inventory/PaymentTerm/changeStatus", $http, $q, model);
    };
    this.isCodeExist = function (propertyId, code) {
        return httpCaller(apiPath + "Inventory/PaymentTerm/IsCodeExist", $http, $q, { propertyId: propertyId, code: code });
    };

}]);
