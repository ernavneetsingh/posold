﻿'use strict';

(function () {

    function employeeService($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getAll = function (propertyId, active) {
            var params = { propertyId: propertyId, active: active };
            return httpCaller(apiPath + "GlobalSetting/Employee/AllActive", $http, $q, params);
        };

        var getData = function (propertyId) {

            var url = apiPath + 'GlobalSetting/Employee/all/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getAllProperty = function (model) {

            var url = apiPath + 'configuration/User/GetByUserName';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Data.Properties);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {

            var url = apiPath + 'GlobalSetting/Employee/Save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {

            var url = apiPath + 'GlobalSetting/Employee/ChangeStatus';

            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var getAllCountry = function () {

            var url = apiPath + 'referencedata/country';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        };

        var GetDesignation = function (propertyId) {

            var url = apiPath + 'GlobalSetting/designation/all/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getAllState(id) {

            var url = apiPath + 'referencedata/state/' + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data) {

                deferred.resolve(data);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;
        }

        var getAllRole = function (propertyId) {

            var url = apiPath + 'AdminConfiguration/Role/allByPropertyId/' + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };

        return {
            getAll: getAll,
            getAllProperty: getAllProperty,
            getData: getData,
            save: save,
            statusChange: statusChange,
            getAllCountry: getAllCountry,
            GetDesignation: GetDesignation,
            getAllState: getAllState,
            getAllRole: getAllRole
        };
    }

    app.factory('employeeService', ['$http', '$q', employeeService]);
})();
