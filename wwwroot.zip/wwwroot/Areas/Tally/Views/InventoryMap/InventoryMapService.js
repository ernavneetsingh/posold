﻿
app.service('InventoryMapService', [
    '$http', '$q', function ($http, $q) {
        this.getStore = function (propertyId) {
            return httpCaller(apiPath + "Inventory/Store/AllByPropertyIdMin/" + propertyId, $http, $q);
        };
        this.getInventoryMap = function (storeId) {
            return httpCaller(apiPath + "Tally/InventoryMap/GetStore/" + storeId, $http, $q);
        };
        this.getAccountDump = function (propertyId) {
            return httpCaller(apiPath + "Tally/AccountDump/GetAll?propertyId=" + propertyId, $http, $q);
        };
        this.save = function (model) {
            return httpPoster(apiPath + "Tally/InventoryMap/Save", $http, $q, model);
        };
    }
]);
