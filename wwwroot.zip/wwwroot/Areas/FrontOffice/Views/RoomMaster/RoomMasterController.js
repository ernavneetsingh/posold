﻿
app.controller("RoomMasterController",
[
    "$scope", "RoomMasterService", "localStorageService", "$cookies", "$filter", function ($scope, roomMasterService, localStorageService, $cookies, $filter) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.ActionMode = "";
        $scope.IsReadonly = false;
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            ApplicableFrom: '',
            RoomTypeId: '',
            RoomTypeName: '',
            RoomNumber: '',
            Description: '',
            Prefix: '',
            MaxPerson: '',
            OppositeRoomId: '',
            OppositeRoomNumber: '',
            FloorId: '',
            FloorName: '',
            BlockId: '',
            BlockName: '',
            IsRange: '',
            IsExtraBed: '',
            IsMiniBar: '',
            IsRangeFrom: '',
            IsRangeTill: '',

            IsActive: true,
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            RoomFeatures: [],
        };

        $scope.RoomFeatures = [];
        $scope.RoomTypes = [];
        $scope.Blocks = [];
        $scope.Floors = [];

        $scope.bsId = "";
        $scope.Name = "";
        $scope.Description = "";
        $scope.Code = "";
        $scope.IsActive = true;
        $scope.roomMasterModel = {};
        $scope.roomMasterData = [];
        $scope.roomMasterDetails = [];
        $scope.Save = "Save";


        var sortKeyOrder = {
            key: "RoomNumber",
            order: "ASC"
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }
        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        getData($scope, roomMasterService, localStorageService);
        $scope.sort = function (col) {
            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData($scope, roomMasterService, localStorageService);
        };
        $scope.pageChanged = function () {
            getData($scope, roomMasterService, localStorageService);
        };
        $scope.search = function (searchfor) {

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData($scope, roomMasterService, localStorageService);
        };
        $scope.recordsonpage = function (records) {

            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData($scope, roomMasterService, localStorageService);
        }


        $scope.RoomFeaturesList = [];
        $scope.SelectedRooms = [];

        $scope.RoomFeatureSettings = {
            width:'400px',
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true,
            displayProp: 'Name'
        };
        $scope.RoomSettings = {
            width: '400px',
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true,
            displayProp: 'Name'
        };

        getPageSetup();
        function getPageSetup() {

            var promiseGet1 = roomMasterService.getroomtypseData($scope.PropertyID);
            promiseGet1.then(function (data, status) {
                $scope.RoomTypes = data.Collection;
            }, function (error, status) {
                msg(error.Message);
            });

            var promiseGet2 = roomMasterService.getroomFeatureData($scope.PropertyID);
            promiseGet2.then(function (data, status) {
                $scope.RoomFeatures = data.Collection;
                //$scope.RoomFeatureSettings = [];
            },
            function (error, status) {
                msg(error.Message);
            });

            var promiseGet3 = roomMasterService.getblockData($scope.PropertyID);
            promiseGet3.then(function (data, status) {
                $scope.Blocks = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });

            var promiseGet4 = roomMasterService.getfloorData($scope.PropertyID);
            promiseGet4.then(function (data, status) {
                $scope.Floors = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });

            var promiseGet5 = roomMasterService.GetAllMinByPropertyId($scope.PropertyID);
            promiseGet5.then(function (data, status) {
                $scope.Rooms = data.Collection;
            },
            function (error, status) {
                msg(error.Message);
            });
        };

        $scope.isExist = function () {

            var promiseGet = roomMasterService.getCodeExistRoomMaster($scope.RoomNumber, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    if (!$scope.IsReadonly) {
                        msg(data.Message);
                        $scope.RoomNumber = "";
                    }
                    return;
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.isExistRooms = function (rooms) {

            if ($scope.isRangeFrom != undefined) {
                msg("Please enter From range");
                return;
            }
            if ($scope.isRangeTo != undefined) {
                msg("Please enter To range");
                return;
            }
            if (parseInt($scope.isRangeFrom) >= parseInt($scope.isRangeTo)) {
                msg("Room range From could not less from Till ");
                return;
            }
            if (parseInt($scope.isRangeTo) <= parseInt($scope.isRangeFrom)) {
                msg("Room range Till could not less From  ");
                return;
            }
            var totalRooms;
            if ($("#chbrange").prop("checked")) {
                totalRooms = (parseInt($scope.isRangeFrom) - parseInt($scope.isRangeTo));
            } else {
                totalRooms = rooms;
            }

            var promiseGet = roomMasterService.getExistRoomMaster(totalRooms, $scope.PropertyID);
            promiseGet.then(function (data, status) {

                if (data.Status) {
                    msg(data.Message);
                    return;
                } else {
                    if ($("#chbrange").prop("checked")) {
                        msg(data.Message);
                        $scope.isRangeFrom = "";
                        $scope.isRangeTo = "";
                    } else {
                        $scope.roomNumber = "";
                    }
                }
            },
            function (error, status) {
                msg(error.Message);
            });
        };
        $scope.reset = function () {
            $scope.ActionMode = "";
            $scope.Model = {};
            $scope.Model.IsActive = true;
            $scope.RoomFeaturesList = [];
            $scope.SelectedRooms = [];
            $scope.IschkPrefix = false;
            $scope.IschkRange = false;
            $scope.IsReadonly = false;

            if ($scope.Save !== "Save") {
                $scope.Save = "Save";
            }
            $scope.search();
        };

        $scope.save = function (form) {

            
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            if ($scope.Model.IsRange && $scope.Model.IsRangeFrom > $scope.Model.IsRangeTill) {
                msg('From number should be lower in range.');
                return;
            }
            
            $scope.Model.RoomFeatures = $scope.RoomFeaturesList;
            
            $scope.Model.LinkRooms = [];
            angular.forEach($scope.SelectedRooms, function (item) {
                if ($scope.Model.Id != item.Id)
                {
                    $scope.Model.LinkRooms.push({ RoomMasterId: $scope.Model.Id, LinkRoomMasterId: item.Id });
                }
            });
            //$scope.Model.LinkRooms = $scope.SelectedRooms;

            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.UserName;
            $scope.Model.DateFormat = $scope.DateFormat;

            var promiseGet = roomMasterService.saveRoomMaster($scope.Model);
            promiseGet.then(function (data, status) {
                msg(data.Message, data.Status);
                getData($scope, roomMasterService, localStorageService);
                $scope.reset();
                //if (data.Status) { parent.successMessage(data.Message); }
            }, function (error, status) {
                msg(error.Message);
            });

        };
        $scope.updateRoomData = function (roomMasterModel) {
            if (!$scope.keys.IsEdit) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            roomMasterModel.PropertyID = $scope.PropertyID;
            roomMasterModel.ModifiedBy = $scope.UserName;
            var promiseGet = roomMasterService.updateIsActiveRoomMaster(roomMasterModel);//.Id, roomMasterModel.IsActive, $scope.PropertyID, $scope.UserName);
            promiseGet.then(function (data, status) {

                msg(data.Message, data.Status);
                getData($scope, roomMasterService, localStorageService);
            }, function (error, status) {

                msg(error.Message);
            });
            //scrollPageOnTop();
        };
        $scope.removeRow = function (roomMasterModel) {
            if (!$scope.keys.IsDelete) {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this Room Number?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            var deleteGuestStatus = roomMasterService.deleteRoomMaster(roomMasterModel.Id, $scope.PropertyID);
                            deleteGuestStatus.then(function (d) {
                                msg(d.Message, d.Status);
                                getData($scope, roomMasterService, localStorageService);
                                //parent.successMessage("Record Successfully deleted.");
                            }, function (error) {
                                msg(error.Message);
                            });
                            $.fancybox.close();
                        });
                }
            });
        };

        $scope.IschkPrefix = false;
        $scope.IschkRange = false;
        $scope.fillData = function (record) {
            $scope.ActionMode = "Edit";
            $scope.IschkPrefix = false;
            $scope.IschkRange = false;

            $scope.Model.Id = record.Id;
            $scope.Model.ApplicableFrom = $filter("date")(new Date(record.ApplicableFrom), $scope.DateFormat);
            $scope.Model.RoomTypeId = record.RoomTypeId;
            $scope.Model.RoomNumber = record.RoomNumber;
            $scope.Model.OrderSNo = record.OrderSNo;
            $scope.Model.Description = record.Description;
            $scope.Model.Prefix = record.Prefix;
            $scope.Model.MaxPerson = record.MaxPerson;
            $scope.Model.OppositeRoomId = record.OppositeRoomId;
            $scope.Model.FloorId = record.FloorId;
            $scope.Model.BlockId = record.BlockId;
            //$scope.Model.IsRange = record.IsRange;
            $scope.Model.IsExtraBed = record.IsExtraBed == true ? 'true' : 'false';
            $scope.Model.IsMiniBar = record.IsMiniBar == true ? 'true' : 'false';
            //$scope.Model.IsRangeFrom = record.IsRangeFrom;
            //$scope.Model.IsRangeTill = record.IsRangeTill;
            $scope.Model.IsActive = record.IsActive;

            if ($scope.Model.Prefix != null) {
                if ($scope.Model.Prefix.length > 0) {
                    $scope.IschkPrefix = true;
                }
            }


            //$scope.roomFeatureDetails = record.RoomFeaturesesList;
            //$scope.roomFeatureList = [];
            //$scope.roomFeatureList = $scope.RoomFeatureDetails;
            $scope.RoomFeaturesList = [];
            angular.forEach(record.RoomFeatures, function (h) {
                $scope.RoomFeaturesList.push({ Id: h.Id });
            });

            $scope.SelectedRooms = [];
            angular.forEach(record.LinkRooms, function (h) {
                $scope.SelectedRooms.push({ Id: h.LinkRoomMasterId });
            });

            ////$scope.ModulesListItem = [];
            ////$scope.ModuleLinkSubModule = item;
            ////$scope.ModulesListItem.push({ Id: item.ModuleId });

            $scope.IsReadonly = true;

            $scope.Save = "Update";
            scrollPageOnTop();
        };

       

    }
]);

var getData = function ($scope, dataService, localStorageService) {
    $scope.ActionMode = "";
    $scope.data = dataService.dataAllData;

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "RoomNumber",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor,
        propertyId: $scope.PropertyID
    };

    dataService.getRoomMaster(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
    }, function () {
        msg("The request failed. Unable to connect to the remote server.");
    });

};
