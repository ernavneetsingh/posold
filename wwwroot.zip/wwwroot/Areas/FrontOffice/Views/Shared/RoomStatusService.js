﻿
app.service('roomStatusService', [
    "$http", "$q", "$cookies", "$filter", function (
        $http, $q, $cookies, $filter) {

        this.init = function ($scope) {

            $scope.ModifiedBy = $cookies.get('UserName');

            var curdate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day)
            $scope.CurDate = curdate.getFullYear() + '-' + ('0' + (curdate.getMonth() + 1)).slice(-2) + '-' + ('0' + curdate.getDate()).slice(-2);

            $scope.searchw = {};
            $scope.searchw.RoomFeatures = [];
            $scope.searchw.Floors = [];
            $scope.searchw.Blocks = [];
            $scope.searchw.RoomStatuss = [];
            $scope.searchw.Year = curdate.getFullYear().toString();
            $scope.SearchwSettings = {
                scrollableHeight: '300px',
                scrollable: true,
                enableSearch: true,
                displayProp: 'Name'
            };

            var getRoomStatusList = function () {
                return httpCaller(apiPath + "referenceconstant/RoomStatusType/all", $http, $q);
            };
            var getRoomFeatureList = function (propertyId) {
                return httpCaller(apiPath + "FrontOffice/roomfeatures/details", $http, $q, { propertyId: propertyId });
            };
            var getFloorList = function (propertyId) {
                return httpCaller(apiPath + "FrontOffice/Floor/allByPropertyId", $http, $q, { propertyId: propertyId });
            };
            var getBlockList = function (propertyId) {
                return httpCaller(apiPath + "FrontOffice/Block/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
            };

            var getDates = function (propertyId, date, period) {
                return httpCaller(apiPath + "FrontOffice/Reservation/GetDates", $http, $q, { propertyId: propertyId, date: date, period: period, min: true });
            };
            var getRoomTypeStatus = function (propertyId, date1, date2) {
                return httpPoster(apiPath + "FrontOffice/QuickReservation/allStatusByPropertyId", $http, $q, { PropertyID: propertyId, FromDate: date1, ToDate: date2 });
            };
            var getRoomList = function (propertyId, roomTypeId, featureId, floorId, blockId, roomStatusId, statusDate) {
                return httpCaller(apiPath + "FrontOffice/RoomMaster/Search", $http, $q, { propertyId: propertyId, roomTypeId: roomTypeId, featureId: featureId || 'All', floorId: floorId || 'All', blockId: blockId || 'All', roomStatusId: roomStatusId || 'All', statusDate: statusDate });
            };

            $scope.getRoomStatusList = function () {
                getRoomStatusList($scope.PropertyID).then(function (result) {

                    $scope.RoomStatusList = result.Collection;
                }, function (err) { msg(err.Message); });
            };
            $scope.getRoomFeatureList = function () {
                getRoomFeatureList($scope.PropertyID).then(function (result) { $scope.RoomFeatureList = result.Collection; }, function (err) { msg(err.Message); });
            };
            $scope.getFloorList = function () {
                getFloorList($scope.PropertyID).then(function (result) { $scope.FloorList = result.Collection; }, function (err) { msg(err.Message); });
            };
            $scope.getBlockList = function () {
                getBlockList($scope.PropertyID).then(function (result) { $scope.BlockList = result.Collection; }, function (err) { msg(err.Message); });
            };

            $scope.searchStatus = function () {

                var featureId = "";
                angular.forEach($scope.searchw.RoomFeatures, function (feature) { featureId += feature.Id + ","; });
                var floorId = "";
                angular.forEach($scope.searchw.Floors, function (floor) { floorId += floor.Id + ","; });
                var blockId = "";
                angular.forEach($scope.searchw.Blocks, function (block) { blockId += block.Id + ","; });
                var roomStatusId = "'";
                angular.forEach($scope.searchw.RoomStatuss, function (roomStatus) { roomStatusId += roomStatus.Id + "','"; });
                roomStatusId = roomStatusId.substr(0, roomStatusId.length - 1);

                getRoomList($scope.PropertyID, "All", featureId, floorId, blockId, roomStatusId, curdate)
                         .then(function (result) {


                             $scope.RoomTypeList = $filter('groupBy')(result.Collection, 'RoomTypeName', 'RoomTypeId');
                             $scope.putRoomTypeStatus();
                         }, function (err) {
                             msg(err.Message);
                         });
            };
            function onItemSelect(property) {
                $scope.searchStatus();
            }
            $scope.myEventListeners = {
                onItemSelect: onItemSelect,
                onItemDeselect: onItemSelect,
                onSelectAll: onItemSelect,
                onDeselectAll: onItemSelect
            };
            $scope.colspan = 5;
            $scope.getColsSpan = function (rd) {
                //rd.GuestName
                if ($scope.colspan > 0) $scope.colspan--;
                return $scope.colspan;
                //parseInt(header.text.split(' ').pop());
            };

            $scope.changeYear = function (year) {
                getDates($scope.PropertyID, new Date(year, 1, 1), 2)
                     .then(function (result) {
                         $scope.MonthList = result.Collection;
                         var objMonth = new Object();
                         objMonth.Date = $scope.MinDate;
                         $scope.changeMonth(objMonth);
                     }, function (err) {
                         msg(err.Message);
                     });
            };
            $scope.changeMonth = function (d) {
                var d1;
                angular.forEach($scope.MonthList, function (m) {
                    m.IsSelected = false;
                    var a1 = parseInt(m.Date.split('-')[1]);
                    var a2 = parseInt(d.Date.split('-')[1]);
                    if (a1 === a2) d1 = m;
                });

                d1.IsSelected = true;

                getDates($scope.PropertyID, d1.Date, 3)
                    .then(function (result) {
                        $scope.DayList = result.Collection;
                    }, function (err) {
                        msg(err.Message);
                    });
                getRoomTypeStatus($scope.PropertyID, d1.Date, dateAdd(dateAdd(d1.Date, 'month', 1, $filter), 'day', -1, $filter), $scope.DateFormat)
                     .then(function (result) {

                         $scope.RoomTypeStatus = result.Data.RoomTypeStatus;
                         $scope.putRoomTypeStatus();
                     }, function (err) {

                         msg(err.Message);
                     });
                $scope.searchw.Month = d1;
            };
            $scope.putRoomTypeStatus = function () {

                //if (!$scope.DayList || !$scope.RoomTypeStatus) return;
                if (!$scope.RoomTypeStatus) return;
                angular.forEach($scope.RoomTypeList, function (roomtype) {

                    roomtype.DayList = angular.copy($scope.DayList);
                    angular.forEach(roomtype.items, function (room) {

                        roomtype.RoomTypeId = angular.copy(room.RoomTypeId);
                        room.DayList = angular.copy($scope.DayList);
                        angular.forEach($scope.RoomTypeStatus, function (status) {

                            if (roomtype.group_name == status.RoomTypeName) {
                                roomtype.AvailableRoom = status.AvailableRoom;
                                angular.forEach(status.RoomStatusMins, function (roomstatus) {

                                    if (room.Id == roomstatus.RoomMasterId) {
                                        room.RoomStatuss = roomstatus.RoomStatuss;
                                    }
                                });
                            }
                        });
                    });
                });
            };

            $scope.selectionStart = function () {
                //$scope.log.push(($scope.log.length + 1) + ': selection start!');
            };
            $scope.selectionStop = function (selected) {

                if (selected.length < 1) return;
                $scope.model.ArrivalDate = selected[0].Date;
                $scope.model.DepartureDate = selected.length > 1 ? selected[selected.length - 1].Date : dateAdd($scope.model.ArrivalDate, 'day', 1, $filter);
                if (selected.length - 1 == 0) {
                    $scope.model.Nights = 1;
                } else {
                    $scope.model.Nights = selected.length - 1;
                }
                $scope.model.NumberOfPax = "1";
                $scope.model.NumberOfRooms = "1";
                $scope.model.RoomTypeId = selected[0].RoomTypeId;
                if ($scope.DefaultSettings) {
                    //$scope.model.CheckOUTTimeForDisplay = $scope.DefaultSettings.Checkin_Checkout_Parameter === "12 Hours" ? "12:00" : $scope.model.CheckINTimeForDisplay;
                    $scope.model.BusinessSourceId = $scope.DefaultSettings.BusinessSourceId.toString();
                    $scope.model.CurrencyMasterId = $scope.DefaultSettings.CurrencyMasterId.toString();
                    $scope.model.PaymentModeId = $scope.DefaultSettings.PaymentModeId.toString();
                    $scope.model.MealPlanId = $scope.DefaultSettings.MealPlanId.toString();
                    $scope.model.SalutationId = $scope.DefaultSettings.SalutationId.toString();
                    if (!$scope.model.RoomTypeId) $scope.model.RoomTypeId = $scope.DefaultSettings.RoomTypeId.toString();
                }
                //$scope.log.push(($scope.log.length + 1) + ': items selected: ' + selected.length);
            };
            $scope.openPopup = function () {

                //$scope.showPopup = true;
                $("#modalQR").modal();
            };
            $scope.selectRoom = function (room) {

            };

        };
        this.load = function ($scope) {

            $scope.getRoomStatusList();
            $scope.getRoomFeatureList();
            $scope.getFloorList();
            $scope.getBlockList();

            $scope.searchw.Years = [];
            var yyyy = new Date().getFullYear();
            for (i = 0; i < 5; i++) {
                $scope.searchw.Years.push(yyyy++);
            }
            $scope.changeYear($scope.searchw.Year);
            $scope.searchStatus();
        };

    }
]);
