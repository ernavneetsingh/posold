﻿app.service('LPService', ['$http', '$q', '$filter', LPService]);

app.controller('CheckINController', [
    '$scope', '$filter', '$cookies', 'CheckINService', '$window', 'localStorageService', 'GuestMessageService', 'roomStatusService', 'manuService', 'CreditCardService', '$timeout', 'ImageUploadService', '$rootScope', 'ImageService', 'DocumentViewerService', 'roomChartService','checkINCommonService','LPService',
    function ($scope, $filter, $cookies, checkINService, $window, localStorageService, guestMessageService, roomStatusService, manuService, creditCardService, $timeout, ImageUploadService, $rootScope, imageService, documentViewerService,roomChartService,checkINCommonService,lpService) {
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.FOShiftId = localStorageService.get('FOShiftId'); 
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');

        roomStatusService.init($scope);        //roomStatusService.load($scope);
        $scope.guestMessageService = guestMessageService.init($scope, true);
        creditCardService.init($scope);
        $scope.imageService = imageService;
        $scope.apiPath = apiPath;
        $scope.documentViewerService = documentViewerService.init($scope);
        $scope.lpService = lpService.init($scope);
        
        //var businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        var businessDateStr = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

        $scope.businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        var businessDate = $filter('date')($scope.businessDate, $scope.DateFormat);
        $scope.MinDate = $scope.ModifiedDate;// date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);

        $scope.MinDOB = dateAdd($scope.MinDate, 'year', -120, $filter);
        $scope.MaxDOB = $scope.MinDate;
        $scope.MaxDOA = dateAdd($scope.MinDate, 'year', 1, $filter);
        $scope.MinChequeDate = dateAdd($scope.MinDate, 'month', -3, $filter);

        $scope.AmenitiesSettings = {
            scrollableHeight: '300px',
            scrollable: true,
            enableSearch: true,
            displayProp: 'Name'
        };

        $scope.IsViewPhotograph = false;
        $scope.IsViewPhoto = false;
        $scope.IsViewSignature = false;

        $scope.ViewPhotograph = function () {
            $scope.IsViewPhotograph = true;
            $scope.IsViewPhoto = false;
            $scope.IsViewSignature = false;
        }

        //Camera & Signature
        //------------------------------------------------------------
        $scope.ActiveCamera = [];
        $scope.ActiveSignature = [];

        $scope.ActiveCameraId = 0;
        $scope.redirectToCamera = function (sno) {
            var link = GetCameraLink(sno, 'CheckIN');
            $window.open('http://' + link, '_blank');
        };
        var guest = {};
        function GetCameraLink(sno, opeartion) {
            $scope.ActiveCameraId = makeid();
            $scope.ActiveCamera.push({ Id: $scope.ActiveCameraId });
            var link = Path.replace('http://', '') + 'FO/Operation/Camera?xId=' + $scope.ActiveCameraId + '&propertyId=' + $scope.PropertyID + '&SNo=' + sno + '&operation=' + opeartion
                + '&GuestId=' + guest.GuestId
            return link;
        }

        $scope.ActiveSignatureId = 0;
        $scope.redirectToSignature = function (sno) {
            var link = GetSignatureLink(sno, 'CheckIN');
            $window.open('http://' + link, '_blank');
        };

        function GetSignatureLink(sno, opeartion) {

            $scope.ActiveSignatureId = makeid();
            $scope.ActiveSignature.push({ Id: $scope.ActiveSignatureId });
            var link = Path.replace('http://', '') + 'FO/Operation/Signature?xId=' + $scope.ActiveSignatureId + '&propertyId=' + $scope.PropertyID + '&SNo=' + sno + '&operation=' + opeartion
                + '&GuestId=' + guest.GuestId
            return link;
        }

        function makeid() {
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (var i = 0; i < 25; i++)
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            return text;
        }

        //-----------------------------------------------
        //Progress Bar
        //-----------------------------------------------
        $scope.ManuService = manuService;
        $scope.IsProgress = true;
        $scope.ProgressStart = function () {
            $scope.IsProgress = true;
            $('#body').addClass("disablewholepage");
            $scope.ManuService.setProgress(true);
        }
        $scope.ProgressEnd = function () {
            $scope.IsProgress = false;
            $('#body').removeClass("disablewholepage");
            $scope.ManuService.setProgress(false);
        }
        //-----------------------------------------------

        //TODO Navneet
        $scope.Model = {
            TotalAdvance: 0,
            //ReservationAdvanceAmount:0,
        };
        $scope.IsSaved = true;

        $scope.DiscountTypes = [];
        $scope.TaxStructures = [];
        $scope.Packages = [];
        $scope.Countrys = [];


        $scope.isCheckInTimeEditable = function (showMsg) {
            checkINService.getByModuleSettingName($scope.PropertyID, 'IsCheckInTimeEditable', true)
                .then(function (s) {
                    $scope.IsCheckInTimeEditable = s.Status && s.Data && s.Data.IsActive;
                }, function (e) {
                    if (showMsg) msg(e.Message);
                });
        };
        $scope.isCheckInTimeEditable();

        //--------------------------------------------
        //Get Room Chart
        //--------------------------------------------
        var CalendarLength = 30; //days
        var first;
        var prev = undefined;
        var prevRoomId = undefined;
        var colspan = 1;
        var cellWidth =36;
        var setColspan = function () {
            first.attr('colspan', colspan);
            colspan = 1;
        }

        $scope.IsColMarge = false;

        $scope.MonthColMarge = function () {     
            var allMonth = $('.monthHead');
            allMonth.each(function () {
                var txt = $(this).text();
                if (prevMonth === txt) {
                    colspanMonth += 1;
                    $(this).remove();
                } else {
                    // doesnt match, set colspan on first and reset colspan counter
                    if (colspanMonth > 1) {
                        setMonthColspan();
                    }
                    firstMonth = $(this);
                    prevMonth = txt;
                }
            });
            if (colspanMonth > 1) {
                setMonthColspan();
            }
        };

        $scope.ColMarge1 = function () {

            $scope.IsColMarge = true;
            //.occupied
            var index = 0;
            var all = $('.occupied');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[5] + '-' + txt.split('$')[6]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                //var htmltxt = toolTip;
                $(this).html(htmltxt);
                if (prev=== htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    // doesnt match, set colspan on first and reset colspan counter
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }

            //.management
            index = 0;
            colspan = 1;
            var all = $('.management');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    
                    htmltxt = 'Management Block' + '<br/>' + txt.split('$')[5] + ' - ' + txt.split('$')[6];
                }
                else {
                    htmltxt = txt;
                }
                $(this).html(htmltxt);

                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }

            //.maintenance
            index = 0;
            colspan = 1;
            var all = $('.maintenance');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    //htmltxt = txt.split('$')[0] + '<br/>' + txt.split('$')[5] + ' - ' + txt.split('$')[6];
                    htmltxt = 'Maintenance Block' + '<br/>' + txt.split('$')[5] + ' - ' + txt.split('$')[6];
                }
                else {
                    htmltxt = txt;
                }
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }

            //.block
            index = 0;
            colspan = 1;
            var all = $('.reservationBlock');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[7] +'-'+ txt.split('$')[8] + ' Pax : ' + txt.split('$')[6] + "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }
            //.block
            index = 0;
            colspan = 1;
            var all = $('.reservationRoomTypeBlock');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[7] +'-'+ txt.split('$')[8] + ' Pax : ' + txt.split('$')[6] + "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }


            //.maintenance
            index = 0;
            colspan = 1;
            var all = $('.dayCol');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    //htmltxt = txt;
                    htmltxt = '<div>'+txt.split('$')[0] + '<br />' + txt.split('$')[1] + '</div>';

                    if(parseInt( txt.split('$')[2])>0)
                    {
                        htmltxt = htmltxt + "<div title='Available Room' class='roomAvalibility ready'>"
                                            + txt.split('$')[2] +'</div>';
                    }
                    else if(parseInt( txt.split('$')[2])<=0)
                    {
                        htmltxt = htmltxt + "<div title='Available Room' class='roomAvalibility occupied2'>"
                                            + txt.split('$')[2] +'</div>';
                    }

                }
                else {
                    htmltxt = txt;
                }
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }

            //.ready
            index = 0;
            colspan = 1;
            var all = $('.readywhite');
            all.each(function () {
                index++;
                var htmltxt = '';
                $(this).html(htmltxt);
            });

            //.ready
            index = 0;
            colspan = 1;
            var all = $('.ready');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = txt.split('$')[1];
                $(this).html(htmltxt);
            });

            //.dirty
            index = 0;
            colspan = 1;
            var all = $('.dirty');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = txt.split('$')[1];
                $(this).html(htmltxt);
            });

            //.ready
            index = 0;
            colspan = 1;
            var all = $('.dirtywhite');
            all.each(function () {
                index++;
                var htmltxt = '';
                $(this).html(htmltxt);
            });

            //.clean
            index = 0;
            colspan = 1;
            var all = $('.clean');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = txt.split('$')[1];
                $(this).html(htmltxt);
            });

            //.checkout
            index = 0;
            colspan = 1;
            var all = $('.checkout');
            all.each(function () {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[5] + '-' + txt.split('$')[6]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).remove();
                } else {
                    if (colspan > 1) {
                        setColspan();
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            if (colspan > 1) {
                setColspan();
            }
        };

        var firstMonth;
        var prevMonth = undefined;
        var colspanMonth = 1;
        $scope.Reset = function () {
            var firstMonth;
            var prevMonth = undefined;
            var colspanMonth = 1;
        };
        var setMonthColspan = function () {
            firstMonth.attr('colspan', colspanMonth);
            colspanMonth = 1;
        }

        $scope.IsShowLoader=false;
        $scope.ShowLoader = function () {
            $scope.IsShowLoader=false;

            $('#roomChart').hide('slow');
            
        }

        $scope.HideLoader = function () {
            if ($('#roomChart').css('display') == 'none') {
                $('#roomChart').show('slow');
                $('#loader').hide('slow');
                $scope.IsShowLoader=false;
            }
        }


        //--------------------------------------------
        //-----------------GetRoomChart---------------
        //--------------------------------------------

        $scope.RoomTypes = [];
        $scope.Rooms = [];
        $scope.GetRoomType = function(){
            $scope.IsShowLoader=true;   
            var promiseGet = roomChartService.GetRoomChartRoomType($scope.PropertyID);
            promiseGet.then(function (data, status) {
                $scope.RoomTypes = data.Data[0];
                $scope.Rooms = data.Data[1];
                $scope.GetCalendar();
                angular.forEach($scope.RoomTypes,function(item){
                    $scope.GetRoomTypeRates(item.Id);
                });
            },
            function (error, status) {
            });
        }

        $scope.GetCalendar = function(){
         
            
            $scope.date.endDate = GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(1, 'days'), $scope.DateFormat)

            $scope.RoomChart = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate: GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
            
            var fromDate = GetMomentDate($filter('date')($scope.RoomChart.FromDate, $scope.DateFormat), $scope.DateFormat);
            var toDate = GetMomentDate($filter('date')($scope.RoomChart.ToDate, $scope.DateFormat), $scope.DateFormat);
            var id=1;
            for (var m = moment(fromDate) ; m.isBefore(toDate) ; m.add(1, 'days')) {
                var date = m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD');
                var day ={
                    Id : id,
                    FutureDate :date,
                    Day : m.format('DD'),
                    DayName : m.format("ddd"),
                    DayCol:m.format('DD') +'$' + m.format("ddd"),
                    Month : m.format('MM'),
                    MonthName : m.format("MMM"),
                    Year : m.format('YYYY'),
                    IsWeekEnd : m.format("ddd") == 'Sun' ? true : m.format("ddd") == 'Sat' ? true : false,
                    IsBusinessDate :GetMomentDate(date,'YYYY-MM-DD').isSame(GetMomentDate($scope.MinDate ,'YYYY-MM-DD')) ? true : false,
                };
                $scope.RoomChart.Days.push(day);
                id++;
            }
            angular.forEach($scope.RoomChart.Days,function(day,index){

                //Rooms
                var i=0;
                angular.forEach($scope.Rooms,function(room,key){
                    
                    if(!room.Days)
                    {
                        room.Days=[];
                    }
                    //AM
                    i = ++i;

                    room.Days.push({
                        Id : i,
                        DayPart : 'AM',
                        Day : day,
                        RoomStatusTypeId : '1',
                        IsSelected :false,

                    });

                    //PM
                    i = ++i;
                    room.Days.push({
                        Id : i,
                        DayPart : 'PM',
                        Day : day,
                        RoomStatusTypeId : '1',
                        IsSelected :false,

                    });
                }); 

               
            }); 
            angular.forEach($scope.RoomTypes,function(roomType){
                roomType.Rooms = $scope.Rooms.filter(x=>x.RoomTypeId == roomType.Id);
                i=0;
                angular.forEach($scope.RoomChart.Days,function(day,index){
                    if(!roomType.Availabilitys)
                    {
                        roomType.Availabilitys=[];
                    }
                    i = ++i;
                    roomType.Availabilitys.push({
                        Id : i,
                        Day : day,
                        
                        AvailabilityCount:0,
                        ManagementBlockCount:0,
                        MaintenanceBlockCount :0,
                        ReservationBlockCount:0,
                        OccupiedCount:0,
                        TotalDayReservation :0,
                        IsSelected:false,
                    });

                    roomType.IsRoomType = true;
                    roomType.IsStickyDayName = false;
                    
                }); 
            });
            $scope.RoomChart.RoomTypes = $scope.RoomTypes;
            $scope.GetRoomChartCheckINGuestRoom();
        }

        $scope.GetRoomChart = function () {
            $scope.ShowLoader();
            $scope.GetRoomType();
            scrollPageOnTop();
        };

        $scope.GetReservationRoomType = function(){
            
            $scope.SearchModel = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate:  GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'),$scope.DateFormat) , //GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
                
            var promiseGet = roomChartService.GetRoomChartReservationRoomType($scope.SearchModel);
            promiseGet.then(function (data, status) {
                var reservationRoomTypes = data.Data;
                angular.forEach(reservationRoomTypes,function(reservationRoomType){
                    $scope.UpdateRoomChartReservation(reservationRoomType);
                });    
                $scope.UpdateRoomChartAvailability();
            },
            function (error, status) {
            });
        }

        $scope.UpdateRoomChartReservation = function(reservationRoomType)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            
            var roomType = roomChart.RoomTypes.find(x=>x.Id ==reservationRoomType.RoomTypeId);
            
            if(reservationRoomType.RoomMasterId)
            {
                var arrivalDate = GetMomentDate($filter('date')(reservationRoomType.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(reservationRoomType.DepartureDate, $scope.DateFormat), $scope.DateFormat);
                var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat);
                var emptyRoomDays=[];
                var roomCopy={};
                angular.forEach(roomType.Rooms,function(room){
                    if(reservationRoomType.RoomMasterId == room.Id)
                    {
                        roomCopy = angular.copy(room);
                        var nights = departureDate.diff(arrivalDate, 'days');
                        var startDay=0;
                        var endDay=nights;
                        var i=0;
                        var isEmpty=true;
                        var firstDate =  moment(room.Days[0].Day.FutureDate);

                        for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                            var futureDate = ConvertDateToServerDate(m);
                                    
                            if(m.isBefore(endDate))
                            {
                                var futureDate = ConvertDateToServerDate(m);
                                    
                                if(!m.isBefore(firstDate))
                                {
                                    //skip Start Day AM
                                    if(!m.isSame(arrivalDate))
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                        //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        if(emptyRoomDays.length==0)
                                        {
                                            isEmpty=false;
                                        }
                                    }
                                    //skip Start Day PM
                                    if(!m.isSame(departureDate))
                                    {
                                        if(arrivalDate.isBefore(firstDate))
                                        {
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        else
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                    }    
                                }
                            }


                        }
                        if(isEmpty)
                        {
                            //Set ReservationStatus
                            for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                if(i==startDay)
                                {
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];
                                        //roomDay.BookingTypeId= data[10];
                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                        //currentroomstatus set bussiness 
                                    });
                                }
                                else if(i==endDay)
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                                
                                        //currentroomstatus set bussiness 

                                    });
                                }
                                else
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                    });
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                    });
                                }

                                i++;
                            }
                        }
                    }
                });
            }
            else
            {
                var reservationRoomTypeCopy = angular.copy(reservationRoomType);                    

                var arrivalDate = GetMomentDate($filter('date')(reservationRoomTypeCopy.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(reservationRoomTypeCopy.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                var emptyRoomDays=[];
                var IsRoomSet = false;
                var roomCopy={};
                angular.forEach(roomType.Rooms,function(room){
                            
                    roomCopy = angular.copy(room);
                            
                    var test = roomCopy.Name;

                    if(reservationRoomTypeCopy.RoomTypeId)
                    {
                        if(!IsRoomSet)
                        {
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;

                            var isEmpty=true;
                                    
                            //var firstDate =  moment(room.Days[0].Day.FutureDate);
                            var firstDate = GetMomentDate($scope.date.startDate, $scope.DateFormat);
                            var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days');

                            for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                        
                                if(m.isBefore(endDate))
                                {
                                    //skip Start Day AM
                                    if(!m.isSame(arrivalDate))
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        if(emptyRoomDays.length==0)
                                        {
                                            isEmpty=false;
                                        }
                                    }

                                    //skip Start Day PM
                                    if(!m.isSame(departureDate))
                                    {
                                        var firstDate =  moment(room.Days[0].Day.FutureDate);
                                        if(arrivalDate.isBefore(firstDate))
                                        {
													
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        else
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
												
                                    }    
                                }	
                            }
                            if(isEmpty)
                            {
                                        
                                //Set ReservationStatus
                                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    
                                    if(i==startDay)
                                    {
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                        });
                                    }
                                    else if(i==endDay)
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                        });
                                    }
                                    else
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                        });
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                        });
                                    }
                                    i++;
                                }
                                IsRoomSet=true;
                                //reservationRoomTypeCopy={};
                            }
                        }
                    }

                });

                if(!IsRoomSet)
                {
                            
                    var nights = departureDate.diff(arrivalDate, 'days');
                    var startDay=0;
                    var endDay=nights;
                    var i=0;
                    var isEmpty=true;
                    var max = Math.max.apply(Math,roomType.Rooms.map(function(item){return item.OrderSNo;}));

                    roomCopy.Id ='OB';
                    roomCopy.Name ='OB';
                    roomCopy.OrderSNo =max +1;
                    roomCopy.MaxPerson ='';
                    roomCopy.CurrentRoomStatus ='';
                    roomCopy.CurrentRoomStatusId ='1';
                    angular.forEach(roomCopy.Days,function(roomDay){
                        roomDay.RoomId = 'OB';
                        roomDay.Name= 'Over Booking';
                        roomDay.OccupiedStatusId='1';
                        roomDay.IsCheckOUTToday=false;
                        roomDay.Content = '';
                        roomDay.RoomStatusTypeId = '1';
                        roomDay.ReservationRoomTypeId = '';
                        roomDay.ReservationId = '';
                        roomDay.GuestName = '';
                        roomDay.FromDateStr = '';
                        roomDay.ToDateStr= '';
                        roomDay.Nights= 0;
                        roomDay.BookingTypeId= '1';
                        roomDay.CheckINGuestRoomId = '';
                        roomDay.CheckINId = '';
                    });
                          
                    //Set ReservationStatus
                    for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                        var futureDate = ConvertDateToServerDate(m);
                        if(i==startDay)
                        {
                            //PM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                            });
                        }
                        else if(i==endDay)
                        {
                            //AM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                            });
                        }
                        else
                        {
                            //AM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                            });
                            //PM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                            });
                        }
                        i++;

                    }
                    roomType.Rooms.push(roomCopy);
                    IsRoomSet=true;

                    reservationRoomTypeCopy={};
                }
            }
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartReservationOld = function(reservationRoomType)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            
            
            if(reservationRoomType.RoomMasterId)
            {
                var arrivalDate = GetMomentDate($filter('date')(reservationRoomType.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(reservationRoomType.DepartureDate, $scope.DateFormat), $scope.DateFormat);
                var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat);
         
                angular.forEach(roomChart.RoomTypes,function(roomType){
                    if(reservationRoomType.RoomTypeId == roomType.Id)
                    {
                        var emptyRoomDays=[];
                        var roomCopy={};
                        angular.forEach(roomType.Rooms,function(room){
                            if(reservationRoomType.RoomMasterId == room.Id)
                            {
                                roomCopy = angular.copy(room);
                                var nights = departureDate.diff(arrivalDate, 'days');
                                var startDay=0;
                                var endDay=nights;
                                var i=0;
                                var isEmpty=true;
                                var firstDate =  moment(room.Days[0].Day.FutureDate);

                                for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    
                                    if(m.isBefore(endDate))
                                    {
                                        var futureDate = ConvertDateToServerDate(m);
                                    
                                        if(!m.isBefore(firstDate))
                                        {
                                            //skip Start Day AM
                                            if(!m.isSame(arrivalDate))
                                            {
                                                //AM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                                //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                if(emptyRoomDays.length==0)
                                                {
                                                    isEmpty=false;
                                                }
                                            }
                                            //skip Start Day PM
                                            if(!m.isSame(departureDate))
                                            {
                                                if(arrivalDate.isBefore(firstDate))
                                                {
                                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                                    //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                    if(emptyRoomDays.length==0)
                                                    {
                                                        isEmpty=false;
                                                    }
                                                }
                                                else
                                                {
                                                    //PM
                                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                                    //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                    if(emptyRoomDays.length==0)
                                                    {
                                                        isEmpty=false;
                                                    }
                                                }
                                            }    
                                        }
                                    }


                                }
                                if(isEmpty)
                                {
                                    //Set ReservationStatus
                                    for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                        var futureDate = ConvertDateToServerDate(m);
                                        if(i==startDay)
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10' ));
                                            angular.forEach(emptyRoomDays,function(roomDay){
                                                roomDay.Content =reservationRoomType.Content;
                                                var data = reservationRoomType.Content.split('$');
                                                roomDay.RoomStatusTypeId=data[0];
                                                roomDay.ReservationRoomTypeId = data[1];
                                                roomDay.ReservationId = data[2];
                                                roomDay.GuestName = data[4];
                                                roomDay.FromDateStr = data[7];
                                                roomDay.ToDateStr= data[8];
                                                roomDay.Nights= data[9];
                                                //roomDay.BookingTypeId= data[10];
                                                roomDay.BookingTypeId= data[5];
                                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                                //currentroomstatus set bussiness 
                                            });
                                        }
                                        else if(i==endDay)
                                        {
                                            //AM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                            angular.forEach(emptyRoomDays,function(roomDay){
                                                roomDay.Content =reservationRoomType.Content;
                                                var data = reservationRoomType.Content.split('$');
                                                roomDay.RoomStatusTypeId=data[0];
                                                roomDay.ReservationRoomTypeId = data[1];
                                                roomDay.ReservationId = data[2];
                                                roomDay.GuestName = data[4];
                                                roomDay.FromDateStr = data[7];
                                                roomDay.ToDateStr= data[8];
                                                roomDay.Nights= data[9];

                                                roomDay.BookingTypeId= data[5];
                                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                                
                                                //currentroomstatus set bussiness 

                                            });
                                        }
                                        else
                                        {
                                            //AM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                            angular.forEach(emptyRoomDays,function(roomDay){
                                                roomDay.Content =reservationRoomType.Content;
                                                var data = reservationRoomType.Content.split('$');
                                                roomDay.RoomStatusTypeId=data[0];
                                                roomDay.ReservationRoomTypeId = data[1];
                                                roomDay.ReservationId = data[2];
                                                roomDay.GuestName = data[4];
                                                roomDay.FromDateStr = data[7];
                                                roomDay.ToDateStr= data[8];
                                                roomDay.Nights= data[9];

                                                roomDay.BookingTypeId= data[5];
                                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                            });
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                            angular.forEach(emptyRoomDays,function(roomDay){
                                                roomDay.Content =reservationRoomType.Content;
                                                var data = reservationRoomType.Content.split('$');
                                                roomDay.RoomStatusTypeId=data[0];
                                                roomDay.ReservationRoomTypeId = data[1];
                                                roomDay.ReservationId = data[2];
                                                roomDay.GuestName = data[4];
                                                roomDay.FromDateStr = data[7];
                                                roomDay.ToDateStr= data[8];
                                                roomDay.Nights= data[9];

                                                roomDay.BookingTypeId= data[5];
                                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                            });
                                        }

                                        i++;
                                    }
                                }
                            }
                        });
                    }
                });
            }
            else
            {
                angular.forEach(roomChart.RoomTypes,function(roomType){
                    var reservationRoomTypeCopy = angular.copy(reservationRoomType);
                    
                    if(reservationRoomTypeCopy.RoomTypeId == roomType.Id)
                    {
                        var arrivalDate = GetMomentDate($filter('date')(reservationRoomTypeCopy.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                        var departureDate = GetMomentDate($filter('date')(reservationRoomTypeCopy.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                        var emptyRoomDays=[];
                        var IsRoomSet = false;
                        var roomCopy={};
                        angular.forEach(roomType.Rooms,function(room){
                            
                            roomCopy = angular.copy(room);
                            
                            var test = roomCopy.Name;

                            if(reservationRoomTypeCopy.RoomTypeId)
                            {
                                if(!IsRoomSet)
                                {
                                    var nights = departureDate.diff(arrivalDate, 'days');
                                    var startDay=0;
                                    var endDay=nights;
                                    var i=0;

                                    var isEmpty=true;
                                    
                                    //var firstDate =  moment(room.Days[0].Day.FutureDate);
                                    var firstDate = GetMomentDate($scope.date.startDate, $scope.DateFormat);
                                    var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days');

                                    for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                                        var futureDate = ConvertDateToServerDate(m);
                                        
                                        if(m.isBefore(endDate))
                                        {
                                            //skip Start Day AM
                                            if(!m.isSame(arrivalDate))
                                            {
                                                //AM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                                if(emptyRoomDays.length==0)
                                                {
                                                    isEmpty=false;
                                                }
                                            }

                                            //skip Start Day PM
                                            if(!m.isSame(departureDate))
                                            {
                                                var firstDate =  moment(room.Days[0].Day.FutureDate);
                                                if(arrivalDate.isBefore(firstDate))
                                                {
													
                                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                                    if(emptyRoomDays.length==0)
                                                    {
                                                        isEmpty=false;
                                                    }
                                                }
                                                else
                                                {
                                                    //PM
                                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                                    if(emptyRoomDays.length==0)
                                                    {
                                                        isEmpty=false;
                                                    }
                                                }
												
                                            }    
                                        }	
                                    }
                                    if(isEmpty)
                                    {
                                        
                                        //Set ReservationStatus
                                        for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                            var futureDate = ConvertDateToServerDate(m);
                                            if(i==startDay)
                                            {
                                                //PM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                                angular.forEach(emptyRoomDays,function(roomDay){
                                                    roomDay.Content =reservationRoomTypeCopy.Content;
                                                    var data = reservationRoomTypeCopy.Content.split('$');
                                                    roomDay.RoomStatusTypeId=data[0];
                                                    roomDay.ReservationRoomTypeId = data[1];
                                                    roomDay.ReservationId = data[2];
                                                    roomDay.GuestName = data[4];
                                                    roomDay.FromDateStr = data[7];
                                                    roomDay.ToDateStr= data[8];
                                                    roomDay.Nights= data[9];

                                                    roomDay.BookingTypeId= data[10];
                                                    roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                                });
                                            }
                                            else if(i==endDay)
                                            {
                                                //AM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                                angular.forEach(emptyRoomDays,function(roomDay){
                                                    roomDay.Content =reservationRoomTypeCopy.Content;
                                                    var data = reservationRoomTypeCopy.Content.split('$');
                                                    roomDay.RoomStatusTypeId=data[0];
                                                    roomDay.ReservationRoomTypeId = data[1];
                                                    roomDay.ReservationId = data[2];
                                                    roomDay.GuestName = data[4];
                                                    roomDay.FromDateStr = data[7];
                                                    roomDay.ToDateStr= data[8];
                                                    roomDay.Nights= data[9];

                                                    roomDay.BookingTypeId= data[10];
                                                    roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                                });
                                            }
                                            else
                                            {
                                                //AM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                                angular.forEach(emptyRoomDays,function(roomDay){
                                                    roomDay.Content =reservationRoomTypeCopy.Content;
                                                    var data = reservationRoomTypeCopy.Content.split('$');
                                                    roomDay.RoomStatusTypeId=data[0];
                                                    roomDay.ReservationRoomTypeId = data[1];
                                                    roomDay.ReservationId = data[2];
                                                    roomDay.GuestName = data[4];
                                                    roomDay.FromDateStr = data[7];
                                                    roomDay.ToDateStr= data[8];
                                                    roomDay.Nights= data[9];

                                                    roomDay.BookingTypeId= data[10];
                                                    roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                                });
                                                //PM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                                angular.forEach(emptyRoomDays,function(roomDay){
                                                    roomDay.Content =reservationRoomTypeCopy.Content;
                                                    var data = reservationRoomTypeCopy.Content.split('$');
                                                    roomDay.RoomStatusTypeId=data[0];
                                                    roomDay.ReservationRoomTypeId = data[1];
                                                    roomDay.ReservationId = data[2];
                                                    roomDay.GuestName = data[4];
                                                    roomDay.FromDateStr = data[7];
                                                    roomDay.ToDateStr= data[8];
                                                    roomDay.Nights= data[9];

                                                    roomDay.BookingTypeId= data[10];
                                                    roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                                });
                                            }
                                            i++;
                                        }
                                        IsRoomSet=true;
                                        //reservationRoomTypeCopy={};
                                    }
                                }
                            }

                        });

                        if(!IsRoomSet)
                        {
                            
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;
                            var isEmpty=true;
                            var max = Math.max.apply(Math,roomType.Rooms.map(function(item){return item.OrderSNo;}));

                            roomCopy.Id ='OB';
                            roomCopy.Name ='OB';
                            roomCopy.OrderSNo =max +1;
                            roomCopy.MaxPerson ='';
                            roomCopy.CurrentRoomStatus ='';
                            roomCopy.CurrentRoomStatusId ='1';
                            angular.forEach(roomCopy.Days,function(roomDay){
                                roomDay.RoomId = 'OB';
                                roomDay.Name= 'Over Booking';
                                roomDay.OccupiedStatusId='1';
                                roomDay.IsCheckOUTToday=false;
                                roomDay.Content = '';
                                roomDay.RoomStatusTypeId = '1';
                                roomDay.ReservationRoomTypeId = '';
                                roomDay.ReservationId = '';
                                roomDay.GuestName = '';
                                roomDay.FromDateStr = '';
                                roomDay.ToDateStr= '';
                                roomDay.Nights= 0;
                                roomDay.BookingTypeId= '1';
                                roomDay.CheckINGuestRoomId = '';
                                roomDay.CheckINId = '';
                            });
                          
                            //Set ReservationStatus
                            for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                if(i==startDay)
                                {
                                    //PM
                                    emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomTypeCopy.Content;
                                        var data = reservationRoomTypeCopy.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                    });
                                }
                                else if(i==endDay)
                                {
                                    //AM
                                    emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomTypeCopy.Content;
                                        var data = reservationRoomTypeCopy.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                    });
                                }
                                else
                                {
                                    //AM
                                    emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomTypeCopy.Content;
                                        var data = reservationRoomTypeCopy.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                    });
                                    //PM
                                    emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomTypeCopy.Content;
                                        var data = reservationRoomTypeCopy.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                    });
                                }
                                i++;

                            }
                            roomType.Rooms.push(roomCopy);
                            IsRoomSet=true;

                            reservationRoomTypeCopy={};
                        }
                    }
                });
            }
            $scope.RoomChart =roomChart;
        }

        $scope.GetRoomChartCheckINGuestRoom = function(){
            $scope.SearchModel = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate:  GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'),$scope.DateFormat) , //GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
            var promiseGet = roomChartService.GetRoomChartCheckINGuestRoom($scope.SearchModel);
            promiseGet.then(function (data, status) {
                var checkINGuestRooms = data.Data;
                angular.forEach(checkINGuestRooms,function(item){
                    $scope.UpdateRoomChartCheckINRoom(item);
                });    
                $scope.GetRoomChartRoomBlock();

            },
            function (error, status) {
            });
        }
        $scope.UpdateRoomChartCheckINRoom = function(checkINGuestRoom)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            if(checkINGuestRoom.RoomMasterId)
            {
                var roomType = roomChart.RoomTypes.find(x=>x.Id == checkINGuestRoom.RoomTypeId);
                if (roomType)
                {
                    var arrivalDate = GetMomentDate($filter('date')(checkINGuestRoom.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                    var departureDate = GetMomentDate($filter('date')(checkINGuestRoom.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                    var emptyRoomDays=[];
                    var roomCopy={};

                    angular.forEach(roomType.Rooms,function(room){
                        if(checkINGuestRoom.RoomMasterId == room.Id)
                        {
                            roomCopy = angular.copy(room);
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;
                            var isEmpty=true;
                            var firstDate =  moment(room.Days[0].Day.FutureDate);
                            var endDate =  GetMomentDate($scope.date.endDate, $scope.DateFormat);
                                
                            for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) 
                            {
                                if(m.isBefore(endDate))
                                {
                                    var futureDate = ConvertDateToServerDate(m);
                                    
                                    if(!m.isBefore(firstDate))
                                    {
                                        //skip Start Day AM
                                        if(!m.isSame(arrivalDate))
                                        {
                                            //AM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        //skip Start Day PM
                                        if(!m.isSame(departureDate))
                                        {
                                            if(arrivalDate.isBefore(firstDate))
                                            {
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                if(emptyRoomDays.length==0)
                                                {
                                                    isEmpty=false;
                                                }
                                            }
                                            else
                                            {
                                                //PM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                if(emptyRoomDays.length==0)
                                                {
                                                    isEmpty=false;
                                                }
                                            }
                                        }    
                                    }
                                }
                            }
                            if(isEmpty)
                            {
                                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    if(i==startDay)
                                    {
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];

                                            //if(roomDay.RoomStatusTypeId == '4') //ManagementBlock
                                            //else if(roomDay.RoomStatusTypeId == '5')    //MaintenanceBlock
                                            //else if(roomDay.RoomStatusTypeId == '6')    //ReservationBlock
                                            //else if(roomDay.RoomStatusTypeId == '7')    //CheckIN
                                            //else if(roomDay.RoomStatusTypeId == '8')    //CheckOUT
                                            //else if(roomDay.RoomStatusTypeId == '10')   //Reservation RoomType
                                               
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];

                                        });
                                    }
                                    else if(i==endDay)
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];

                                        });
                                    }
                                    else
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];
                                        });
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];
                                        });
                                    }
                                    i++;
                                }
                            }
                        }
                    });
                }
            }
           
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartCheckINGuestRoomDelete = function(checkINGuestRoomId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        if(roomDay.CheckINGuestRoomId  == checkINGuestRoomId)
                        {       
                            roomDay.RoomStatusTypeId='1';
                            roomDay.CheckINGuestRoomId = '';
                            roomDay.CheckINId  = '';
                            roomDay.IsCheckOUTToday  = '';
                            roomDay.Content = '';
                        }
                    });
                });
            });
            $scope.RoomChart =roomChart;
        }

        $scope.UpdateRoomChartReservationRoomTypeDelete = function(reservationRoomTypeId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        
                        if(roomDay.ReservationRoomTypeId  == reservationRoomTypeId)
                        {   
                            roomDay.RoomStatusTypeId='1';
                            roomDay.ReservationRoomTypeId = '';
                            roomDay.ReservationId = '';
                            roomDay.GuestName = '';
                            roomDay.FromDateStr = '';
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                            roomDay.BookingTypeId= '1';
                        }
                    });
                });
            });
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartReservationDelete = function(reservationId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        
                        if(roomDay.ReservationId  == reservationId)
                        {   
                            roomDay.RoomStatusTypeId='1';
                            roomDay.ReservationRoomTypeId = '';
                            roomDay.ReservationId = '';
                            roomDay.GuestName = '';
                            roomDay.FromDateStr = '';
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                            roomDay.BookingTypeId= '1';
                        }
                    });
                });
            });

            $scope.UpdateRoomChartAvailability();
            //$timeout(function () {
            //    $scope.MonthColMarge();
            //    $scope.ColMarge1();
            //    $scope.HideLoader();
            //    $scope.load1($(".followMeBar"));
            //}, 200); // 3 seconds

            $scope.RoomChart =roomChart;
        }
        $scope.GetRoomChartRoomBlock = function(){
            
            $scope.SearchModel = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate:  GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'),$scope.DateFormat) , //GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
                
            var promiseGet = roomChartService.GetRoomChartRoomBlock($scope.SearchModel);
            promiseGet.then(function (data, status) {
                var roomBlocks = data.Data;
                angular.forEach(roomBlocks,function(item){
                    $scope.UpdateRoomChartRoomBlock(item);
                });    
                $scope.GetReservationRoomType();

            },
            function (error, status) {
            });
        }

        $scope.UpdateRoomChartRoomBlock = function(roomBlock)
        {
            $scope.UpdateRoomChartRoomBlockDelete(roomBlock.Content.split('$')[1]);
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            
            var roomType = roomChart.RoomTypes.find(x=>x.Id == roomBlock.RoomTypeId);
            if(roomType)
            {
                var arrivalDate = GetMomentDate($filter('date')(roomBlock.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(roomBlock.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                var emptyRoomDays=[];
                var roomCopy={};

                angular.forEach(roomType.Rooms,function(room){
                    if(roomBlock.RoomMasterId == room.Id)
                    {
                        roomCopy = angular.copy(room);
                        var nights = departureDate.diff(arrivalDate, 'days');
                        var startDay=0;
                        var endDay=nights;
                        var i=0;
                        var isEmpty=true;
                        var firstDate =  moment(room.Days[0].Day.FutureDate);
                        var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days');

                        for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                            var futureDate = ConvertDateToServerDate(m);
                                    

                            if(m.isBefore(endDate))
                            {
                                var futureDate = ConvertDateToServerDate(m);
                                    
                                if(!m.isBefore(firstDate))
                                {
                                    //skip Start Day AM
                                    if(!m.isSame(arrivalDate))
                                    {
                                        //AM
                                            
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                        //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        if(emptyRoomDays.length==0)
                                        {
                                            isEmpty=false;
                                        }
                                    }
                                    //skip Start Day PM
                                    if(!m.isSame(departureDate))
                                    {
                                        if(arrivalDate.isBefore(firstDate))
                                        {
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        else
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                    }    
                                }
                            }

                        }
                        if(isEmpty)
                        {
                                
                            //Set ReservationStatus
                            for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                if(i==startDay)
                                {
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                }
                                else if(i==endDay)
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                }
                                else
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                }
                                i++;
                            }
                        }
                    }
                });
            }
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartRoomBlockDelete = function(roomBlockId)
        {
            
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        if(roomDay.RoomBlockId  == roomBlockId)
                        {   
                            roomDay.RoomStatusTypeId='1';
                            roomDay.RoomBlock = null;
                            roomDay.RoomBlockId = '';
                            roomDay.FromDateStr = '';
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                        }
                    });
                });
            });
            $scope.RoomChart =roomChart;
        }
        function GetBookingTypeName(bookingTypeId){
            
            try{
                if (bookingTypeId == "2")
                {
                    return  "Travel Agent";
                }else if (bookingTypeId == "3")
                {
                    return "Group";
                }else if (bookingTypeId == "4")
                {
                    return "Booking Engine";
                }else if (bookingTypeId == "5")
                {
                    return "Channel Manager";
                }
                else
                {
                    return "Individual";
                }  
            }
            catch(ex)
            {return "";}
        }
        $scope.GetDistinctRoomType = function (list) {
            var distinct = [];
            var newArr = list.filter(function (el) {
                if (distinct.indexOf(el.RoomTypeId) === -1) {
                    // If not present in array, then add it
                    distinct.push(el.RoomTypeId);
                    return true;
                }
                else {
                    // Already present in array, don't add it
                    return false;
                }
            });
            return distinct;
        };

        $scope.GetAvailableRoom = function(ArrivalDate,DepartureDate,roomType)
        {   
            if(roomType)
            {
                var a = GetMomentDate(ArrivalDate, $scope.DateFormat);
                var b = GetMomentDate(DepartureDate, $scope.DateFormat);
                var myRoom = {};
                roomType.AvailableRooms =[];
                angular.forEach(roomType.Rooms, function (room) {
                    var IsAdd = true;
                    myRoom = room;
                    for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                        angular.forEach(room.Days, function (roomDay) {
                            var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                            if (futureDate.isSame(m)) {
                                if(roomDay.DayPart=='PM')
                                {
                                    if (IsAdd)
                                    {
                                        if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
                                            IsAdd = false;
                                        }
                                        else if((roomDay.RoomStatusTypeId == '10'))
                                        {
                                            //SKIP 
                                            IsAdd = false;
                                        }
                                        else {
                                            if ((roomDay.RoomStatusTypeId != '1') && !roomDay.IsCheckOUTToday) {    // || roomDay.RoomStatusTypeId != '10'
                                                IsAdd = false;
                                            }
                                        }
                                    }
                                    angular.forEach(roomType.Availabilitys  ,function(ava){
                                        var futureDate2 = GetMomentDate($filter('date')(ava.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                                        if (futureDate.isSame(futureDate2)) {
                                            if (ava.TotalRemainingCount<=0) {
                                                IsAdd = false;
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    }
                    if (IsAdd) {
                        if(myRoom.Name != 'OB')
                        {
                            //RoomType
                            for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                                angular.forEach(roomType.Availabilitys  ,function(ava){
                                    var futureDate = GetMomentDate($filter('date')(ava.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                                    if (futureDate.isSame(m)) {
                                        ava.TotalRemainingCount = ava.TotalRemainingCount-1;
                                    }
                                });
                            }
                            roomType.AvailableRooms.push({ Id: myRoom.Id, Name: myRoom.Name ,MaxPerson:myRoom.MaxPerson,OrderSNo:myRoom.OrderSNo,RoomTypeId:myRoom.RoomTypeId,RoomStatusTypeId:myRoom.CurrentRoomStatusId  });
                        }
                    }
                });
            }
        } 

        $scope.UpdateRoomChartAvailability = function()
        {
            
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
               
            var arrivalDate = GetMomentDate($filter('date')(roomChart.FromDate, $scope.DateFormat), $scope.DateFormat);
            var departureDate = GetMomentDate($filter('date')(roomChart.ToDate, $scope.DateFormat), $scope.DateFormat);

            angular.forEach(roomChart.RoomTypes,function(roomType)  {

                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                    var futureDate = ConvertDateToServerDate(m);
                    var roomtypes = $scope.RoomTypes.filter(x=>x.Id == roomType.Id);
                    
                    roomType.OverBooking = roomtypes[0].OverBooking;

                    var availability = roomType.Availabilitys.filter(x=>x.Day.FutureDate == futureDate );
                    if(availability[0])
                    {
                        var occupiedRooms=[];
                        var list = roomType.Rooms.filter(
                                function(room)
                                {
                                    var roomDay = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '4' || x.RoomStatusTypeId == '5' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '7'|| x.RoomStatusTypeId == '10'));
                                    angular.forEach(roomDay,function(item){
                                        occupiedRooms.push(item);
                                    });
                                    return occupiedRooms;
                                }
                            );
                        
                        availability[0].RoomCount = roomType.Rooms.filter(x=>x.Id!='OB').length;
                        availability[0].OccupiedCount = occupiedRooms.length;
                        availability[0].AvailabilityCount = availability[0].RoomCount - (availability[0].OccupiedCount);
                        var OBRooms = (availability[0].RoomCount) * (roomType.OverBooking/100);
                        OBRooms = parseInt(OBRooms);
                        availability[0].TotalRemainingCount = availability[0].RoomCount + OBRooms - availability[0].OccupiedCount;
                    }

                    angular.forEach(roomType.Rooms,function(room){
                        angular.forEach(room.Days,function(roomday){
                            
                            //var availability = roomType.Availabilitys.filter(x=>x.RoomTypeId == roomType.Id && x.Day==roomday.Day && x.Month==roomday.Month && x.Year==roomday.Year);
                            var availability = roomType.Availabilitys.filter(x=> x.Day.Day==roomday.Day.Day && x.Day.Month==roomday.Day.Month && x.Day.Year==roomday.Day.Year);
                            roomday.AvailabilityCount = availability[0].AvailabilityCount;
                            roomday.DayCol = roomday.Day.Day + '$'+ roomday.Day.DayName + '$'+ availability[0].AvailabilityCount;
                        });
                    });
                }
            });

            
            $timeout(function () {
                //$scope.MonthColMarge();
                //$scope.ColMarge1();
                $scope.HideLoader();
                //$scope.load1($(".followMeBar"));
            }, 1000); // 3 seconds
            
            //$scope.HideLoader();
            $scope.RoomChart =roomChart;
        }

        
        $scope.date = {
            startDate: businessDate,
            endDate:  GetLocalDate(GetMomentDate(businessDate, $scope.DateFormat).add(1, 'days'), $scope.DateFormat)

        };

        function GetRoomChart(ArrivalDate,DepartureDate,RoomTypeId) {
            
            $scope.SetDate();
            $scope.date.startDate = $filter('date')(ArrivalDate, $scope.DateFormat);
            $scope.date.endDate = $filter('date')(DepartureDate, $scope.DateFormat);
            $scope.GetRoomChart();
        }

        $scope.UpdateRoomChartRoomStatus = function(roomId, roomStatusTypeId)
        {
            angular.forEach($scope.SelectedRoomType.Rooms,function(room){
                if(room.Id==roomId)
                {
                    var currentRoomStatus="";
                    if(roomStatusTypeId=='1')
                    {
                        currentRoomStatus="Ready";
                    }
                    else if(roomStatusTypeId=='2')
                    {   
                        currentRoomStatus="Dirty";
                    }
                    else if(roomStatusTypeId=='3')
                    {
                        currentRoomStatus="Clean";
                    }

                    room.CurrentRoomStatusId = roomStatusTypeId;
                    room.CurrentRoomStatus=currentRoomStatus;

                }
            });
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    if(room.Id==roomId)
                    {
                        var currentRoomStatus="";
                        if(roomStatusTypeId=='1')
                        {
                            currentRoomStatus="Ready";
                        }
                        else if(roomStatusTypeId=='2')
                        {   
                            currentRoomStatus="Dirty";
                        }
                        else if(roomStatusTypeId=='3')
                        {
                            currentRoomStatus="Clean";
                        }

                        room.CurrentRoomStatusId = roomStatusTypeId;
                        room.CurrentRoomStatus=currentRoomStatus;
                    }
                });
            });
            $scope.RoomChart =roomChart;
        }

        $scope.RoomFeatureRooms=[];
        $scope.getRoomFeatureRoom = function () {
            
            $scope.RoomFeatureRooms = [];
            checkINService.getRoomFeatureRoom($scope.PropertyID)
                   .then(function (result) {
                       $scope.RoomFeatureRooms = result.Data[0];
                   }, function (err) {
                       msg(err.Message);
                   });
        };


        //--------------------------------------------
        //---------------END GetRoomChart-------------
        //--------------------------------------------

        $scope.OpenRoomStatusBox = function (room) {
            
            $scope.Model.FromRoomDay =
            {
                RoomTypeId : room.RoomTypeId,
                RoomId : room.Id,
                
                Name : room.Name,

                FromDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                ToDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                RoomStatusTypeId :room.CurrentRoomStatusId,                
                FutureDate : $scope.businessDate,
                IsBusinessDate :true,
            };

            $scope.Model.FromRoomMasterId = room.Id;
            $scope.Model.FromRoomMasterName = room.Name;
            $scope.Model.FromRoomTypeId = room.RoomTypeId;
            $scope.Model.FromRoomTypeName = room.RoomTypeName;

            //var roomType = $scope.RoomTypes.find(x=>x.Id = room.RoomTypeId);
            var roomStatus = {
                StatusDate: $scope.MinDate,
                FromDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                ToDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                ToTime: '',
                RoomMasterId: room.Id,
                RoomStatusTypeId: room.CurrentRoomStatusId,
                RoomNumber: room.Name,
                RoomTypeId: room.RoomTypeId,
                RoomTypeName: room.RoomTypeName,
                EmployeeName: $scope.ModifiedBy,
                
            };

            $scope.Model.FromRoomDay.RoomStatus = roomStatus;
            $scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeName= 'Room Status';
            $("#cleanModel").modal('show');
        }

        $scope.SaveRoomStatus = function (frm) {
            
            if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId != 1 && frm)
            {
                if ($scope[frm].$valid) {
                } else {
                    scrollPageOnTop();
                    $scope.ShowErrorManagementBlock = true;
                    return;
                }
            }
            
            if (!$scope.Model.FromRoomDay.RoomStatus.MaintenanceTypeId && $scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId==5) {
                $scope.ShowErrorMaintenanceType = true;
                return;
            }

            $scope.Model.FromRoomDay.RoomStatus.PropertyID = $scope.PropertyID;
            $scope.Model.FromRoomDay.RoomStatus.ModifiedBy = $scope.ModifiedBy;
            $scope.Model.FromRoomDay.RoomStatus.DateFormat = $scope.DateFormat;
            $scope.Model.FromRoomDay.RoomStatus.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

            var roomStatus = angular.copy($scope.Model.FromRoomDay.RoomStatus);
            roomStatus.FromDate = GetServerDate(roomStatus.FromDate, $scope.DateFormat);
            roomStatus.ToDate = GetServerDate(roomStatus.ToDate, $scope.DateFormat);
            
            if($scope.Model.FromRoomDay.RoomStatus.CheckINGuestRoomId)
            {
                roomStatus.CheckINGuestRoomId = $scope.Model.FromRoomDay.RoomStatus.CheckINGuestRoomId
                if($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId=='3')
                {
                    roomStatus.RoomStatusTypeId='7';
                }
                else if($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId=='4')
                {
                    roomStatus.RoomStatusTypeId='8';
                }
            }
            var promiseGet = checkINService.saveRoomStatus(roomStatus);
            promiseGet.then(function (details) {
                scrollPageOnTop();
                var msg = "";
                if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 1) {
                    msg = "Room Status changed to Ready.";
                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 2) {
                    
                    var fromdate = GetMomentDate($scope.Model.FromRoomDay.RoomStatus.FromDate, $scope.DateFormat);
                    var businessDate = GetMomentDate($scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day, "YYYY-MM-DD")

                    if (businessDate.isSame(fromdate))
                    {
                        msg = "Room Status changed to Dirty.";
                    }
                    else
                    {
                        msg = "Room Released successfully.";
                    }

                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 3) {
                    msg = "Room Status changed to Clean.";
                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 4) {
                    if($scope.Model.FromRoomDay.RoomStatus.IsExtend)
                    {
                        msg = "Room Status changed successfully.";
                    }
                    else
                    {
                        msg = "Room Status changed as Management Block .";
                    }
                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 5) {
                    if($scope.Model.FromRoomDay.RoomStatus.IsExtend)
                    {
                        msg = "Room Status changed successfully.";
                    }
                    else
                    {
                        msg = "Room Status changed as Maintenance Block.";
                    }
                }
                
                $("#cleanModel").modal('hide');
                parent.successMessage(msg);
                $scope.UpdateRoomChartRoomStatus($scope.Model.FromRoomMasterId,$scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId);
                $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};
                
                //$scope.RoomChart={};
                //$scope.GetRoomChart();
                

            },
            function (xhr) {
                parent.popErrorMessage(xhr.Message);
            });
            scrollPageOnTop();

        };

        

        //Navneet2.0
        Setup();
        function Setup() {
            $scope.IsProgress = true;
            $scope.ProgressStart();
            var promiseGet1 = checkINService.GetConstantByPropertyId($scope.PropertyID);
            promiseGet1.then(function (data, status) {
                $scope.PropertyConstant = data.Data;

                var promiseGet = checkINService.GetSetup($scope.PropertyID);
                promiseGet.then(function (data, status) {
                
                    $scope.SettlementModeDetailsAll = data.Data[0];
                    $scope.SettlementModeDetails = $scope.SettlementModeDetailsAll.filter(x => x.RevenueForId == '5');

                    $scope.ReservationModes =data.Data[1];
                    $scope.BillingInstructions =data.Data[2];
                    $scope.MarketSegments =data.Data[3];
                    $scope.NewsPapers =data.Data[4];
                    $scope.BusinessSources =data.Data[5];
                    $scope.TaxStructures =data.Data[6];
                    $scope.Designations =data.Data[7];
                    $scope.Corporates =data.Data[8];
                    $scope.Bookers =data.Data[9];
                    $scope.DocumentTypes =data.Data[10];
                    $scope.DefaultSettings =data.Data[11];
                    $scope.DefaultSetting = {

                        CurrencyConversionRate: data.Data[11][0].CurrencyConversionRate,
                        CurrencyConversionMargin: data.Data[11][0].CurrencyConversionMargin,
                        CurrencydecimalPlaces: data.Data[11][0].CurrencydecimalPlaces,
                        DateFormat: data.Data[11][0].DateFormat,
                        TimeZoneLocation: data.Data[11][0].TimeZoneLocation,
                        TimeFormat: data.Data[11][0].TimeFormat,
                        ChildAge: data.Data[11][0].ChildAge,
                        InfantAge: data.Data[11][0].InfantAge,
                        DefaultNationality: data.Data[11][0].DefaultNationality,
                        GlobalLanguage: data.Data[11][0].GlobalLanguage,
                        Software_Started_Date: data.Data[11][0].Software_Started_Date,
                        Financial_FromYear: data.Data[11][0].Financial_FromYear,
                        Financial_ToYear: data.Data[11][0].Financial_ToYear,
                        CheckOUTTypeId: data.Data[11][0].CheckOUTTypeId,
                        EarlyArrival: data.Data[11][0].EarlyArrival,
                        LateDeparture: data.Data[11][0].LateDeparture,
                        CountryMasterId: data.Data[11][0].CountryMasterId,
                        MarketSegmentId: data.Data[11][0].MarketSegmentId,
                        RateMasterId: data.Data[11][0].RateMasterId,
                        RoomTypeId: data.Data[11][0].RoomTypeId,
                        BusinessSourceId: data.Data[11][0].BusinessSourceId,
                        CurrencyMasterId: data.Data[11][0].CurrencyMasterId,
                        MealPlanId: data.Data[11][0].MealPlanId,
                        RevenueHeadId: data.Data[11][0].RevenueHeadId,
                        RevenueHeadCode: data.Data[11][0].RevenueHeadCode,
                        SalutationId: data.Data[11][0].SalutationId.toString(),
                        StateMasterId: data.Data[11][0].StateMasterId,
                    };
                    $scope.Amenitys =data.Data[12];
                    $scope.RevenueHeads =data.Data[13];
                    angular.forEach($scope.RevenueHeads, function (item) {
                        item.RevenueForId = item.RevenueForId.toString();
                    })
                    $scope.AdvanceRevenueHeads = $scope.RevenueHeads.filter(x=>x.RevenueForId == '6');  //Navneet Do not Confuse with Reservation Advance
                    $scope.RateMasters =data.Data[14];
                    $scope.RateMasterList = $scope.RateMasters;

                    $scope.GuestStatuss =data.Data[15];
                    $scope.OccupationMasters =data.Data[16];
                    $scope.BookerTypes =data.Data[17];
                    $scope.CorporateTypes =data.Data[18];
                    $scope.Currencys =data.Data[19];
                    $scope.Salutations =data.Data[20];
                    $scope.Countrys =data.Data[21];
                    $scope.GuestClasss =data.Data[22];
                    $scope.MealPlans =data.Data[23];
                    //$scope.CreditCardNetworks =data.Data[24];
                    $scope.NetworkList =data.Data[24];
                    $scope.RoomTypes =data.Data[25];
                    $scope.OccupancyRates =data.Data[26];
                    $scope.OccupancyMealPlanRates =data.Data[27];
                    $scope.LinkTaxStructures =data.Data[28];

                    $scope.BookingStatuss =$scope.PropertyConstant.BookingStatuss;
                    $scope.DiscountTypes =$scope.PropertyConstant.DiscountTypes;
                    $scope.LocationTypes =$scope.PropertyConstant.LocationTypes;
                    $scope.CorporateCategorys =$scope.PropertyConstant.CorporateCategorys;

                    $scope.BookingTypes     =$scope.PropertyConstant.BookingTypes;
                    $scope.PaxTypes         =$scope.PropertyConstant.PaxTypes;
                    $scope.TravelTypes      =$scope.PropertyConstant.TravelTypes;
                    $scope.VisitTypes       =$scope.PropertyConstant.VisitTypes;
                    $scope.PickupDropTypes  =$scope.PropertyConstant.PickupDropTypes;


                    $scope.walkinGuest(false);
                    
                    $rootScope.$broadcast("CallSetScanAPI", {ScanAPIPath: $scope.DefaultSetting.DocumentReaderAPI});
                    $rootScope.$broadcast("CallOpenRoomChartCheckIN", null);
                    $scope.ProgressEnd();
                    
                },
                    function (error, status) {
                        parent.failureMessage(error.Message); scrollPageOnTop();
                        $scope.ProgressEnd();
                    });
            });
        }


        //$scope.getSetup = function () {

        //    $scope.ProgressStart();
        //    checkINService.getSetup($scope.PropertyID)
        //        .then(function (data) {

        //            $scope.setupData = data.Data;
        //            $scope.DiscountTypes = $scope.setupData.DiscountTypes;
        //            $scope.TaxStructures = $scope.setupData.TaxStructures;
        //            $scope.RoomTypes = $scope.setupData.RoomTypes;
        //            //$scope.Packages = $scope.setupData.Packages;
        //            $scope.Countrys = $scope.setupData.Countrys;
        //            $scope.MealPlans = $scope.setupData.MealPlans;
        //            $scope.BookingTypes = $scope.setupData.BookingTypes;
        //            $scope.PaxTypes = $scope.setupData.PaxTypes;
        //            $scope.TravelTypes = $scope.setupData.TravelTypes;
        //            $scope.VisitTypes = $scope.setupData.VisitTypes;
        //            $scope.PickupDropTypes = $scope.setupData.PickupDropTypes;
        //            $scope.LocationTypes = $scope.setupData.LocationTypes;
        //            $scope.CorporateCategorys = $scope.setupData.CorporateCategorys;
        //            $scope.CreditCardNetworks = $scope.setupData.CreditCardNetworks;
        //            $scope.CorporateTypes = $scope.setupData.CorporateTypes;
        //            $scope.Designations = $scope.setupData.DesignationMasters;
                    
        //            $scope.RateMasters = data.Data.RateMasters;
        //            $scope.SettlementMode = data.Data.SettlementMode;
        //            $scope.SettlementModeDetails = $scope.SettlementMode.SettlementModeDetails;
                    
        //            $scope.AdvanceRevenueHeads = $scope.SettlementModeDetails.filter(x => x.RevenueForId == '6');
        //            $scope.Amenitys = data.Data.Amenitys;
        //            $scope.RevenueHeads = data.Data.RevenueHeads;

        //            //GetRateMaster();
        //            $scope.DefaultSetting = {
        //                DateFormat: data.Data.DefaultSetting.DateFormat,
        //                TimeZoneLocation: data.Data.DefaultSetting.TimeZoneLocation,
        //                TimeFormat: data.Data.DefaultSetting.TimeFormat,
        //                ChildAge: data.Data.DefaultSetting.ChildAge,
        //                InfantAge: data.Data.DefaultSetting.InfantAge,
        //                DefaultNationality: data.Data.DefaultSetting.DefaultNationality,
        //                GlobalLanguage: data.Data.DefaultSetting.GlobalLanguage,
        //                Software_Started_Date: data.Data.DefaultSetting.Software_Started_Date,
        //                Financial_FromYear: data.Data.DefaultSetting.Financial_FromYear,
        //                Financial_ToYear: data.Data.DefaultSetting.Financial_ToYear,
        //                Checkin_Checkout_Parameter: data.Data.DefaultSetting.CheckOUTTypeId,
        //                EarlyArrival: data.Data.DefaultSetting.EarlyArrival,
        //                LateDeparture: data.Data.DefaultSetting.LateDeparture,
        //                CountryMasterId: data.Data.DefaultSetting.CountryMasterId,
        //                MarketSegmentId: data.Data.DefaultSetting.MarketSegmentId,
        //                RateMasterId: data.Data.DefaultSetting.RateMasterId,
        //                RoomTypeId: data.Data.DefaultSetting.RoomTypeId,
        //                BusinessSourceId: data.Data.DefaultSetting.BusinessSourceId,
        //                CurrencyMasterId: data.Data.DefaultSetting.CurrencyMasterId,
        //                MealPlanId: data.Data.DefaultSetting.MealPlanId,
        //                RevenueHeadId: data.Data.DefaultSetting.RevenueHeadId,
        //                RevenueHeadCode: data.Data.DefaultSetting.RevenueHeadCode,
        //                SalutationId: data.Data.DefaultSetting.SalutationId,
        //                StateMasterId: data.Data.DefaultSetting.StateMasterId,
        //                CheckOUTTypeId: data.Data.DefaultSetting.CheckOUTTypeId.toString(),
        //                DocumentReaderAPI: data.Data.DefaultSetting.DocumentReaderAPI,
        //                ExemptRackRateTAXStayLength:data.Data.DefaultSetting.ExemptRackRateTAXStayLength,
        //            };
        //            $scope.walkinGuest(false);
                    
        //            $rootScope.$broadcast("CallSetScanAPI", {ScanAPIPath: $scope.DefaultSetting.DocumentReaderAPI});
        //            $rootScope.$broadcast("CallOpenRoomChartCheckIN", null);

        //            $scope.ProgressEnd();
        //        }, function (err) {
        //            msg(err.Message);
        //            $scope.ProgressEnd();
        //        });

        //};
        //$scope.getSetup();

        $scope.IsFutureReservation = false;
        $scope.IsCheckedIN = false;
        $scope.BookingStatusId = 1;
        $scope.selectReservation = function (searchReservation) {

            $scope.IsFutureReservation = false;
            $scope.BookingStatusId = 1;
            angular.forEach($scope.SearchReservationList, function (SearchReservation) {
                if (SearchReservation.Id != searchReservation.Id) {
                    SearchReservation.itemChecked = false;
                }
            });
            $scope.SearchReservation = searchReservation.itemChecked ? searchReservation : null;
            angular.forEach($scope.SearchReservationList, function (SearchReservation) {
                if (SearchReservation.itemChecked == true) {
                    var guestArrivalDate = GetMomentDate($filter('date')(SearchReservation.GuestArrivalDate, $scope.DateFormat), $scope.DateFormat);
                    var currentDate = GetMomentDate(businessDateStr, "YYYY-MM-DD");
                    if (!guestArrivalDate.isSame(currentDate)) {
                        $scope.IsFutureReservation = true;
                    }
                    $scope.IsCheckedIN = SearchReservation.IsCheckedIN;
                    $scope.BookingStatusId = SearchReservation.BookingStatusId;
                }
            });
        };
        $scope.loadReservation = function (id) {
            
            if(!id)
            {
                return; 
            }
            $scope.ProgressStart();
            checkINService.getReservation($scope.PropertyID, id, businessDateStr)
                .then(function (result) {
                    $scope.Reservation = result.Data;

                    $scope.SetCheckINModelByReservation();
                    $scope.ResetRoomOwner();
                    angular.forEach($scope.Model.CheckINGuests,function(item){
                        $scope.SetRoomOwner(item);
                    });
                    $scope.ProgressEnd();
                    $rootScope.$broadcast("CallCheckINLoaded", {});
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.SetCheckINModelByReservation = function () {
            
            var fromDate =$scope.ModifiedDate;
            var blogPosts = _.sortBy($scope.Reservation.ReservationRoomTypes, function(o) { return new moment(o.DepartureDate); }).reverse();
            var maxDate =blogPosts[0].DepartureDate;
            $scope.Model = $scope.Reservation.ReservationRoomTypes == null || $scope.Reservation.ReservationRoomTypes.length < 1 ? null : angular.copy($scope.Reservation.ReservationRoomTypes[0]);
            var days = GetDays($filter('date')(fromDate, $scope.DateFormat) ,$filter('date')(maxDate, $scope.DateFormat) ,$scope.DateFormat);
            var nights =days.length-1;
            $scope.Model = {
                Id: "",
                ReservationId: $scope.Reservation.Id,
                CheckINDate: fromDate,//$scope.ModifiedDate,// $scope.Model.ArrivalDate,
                CheckOUTDate: maxDate,//$scope.Model.DepartureDate,
                TotalPax: $scope.Reservation.TotalPax,
                BookerId: $scope.Reservation.BookerId,
                BillingInstructionId: $scope.Reservation.BillingInstructionId,
                BusinessSourceId: $scope.Reservation.BusinessSourceId,
                CurrencyMasterId: $scope.Reservation.CurrencyMasterId.toString(),
                BookingTypeId: $scope.Reservation.BookingTypeId.toString(),
                RevenueHeadId: $scope.Reservation.RevenueHeadId,
                SpecialInstructions: $scope.Reservation.SpecialInstructions,
                Arrangements: $scope.Reservation.Arrangements,
                Amenitys: $scope.Reservation.Amenitys,
                NewsPaperId: $scope.Reservation.NewsPaperId,
                IsRateDisplay: $scope.Reservation.IsRateDisplay,
                CheckINGuests: [],
                IsCorporateGuest: $scope.Reservation.CorporateId ? true : false,
                Nights: nights,
                TotalAdvance: $scope.Reservation.TotalAdvance,

                IsGroup:$scope.Reservation.IsGroup,
                GroupCode:$scope.Reservation.GroupCode,
                GroupName:$scope.Reservation.GroupName,
                IsGroupLeaderComplementary:$scope.Reservation.IsGroupLeaderComplementary,
                //ReservationAdvanceAmount:0,
            };

            //$timeout(function(){   
            //},4000);

            var paxCount = 0;
            var sno = 1;
            var isGuestFound = false;
                            
            angular.forEach($scope.Reservation.ReservationRoomTypes, function (reservationRoomType,index) {

                var reservationRoomTypeArrivalDate = GetMomentDate($filter('date')(reservationRoomType.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var currentDate = GetMomentDate(businessDateStr, "YYYY-MM-DD");

                if (reservationRoomTypeArrivalDate.isSame(currentDate)) {
                    paxCount += reservationRoomType.NumberOfPax;
                    var x=0;
                    for (var i = 1; i <= reservationRoomType.NumberOfPax; i++) {
                        isGuestFound = false;
                        if (i <= reservationRoomType.ReservationRoomTypeGuests.length)                                //if( reservationRoomType.ReservationRoomTypeGuests.length<=i)
                        {        
                            var reservationRoomTypeGuest = reservationRoomType.ReservationRoomTypeGuests[i - 1];
                            if (reservationRoomTypeGuest) {
                                isGuestFound = true;
                                
                                var checkINGuest = {};

                                var availableRooms =[];
                                if($scope.RoomChart)
                                {
                                    var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == reservationRoomTypeGuest.RoomTypeId);
                                    $scope.GetAvailableRoom(reservationRoomType.ArrivalDate,reservationRoomType.DepartureDate, roomType);
                                    availableRooms = roomType.AvailableRooms
                                }
                                else
                                {
                                    availableRooms = [{Id:reservationRoomType.RoomMasterId,Name: reservationRoomType.RoomNumber,RoomTypeId:reservationRoomType.RoomTypeId,RoomTypeName: reservationRoomType.RoomTypeName}];
                                }

                                checkINGuest = {
                                    $id:x++,
                                    Id: '',
                                    ReservationRoomTypeGuestId : reservationRoomTypeGuest.Id,
                                    CorporateId: $scope.Reservation.CorporateId,
                                    CorporateName: $scope.Reservation.CorporateName,
                                    CheckINId: reservationRoomTypeGuest.CheckINId,
                                    CheckINNo: reservationRoomTypeGuest.CheckINNo,
                                    SNo: reservationRoomTypeGuest.SNo,

                                    FolioNo: 1,
                                    GuestId: reservationRoomTypeGuest.GuestId,
                                    SalutationId: reservationRoomTypeGuest.SalutationId.toString(),
                                    SalutationName: reservationRoomTypeGuest.SalutationName,
                                    GenderId: reservationRoomTypeGuest.GenderId,
                                    GenderName: reservationRoomTypeGuest.GenderName,
                                    FirstName: reservationRoomTypeGuest.FirstName,
                                    MiddleName: reservationRoomTypeGuest.MiddleName,
                                    LastName: reservationRoomTypeGuest.LastName,
                                    Name: reservationRoomTypeGuest.Name,
                                    Mobile: reservationRoomTypeGuest.Mobile,
                                    EmailId: reservationRoomTypeGuest.EmailId,
                                    PaxTypeId: reservationRoomTypeGuest.PaxTypeId == '0' ? '1' : reservationRoomTypeGuest.PaxTypeId.toString(),//TODO navneet
                                    Nationality: '',
                                    IsExtraBed: reservationRoomTypeGuest.IsExtraBed,
                                    IsGroupLeader :reservationRoomTypeGuest.IsGroupLeader,

                                    RoomINDate: $filter('date')(reservationRoomType.ArrivalDate, $scope.DateFormat),
                                    RoomOUTDate:  $filter('date')(reservationRoomType.DepartureDate, $scope.DateFormat),  
                                    RoomINTime: '',
                                    RoomOUTTime: '',

                                    IsRoomOUT: '',

                                    NewsPaperId: reservationRoomTypeGuest.NewsPaperId,
                                    //CorporateDiscountId:reservationRoomTypeGuest.CorporateDiscountId ,
                                    //PackageId:reservationRoomType.PackageId,
                                    RoomTypeId: reservationRoomType.RoomTypeId.toString(),
                                    RoomTypeName: reservationRoomType.RoomTypeName,

                                    MealPlanId: reservationRoomType.MealPlanId.toString(),
                                    GuestClassId: reservationRoomTypeGuest.GuestClassId.toString(),
                                    CountryMasterId: reservationRoomTypeGuest.CountryMasterId.toString(),
                                    StateId: reservationRoomTypeGuest.StateId.toString(),

                                    ReservationRoomType: reservationRoomType,
                                    ReservationRoomTypeId :reservationRoomType.Id,
                                    RoomMasterId: reservationRoomType.RoomMasterId,
                                    RoomNumber: reservationRoomType.RoomNumber,
                                    CheckINGuestRooms: [],
                                    //AvailableRooms: [{Id:reservationRoomType.RoomMasterId,Name: reservationRoomType.RoomNumber,RoomTypeId:reservationRoomType.RoomTypeId,RoomTypeName: reservationRoomType.RoomTypeName}],
                                    AvailableRooms: availableRooms,
                                    
                                    StateList: [],
                                    LocalStateList: [],
                                    IsCheckedIN: reservationRoomTypeGuest.IsCheckedIN,
                                    Address1: reservationRoomTypeGuest.Address1,
                                    DOB: reservationRoomTypeGuest.DOB,
                                    PlaceofBirth: reservationRoomTypeGuest.PlaceofBirth,
                                    DesignationMasterId: reservationRoomTypeGuest.DesignationMasterId,
                                    City: reservationRoomTypeGuest.City,
                                    PIN: reservationRoomTypeGuest.PIN,
                                    OccupationMasterId: reservationRoomTypeGuest.OccupationMasterId,
                                    DOA: reservationRoomTypeGuest.DOA,
                                    SpouseName: reservationRoomTypeGuest.SpouseName,
                                    SpouseDOB: reservationRoomTypeGuest.SpouseDOB,
                                    IsBlackList: reservationRoomTypeGuest.IsBlackList,
                                    //ReservationAdvance: {
                                    //    ReferenceNo: '',
                                    //    AdvanceAmount: '',
                                    //    CurrencyId: '',
                                    //    RevenueHeadId: '',
                                    //},
                                    CorporateReferenceNo : $scope.Reservation.CorporateReferenceNo,
                                    GSTIN : reservationRoomTypeGuest.GSTIN,

                                    //CheckINGuestAdvance:{
                                    //    ReferenceNo:'',
                                    //    AdvanceAmount:'',
                                    //    CurrencyId:1,
                                    //    RevenueHeadCode:''
                                    //},

                                    CheckINAdvance:0,
                                    CheckINGuestAdvances:[],
                                    GuestDocuments:reservationRoomTypeGuest.GuestDocuments,
                                };

                                $scope.Customer=angular.extend({},$scope.Customer,reservationRoomTypeGuest);

                                //$scope.DefaultSetting.CurrencyMasterId
                                //$scope.DefaultSetting.RevenueHeadId
                                //$scope.DefaultSetting.RevenueHeadCode

                                var currencyMasterId ='1';
                                if($scope.DefaultSetting)
                                {
                                    currencyMasterId = $scope.DefaultSetting.CurrencyMasterId;
                                }

                                checkINGuest.CheckINGuestAdvances.push({ReferenceNo:'',Amount:0,CurrencyMasterId:currencyMasterId.toString(),RevenueHeadCode:'ADC'});
                            }
                            
                            if (reservationRoomTypeGuest.CheckINGuestRoom) {
                                    
                                if (reservationRoomTypeGuest.CheckINGuestRoom.Id) {
                                    if (reservationRoomTypeGuest.CheckINGuestRoom.Id.length > 0) {
                                        checkINGuest.Id = reservationRoomTypeGuest.IsCheckedIN ? reservationRoomTypeGuest.CheckINGuestRoom.CheckINGuestId : null;
                                        checkINGuest.RoomTypeId = reservationRoomTypeGuest.CheckINGuestRoom.RoomTypeId;
                                        checkINGuest.RoomTypeName = reservationRoomTypeGuest.CheckINGuestRoom.RoomTypeName;
                                        checkINGuest.RoomMasterId = reservationRoomTypeGuest.CheckINGuestRoom.RoomMasterId;
                                        checkINGuest.RoomNumber = reservationRoomTypeGuest.CheckINGuestRoom.RoomNumber;
                                        checkINGuest.MealPlanId = reservationRoomTypeGuest.CheckINGuestRoom.MealPlanId.toString();
                                        checkINGuest.RateMasterId = reservationRoomTypeGuest.CheckINGuestRoom.RateMasterId;
                                        checkINGuest.RateMasterCode = reservationRoomTypeGuest.CheckINGuestRoom.RateMasterCode;
                                        //checkINGuest.IsGroupLeader =reservationRoomTypeGuest.IsGroupLeader;
                                    }
                                }
                            }
                                
                            checkINGuest.CheckINGuestVehicle = !reservationRoomTypeGuest.ReservationGuestVehicles || reservationRoomTypeGuest.ReservationGuestVehicles.length < 1 ? {} : reservationRoomTypeGuest.ReservationGuestVehicles[0];

                            //checkINGuest.CheckINGuestLocalContact = !checkINGuest.ReservationGuestLocalContacts || checkINGuest.ReservationGuestLocalContacts.length < 1 ? {} : checkINGuest.ReservationGuestLocalContacts[0];
                          
                            //if (checkINGuest.CheckINGuestLocalContact && checkINGuest.CheckINGuestLocalContact.StateId)
                            //    checkINGuest.CheckINGuestLocalContact.StateId = checkINGuest.CheckINGuestLocalContact.StateId.toString();
                            
                            //checkINGuest.CheckINGuestVisitDetail = !checkINGuest.ReservationGuestVisitDetails || checkINGuest.ReservationGuestVisitDetails.length < 1 ? {} : checkINGuest.ReservationGuestVisitDetails[0];
                            //if (checkINGuest.CheckINGuestVisitDetail && checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId) {
                            //    checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId = checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId.toString();
                            //    $scope.changeArrivingCountry(checkINGuest.CheckINGuestVisitDetail);
                            //    checkINGuest.CheckINGuestVisitDetail.ArrivalStateId = !checkINGuest.CheckINGuestVisitDetail || !checkINGuest.CheckINGuestVisitDetail.ArrivalStateId ? '' : CheckINGuest.CheckINGuestVisitDetail.ArrivalStateId.toString();

                            //    checkINGuest.CheckINGuestVisitDetail.ProceedToCountryId = !checkINGuest.CheckINGuestVisitDetail || !checkINGuest.CheckINGuestVisitDetail.ProceedToCountryId ? '' : CheckINGuest.CheckINGuestVisitDetail.ProceedToCountryId.toString();
                            //    $scope.changeProceedingCountry(checkINGuest.CheckINGuestVisitDetail);
                            //    checkINGuest.CheckINGuestVisitDetail.ProceedToStateId = !checkINGuest.CheckINGuestVisitDetail || !checkINGuest.CheckINGuestVisitDetail.ProceedToStateId ? '' : checkINGuest.CheckINGuestVisitDetail.ProceedToStateId.toString();
                            //    checkINGuest.CheckINGuestVisitDetail.ArrivalViaId = !checkINGuest.CheckINGuestVisitDetail || !checkINGuest.CheckINGuestVisitDetail.ArrivalViaId ? '' : checkINGuest.CheckINGuestVisitDetail.ArrivalViaId.toString();
                            //    checkINGuest.CheckINGuestVisitDetail.ProceedToViaId = !checkINGuest.CheckINGuestVisitDetail || !checkINGuest.CheckINGuestVisitDetail.ProceedToViaId ? '' : checkINGuest.CheckINGuestVisitDetail.ProceedToViaId.toString();
                            //    checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId = !checkINGuest.CheckINGuestVisitDetail || !checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId ? '' : checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId.toString();
                            //}

                            checkINGuest.CheckINGuestExtraCharge = !reservationRoomTypeGuest.ReservationGuestExtraCharges || reservationRoomTypeGuest.ReservationGuestExtraCharges.length < 1 ? {} : reservationRoomTypeGuest.ReservationGuestExtraCharges[0];
                            if (checkINGuest.CheckINGuestExtraCharge && checkINGuest.CheckINGuestExtraCharge.RevenueHeadId)
                                checkINGuest.CheckINGuestExtraCharge.RevenueHeadId = checkINGuest.CheckINGuestExtraCharge.RevenueHeadId.toString();

                            checkINGuest.CheckINGuestDiplomatDetail = !reservationRoomTypeGuest.ReservationGuestDiplomatDetails || reservationRoomTypeGuest.ReservationGuestDiplomatDetails.length < 1 ? {} : reservationRoomTypeGuest.ReservationGuestDiplomatDetails[0];
                            if (checkINGuest.CheckINGuestDiplomatDetail && checkINGuest.CheckINGuestDiplomatDetail.CountryId)
                                checkINGuest.CheckINGuestDiplomatDetail.CountryId = checkINGuest.CheckINGuestDiplomatDetail.CountryId.toString();

                            checkINGuest.CheckINGuestPickupDrop = !reservationRoomTypeGuest.ReservationGuestPickupDrops || reservationRoomTypeGuest.ReservationGuestPickupDrops.length < 1 ? {} : reservationRoomTypeGuest.ReservationGuestPickupDrops[0];
                            if (checkINGuest.CheckINGuestPickupDrop && checkINGuest.CheckINGuestPickupDrop.PickupDropTypeId) {
                                checkINGuest.CheckINGuestPickupDrop.PickupDropTypeId = checkINGuest.CheckINGuestPickupDrop.PickupDropTypeId.toString();
                                checkINGuest.CheckINGuestPickupDrop.LocationTypeId = !checkINGuest.CheckINGuestPickupDrop || !checkINGuest.CheckINGuestPickupDrop.LocationTypeId ? '' : checkINGuest.CheckINGuestPickupDrop.LocationTypeId.toString();
                            }

                            if (reservationRoomTypeGuest.ReservationGuestWorkPermits.length>0) {

                                checkINGuest.CheckINGuestWorkPermit={
                                    
                                    Id             : ''  ,
                                    CheckINGuestId : ''  ,
                                    PermitNo       : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].PermitNo            ,
                                    PermitExpiryOn : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].PermitExpiryOn      ,
                                    IssuedAuthority: reservationRoomTypeGuest.ReservationGuestWorkPermits[0].IssuedAuthority     ,
                                    CompanyName    : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].CompanyName         ,
                                    Designation    : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].Designation         ,
                                    GSTIN          : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].GSTIN               ,
                                    Address1       : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].Address1            ,
                                    Address2       : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].Address2            ,
                                    StateId        : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].StateId.toString()             ,
                                    CountryId      : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].CountryId.toString()           ,
                                    City           : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].City                ,
                                    PIN            : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].PIN                 ,
                                    Mobile         : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].Mobile              ,
                                    EmailId        : reservationRoomTypeGuest.ReservationGuestWorkPermits[0].EmailId             ,
                                    StateList      : [],
                                };
                                checkINGuest.CheckINGuestWorkPermit.StateList.push({Id:reservationRoomTypeGuest.ReservationGuestWorkPermits[0].StateId.toString(), Name: reservationRoomTypeGuest.ReservationGuestWorkPermits[0].StateName});
                            }
                            //if (reservationRoomTypeGuest.SNo == 1 && $scope.Reservation.TotalAdvance > 0 && index==0) {
                            //    angular.forEach($scope.Reservation.ReservationAdvances,function(reservationAdvance){
                            //        $scope.Model.ReservationAdvanceAmount = parseFloat( $scope.Model.ReservationAdvanceAmount ) + parseFloat(reservationAdvance.Amount);
                            //    });
                            //}

                        }
                       
                        if (isGuestFound == false) {
                                                   
                            
                            var availableRooms =[];
                            if($scope.RoomChart)
                            {
                                var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == reservationRoomTypeGuest.RoomTypeId);
                                $scope.GetAvailableRoom(reservationRoomType.ArrivalDate,reservationRoomType.DepartureDate, roomType);
                                availableRooms = roomType.AvailableRooms;
                            }
                            else
                            {
                                //availableRooms = [{Id:reservationRoomType.RoomMasterId,Name: reservationRoomType.RoomNumber,RoomTypeId:reservationRoomType.RoomTypeId,RoomTypeName: reservationRoomType.RoomTypeName}];
                                availableRooms = [{Id:reservationRoomType.RoomMasterId,Name: reservationRoomType.RoomNumber,RoomTypeId:reservationRoomType.RoomTypeId}];
                            }

                            //var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == reservationRoomType.RoomTypeId);
                            //var availableRooms = roomType.AvailableRooms;

                            var checkINGuest = {

                                Id: '',
                                CheckINId: '',
                                CheckINNo: '',
                                CorporateId: $scope.Reservation.CorporateId,
                                SNo: i,//1,
                                FolioNo: '1',
                                GuestId: '',
                                SalutationId: $scope.Reservation.SalutationId.toString(),
                                SalutationName: $scope.Reservation.SalutationName,
                                GenderId: '', //TODO 
                                GenderName: '',
                                FirstName: $scope.Reservation.GuestName,
                                Mobile: $scope.Reservation.MobileNo,
                                EmailId: $scope.Reservation.Email,
                                PaxTypeId: '1',//TODO navneet
                                Nationality: '',
                                IsExtraBed: false,
                                IsGroupLeader:false,

                                RoomINDate: $filter('date')(reservationRoomType.ArrivalDate, $scope.DateFormat),
                                RoomOUTDate:  $filter('date')(reservationRoomType.DepartureDate, $scope.DateFormat),  

                                RoomINTime: '',
                                RoomOUTTime: '',
                                IsRoomOUT: '',

                                NewsPaperId: '',

                                RoomTypeId: reservationRoomType.RoomTypeId,
                                RoomTypeName: reservationRoomType.RoomTypeName,
                                MealPlanId: reservationRoomType.MealPlanId.toString(),
                                ReservationRoomTypeId: reservationRoomType.Id,
                                RoomMasterId: reservationRoomType.RoomMasterId,
                                RoomNumber: reservationRoomType.RoomNumber,

                                GuestClassId: '',
                                CountryMasterId: '',
                                StateId: '',

                                ReservationRoomType: reservationRoomType,
                                ReservationRoomTypeId: reservationRoomType.Id,
                                CheckINGuestRooms: [],
                                //AvailableRooms: [{Id:reservationRoomType.RoomMasterId,Name: reservationRoomType.RoomNumber}],
                                AvailableRooms: availableRooms,

                                StateList: [],
                                LocalStateList: [],

                                CheckINGuestAdvances:[],
                                CheckINAdvance:0,
                                    
                            };

                            var currencyMasterId ='1';
                            if($scope.DefaultSetting)
                            {
                                currencyMasterId = $scope.DefaultSetting.CurrencyMasterId;
                            }

                            checkINGuest.CheckINGuestAdvances.push({ReferenceNo:'',Amount:0,CurrencyMasterId:currencyMasterId.toString(),RevenueHeadCode:'ADC'});
                        }
                            
                        checkINGuest.ReservationRoomTypeRates = angular.copy(reservationRoomType.ReservationRoomTypeRates);
                            
                        $scope.Model.CheckINGuests.push(checkINGuest);
                    }
                }
            });

                
            $scope.Model.CheckINGuests.forEach(function(checkINGuest){

                checkINGuest.FolioNo = checkINGuest.FolioNo.toString();

                if($scope.IsRoomChartActive)
                {
                    var model ={
                        ArrivalDate   :checkINGuest.RoomINDate,
                        DepartureDate :checkINGuest.RoomOUTDate,
                        RoomTypeId    :checkINGuest.RoomTypeId,
                    }
                        
                    $rootScope.$broadcast("CallGetAvailableRoom", model);
                    $timeout(function() { 
                        checkINGuest.AvailableRooms = $scope.AvailableRooms;
                        if(checkINGuest.ReservationRoomType.RoomMasterId)
                        {
                            checkINGuest.AvailableRooms.push({Id:checkINGuest.ReservationRoomType.RoomMasterId,Name:checkINGuest.ReservationRoomType.RoomNumber,RoomTypeId:checkINGuest.ReservationRoomType.RoomTypeId,MaxPerson:checkINGuest.ReservationRoomType.RoomTypeMaxPax});
                        }
                        $scope.ChangeRoom(checkINGuest);
                        $scope.changeGuestCountry(checkINGuest);
                        $scope.getLocalStateList(checkINGuest);

                    }, 40);
                }

                $timeout(function() { 
                    if(!$scope.IsRoomChartActive)
                    {
                        $scope.changeGuestCountry(checkINGuest);
                        $scope.getLocalStateList(checkINGuest);
                    }
                }, 40);

                checkINGuest.CheckINGuestDiscounts=$scope.Reservation.ReservationDiscounts;
            });

            $scope.Model.ReservationInfo = "     Number of Rooms: " + $scope.Reservation.ReservationRoomTypes.length + ", Number of Guests : " + paxCount;

            $scope.SetRoomOwner($scope.Model.CheckINGuests[0]);
            $scope.IsShowExtraBed();
            $scope.SetCheckINGuestRoom();
            $scope.getCorporateDiscountList($scope.Model.CorporateId);//TODO
            $scope.getMessageList(1, 1, $scope.Reservation.Id);

            
            GetRoomChart($scope.Model.CheckINDate,$scope.Model.CheckOUTDate);
            
            //checkINService.getServerTime() //TODO
            //    .then(function (result) {
            //        var cit1 = result.Message.split(':');
            //        var tt = new Date();
            //        $scope.Model.CheckINTimeForDisplayD = new Date(tt.getFullYear(), tt.getMonth(), tt.getDate(), cit1[0], cit1[1], 0);
            //        //$scope.Model.CheckINTimeForDisplayD=new Date(1970, 0, 1, cit1[0], cit1[1], 0);
            //        if ($scope.DefaultSetting) {
            //            $scope.Model.CheckOUTTimeForDisplayD = $scope.DefaultSetting.CheckOUTTypeId === "1" || $scope.DefaultSetting.CheckOUTTypeId === 1 ?
            //                new Date(1970, 0, 1, 12, 0, 0) : new Date(1970, 0, 1, cit1[0], cit1[1], 0);
            //        }
            //    });

            $scope.SetTimeForDisplay();
        }

        $scope.showReservation = function () {
            if (!$scope.SearchReservation.Id) {
                return;
            }
            if ($scope.IsFutureReservation) {
                parent.popErrorMessage('Future Reservation CheckIN is not allowed.');
                return;
            }
            if ($scope.BookingStatusId > 1) {
                parent.popErrorMessage('Waiting/Tentetive reservations are not allowed to CheckIN.');
                return;
            }
            $scope.IsSearchReservation = false;
            $('#modalSearchResersvation').modal('hide');
            if ($scope.SearchReservation.ReservationRoomTypes !== null && $scope.SearchReservation.ReservationRoomTypes.length > 0)
                if ($scope.SearchReservation.ReservationRoomTypes[0].DepartureDate < $scope.ModifiedDate) {
                    msg('Sorry! Reserved departure date is past.');
                    return;
                }

            $scope.IsWalkIN = false;
            $scope.walkinGuest(false);
            $scope.loadReservation($scope.SearchReservation.Id);

        };

        $("#ReservationSearch").autocomplete({
            source: function (request, response) {

                checkINService.SearchReservationList({ PropertyID: $scope.PropertyID, ReservationNo: request.term, IsPending: true, DepartureDateString: $scope.ModifiedDate, ArrivalDateString: $scope.ModifiedDate })
                    .then(function (result) {
                        if (result.Collection.length < 1)
                            response([{ label: "No Records Found", val: -1 }]);
                        else
                            response($.map(result.Collection, function (item) {
                                return {
                                    label: item.ReservationNo,
                                    val: item
                                };
                            }));
                    }, function (err) {
                        msg(err.Message);
                    });
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value === "No Records Found") {
                        ui.item.value = "";
                    } else {
                        $scope.loadReservation(ui.item.val.Id);
                    }
                }
            },
            change: function (e, ui) {

            },
            minLength: 1
        });

        $scope.clickGuestEdit = function (checkINGuest, idx) {
            $scope.IsGuestEdit = true;

            $scope.guest.SalutationId =  $scope.DefaultSetting.SalutationId;
          
            $scope.GuestCheckIn=checkINGuest;

            if(checkINGuest.GuestId)
            {
                checkINService.getGuestHistory($scope.PropertyID, checkINGuest.GuestId)
               .then(function (s) {
                   $scope.guest = s.Data;
                   $scope.guest.SalutationId = $scope.guest.SalutationId.toString();
                   $scope.guest.GuestClassId= $scope.guest.GuestClassId.toString();
                   $scope.Customer=angular.extend({},$scope.Customer,$scope.guest);
                   if($scope.Customer.LPCardIssueDate) $scope.Customer.LPCardIssueDate=  $filter('date')( $scope.Customer.LPCardIssueDate, $scope.DateFormat);
               });
            }
           
            //$scope.guest = checkINGuest;
            //$scope.guest.SalutationId = $scope.guest.SalutationId.toString();
            //$scope.guest.GuestClassId= $scope.guest.GuestClassId.toString();
            //$scope.Customer=angular.extend({},$scope.Customer,$scope.guest);

            $scope.CheckINGuestSaveIndex = idx;
            if (!checkINGuest.Amenitys) checkINGuest.Amenitys = [];
            if (!checkINGuest.NewsPapers) checkINGuest.NewsPapers = [];
            if (!checkINGuest.CountryMasterId) {
                checkINGuest.CountryMasterId = $scope.DefaultSetting.CountryMasterId.toString();
                $scope.changeGuestCountry($scope.guest);
            }
            if (!checkINGuest.CheckINGuestLocalContact) {
                checkINGuest.CheckINGuestLocalContact = {};
            }
            if (!checkINGuest.CheckINGuestLocalContact.CountryMasterId) {
                checkINGuest.CheckINGuestLocalContact.CountryMasterId = $scope.DefaultSetting.CountryMasterId.toString();
                $scope.changeLocalContactCountry(checkINGuest.CheckINGuestLocalContact);
            }
        };

        $scope.clickGuestScan = function (guest, idx) {

            $scope.Document={};
            $scope.IsGuestEdit = true;
            $scope.guest = guest;
            $scope.CheckINGuestSaveIndex = idx;
            $rootScope.$broadcast("CallResetScan", {});
            
        };

        $scope.$on("CallSaveGuestWithPassport", function (event, obj) {
            
            $scope.guest.IssueCountry         =obj.IssueCountry ? obj.IssueCountry : obj.IssueCountry;
            
            $scope.guest.Address1         =obj.Address1 ? obj.Address1 : obj.IssueCountry;
            $scope.guest.Address2         =obj.Address2          ;
            $scope.guest.Address3         =obj.Address3          ;
            $scope.guest.City             =obj.City              ;
            $scope.guest.DOB              =obj.DOB               ;
            $scope.guest.ExpiryDate       =obj.ExpiryDate        ;
            //$scope.guest.ImageUrl         =obj.ImageUrl          ;
            $scope.guest.ImageModel         =obj.ImageModel         ;
            $scope.guest.IssueDate        =obj.IssueDate         ;
            $scope.guest.FirstName             =obj.FirstName              ;
            $scope.guest.LastName             =obj.LastName              ;
            $scope.guest.Nationality      =obj.Nationality       ;
            $scope.guest.PlaceofBirth     =obj.PlaceofBirth      ;
            $scope.guest.IssuePlace       =obj.IssuePlace ? obj.IssuePlace :  obj.IssueCountry;
            $scope.guest.GenderId         =obj.GenderName == 'M' || obj.GenderName == 'Male' ? '1' : '2'         ;
            $scope.guest.GenderName         =obj.GenderName          ;
            $scope.guest.StateName        =obj.StateName         ;
            $scope.guest.PIN              =obj.PIN               ;
            $scope.guest.CountryMasterName=obj.CountryMasterName ;
            $scope.guest.Mobile           =obj.Mobile            ;
            $scope.guest.EmailId          =obj.EmailId           ;
            $scope.guest.IssueCountry     =obj.IssueCountry      ;
            $scope.guest.PassportNo       =obj.PassportNo        ;
            $scope.guest.VisaNo           =obj.VisaNo            ;
            $scope.guest.LicenseNo        =obj.LicenseNo            ;
            $scope.guest.GuestClassId      ='1'            ;
            $scope.guest.StateId           = $scope.DefaultSetting.StateMasterId.toString()            ;
            $scope.guest.SalutationId           = $scope.guest.GenderId == '1' ? '1' : '2'   ;
            $scope.doc ={};
            angular.forEach($scope.DocumentTypes,function(item){
                if(item.Name.toUpperCase().indexOf(obj.DocumentTypeName) !== -1 )
                {
                    var remark='';
                    if($scope.guest.PassportNo)
                    {
                        if($scope.guest.PassportNo.length>0)
                        {
                            remark=$scope.guest.PassportNo;
                        }
                    }
                    if($scope.guest.VisaNo)
                    {
                        if($scope.guest.VisaNo.length>0)
                        {
                            remark=$scope.guest.VisaNo;
                        }
                    }
                    if($scope.guest.LicenseNo)
                    {
                        if($scope.guest.LicenseNo.length>0)
                        {
                            remark=$scope.guest.LicenseNo;
                        }
                    }


                    $scope.doc ={
                        DocumentTypeId  :item.Id,
                        Remarks         :remark,
                        IsExpiry        :true,
                        ExpiryDateString:$scope.guest.ExpiryDate,
                        ImageModel:obj.PassportImageModel
                    };
                }
            });
            
            $scope.guest.GuestDocuments=[];
            $scope.guest.GuestDocuments.push($scope.doc);

            $scope.saveGuestWithPassport($scope.guest);

        });

        $scope.saveGuestWithPassport = function (guest, passDocuments) {
           
            guest.PropertyID = $scope.PropertyID;
            guest.ModifiedBy = $scope.ModifiedBy;
            guest.NationalityCountryId = guest.CountryMasterId;
            var promise = checkINService.saveGuestWithPassport(guest);
            promise.then(function (data) {
                msg("Guest successfully saved.", true);
                
                $scope.Model.CheckINGuests[$scope.CheckINGuestSaveIndex].GuestId = data.Message;
                $scope.GetGuestById(data.Message,$scope.CheckINGuestSaveIndex);

            }, function (err) {
                msg(err.Message);
            });
        };

        $scope.GetGuestById = function(id,idx){
            
            var promise = checkINService.getGuestById(id);
            promise.then(function (data) {
                
                var temp = $scope.Model.CheckINGuests[idx];
                $scope.Model.CheckINGuests[idx] = data.Data;
                $scope.Model.CheckINGuests[idx].SalutationId = data.Data.SalutationId.toString();

                $scope.Model.CheckINGuests[idx].PaxTypeId = data.Data.PaxTypeId.toString();
                $scope.Model.CheckINGuests[idx].GuestId = data.Data.Id;
                $scope.Model.CheckINGuests[idx].ImageUrl = data.Data.ImageUrl;

                if ($scope.Model.CheckINGuests[idx].ImageUrl) {
                    $scope.Model.CheckINGuests[idx].ImageUrlForDisplay = apiPath + $scope.Model.CheckINGuests[idx].ImageUrl;
                }

                try {

                    $scope.Model.CheckINGuests[idx].Id = "";
                    $scope.Model.CheckINGuests[idx].SNo = temp.SNo.toString();

                    $scope.Model.CheckINGuests[idx].FolioNo = temp.FolioNo.toString();
                    $scope.Model.CheckINGuests[idx].IsRoomOwner = temp.IsRoomOwner;

                    $scope.Model.CheckINGuests[idx].CorporateId = temp.CorporateId;
                    $scope.Model.CheckINGuests[idx].CorporateName = temp.CorporateName;

                    $scope.Model.CheckINGuests[idx].MealPlanId = temp.MealPlanId.toString();

                    $scope.Model.CheckINGuests[idx].RoomTypeId = temp.RoomTypeId.toString();
                    $scope.Model.CheckINGuests[idx].RoomTypeName = temp.RoomTypeName;

                    $scope.ChangeRoomType($scope.Model.CheckINGuests[idx]);

                    $scope.Model.CheckINGuests[idx].RoomMasterId = temp.RoomMasterId;
                    $scope.Model.CheckINGuests[idx].RoomNumber = temp.RoomNumber;

                    $scope.Model.CheckINGuests[idx].IsExtraBed = temp.IsExtraBed;
                    $scope.Model.CheckINGuests[idx].IsGroupLeader = temp.IsGroupLeader;

                    $scope.Model.CheckINGuests[idx].GuestClassId = data.Data.GuestClassId.toString();
                    $scope.Model.CheckINGuests[idx].StateId = data.Data.StateId.toString();
                    $scope.Model.CheckINGuests[idx].CountryMasterId = data.Data.CountryMasterId.toString();

                    $scope.Model.CheckINGuests[idx].ReservationRoomType = temp.ReservationRoomType;
                    $scope.Model.CheckINGuests[idx].ReservationRoomTypeRates = temp.ReservationRoomTypeRates;

                    $scope.Model.CheckINGuests[idx].CheckINAdvance = 0;
                    $scope.Model.CheckINGuests[idx].CheckINGuestAdvances = [];
                    
                    $scope.Model.CheckINGuests[idx].CheckINGuestAdvances.push(
                        {
                            ReferenceNo:'',
                            Amount:0,
                            CurrencyMasterId: $scope.DefaultSetting.CurrencyMasterId ? $scope.DefaultSetting.CurrencyMasterId.toString():'1',
                            RevenueHeadCode:'ADC'
                        });
                    
                    $scope.changeGuestCountry(data.Data);
                    $scope.getLocalStateList(data.Data);
                    $scope.IsShowExtraBed();

                    $scope.showBlackListAlert(data.Data.IsBlackList);
                }
                catch (ex) { }

                $rootScope.$broadcast("CallCloseScanBox", {});
            }, function (err) {
                msg(err.Message);
            });
        
           
        
        };

        $scope.saveGuest = function (guest, passDocuments) {
            
            if (!$scope['formEditGuest'].$valid) {
                var count = 0;
                $scope['formEditGuest'].$error.required.forEach(function (e) {
                    if (e.$name !== 'docForm') count++;
                });
                if (count > 0) {
                    $scope.showEmsgs = true;
                    msg('');
                    return;
                }
            }

            if (!passDocuments && $scope.DocumentTypes) {
                var requiredDocs = '', expiredDocs = '';
                $scope.DocumentTypes.forEach(function (t) {

                    if (t.IsRequired) {
                        var found = !guest.GuestDocuments ? null : guest.GuestDocuments.find(x => x.DocumentTypeId == t.Id);
                        if (!found) requiredDocs += t.Name + ' and ';
                        else if (found.ExpiryDateString < $scope.ModifiedDate) expiredDocs += t.Name + ' and ';
                    }
                });
                if (requiredDocs.length > 4 || expiredDocs.length > 4) {
                    if (requiredDocs.lastIndexOf('and') > -1) requiredDocs = requiredDocs.substr(0, requiredDocs.lastIndexOf('and'));
                    if (expiredDocs.lastIndexOf('and') > -1) expiredDocs = expiredDocs.substr(0, expiredDocs.lastIndexOf('and'));
                    var strDelete = DeletePopup("!!WARNING!!<br/><br/>" + (requiredDocs.length > 1 ? requiredDocs + " not attached, " : "") + (expiredDocs.length > 1 ? "<br/>" + expiredDocs + " expired, " : "") + "<br/>Do you want to continue?");
                    var ret;
                    $('#myModal1').hide('slow');
                    $.fancybox({
                        'modal': true,
                        'content': strDelete,
                        'afterShow': function () {
                            $("#fancyconfirm_cancel")
                                .click(function () {
                                    ret = false;
                                    $.fancybox.close();
                                    $('#myModal1').show('slow');
                                    return;
                                });
                            $("#fancyConfirm_ok")
                                .click(function () {

                                    ret = true;
                                    $.fancybox.close();
                                    //$('#myModal1').show('slow');
                                    $scope.saveGuest(guest, true);
                                });
                        }
                    });
                    return;
                }
            }
            guest.PropertyID = $scope.PropertyID;
            guest.ModifiedBy = $scope.ModifiedBy;
            guest.NationalityCountryId = guest.CountryMasterId;
           
            //TODO: As per discussion with manoj ji 05-0-2019
            // angular.extend(guest,$scope.Customer);
            guest.LPCardId = $scope.Customer.LPCardId;
            guest.LPCardNumber = $scope.Customer.LPCardNumber;
            guest.LPCardIssueDate = $scope.Customer.LPCardIssueDate;
            guest.LPOpeningPoints = $scope.Customer.LPOpeningPoints;

            var promise = checkINService.saveGuest(guest);
            promise.then(function (data) {
                msg("Guest successfully saved.", true);

                $scope.Model.CheckINGuests[$scope.CheckINGuestSaveIndex].GuestId = data.Message;

                $('#myModal1').hide('slow');
                $('.modal-backdrop').hide('slow');
                $rootScope.$broadcast("CallCloseScanBox", {});
            }, function (err) {
                msg(err.Message);
            });

            $scope.Model.CheckINGuests.forEach(function(checkINGuest){
                if(checkINGuest.$id==$scope.GuestCheckIn.$id)
                {
                    checkINGuest.CheckINGuestVehicles = [];
                    checkINGuest.CheckINGuestVehicles.push($scope.GuestCheckIn.CheckINGuestVehicle);

                    checkINGuest.CheckINGuestPickupDrops = [];
                    if ($scope.GuestCheckIn.CheckINGuestPickupDrop) {
                        checkINGuest.CheckINGuestPickupDrops.push($scope.GuestCheckIn.CheckINGuestPickupDrop);
                        if ($scope.GuestCheckIn.CheckINGuestPickupDrop.OnTime && !$scope.GuestCheckIn.CheckINGuestPickupDrop.OnDate) {
                            msgInPopup('Please enter pickup drop date.');
                            return;
                        }
                        if ($scope.GuestCheckIn.CheckINGuestPickupDrop.OnDate) checkINGuest.CheckINGuestPickupDrop.PickupDropTypeId = 2;
                    }
                }
            
            });

        };
        $scope.deleteGuest = function (index) {
            $scope.Model.CheckINGuests.splice(index, 1);
            $scope.Model.TotalPax = $scope.Model.CheckINGuests.length;
            $scope.ResetRate();
        };
        $scope.changeGuestCountry = function (guest) {
            if (!guest.CountryMasterId) return;
            checkINService.getStateList(guest.CountryMasterId)
                .then(function (result) {

                    guest.StateList = result.Collection;
                    var tcountry = $scope.Countrys.find(x => x.Id.toString() === guest.CountryMasterId);
                    guest.Nationality = tcountry ? tcountry.Nationality : null;
                    if (!guest.StateId) guest.StateId = $scope.DefaultSetting.StateMasterId.toString();
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.changeLocalContactCountry = function (g) {
            if (!g.CountryMasterId) return;
            checkINService.getStateList(g.CountryMasterId)
                .then(function (result) {

                    g.StateList = result.Collection;
                    var tcountry = $scope.Countrys.find(x => x.Id.toString() === g.CountryMasterId);
                    g.Nationality = tcountry ? tcountry.Nationality : null;
                    if (!g.StateId) g.StateId = $scope.DefaultSetting.StateMasterId.toString();
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getLocalStateList = function (guest) {

            checkINService.getStateList(95)
                .then(function (result) {

                    guest.LocalStateList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.changeArrivingCountry = function (guest) {
            if (!guest.ArrivalCountryId) return;
            checkINService.getStateList(guest.ArrivalCountryId)
                .then(function (result) {

                    guest.ArrivingStateList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.changeProceedingCountry = function (guest) {
            if (!guest.ProceedToCountryId) return;
            checkINService.getStateList(guest.ProceedToCountryId)
                .then(function (result) {

                    guest.ProceedToStateList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.changeWorkCountry = function (guest) {
            if (!guest.CountryId) return;
            checkINService.getStateList(guest.CountryId)
                .then(function (result) {

                    guest.StateList = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });
        };

        $scope.addDiscount = function (dis, guest) {

            if (!guest.CheckINGuestDiscounts) guest.CheckINGuestDiscounts = [];
            dis.DiscountTypeName = dis.DiscountTypeId == "1" ? "Amount" : "Percentage";
            var rhead = $scope.RevenueHeads.find(x => x.Id === dis.RevenueHeadId);
            dis.RevenueHeadName = rhead == null ? "" : rhead.Name;
            guest.CheckINGuestDiscounts.push(angular.copy(dis));

        };
        $scope.deleteGuestDiscount = function (guest, index) {

            if (!guest.CheckINGuestDiscounts) return;
            guest.CheckINGuestDiscounts.splice(index, 1);

        };
        $scope.getCorporateDiscountList = function (corporateId) {
            var promise = checkINService.getCorporateDiscountList($scope.PropertyID, corporateId);
            promise.then(function (data) {
                $scope.CorporateDiscountList = data.Collection;
            });
        };
        $scope.changeDiscountCode = function (guest) {
            guest.CheckINGuestDiscounts = [];
            var heads = angular.fromJson(guest.CorporateDiscount);
            if (!heads || !heads.CorporateDiscountRevenueHeads) return;
            angular.forEach(heads.CorporateDiscountRevenueHeads, function (rhead) {
                guest.CheckINGuestDiscounts.push(angular.copy(rhead));
            });
        };

        $scope.checkRoomMaxPerson = function (room, guest) {

            var guests = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == room.Id && x.PaxTypeId == 1);
            var guestCount = guests ? guests.length : 0;
            var rightCount = guestCount <= room.MaxPerson;
            if (!rightCount) {
                msg('Number of person in this room ' + guestCount + ' cannot exceed max limit ' + room.MaxPerson);
                guest.RoomMasterId = "";
                guest.RoomNumber = "";

            }
            return rightCount;
        };
        $scope.walkinGuest = function (isWalkIn) {
            
            tempRooms = [];
            $scope.CorporateRates = [];
            $scope.IsWalkIN = isWalkIn;
            $scope.reset();
            if (isWalkIn) {
                $scope.Model.CheckINDate = $scope.ModifiedDate;
                $scope.Model.CheckOUTDate = $scope.DepartureDate ? $scope.DepartureDate : dateAdd($scope.ModifiedDate, 'day', 1, $filter);
                //$scope.Model.ReservationAdvanceAmount=0;

                $scope.walkinNights();
                $scope.Model.TotalPax = 1;
                $scope.Model.CheckINTimeMax = moment().add(1, 'day').format('hh:mm A');//.add(5, 'minute')

                //checkINService.getServerTime()
                //    .then(function (result) {
                //        var cit1 = result.Message.split(':');
                //        var tt = new Date();
                //        $scope.Model.CheckINTimeForDisplayD = new Date(tt.getFullYear(), tt.getMonth(), tt.getDate(), cit1[0], cit1[1], 0);
                //        if ($scope.DefaultSetting) {
                //            $scope.Model.CheckOUTTimeForDisplayD = $scope.DefaultSetting.CheckOUTTypeId === "1" || $scope.DefaultSetting.CheckOUTTypeId === 1 ?
                //                new Date(1970, 0, 1, 12, 0, 0) : new Date(1970, 0, 1, cit1[0], cit1[1], 0);
                //            $scope.Model.BusinessSourceId = $scope.DefaultSetting.BusinessSourceId.toString();
                //            $scope.Model.CurrencyMasterId = $scope.DefaultSetting.CurrencyMasterId.toString();
                //            $scope.Model.RevenueHeadId = $scope.DefaultSetting.RevenueHeadId;
                //        }
                //    });

                $scope.SetTimeForDisplay();
                
                $scope.Model.BusinessSourceId = $scope.DefaultSetting.BusinessSourceId.toString();
                $scope.Model.CurrencyMasterId = $scope.DefaultSetting.CurrencyMasterId.toString();
                $scope.Model.RevenueHeadId = $scope.DefaultSetting.RevenueHeadId;
                
                $scope.addGuest();
                $scope.ReservationSearch = "";
                $scope.resetAdvance();
            }
            else
            {
                $scope.RoomChart=null;
            }
        };

        $scope.IsRoomChartActive=false;
        $scope.$on("CallWalkIN", function (event, obj) {
            
            $scope.IsRoomChartActive=true;
            
            if(obj.IsWalkIN)
            {

                $scope.RoomChart = obj.RoomChart;
                $scope.ArrivalDate = obj.ArrivalDate;
                $scope.DepartureDate = obj.DepartureDate;
                $scope.RoomTypeId=obj.RoomTypeId,
                $scope.RoomTypeCode    =obj.RoomTypeCode   ,
                $scope.RoomTypeName    =obj.RoomTypeName   ,
                $scope.TotalRoom       =obj.TotalRoom      ,
                $scope.OverBooking     =obj.OverBooking    ,
                $scope.MaxPax          =obj.MaxPax         ,
                $scope.Advance         =obj.Advance        ,
                $scope.RoomMasterId    =obj.RoomMasterId   ,
                $scope.RoomNumber      =obj.RoomNumber     ,
                $scope.AvailableRooms  =obj.AvailableRooms ,
                $scope.Availabilitys   =obj.Availabilitys  ,
                $scope.Rooms           =obj.Rooms          ,
                
                //$scope.ArrivalDate = obj.ArrivalDate;
                //$scope.DepartureDate = obj.DepartureDate;
                //$scope.RoomTypeId = obj.RoomTypeId;
                //$scope.RoomMasterId = obj.RoomMasterId;
                //$scope.RoomNumber = obj.RoomNumber;
                //$scope.RoomList= obj.AvailableRooms;

                $scope.walkinGuest(true);
            }
            
        });

        $scope.walkinNights = function () {
            
            if (!$scope.Model.CheckINDate || !$scope.Model.CheckOUTDate) return;
            if ($scope.Model.CheckINDate > $scope.Model.CheckOUTDate) $scope.Model.CheckOUTDate = dateAdd($scope.Model.CheckINDate, 'day', 1, $filter);
            var days = GetDays($filter('date')( $scope.Model.CheckINDate, $scope.DateFormat),$filter('date')( $scope.Model.CheckOUTDate, $scope.DateFormat),$scope.DateFormat);
            $scope.Model.Nights  =days.length-1;
            //reset rooms
            $scope.resetGuestRooms();

            if(!$scope.IsRoomChartActive)            
            {
                GetRoomChart($scope.Model.CheckINDate,$scope.Model.CheckOUTDate);
            }
            
        };

        $scope.pickGuestByName = function (guest, idx) {
            if (!guest.FirstName) return;
            var promise = checkINService.getAllGuestByName($scope.PropertyID, guest.FirstName);
            promise.then(function (data) {
                $("#nameSearch" + idx).autocomplete({
                    source: function (request, response) {
                        response($.map(data.Collection, function (ret) {

                            return {
                                label: ret.FirstName + ' ' + ret.Mobile ,
                                val: ret
                            }
                        }));
                    },
                    select: function (e, ui) {

                        if (ui.item) {
                            if (ui.item.value !== "No Record Found!") {
                                
                                $timeout(function () {
                                    $scope.GetGuestById(ui.item.val.Id,idx);
                                },300);
                                
                                try {

                                    $scope.Model.CheckINGuests[idx].FolioNo = temp.FolioNo.toString();
                                    $scope.Model.CheckINGuests[idx].MealPlanId = temp.MealPlanId.toString();
                                                                        
                                    $scope.Model.CheckINGuests[idx].RoomTypeId = temp.RoomTypeId.toString();
                                    $scope.Model.CheckINGuests[idx].RoomTypeName = temp.RoomTypeName;

                                    $scope.ChangeRoomType($scope.Model.CheckINGuests[idx]);

                                    $scope.Model.CheckINGuests[idx].RoomMasterId = temp.RoomMasterId;
                                    $scope.Model.CheckINGuests[idx].RoomNumber = temp.RoomNumber;
                                    $scope.Model.CheckINGuests[idx].RoomINDate = temp.RoomINDate;
                                    $scope.Model.CheckINGuests[idx].RoomOUTDate = temp.RoomOUTDate;

                                    $scope.Model.CheckINGuests[idx].IsExtraBed = temp.IsExtraBed;
                
                                    $scope.Model.CheckINGuests[idx].IsGroupLeader = temp.IsGroupLeader;

                                    $scope.Model.CheckINGuests[idx].GuestClassId = ui.item.val.GuestClassId.toString();
                                    $scope.Model.CheckINGuests[idx].StateId = ui.item.val.StateId.toString();
                                    $scope.Model.CheckINGuests[idx].CountryMasterId = ui.item.val.CountryMasterId.toString();

                                    $scope.Model.CheckINGuests[idx].ReservationRoomType = temp.ReservationRoomType;
                                    $scope.Model.CheckINGuests[idx].ReservationRoomTypeRates = temp.ReservationRoomTypeRates;

                                    $scope.Model.CheckINGuests[idx].CheckINGuestRoom = temp.CheckINGuestRoom;

                                    $scope.Model.CheckINGuests[idx].CheckINAdvance = 0;
                                    $scope.Model.CheckINGuests[idx].CheckINGuestAdvances = [];
                                    $scope.Model.CheckINGuests[idx].CheckINGuestAdvances.push({ReferenceNo:'',Amount:0,CurrencyMasterId:$scope.DefaultSetting.CurrencyMasterId.toString(),RevenueHeadCode:'ADC'});
                                    
                                    $scope.changeGuestCountry(ui.item.val);
                                    $scope.getLocalStateList(ui.item.val);
                                    $scope.IsShowExtraBed();

                                    $scope.showBlackListAlert(ui.item.val.IsBlackList);
                                }
                                catch (ex) { }
                            }
                        }
                    }
                });
            });
        };

        $scope.pickGuest = function (guest, idx) {
            if (!guest.Mobile || isNaN(guest.Mobile)) return;
            var promise = checkINService.getAllGuestByMobile($scope.PropertyID, guest.Mobile);
            promise.then(function (data) {
                $("#mobileSearch" + idx).autocomplete({
                    source: function (request, response) {
                        response($.map(data.Collection, function (ret) {

                            return {
                                label: ret.Mobile + ' : ' + ret.Name,
                                val: ret
                            }
                        }));
                    },
                    select: function (e, ui) {

                        if (ui.item) {
                            if (ui.item.value !== "No Record Found!") {
                                $timeout(function () {
                                    $scope.GetGuestById(ui.item.val.Id,idx);
                                },300);

                                $scope.Model.CheckINGuests[idx].CheckINAdvance = 0;
                                $scope.Model.CheckINGuests[idx].CheckINGuestAdvances = [];
                               
                                $scope.Model.CheckINGuests[idx].CheckINGuestAdvances.push(
                                   {
                                       ReferenceNo:'',
                                       Amount:0,
                                       CurrencyMasterId: $scope.DefaultSetting.CurrencyMasterId ? $scope.DefaultSetting.CurrencyMasterId.toString():'1',
                                       RevenueHeadCode:'ADC'
                                   });
                                
                            }
                        }
                    }
                });
            });
        };

        $scope.showBlackListAlert = function (isBlackList, type) {
            if (!isBlackList) return;
            msg('This ' + (type === 'c' ? 'Corporate' : 'Guest') + ' is black listed, so be cautious.');

        };

        var tempRooms = [];
        
        $scope.SetIsShowExtraBed = function () {
            var getDistinctRoomIds = $scope.GetDistinctRoomId($scope.Model.CheckINGuests);
            getDistinctRoomIds.forEach(function (roomid) {
                var i = 0;
                $scope.Model.CheckINGuests.forEach(function (guest) {
                   
                    guest.FolioNo = guest.FolioNo.toString();
                                
                    if (roomid == guest.RoomMasterId) {
                        guest.IsShowExtraBed = false;
                        i++;
                        if (i > 1) {
                            guest.IsShowExtraBed = true;
                        }
                    }
                });
            });

            //$scope.SetRoomOwner();

        };

        $scope.IsAsExtraBedSelected = false;
        $scope.SetGuests = function (previousGuests, guest) {

            $scope.Model.TempCheckINGuests = angular.copy($scope.Model.CheckINGuests.filter(x => !x.Id || x.Id === ''));

            $scope.Model.CheckINGuests = [];
            angular.forEach(previousGuests, function (checkINGuest) {
                
                checkINGuest.Id = checkINGuest.Id;
                checkINGuest.IsCheckedIN = true;

                checkINGuest.SalutationId = checkINGuest.SalutationId.toString();
                //checkINGuest.CountryMasterId = checkINGuest.CountryMasterId.toString();
                checkINGuest.StateId = checkINGuest.StateId.toString();
                $scope.changeGuestCountry(checkINGuest);
                checkINGuest.GenderId = checkINGuest.GenderId.toString();
                checkINGuest.PaxTypeId = checkINGuest.PaxTypeId.toString();
                //checkINGuest.MealPlanId=!checkINRoom.MealPlanId?'': checkINRoom.MealPlanId.toString();
                checkINGuest.CheckINGuestVisitDetail = checkINGuest.CheckINGuestVisitDetails && checkINGuest.CheckINGuestVisitDetails.length > 0 ? checkINGuest.CheckINGuestVisitDetails[0] : null;
                if (checkINGuest.CheckINGuestVisitDetail) {
                    checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId = checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId.toString();
                    checkINGuest.CheckINGuestVisitDetail.ArrivalStateId = checkINGuest.CheckINGuestVisitDetail.ArrivalStateId.toString();
                    $scope.changeArrivingCountry(checkINGuest.CheckINGuestVisitDetail);
                    checkINGuest.CheckINGuestVisitDetail.ProceedToCountryId = checkINGuest.CheckINGuestVisitDetail.ProceedToCountryId.toString();
                    checkINGuest.CheckINGuestVisitDetail.ProceedToStateId = checkINGuest.CheckINGuestVisitDetail.ProceedToStateId.toString();
                    $scope.changeProceedingCountry(checkINGuest.CheckINGuestVisitDetail);
                    checkINGuest.CheckINGuestVisitDetail.ArrivalViaId = checkINGuest.CheckINGuestVisitDetail.ArrivalViaId.toString();

                    checkINGuest.CheckINGuestVisitDetail.ProceedToViaId = checkINGuest.CheckINGuestVisitDetail.ProceedToViaId.toString();
                    checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId = checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId.toString();
                }
                $scope.getGuestHistory(checkINGuest);

                checkINGuest.checkINGuestVehicle = checkINGuest.CheckINGuestVehicles && checkINGuest.CheckINGuestVehicles.length > 0 ? checkINGuest.CheckINGuestVehicles[0] : null;
                $scope.getLocalStateList(checkINGuest);
                checkINGuest.CheckINGuestLocalContact = checkINGuest.CheckINGuestLocalContacts && checkINGuest.CheckINGuestLocalContacts.length > 0 ? checkINGuest.CheckINGuestLocalContacts[0] : null;
                if (checkINGuest.CheckINGuestLocalContact) checkINGuest.CheckINGuestLocalContact.StateId = checkINGuest.CheckINGuestLocalContact.StateId.toString();

                checkINGuest.CheckINGuestWorkPermit = checkINGuest.CheckINGuestWorkPermits && checkINGuest.CheckINGuestWorkPermits.length > 0 ? checkINGuest.CheckINGuestWorkPermits[0] : null;
                if (checkINGuest.CheckINGuestWorkPermit) {
                    checkINGuest.CheckINGuestWorkPermit.CountryId = checkINGuest.CheckINGuestWorkPermit.CountryId.toString();
                    checkINGuest.CheckINGuestWorkPermit.StateId = checkINGuest.CheckINGuestWorkPermit.StateId.toString();
                    $scope.changeWorkCountry(checkINGuest.CheckINGuestWorkPermit);
                }

                //Room Rate

                var checkINGuestRoomRates = [];
                angular.forEach(checkINGuest.CheckINGuestRoom.CheckINGuestRoomRates, function (checkINGuestRoomRate) {

                    var checkINDate = GetJavaScriptDate($scope.Model.CheckINDate, "YYYY-MM-DD", 0);
                    var checkOUTDate = GetJavaScriptDate($scope.Model.CheckOUTDate, "YYYY-MM-DD", 0);
                    var chargeDate = GetJavaScriptDate($filter("date")(checkINGuestRoomRate.ChargeDate, $scope.DateFormat), $scope.DateFormat, 0);
                    if (checkINDate.getDate() <= chargeDate.getDate() && checkOUTDate.getDate() > chargeDate.getDate()) {
                        checkINGuestRoomRate.ChargeDate = $filter("date")(checkINGuestRoomRate.ChargeDate, $scope.DateFormat);
                        
                        checkINGuestRoomRate.RateDiscountInId = checkINGuestRoomRate.RateDiscountInId.toString();

                        checkINGuestRoomRates.push(checkINGuestRoomRate);
                    }

                });
                
                checkINGuest.FolioNo = checkINGuest.FolioNo.toString();

                checkINGuest.CheckINGuestRoom.CheckINGuestRoomRates = checkINGuestRoomRates;

                checkINGuest.RoomTypeId = checkINGuest.CheckINGuestRoom.RoomTypeId;
                checkINGuest.RoomTypeName = checkINGuest.CheckINGuestRoom.RoomTypeName;
                checkINGuest.RoomMasterId = checkINGuest.CheckINGuestRoom.RoomMasterId;
                checkINGuest.RoomNumber = checkINGuest.CheckINGuestRoom.RoomNumber;

                checkINGuest.MealPlanId = checkINGuest.CheckINGuestRoom.MealPlanId.toString();
                checkINGuest.RateMasterId = checkINGuest.CheckINGuestRoom.RateMasterId;
                checkINGuest.RateMasterCode = checkINGuest.CheckINGuestRoom.RateMasterCode;
                
                checkINGuest.CheckINAdvance = guest.CheckINAdvance;
                checkINGuest.CheckINGuestAdvances = guest.CheckINGuestAdvances;
                $scope.ChangeRoomType(checkINGuest);
                
                $scope.Model.CheckINGuests.push(checkINGuest);
            });
            
            angular.forEach($scope.Model.TempCheckINGuests, function (item) {

                if ($scope.IsAsExtraBedSelected) {
                    item.IsExtraBed = true;
                }

                
                var foliono = 1;
                var selectedFolio = previousGuests.find(x => x.IsSelected == true);
                if (selectedFolio) {
                    item.FolioNo = selectedFolio.FolioNo;
                    item.IsRoomOwner=false;
                }
                else {
                    selectedFolio = Math.max.apply(Math, previousGuests.map(function (item) { return item.FolioNo; }));
                    if (selectedFolio) {
                        item.FolioNo = parseInt(selectedFolio) + 1;
                    }
                    else {
                        item.FolioNo = 1;
                    }
                }
                
                item.FolioNo = item.FolioNo.toString();
                $scope.Model.CheckINGuests.push(item);
            });

            //23-05-2019
            //$scope.SetRoomOwner();

            $scope.SetSNo();
            $scope.SetCheckINGuestRoom();

        };

        $scope.SetSNo = function () {
            //IMP: Skip Reseting SNo if Reservation CheckIN 
            if ($scope.Reservation) {
                if ($scope.Reservation.Id) {
                    return;
                }
            }
            var i = 1;
            angular.forEach($scope.Model.CheckINGuests, function (item) {
                item.SNo = i;
                i++;
            });
        };

        $scope.GetDistinctRoomId = function (list) {
            var distinctRoomMasterId = [];
            var newArr = list.filter(function (el) {
                if (distinctRoomMasterId.indexOf(el.RoomMasterId) === -1) {
                    // If not present in array, then add it
                    distinctRoomMasterId.push(el.RoomMasterId);
                    return true;
                }
                else {
                    // Already present in array, don't add it
                    return false;
                }
            });
            return distinctRoomMasterId;
        };

        $scope.resetAdvance = function (rate) {

            if (!rate) return;
            rate.Advance = {};
            if (!$scope.DefaultSetting) return;
            rate.Advance.CurrencyId = $scope.DefaultSetting.CurrencyMasterId.toString();
            rate.Advance.RevenueHeadId = $scope.DefaultSetting.RevenueHeadId;

        };

        $scope.$on("CallResetCheckIN", function (event, obj) {
            $scope.ArrivalDate = '';
            $scope.DepartureDate = '';
            $scope.RoomTypeId = '',
            $scope.RoomMasterId = '',
            $scope.reset();
        });

        $scope.reset = function () {
            msg('');
            $scope.IsInterPropertyTransfer = false;
            $scope.Reservation = {};
            $scope.ReservationSearch = "";
            $scope.IsGuestEdit = false;
            $scope.Model = {};
            $scope.Model.CheckINGuests = [];
            $scope.Model.IsRateDisplay = true;
            $scope.IsSaved = true;
            $scope.IsDiscountManual = false;
            $scope.ActiveCamera = [];
            $scope.ActiveSignature = [];
            try {
                $scope.guest = {
                    CountryMasterId: $scope.DefaultSetting.CountryMasterId.toString(),
                    IssueCountry: $scope.DefaultSetting.CountryMasterId.toString(),
                    States: [],
                };
                $scope.guest.States = $scope.GetStateByCountry($scope.guest.CountryMasterId);
                $scope.guest.StateId = $scope.DefaultSetting.StateMasterId.toString();
            }
            catch (e) { }
            $scope.CheckINGuestRooms = [];
            $('#body').removeClass("disablewholepage");
            $scope.formdata1 = new FormData();
        };
        $scope.ResetReservationSearch = function () {
            $scope.SearchModel = { ReservationStatusId: 1, IsExactSearch: true };
            $scope.IsLocationSearch = false;
            $scope.SearchReservationList = [];
        };
        $scope.SetResetCorporate = function () {

            if (!$scope.Model.IsCorporateGuest) {
                angular.forEach($scope.Model.CheckINGuests, function (item) {
                    item.CorporateId = '';
                    item.CorporateName = '';
                });
            }
        };

        $scope.save = function (form) {
            
            if (!$scope.RoomOwnerValidation()) {
                msg('Please Select Room Owner.');
                return;
            }

            if (!$scope.IsWalkIN && (!$scope.Reservation || !$scope.Reservation.Id) && !$scope.IsInterPropertyTransfer) {
                msg('Please Select Reservation.');
                return;
            }

           
            
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                msg('');
                if (form == 'myform' && !$scope[form]['formGuest'].$valid) {
                    $scope.showGmsgs = true;
                }
                return;
            }
            var IsExistCorporateId = false;
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                if (checkINGuest.CorporateId) {
                    IsExistCorporateId = true;
                }
            });
            if ($scope.Model.IsCorporateGuest == true) {
                if (!IsExistCorporateId) {
                    msg("Please select at least one Corporate.");
                    return;
                }
            }
            //changedate formate
            angular.forEach($scope.CheckINGuestRooms, function (item) {
                angular.forEach(item.CheckINGuestRoomRates, function (rate) {
                    rate.ChargeDate = GetServerDate(rate.ChargeDate, $scope.DateFormat);
                });
            });
            //var someNew=false;
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                
                checkINGuest.RoomINDate = GetServerDate(checkINGuest.RoomINDate, $scope.DateFormat);
                checkINGuest.RoomOUTDate = GetServerDate(checkINGuest.RoomOUTDate, $scope.DateFormat);
                checkINGuest.ReservationRoomType = null;

                if (!checkINGuest.GuestId) {
                    checkINGuest.Guest = {
                        SalutationId: checkINGuest.SalutationId,
                        FirstName: checkINGuest.FirstName,
                        LastName: checkINGuest.LastName,
                        Mobile: checkINGuest.Mobile,
                        Address1: checkINGuest.FirstName,
                        StateId: $scope.DefaultSetting.StateMasterId.toString(),
                        GuestClassId: '1',
                        EmailId: checkINGuest.EmailId,
                    };
                }
                checkINGuest.CheckINGuestRooms = [];
                
                //push guest room       
                angular.forEach($scope.CheckINGuestRooms, function (item) {
                    if (item.RoomMasterId == checkINGuest.RoomMasterId && item.FolioNo == checkINGuest.FolioNo) {
                        checkINGuest.CheckINGuestRoom = item;
                    }
                });

                checkINGuest.CheckINGuestVehicles = [];
                checkINGuest.CheckINGuestVehicles.push(checkINGuest.CheckINGuestVehicle);
                checkINGuest.CheckINGuestLocalContacts = [];
                if (checkINGuest.CheckINGuestLocalContact) {
                    if (checkINGuest.CheckINGuestLocalContact.Name && checkINGuest.CheckINGuestLocalContact.Name.length > 1) checkINGuest.CheckINGuestLocalContacts.push(checkINGuest.CheckINGuestLocalContact);
                }

                checkINGuest.CheckINGuestVisitDetails = [];
                checkINGuest.CheckINGuestVisitDetails.push(checkINGuest.CheckINGuestVisitDetail);
                checkINGuest.CheckINGuestWorkPermits = [];
                checkINGuest.CheckINGuestWorkPermits.push(checkINGuest.CheckINGuestWorkPermit);

                checkINGuest.CheckINGuestExtraCharges = [];
                checkINGuest.CheckINGuestExtraCharges.push(checkINGuest.CheckINGuestExtraCharge);
                checkINGuest.CheckINGuestDiplomatDetails = [];
                checkINGuest.CheckINGuestDiplomatDetails.push(checkINGuest.CheckINGuestDiplomatDetail);
                checkINGuest.CheckINGuestPickupDrops = [];
                if (checkINGuest.CheckINGuestPickupDrop) {
                    checkINGuest.CheckINGuestPickupDrops.push(checkINGuest.CheckINGuestPickupDrop);
                    if (checkINGuest.CheckINGuestPickupDrop.OnTime && !checkINGuest.CheckINGuestPickupDrop.OnDate) {
                        msgInPopup('Please enter pickup drop date.');
                        return;
                    }
                    if (checkINGuest.CheckINGuestPickupDrop.OnDate) checkINGuest.CheckINGuestPickupDrop.PickupDropTypeId = 2;
                }
            });

            $scope.Model.PropertyID = $scope.PropertyID;
            $scope.Model.ModifiedBy = $scope.ModifiedBy;
            $scope.Model.DateFormat = $scope.DateFormat;
            $scope.Model.BusinessDate = businessDateStr;
            $scope.Model.FOShiftId = $scope.FOShiftId;
            
            $scope.Model.CheckINTimeForDisplay = $scope.Model.CheckINTimeForDisplayD;
            $scope.Model.CheckOUTTimeForDisplay = $scope.Model.CheckOUTTimeForDisplayD;

            $('#body').addClass("disablewholepage");
            $scope.IsSaved = false;
            $scope.ProgressStart();
            var paxCount = $scope.Model.CheckINGuests.length;
            
            var promise;
            promise = checkINService.saveWalkIN($scope.Model);
            promise.then(function (d) {

                $scope.IsSaved = true;
                $scope.ProgressEnd();
                
                var reservationRoomTypeDeletes=[];
                angular.forEach($scope.Model.CheckINGuests,function(checkINGuest){
                    if(checkINGuest.ReservationRoomTypeId)
                    {
                        reservationRoomTypeDeletes.push({Id:checkINGuest.ReservationRoomTypeId});
                    }
                });

                msg('Checked In Sucessfully. Preparing to print', true);

                var m1 = d.Message.split(" ");
                var pid = m1.pop();
                var retCheckInId = m1.filter(function (item) {
                    return item.indexOf('CheckINId:') > -1;
                })[0];

                if (!retCheckInId) msg('CheckInId not found.');
                else {
                    checkINService.get($scope.PropertyID, retCheckInId.substr(10))
                        .then(function (s) {
                            $scope.model1 = s.Data;
                            $scope.model1.pid = pid;
                            $scope.model1.PaxCount = paxCount;
                            $scope.OpenSendEmail();

                            
                            var checkINGuestRooms =[];
                            angular.forEach($scope.model1.CheckINGuests,function(checkINGuest){
                                checkINGuest.IsSelected = false;
                                var checkINGuestRoom = checkINGuest.CheckINGuestRooms[0];

                                
                                var roomINDate = $filter("date")(checkINGuest.RoomINDate, 'dd-MMM-yyyy'); 
                                var roomOUTDate = $filter("date")(checkINGuest.RoomOUTDate, 'dd-MMM-yyyy'); 
                                
                                content = "7$" + checkINGuestRoom.Id + "$" + checkINGuest.CheckINId + "$" + $scope.model1.CheckINNos + "$" + checkINGuest.FirstName.toUpperCase() + "$" + roomINDate + "$" + roomOUTDate + "$" + checkINGuest.Nights;
                                checkINGuestRooms.push({
                                    Id:checkINGuestRoom.Id,
                                    CheckINId:checkINGuest.CheckINId,
                                    RoomTypeId: checkINGuestRoom.RoomTypeId,
                                    RoomMasterId: checkINGuestRoom.RoomMasterId,
                                    RoomNumber: checkINGuestRoom.RoomNumber,

                                    RoomINDate:checkINGuest.RoomINDate,
                                    RoomOUTDate:checkINGuest.RoomOUTDate,
                                    Content : content,
                                
                                });
                            });

                            $scope.CallCloseRoomChartCheckIN(checkINGuestRooms,reservationRoomTypeDeletes);
                        });
                }
                $scope.reset();
                

            }, function (error) {

                angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                    checkINGuest.RoomINDate = GetLocalDate(checkINGuest.RoomINDate, $scope.DateFormat);
                    checkINGuest.RoomOUTDate = GetLocalDate(checkINGuest.RoomOUTDate, $scope.DateFormat);
                });

                angular.forEach($scope.CheckINGuestRooms, function (item) {
                    angular.forEach(item.CheckINGuestRoomRates, function (rate) {
                        rate.ChargeDate = GetLocalDate(rate.ChargeDate, $scope.DateFormat);
                    });
                });
                $scope.IsSaved = true;
                $scope.ProgressEnd();
                scrollPageOnTop();
                msg(error.Message);
                $scope.ProgressEnd();
            });
        };

        $scope.CallCloseRoomChartCheckIN = function (checkINGuestRooms,reservationRoomTypeDeletes) {
            $scope.IsRoomChartActive=false;
            $rootScope.$broadcast("CallCloseRoomChartCheckIN", {CheckINGuestRooms : checkINGuestRooms,ReservationRoomTypeDeletes:reservationRoomTypeDeletes});
        }

        $scope.sendCheckINEMail = function () {
            
            $scope.CheckINEMailModel={};
            $scope.CheckINEMailModel.ModifiedBy = $scope.UserName;
            $scope.CheckINEMailModel.PropertyID = $scope.PropertyID;
            $scope.CheckINEMailModel.CheckINGuests=[];
            angular.forEach($scope.model1.CheckINGuests,function(checkINGuest){
                if(checkINGuest.IsSelected)
                {
                    $scope.CheckINEMailModel.CheckINGuests.push({Id:checkINGuest.Id});
                }
            });

            if($scope.CheckINEMailModel.CheckINGuests.length==0)
            {
                msg("Please Select at least one CheckIN Guest.");
                return;
            }

            var promiseGet = checkINService.sendCheckINEMail($scope.CheckINEMailModel);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    parent.posSuccessMessage("EMail sent successfully.");
                    scrollPageOnTop();
                }
            },
                function (error, status) {
                    if (error.Message) {
                        alert(error.Message);
                    }
                    else if (error.responseJSON) {
                        alert(error.responseJSON.Message);
                    }
                    scrollPageOnTop();
                });

        }


        $scope.SendEMail = function () {
            $scope.EMailTemplate.ModifiedBy = $scope.UserName;
            $scope.EMailTemplate.PropertyID = $scope.PropertyID;
            $scope.EMailTemplate.SendOn = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day
            var promiseGet = service.sendEMail($scope.EMailTemplate);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    $("#emailTemplate").modal('hide');
                    parent.posSuccessMessage("EMail sent successfully.");
                    scrollPageOnTop();
                }
            },
                function (error, status) {
                    if (error.Message) {
                        alert(error.Message);
                    }
                    else if (error.responseJSON) {
                        alert(error.responseJSON.Message);
                    }
                    scrollPageOnTop();
                });

        }
        $scope.SendSMS = function (model) {

            model.ModifiedBy = $scope.UserName;
            model.PropertyID = $scope.PropertyID;

            service.sendSMS(model)
                .then(function (s) {
                    if (s) {
                        parent.posSuccessMessage(data.Message);
                    }
                }, function (e) {
                    parent.posErrorMessage(e.Message);
                    scrollPageOnTop();
                });

        };

        $scope.GetAddEMailTemplate = function (model) {
            model.PropertyID = $scope.PropertyID;
            var promiseGet = service.getAddEMailTemplate(model);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    $scope.EMailTemplate = data.Data;
                    $("#emailTemplate").modal('show');
                    scrollPageOnTop();
                }
            },
                function (error, status) {

                    if (error.Message) {
                        parent.popErrorMessage(error.Message);
                    }
                    else {
                        parent.popErrorMessage(error.responseJSON.Message);
                    }

                    scrollPageOnTop();
                });

        }
        
        $scope.printReport = function (checkINGuestId,reportName) {
            checkINService.MapReport($scope.PropertyID, reportName)
                .then(function (s) {
                    $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + checkINGuestId, '_blank');
                }, function (e) {
                    $scope.IsSaved = true;
                    msg('Error in mapping to print.');
                }).finally(function () {
                    $scope.reset();
                });
        };

        $scope.OpenSendEmail = function () {
            $.fancybox({
                'href': '#checkinsave',
                'modal': true,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.hideCheckInSave = function () {
            parent.$.fancybox.close();
            $("#checkinsave").hide('slow');
        };

        //Send Link
        $scope.SendLinkTemplate = function (checkINGuest) {

            var sendLinkModel = {
                PropertyID: $scope.PropertyID,
                ModifiedBy: $scope.UserName,
                Mobile: checkINGuest.Mobile,
                EMail: checkINGuest.EmailId,
                BusinessDate: $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
            };

            var promiseGet = checkINService.getAddSendLinkTemplate(sendLinkModel);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    $scope.EMailTemplate = data.Data;
                    //$("#emailTemplate").modal('show');
                    $scope.SendLink(checkINGuest);
                    scrollPageOnTop();
                }
            }, function (error, status) {

                if (error.Message) {
                    parent.popErrorMessage(error.Message);
                }
                else {
                    parent.popErrorMessage(error.responseJSON.Message);
                }

                scrollPageOnTop();
            });
        }
        $scope.SendLink = function (checkINGuest) {
            guest = {
                CorporateName: checkINGuest.CorporateName,
                EmailId: checkINGuest.EmailId,
                //FolioNo                          :checkINGuest.FolioNo       ,
                //IsExtraBed                       :checkINGuest.IsExtraBed    ,
                Mobile: checkINGuest.Mobile,
                Name: checkINGuest.Name,
                DOB: checkINGuest.DOB,
                DOA: checkINGuest.DOA,

                Address1: checkINGuest.Address1,
                Address2: checkINGuest.Address2,
                City: checkINGuest.City,
                PIN: checkINGuest.PIN,

                GuestId: checkINGuest.CheckINGuestRoom.GuestId,
                
            };

            //Guest Detail



            var guestStr = "<style>table, th, td {border: 1px solid black;} table {border-collapse: collapse;cellpadding:15px; cellspacing:15px;width:900px;}</style><table>"
            guestStr += "<tr>"
            guestStr += "<td colspan='6' align='center'>"
            guestStr += "<b>You Personal Details</b>"
            guestStr += "</td>"
            guestStr += "</tr>"
            guestStr += "<tr bgcolor='#D3D3D3'>"
            guestStr += "<td align='center'>"
            guestStr += "Name"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "DOB"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "DOA"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "Mobile"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "EMail"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "Company"
            guestStr += "</td>"
            guestStr += "</tr>"

            guestStr += "<tr>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.FirstName + ' ' + guest.LastName  + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + $filter('date')(guest.DOB, $scope.DateFormat) + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + $filter('date')(guest.DOA, $scope.DateFormat) + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.Mobile + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.EmailId + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.CorporateName + "</b>"
            guestStr += "</td>"
            guestStr += "</tr>"

            guestStr += "<tr bgcolor='#D3D3D3'>"
            guestStr += "<td align='center'>"
            guestStr += "Address"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += ""
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "City"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "PIN"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += ""
            guestStr += "</td>"
            guestStr += "</tr>"
            guestStr += "<tr>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.Address1 + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.Address2 + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.City + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += "<b>" + guest.PIN + "</b>"
            guestStr += "</td>"
            guestStr += "<td align='center'>"
            guestStr += ""
            guestStr += "</td>"
            guestStr += "</tr>"
            guestStr += "</table>"

            guestStr = replaceAll(guestStr, 'null', '');

            var possportStr = "<table>"
            possportStr += "<tr>"
            possportStr += "<td colspan='6' align='center'>"
            possportStr += "<b>Passport Details</b>"
            possportStr += "</td>"
            possportStr += "</tr>"
            possportStr += "<tr bgcolor='#D3D3D3'>"
            possportStr += "<td align='center'>"
            possportStr += "Nationality"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "Passport No"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "Date of Issue"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "Visa No"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "Date Of Issue"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += ""
            possportStr += "</td>"
            possportStr += "</tr>"

            possportStr += "<tr>"
            possportStr += "<td align='center'>"
            possportStr += "<b>" + checkINGuest.Nationality + "</b>"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "<b>" + checkINGuest.PassportNo + "</b>"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "<b>" + $filter('date')(checkINGuest.IssueDate, $scope.DateFormat) + "</b>"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "<b>" + checkINGuest.VisaNo + "</b>"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "<b>" + $filter('date')(checkINGuest.IssueVisaDate, $scope.DateFormat) + "</b>"
            possportStr += "</td>"
            possportStr += "<td align='center'>"
            possportStr += "<b></b>"
            possportStr += "</td>"
            possportStr += "</tr>"
            possportStr += "</table>"
            possportStr = replaceAll(possportStr, 'null', '');

            
            if (!checkINGuest.PassportNo) {
                possportStr = "";
            }

            angular.forEach(checkINGuest.AvailableRooms, function (item) {
                if (item.Id == checkINGuest.RoomMasterId) {
                    checkINGuest.RoomNumber = item.RoomNumber;
                }
            });

            angular.forEach($scope.BillingInstructions, function (item) {
                if (item.Id == $scope.Model.BillingInstructionId) {
                    checkINGuest.BillingInstructionName = item.Name;
                }
            });

            var checkINStr = "<table>"
            checkINStr += "<tr>"
            checkINStr += "<td colspan='6' align='center'>"
            checkINStr += "<b>CheckIN Details</b>"
            checkINStr += "</td>"
            checkINStr += "</tr>"
            checkINStr += "<tr bgcolor='#D3D3D3'>"
            checkINStr += "<td align='center'>"
            checkINStr += "Room Type"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "Room No"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "Room Rate"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "Pax Type"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "Billing Instruction"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "Booked By"
            checkINStr += "</td>"
            checkINStr += "</tr>"

            checkINStr += "<tr>"
            checkINStr += "<td align='center'>"
            checkINStr += "<b>" + checkINGuest.RoomTypeName + "</b>"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "<b>" + checkINGuest.RoomNumber + "</b>"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "<b>" + checkINGuest.CheckINGuestRoom.CheckINGuestRoomRates[0].DayRateAmount + "</b>"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "<b>" + $scope.Model.PaxTypeName + "</b>"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "<b>" + $scope.Model.BillingInstructionName + "</b>"
            checkINStr += "</td>"
            checkINStr += "<td align='center'>"
            checkINStr += "<b>" + $scope.Model.BookerName + "</b>"
            checkINStr += "</td>"
            checkINStr += "</tr>"
            checkINStr += "</table>"
            checkINStr = replaceAll(checkINStr, 'null', '');

            
            var linkGuestImage = GetCameraLink(checkINGuest.SNo, 'CheckIN');
            var linkGuestSignature = GetSignatureLink(checkINGuest.SNo, 'CheckIN');

            if ($scope.EMailTemplate.Message.length > 0) {
                $scope.EMailTemplate.Message = $scope.EMailTemplate.Message.replace('$$LinkGuestImage$$', linkGuestImage);
                $scope.EMailTemplate.Message = $scope.EMailTemplate.Message.replace('$$LinkGuestSignature$$', linkGuestSignature);
                $scope.EMailTemplate.Message = $scope.EMailTemplate.Message.replace('$$GuestInfo$$', guestStr);
                $scope.EMailTemplate.Message = $scope.EMailTemplate.Message.replace('$$PassportInfo$$', possportStr);
                $scope.EMailTemplate.Message = $scope.EMailTemplate.Message.replace('$$CheckINInfo$$', checkINStr);
            }

            $scope.EMailTemplate.ModifiedBy = $scope.UserName;
            $scope.EMailTemplate.PropertyID = $scope.PropertyID;
            $scope.EMailTemplate.SendOn = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

            var promiseGet = checkINService.sendEMail($scope.EMailTemplate);
            promiseGet.then(function (data, status) {
                if (data.Status) {
                    parent.posSuccessMessage("EMail sent successfully.");
                    scrollPageOnTop();
                }
            },
                function (error, status) {

                    if (error.Message) {
                        alert(error.Message);
                    }
                    else if (error.responseJSON) {
                        alert(error.responseJSON.Message);
                    }


                    scrollPageOnTop();
                });
        }

        $scope.fillRecord = function (record, guest) {
            
            msg('');
            checkINService.get($scope.PropertyID, record.Id)
                .then(function (result) {

                    $scope.Model = result.Data;
                    //if($scope.IsWalkIN) $scope.Model.Id = '';

                    var cit = $scope.Model.CheckINTimeForDisplay.split(':');

                    var tt = new Date();

                    $scope.Model.CheckINTimeForDisplayD = new Date(tt.getFullYear(), tt.getMonth(), tt.getDate(), cit1[0], cit1[1], 0);

                    //$scope.Model.CheckINTimeForDisplayD=new Date(1970, 0, 1, cit[0], cit[1], 0) ;
                    var cit1 = $scope.Model.CheckOUTTimeForDisplay.split(':');
                    $scope.Model.CheckOUTTimeForDisplayD = new Date(1970, 0, 1, cit1[0], cit1[1], 0);

                    $scope.Model.TotalPax = 0;
                    $scope.Model.CurrencyMasterId = result.Data.CurrencyMasterId.toString();
                    $scope.Model.RevenueHeadId = result.Data.RevenueHeadId;

                    angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {

                        if (checkINGuest.CheckINGuestRooms && checkINGuest.CheckINGuestRooms.length > 0) {
                            var checkINRoom = checkINGuest.CheckINGuestRooms[0];
                            

                            checkINGuest.IsCheckedIN = true;
                            checkINGuest.RoomTypeId = checkINRoom.RoomTypeId;
                            checkINGuest.RoomMasterId = checkINRoom.RoomMasterId;
                            $scope.ChangeRoomType(checkINGuest);
                            checkINGuest.SalutationId = checkINGuest.SalutationId.toString();
                            checkINGuest.CountryMasterId = checkINGuest.CountryMasterId.toString();
                            checkINGuest.StateId = checkINGuest.StateId.toString();
                            $scope.changeGuestCountry(checkINGuest);
                            checkINGuest.GenderId = checkINGuest.GenderId.toString();
                            checkINGuest.PaxTypeId = checkINGuest.PaxTypeId.toString();
                            checkINGuest.MealPlanId = !checkINRoom.MealPlanId ? '' : checkINRoom.MealPlanId.toString();
                            checkINGuest.CheckINGuestVisitDetail = checkINGuest.CheckINGuestVisitDetails && checkINGuest.CheckINGuestVisitDetails.length > 0 ? checkINGuest.CheckINGuestVisitDetails[0] : null;
                            if (checkINGuest.CheckINGuestVisitDetail) {
                                checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId = checkINGuest.CheckINGuestVisitDetail.ArrivalCountryId.toString();
                                checkINGuest.CheckINGuestVisitDetail.ArrivalStateId = checkINGuest.CheckINGuestVisitDetail.ArrivalStateId.toString();
                                $scope.changeArrivingCountry(checkINGuest.CheckINGuestVisitDetail);
                                checkINGuest.CheckINGuestVisitDetail.ProceedToCountryId = checkINGuest.CheckINGuestVisitDetail.ProceedToCountryId.toString();
                                checkINGuest.CheckINGuestVisitDetail.ProceedToStateId = checkINGuest.CheckINGuestVisitDetail.ProceedToStateId.toString();
                                $scope.changeProceedingCountry(checkINGuest.CheckINGuestVisitDetail);
                                checkINGuest.CheckINGuestVisitDetail.ArrivalViaId = checkINGuest.CheckINGuestVisitDetail.ArrivalViaId.toString();

                                checkINGuest.CheckINGuestVisitDetail.ProceedToViaId = checkINGuest.CheckINGuestVisitDetail.ProceedToViaId.toString();
                                checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId = checkINGuest.CheckINGuestVisitDetail.PurposeofVisitId.toString();
                            }
                            $scope.getGuestHistory(checkINGuest);

                            checkINGuest.checkINGuestVehicle = checkINGuest.CheckINGuestVehicles && checkINGuest.CheckINGuestVehicles.length > 0 ? checkINGuest.CheckINGuestVehicles[0] : null;
                            $scope.getLocalStateList(checkINGuest);
                            checkINGuest.CheckINGuestLocalContact = checkINGuest.CheckINGuestLocalContacts && checkINGuest.CheckINGuestLocalContacts.length > 0 ? checkINGuest.CheckINGuestLocalContacts[0] : null;
                            if (checkINGuest.CheckINGuestLocalContact) checkINGuest.CheckINGuestLocalContact.StateId = checkINGuest.CheckINGuestLocalContact.StateId.toString();

                            checkINGuest.CheckINGuestWorkPermit = checkINGuest.CheckINGuestWorkPermits && checkINGuest.CheckINGuestWorkPermits.length > 0 ? checkINGuest.CheckINGuestWorkPermits[0] : null;
                            if (checkINGuest.CheckINGuestWorkPermit) {
                                checkINGuest.CheckINGuestWorkPermit.CountryId = checkINGuest.CheckINGuestWorkPermit.CountryId.toString();
                                checkINGuest.CheckINGuestWorkPermit.StateId = checkINGuest.CheckINGuestWorkPermit.StateId.toString();
                                $scope.changeWorkCountry(checkINGuest.CheckINGuestWorkPermit);
                            }
                            $scope.Model.TotalPax++;
                        }
                    });
                    

                    if (guest) {
                        $scope.Model.TotalPax++;
                        ('formGuest', guest);
                    }
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.getGuestHistory = function (guest) {
            
            checkINService.getGuestHistory($scope.PropertyID, guest.GuestId)
                .then(function (s) {
                    guest.GuestHistoryList = s.Data ? s.Data.CheckINGuests : [];
                    guest.TotalRoomRevenue = 0;
                    guest.TotalRoomNights = 0;
                    guest.GuestHistoryList.forEach(function (c) {
                        guest.TotalRoomRevenue += c.TotalRoomRevenue;
                        //guest.TotalRoomNights += dateCompare(c.CheckOUTDate, c.CheckINDate);
                        
                        var days = GetDays(c.CheckINDate,c.CheckOUTDate,$scope.DateFormat);
                        guest.TotalRoomNights += days.length-1;

                    });
                    guest.TotalRoomRevenue = decimalValD(guest.TotalRoomRevenue);
                });
        };

        $scope.AvailableRooms = [];
        $scope.ShowRoomChart = function (rooms) {
            
            $scope.AvailableRooms = rooms;
            $("#roomChartBox").modal('show');
        }
        //Rate Change
        $scope.IsMultiRate = "1";

        $scope.Advance = {

            CreditCardNumber: '',
            CreditCardNetworkId: '',
            CreditCardNetworkName: '',
            GuestName: '',
            ChequeNumber: '',
            ChequeDate: $scope.ModifiedDate,
            BankName: '',
            BankBranch: '',
            Amount: 0,
            ReferenceNo: '',
        };
        $scope.CheckINGuestRoomRate = {

            CheckINGuestRoomId: '',
            ChargeDate: '',
            DayRate: 0,
            //DayRateApply                    :0,
            RateDiscountInId: '2',
            RateDiscountValue: 0,
            DayRateAmount: 0,
            TotalTariffTAXAmount: 0,
            MealPlanDayRate: 0,
            MealPlanDiscountInId: '2',
            MealPlanDiscountValue: 0,
            MealPlanDayRateAmount: 0,
            TotalMealPlanTAXAmount: 0,

            ExtraBedNumber: 0,
            ExtraBedAmount: 0,
            ExtraBedTAXAmount: 0,

            TotalExtraBed: 0,
            ExtraBedMealPlanDayRate: 0,
            ExtraBedMealPlanTAXAmount: 0,
            TotalExtraBedMealPlan: 0,
            NetDayExtraBedAmount: 0,
            TotalDayAmount: 0,
            //TotalNumberExtraBed:0,

            EarlyArrivalCharge: 0,
            LateDepartureCharge: 0,

        };

        $scope.GetFolioCount = function (roomId, array) {

            var flags = [], output = [], l = array.length, i;
            for (i = 0; i < l; i++) {
                if (array[i].RoomMasterId) {
                    if (roomId == array[i].RoomMasterId) {
                        if (array[i].FolioNo) {
                            if (flags[array[i].FolioNo]) continue;
                            flags[array[i].FolioNo] = true;
                            output.push(array[i].FolioNo);
                        }
                    }
                }
            }
            return output.length == 0 ? 1 : output.length;
        };

        //Navneet----------------------------------------------

        //CheckINGuests

        $scope.addGuest = function (form, g) {
            
            if (form && !$scope[form].$valid) {
                $scope.showGmsgs = true;
                msg('');
                return;
            }
            if (!g) {

                var sno = $scope.Model.CheckINGuests.length + 1;

                var companyId = "";
                var companyName = "";
                if ($scope.Model.CheckINGuests.length > 0) {
                    if ($scope.Model.CheckINGuests[$scope.Model.CheckINGuests.length - 1].CorporateId) {
                        companyId = $scope.Model.CheckINGuests[$scope.Model.CheckINGuests.length - 1].CorporateId;
                        companyName = $scope.Model.CheckINGuests[$scope.Model.CheckINGuests.length - 1].CorporateName;
                    }
                }
                
                
                g = new Object();
                if ($scope.DefaultSetting) {
                    g.IsRoomOwner = false;
                    g.FolioNo = "1";
                    g.SNo = sno.toString();
                    g.SalutationId = $scope.DefaultSetting.SalutationId.toString();
                    g.PaxTypeId = "1";
                    g.IsExtraBed = false;
                    g.IsGroupLeader = false;

                    g.CorporateId = companyId;
                    g.CorporateName = companyName;

                    if($scope.RoomTypeId)
                    {
                        g.RoomTypeId = $scope.RoomTypeId;
                    }
                    else
                    {
                        g.RoomTypeId = $scope.DefaultSetting.RoomTypeId;
                    }

                    g.RoomINDate = $filter("date")( $scope.Model.CheckINDate, $scope.DateFormat);
                    g.RoomOUTDate = $filter("date")( $scope.Model.CheckOUTDate, $scope.DateFormat);

                    g.MealPlanId = $scope.DefaultSetting.MealPlanId.toString();
                    //$scope.ChangeRoomType(g, true);
                    $scope.ChangeRoomType(g);
                    $scope.getLocalStateList(g);
                }
            }
            else {
            }
            
            
            g.CheckINGuestAdvance={};
            $scope.Model.CheckINGuests.push(g);
            $scope.Model.TotalPax = $scope.Model.CheckINGuests.length;
            
            //RoomChart CheckIN
            if ($scope.RoomMasterId) {
                angular.forEach($scope.Model.CheckINGuests, function (item) {
                    if(!item.RoomMasterId)
                    {
                        
                        item.RoomMasterId = $scope.RoomMasterId;
                        item.RoomNumber = $scope.RoomNumber;
                        item.AvailableRooms = $scope.AvailableRooms;
                        $scope.ChangeRoom(item);
                    }
                });
            }

            //$scope.SetRoomOwner(g);
            $scope.ResetRoomOwner();

        };
        
        $scope.SetRoomOwner = function(checkINGuest){

            if(!checkINGuest.RoomMasterId)
            {
                checkINGuest.IsRoomOwner=false;
                return;
            }
            //var distinctFolioNos = $scope.GetDistinctFolioNos($scope.Model.CheckINGuests);
            //distinctFolioNos.forEach(function (folioNo) {

            //    var i = 0;
            //    //Reset
            //    $scope.Model.CheckINGuests.forEach(function (guest) {   
            //        if(checkINGuest.FolioNo == guest.FolioNo && checkINGuest.RoomMasterId==guest.RoomMasterId)
            //        {
            //            guest.IsRoomOwner = false;
            //        }  
            //    });

            //    //Set
            //    $scope.Model.CheckINGuests.forEach(function (guest) {   
            //        if(checkINGuest.SNo == guest.SNo  && guest.RoomMasterId==checkINGuest.RoomMasterId)
            //        {
            //            guest.IsRoomOwner = true;
            //        }                    
            //    });

            var distinctValues = [];
            var newArr = $scope.Model.CheckINGuests.filter(function (el) {
                if (distinctValues.indexOf(el.RoomMasterId) === -1) {
                    // If not present in array, then add it
                    distinctValues.push(el.RoomMasterId);
                    //return true;
                }
               
            });


            //var guests = $scope.Model.CheckINGuests.filter(x=>x.FolioNo == folioNo && x.RoomMasterId==checkINGuest.RoomMasterId);
            //if(guests.length > 0)
            //{
            for (i = 0; i < distinctValues.length; i++) {
                for (j = 0; j < $scope.Model.CheckINGuests.length; j++) {
                    if($scope.Model.CheckINGuests[j].RoomMasterId==distinctValues[i].RoomMasterId)
                    {
                        $scope.Model.CheckINGuests[j].IsRoomOwner = true;
                        break;
                    }     
                }
                //$scope.Model.CheckINGuests.forEach(function (guest) {   
                //    if(guest.RoomMasterId==distinctValues[i].RoomMasterId)
                //    {
                //        guest.IsRoomOwner = true;
                //        break;
                //    }     
                //});      
            }

           
            // }
            //var guests = $scope.Model.CheckINGuests.filter(x=>x.FolioNo == folioNo && x.IsRoomOwner == true && x.RoomMasterId==checkINGuest.RoomMasterId);
            //if(guests.length==0)
            //{
            //    var guests = $scope.Model.CheckINGuests.filter(x=>x.FolioNo == folioNo  && x.RoomMasterId==checkINGuest.RoomMasterId );
            //    if(guests.length==1)
            //    {
            //        guests[0].IsRoomOwner = true;
            //    }
            //}

            // });
          
            $scope.ResetRate();
        };

        $scope.GetDistinctFolioNos = function (list) {

            var distinctValues = [];
            var newArr = list.filter(function (el) {
                if (distinctValues.indexOf(el.FolioNo) === -1) {
                    // If not present in array, then add it
                    distinctValues.push(el.FolioNo);
                    return true;
                }
                else {
                    // Already present in array, don't add it
                    return false;
                }
            });
            return distinctValues;
        };

        $scope.RoomOwnerValidation = function(){
            var value =true;
            var getDistinctRoomIds = $scope.GetDistinctRoomId($scope.Model.CheckINGuests);
            getDistinctRoomIds.forEach(function (roomid) {
                var guests = $scope.Model.CheckINGuests.filter(x=>x.RoomMasterId == roomid && x.IsRoomOwner == true);
                if(guests.length==0)
                {
                    value =false;
                }
            });
            return value;
        };

        //TODO: Navneet2.0
        $scope.ResetRoomOwner = function(){
            $scope.Model.CheckINGuests.forEach(function (guest) {   
                guest.IsRoomOwner = false;
            });

            var value =true;
            var getDistinctRoomIds = $scope.GetDistinctRoomId($scope.Model.CheckINGuests);
            getDistinctRoomIds.forEach(function (roomid) {
                var guests = $scope.Model.CheckINGuests.filter(x=>x.RoomMasterId == roomid);
                if(guests.length>0)
                {
                    guests[0].IsRoomOwner =true;
                }
            });
            return value;
        };

        //$scope.SetRoomOwner = function () {
        //    $scope.ResetRoomOwner();

        //    if ($scope.Model.CheckINGuests.length > 0) {
        //        var getDistinctRoomIds = $scope.GetDistinctRoomId($scope.Model.CheckINGuests);
        //        getDistinctRoomIds.forEach(function (roomid) {
        //            if (roomid) {
        //                var roomGuests = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == roomid);
        //                if (roomGuests.length > 0) {
        //                    var getDistinctFolios = $scope.GetDistinctFolio(roomGuests);

        //                    getDistinctFolios.forEach(function (folio) {

        //                        var roomGuests2 = roomGuests.filter(x => x.FolioNo == folio);

        //                        angular.forEach(roomGuests2, function (guest) {
        //                            guest.IsRoomOwner = false;
        //                        });
        //                        roomGuests2[0].IsRoomOwner = true;

        //                    });
        //                }
        //            }
        //            else {
        //                $scope.Model.CheckINGuests[0].IsRoomOwner = true;
        //            }
        //        });
        //    }
           
        //};
        //$scope.ResetRoomOwner = function () {
        //    angular.forEach($scope.Model.CheckINGuests, function (guest) {
        //        guest.IsRoomOwner = false;
        //    });

        //};

        $scope.ChangeFolio = function (checkINGuest) {
            $scope.SetRoomOwner(checkINGuest);
            $scope.SetCheckINGuestRoom();
        };

        $scope.ChangePaxType = function (checkINGuest) {
            checkINGuest.RoomMasterId = '';
            checkINGuest.RoomNumber='';
            $scope.SetPaxAndEB();
            $scope.SetCheckINGuestRoomRate(checkINGuest);
        };

        $scope.ChangeRoomType = function (checkINGuest) {
            
            if ($scope.IsWalkIN || !checkINGuest.ReservationRoomType) {
                if(!checkINGuest.Id)
                {
                    checkINGuest.RoomMasterId='';
                    checkINGuest.RoomNumber='';
                }

                if($scope.IsRoomChartActive)
                {
                    var checkINDate = GetJavaScriptDate($scope.Model.CheckINDate, "YYYY-MM-DD", 0);
                    var checkOUTDate = GetJavaScriptDate($scope.Model.CheckOUTDate, "YYYY-MM-DD", 0);
                    
                    var model ={
                        ArrivalDate   :GetLocalDate(checkINDate, $scope.DateFormat),
                        DepartureDate :GetLocalDate(checkOUTDate, $scope.DateFormat),
                        RoomTypeId    :checkINGuest.RoomTypeId,
                    }

                    $rootScope.$broadcast("CallGetAvailableRoom", model);
                    $timeout(function() { 
                        checkINGuest.AvailableRooms = $scope.AvailableRooms;
                        $scope.ChangeRoom(checkINGuest);
                    }, 40);
                }
                
                angular.forEach($scope.CheckINGuestRooms,function(checkINGuestRoom){
                    if(checkINGuestRoom.SNo == checkINGuest.SNo && checkINGuestRoom.RoomTypeId == checkINGuest.RoomTypeId && checkINGuestRoom.FolioNo == checkINGuest.FolioNo )
                    {
                        checkINGuestRoom.RoomTypeId=checkINGuest.RoomTypeId;
                        checkINGuestRoom.RoomTypeName=checkINGuest.RoomTypeName;
                        checkINGuestRoom.RoomMasterId='';
                        checkINGuestRoom.RoomNumber='';
                        checkINGuestRoom.CheckINGuestRoomRates=[]; 
                    }
                });

                checkINCommonService.GetTotal($scope);
            }
            else if (checkINGuest.ReservationRoomType && checkINGuest.RoomTypeId != checkINGuest.ReservationRoomType.RoomTypeId) {
                var strMsg = DeletePopup('This reservation was done for room type ' + checkINGuest.ReservationRoomType.RoomTypeName + ', Do you want to change?');
                $.fancybox({
                    'modal': true,
                    'content': strMsg,
                    'afterShow': function () {
                        $("#fancyconfirm_cancel")
                            .click(function () {
                                $.fancybox.close();
                                checkINGuest.RoomTypeId = checkINGuest.ReservationRoomType.RoomTypeId;
                            });
                        $("#fancyConfirm_ok")
                            .click(function () {
                                $.fancybox.close();
                                checkINGuest.RoomMasterId='';
                                checkINGuest.RoomNumber='';
                                checkINGuest.AvailableRooms = [];
                                checkINGuest.IsLoadingRoomList = 1;
                                
                                if($scope.IsRoomChartActive)
                                {
                                    var model ={
                                        ArrivalDate   :checkINGuest.RoomINDate,
                                        DepartureDate :checkINGuest.RoomOUTDate,
                                        RoomTypeId    :checkINGuest.RoomTypeId,
                                    }
                                    
                                    $rootScope.$broadcast("CallGetAvailableRoom", model);
                                    $timeout(function() { 
                                        
                                        checkINGuest.AvailableRooms = $scope.AvailableRooms;
                                        if(checkINGuest.ReservationRoomType.RoomMasterId)
                                        {
                                            checkINGuest.AvailableRooms.push({Id:checkINGuest.ReservationRoomType.RoomMasterId,Name:checkINGuest.ReservationRoomType.RoomNumber,RoomTypeId:checkINGuest.ReservationRoomType.RoomTypeId,MaxPerson:checkINGuest.ReservationRoomType.RoomTypeMaxPax});
                                        }
                                        
                                        $scope.ChangeRoom(checkINGuest);
                                    }, 40);
                                }

                                //$scope.getRoomList(checkINGuest);
                                if (checkINGuest.ReservationRoomType) {
                                    if (checkINGuest.ReservationRoomType.RoomMasterId) {
                                        checkINGuest.RoomMasterId = checkINGuest.ReservationRoomType.RoomMasterId;
                                        checkINGuest.RoomNumber = checkINGuest.ReservationRoomType.RoomNumber;
                                    }
                                }
                            });
                    }
                });
            }
            else if (checkINGuest.ReservationRoomType && checkINGuest.RoomTypeId == checkINGuest.ReservationRoomType.RoomTypeId) {
                checkINGuest.RoomMasterId='';
                checkINGuest.RoomNumber='';
                checkINGuest.AvailableRooms = [];
                checkINGuest.IsLoadingRoomList = 1;
                
                if($scope.IsRoomChartActive)
                {
                    var model ={
                        ArrivalDate   :checkINGuest.RoomINDate,
                        DepartureDate :checkINGuest.RoomOUTDate,
                        RoomTypeId    :checkINGuest.RoomTypeId,
                    }
                    
                    $rootScope.$broadcast("CallGetAvailableRoom", model);
                    $timeout(function() { 
                        checkINGuest.AvailableRooms = $scope.AvailableRooms;
                        
                        if(checkINGuest.ReservationRoomType.RoomMasterId)
                        {
                            checkINGuest.AvailableRooms.push({Id:checkINGuest.ReservationRoomType.RoomMasterId,Name:checkINGuest.ReservationRoomType.RoomNumber,RoomTypeId:checkINGuest.ReservationRoomType.RoomTypeId,MaxPerson:checkINGuest.ReservationRoomType.RoomTypeMaxPax});
                        }
                                        
                        $scope.ChangeRoom(checkINGuest);
                    }, 40);
                }

                //$scope.getRoomList(checkINGuest);
                if (checkINGuest.ReservationRoomType) {
                    if (checkINGuest.ReservationRoomType.RoomMasterId) {
                        checkINGuest.RoomMasterId = checkINGuest.ReservationRoomType.RoomMasterId;
                        checkINGuest.RoomNumber = checkINGuest.ReservationRoomType.RoomNumber;
                    }
                }
            }
            
            if (checkINGuest.ReservationRoomType) {
                if (checkINGuest.ReservationRoomType.RoomMasterId) {
                    angular.forEach($scope.Model.CheckINGuests, function (item) {
                        if (item.ReservationRoomTypeId == checkINGuest.ReservationRoomTypeId) {
                            item.RoomMasterId = checkINGuest.ReservationRoomType.RoomMasterId;
                        }
                    });
                }
            }

        };
        $scope.ChangeRoom = function (checkINGuest) {
            $scope.IsAsExtraBedSelected = false;
            $scope.SelectedCheckINGuest = checkINGuest;

            if (checkINGuest.CheckINGuestRoom) {
                checkINGuest.CheckINGuestRoom.RoomMasterId = checkINGuest.RoomMasterId;
            }

            if (checkINGuest.PaxTypeId == 0) {
                checkINGuest.RoomMasterId = "";
                checkINGuest.RoomNumber='';
                msg('Please Select Pax Type first.');
                return;
            }
            if(checkINGuest.AvailableRooms)
            {
                $scope.SelectedRoom = checkINGuest.AvailableRooms.find(x => x.Id == checkINGuest.RoomMasterId);
            }
            
            if (!$scope.SelectedRoom) {
                //23-05-2019
                //$scope.SetRoomOwner();
                $scope.IsShowExtraBed();
                $scope.SetCheckINGuestRoom();
                return;
            };

            if (!$scope.checkRoomMaxPerson($scope.SelectedRoom, checkINGuest)) return;
            
            if ($scope.SelectedRoom.RoomStatusTypeId != 7) {
                
                $scope.Model.CheckINGuests = $scope.Model.CheckINGuests.filter(function (otherGuest) {
                    return !otherGuest.IsCheckedIN;
                });

                //23-05-2019
                //$scope.SetRoomOwner();

                $scope.IsShowExtraBed();
                $scope.SetCheckINGuestRoom();

            } else {

                var promise = checkINService.getAllCheckINGuestByRoomId(checkINGuest.RoomMasterId);
                promise.then(function (data) {
                    if (data.Status) {
                        var i = 0;

                        $scope.OccupiedRoomGuests = data.Collection;
                        angular.forEach($scope.OccupiedRoomGuests, function (item) {
                            if (item.IsRoomOwner) {
                                if (i == 0) {
                                    item.IsSelected = true;
                                    i++;
                                }
                            }
                        });
                        $.fancybox({
                            'href': '#openOccupiedRoom',
                            'modal': true,
                            'afterShow': function () {
                                $("#fancyconfirm_cancel")
                                    .click(function () {
                                        $.fancybox.close();
                                        checkINGuest.RoomMasterId = "";
                                        checkINGuest.RoomNumber='';
                                    });
                                $("#fancyConfirm_ok")
                                    .click(function () {
                                        $.fancybox.close();
                                        var promise = checkINService.getAllCheckINGuestByRoomId(checkINGuest.RoomMasterId);
                                        promise.then(function (data) {
                                            if (data.Status) {

                                            }
                                        });
                                    });
                            }
                        });
                    }
                });
            }
        };

        $scope.$on("CallSetGetAvailableRoom", function (event, obj) {
            $scope.AvailableRooms = obj.AvailableRooms;
        });
        $scope.OpenOccupiedRoom = function () {
            $.fancybox({
                'href': '#OpenOccupiedRoom',
                'modal': true,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            $.fancybox.close();
                        });
                }
            });
        };
        $scope.OpenOccupiedRoomConfirm = function (guestCount) {
            var guests = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == $scope.SelectedRoom.Id & x.Id == "" && x.PaxTypeId == 1);
            guestCount += guests ? guests.length : 0;

            var rightCount = guestCount <= $scope.SelectedRoom.MaxPerson;
            if (!rightCount) {
                parent.popErrorMessage('Number of person in this room ' + guestCount + ' cannot exceed max limit ' + $scope.SelectedRoom.MaxPerson);
                returm;
            }
            else {
                $scope.SetGuests($scope.OccupiedRoomGuests, $scope.SelectedCheckINGuest);
                $scope.SetIsShowExtraBed();
            }

            //23-05-2019
            //$scope.SetRoomOwner();

            $scope.IsShowExtraBed();
            //$scope.SetCheckINGuestRoom('',$scope.SelectedCheckINGuest);
            $scope.SetCheckINGuestRoom();

            parent.$.fancybox.close();
        };
        $scope.closeOccupiedRoomConfirm = function () {
            parent.$.fancybox.close();
            $scope.SelectedCheckINGuest.RoomMasterId = "";
            $scope.SelectedCheckINGuest.RoomNumber= "";
        };

        $scope.IsShowExtraBed = function () {
            $scope.IsShowExtraBedRest();
            if ($scope.Model.CheckINGuests.length > 0) {
                var getDistinctRoomIds = $scope.GetDistinctRoomId($scope.Model.CheckINGuests);
                getDistinctRoomIds.forEach(function (roomid) {
                    if (roomid) {
                        var roomGuests = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == roomid);
                        if (roomGuests.length > 0) {
                            var i = 0;
                            angular.forEach(roomGuests, function (guest) {
                                if (i > 0) {
                                    guest.IsShowExtraBed = true;
                                }
                                i++;
                            });
                        }
                    }
                    else {
                        $scope.Model.CheckINGuests[0].IsRoomOwner = true;
                    }
                });
            }
            $scope.SetPaxAndEB();
        };
        $scope.IsShowExtraBedRest = function () {
            angular.forEach($scope.Model.CheckINGuests, function (guest) {
                guest.IsShowExtraBed = false;
            });
        };

        $scope.SetExtraBed = function (checkINGuest) {

            if (checkINGuest.IsCheckedIN) return;

            checkINGuest.IsExtraBed = !checkINGuest.IsExtraBed;
            $scope.SetPaxAndEB();
            $scope.SetCheckINGuestRoomRate(checkINGuest);
            $scope.SetCheckINGuestRoom();
        };

        //CheckINGuests-End

        //CheckINGuestRooms
        $scope.SetPaxAndEB = function () {

            angular.forEach($scope.CheckINGuestRooms, function (checkINGuestRoom) {
                if (checkINGuestRoom.FolioNo) {
                    checkINGuestRoom.NumberOfPax = 0;
                    checkINGuestRoom.NumberOfAdult = 0;
                    checkINGuestRoom.NumberOfChild = 0;
                    checkINGuestRoom.NumberOfInfant = 0;

                    checkINGuestRoom.ExtraBedNumber = 0;
                    checkINGuestRoom.NumberOfAdultExtraBed = 0;
                    checkINGuestRoom.NumberOfChildExtraBed = 0;
                    checkINGuestRoom.NumberOfInfantExtraBed = 0;

                    angular.forEach($scope.Model.CheckINGuests, function (item) {
                        if (checkINGuestRoom.RoomMasterId == item.RoomMasterId && checkINGuestRoom.FolioNo == item.FolioNo) {

                            checkINGuestRoom.NumberOfPax++;

                            if (item.PaxTypeId == '1') {
                                checkINGuestRoom.NumberOfAdult++;
                            }
                            else if (item.PaxTypeId == '2') {
                                checkINGuestRoom.NumberOfChild++;
                            }
                            else if (item.PaxTypeId == '3') {
                                checkINGuestRoom.NumberOfInfant++;
                            }

                            if (item.IsExtraBed) {
                                if (item.PaxTypeId == '1') {
                                    checkINGuestRoom.NumberOfAdultExtraBed++;
                                }
                                else if (item.PaxTypeId == '2') {
                                    checkINGuestRoom.NumberOfChildExtraBed++;
                                }
                                else if (item.PaxTypeId == '3') {
                                    checkINGuestRoom.NumberOfInfantExtraBed++;
                                }

                                checkINGuestRoom.ExtraBedNumber++;
                            }
                        }
                    });
                }
            });

            //Remove NumberOfPax=0 Room
            angular.forEach($scope.CheckINGuestRooms, function (checkINGuestRoom, index) {
                if (checkINGuestRoom.NumberOfPax == 0) {
                    $scope.CheckINGuestRooms.splice(index, 1);
                }
            });
        }

        //CheckINGuestRooms-End
        $scope.SetCheckINGuestRoomMealPlan = function (mealPlanId, selectedCheckINGuest) {

            if (mealPlanId) {
                angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {

                    if (!checkINGuest.IsCheckedIN && (selectedCheckINGuest.RoomMasterId == checkINGuest.RoomMasterId && selectedCheckINGuest.FolioNo == checkINGuest.FolioNo)) {
                        checkINGuest.MealPlanId = mealPlanId;
                        if (checkINGuest.CheckINGuestRoom) {
                            checkINGuest.CheckINGuestRoom.MealPlanId = mealPlanId;
                        }
                    }
                });

            }

            $scope.SetCheckINGuestRoom();
        }

        $scope.SetCheckINGuestRoom = function () {
            
            $scope.CheckINGuestRooms = [];

            var checkINGuestRoomOwners = $scope.Model.CheckINGuests.filter(x => x.IsRoomOwner == true);

            angular.forEach(checkINGuestRoomOwners, function (checkINGuest) {
                
                if (!checkINGuest.Id && !checkINGuest.ReservationRoomTypeId) {
                    var checkINDate = GetJavaScriptDate($scope.Model.CheckINDate, "YYYY-MM-DD", 0);
                    var checkOUTDate = GetJavaScriptDate($scope.Model.CheckOUTDate, "YYYY-MM-DD", 0);

                    checkINGuest.RoomINDate = GetLocalDate(checkINDate, $scope.DateFormat);
                    checkINGuest.RoomOUTDate = GetLocalDate(checkOUTDate, $scope.DateFormat);
                }
                else {
                    checkINGuest.RoomINDate = $filter("date")(checkINGuest.RoomINDate, $scope.DateFormat);
                    checkINGuest.RoomOUTDate = $filter("date")(checkINGuest.RoomOUTDate, $scope.DateFormat);
                }
                
                //var nights = dateCompare(checkINGuest.RoomOUTDate, checkINGuest.RoomINDate);
                
                var days = GetDays(checkINGuest.RoomINDate, checkINGuest.RoomOUTDate,$scope.DateFormat);
                var nights =days.length-1;
                
                if(checkINGuest.AvailableRooms)
                {
                    var room = checkINGuest.AvailableRooms.find(x => x.Id == checkINGuest.RoomMasterId);
                }
                
                var roomNumber = '';
                if (!room) {
                    roomNumber = checkINGuest.RoomNumber;
                }
                else {
                    roomNumber = room.Name;
                    checkINGuest.RoomTypeId = room.RoomTypeId;
                    checkINGuest.RoomTypeName = room.RoomTypeName;
                }

                var numberOfPax = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo).length;
                var numberOfAdult = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo && x.PaxTypeId == 1).length;
                var numberOfChild = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo && x.PaxTypeId == 2).length;
                var numberOfInfant = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo && x.PaxTypeId == 3).length;


                var numberOfAdultExtraBed = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo && x.PaxTypeId == 1 && x.IsExtraBed == true).length;
                var numberOfChildExtraBed = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo && x.PaxTypeId == 2 && x.IsExtraBed == true).length;
                var numberOfInfantExtraBed = $scope.Model.CheckINGuests.filter(x => x.RoomMasterId == checkINGuest.RoomMasterId && x.FolioNo == checkINGuest.FolioNo && x.PaxTypeId == 3 && x.IsExtraBed == true).length;
                var numberExtraBed = parseFloat(numberOfAdultExtraBed) + parseFloat(numberOfChildExtraBed) + parseFloat(numberOfInfantExtraBed);

                
                var tempCheckINGuestRoom = checkINGuest.CheckINGuestRoom;
                if (!tempCheckINGuestRoom) {
                    tempCheckINGuestRoom = {};
                    if (checkINGuest.ReservationRoomTypeRates) {
                        tempCheckINGuestRoom.Tariff = checkINGuest.ReservationRoomTypeRates[0].DayRate;
                    }
                }

                
                var roomTypeRates = [];
                //angular.forEach($scope.RoomTypes, function (item) {
                //    if (item.Id == checkINGuest.RoomTypeId) {
                //        roomTypeRates = angular.copy(item.RoomTypeRates);
                //    }
                //});

                roomTypeRates= $scope.GetRoomTypeRates(checkINGuest.RoomTypeId);




                var rateMasterId = '';
                var rateMasterCode = '';
                var mealPlanId = '';

                if ($scope.CorporateRates.length > 0) {
                    rateMasterId = $scope.CorporateRates[0].Id;
                }
                else {
                    rateMasterId = $scope.DefaultSetting.RateMasterId;
                    if (!rateMasterId || rateMasterId.length < 1) {
                        msg('Rate Master parameter missing in default setting');
                        return;
                    }
                }

                rateMaster = $scope.RateMasters.find(x => x.Id == rateMasterId);

                var rateMasterCode = rateMaster.Description;
                var rateTaxStructureId = rateMaster.RateTaxStructureId;
                var mealPlanTaxStructureId = rateMaster.MealPlanTAXStructureId;
                var isInclusive = rateMaster.IsInclusive;
                var mealPlanId = '';

                if (checkINGuest.MealPlanId) {
                    mealPlanId = checkINGuest.MealPlanId;
                }
                else {
                    mealPlanId = rateMaster.MealPlanId;
                }

                
                var rate = roomTypeRates.find(x=>x.RateMasterId==rateMasterId);
                if(rate)
                {
                    rateMasterCode = rate.RateMasterDescription;
                    rateTaxStructureId = rate.RateTaxStructureId;
                    mealPlanTaxStructureId = rate.MealPlanTAXStructureId;
                    isInclusive = rate.IsInclusive;
                }

                //angular.forEach(roomTypeRates, function (rate) {
                //    if (rateMasterId == rate.RateMasterId) {
                //        //mealPlanId= rate.MealPlanId;
                //    }
                //});
                
                //tempCheckINGuestRoom.Islusive = rateMasterId;
                tempCheckINGuestRoom.RateMasterId = rateMasterId;
                tempCheckINGuestRoom.RateMasterCode = rateMasterCode;
                tempCheckINGuestRoom.MealPlanId = mealPlanId;
                tempCheckINGuestRoom.RateTaxStructureId = rateTaxStructureId;
                tempCheckINGuestRoom.MealPlanTaxStructureId = mealPlanTaxStructureId;
                tempCheckINGuestRoom.IsInclusive = isInclusive;
                
                if(checkINGuest.ReservationRoomType)
                {
                    tempCheckINGuestRoom.IsInclusive = checkINGuest.ReservationRoomType.IsInclusive;
                }

                if(checkINGuest.InterPropertyTransfer)
                {
                    tempCheckINGuestRoom.Tariff  = checkINGuest.InterPropertyTransfer.DayRateAmount
                    tempCheckINGuestRoom.MealPlanDayRate  = checkINGuest.InterPropertyTransfer.MealPlanDayRate
                    tempCheckINGuestRoom.IsInclusive = checkINGuest.InterPropertyTransfer.IsInclusive;
                }

                checkINGuestRoom = {

                    FolioNo: checkINGuest.FolioNo,
                    SNo: checkINGuest.SNo,
                    NumberOfPax: numberOfPax,
                    NumberOfAdult: numberOfAdult,
                    NumberOfChild: numberOfChild,
                    NumberOfInfant: numberOfInfant,
                    NumberOfAdultExtraBed: numberOfAdultExtraBed ? numberOfAdultExtraBed : 0,
                    NumberOfChildExtraBed: numberOfChildExtraBed ? numberOfChildExtraBed : 0,
                    NumberOfInfantExtraBed: numberOfInfantExtraBed ? numberOfInfantExtraBed : 0,
                    ExtraBedNumber: numberExtraBed ? numberExtraBed : 0,
                    AdultExtraBedAmount: 0,
                    ChildExtraBedAmount: 0,
                    InfantExtraBedAmount: 0,

                    GuestId: checkINGuest.GuestId,
                    CheckINGuestId: checkINGuest.Id,
                    CheckINGuestName: (checkINGuest.FirstName ? checkINGuest.FirstName : '') +' ' + (checkINGuest.LastName ? checkINGuest.LastName : '') ,
                    RoomMoveDate: businessDateStr,
                    RoomMoveTypeId: 1,
                    RoomMoveTypeName: "CheckIN",
                    ToId: "",
                    IsUpgrade: false,
                    ReasonId: null,
                    ReasonCode: "",
                    ReasonName: "",
                    RoomMoveRemark: "",
                    RoomMasterId: checkINGuest.RoomMasterId,
                    RoomNumber: roomNumber,
                    RoomTypeId: checkINGuest.RoomTypeId,
                    RoomTypeName: checkINGuest.RoomTypeName,

                    PackageId: '',
                    RateMasterId: tempCheckINGuestRoom.RateMasterId == undefined ? rateMasterId : tempCheckINGuestRoom.RateMasterId,
                    RateMasterCode: tempCheckINGuestRoom.RateMasterCode == undefined ? rateMasterCode : tempCheckINGuestRoom.RateMasterCode,
                    MealPlanId: tempCheckINGuestRoom.MealPlanId == undefined ? $scope.DefaultSetting.MealPlanId : tempCheckINGuestRoom.MealPlanId,
                    MealPlanCode: '',
                    MealPlanName: '',
                    RateTaxStructureId: tempCheckINGuestRoom.RateTaxStructureId == undefined ? rateTaxStructureId : tempCheckINGuestRoom.RateTaxStructureId,
                    MealPlanTaxStructureId: tempCheckINGuestRoom.MealPlanTaxStructureId == undefined ? mealPlanTaxStructureId : tempCheckINGuestRoom.MealPlanTaxStructureId,

                    //IsInclusive: tempCheckINGuestRoom.IsInclusive,
                    IsInclusiveSet: checkINGuest.ReservationRoomType ? false : tempCheckINGuestRoom.IsInclusive,

                    IsTariffPlanInclusive: false,
                    IsTariffTAXInclusive: false,
                    IsMultiRate: tempCheckINGuestRoom.IsMultiRate,
                    IsPackage: false,

                    Tariff: tempCheckINGuestRoom.Tariff == undefined ? 0 : tempCheckINGuestRoom.Tariff,
                    MealPlanRate: tempCheckINGuestRoom.MealPlanDayRate ? tempCheckINGuestRoom.MealPlanDayRate  : 0,

                    TotalDayRate: 0,
                    TotalDayRateAmount: 0,
                    TotalTariffTAXAmount: 0,
                    TotalMealPlanDayRateAmount: 0,
                    TotalMealPlanTAXAmount: 0,
                    TotalNetDayAmount: 0,

                    TotalExtraBedAmount: 0,

                    CheckINGuestRoomRates: tempCheckINGuestRoom != undefined ? tempCheckINGuestRoom.CheckINGuestRoomRates : [],
                    TariffLinkTaxStructures: [],
                    MealPlanLinkTaxStructures: [],
                    TotalFolio: $scope.GetFolioCount(checkINGuest.RoomMasterId, $scope.Model.CheckINGuests),
                    Nights: nights,
                    RoomTypeRates: angular.copy(roomTypeRates),
                    Advance: {}
                };
                
                if (checkINGuest.ReservationRoomType) {
                    checkINGuestRoom.ReservationRoomTypeId = checkINGuest.ReservationRoomType.Id;
                    checkINGuestRoom.RoomMasterId = !checkINGuestRoom.RoomMasterId ? checkINGuest.ReservationRoomType.RoomMasterId : checkINGuestRoom.RoomMasterId;
                    checkINGuestRoom.RoomNumber = checkINGuest.ReservationRoomType.RoomMasterId ? checkINGuest.ReservationRoomType.RoomNumber : "";
                    checkINGuestRoom.RoomTypeName = checkINGuest.ReservationRoomType.RoomTypeName ? checkINGuest.ReservationRoomType.RoomTypeName : "";
                    
                    checkINGuestRoom.PackageId = checkINGuest.ReservationRoomType.PackageId;
                    checkINGuestRoom.RateMasterId = checkINGuest.ReservationRoomType.RateMasterId;
                    checkINGuestRoom.RateMasterCode = checkINGuest.ReservationRoomType.RateMasterCode;
                    checkINGuestRoom.MealPlanId = checkINGuest.ReservationRoomType.MealPlanId;
                    checkINGuestRoom.MealPlanCode = checkINGuest.ReservationRoomType.MealPlanCode;
                    checkINGuestRoom.MealPlanName = checkINGuest.ReservationRoomType.MealPlanName;
                    checkINGuestRoom.RateTaxStructureId = checkINGuest.ReservationRoomType.RateTaxStructureId;
                    checkINGuestRoom.MealPlanTaxStructureId = checkINGuest.ReservationRoomType.MealPlanTAXStructureId;
                    checkINGuestRoom.IsInclusive = checkINGuest.ReservationRoomType.IsInclusive;
                    checkINGuestRoom.IsTariffPlanInclusive = checkINGuest.ReservationRoomType.IsTariffPlanInclusive;
                    checkINGuestRoom.IsTariffTAXInclusive = checkINGuest.ReservationRoomType.IsTariffTAXInclusive;
                    checkINGuestRoom.IsMultiRate = checkINGuest.ReservationRoomType.IsMultiRate;
                    checkINGuestRoom.IsPackage = checkINGuest.ReservationRoomType.IsPackage;
                    checkINGuestRoom.CheckINGuestRoomRates = [];

                }

                if(checkINGuest.InterPropertyTransfer)
                {
                    //tempCheckINGuestRoom.Tariff  = checkINGuest.InterPropertyTransfer.DayRateAmount
                    //tempCheckINGuestRoom.MealPlanRate  = checkINGuest.InterPropertyTransfer.MealPlanRate
                    //tempCheckINGuestRoom.IsInclusive = checkINGuest.InterPropertyTransfer.IsInclusive;
                    checkINGuestRoom.IsInclusive = checkINGuest.InterPropertyTransfer.IsInclusive;
                }

                
                $scope.resetAdvance(checkINGuestRoom);
                checkINCommonService.SetTax($scope,checkINGuestRoom);
                
                if (checkINGuest.ReservationRoomType) {
                    checkINGuest.CheckINGuestRoom = checkINGuestRoom;
                    checkINCommonService.SetReservationRoomTypeRate($scope,checkINGuest);
                }
                else if (checkINGuest.InterPropertyTransfer) {
                    checkINGuest.CheckINGuestRoom = checkINGuestRoom;
                    checkINCommonService.SetInterPropertyTransferRate($scope,checkINGuestRoom);
                }
                else {
                    checkINCommonService.SetRate($scope,checkINGuestRoom);
                }
                
                checkINGuest.CheckINGuestRoom = checkINGuestRoom;
                
                $scope.CheckINGuestRooms.push(checkINGuestRoom);
            })

            checkINCommonService.CalculateCheckINRoom($scope);
            $scope.SetInclusive();
        };

        $scope.SetInclusive = function(){
            angular.forEach($scope.CheckINGuestRooms, function (item) {
                if(item.IsInclusiveSet)
                {
                    item.IsInclusive = item.IsInclusiveSet;
                    $scope.CheckINGuestRoom=item;
                    $scope.IsInclusive(item);
                }
            });
        }

        $scope.SetOccupiedRoomGuest = function(occupiedRoomGuest)
        {
            var occupiedRoomGuestCopy = angular.copy(occupiedRoomGuest);
            angular.forEach($scope.OccupiedRoomGuests,function(item){
                item.IsSelected=false;
            });
            angular.forEach($scope.OccupiedRoomGuests,function(item){
                if(occupiedRoomGuestCopy.Id == item.Id)
                {
                    item.IsSelected=occupiedRoomGuestCopy.IsSelected;
                }
            });
        }

        $scope.SetRate = function (checkINGuestRoom) {
            checkINCommonService.SetRate($scope,checkINGuestRoom);
        }

        $scope.SetCheckINGuestRoomRate = function (checkINGuest) {
            var checkINGuestRoom = $scope.CheckINGuestRooms.filter(x => x.FolioNo == checkINGuest.FolioNo && x.RoomMasterId == checkINGuest.RoomMasterId);
            checkINCommonService.SetRate($scope,checkINGuestRoom[0]);
        }

        function SetExtraBedTariff(checkINGuestRoom) {
            
            angular.forEach(checkINGuestRoom.RoomTypeRates, function (rate, index) {

                if (checkINGuestRoom.RateMasterId == rate.RateMasterId) {

                    angular.forEach($scope.RateMasters, function (rateMaster, index) {
                        if (rateMaster.Id == checkINGuestRoom.RateMasterId) {
                            checkINGuestRoom.RateTypeId = rateMaster.RateTypeId;
                        }
                    });

                    //ExtraBed
                    checkINGuestRoom.ExtraBedAdultRate = 0;
                    checkINGuestRoom.ExtraBedChildRate = 0;
                    checkINGuestRoom.ExtraBedInfantRate = 0;
                    checkINGuestRoom.ExtraBedMealPlanDayRate = 0;
                    checkINGuestRoom.TotalExtraBedAmount = 0;
                    checkINGuestRoom.TotalExtraBedTAXAmount = 0;

                    var occupancy = parseFloat(checkINGuestRoom.NumberOfAdult) + parseFloat(checkINGuestRoom.NumberOfChild) + parseFloat(checkINGuestRoom.NumberOfInfant);
                    var extraBedOccupancy = parseFloat(checkINGuestRoom.NumberOfAdultExtraBed) + parseFloat(checkINGuestRoom.NumberOfChildExtraBed) + parseFloat(checkINGuestRoom.NumberOfInfantExtraBed);
                    if (extraBedOccupancy) {
                        occupancy = parseFloat(occupancy) - parseFloat(extraBedOccupancy);
                    }
                    checkINCommonService.SetTax($scope,checkINGuestRoom);

                    //Extra Bed
                    checkINGuestRoom.ExtraBedAdultRate = parseFloat(rate.ExtraBedAdultRate);
                    checkINGuestRoom.ExtraBedChildRate = parseFloat(rate.ExtraBedChildRate);
                    checkINGuestRoom.ExtraBedInfantRate = parseFloat(rate.ExtraBedInfantRate);

                    angular.forEach(rate.OccupancyRates, function (occupancyRate, index) {
                        if (checkINGuestRoom.ExtraBedNumber == occupancyRate.OccupancyId) {
                            angular.forEach(occupancyRate.OccupancyMealPlanRates, function (occupancyMealPlanRate, index) {

                                if (checkINGuestRoom.MealPlanId == occupancyMealPlanRate.MealPlanId) {
                                    checkINGuestRoom.ExtraBedMealPlanCode = occupancyMealPlanRate.MealPlanCode;
                                    checkINGuestRoom.ExtraBedMealPlanDayRate = occupancyMealPlanRate.RateDay1;
                                }
                            });
                        }
                    });
                }
            });

        }
        
        $scope.GetChangeRate = function (fromId) {
            checkINCommonService.GetChangeRate($scope,fromId)
        };

        //Navneet

        $scope.IsInclusive = function (selectedRoom) {
            checkINCommonService.IsInclusive($scope, selectedRoom);
        };

        $scope.ChangeRateDiscountValue = function (roomRate, index) {
            checkINCommonService.ChangeRateDiscountValue($scope, roomRate, index);
        };
        $scope.CalculateDiscount = function (roomRate, index) {
            checkINCommonService.CalculateDiscount($scope, roomRate, index);
        };

        $scope.ChangeDayRate = function (roomRate, index) {
            checkINCommonService.ChangeDayRate($scope, roomRate, index);
        };

        $scope.ResetRate = function () {
            //$scope.SetRoomOwner();
            $scope.SetSNo();
            $scope.SetCheckINGuestRoom();
        }
        //Navneet End----------------------------------------------

        $scope.PackageTariff = 0;
        $scope.PackageMP = 0;

        $scope.GetPackageDetails = function (packageId) {

            $scope.CheckINGuestRoom.PackageMealPlanId = '';
            $scope.CheckINGuestRoom.MealPlanCode = '';
            $scope.CheckINGuestRoom.PackageMaxPax = '';
            $scope.CheckINGuestRoom.PackageAmount = '';
            $scope.CheckINGuestRoomPackageDetails = [];

            angular.forEach($scope.CheckINGuestRoomPackages, function (item) {
                if (item.Id == packageId) {
                    $scope.CheckINGuestRoom.PackageMealPlanId = item.MealPlanId;
                    $scope.CheckINGuestRoom.MealPlanCode = item.MealPlanCode;
                    $scope.CheckINGuestRoom.PackageMaxPax = item.MaxPax;
                    $scope.CheckINGuestRoom.PackageAmount = item.PackageAmount;
                    $scope.CheckINGuestRoomPackageDetails = item.PackageDetails;
                }
            });

            $scope.PackageTariff = 0;
            $scope.PackageTariffTax = 0;

            $scope.PackageMP = 0;
            $scope.PackageMPTax = 0;

            angular.forEach($scope.CheckINGuestRoomPackageDetails, function (item) {
                if (item.RevenueHeadCode == 'TRF') {

                    $scope.PackageRateTaxStructureId = item.TaxStructureId;

                    if (item.RevenueINId == '2') {

                        if (item.IsTaxInclusive) {
                            $scope.PackageTariff = parseFloat(item.Amount) - parseFloat(item.TaxAmount);
                        }
                        else {
                            $scope.PackageTariff = parseFloat(item.Amount);
                        }
                    }
                    else {
                        if (item.IsTaxInclusive) {
                            $scope.PackageTariff = parseFloat(item.RevenueValue) - parseFloat(item.TaxAmount);
                        }
                        else {
                            $scope.PackageTariff = parseFloat(item.RevenueValue);
                        }
                    }
                }
                else if (item.RevenueHeadCode == 'MP') {
                    $scope.PackageMealPlanTAXStructureId = item.TaxStructureId;

                    if (item.RevenueINId == '2') {
                        $scope.PackageMP = item.Amount;
                        $scope.PackageMPTax = item.TaxAmount;
                    }
                    else {
                        $scope.PackageMP = item.RevenueValue;
                        $scope.PackageMPTax = item.TaxAmount;
                    }
                }
                else {
                    if (item.RevenueINId == '2') {
                        $scope.CheckINGuestRoom.TempAmount = item.TaxAmount;
                    }
                    else {
                        $scope.CheckINGuestRoom.TempAmount = item.RevenueValue;
                    }
                }
            });

            $scope.ResetRateForPackage();
        };

        $scope.ResetRateForPackage = function () {

            $scope.CheckINGuestRoom.TariffLinkTaxStructures = [];
            $scope.CheckINGuestRoom.MealPlanLinkTaxStructures = [];
            $scope.CheckINGuestRoom.RateTaxStructureId = $scope.PackageRateTaxStructureId;
            $scope.CheckINGuestRoom.MealPlanTaxStructureId = $scope.PackageMealPlanTAXStructureId;

            angular.forEach($scope.TaxStructures, function (tax) {
                if ($scope.CheckINGuestRoom.RateTaxStructureId == tax.Id) {
                    $scope.CheckINGuestRoom.TariffLinkTaxStructures = angular.copy(tax.LinkTaxStructures);
                }
                if ($scope.CheckINGuestRoom.MealPlanTaxStructureId == tax.Id) {
                    $scope.CheckINGuestRoom.MealPlanLinkTaxStructures = angular.copy(tax.LinkTaxStructures);
                }
            });
            
            angular.forEach($scope.CheckINGuestRoom.CheckINGuestRoomRates, function (item) {
                item.MealPlanDayRate = parseFloat($scope.PackageMP) / parseFloat($scope.CheckINGuestRoom.CheckINGuestRoomRates.length);
                item.MealPlanDayRate = $filter("number")(item.MealPlanDayRate, 2).replace(/,/g, "");

            });

            checkINCommonService.CalculateCheckINRoom($scope);

        };
       

        $scope.HideRateChangeBox = function () {
            // $scope.ShowChangeRate = false;
        };

        $scope.IsExtraBed = false;
        $scope.ShowRateChangeBoxCheckIN = function (checkINGuestRoom, index, isExtraBed) {

            $scope.IsExtraBed = isExtraBed;
            $scope.CheckINRoomRatePackages = [];
            $scope.IsMultiRate = "1";
            scrollPageOnTop();
            //$scope.ShowChangeRate = true;
            var corporateId = '';
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                
                if (checkINGuestRoom.SNo == checkINGuest.SNo && checkINGuestRoom.RoomTypeId == checkINGuest.RoomTypeId) {
                    corporateId = checkINGuest.CorporateId;
                }
            });

            $scope.CheckINGuestRoom = checkINGuestRoom;
            $scope.CheckINGuestRoom.CorporateId = corporateId;
            $scope.CheckINGuestRoom.SNo = index + 1;
            if ($scope.CheckINGuestRoom.IsMultiRate == true) {
                $scope.IsMultiRate = "2"
            }
            if ($scope.CheckINGuestRoom.PackageId != null && $scope.CheckINGuestRoom.PackageId.length > 0) {
                $scope.IsMultiRate = "3"

                angular.forEach($scope.Packages, function (item) {
                    if (item.RoomTypeId == $scope.CheckINGuestRoom.RoomTypeId) {
                        $scope.CheckINRoomRatePackages.push(item);
                    }
                });

                $scope.CheckINGuestRoom.PackageId = $scope.CheckINGuestRoom.PackageId;
            }
        };

        $scope.ResetRoomRate = function () {

            angular.forEach($scope.CheckINGuestRooms, function (room) {

                room.TotalDayRate = 0;
                room.TotalDayRateAmount = 0;
                room.TotalTariffTAXAmount = 0;
                room.TotalTariff = 0;
                room.TotalMealPlanDayRateAmount = 0;
                room.TotalMealPlanTAXAmount = 0;
                room.TotalMealPlan = 0;
                room.TotalNetDayAmount = 0;

                angular.forEach(room.CheckINGuestRoomRates, function (rate) {

                    var i = 1;
                    rate.IsRateDisabled = false;
                    rate.FolioNo = room.FolioNo;
                    rate.TariffTAXAmount = 0;
                    rate.MealPlanTAXAmount = 0;
                    rate.RateDiscountAmount = 0;
                    rate.NetDayAmount = 0;
                    rate.CheckINGuestRoomRateTaxs = [];

                    rate.DayRateAmount = rate.DayRate;
                });
            });

        }
        $scope.TariffLinkTaxStructures = [];
        $scope.MealPlanLinkTaxStructures = [];
        $scope.ApplyRateForSameRoomType = function () {

            var arrivalDate = GetMomentDate($scope.ReservationRoomType.ArrivalDate, $scope.DateFormat);
            var departureDate = GetMomentDate($scope.ReservationRoomType.DepartureDate, $scope.DateFormat);

            angular.forEach($scope.ReservationRoomTypes, function (item, index) {

                var itemArrivalDate = GetMomentDate(item.ArrivalDate, $scope.DateFormat);
                var itemDepartureDate = GetMomentDate(item.DepartureDate, $scope.DateFormat);

                if (arrivalDate.isSame(itemArrivalDate) && departureDate.isSame(itemDepartureDate)) {
                    
                    if ($scope.ReservationRoomType.RoomTypeId == item.RoomTypeId && $scope.ReservationRoomType.NumberOfPax == item.NumberOfPax && $scope.ReservationRoomType.SNo != item.SNo) {
                        $scope.ReservationRoomTypes[index].IsInclusive = $scope.ReservationRoomType.IsInclusive;
                        $scope.ReservationRoomTypes[index].IsTariffPlanInclusive = $scope.ReservationRoomType.IsTariffPlanInclusive;
                        $scope.ReservationRoomTypes[index].IsTariffTAXInclusive = $scope.ReservationRoomType.IsTariffTAXInclusive;

                        $scope.ReservationRoomTypes[index].RateMasterId = $scope.ReservationRoomType.RateMasterId;
                        $scope.ReservationRoomTypes[index].TotalDayRateAmount = $scope.ReservationRoomType.TotalDayRateAmount;
                        $scope.ReservationRoomTypes[index].RateTaxStructureId = $scope.ReservationRoomType.RateTaxStructureId;
                        $scope.ReservationRoomTypes[index].TotalTariffTAXAmount = $scope.ReservationRoomType.TotalTariffTAXAmount;

                        $scope.ReservationRoomTypes[index].MealPlanId = $scope.ReservationRoomType.MealPlanId;
                        $scope.ReservationRoomTypes[index].MealPlanCode = $scope.ReservationRoomType.MealPlanCode;
                        $scope.ReservationRoomTypes[index].MealPlanTAXStructureId = $scope.ReservationRoomType.MealPlanTAXStructureId;
                        $scope.ReservationRoomTypes[index].TotalMealPlanTAXAmount = $scope.ReservationRoomType.TotalMealPlanTAXAmount;
                        $scope.ReservationRoomTypes[index].TotalMealPlanDayRateAmount = $scope.ReservationRoomType.TotalMealPlanDayRateAmount;

                        $scope.ReservationRoomTypes[index].TotalAmount = $scope.ReservationRoomType.TotalAmount;
                        $scope.ReservationRoomTypes[index].PackageId = $scope.ReservationRoomType.PackageId;

                        angular.forEach($scope.ReservationRoomTypes[index].ReservationRoomTypeRates, function (reservationRoomTypeRate1) {
                            angular.forEach($scope.ReservationRoomType.ReservationRoomTypeRates, function (reservationRoomTypeRate2) {
                                if (reservationRoomTypeRate1.ChargeDate == reservationRoomTypeRate1.ChargeDate) {
                                    reservationRoomTypeRate1.RateMasterId = reservationRoomTypeRate2.RateMasterId;
                                    
                                    reservationRoomTypeRate1.RateMasterCode = reservationRoomTypeRate2.RateMasterCode;
                                    reservationRoomTypeRate1.DayRate = reservationRoomTypeRate2.DayRate;
                                    reservationRoomTypeRate1.RateDiscountInId = reservationRoomTypeRate2.RateDiscountInId;
                                    reservationRoomTypeRate1.RateDiscountValue = reservationRoomTypeRate2.RateDiscountValue;
                                    reservationRoomTypeRate1.DayRateAmount = reservationRoomTypeRate2.DayRateAmount;
                                    reservationRoomTypeRate1.RateTaxStructureId = reservationRoomTypeRate2.RateTaxStructureId;
                                    reservationRoomTypeRate1.TariffTAXAmount = reservationRoomTypeRate2.TariffTAXAmount;
                                    reservationRoomTypeRate1.TotalTariff = reservationRoomTypeRate2.TotalTariff;

                                    reservationRoomTypeRate1.MealPlanId = reservationRoomTypeRate2.MealPlanId;

                                    reservationRoomTypeRate1.MealPlanDayRate = reservationRoomTypeRate2.MealPlanDayRate;
                                    reservationRoomTypeRate1.MealPlanDiscountInId = reservationRoomTypeRate2.MealPlanDiscountInId;
                                    reservationRoomTypeRate1.MealPlanDiscountValue = reservationRoomTypeRate2.MealPlanDiscountValue;
                                    reservationRoomTypeRate1.MealPlanDayRateAmount = reservationRoomTypeRate2.MealPlanDayRateAmount;
                                    reservationRoomTypeRate1.MealPlanTAXStructureId = reservationRoomTypeRate2.MealPlanTAXStructureId;
                                    reservationRoomTypeRate1.MealPlanTAXAmount = reservationRoomTypeRate2.MealPlanTAXAmount;
                                    reservationRoomTypeRate1.TotalMealPlan = reservationRoomTypeRate2.TotalMealPlan;
                                    reservationRoomTypeRate1.NetDayAmount = reservationRoomTypeRate2.NetDayAmount;
                                }
                            });
                        });
                    }
                }
            });

            checkINCommonService.GetTotal($scope);
            $("#rateChangeBoxCheckIN").modal('hide');
            parent.successMessage("Rate successfully apply to same Room Type"); scrollPageOnTop();

        };

        //End Rate Change

        $("#BookerSearch").autocomplete({
            source: function (request, response) {

                if (!$scope.Bookers || $scope.Bookers.length < 1) {
                    msg('Bookers not available.');
                    return;
                }
                $scope.BookerListSearched = [];
                angular.forEach($scope.Bookers, function (item) {
                    if (item.Name.toLowerCase().indexOf(request.term.toLowerCase()) > -1) {
                        $scope.BookerListSearched.push(item);
                    }
                });
                if (!$scope.BookerListSearched || $scope.BookerListSearched.length < 1) {
                    msg('Bookers not found.');
                    $("#BookerSearch").val("");
                    return;
                }
                response($.map($scope.BookerListSearched, function (item) {
                    return {
                        label: item.Name + ': ' + item.Code + ': ' + item.City,
                        val: item
                    };
                }));
            },
            select: function (e, ui) {
                if (ui.item) {
                    if (ui.item.value !== "No Record Found!") {
                        ui.item.value = ui.item.val.Name;
                        $scope.Model.BookerId = ui.item.val.Id;
                        $scope.Model.BookerName = ui.item.val.Name;
                    }
                }
            },
            minLength: 1
        });

        $scope.getAutoSuggest = function (index, txt) {

            $("#CorporateName" + index).autocomplete({
                source: function (request, response) {
                    angular.forEach($scope.Model.CheckINGuests, function (checkINGuest, key) {
                        if (index == key) {
                            checkINGuest.CorporateId = "";
                        }
                    });
                    $scope.CorporateRates = [];
                    if (!$scope.Corporates || $scope.Corporates.length < 1) {
                        msg('Corporates not available.');
                        $scope.Model.CheckINGuests[index].CorporateId = '';
                        $scope.Model.CheckINGuests[index].CorporateName = '';
                        $scope.SetCheckINGuestRoom();
                        return;
                    }
                    $scope.CorporateListSearched = [];
                    angular.forEach($scope.Corporates, function (item) {
                        if (item.Name.toLowerCase().indexOf(request.term.toLowerCase()) > -1) {
                            $scope.CorporateListSearched.push(item);
                        }
                    });
                    if (!$scope.CorporateListSearched || $scope.CorporateListSearched.length < 1) {
                        msg('Corporates not found.');
                        $scope.Model.CheckINGuests[index].CorporateId = '';
                        $scope.Model.CheckINGuests[index].CorporateName = '';
                        $scope.SetCheckINGuestRoom();

                        return;
                    }
                    response($.map($scope.CorporateListSearched, function (item) {
                        return {
                            label: item.Name + ' : ' + item.Code,
                            val: item
                        };
                    }));
                },
                select: function (e, ui) {

                    if (ui.item) {
                        if (ui.item.value !== "No Record Found!") {
                            var corporateId = ui.item.val.Id;
                            var corporateName = ui.item.val.Name;
                            $scope.Model.CheckINGuests[index].CorporateId = corporateId;
                            $scope.Model.CheckINGuests[index].CorporateName = corporateName;
                            $scope.CorporateDiscounts = [];
                            var promiseGet = checkINService.getCorporateById(corporateId);
                            promiseGet.then(function (data, status) {
                                $scope.Corporate = data.Data;
                                $scope.CorporateDiscounts = $scope.Corporate.CorporateDiscounts;
                                $scope.CorporateRates = $scope.Corporate.RateMasters;
                                $scope.SetCheckINGuestRoom();
                                $scope.showBlackListAlert($scope.Corporate.IsBlackList, 'c');
                            },
                                function (error, status) {
                                    parent.failureMessage(error.Message); scrollPageOnTop();
                                });

                        }
                    }
                },
                minLength: 1
            });
        }

        $scope.getMessageList = function (messageTypeId, messageForTypeId, messageForId) {

            guestMessageService.getMessageListCaller($scope.PropertyID, messageForTypeId, messageForId, messageTypeId)
                .then(function (result) {

                    $scope.messages = $filter('groupBy')(result.Collection, 'MessageToName');
                    if ($scope.messages && $scope.messages['0000']) {
                        $scope.beforePopup($scope.messages['0000']);
                        $("#modalGuestMessage").modal({ backdrop: 'static', keyboard: false });
                    }
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.validateEmail = function (event) {
            // 
            if (event.currentTarget.value == "") {
                $(event.currentTarget).removeClass("danger");
                $(event.currentTarget).addClass("success");
                return false;
            }
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (expr.test((event.currentTarget.value)) == false) {
                event.currentTarget.value = "";
                $(event.currentTarget).removeClass("success");
                $(event.currentTarget).addClass("danger");
                return false;
            } else {
                $(event.currentTarget).addClass("success");
                return true;
            }
        };
        $scope.validateEmail1 = function (event) {
            // 
            if (event.currentTarget.value == "") {
                $(event.currentTarget).removeClass("error");
                //$(event.currentTarget).addClass("success");
                return false;
            }
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (expr.test((event.currentTarget.value)) == false) {
                event.currentTarget.value = "";
                //$(event.currentTarget).removeClass("success");
                $(event.currentTarget).addClass("error");
                return false;
            } else {
                //$(event.currentTarget).addClass("success");
                $(event.currentTarget).removeClass("error");
                return true;
            }
        };
        
        $scope.showAdvanceBox = function (checkINGuestRoom) {
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                if (checkINGuestRoom.RoomMasterId == checkINGuest.RoomMasterId && checkINGuestRoom.FolioNo == checkINGuest.FolioNo && checkINGuest.IsRoomOwner == true) {
                    $scope.SelectedCheckINGuest = checkINGuest;
                }
            });
            if(!$scope.SelectedCheckINGuest.CheckINGuestAdvances)
            {
            }

        };

        $scope.ConfirmAdvance = function(){
            

            //if(!$scope.SelectedCheckINGuest.CheckINGuestAdvances[0].ReferenceNo)
            //{
            //    parent.popErrorMessage("Please Enter Reference No.");
            //    scrollPageOnTop();
            //    return;
            //}
            if(!$scope.SelectedCheckINGuest.CheckINGuestAdvances[0].CurrencyMasterId)
            {
                parent.popErrorMessage("Please Select Currency.");
                scrollPageOnTop();
                return;
            }
            if(!$scope.SelectedCheckINGuest.CheckINGuestAdvances[0].RevenueHeadCode)
            {
                parent.popErrorMessage("Please Select Revenue.");
                scrollPageOnTop();
                return;
            }
            if($scope.SelectedCheckINGuest.CheckINGuestAdvances[0].Amount<0)
            {
                parent.popErrorMessage("Please Enter Amount.");
                scrollPageOnTop();
                return;
            }

            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                if ($scope.SelectedCheckINGuest.RoomMasterId == checkINGuest.RoomMasterId && $scope.SelectedCheckINGuest.FolioNo == checkINGuest.FolioNo && checkINGuest.IsRoomOwner == true) {
                    checkINGuest.CheckINAdvance=$scope.SelectedCheckINGuest.CheckINGuestAdvances[0].Amount;
                }
            });
            
            
            $scope.GetTotal()
            $("#modalAdvance").modal('hide');
        }

        $scope.ResetReservationSearch();

        $scope.GetTotal = function () {
            checkINCommonService.GetTotal($scope);
        }
        $scope.resetGuestRooms = function () {
            angular.forEach($scope.Model.CheckINGuests, function (guest) {
                if (!guest.IsCheckedIN) {
                    guest.RoomMasterId = '';
                    guest.RoomNumber = '';
                    guest.IsExtraBed = false;
                }

            });
            
            $scope.CheckINGuestRooms = [];
            checkINCommonService.GetTotal($scope);
        };

        $scope.GetDistinctFolio = function (list) {

            var distinctFolios = [];
            var newArr = list.filter(function (el) {
                if (distinctFolios.indexOf(el.FolioNo) === -1) {
                    // If not present in array, then add it
                    distinctFolios.push(el.FolioNo);
                    return true;
                }
                else {
                    // Already present in array, don't add it
                    return false;
                }
            });
            return distinctFolios;
        };

        //WalkIN Corporate
        $scope.WalkINCorporate = {};
        $scope.CorporateContact = {};

        $scope.SaveCorporate = function (form) {

            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                scrollPageOnTop();
                return;
            }

            if ($scope.WalkINCorporate.CorporateCategoryId) {
                if (parseFloat($scope.WalkINCorporate.CorporateCategoryId) < 1) {
                    parent.popErrorMessage("Please Select Corporate Category.");
                    scrollPageOnTop();
                    return;
                }
            }
            else {
                parent.popErrorMessage("Please Select Corporate Category.");
                scrollPageOnTop();
                return;
            }

            if ($scope.CorporateContact.Name) {
                if ($scope.CorporateContact.Name.length > 0) {
                    if (!$scope.CorporateContact.Designation) {
                        parent.popErrorMessage("Please Select Contact Person Designation.");
                        scrollPageOnTop();
                        return;
                    }

                    if (!$scope.CorporateContact.Mobile1) {
                        parent.popErrorMessage("Please Select Contact Person Mobile.");
                        scrollPageOnTop();
                        return;
                    }

                    $scope.WalkINCorporate.CorporateContacts = [];
                    $scope.WalkINCorporate.CorporateContacts.push({
                        Name: $scope.CorporateContact.Name,
                        Designation: $scope.CorporateContact.Designation,
                        Email: $scope.CorporateContact.Email,
                        PhoneNo: $scope.CorporateContact.PhoneNo,
                        Ext: $scope.CorporateContact.Ext,
                        Mobile1: $scope.CorporateContact.Mobile1,
                    });
                }
            }

            $scope.WalkINCorporate.IsActive = true;
            $scope.WalkINCorporate.PropertyID = $scope.PropertyID;
            $scope.WalkINCorporate.ModifiedBy = $scope.UserName;
            $scope.WalkINCorporate.ModifiedDate = $scope.ModifiedDate;

            var promiseGet = checkINService.saveCorporate($scope.WalkINCorporate);
            promiseGet.then(function (data, status) {

                if (data.Status) {

                    $("#walkINCorporateBox").modal('hide');
                    parent.successMessage("Corporate saved successfully.");

                    var promiseGet1 = checkINService.getCorporateByCode($scope.WalkINCorporate.Code, $scope.PropertyID);
                    promiseGet1.then(function (data, status) {

                        $scope.WalkINCorporate = {};
                        $scope.CorporateContact = {};

                        if (data.Status) {
                            $scope.WalkINCorporate.Id = data.Data.Id;
                            $scope.WalkINCorporate.Name = data.Data.Name;


                            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest, key) {
                                if (key == $scope.SelectedIndex) {
                                    $scope.Corporates.push({
                                        Id: $scope.WalkINCorporate.Id,
                                        Name: $scope.WalkINCorporate.Name
                                    })

                                    checkINGuest.CorporateName = $scope.WalkINCorporate.Name;
                                    checkINGuest.CorporateId = $scope.WalkINCorporate.Id;
                                }
                            });

                        }
                    },
                        function (error, status) {
                            parent.failureMessage(error.Message); scrollPageOnTop();
                        });
                }
            },
                function (error, status) {
                    parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
                });
        };

        $scope.SelectedIndex = 0;
        $scope.OpenWalkINCorporateBox = function (index) {
            $scope.SelectedIndex = index;
            $("#walkINCorporateBox").modal('show');
            $scope.WalkINCorporate.CorporateCategoryId = '5';
            $scope.WalkINCorporate.CountryId = $scope.DefaultSetting.CountryMasterId.toString();
            $scope.GetStateByCountry($scope.WalkINCorporate.CountryId);
            $scope.WalkINCorporate.StateId = $scope.DefaultSetting.StateMasterId.toString();
        };

        $scope.ResetCorporate = function () {
            $scope.WalkINCorporate = {};
            $scope.CorporateContact = {};
            $scope.WalkINCorporate.CorporateCategoryId = '5';
        };

        $scope.States = [];
        $scope.GetStateByCountry = function (id) {

            $scope.States = [];
            var promiseGet = checkINService.getAllState(id);
            promiseGet.then(function (data) {
                $scope.States = data.Collection;
                return $scope.States;
            },
                function (error) {
                    parent.posFailureMessage(error.Message);
                });
        };

        //filters for Posting
        $scope.selectedRevenue = ['1', '3'];
        $scope.filterForRevenueHead = function (revenueHead) {
            return ($scope.selectedRevenue.indexOf(revenueHead.RevenueForId) !== -1);
        };

        //filters for Posting
        $scope.filterForRateType = function (rate) {
            
            return checkINCommonService.filterForRateType($scope,rate);
        };

        //Reservation SearchModel
        //-----------------------------------------------------------
        //Paging
        //-----------------------------------------------------------
        $scope.sortType = ""; // set the default sort type
        $scope.sortReverse = true; // set the default sort order
        $scope.searchText = "";

        var sortKeyOrder = {
            key: "",
            order: ""
        };

        if (localStorageService.get("searchfor") !== undefined) {
            $scope.searchfor = localStorageService.get("searchfor");
        }

        $scope.totalItems = 0;
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.records = "10";
        $scope.recordsPerPage = $scope.records;
        $scope.numberOfPageButtons = 10;
        $scope.sortReverse = false;

        //getData1($scope, checkINService, localStorageService);
        $scope.sort = function (col) {

            sortKeyOrder = localStorageService.get("sortKeyOrder");
            if (sortKeyOrder !== null && sortKeyOrder.key === col) {
                if (sortKeyOrder.order === "ASC")
                    sortKeyOrder.order = "DESC";
                else
                    sortKeyOrder.order = "ASC";
                localStorageService.set("sortKeyOrder", sortKeyOrder);

            } else {
                sortKeyOrder = {
                    key: col,
                    order: "ASC"
                };
                localStorageService.set("sortKeyOrder", sortKeyOrder);
            }
            getData1($scope, checkINService, localStorageService);
        };

        $scope.pageChanged = function () {
            getData1($scope, checkINService, localStorageService);
        };

        $scope.search = function (searchfor) {
            $scope.SearchReservationList = [];
            $scope.IsProgress = true;
            $scope.SearchModel.PropertyID = $scope.PropertyID;
            $scope.SearchModel.IsPending = true;

            if ($scope.SearchModel.ArrivalDateString) {
                $scope.SearchModel.ArrivalDate = GetServerDate($scope.SearchModel.ArrivalDateString, $scope.DateFormat);
            }
            if ($scope.SearchModel.DepartureDateString) {
                $scope.SearchModel.DepartureDate = GetServerDate($scope.SearchModel.DepartureDateString, $scope.DateFormat);
            }

            if (searchfor === undefined) {
                $scope.searchfor = "";
            }
            localStorageService.set("searchfor", searchfor);
            getData1($scope, checkINService, localStorageService);
        }
        $scope.recordsonpage = function (records) {
            $scope.recordsPerPage = records;
            if (records === undefined) {
                $scope.recordsPerPage = 10;
            }
            getData1($scope, checkINService, localStorageService);
        }

        $scope.ClearDate = function (element, event) {
            if (event.keyCode == 8) {
                if (element == 'ArrivalDateString') {
                    $scope.SearchModel.ArrivalDateString = "";
                    $scope.SearchModel.ArrivalDate = "";
                }
                else if (element == 'ReservationDateString') {
                    $scope.SearchModel.ReservationDateString = "";
                    $scope.SearchModel.ReservationDate = "";
                }
                else if (element == 'DepartureDateString') {
                    $scope.SearchModel.DepartureDateString = "";
                    $scope.SearchModel.DepartureDate = "";
                }

                $scope.search();
            }
        }

        $scope.SelectReservation = function (reservation) {

            if ($scope.SelectedReservation) {
                if ($scope.SelectedReservation.Id == reservation.Id) {
                    $scope.SelectedReservation = {};
                }
                else {
                    $scope.SelectedReservation = reservation;
                }
            }
            else {
                $scope.SelectedReservation = reservation;
            }

        }
        //-----------------------------------------------------------

        $scope.SearchModel = {
            ReservationNo: '',
            ReservationDateString: '',
            Name: '',
            CorporateName: '',
            GroupDetailCode: '',
            ArrivalDateString: '',
            DepartureDateString: '',
            Nationality: '',
            MobileNo: '',
            Email: '',
            LocationTypeId: '',
            FlightNo: '',
            PropertyID: '',
            IsPending: true,
        };

        $scope.$on("CallParentMethod", function (event, obj) {
            $scope.parentmethod(obj);
        });
        $scope.parentmethod = function (obj) {
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {

                angular.forEach($scope.ActiveCamera, function (item) {
                    
                    if (item.Id == obj.Id && checkINGuest.SNo == obj.SNo && checkINGuest.RoomTypeId == obj.RoomTypeId) {
                        $scope.$apply(function () {
                            checkINGuest.ImageUrl = obj.UploadImageUrl;
                            checkINGuest.ImageUrlForDisplay = apiPath + obj.UploadImageUrl;
                        });
                    }
                });
            });
        };
        $scope.$on("CallAcceptCheckINGuest", function (event, obj) {
            $scope.SetCheckINGuestSignature(obj);
        });
        $scope.$on("CallDeclineCheckINGuest", function (event, obj) {
            $scope.SetDeclineCheckINGuest(obj);
        });

        $scope.SetCheckINGuestSignature = function (obj) {
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                if (checkINGuest.CheckINGuestAcceptId == obj.GUID) {
                    $scope.$apply(function () {
                        checkINGuest.SignatureUrl = obj.SignatureUrl;
                        checkINGuest.SignatureUrlForDisplay = apiPath + obj.SignatureUrl;
                        checkINGuest.IsAccept = true;
                        checkINGuest.IsDecline = false;
                    });
                }
                parent.popSuccessMessage('Guest verified details successfully.'); scrollPageOnTop();
            });
        };
        $scope.SetDeclineCheckINGuest = function (obj) {
            angular.forEach($scope.Model.CheckINGuests, function (checkINGuest) {
                if (checkINGuest.CheckINGuestAcceptId == obj.GUID) {
                    $scope.$apply(function () {
                        checkINGuest.IsAccept = false;
                        checkINGuest.IsDecline = true;
                    });
                }
            });
            parent.popErrorMessage('Guest Decline the details.'); scrollPageOnTop();
        };

        $scope.formdata1 = new FormData();
        $scope.addDocument = function (doc) {
            if (!$scope.guest) return;
            if (!$scope.guest.Mobile) {
                msgInPopup('Please enter guest mobile.');
                return;
            }
            if (!$scope['docForm'].$valid) {
                $scope.ShowErrorMessageD = true;
                msg('');
                return;
            }

            doc.DocumentTypeName = $scope.DocumentTypes.find(x => x.Id == doc.DocumentTypeId).Name;
            if (!$scope.guest.GuestDocuments) $scope.guest.GuestDocuments = [];
            var newDoc = angular.copy(doc);

            imageService.file_upload($scope.PropertyID + '/guest/' + ($scope.guest.GuestId ? $scope.guest.GuestId : $scope.guest.Mobile) + '/', $scope.formdata1)
                .then(function (s) {
                    if (s.Message && s.Message.indexOf('rror') > -1) {
                        msgInPopup(s.Message);
                        return;
                    }
                    $scope.guest.GuestDocuments.push(newDoc);
                    $scope.resetGuestDocument();// $scope.doc={};
                    var filePaths = s.Collection;
                    newDoc.Path = filePaths && filePaths.length > 0 ? filePaths[0].fileNameLarge : '';
                }).catch(function (e) {
                    msgInPopup(e);
                });
            if (!newDoc.ExpiryDateString) newDoc.ExpiryDateString = $scope.ModifiedDate;

        };
        $scope.deleteDocument = function (doc) {
            if (!$scope.guest || !doc) return;
            $scope.guest.GuestDocuments = $scope.guest.GuestDocuments.filter(x => x.Id != doc.Id);
        };
        $scope.resetGuestDocument = function () {
            $scope.doc = {};
            $scope.formdata1 = new FormData();
            document.getElementById("guestDocFile").value = '';
        };
     
        //Verfication
        $scope.ShowGuestInfo=true;
        $scope.ShowTermsConditions=false;
        $scope.CheckINGuestVerification ={};
        $scope.SaveCheckINGuestVerification = function(checkINGuest){
            
            //BillingInstructionName
            if($scope.Model.BillingInstructionId)
            {
                angular.forEach($scope.BillingInstructions,function(item){
                    if(item.Id == $scope.Model.BillingInstructionId)
                    {
                        $scope.Model.BillingInstructionName= item.Name;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select Billing Instruction.');
                return;
            }
            //BookingTypeName
            if($scope.Model.BookingTypeId)
            {
                angular.forEach($scope.BookingTypes,function(item){
                    if(item.Id == $scope.Model.BookingTypeId)
                    {
                        $scope.Model.BookingTypeName = item.Name;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select Booking Type.');
                return;
            }
            
            //RevenueHeadName
            if($scope.Model.RevenueHeadId)
            {
                //TODO: Navneet
                
                angular.forEach($scope.SettlementModeDetails,function(item){
                    if(item.RevenueHeadId == $scope.Model.RevenueHeadId)
                    {
                        $scope.Model.RevenueHeadName = item.RevenueHeadName;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select Settlement Mode.');
                return;
            }
           
            //CurrencyName
            if($scope.Model.CurrencyMasterId)
            {
                angular.forEach($scope.Currencys,function(item){
                    if(item.Id == $scope.Model.CurrencyMasterId)
                    {
                        $scope.Model.CurrencyName = item.Name;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select Currency.');
                return;
            }
            
            //SalutationName
            if(checkINGuest.SalutationId)
            {
                angular.forEach($scope.Salutations,function(item){
                    if(item.Id == checkINGuest.SalutationId)
                    {
                        checkINGuest.SalutationName = item.Name;
                    }
                }); 
            }
            else
            {
                parent.popErrorMessage('Please Select Salutation.');
                return;
            }
            
            //GenderName
            //StateName
            if(checkINGuest.StateId)
            {
                angular.forEach(checkINGuest.StateList,function(item){
                    if(item.Id == checkINGuest.StateId)
                    {
                        checkINGuest.StateName = item.Name;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select State.');
                return;
            }
           
            if(checkINGuest.RoomMasterId)
            {
                angular.forEach(checkINGuest.AvailableRooms,function(item){
                    if(item.Id == checkINGuest.RoomMasterId)
                    {
                        checkINGuest.RoomNumber = item.RoomNumber;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select Room No.');
                return;
            }
            
            //RoomTypeName
            if(checkINGuest.RoomTypeId)
            {
                angular.forEach($scope.RoomTypes,function(item){
                    if(item.Id == checkINGuest.RoomTypeId)
                    {
                        checkINGuest.RoomTypeName = item.Name;
                    }
                });
            }
            else
            {
                parent.popErrorMessage('Please Select Room Type.');
                return;
            }
            
            //CheckINGuestRoom
            if(!checkINGuest.CheckINGuestRoom)
            {
                parent.popErrorMessage('Please Select Room.');
                return;
            }
            
            $scope.CheckINGuestVerification ={

                ReservationNo: $scope.Model.ReservationNo,
                ReservationDate : $scope.Model.ReservationDate,
                CheckINDate : $scope.Model.CheckINDate,
                CheckINTime : $scope.Model.CheckINTimeForDisplayD,
                CheckOUTDate : $scope.Model.CheckOUTDate,
                CheckOUTTime : $scope.Model.CheckOUTTimeForDisplayD,
                BookerName : $scope.Model.BookerName,
                BookingTypeName : $scope.Model.BookingTypeName,
                BillingInstructionName : $scope.Model.BillingInstructionName,
                RevenueHeadName : $scope.Model.RevenueHeadName,
                CurrencyName : $scope.Model.CurrencyName,
                CurrencyRate : $scope.Model.CurrencyRate,
                IsRateDisplay : $scope.Model.IsRateDisplay,

                NumberOfAdult   : checkINGuest.CheckINGuestRoom.NumberOfAdult,
                NumberOfChild   : checkINGuest.CheckINGuestRoom.NumberOfChild,
                NumberOfInfant  : checkINGuest.CheckINGuestRoom.NumberOfInfant,
                NumberOfPax     : checkINGuest.CheckINGuestRoom.NumberOfPax,
                
                SNo : checkINGuest.SNo,
                FolioNo : checkINGuest.FolioNo,
                SalutationName : checkINGuest.SalutationName,
                GenderName : checkINGuest.GenderName,
                Name : checkINGuest.Name,
                CorporateName : checkINGuest.CorporateName,
                DOB : checkINGuest.DOB,
                PlaceofBirth : checkINGuest.PlaceofBirth,
                PaxTypeName : checkINGuest.PaxTypeName,
                DOA : checkINGuest.DOA,
                SpouseName : checkINGuest.SpouseName,
                SpouseDOB : checkINGuest.SpouseDOB,
                Address1 : checkINGuest.Address1,
                Address2 : checkINGuest.Address2,
                StateName : checkINGuest.StateName,
                City : checkINGuest.City,
                PIN : checkINGuest.PIN,
                Mobile : checkINGuest.Mobile,
                EmailId : checkINGuest.EmailId,
                Nationality : checkINGuest.Nationality,
                GuestClassName : checkINGuest.GuestClassName,
                GuestStatusName : checkINGuest.GuestStatusName,
                PassportNo : checkINGuest.PassportNo,
                IssuePlace : checkINGuest.IssuePlace,
                IssueCountry : checkINGuest.IssueCountry,
                IssueDate : checkINGuest.IssueDate,
                IsIssueDateVerified : checkINGuest.IsIssueDateVerified,
                ExpiryDate : checkINGuest.ExpiryDate,
                IsExpiryDateVerified : checkINGuest.IsExpiryDateVerified,
                VisaNo : checkINGuest.VisaNo,
                IssueVisaPlace : checkINGuest.IssueVisaPlace,
                IssueVisaDate : checkINGuest.IssueVisaDate,
                IsIssueVisaDateVerified : checkINGuest.IsIssueVisaDateVerified,
                ExpiryVisaDate : checkINGuest.ExpiryVisaDate,
                IsExpiryVisaDateVerified : checkINGuest.IsExpiryVisaDateVerified,
                //IsMinor : $scope.Model.IsMinor,
                GuardianName : checkINGuest.GuardianName,
                GuardianPassportNo : checkINGuest.GuardianPassportNo,
                IsExtraBed : checkINGuest.IsExtraBed,
                ReferenceNo : checkINGuest.ReferenceNo,
                AdvanceAmount : checkINGuest.AdvanceAmount,
                SignatureUrl : checkINGuest.SignatureUrl,
                ImageUrl : checkINGuest.ImageUrl,
                //PackageName : checkINGuest.CheckINGuestRoom.PackageName,
                RoomNumber : checkINGuest.RoomNumber,
                RoomTypeName : checkINGuest.RoomTypeName,
                RateMasterCode : checkINGuest.CheckINGuestRoom.RateMasterCode,
                TotalDayRateAmount : checkINGuest.CheckINGuestRoom.TotalDayRateAmount,
                TotalTariffTAXAmount : checkINGuest.CheckINGuestRoom.TotalTariffTAXAmount,
                TotalMealPlanDayRateAmount : checkINGuest.CheckINGuestRoom.TotalMealPlanDayRateAmount,
                TotalMealPlanTAXAmount : checkINGuest.CheckINGuestRoom.TotalMealPlanTAXAmount,
                ExtraBedNumber : checkINGuest.CheckINGuestRoom.ExtraBedNumber,
                TotalExtraBedAmount : checkINGuest.CheckINGuestRoom.TotalExtraBedAmount,
                TotalExtraBedTAXAmount : checkINGuest.CheckINGuestRoom.TotalExtraBedTAXAmount,
                TotalExtraBedMealPlanDayRate : checkINGuest.CheckINGuestRoom.TotalExtraBedMealPlanDayRate,
                TotalExtraBedMealPlanTAXAmount : checkINGuest.CheckINGuestRoom.TotalExtraBedMealPlanTAXAmount,
                TotalDayAmount : checkINGuest.CheckINGuestRoom.TotalDayAmount,
                MealPlanName : checkINGuest.CheckINGuestRoom.MealPlanCode,
                IsInclusive : checkINGuest.CheckINGuestRoom.IsInclusive,
                IsTariffPlanInclusive : checkINGuest.CheckINGuestRoom.IsTariffPlanInclusive,
                IsTariffTAXInclusive : checkINGuest.CheckINGuestRoom.IsTariffTAXInclusive,
                IsMultiRate : checkINGuest.CheckINGuestRoom.IsMultiRate,
                IsPackage : checkINGuest.CheckINGuestRoom.IsPackage,
                
                PropertyID : $scope.PropertyID,
                ModifiedBy : $scope.UserName,
                ModifiedDate : $scope.ModifiedDate,

            } ;
        
            if(checkINGuest.GuestDocuments.length>0)
            {
                $scope.CheckINGuestVerification.DocumentTypeName = checkINGuest.GuestDocuments[0].DocumentTypeName;
                $scope.CheckINGuestVerification.DocumentRemarks = checkINGuest.GuestDocuments[0].Remarks;
                $scope.CheckINGuestVerification.DocumentExpiryDate = checkINGuest.GuestDocuments[0].ExpiryDate;
            }

            var promiseGet = checkINService.saveCheckINGuestVerification($scope.CheckINGuestVerification);
            promiseGet.then(function (data, status) {
                checkINGuest.CheckINGuestAcceptId = data.Data;
                parent.popSuccessMessage('Guest Verification Sent.'); scrollPageOnTop();
            },
                function (error, status) {
                    parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
                });
        };
        $scope.$on("CallOpenVerification", function (event, obj) {
            $scope.OpenVerification(obj);
        });

        $scope.OpenVerification= function(checkINGuestVerification){
            
            $scope.CheckINGuestVerification ={};
            var promiseGet = checkINService.getCheckINGuestVerification(checkINGuestVerification.GUID);
            promiseGet.then(function (data, status) {
                $scope.CheckINGuestVerification =data.Data;
                $scope.ShowGuestInfo=true;
                $scope.ShowTermsConditions=false;
                $('#VerficationBox').modal('show');
                scrollPageOnTop();
            },
                function (error, status) {
                    parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
                });
        };
        $scope.ShowCheckINGuestVerificationNext =function()
        {
            $scope.ShowGuestInfo=false;
            $scope.ShowTermsConditions=true;
        };

        $scope.showHistoryComplaints = function (history) {
            $scope.showComplaints=! $scope.showComplaints;

            checkINService.showHistoryComplaints($scope.PropertyID, history.Id)
                .then(function (s) {
                    history.Complaints=s.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };

        $scope.ResetChkGroupLeader = function(d)
        {   
            var guest = angular.copy(d);
            angular.forEach($scope.Model.CheckINGuests,function(item){
                item.IsGroupLeader=false;
            });
            angular.forEach($scope.Model.CheckINGuests,function(item){
                

                if(item.SNo == guest.SNo && item.RoomTypeId == guest.RoomTypeId)
                {
                    item.IsGroupLeader=true;
                }
            });
        }

        $scope.$on("CallCheckINLoadReservation", function (event, obj) {
            
            //$scope.getSetup();
            //$timeout(function() { 
            //    $scope.loadReservation(obj.ReservationId);
            //}, 4000);

            $scope.RoomChart = obj.RoomChart;
            $scope.loadReservation(obj.ReservationId);
            
        });

        $scope.SetDate = function () {

            var arrivalDate = GetMomentDate($scope.ArrivalDate, $scope.DateFormat);
            var departureDate = GetMomentDate($scope.DepartureDate, $scope.DateFormat);
            if (arrivalDate.isAfter(departureDate) || arrivalDate.isSame(departureDate)) {
                departureDate = angular.copy(arrivalDate);
                var d = departureDate.add(1, 'days');
                $scope.DepartureDate = GetLocalDate(d, $scope.DateFormat);
            }
            $scope.Nights = departureDate.diff(arrivalDate, 'days');
        }
        
        $scope.SetRoomType = function(checkINGuest){
            
            $scope.SelectedSearchRoomType={RoomTypes:[]};
            $scope.SelectedCheckINGuest=checkINGuest;
            $scope.SelectedRoomType={};

            if(checkINGuest.RoomTypeId)
            {
                
                var temp = $scope.RoomChart.RoomTypes.find(x=>x.Id == checkINGuest.RoomTypeId);
                $scope.SelectedRoomType = angular.copy(temp);
                $scope.SelectedSearchRoomType.RoomTypes.push({Id:$scope.SelectedRoomType.Id});
                
                $timeout(function () {
                    $scope.MonthColMarge();
                    $scope.ColMarge1();
                    $scope.HideLoader();
                    //$scope.getRoomCustom();

                    $('#roomChartBox').modal('show');
                }, 1000);

            }
            
            return;

            //$scope.SelectedSearchRoomType={RoomTypes:[]};
            //$scope.SelectedCheckINGuest=checkINGuest;
            //$scope.SelectedRoomType={};
            //var temp={};
            //angular.forEach($scope.RoomChart.RoomTypes , function(roomType){
            //    if(roomType.Id == checkINGuest.RoomTypeId)
            //    {   
            //        temp=roomType;
            //    }
            //});
           
            //$timeout(function () {

            //    $scope.SelectedRoomType=temp;
            //    $scope.SelectedSearchRoomType.RoomTypes.push({Id:$scope.SelectedRoomType.Id})

            //    $scope.MonthColMarge();
            //    $scope.ColMarge1();
            //    $scope.HideLoader();
            //    //$scope.load1($(".followMeBar"));
            //    $('#roomChartBox').modal('show');

            //    $scope.getRoomCustom();

            //}, 100); // 3 seconds
        }

        $scope.GetRoomTypeRates = function(roomTypeId)
        {
            
            var roomType = $scope.RoomTypes.find(x=>x.Id ==roomTypeId );
            if(roomType)
            {
                roomType.RoomTypeRates= $scope.OccupancyRates.filter(x=>x.RoomTypeId == roomTypeId );;
                return roomType.RoomTypeRates;
            }
            return null;

            //if(roomType.RoomTypeRates)
            //{
            //    roomTypeRates= roomType.RoomTypeRates;
            //}
            //else
            //{
            //    var promiseGet = service.getAllRoomTypeRatesByRoomTypeId(roomType.Id,$scope.PropertyID);
            //    promiseGet.then(function (data, status) {
            //        roomType.RoomTypeRates = data.Collection;
            //        return roomType.RoomTypeRates;
            //    },
            //        function (error, status) {
            //            parent.failureMessage(error.Message); scrollPageOnTop();
            //            $scope.ProgressEnd();
            //        });
            //}
        }

        $scope.SelectRoom = function(room){
            
            $scope.LinkRoomModel.SelectedRoomLinkRooms=[];
            $scope.SelectedRoomLinkRooms=[];
            $scope.SelectedCheckINGuest.RoomMasterId = room.Id;
            $scope.SelectedCheckINGuest.RoomNumber = room.Name;
            $scope.SelectedCheckINGuest.RoomTypeName = room.RoomTypeName;
            $scope.SelectedCheckINGuest.AvailableRooms=[];
            var roomStatusTypeId=1;
            var currentRoomStatusId=room.CurrentRoomStatusId;
            var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == room.RoomTypeId) ;
            
            angular.forEach(room.Days , function(roomDay){
                var futureDate = GetMomentDate($filter('date')(roomDay.FutureDate, $scope.DateFormat), $scope.DateFormat);
                var businessDateMoment = GetMomentDate(businessDate, $scope.DateFormat);
                if(roomDay.DayPart=='AM')
                {
                    if (futureDate.isSame(businessDateMoment)) {

                        if(roomDay.RoomStatusTypeId=='7' || roomDay.RoomStatusTypeId=='8')
                        {
                            if(roomStatusTypeId=='4' || roomStatusTypeId=='5' || roomStatusTypeId=='6')
                            {
                            }
                            else
                            {
                                roomStatusTypeId=roomDay.RoomStatusTypeId.toString();
                            }
                        }
                    }
                }

                if(roomDay.DayPart=='PM')
                {
                    if(roomDay.RoomStatusTypeId=='4' || roomDay.RoomStatusTypeId=='5' || roomDay.RoomStatusTypeId=='6')
                    {
                        roomStatusTypeId = roomDay.RoomStatusTypeId;
                    }
                    else if(roomDay.RoomStatusTypeId=='7' || roomDay.RoomStatusTypeId=='8')
                    {
                        if(roomStatusTypeId=='4' || roomStatusTypeId=='5' || roomStatusTypeId=='6')
                        {
                        }
                        else
                        {
                            roomStatusTypeId=7;
                        }
                    }
                }
            }); 
            //angular.forEach($scope.RoomChart.RoomTypes , function(roomType){
            //    if(roomType.Id == room.RoomTypeId)
            //    {
                    
            //    }
            //});
            
            if(roomStatusTypeId=='4' || roomStatusTypeId=='5' || roomStatusTypeId=='6')
            {
                //error message
                //$("#containerDiv").animate({ scrollTop: 0 }, "fast");
                $scope.SelectedCheckINGuest.RoomMasterId='';
                $scope.SelectedCheckINGuest.RoomNumber='';
                parent.popErrorMessage("Room is Bloked.");
                return;
            }
            else if(roomStatusTypeId=='7')
            {
                //Occupied Room
                $('#roomChartBox').modal('hide');
                $scope.SelectedCheckINGuest.AvailableRooms.push({ Id: room.Id, Name: room.Name, RoomTypeId: room.RoomTypeId, RoomTypeName: room.RoomTypeName, RoomStatusTypeId:roomStatusTypeId, MaxPerson:room.MaxPerson,RoomOrder:room.RoomOrder});
                $scope.ChangeRoom($scope.SelectedCheckINGuest);
                $scope.ResetRoomOwner();
                return;
            }
            else
            {
                if(currentRoomStatusId==2)
                {
                    //error message
                    //$("#containerDiv").animate({ scrollTop: 0 }, "fast");
                    $scope.SelectedCheckINGuest.RoomMasterId='';
                    $scope.SelectedCheckINGuest.RoomNumber='';
                    parent.popErrorMessage("Room is Dirty.");
                    return;
                }
                else
                {
                    //OK
                    $('#roomChartBox').modal('hide');
                    $scope.SelectedCheckINGuest.AvailableRooms.push({ Id: room.Id, Name: room.Name, RoomTypeId: room.RoomTypeId, RoomTypeName: room.RoomTypeName, RoomStatusTypeId:roomStatusTypeId, MaxPerson:room.MaxPerson,RoomOrder:room.RoomOrder});
                    $scope.ResetRoomOwner();
                    $scope.ChangeRoom($scope.SelectedCheckINGuest);
                }
            }

           
        }
    
        //Search

        $scope.searchModel = function () {
            $scope.SearchCount = 0;
            $scope.SearchRooms = [];
            $scope.BalanceRooms = [];
            $scope.ResetIsFindTrue();
            $scope.GetSetting();
            $scope.SelectedRoomLinkRooms=[];
            $("#searchModel").modal('show');
        }
        $scope.SearchRooms = [];
        $scope.SearchCount = 0;

        $scope.SearchRoom = function () {
            
            $scope.SearchCount = 0;
            $scope.SearchRooms = [];
            $scope.BalanceRooms = [];
            $scope.ResetIsFindTrue();

            //RoomType

            var rooms =  $scope.SelectedRoomType.Rooms;

            $scope.SearchRoomTypes = [];
            if ($scope.SelectedSearchRoomType.RoomTypes.length > 0)
            {
                angular.forEach($scope.SelectedSearchRoomType.RoomTypes, function (id) {
                    angular.forEach(rooms, function (room) {
                        if (id == room.RoomTypeId) {
                            $scope.SearchRoomTypes.push(room);
                        }
                    });
                });
            }
            else
            {
                $scope.SearchRoomTypes = rooms;
            }
            //Floor
            $scope.SearchFloors = [];
            if ($scope.SelectedSearchFloor.Floors.length > 0 && $scope.SearchRoomTypes.length > 0) {
                angular.forEach($scope.SelectedSearchFloor.Floors, function (id) {
                    angular.forEach($scope.SearchRoomTypes, function (room) {
                        if (id == room.FloorId) {
                            //$scope.SearchRooms.push({ Id: room.Id });
                            $scope.SearchFloors.push(room);
                            //$scope.AddSearchRoom(room.Id);
                        }
                    });
                });
            }
            else
            {
                $scope.SearchFloors = $scope.SearchRoomTypes;
            }
            
            //Block
            $scope.SearchBlocks = [];
            if ($scope.SelectedSearchBlock.Blocks.length > 0 && $scope.SearchFloors.length > 0) {
                angular.forEach($scope.SelectedSearchBlock.Blocks, function (id) {
                    angular.forEach($scope.SearchFloors, function (room) {
                        if (id == room.BlockId) {
                            //$scope.SearchRooms.push({ Id: room.Id });
                            $scope.SearchBlocks.push(room);
                            // $scope.AddSearchRoom(room.Id);
                        }
                    });
                });
            }
            else
            {
                $scope.SearchBlocks = $scope.SearchFloors;
            }
            
            //Mini Bar
            $scope.SearchMiniBars = [];
            if ($scope.SearchIsMiniBar && $scope.SearchBlocks.length > 0) {
                angular.forEach($scope.SearchBlocks, function (room) {
                    if (room.IsMiniBar == true) {
                        //$scope.SearchRooms.push({ Id: room.Id });
                        $scope.SearchMiniBars.push(room);
                        //$scope.AddSearchRoom(room.Id);
                    }
                });
            }
            else {
                $scope.SearchMiniBars = $scope.SearchBlocks;
            }
            
            //RoomFeature
            $scope.SearchRoomFeatures = [];
            if ($scope.SelectedSearchRoomFeature.RoomFeatures.length > 0 && $scope.SearchMiniBars.length > 0) {
                angular.forEach($scope.SearchMiniBars, function (room) {
                    var selectedRoomFeatures = [];
                    angular.forEach($scope.SelectedSearchRoomFeature.RoomFeatures, function (id) {
                        selectedRoomFeatures.push({ Id: id, IsFind: false });
                    });
                    
                    room.RoomFeatures=[];
                    room.RoomFeatures = $scope.RoomFeatureRooms.filter(x=>x.RoomMasterId == room.Id);
                    angular.forEach(room.RoomFeatures, function (roomFeature) {
                        angular.forEach(selectedRoomFeatures, function (selectedRoomFeature) {
                            if (selectedRoomFeature.Id == roomFeature.RoomFeatureId) {
                                selectedRoomFeature.IsFind = true;
                            }
                        });
                    });
                    var IsFind = true;
                    angular.forEach(selectedRoomFeatures, function (item) {
                        if (item.IsFind == false) {
                            IsFind = false;
                        }
                    });
                    if (IsFind && selectedRoomFeatures.length > 0) {
                        //$scope.SearchRooms.push({ Id: room.Id });
                        $scope.SearchRoomFeatures.push(room);
                        //$scope.AddSearchRoom(room.Id);
                    }
                });
            }
            else {
                $scope.SearchRoomFeatures = $scope.SearchMiniBars;
            }

            //Mini Bar
            $scope.SearchLinkRooms = [];
            if ($scope.SearchIsLinkRoom && $scope.SearchRoomFeatures.length > 0) {
                angular.forEach($scope.SearchRoomFeatures, function (room) {
                    angular.forEach($scope.LinkRooms, function (linkRoom) {
                        if (room.Id == linkRoom.Id) {
                            $scope.SearchLinkRooms.push(room);
                        }
                    });
                });
            }
            else {
                $scope.SearchLinkRooms = $scope.SearchRoomFeatures;
            }

            if ($scope.SearchLinkRooms.length > 0) {
                $scope.ResetIsFindFalse();
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    angular.forEach(roomType.Rooms, function (room) {
                        angular.forEach($scope.SearchLinkRooms, function (searchRoom) {
                            if (searchRoom.Id == room.Id) {
                                room.IsShow = true;
                                $scope.SearchCount = $scope.SearchCount +1;
                            }
                        });
                    });
                });
            }
            else
            {
                $scope.ResetIsFindFalse();
            }

            //$scope.SelectedRoomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == $scope.SelectedRoomType.Id  );

            //$timeout(function () {
            //    $scope.MonthColMarge();
            //    $scope.ColMarge1();
            //}, 1500);
        }

        $scope.SearchRoomOld = function () {
            
            $scope.SearchCount = 0;
            $scope.SearchRooms = [];
            $scope.BalanceRooms = [];
            $scope.ResetIsFindTrue();

            //RoomType
            $scope.SearchRoomTypes = [];
            
            if ($scope.SelectedSearchRoomType.RoomTypes.length > 0)
            {
                angular.forEach($scope.SelectedSearchRoomType.RoomTypes, function (roomType) {
                    angular.forEach($scope.Rooms, function (room) {
                        if (roomType.Id == room.RoomTypeId) {
                            $scope.SearchRoomTypes.push(room);
                        }
                    });
                });
            }
            else
            {
                if($scope.Rooms)
                    $scope.SearchRoomTypes = $scope.Rooms;
            }

            //Floor
            $scope.SearchFloors = [];
            if ($scope.SelectedSearchFloor.Floors.length > 0 && $scope.SearchRoomTypes.length > 0) {
                angular.forEach($scope.SelectedSearchFloor.Floors, function (id) {
                    angular.forEach($scope.SearchRoomTypes, function (room) {
                        if (id == room.FloorId) {
                            //$scope.SearchRooms.push({ Id: room.Id });
                            $scope.SearchFloors.push(room);
                            //$scope.AddSearchRoom(room.Id);
                        }
                    });
                });
            }
            else
            {
                if($scope.SearchRoomTypes)
                    $scope.SearchFloors = $scope.SearchRoomTypes;
            }
            
            //Block
            $scope.SearchBlocks = [];
            if ($scope.SelectedSearchBlock.Blocks.length > 0 && $scope.SearchFloors.length > 0) {
                angular.forEach($scope.SelectedSearchBlock.Blocks, function (id) {
                    angular.forEach($scope.SearchFloors, function (room) {
                        if (id == room.BlockId) {
                            //$scope.SearchRooms.push({ Id: room.Id });
                            $scope.SearchBlocks.push(room);
                            // $scope.AddSearchRoom(room.Id);
                        }
                    });
                });
            }
            else
            {
                if($scope.SearchFloors)
                    $scope.SearchBlocks = $scope.SearchFloors;
            }
            
            //Mini Bar
            $scope.SearchMiniBars = [];
            if ($scope.SearchIsMiniBar && $scope.SearchBlocks.length > 0) {
                angular.forEach($scope.SearchBlocks, function (room) {
                    if (room.IsMiniBar == true) {
                        //$scope.SearchRooms.push({ Id: room.Id });
                        $scope.SearchMiniBars.push(room);
                        //$scope.AddSearchRoom(room.Id);
                    }
                });
            }
            else {
                if($scope.SearchBlocks)
                    $scope.SearchMiniBars = $scope.SearchBlocks;
            }
            
            //RoomFeature
            $scope.SearchRoomFeatures = [];
            if ($scope.SelectedSearchRoomFeature.RoomFeatures.length > 0 && $scope.SearchMiniBars.length > 0) {
                angular.forEach($scope.SearchMiniBars, function (room) {
                    var selectedRoomFeatures = [];
                    angular.forEach($scope.SelectedSearchRoomFeature.RoomFeatures, function (id) {
                        selectedRoomFeatures.push({ Id: id, IsFind: false });
                    });
                    angular.forEach(room.RoomFeatures, function (roomFeature) {
                        angular.forEach(selectedRoomFeatures, function (selectedRoomFeature) {
                            if (selectedRoomFeature.Id == roomFeature.Id) {
                                selectedRoomFeature.IsFind = true;
                            }
                        });
                    });
                    var IsFind = true;
                    angular.forEach(selectedRoomFeatures, function (item) {
                        if (item.IsFind == false) {
                            IsFind = false;
                        }
                    });
                    if (IsFind && selectedRoomFeatures.length > 0) {
                        //$scope.SearchRooms.push({ Id: room.Id });
                        $scope.SearchRoomFeatures.push(room);
                        //$scope.AddSearchRoom(room.Id);
                    }
                });
            }
            else {
                if($scope.SearchMiniBars)
                {
                    if($scope.SearchMiniBars)
                        $scope.SearchRoomFeatures = $scope.SearchMiniBars;
                }
            }

            //Mini Bar
            $scope.SearchLinkRooms = [];
            if ($scope.SearchIsLinkRoom && $scope.SearchRoomFeatures.length > 0) {
                angular.forEach($scope.SearchRoomFeatures, function (room) {
                    angular.forEach($scope.LinkRooms, function (linkRoom) {
                        if (room.Id == linkRoom.Id) {
                            $scope.SearchLinkRooms.push(room);
                        }
                    });
                });
            }
            else {
                if($scope.SearchRoomFeatures)
                    $scope.SearchLinkRooms = $scope.SearchRoomFeatures;
            }

            if ($scope.SearchLinkRooms.length > 0) {
                $scope.ResetIsFindFalse();
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    if(roomType.Id==$scope.SelectedRoomType.Id)
                    {
                        angular.forEach(roomType.Rooms, function (room) {
                            angular.forEach($scope.SearchLinkRooms, function (searchRoom) {
                                if (searchRoom.Id == room.Id) {
                                    room.IsShow = true;
                                    $scope.SearchCount = $scope.SearchCount +1;
                                }
                            });
                        });
                    }
                });
            }
            else
            {
                $scope.ResetIsFindFalse();
            }
        }
        $scope.searchModel = function () {
            $scope.uncheckAll();
            $scope.SearchCount = 0;
            $scope.SearchRooms = [];
            $scope.BalanceRooms = [];
            $scope.ResetIsFindTrue();
            $scope.GetSetting();
            $scope.SelectedRoomLinkRooms=[];
            $("#searchModel").modal('show');
        }

        $scope.ResetIsFindTrue = function () {
            $scope.SearchCount = 0;
            if ($scope.RoomChart)
            {
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    if(roomType.Id==$scope.SelectedRoomType.Id)
                    {
                        angular.forEach(roomType.Rooms, function (room) {
                            room.IsShow = true;
                            $scope.SearchCount = $scope.SearchCount + 1;
                        });
                    }
                });
            }
        }
        $scope.ResetIsFindFalse = function () {
            $scope.SearchCount = 0;
            if ($scope.RoomChart) {
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    if(roomType.Id==$scope.SelectedRoomType.Id)
                    {
                        angular.forEach(roomType.Rooms, function (room) {
                            room.IsShow = false;
                        });
                    }
                });
            }
        }
    
        $scope.GetSetting =function(){
            $scope.getBlock();
            $scope.getRoomFeature();
            $scope.getFloor();
            //$scope.getRoomType();
            $scope.getRoomFeatureRoom();
        };
        
        $scope.getRoomCustom = function () {
            //$scope.Rooms = [];
            roomChartService.getRoomCustom($scope.PropertyID)
                   .then(function (result) {
                       
                       //$scope.Rooms = result.Collection;
                       //$scope.LinkRooms = $scope.Rooms.filter(x=>x.IsLinkRoom ==true);
                       $scope.LinkRooms = result.Collection.filter(x=>x.IsLinkRoom ==true);
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getRoomCustom();
        $scope.getRoomType = function () {
            $scope.RoomTypes = [];
            roomChartService.getRoomType($scope.PropertyID)
                   .then(function (result) {
                       $scope.RoomTypes = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getFloor = function () {
            $scope.Floors = [];
            roomChartService.getFloor($scope.PropertyID)
                   .then(function (result) {
                       $scope.Floors = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getRoomFeature = function () {
            $scope.RoomFeatures = [];
            roomChartService.getRoomFeature($scope.PropertyID)
                   .then(function (result) {
                       $scope.RoomFeatures = result.Collection;
                       
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getBlock = function () {
            $scope.Blocks = [];
            roomChartService.getBlock($scope.PropertyID)
                   .then(function (result) {
                       $scope.Blocks = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };

        //checklist-model------------------------------------------------------------------------------------

        //$scope.RoomTypes = [];
        $scope.SelectedSearchRoomType = {
            RoomTypes: []
        };
        $scope.checkAllRoomType = function () {
            $scope.SelectedSearchRoomType.RoomTypes = $scope.RoomTypes.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllRoomType = function () {
            $scope.SelectedSearchRoomType.RoomTypes = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstRoomType = function () {
            $scope.SelectedSearchRoomType.RoomTypes.splice(0, $scope.SelectedSearchRoomType.RoomTypes.length);
            $scope.SelectedSearchRoomType.RoomTypes.push(1);
        };

        $scope.SelectedSearchFloor = {
            Floors: []
        };
        $scope.checkAllFloor = function () {
            $scope.SelectedSearchFloor.Floors = $scope.Floors.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllFloor = function () {
            $scope.SelectedSearchFloor.Floors = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstFloor = function () {
            $scope.SelectedSearchFloor.Floors.splice(0, $scope.SelectedSearchFloor.Floors.length);
            $scope.SelectedSearchFloor.Floors.push(1);
        };

        $scope.SelectedSearchBlock = {
            Blocks: []
        };
        $scope.checkAllBlock = function () {
            $scope.SelectedSearchBlock.Blocks = $scope.Blocks.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllBlock = function () {
            $scope.SelectedSearchBlock.Blocks = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstBlock = function () {
            $scope.SelectedSearchBlock.Blocks.splice(0, $scope.SelectedSearchBlock.Blocks.length);
            $scope.SelectedSearchBlock.Blocks.push(1);
        };

        $scope.SelectedSearchRoomFeature = {
            RoomFeatures: []
        };
        $scope.checkAllRoomFeature = function () {
            
            $scope.SelectedSearchRoomFeature.RoomFeatures = $scope.RoomFeatures.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllRoomFeature = function () {
            $scope.SelectedSearchRoomFeature.RoomFeatures = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstRoomFeature = function () {
            $scope.SelectedSearchRoomFeature.RoomFeatures.splice(0, $scope.SelectedSearchRoomFeature.RoomFeatures.length);
            $scope.SelectedSearchRoomFeature.RoomFeatures.push(1);
        };

        $scope.uncheckAll = function () {
            $scope.uncheckAllRoomType();
            $scope.uncheckAllFloor();
            $scope.uncheckAllBlock();
            $scope.uncheckAllRoomFeature();
            $scope.SearchIsMiniBar  =false;
            $scope.SearchIsLinkRoom =false;
        };


        //end checklist-model------------------------------------------------------------------------------------
        $scope.CloseRoomChartBox =function(){
            $scope.SelectedRoomLinkRooms=[];
            $('#roomChartBox').modal('hide');
        }

        $scope.onMouseOverRoom = function (room, $event) {

            $scope.LinkRoomModel = {SelectedRoomLinkRooms:[]};
            $scope.SelectedRoomLinkRooms=[];
            
            var screenwidth = $('body').width();
            var screenheight = $('body').height();
            var mouseOverBoxHeight = 300;// $('#MouseOverBox').height();

            var left = $event.pageX - $event.offsetX;
            if (screenwidth < left + 350) {
                left = screenwidth - 350;
            }
            var top = $event.pageY - $event.offsetY - 60
            
            angular.forEach($scope.LinkRooms,function(linkRoom) {
                if(linkRoom.Id == room.Id)
                {
                    angular.forEach(linkRoom.LinkRooms,function(item) {
                        $scope.SelectedRoomLinkRooms.push({Id:item.LinkRoomMasterId,Name:item.LinkRoomNumber});
                    });
                }
            });
            if($scope.SelectedRoomLinkRooms.length>0)
            {
                $scope.LinkRoomModel = {
                    SelectedRoomLinkRooms:$scope.SelectedRoomLinkRooms,
                    Left: left,
                    Top: top,
                };
            }
        };

        $scope.onMouseDown = function (selectedRoom, roomDay, $event) {
            
            $scope.SelectedRoomLinkRooms=[];
        };

        $scope.onMouseOver = function (room, roomDay, $event) {
            
            $scope.SelectedRoomLinkRooms=[];
            
        };

        $scope.printPreRegCard = function () {
            if(!   $scope.SearchReservation ){
                return;
            }
            checkINService.MapReport($scope.PropertyID, 'preregcard')
                .then(function (s) {
                    $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' +    $scope.SearchReservation.Id , '_blank');
                }, function (e) {
                    $scope.IsSaved = true;
                    msg('Error in mapping to print.');
                }).finally(function () {
                    $scope.reset();
                });
        };
    
        //InterPropertyTransfers

        $scope.InterPropertyTransfers=[];
        $scope.GetCheckINGuestRoomInterPropertyTransfer = function () {
            $scope.InterPropertyTransfers=[];
            checkINService.GetCheckINGuestRoomInterPropertyTransfer($scope.PropertyID)
                .then(function (result) {
                    $scope.InterPropertyTransfers = result.Collection;
                    if($scope.InterPropertyTransfers.length>0)
                    {
                        $('#interPropertyTransferBox').modal('show');
                    }
                }, function (err) {
                    msg(err.Message);
                });
        };
        $scope.GetCheckINGuestRoomInterPropertyTransfer();
        
        $scope.IsInterPropertyTransfer = false;
        $scope.GetByCheckINGuestRoomId = function (id) {
            
            if(!id)
            {
                return;
            }
            checkINService.GetByCheckINGuestRoomId(id)
                .then(function (result) {
                    $scope.Model = result.Data;
                    $scope.Model.CheckINDate = $scope.MinDate;
                    $scope.Model.CheckOUTDate = GetServerDate( $scope.Model.CheckOUTDate,'YYYY-MM-DD');
                    if($scope.Model.CheckINDate == $scope.Model.CheckOUTDate)
                    {
                        $scope.Model.CheckOUTDate = GetMomentDate($scope.Model.CheckOUTDate,'YYYY-MM-DD').add(1,'days').format('YYYY-MM-DD');
                    }

                    $scope.Model.BillingInstructionId =   $scope.DefaultSetting.BillingInstructionId;
                    $scope.Model.BusinessSourceId     =   $scope.DefaultSetting.BusinessSourceId;
                    $scope.Model.BookingTypeId        =   $scope.DefaultSetting.BookingTypeId;
                    $scope.Model.CurrencyMasterId     =   $scope.DefaultSetting.CurrencyMasterId.toString();
                    $scope.Model.RevenueHeadId        =   $scope.DefaultSetting.RevenueHeadId;
                    $scope.Model.TotalPax = $scope.Model.CheckINGuests.length;

                    $scope.Model.ReservationId ="";
                    $scope.walkinNights();

                    var interPropertyTransfer =$scope.InterPropertyTransfers.filter(x=>x.CheckINGuestRoomId == id)[0];
                    $scope.Model.CheckINGuestRoomInterPropertyTransferId = interPropertyTransfer.Id;
                    $scope.CheckINGuestRooms = $scope.Model.CheckINGuestRooms;
                    angular.forEach($scope.CheckINGuestRooms ,function(checkINGuestRoom){
                        
                        checkINGuestRoom.RoomTypeId = $scope.DefaultSetting.RoomTypeId;
                        var roomTypes = $scope.RoomTypes.filter(x=>x.Id == checkINGuestRoom.RoomTypeId);
                        checkINGuestRoom.RoomTypeName = roomTypes[0].Name;

                        checkINGuestRoom.RateMasterId =$scope.DefaultSetting.RateMasterId;
                        var rateMasters = $scope.RateMasters.filter(x=>x.Id == checkINGuestRoom.RateMasterId);
                        checkINGuestRoom.RateMasterCode=rateMasters[0].Code;
                        checkINGuestRoom.RateTaxStructureId=rateMasters[0].RateTaxStructureId;
                        checkINGuestRoom.MealPlanTaxStructureId=rateMasters[0].MealPlanTAXStructureId;

                        var checkinguest = $scope.Model.CheckINGuests.filter(x=>x.IsRoomOwner = true);

                        checkINGuestRoom.RoomNumber="";
                        checkINGuestRoom.SNo=checkinguest[0].SNo;
                        checkINGuestRoom.FolioNo=checkinguest[0].FolioNo;
                        checkINGuestRoom.CheckINGuestName=checkinguest[0].FirstName + ' ' + checkinguest[0].LastName ;
                        checkINGuestRoom.NumberOfPax=$scope.Model.CheckINGuests.length;
                        
                    }); 

                    angular.forEach($scope.Model.CheckINGuests,function(checkINGuest){
                        checkINGuest.Id ="";
                        checkINGuest.IsCheckedIN = false;
                        checkINGuest.RoomChangeNotAllowed =false;

                        checkINGuest.FolioNo = checkINGuest.FolioNo.toString(); 
                        checkINGuest.SalutationId = checkINGuest.SalutationId.toString();
                        checkINGuest.PaxTypeId = checkINGuest.PaxTypeId.toString();

                        var roomTypes = $scope.RoomTypes.filter(x=>x.Id == $scope.DefaultSetting.RoomTypeId);
                        checkINGuest.RoomTypeId = roomTypes[0].Id;
                        checkINGuest.RoomTypeName = roomTypes[0].Name;

                        checkINGuest.MealPlanId = $scope.Model.CheckINGuestRooms[0].MealPlanId.toString();
                        checkINGuest.IsCheckedIN = false;
                        checkINGuest.PaxTypeId = checkINGuest.PaxTypeId.toString();

                        
                        checkINGuest.InterPropertyTransfer = {};
                        checkINGuest.InterPropertyTransfer.DayRateAmount = interPropertyTransfer.CheckINGuestRoom.CheckINGuestRoomRates[0].DayRateAmount;
                        checkINGuest.InterPropertyTransfer.MealPlanDayRate = interPropertyTransfer.CheckINGuestRoom.CheckINGuestRoomRates[0].MealPlanDayRate;
                        checkINGuest.InterPropertyTransfer.IsInclusive = interPropertyTransfer.CheckINGuestRoom.IsInclusive;

                        $scope.ChangeRoomType(checkINGuest);

                        $scope.IsInterPropertyTransfer = true;
                    });

                    $scope.SetTimeForDisplay();

                    $('#interPropertyTransferBox').modal('hide');
                }, function (err) {
                    msg(err.Message);
                });
        };


        $scope.SetTimeForDisplay = function(){
            checkINService.getServerTime() 
                    .then(function (result) {
                        var cit1 = result.Message.split(':');
                        var tt = new Date();
                        $scope.Model.CheckINTimeForDisplayD = new Date(tt.getFullYear(), tt.getMonth(), tt.getDate(), cit1[0], cit1[1], 0);
                        if ($scope.DefaultSetting) {
                            $scope.Model.CheckOUTTimeForDisplayD = $scope.DefaultSetting.CheckOUTTypeId === "1" || $scope.DefaultSetting.CheckOUTTypeId === 1 ?
                                new Date(1970, 0, 1, 12, 0, 0) : new Date(1970, 0, 1, cit1[0], cit1[1], 0);
                        }
                    });

        }

        //


        //-----------------------------------------------------------------------------------------------------
        //CheckINMenu USE IN 1) CHECK-IN And 2) ROOM CHART CHECK-IN
        //-----------------------------------------------------------------------------------------------------
        $('#guestinfoshow').click(function () {
            $('#guestinfo').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#passportinfo, #pickupdropinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox,#historydetailsbox,  #groupinfo, #likedislike, #vehiclenumber, #extrachargesnew,#arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#passportvisashow').click(function () {
            $('#passportinfo').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");

            $('#guestinfo, #pickupdropinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox, #groupinfo,#historydetailsbox, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#pickdropinfoshow').click(function () {
            $('#pickupdropinfo').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #advance, #discount, #extracharges,#localcontactbox,#visitdetailsbox, #groupinfo,#historydetailsbox, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#advanceshow').click(function () {
            $('#advance').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo, #discount,#localcontactbox, #extracharges,#visitdetailsbox,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#discountshow').click(function () {
            $('#discount').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox, #extracharges,#visitdetailsbox,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#extrachargesshow').click(function () {
            $('#extracharges').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox,#visitdetailsbox, #discount,#historydetailsbox, #groupinfo, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#groupinformationshow').click(function () {
            $('#groupinfo').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo, #advance,#localcontactbox,#visitdetailsbox,#historydetailsbox, #discount, #extracharges, #likedislike, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#likedislikeshow').click(function () {
            $('#likedislike').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox, #advance,#visitdetailsbox,#historydetailsbox, #discount, #extracharges, #groupinfo, #vehiclenumber,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#vehicleinformationshow').click(function () {
            $('#vehiclenumber').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew, #arrangements,#documentcenter,#diplomat,#workdetail').css('display', 'none');
        });

        $('#arrangementsamenitiesshow').click(function () {
            $('#arrangements').slideToggle();
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#localcontactbox,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike, #extrachargesnew,#vehiclenumber,#documentcenter,#diplomat,#workdetail').css('display', 'none');

        });

        $('#documentcentershow').click(function () {
            $('#documentcenter').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo,#localcontactbox,#visitdetailsbox, #pickupdropinfo,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew,#arrangements,#diplomat').css('display', 'none');
        });

        $('#workdetailshow').click(function () {
            $('#workdetail').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo,#localcontactbox,#visitdetailsbox, #pickupdropinfo,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike,#extrachargesnew,#arrangements,#diplomat').css('display', 'none');
        });

        $('#localcontactshow').click(function () {
            $('#localcontactbox').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox,#historydetailsbox, #advance, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

        });
        $('#visitdetails').click(function () {
            $('#visitdetailsbox').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#historydetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

        });
        $('#historyshow').click(function () {
            $('#historydetailsbox').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#diplomat,#workdetail').css('display', 'none');

        });
        $('#extraamount').click(function () {
            $('#extrachargesnew').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#documentcenter,#historydetailsbox,#diplomat,#workdetail').css('display', 'none');

        });
        $('#diplomatshow').click(function () {
            $('#diplomat').slideToggle('slow');
            $("li a").removeClass("visited")
            $(this).addClass("visited");
            $('#guestinfo, #passportinfo, #pickupdropinfo,#visitdetailsbox, #advance,#localcontactbox, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#extrachargesnew,#documentcenter,#historydetailsbox,#workdetail').css('display', 'none');

        });

        $('.navigation ul li a').click(function () {
            $('.navigation ul li a').removeClass('selectedli')
            $(this).addClass('selectedli');
        });
        
        //EndMenu
        //-----------------------------------------------------------------------------------------------------

    
    }
]);

var getData1 = function ($scope, service, localStorageService) {

    $scope.IsProgress = true;

    $scope.SearchReservationList = [];

    var sortKeyOrder = localStorageService.get("sortKeyOrder");
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: "ReservationNo",
            order: "ASC"
        };
    }

    var searchfor = localStorageService.get("searchfor");

    if (!$scope.SearchModel) {
        $scope.SearchModel = {};
    }
    else {
        if ($scope.SearchModel.ArrivalDateString) {
            $scope.SearchModel.ArrivalDate = $scope.SearchModel.ArrivalDateString;
        }
        if ($scope.SearchModel.DepartureDateString) {
            $scope.SearchModel.DepartureDate = $scope.SearchModel.DepartureDateString;
        }

    }


    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        CurrentPage: $scope.currentPage,
        RecordsPerPage: $scope.recordsPerPage,

        SortKey: "ReservationNo",
        SortKeyOrder: "ASC",

        Searchfor: searchfor,
        PropertyID: $scope.PropertyID,
        Model: $scope.SearchModel
    };

    service.getReservationSearch(options)
        .then(function (result) {
            angular.copy(result.Collection, $scope.SearchReservationList);
            $scope.totalItems = result.RecordCount;
            $scope.IsProgress = false;
        },
        function () {
            $scope.IsProgress = false;
            msg("The request failed. Unable to connect to the remote server.");
        });

};

