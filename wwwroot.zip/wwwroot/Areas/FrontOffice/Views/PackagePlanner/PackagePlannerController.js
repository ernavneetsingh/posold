﻿
$(function () {
    $('#rackrate').click(function () {
        $('#rackratesub').slideToggle('20000').css('max-height', '380px');
        $('#corporatesub, #bookingsub, #channelmansub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
    $('#corporate').click(function () {
        $('#corporatesub').slideToggle('20000').css('max-height', '380px');
        $('#rackratesub, #bookingsub, #channelmansub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
    $('#booking').click(function () {
        $('#bookingsub').slideToggle('20000').css('max-height', '380px');
        $('#corporatesub, #rackratesub, #channelmansub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
    $('#channelman').click(function () {
        $('#channelmansub').slideToggle('20000').css('max-height', '380px');
        $('#corporatesub, #bookingsub, #rackratesub').css('display', 'none');
        $('li a').removeClass('activenav');
        $(this).addClass('activenav');
    });
});

app.controller("controller",
[
    "$scope", "packagePlannerService", "localStorageService", "$cookies", "$filter",
    function ($scope, packagePlannerService, localStorageService, $cookies, $filter) {

        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.keys=localStorageService.get('ActionKeys');
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        
        $scope.YearList=[];
        $scope.YearList.push({Id:'2018',Name:'2018'});
        $scope.YearList.push({Id:'2019',Name:'2019'});
        $scope.YearList.push({Id:'2020',Name:'2020'});
        $scope.YearList.push({Id:'2021',Name:'2021'});
        $scope.YearList.push({Id:'2022',Name:'2022'});
        $scope.selectedYearId = $scope.BusinessDate.Year.toString();

        $scope.IsProgress=false;
        $scope.RoomRateParent = {
            BookingEngineRates: [],
            ChannelManagerRates: [],
            RackRates: [],
            TravelAgentRates: [],
        };
        $scope.ShowErrorMessage = false;
        $scope.RoomRateId = "";
        $scope.RateTypes = [];
        GetRateType();
        function GetRateType() {
            var promiseGet = packagePlannerService.GetRateType();
            promiseGet.then(function (data) {
                $scope.RateTypes = data;
            }, function (data) {
                msg(data.message);
            });
        }

        getAllPackage();
        function getAllPackage() {
            var promiseGet = packagePlannerService.getAllPackage($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Packages=data.Collection;
            }, function (error) {

                msg(error.Message);
                //$("html, body").animate({ scrollTop: 0 }, "slow");
            });
        }

        $scope.Save = function (packageId) {
            if (!$scope.keys.IsAdd || !$scope.keys.IsEdit)
            {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var  model = {
                FromDate :$scope.YearDays[fromIndex].Date,
                ToDate :$scope.YearDays[toIndex].Date,
                PackageId :packageId,
                RateTypeId: $scope.SelectedRoomRateTypeChange.Id,
                PropertyID:$scope.PropertyID,
                ModifiedBy:$scope.UserName,
                SkeepWeeks : $scope.SelectedWeekDay.CalendarWeekDays
            };
            $scope.IsProgress=true;
            var promiseGet = packagePlannerService.save(model);
            promiseGet.then(function (data) {
                msg(data.Message, true);
                GetYearCalendar($scope.SelectedYear);
                fromIndex=-1;
                toIndex=-1;
                $scope.SelectedWeekDay=[];
                $scope.IsProgress=false;
            }, function (error) {
                $scope.IsProgress=false;
                msg(error.Message);
                
            });

            $("#rateModel").modal('hide');
            
        };
        $scope.remove = function (packageId) {          
            var  model = {
                FromDate :$scope.YearDays[fromIndex].Date,
                ToDate :$scope.YearDays[toIndex].Date,
                PackageId :packageId,
                RateTypeId: $scope.SelectedRoomRateTypeChange.Id,
                PropertyID:$scope.PropertyID,
                ModifiedBy:$scope.UserName,
                SkeepWeeks : $scope.SelectedWeekDay.CalendarWeekDays
            };
            $scope.IsProgress=true;
            var promiseGet = packagePlannerService.remove(model);
            promiseGet.then(function (data) {
                msg(data.Message, true);
                GetYearCalendar($scope.SelectedYear);
                fromIndex=-1;
                toIndex=-1;
                $scope.IsProgress=false;
            }, function (error) {
                $scope.IsProgress=false;
                msg(error.Message);
                
            });

            $("#rateModel").modal('hide');
            
        };
        $scope.Remove = function (packageId) {
            if (!$scope.keys.IsDelete)
            {
                parent.failureMessage("Unauthorized Access !!!");
                scrollPageOnTop();
                return false;
            }
            var strDelete = DeletePopup("Are you sure you want to delete this?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {

                            ret = true;
                            
                            $scope.remove(packageId);

                            $.fancybox.close();
                        });
                }
            });
        }

        $scope.SelectedRoomRateTypeChange ={Id:'1',Name:'Rack Rate'};
        $scope.Packages=[];

        $scope.RoomRateTypeChange = function (item) {

            $scope.SelectedRoomRateTypeChange =item;
            
            GetYearCalendar($scope.SelectedYear);
        };
        
        $scope.model.RateTypeId="1";
        
        $scope.MaxDate = $filter("date")(date, $scope.DateFormat);
        $scope.RoomRate = {
            Id: "",
            RateType: 1,
            RateTypeId: "",
            RateTypeDescription: "",
            RateMasterCode: "",
            Description: "",
            IsActive: true,
            ApplicableFrom: "",
            ApplicableTo: "",
            AdultExtraCharge: 0.00,
            ChildExtraCharge: 0.00,
            AdultExtraChargeMeal: 0.00,
            ChildExtraChargeMeal: 0.00,
            MinimumStay: 0,
            IsMinuteDefault: false,
            IsTariffPlanInclusive: false,//navneet
            IsTariffTAXInclusive: false,//
            IsInclusive: false,//
            RateTaxStructureId: "",
            MealPlanTAXStructureId: "",
            ExtraBedTaxId: "",
            ExtraBedPlanTaxId: "",
            CorporatePartner: "",    //navneet: discussion required
            ChannelPartner: "",
            IsCorporatePartner: false,
            IsChannelPartner: false,
            IsWeekDays: false,

            CorporateRateMasters: [],
            MealPlanRates: [],
            OccupancyTypeRates: [],
            ReservationRoomTypes: [],
            RoomTypeRates: [],
            DefaultSettings: [],

            MinimumStayRates: [],
            RoomTypes: [],
            WeekDaysRates: [],
            DefaultRateViewModels: [],
            TaxStructures: [],

            PropertyID: $scope.PropertyID,
            ModifiedBy: $scope.UserName
        };
        

        

        //Calendar 
        
        $scope.SelectedYear  =$scope.BusinessDate.Year;
        $scope.SelectedPackagesId ='abc';

        $scope.Months = [];
        $scope.Months.push({ Id: 1, Name: 'January' });
        $scope.Months.push({ Id: 2, Name: 'February' });
        $scope.Months.push({ Id: 3, Name: 'March' });
        $scope.Months.push({ Id: 4, Name: 'April' });
        $scope.Months.push({ Id: 5, Name: 'May' });
        $scope.Months.push({ Id: 6, Name: 'June' });
        $scope.Months.push({ Id: 7, Name: 'July' });
        $scope.Months.push({ Id: 8, Name: 'August' });
        $scope.Months.push({ Id: 9, Name: 'September' });
        $scope.Months.push({ Id: 10, Name: 'October' });
        $scope.Months.push({ Id: 11, Name: 'November' });
        $scope.Months.push({ Id: 12, Name: 'December' });
        $scope.DayNames = [];
        $scope.DayNames.push({ Id: 1, Name: 'Monday' });
        $scope.DayNames.push({ Id: 2, Name: 'Tuesday' });
        $scope.DayNames.push({ Id: 3, Name: 'Wednesday' });
        $scope.DayNames.push({ Id: 4, Name: 'Thursday' });
        $scope.DayNames.push({ Id: 5, Name: 'Friday' });
        $scope.DayNames.push({ Id: 6, Name: 'Saturday' });
        $scope.DayNames.push({ Id: 7, Name: 'Sunday' });
    
        $scope.YearDays = [];
        
        GetYearCalendar($scope.BusinessDate.Year);
        function GetYearCalendar() {
            
            if(!$scope.SelectedPackagesId)
            {
                msg('Please Select Package.');
                return;
            }

            $scope.YearCalendar=[];
            $scope.YearDays=[];
            var startdate = $scope.SelectedYear + '-01-01'
            var numberOfYears = 1;

            

           var promiseGet = packagePlannerService.getYearCalendar(startdate,numberOfYears,$scope.PropertyID,$scope.SelectedRoomRateTypeChange.Id,$scope.SelectedPackagesId);
            promiseGet.then(function (data) {
                $scope.YearCalendar = data.Data;
                
                $scope.WeekDayTemps = [];
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[0].DayOfWeek, Name:$scope.YearCalendar[0].DayName, IsWeekEnd:$scope.YearCalendar[0].IsWeekEnd})
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[1].DayOfWeek, Name:$scope.YearCalendar[1].DayName, IsWeekEnd:$scope.YearCalendar[1].IsWeekEnd})
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[2].DayOfWeek, Name:$scope.YearCalendar[2].DayName, IsWeekEnd:$scope.YearCalendar[2].IsWeekEnd})
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[3].DayOfWeek, Name:$scope.YearCalendar[3].DayName, IsWeekEnd:$scope.YearCalendar[3].IsWeekEnd})
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[4].DayOfWeek, Name:$scope.YearCalendar[4].DayName, IsWeekEnd:$scope.YearCalendar[4].IsWeekEnd})
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[5].DayOfWeek, Name:$scope.YearCalendar[5].DayName, IsWeekEnd:$scope.YearCalendar[5].IsWeekEnd})
                $scope.WeekDayTemps.push({DayOfWeekId: $scope.YearCalendar[6].DayOfWeek, Name:$scope.YearCalendar[6].DayName, IsWeekEnd:$scope.YearCalendar[6].IsWeekEnd})

                $scope.WeekDayTemps = $filter('orderBy')($scope.WeekDayTemps, 'DayOfWeekId');
                
                $scope.WeekDay1s = [];
                $scope.WeekDay1s.push($scope.WeekDayTemps[1]);
                $scope.WeekDay1s.push($scope.WeekDayTemps[2]);
                $scope.WeekDay1s.push($scope.WeekDayTemps[3]);
                $scope.WeekDay1s.push($scope.WeekDayTemps[4]);
                $scope.WeekDay1s.push($scope.WeekDayTemps[5]);
                $scope.WeekDay1s.push($scope.WeekDayTemps[6]);
                $scope.WeekDay1s.push($scope.WeekDayTemps[0]);

                $scope.WeekDays = [];
                var i=0;
                var x=0;
                for(i=0; i<5;i++)
                {
                    angular.forEach($scope.WeekDay1s,function(item){
                        $scope.WeekDays.push({
                            Id:x ,
                            DayOfWeekId: item.DayOfWeekId, 
                            Name:item.Name, 
                            IsWeekEnd:item.IsWeekEnd,
                        });    
                        x++;
                    });
                    
                }

                $scope.WeekDays.push({
                    Id:35 ,
                    DayOfWeekId: $scope.WeekDay1s[0].DayOfWeekId, 
                    Name:$scope.WeekDay1s[0].Name, 
                    IsWeekEnd:$scope.WeekDay1s[0].IsWeekEnd,
                });    
                $scope.WeekDays.push({
                    Id:36 ,
                    DayOfWeekId: $scope.WeekDay1s[1].DayOfWeekId, 
                    Name:$scope.WeekDay1s[1].Name, 
                    IsWeekEnd:$scope.WeekDay1s[1].IsWeekEnd,
                });    

                var index =0;
                angular.forEach( $scope.Months ,function(month){    
                    var monthDays = $scope.YearCalendar.filter(x=>x.Month === month.Id);
                    var startDayofWeek = monthDays[0].DayOfWeek;
                    
                    if(startDayofWeek==1)
                    {
                        startDayofWeek =8;// $scope.YearDays.push({Id:i,Month:month.Id});
                    }

                    var i;
                    for (i = 2; i < 40; i++) { 
                        
                        var weekEndColor ="";
                       
                        if(startDayofWeek>i)
                        {
                            if($scope.WeekDays[i-2].IsWeekEnd =='1')
                            {
                                weekEndColor ="darkgrey";
                            }
                            
                            $scope.YearDays.push({Index:index,Id:i,Month:month.Id,IsWeekEnd:$scope.WeekDays[i-2].IsWeekEnd,Color:weekEndColor});
                            index++;
                        }
                        else if((startDayofWeek+monthDays.length)<i)
                        {
                            if($scope.WeekDays[i-3].IsWeekEnd=='1')
                            {
                                weekEndColor ="darkgrey";
                            }
                            $scope.YearDays.push({Index:index,Id:i,Month:month.Id,IsWeekEnd:$scope.WeekDays[i-3].IsWeekEnd,Color:weekEndColor});
                            index++;
                        }
                        else
                        {
                            angular.forEach( monthDays ,function(monthDay){
                                monthDay.Id = i;
                                $scope.YearDays.push({Index:index,Id:i,Date:monthDay.Date,Month:monthDay.Month,Day:monthDay.Day, DayOfYear:monthDay.DayOfYear, DayName:monthDay.DayName, DayOfWeek:monthDay.DayOfWeek,IsWeekEnd:monthDay.IsWeekEnd,HolidayName:monthDay.HolidayName,Color:monthDay.Color});;
                                i++;
                                index++;        
                            })
                        }
                        
                    }

                });
                
                
            },
            function (error) {
                
                msg(error.Message);
                //$("html, body").animate({ scrollTop: 0 }, "slow");
            });
        }

        

       $scope.ChangeYear =function(year)
       {
           $scope.SelectedYear=year;
           GetYearCalendar();
       }
       $scope.ChangePackage =function(selectedPackagesId)
       {
           $scope.SelectedPackagesId=selectedPackagesId;
           GetYearCalendar();
       }


       var fromIndex=-1;
       var toIndex=-1;

       $scope.SetDay =function(day)
       {
           if(day.Date)
           {
               if(fromIndex<0)
               {
                   fromIndex=day.Index;
               }
               else if(toIndex<0 && fromIndex>=0)
               {
                   if(day.Index<fromIndex)
                   {
                       $scope.YearDays[fromIndex].IsSelected=false;
                       if(toIndex>=0)
                       {
                           $scope.YearDays[toIndex].IsSelected=false;
                       }
                       
               
                       fromIndex=-1;
                       toIndex=-1;
                       fromIndex=day.Index;
                       day.IsSelected=true;
                       return;
                   }
                   toIndex=day.Index;

                   //Show popup
                   if($scope.SelectedPackagesId)
                   {
                       $("#rateModel").modal('show');
                   }
                   else
                   {
                       parent.failureMessage('Select Package.');
                   }
               }
               else if(toIndex>0 && fromIndex>=0)
               {
                   $scope.YearDays[fromIndex].IsSelected=false;
                   $scope.YearDays[toIndex].IsSelected=false;
               
                   fromIndex=-1;
                   toIndex=-1;
                   fromIndex=day.Index;
               }
               

               day.IsSelected=true;
           }
           
       }

       $scope.CalendarWeekDays = [];
       $scope.SelectedWeekDay = {
           CalendarWeekDays: []
       };

       GetWeekDay();
       function GetWeekDay() {

           $scope.SelectedWeekDay.CalendarWeekDays = [];
           $scope.CalendarWeekDays=[];
           var promiseGet = packagePlannerService.getWeekDay();
           promiseGet.then(function (d) {
               $scope.CalendarWeekDays =d;
           },
             function (e) {
                 parent.failureMessage(e.Message);
             });
       }

        //checklist-model------------------------------------------------------------------------------------

      
       $scope.checkAllWeekDay = function () {
           $scope.SelectedWeekDay.CalendarWeekDays = $scope.CalendarWeekDays.map(function (item) { return item.Id; });
       };
       $scope.uncheckAllWeekDay = function () {
           $scope.SelectedWeekDay.CalendarWeekDays = [];
       };
       $scope.checkFirstWeekDay = function () {
           $scope.SelectedWeekDay.CalendarWeekDays.splice(0, $scope.SelectedWeekDay.CalendarWeekDays.length);
           $scope.SelectedWeekDay.CalendarWeekDays.push(1);
       };

        //-----------------------------------------------------------------------------------------------------
    }

]);
