﻿
app.service('HelpService', function ($http, $q) {

    this.getPageHelp = function (id) {
        return httpCaller(apiPath + "configuration/ModulePageHelp/GetAllByUserProductPageId/" + id, $http, $q);
    };

});
