﻿(function () {
    function settlementService($http, $q) {
         
        var accessToken = 'ad65n562dc5t48i4edc4:9k93s278e370c59a08t';

        var getAllSettlementMode = function (propertyId, outletId, revenueFor) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/SettlementMode/allByOutletId/" + propertyId + "/" + outletId + "/" + revenueFor)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        
        var getCorporate = function (propertyId) {

            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/Corporate/GetAllByPropertyIdMin/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var getOccupiedRooms = function (propertyId, date) {
            
            //var url = apiPath + "FrontOffice/RoomStatus/GetAllByRoomStatusType/?" + "propertyId=" + propertyId + "&businessDate=" + date + "&roomStatusTypeId=7";
            var url = apiPath + "FrontOffice/RoomStatus/GetAllByOccupiedRoom/?" + "propertyId=" + propertyId + "&businessDate=" + date;

            var deferred = $q.defer();
            $http.get(url)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;

        };

        var getCurrency = function () {

            var deferred = $q.defer();
            $http.get(apiPath + "referencedata/currency")
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        var saveSettlement = function (model) {

            var url = apiPath + 'GlobalSetting/Settlement/Save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {

                deferred.resolve(data);

            }).error(function (data, status, headers, config) {


                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
      
        //GetBill
        

        return {
            SendOTP:SendOTP,
            getAllSettlementMode: getAllSettlementMode,
            getCorporate: getCorporate,
            getOccupiedRooms: getOccupiedRooms,
            saveSettlement: saveSettlement,
            getCurrency: getCurrency
        };
    }
    app.factory("settlementService", ["$http", "$q", settlementService]);
})();
