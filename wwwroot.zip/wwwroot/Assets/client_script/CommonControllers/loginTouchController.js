﻿
apppos.controller("loginTouchController", [
    "$scope", "loginTouchService", "$cookies", "localStorageService", "$filter", "$timeout", function ($scope, loginTouchService, $cookies, localStorageService, $filter, $timeout) {
        
        //$scope.DateFormat = "dd/MMM/yyyy";

        localStorageService.set('DateFormat', 'dd-MMM-yyyy')

        $scope.LoginId = $cookies.get('LoginId');
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        
        $scope.PropertyName = "Welcome";

        $scope.Model =
            {
                UserName: $scope.UserName,
                IsDisable: true,
                Outlets: [],
                RoleId: ''
            };
        $scope.SelectedOutlets = [];
        $scope.format = "dd-MMM-yyyy h:mm:ss a";
        $scope.loginRequest = false;
        $scope.LoginPropertys = [];
        $scope.IsReadonly = false;

        $("#btnEnter").hide();

        $scope.Model.IsDisable = true;

        //$scope.GoToPOSScreen = function (model) {
        //    window.location.href = "Operation/POSShift";
        //    return;
        //};

        $scope.GoToProperty = function (id) {
           
            
            angular.forEach($scope.LoginPropertys, function (item) {
                if (id == item.Id) {

                    localStorageService.set('LoginId', $cookies.get('LoginId'));
                    localStorageService.set('UserName', $cookies.get('UserName'));
                    localStorageService.set('FirstName', $cookies.get('FirstName'));
                    localStorageService.set('LastName', $cookies.get('LastName'));
                    localStorageService.set('UserProfile', $cookies.get('UserProfile'));
                    localStorageService.set('accessToken', $cookies.get('accessToken'));

                    localStorageService.set('PropertyId', item.Id);
                    localStorageService.set('PropertyName', item.Name);
                    localStorageService.set('PropertyCity', item.City);
                    localStorageService.set('PropertyStateId', item.StateId);
                    localStorageService.set('PropertyCountryId', item.CountryId);
                    localStorageService.set('DateFormat', item.DateFormat);
                    //localStorageService.set('BusinessDate', item.BusinessDate);
                    var mDate = GetMomentDate(item.BusinessDate, 'YYYY-MM-DD')
                    var businessDate = {
                        Year: mDate.format('YYYY'),
                        Month: mDate.format('MM'),
                        Day: mDate.format('DD'),
                    };
                    localStorageService.set('BusinessDate', businessDate);
                }

            });

            $scope.PropertyID = localStorageService.get('PropertyId');
            if ($scope.PropertyID.length > 0) {
                window.location.href = Path + "/POS/POSShift";
            }

        };

        $scope.EnterPasswordForLoginTouch = function (model) {
            
            if (model.UserName == "" || model.UserName == undefined) {
                $("#UserName").css("border", "1px solid red");
                return;
            }
            if (model.Password == "" || model.Password == undefined) {
                $("#Password-Info").css("border", "1px solid red");
                return;
            }

            else {

                $scope.Model.Outlets = [];

                model.PropertyID = $scope.PropertyID;
                $scope.LoginProcessing = true;
                var promiseGet = loginTouchService.loginRequest(model);

                promiseGet.then(function (data) {
                    if (data.Status) {

                        //store cookies
                        $cookies.put('LoginId', data.Data.LoginId);
                        $cookies.put('UserName', data.Data.UserName);
                        $cookies.put('FirstName', data.Data.FirstName);
                        $cookies.put('LastName', data.Data.LastName);
                        $cookies.put('UserProfile', data.Data.UserProfile);
                        $cookies.put('BusinessDate', data.Data.BusinessDate);
                        $cookies.put('accessToken', data.Data.access_Token);

                        var jsonObj = JSON.stringify(data.Data.Propertys);
                        $cookies.putObject('LoginPropertys', jsonObj);

                        if (data.Data.Propertys.length > 1) {
                            $scope.LoginPropertys = data.Data.Propertys;
                        }
                        else {
                            
                            localStorageService.set('LoginId', data.Data.LoginId);
                            localStorageService.set('UserName', data.Data.UserName);
                            localStorageService.set('FirstName', data.Data.FirstName);
                            localStorageService.set('LastName', data.Data.LastName);
                            localStorageService.set('UserProfile', data.Data.UserProfile);
                            localStorageService.set('accessToken', data.Data.access_Token);

                            localStorageService.set('PropertyId', data.Data.Propertys[0].Id);
                            localStorageService.set('PropertyName', data.Data.Propertys[0].Name);
                            localStorageService.set('PropertyCity', data.Data.Propertys[0].City);
                            localStorageService.set('PropertyStateId', data.Data.Propertys[0].StateId.toString());
                            localStorageService.set('PropertyCountryId', data.Data.Propertys[0].CountryId.toString());
                            localStorageService.set('DateFormat', data.Data.Propertys[0].DateFormat);
                            localStorageService.set('BusinessDate', data.Data.Propertys[0].BusinessDate);

                            window.location.href = Path + "/POS/POSShift";
                        }

                        $scope.LoginProcessing = false;
                    }
                    else
                    {
                        $scope.LoginProcessing = false;
                        parent.posFailureMessage(data.Message);
                        $scope.Message = data.Message;
                    }
                    
                },
                    function (error) {
                        $scope.LoginProcessing = false;
                        $scope.Message = error.Message;
                        parent.posFailureMessage(error.Message);

                        scrollPageOnTop();
                    });
            }
        };
        
    }
]);