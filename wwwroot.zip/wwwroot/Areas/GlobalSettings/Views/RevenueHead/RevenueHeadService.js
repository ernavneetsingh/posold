﻿
(function () {
    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var linkModule = [];


        function revenueHeadSync(model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/RevenueHead/Sync",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var getRevenueHead = function (options) {
            var url = apiPath + "GlobalSetting/revenuehead/details?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var getGeneralRevenueHead = function (options) {
            var url = apiPath + "GlobalSetting/generalrevenuehead/details?currentPage=" + options.currentPage + "&" +
                "recordsPerPage=" + options.recordsPerPage + "&" +
                "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor + "&propertyId=" + options.propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, linkModule);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        function getRevenueHeadData(revenueHeadId, propertyId) {

            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/revenuehead/details/" + revenueHeadId + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getCodeExistRevenueHead(revenueHeadCode, propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/revenuehead/exist/" + revenueHeadCode + "/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        //function getAllTaxStructure(moduleId, propertyId) {
        //    var deferred = $q.defer();
        //    $http({
        //        method: "GET",
        //        url: apiPath + "GlobalSetting/TaxStructure/" + moduleId + "/" + propertyId,
        //        data: {},
        //        headers: { 'duxtechApiKey': accessToken },
        //        contentType: "application/json; charset=utf-8"
        //    }).success(function (data, status, headers, cfg) {
        //        deferred.resolve(data);
        //    }).error(function (err, status) {
        //        deferred.reject(status);
        //    });
        //    return deferred.promise;
        //};

        function getAllTaxStructure(propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/TaxStructure/" + propertyId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };



        function getAuditCode(propertyId, revenueForId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/revenuehead/auditcode/" + propertyId + "/" + revenueForId,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function save(model) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/RevenueHead/Save",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function GeneralSave(model) {
            
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/GeneralRevenueHead/Save",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                
                deferred.reject(err);
            });
            return deferred.promise;
        };

        function changeStatus(model) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "GlobalSetting/RevenueHead/ChangeStatus/",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getRevenueClassificationType() {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "ReferenceConstant/RevenueClassificationType/all",
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        function getRevenueType() {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "ReferenceConstant/RevenueType/all",
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(status);
            });
            return deferred.promise;
        };

        var service = {

            revenueHeadSync: revenueHeadSync,
            dataAllData: linkModule,
            getAuditCode: getAuditCode,

            getRevenueHead: getRevenueHead,
            getGeneralRevenueHead:getGeneralRevenueHead,
            getCodeExistRevenueHead: getCodeExistRevenueHead,
            save: save,
            getRevenueHeadData: getRevenueHeadData,
            changeStatus: changeStatus,
            getRevenueClassificationType: getRevenueClassificationType,
            getRevenueType: getRevenueType,
            getAllTaxStructure: getAllTaxStructure,
            GeneralSave: GeneralSave,
        };
        return service;
    }

    app.factory("service", ["$http", "$q", service]);
})();
