﻿
app.service('NightAuditOutletDetailService', [
    "$http", "$q", function (
        $http, $q) {

        this.getAll = function (propertyId, date1) {
            return httpCaller(apiPath + "FrontOffice/NightAuditRevenueHeadSummary/GetAllForOutlets", $http, $q, { propertyId: propertyId, date1: date1 });
        };
        this.getCompanyInfo = function (propertyId) {
            return httpCaller(apiPath + "Admin/Property/GetById/" + propertyId, $http, $q);
        };

    }
]);
