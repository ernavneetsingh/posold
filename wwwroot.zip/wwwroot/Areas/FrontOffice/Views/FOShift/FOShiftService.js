﻿'use strict';

(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getShiftDetail = function (model) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/FOShift/GetByUserId",
                data: model
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;

        };

        //var getLastShift = function (propertyId) {
        //    var deferred = $q.defer();
        //    $http({
        //        method: "GET",
        //        url: apiPath + "FrontOffice/FOShift/GetLastShift/" + propertyId,
        //    })
        //        .success(function (data) {
        //            deferred.resolve(data);
        //        })
        //        .error(function (data, status, headers, config) {
        //            deferred.reject(data, status, headers, config);
        //        });
        //    return deferred.promise;

        //};

        var getLastShift = function (model) {
            var url = apiPath + "FrontOffice/FOShift/GetLastShift";
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var openShiftRequest = function (model) {
            //var deferred = $q.defer();
            //$http.get(apiPath + "posshift/open/close/" + propertyId + "/" + userName)
            //    .then(function (result) {
            //        deferred.resolve(result.data);
            //    },
            //        function (data, status, headers, config) {
            //            deferred.reject(data, status, headers, config);
            //        });
            //return deferred.promise;

            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: apiPath + 'FrontOffice/FOShift/save',
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var getAllFOCashByFOShiftId = function (shiftId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/FOCash/GetAllByFOShiftId?shiftId=" + shiftId,
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;

        };
        var GetClosingByFOShiftId = function (shiftId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "FrontOffice/FOCash/GetClosingByFOShiftId/" + shiftId,
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;

        };
        var getOpeningByFOShiftId = function (shiftId) {

            var deferred = $q.defer();
            $http.get(apiPath + "FrontOffice/FOCash/GetOpeningByFOShiftId/" + shiftId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };


        var addCashRequest = function (shiftId, shiftNumber, propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "shiftId/add/cash/" + shiftId + "/" + shiftNumber + "/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var cashOutRequest = function (shiftId, shiftNumber, propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "foshift/case/out/" + shiftId + "/" + shiftNumber + "/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        var saveFOCash = function (foCash) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "FrontOffice/FOCash/Save",
                data: foCash
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        var saveCashOutRequest = function (cashOut) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "foshift/case/out/create",
                data: cashOut
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        //var logoutShift = function () {
        //    var deferred = $q.defer();
        //    $.ajax({
        //        type: "POST",
        //        url: apiPath + "FrontOffice/Operation/LoginTouchScreen/logout",
        //        data: {},
        //        contentType: "application/json; charset=utf-8",
        //        dataType: "json",
        //        headers: {
        //            'duxtechApiKey': accessToken
        //        },
        //        success: function (response) {
        //            deferred.resolve(response);
        //        },
        //        error: function (error, status, headers, config) {
        //            deferred.reject(error, status, headers, config);
        //        }
        //    });
        //    return deferred.promise;
        //};

        var yesIWantChangeOutlet = function (outlet) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "foshift/shiftoutlet/status",
                data: outlet
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        var isShiftBalance = function (shiftId) {
            var url = apiPath + 'FrontOffice/FOCash/IsShiftBalance/' + shiftId;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var getAllDenominationMaster = function (propertyId) {
            var deferred = $q.defer();
            $http({
                method: "GET",
                url: apiPath + "GlobalSetting/DenominationMaster/all?propertyId=" + propertyId,
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        var getByModuleSettingName = function (propertyId, moduleSettingName, error_suppress) {
            var params = { propertyId: propertyId, moduleSettingName: moduleSettingName };
            return httpCaller(apiPath + "GlobalSetting/ModuleSettingResponse/get", $http, $q, params, error_suppress);
        };

        var getByModuleSettingName = function (propertyId, moduleSettingName) {
            var url = apiPath + 'GlobalSetting/ModuleSettingResponse/Get?propertyId=' + propertyId + '&moduleSettingName=' + moduleSettingName;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var MapReport1 = function (propertyId, reportName) {
            
            var url = reportXPath + "api/Reporter/Report/MapReport?propertyId=" + propertyId + '&moduleSettingName=' + reportName;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var MapReport = function (filterValue, reportName) {
            
            return httpCaller1(reportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
        };
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var headers = { 'duxtechApiKey': accessToken, 'Accept': 'application/json; charset=utf-8' };
        var httpCaller1 = function (url, $http, $q, params) {

            var config = { headers: headers, params: params };
            var deferred = $q.defer();
            $http.defaults.useXDomain = true;
            try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e4) { }
            $http.get(url, config)
                .then(function (response) {
                    deferred.resolve(response.data);
                })
                .catch(function (ex) {
                    if (ex.data) {
                        msg(ex.data.Message);
                        deferred.reject(ex.data, status);
                    }
                    else {
                        msg('Undefined error!');
                        deferred.reject(ex.data, status);
                    }

                });
            return deferred.promise;
        }


        return {

            getShiftDetail: getShiftDetail,
            getLastShift: getLastShift,
            openShiftRequest: openShiftRequest,
            saveFOCash: saveFOCash,
            getAllFOCashByFOShiftId: getAllFOCashByFOShiftId,

            getOpeningByFOShiftId: getOpeningByFOShiftId,
            addCashRequest: addCashRequest,
            cashOutRequest: cashOutRequest,
            saveCashOutRequest: saveCashOutRequest,

            //logoutShift: logoutShift,
            yesIWantChangeOutlet: yesIWantChangeOutlet,
            isShiftBalance: isShiftBalance,
            getAllDenominationMaster: getAllDenominationMaster,
            GetClosingByFOShiftId: GetClosingByFOShiftId,
            getByModuleSettingName: getByModuleSettingName,
            MapReport: MapReport,
        };
    }

    apppos.factory("service", ["$http", "$q", service]);
})();
