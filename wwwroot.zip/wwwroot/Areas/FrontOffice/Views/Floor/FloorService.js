﻿
app.service("floorService", function () {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.getData = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/Floor/allfloor/?propertyId=" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "FrontOffice/Floor/allfloor/?propertyId=" + propertyId,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});
    };

    this.save = function (floorData) {
        return httpPoster(apiPath + "FrontOffice/Floor/create/modify", $http, $q, floorData);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Floor/create/modify",
        //    data: JSON.stringify(floorData),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.remove = function (floorData) {
        return httpPoster(apiPath + "FrontOffice/Floor/remove/" + floorData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Floor/remove/" + floorData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };

    this.status = function (floorData, currentUser) {
        return httpPoster(apiPath + "FrontOffice/Floor/changestatus?floorData=" + floorData + "&currentUser=" + currentUser, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Floor/changestatus?floorData=" + floorData + "&currentUser=" + currentUser,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});

    };

    this.Exists = function (floorData, propertyId) {
        return httpPoster(apiPath + "FrontOffice/Floor/existcode/" + propertyId + "/" + floorData, $http, $q);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Floor/existcode/" + propertyId + "/" + floorData,
        //    data: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    }
        //    ,
        //    error: function (data) {
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //    }
        //});
    };
});
