﻿
app.controller('controller', ['$scope', 'service', 'localStorageService', function ($scope, service, localStorageService) {

    $scope.Model = {};
    $scope.Model.IsActive = true;

    var sortKeyOrder = {
        key: '',
        order: '',
    };

    if (localStorageService.get("searchfor") !== undefined) {
        $scope.searchfor = localStorageService.get("searchfor");
    }

    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.maxSize = 100;
    $scope.recordsPerPage = 100;
    $scope.numberOfPageButtons = 100;

    getData($scope, service, localStorageService);
    $scope.sort = function (col) {
        sortKeyOrder = localStorageService.get('sortKeyOrder');
        if (sortKeyOrder !== null && sortKeyOrder.key === col) {
            if (sortKeyOrder.order == 'ASC')
                sortKeyOrder.order = 'DESC';
            else
                sortKeyOrder.order = 'ASC';
            localStorageService.set('sortKeyOrder', sortKeyOrder);

        } else {
            sortKeyOrder = {
                key: col,
                order: 'ASC'
            };
            localStorageService.set('sortKeyOrder', sortKeyOrder);
        }
    };

    $scope.pageChanged = function () {
        getData($scope, service, localStorageService);
    };

    $scope.search = function (searchfor) {
        if (searchfor === undefined) {
            $scope.searchfor = "";
        }
        localStorageService.set("searchfor", searchfor);
        getData($scope, service, localStorageService);
    }

    $scope.Edit = function (item) {
        $scope.Model = item;

        scrollPageOnTop();
    }

    $scope.Reset = function () {
        $scope.Model = {};
        $scope.Model.IsActive = true;
    }

    $scope.ErrorMessage = false;

    $scope.Save= function (model, form) {
        if ($scope[form].$valid) {
            var promiseGet = service.save($scope.Model);
            promiseGet.then(function (data, status) {
                getData($scope, service, localStorageService);

                parent.successMessage(data.Message);
                $scope.Reset();
            },
            function (data, status, headers, config) {
                parent.failureMessage(data.Message);
            });
        } else {
            $scope.ErrorMessage = true;
        }
    };

    $scope.IsNameExist = function (model) {

        var promiseGet = service.isNameExist(model);
        promiseGet.then(function (data) {
        },
        function (error) {
            $scope.Model.Name = "";
            parent.failureMessage(error.Message);
        });
    }

    $scope.IsOrderSNoExist = function (model) {
        var promiseGet = service.isOrderSNoExist(model);
        promiseGet.then(function (data) {
        },
        function (error) {
            $scope.Model.OrderSNo = "";
            parent.failureMessage(error.Message);
        });
    }

    $scope.ChangeStatus = function (model) {
        
        var promiseGet = service.changeStatus(model.Id);
        promiseGet.then(function (data) {
            parent.successMessage(data.Message);
            getData($scope, service, localStorageService);
            scrollPageOnTop();
        },
            function (error) {
                parent.failureMessage(error.Message);
                scrollPageOnTop();
            });
    };

}]);


var getData = function ($scope, dataService, localStorageService) {

    $scope.data = dataService.dataModel;

    var sortKeyOrder = localStorageService.get('sortKeyOrder');
    if (sortKeyOrder == null) {
        sortKeyOrder = {
            key: 'OrderSNo',
            order: 'ASC'
        };
    }

    var searchfor = localStorageService.get('searchfor');
    $scope.sortKeyOrder = sortKeyOrder;
    var options = {
        currentPage: $scope.currentPage,
        recordsPerPage: $scope.recordsPerPage,
        sortKeyOrder: sortKeyOrder,
        searchfor: searchfor
    };

    $scope.showLoader = true;
    dataService.getAll(options)
    .then(function (totalItems) {
        $scope.totalItems = totalItems;
        $scope.showLoader = false;
    },
    function () {
        alert("The request failed. Unable to connect to the remote server.");
    });

};