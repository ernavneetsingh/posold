﻿
(function () {
    function service($http, $q, $timeout, $window) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getRating = function (id, moduleId) {
            var deferred = $q.defer();
            $http.get(apiPath + "GlobalSetting/Rating/GetAllByKOTBillId/" + id + "/" + moduleId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        function save(model) {

            var deferred = $q.defer();
            $http({
                method: "POST",
                url: apiPath + "PointOfSale/FeedbackRating/Save",
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);
            }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        return service = {
            getRating: getRating,
            save: save
        };
         
    }

    app.factory("service", ["$http", "$q", "$timeout", "$window", service]);
})();
