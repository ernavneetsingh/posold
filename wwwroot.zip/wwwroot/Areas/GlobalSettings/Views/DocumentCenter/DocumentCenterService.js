﻿
app.service('DocumentCenterService', [
    '$http', '$q', function (
        $http, $q) {

        this.getGuestList = function (propertyId) {
            return httpCaller(apiPath + 'FrontOffice/Guest/GetAllByPropertyId', $http, $q, { propertyId: propertyId });
        };
        this.getDocumentTypeList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/DocumentType/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
        }
        this.getAll = function (options) {
            return httpCaller(apiPath + "GlobalSetting/DocumentCenter/GetAll", $http, $q, options);
        }

        this.save = function (model) {
            return httpPoster(apiPath + "GlobalSetting/DocumentCenter/save", $http, $q, model);
        };
        this.delete = function (id) {
            return httpCaller(apiPath + "GlobalSetting/DocumentCenter/delete", $http, $q, { id: id });
        };

    }
]);
