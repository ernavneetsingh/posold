﻿function taxstructurebox() {
    $('#taxstructurebox').show('slow');
}

function closeBox() {
    $('#taxstructurebox').hide('slow');
}



$(function () {


    /*Room Rate Master Right Form Coding Starts Here by Tarun Gupta*/
    $('#roomratebox').slideDown('slow');

    /* Transaction and account detail page's codding starts from here by Tarun Gupta*/
    $('#searchlink').click(function () {
        $('#searchbox').fadeIn('slow');
        $('#historybox').css('display', 'none');
        $('li').removeClass('active');
        $('#searchlink').addClass('active');
    });
    $('#historylink').click(function () {
        $('#historybox').fadeIn('slow');
        $('#searchbox').css('display', 'none');
        $('li').removeClass('active');
        $('#historylink').addClass('active');
    });

    /* de-link transaction page coding */
    $('#delinktranlink').click(function () {
        $('#delinktrasacbox').fadeIn('20000000');
        $('#linktransactionbox').css('display', 'none');
        $('.linkdetran li').removeClass('active');
        $('#delinktranlink').addClass('active');
        $('#delinktranlink').css('padding', '4px 25px');
        $('#delinktranlink').css('margin-top', '8px');
        $('#linktranslink').css('padding', '8px 25px');
        $('#linktranslink').css('margin-top', '0px');
        $('#linktranslink').css('opacity', '0.5');
        $('#delinktranlink').css('opacity', '1');


    });
    $('#linktranslink').click(function () {
        $('#linktransactionbox').fadeIn('2000000000');
        $('#delinktrasacbox').css('display', 'none');
        $('.linkdetran li').removeClass('active');
        $('#linktranslink').addClass('active');
        $('#linktranslink').css('padding', '4px 25px');
        $('#linktranslink').css('margin-top', '8px');
        $('#delinktranlink').css('padding', '8px 25px');
        $('#delinktranlink').css('margin-top', '0px');
        $('#delinktranlink').css('opacity', '0.5');
        $('#linktranslink').css('opacity', '1');

    });

    $('#ratechangelink').click(function (ratechange) {
        if (ratechange.target.checked) {
            $('#chargetypebox').slideToggle('slow');
        }
        else {
            $('#chargetypebox').hide('slow');
        }

    });
    $('#changetaxstruclink').click(function (changetax) {
        if (changetax.target.checked) {
            $('#chargetypebox').hide('slow');
        }
        else {
            $('#chargetypebox').show('slow');
        }

    });
    $('#btnSlide2').click(function () {

        if ($('.mainnavigation-nav').css('width') == '54px') {
            $('.mainnavigation-nav').css({ 'width': '225px' });
            $('.page-content').css('width', '84%');
            $('.page-content').css('margin-left', '200px');
            $('.dashboard-cashering').css('width', '84%');
            $('.dashboard-cashering').css('margin-left', '185px');
            $('.navbar-header').css('width', '225px');
            $('.nav-new').css('width', '225px');
            $('#navnewicon').css('margin-left', '175px');
            $('.arrowalig').css('right', '20px');
            $('.arrowalig').css('position', 'absolute');
            $('.arrowalig').css('margin-right', '0px');
            $('.graphs').css('margin-left', '203px');
            $('.graphs').css('width', '83%');
            $('.submenu-wrap').css('display', 'none');
            $('.site-footer').css('margin-left', '160px');

        }
        else {
            $('.mainnavigation-nav').css({ 'width': '54px' });
            $('.page-content').css('width', '98%');
            $('.page-content').css('margin-left', '25px');
            $('.dashboard-cashering').css('width', '99%');
            $('.dashboard-cashering').css('margin-left', '17px');
            $('.submodule').css('display', 'none');
            $('.navbar-header').css('width', '54px');
            $('.nav-new').css('width', '54px');
            $('#navnewicon').css('margin-left', '0px');
            $('.arrowalig').css('right', '10px');
            $('.arrowalig').css('position', 'absolute');
            $('.arrowalig').css('margin-right', '-50px');
            $('.graphs').css('width', '97%');
            $('.graphs').css('margin-left', '32px');
            $('.submenu-wrap').css('display', 'none');
            $('.site-footer').css('margin-left', '0px');
        }
    })


    $('#mainnav-ul').click(function () {
        $('.mainnavigation-nav').css('width', '225px', 'transition', '0.1s');
        $('.mainnavigation-nav ul li a span').show();
        $('.mainnavigation-nav ul li a').css('display', 'block');
        $('.mainnavigation-nav ul li a span i').css('float', 'right');
        $('.page-content').css('width', '84%');
        $('.page-content').css('margin-left', '200px');
        $('.dashboard-cashering').css('width', '84%');
        $('.dashboard-cashering').css('margin-left', '185px');
        $('.navbar-header').css('width', '225px');
        $('.nav-new').css('width', '225px');
        $('#navnewicon').css('margin-left', '175px');
        $('.arrowalig').css('right', '20px');
        $('.arrowalig').css('position', 'absolute');
        $('.arrowalig').css('margin-right', '0px');
        $('.graphs').css('margin-left', '203px');
        $('.graphs').css('width', '83%');
        $('.site-footer').css('margin-left', '160px');

    })

    //$(".subModule").click(function (event) {
    //    var $input = $(event.target);
    //    var parent = $($input.parents('.drink-select').get(0));

    //    console.log(parent);
    //});
    //$(this).find('.mainmodule').click(function () {
    //    $('.mainnavigation-nav ul li ul').show('slow');
    //    $('.mainnavigation-nav ul li i').css('transform', 'rotate(90deg)','trasition','0.3s');
    //    $(this).find('.submodule').css('background-color', '#222226');
    //});
    //$('.mainnavigation-nav ul li ul a').click(function () {
    //    $('.submenu-wrap').show('slow');
    //    $('.submenu-wrap').css('display','block','z-index','999');
    //});

    $('.submenu-wrap').mouseenter(function () {
        $('.mainnavigation-nav').css('width', '225px', 'transition', '0.3s');
        $('.mainnavigation-nav ul li a span').show();
        $('.mainnavigation-nav ul li a').css('display', 'block');
        $('.navbar-header').css('width', '225px');
        $('.nav-new').css('width', '225px');
        $('#navnewicon').css('margin-left', '175px');
        $('.graphs').css('margin-left', '203px');
        $('.graphs').css('width', '83%');
        //$('.mainnavigation-nav ul li ul').css('display', 'block');
    }).mouseleave(function () {
        $('.mainnavigation-nav').css('width', '225px', 'transition', '0.1s');
        $('.mainnavigation-nav ul li a span').show();
        $('.mainnavigation-nav ul li a').css('display', 'block');
        $('.mainnavigation-nav ul li a span i').css('float', 'right');

        $('.submenu-wrap').hide();


    });


    $('#monthly').on('click', function () {
        $('#monthlybox').css('display', 'block');
        $('#weeklybox').css('display', 'none');
        $('#currentdatebox').css('display', 'none');
        $('#monthly').addClass('active');
        $('#weeklylink').removeClass('active');
        $('#currentdatelink').removeClass('active');
    });
    $('#weeklylink').on('click', function () {
        $('#weeklybox').css('display', 'block');
        $('#monthlybox').css('display', 'none');
        $('#currentdatebox').css('display', 'none');
        $('#weeklylink').addClass('active');
        $('#monthly').removeClass('active');
        $('#currentdatelink').removeClass('active');
    });
    $('#currentdatelink').on('click', function () {
        $('#currentdatebox').css('display', 'block');
        $('#monthlybox').css('display', 'none');
        $('#weeklybox').css('display', 'none');
        $('#currentdatelink').addClass('active');
        $('#monthly').removeClass('active');
        $('#weeklylink').removeClass('active');
    });

    $('#fdlink').click(function () {
        $('#fd').show('slow');
        $('#pos,#inv,#hk,#ar').hide('slow');
        $('#fdlink').addClass('active');
        $('#poslink,#invlink,#hklink,#arlink').removeClass('active');
    });
    $('#poslink').click(function () {
        $('#pos').show('slow');
        $('#fd,#inv,#hk,#ar').hide('slow');
        $('#poslink').addClass('active');
        $('#fdlink,#invlink,#hklink,#arlink').removeClass('active');
    });
    $('#invlink').click(function () {
        $('#inv').show('slow');
        $('#fd,#pos,#hk,#ar').hide('slow');
        $('#invlink').addClass('active');
        $('#fdlink,#poslink,#hklink,#arlink').removeClass('active');
    });
    $('#hklink').click(function () {
        $('#hk').show('slow')
        $('#fd,#pos,#inv,#ar').hide('slow');
        $('#hklink').addClass('active');
        $('#fdlink,#poslink,#invlink,#arlink').removeClass('active');
    });
    $('#arlink').click(function () {
        $('#ar').show('slow');
        $('#fd,#pos,#inv,#hk').hide('slow');
        $('#arlink').addClass('active');
        $('#fdlink,#poslink,#invlink,#hklink').removeClass('active');
    });
    $('#discntlink').click(function () {
        $('#frmrevn-btn').css('display', 'none');
        $('#dicntid').css('display', 'block');

    });
    $('#manuallink').click(function () {
        $('#frmrevn-btn').css('display', 'block');
        $('#dicntid').css('display', 'none');
    });

    $('#paymodeadvance').change(function () {
        var paymode = $('#paymodeadvance option:selected').val();
        if (paymode == "Credit Card") {
            $('#creditcardbox').show('slow');
            $('#chequenumberbox').hide('slow');
        }
        if (paymode == "Cheque") {
            $('#creditcardbox').hide('slow');
            $('#chequenumberbox').show('slow');
        }
    });

    $('#company').click(function () {
        $('#iata').hide('slow');
        $('#companyid').show('slow');
        $('#unicompany').show('slow');
        $('#idnumber').hide('slow');
    });
    $('#travelagent').click(function () {
        $('#companyid').hide('slow');
        $('#iata').show('slow');
        $('#unicompany').show('slow');
        $('#idnumber').hide('slow');
    });
    $('#individual').click(function () {
        $('#idnumber').show('slow');
        $('#iata').hide('slow');
        $('#companyid').hide('slow');
        $('#unicompany').hide('slow');
    });
    $('#billingdetailslink').click(function (billingdetails) {
        if (billingdetails.target.checked) {
            $('#billingdetailsbox').show('slow');
            $('#contactdetails').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#accountdetails').hide('slow');
            $('#discountcode').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#contactdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#billingdetailsbox').hide('slow');

        }
    });

    $('#contactdetailslink').click(function (contactdetails) {
        if (contactdetails.target.checked) {
            $('#contactdetails').show('slow');
            $('#billingdetailsbox').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#accountdetails').hide('slow');
            $('#discountcode').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#contactdetails').hide('slow');
        }
    });
    $('#bookersdetailslink').click(function (bookersdetails) {
        if (bookersdetails.target.checked) {
            $('#bookersdetails').show('slow');

            $('#billingdetailsbox').hide('slow');
            $('#contactdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#accountdetails').hide('slow');
            $('#discountcode').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#contactdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#bookersdetails').hide('slow');
        }
    });
    $('#businessdetailslink').click(function (businessdetails) {
        if (businessdetails.target.checked) {
            $('#businessdetails').show('slow');

            $('#billingdetailsbox').hide('slow');
            $('#contactdetails').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#accountdetails').hide('slow');
            $('#discountcode').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#contactdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#businessdetails').hide('slow');
        }
    });
    $('#negotiatedrateslink').click(function (negotiatedrates) {
        if (negotiatedrates.target.checked) {
            $('#negotiatedrates').show('slow');

            $('#billingdetailsbox').hide('slow');
            $('#contactdetails').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#accountdetails').hide('slow');
            $('#discountcode').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#contactdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#negotiatedrates').hide('slow');
        }
    });
    $('#accountdetailslink').click(function (accountdetails) {
        if (accountdetails.target.checked) {
            $('#accountdetails').show('slow');

            $('#billingdetailsbox').hide('slow');
            $('#contactdetails').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#discountcode').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#contactdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#accountdetails').hide('slow');
        }
    });
    $('#dicountcodelink').click(function (dicountcode) {
        if (dicountcode.target.checked) {
            $('#discountcode').show('slow');

            $('#billingdetailsbox').hide('slow');
            $('#contactdetails').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#accountdetails').hide('slow');
            $('#revenueforcast').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#contactdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#revenueforecastlink').attr('checked', false);
        }
        else {
            $('#discountcode').hide('slow');
        }
    });
    $('#revenueforecastlink').click(function (revenueforcast) {
        if (revenueforcast.target.checked) {
            $('#revenueforcast').show('slow');

            $('#billingdetailsbox').hide('slow');
            $('#contactdetails').hide('slow');
            $('#bookersdetails').hide('slow');
            $('#businessdetails').hide('slow');
            $('#negotiatedrates').hide('slow');
            $('#accountdetails').hide('slow');
            $('#discountcode').hide('slow');

            $('#billingdetailslink').attr('checked', false);
            $('#contactdetailslink').attr('checked', false);
            $('#bookersdetailslink').attr('checked', false);
            $('#businessdetailslink').attr('checked', false);
            $('#negotiatedrateslink').attr('checked', false);
            $('#accountdetailslink').attr('checked', false);
            $('#dicountcodelink').attr('checked', false);
        }
        else {
            $('#revenueforcast').hide('slow');
        }
    });
    $('#allowcreditlink').click(function () {
        $('#creditbox').show('slow');

    });

    $('#closesession').click(function () {
        $('#menucard').fadeOut('slow');
    });
    $('#walikclose').click(function () {
        $('#walikinintvw').fadeOut('slow');
    });
    $('#btnwalkin').click(function () {
        $('#walikinintvw').fadeOut('slow');
    });

    $('#changerateclose').click(function () {
        $('#reservationRoomTypeRateBox').fadeOut('slow');
    });
    $('#bookerscloseicon').click(function () {
        $('#bookersbox').fadeOut('slow');
    });
    $('#bookersbtn').click(function () {
        $('#bookersbox').fadeOut('slow');
    });
    $('#changeratelink').click(function (changeratelink) {
        if (changeratelink.target.checked) {
            $('#changeratedivbox').show('slow');
            $('#mltidysmtlrtebox').hide('slow');

            $('#mltirtemltdylink').attr('checked', false);
        }
        else {
            $('#changeratedivbox').hide('slow');
        }
    });
    $('#mltirtemltdylink').click(function (mltirtemltdylink) {
        if (mltirtemltdylink.target.checked) {
            $('#mltidysmtlrtebox').show('slow');
            $('#changeratedivbox').hide('slow');

            $('#changeratelink').attr('checked', false);
        }
        else {
            $('#mltidysmtlrtebox').hide('slow');

        }
    });

    $('#addcompanylink').click(function () {
        $('#walikinintvw').slideDown('slow');
    });
    $('#addbookerslink').click(function () {
        $('#bookersbox').slideDown('slow');
    });
    $('#changeratebtnlink').click(function () {
        $('#reservationRoomTypeRateBox').slideDown('slow');
        $('#changeratelink').prop('checked', true);
    });

    $('#disocuntidlink').click(function () {
        $('#manualbox').slideDown('slow');
        $('#discountidbox').slideUp('slow');

    });

    $('#manualidlink').click(function () {
        $('#discountidbox').slideDown('slow');
        $('#manualbox').slideUp('slow');

    });

    $('#addhotelposition').click(function () {
        $('#hotelpositionbox').fadeIn('slow');
    });
    $('#hotelpositionclose').click(function () {
        $('#hotelpositionbox').fadeOut('slow');
    });
    //$('#locknowbtn').click(function () {
    //    $('#hotelpositionbox').fadeOut('slow');
    //});
    $('#guestinfoedit').click(function (e) {
        $('#guestinfomain').show();
        $('#guestinfo').hide();
        $('#passportvisashow, #pickdropinfoshow, #extrachargesshow, #likedislikeshow, #vehicleinformationshow, #documentcentershow, #workdetailshow').removeClass('reservation-nav-inactive');
        $('#advanceshow, #discountshow, #groupinformationshow, #arrangementsamenitiesshow').addClass('reservation-nav-inactive');

        $('#guestinfoshow').text("Back To Reservation");
    });

    $('#paxdetailslink').click(function () {
        $('#paxdetailsbox').slideDown('slow');
    });
    $('#paxdetailcloseicon').click(function () {
        $('#paxdetailsbox').slideUp('slow');
    });

    $('.chefs-recomed li a').click(function () {
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
        }
        else {
            $(this).addClass('active');
        }
    });

    //$('.calendar-row-container li').on('click', function () {
    //    $('#quickreservationbox').show('slow');
    //});
    $("#quickreserclose").on("click", function () {
        $("#quickreservationbox").hide("slow");
    });

    $('#btnShow').click(function () {
        $('#dialog').show('slow');
    });

    $('#invoicesettleclose').click(function () {
        $('#dialog').hide('slow');
    });
    $('#invoicesettleconfirm').click(function () {
        $('#dialog').hide('slow');
    });

    $('#changeratepopclose').click(function () {
        $('#changeratepopbox').hide('fast');
    });

    $('.datemothyr-calendar .calendar-dashboard .category').click(function () {
        alert('its working');
        if ($('.repeatable-wrap').hasClass('calendar-content-opened')) {
            $('.repeatable-wrap').removeClass('calendar-content-opened');
        }
        else {
            $('.repeatable-wrap').addClass('calendar-content-opened');
        }
    });


});

function changeratePop() {
    $('#changeratepopbox').show('fast');
}

