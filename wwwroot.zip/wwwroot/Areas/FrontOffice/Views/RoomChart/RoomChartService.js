﻿
app.service('roomChartService', ["$http", "$q", function ($http, $q) {

    var getRoomChart = function (model) {

        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChart';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;

    };
    var cancelReservationConfirm = function (model) {
        return httpPoster(apiPath + "FrontOffice/Reservation/Cancel", $http, $q, model);
        //var deferred = $q.defer();
        //$.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Reservation/Cancel",
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    data: JSON.stringify(model),
        //    headers: {
        //        'duxtechApiKey': accessToken
        //    },
        //    success: function (data) {
        //        deferred.resolve(data);
        //    },
        //    error: function (data, status, headers, config) {
        //        deferred.reject(data, status, headers, config);
        //    }
        //});
        //return deferred.promise;
    };
    var getRoomChartTest = function (model) {

        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartTest';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var getAllReservationRoomType = function (model) {
        var url = apiPath + 'FrontOffice/RoomChart/GetAllReservationRoomType';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var getDepartment = function (propertyId) {
        var url = apiPath + 'GlobalSetting/Department/allbystatus/' + propertyId + '/1';
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result.Collection);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;

    };

    var getReason = function (propertyId) {
        var url = apiPath + 'GlobalSetting/Reason/all/?propertyId=' + propertyId + '&moduleId=1&active=1';
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result.Collection);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;
    };

    var saveRoomStatus = function (model) {

        var deferred = $q.defer();
        var url = apiPath + 'FrontOffice/RoomStatus/SaveStatus';
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    function getCurrentRoomGuests1(roomMasterId, businessDate) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/CheckINGuest/GetRoomGuests?roomMasterId=" + roomMasterId + "&businessDate=" + businessDate,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;
    };

    function getCurrentRoomGuests(checkINGuestRoomId, businessDate) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/CheckINGuest/GetAllGuestByCheckINGuestRoomId?checkINGuestRoomId=" + checkINGuestRoomId + "&businessDate=" + businessDate,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;
    };

    function getReservationByRoomTypeId(reservationRoomTypeId) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/Reservation/GetByReservationRoomTypeId/" + reservationRoomTypeId,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;
    };

    function getRoomStatusById(id) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/RoomStatus/GetById/" + id,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;
    };

    var saveRoomTransfer = function (model) {
        var deferred = $q.defer();
        var url = apiPath + 'FrontOffice/GuestManagement/SaveTransfer';
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {

            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    function getByRoomId(roomMasterId, businessDate) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/RoomStatus/GetByRoomId?roomId=" + roomMasterId + "&businessDate=" + businessDate,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;
    };

    var getRoomList = function (propertyId, roomTypeId, featureId, floorId, blockId, roomStatusId, statusDate) {
        //return httpCaller(apiPath + "FrontOffice/RoomMaster/Search", $http, $q, { propertyId: propertyId, roomTypeId: roomTypeId, featureId: featureId || 'All', floorId: floorId || 'All', blockId: blockId || 'All', roomStatusId: roomStatusId || 'All', statusDate: statusDate });
        return httpCaller(apiPath + "FrontOffice/RoomMaster/Search", $http, $q, { propertyId: propertyId, roomTypeId: roomTypeId || "All", featureId: featureId || 'All', floorId: floorId || 'All', blockId: blockId || 'All', roomStatusId: 'All' });
    };
    var getRoom = function (propertyId) {
        var url = apiPath + 'FrontOffice/RoomMaster/GetActive/' + propertyId + '/1';
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;
    };

    var getRoomCustom = function (propertyId) {
        var url = apiPath + 'FrontOffice/RoomMaster/GetAllCustomRoomByPropertyId/' + propertyId;
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (result) {
            deferred.resolve(result);
        }).error(function (err) {
            deferred.reject(err);
        });
        return deferred.promise;
    };

    var getRoomType = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/RoomType/GetAllByPropertyIdMin", $http, $q, { propertyId: propertyId });
    };
    var getFloor = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/Floor/allByPropertyId", $http, $q, { propertyId: propertyId });
    };
    var getRoomFeature = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/RoomFeatures/details", $http, $q, { propertyId: propertyId });
    };
    var getBlock = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/Block/GetAllByPropertyId", $http, $q, { propertyId: propertyId });
    };

    var getRoomFeatureRoom = function (propertyId) {
        return httpCaller(apiPath + "FrontOffice/RoomChart/GetRoomChartRoomFeatureRoom/" + propertyId, $http, $q, {});
    };

    //no show
    var noShow = function (model) {
        var deferred = $q.defer();
        $http({
            method: "POST",
            url: apiPath + "FrontOffice/NightAudit/NOShow",
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (err, status) {

            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    //RoomBlock

    function getRoomBlockById(id) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/RoomBlock/GetById/" + id,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(status);
        });
        return deferred.promise;
    };

    var SaveRoomBlock = function (model) {
        var deferred = $q.defer();
        $http({
            method: "POST",
            url: apiPath + "FrontOffice/RoomBlock/Save",
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {

            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    var ReleaseRoomBlock = function (model) {
        var deferred = $q.defer();
        $http({
            method: "POST",
            url: apiPath + "FrontOffice/RoomBlock/Release",
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {

            deferred.reject(err, status);
        });
        return deferred.promise;
    };

    function ChangeRoomOutDate(checkINGuestId, newRoomOutDate, businessDate) {

        var deferred = $q.defer();
        $http({
            method: "GET",
            url: apiPath + "FrontOffice/CheckINGuest/ChangeRoomOutDate/" + checkINGuestId + "/" + newRoomOutDate + "/" + businessDate,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (err, status) {
            deferred.reject(err.Message);
        });
        return deferred.promise;
    };

    var UpdateInventory = function (model) {
        var url = apiPath + 'Admin/PropertyChannelManager/GetAllRoomInventory';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var MapReport = function (filterValue, reportName) {
        var url = ReportXPath + "api/Reporter/Report/MapReport";
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: { filterValue: filterValue, reportName: reportName },
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;

        //return httpCaller1(ReportXPath + "api/Reporter/Report/MapReport", $http, $q, { filterValue: filterValue, reportName: reportName });
    };

    var sendSMS = function (model) {
        return httpPoster(apiPath + "FrontOffice/Reservation/SendSMS", $http, $q, model);
        //var deferred = $q.defer();
        //$.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Reservation/SendSMS",
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    data: JSON.stringify(model),
        //    headers: {
        //        'duxtechApiKey': accessToken
        //    },
        //    success: function (data) {
        //        deferred.resolve(data);
        //    },
        //    error: function (data, status, headers, config) {
        //        deferred.reject(data, status, headers, config);
        //    }
        //});
        //return deferred.promise;
    };

    var SendMail = function (id, smsTemplateTypeId, propertyId, businessDate) {

        var model = { Id: id, SMSTemplateTypeId: smsTemplateTypeId, PropertyID: propertyId, BusinessDate: businessDate };
        return httpPoster(apiPath + "FrontOffice/Reservation/SendMail", $http, $q, model);
       // var deferred = $q.defer();
        //$.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/Reservation/SendMail",
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    data: JSON.stringify(model),
        //    headers: {
        //        'duxtechApiKey': accessToken
        //    },
        //    success: function (data) {
        //        deferred.resolve(data);
        //    },
        //    error: function (data, status, headers, config) {
        //        deferred.reject(data, status, headers, config);
        //    }
        //});
        //return deferred.promise;
    };

    var GetPropertyGroupByPropertyId = function (propertyId) {
        return httpCaller(apiPath + "Admin/Property/GetPropertyGroupByPropertyId/" + propertyId, $http, $q, {});
    };
    var GetRoomChartCalendar = function (model) {

        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartCalendar';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {

            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var GetRoomChartReservationRoomType = function (model) {
        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartReservationRoomType';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var GetRoomChartCheckINGuestRoom = function (model) {
        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartCheckINGuestRoom';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var GetRoomChartRoomBlock = function (model) {
        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartRoomBlock';
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: url,
            data: model,
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };

    var SaveReservationInterPropertyTransfer = function (model) {
        return httpPoster(apiPath + "FrontOffice/ReservationInterPropertyTransfer/Save", $http, $q, model);
        //var deferred = $q.defer();
        //$.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/ReservationInterPropertyTransfer/Save",
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    data: JSON.stringify(model),
        //    headers: {
        //        'duxtechApiKey': accessToken
        //    },
        //    success: function (data) {
        //        deferred.resolve(data);
        //    },
        //    error: function (data, status, headers, config) {
        //        deferred.reject(data, status, headers, config);
        //    }
        //});
        //return deferred.promise;
    };
    var SaveCheckINGuestRoomInterPropertyTransfer = function (model) {
        return httpPoster(apiPath + "FrontOffice/CheckINGuestRoomInterPropertyTransfer/Save", $http, $q, model);
        //var deferred = $q.defer();
        //$.ajax({
        //    type: "POST",
        //    url: apiPath + "FrontOffice/CheckINGuestRoomInterPropertyTransfer/Save",
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    data: JSON.stringify(model),
        //    headers: {
        //        'duxtechApiKey': accessToken
        //    },
        //    success: function (data) {
        //        deferred.resolve(data);
        //    },
        //    error: function (data, status, headers, config) {
        //        deferred.reject(data, status, headers, config);
        //    }
        //});
        //return deferred.promise;
    };

    //var getDepartment = function (propertyId) {
    //    var url = apiPath + 'GlobalSetting/Department/allbystatus/' + propertyId + '/1';
    //    var deferred = $q.defer();
    //    $http({
    //        method: 'GET',
    //        url: url,
    //        data: {},
    //        headers: { 'duxtechApiKey': accessToken },
    //        contentType: "application/json; charset=utf-8"
    //    }).success(function (result) {
    //        deferred.resolve(result.Collection);
    //    }).error(function (err) {
    //        deferred.reject(err);
    //    });
    //    return deferred.promise;

    //};

    var GetRoomChartRoomType = function (propertyId) {
        var url = apiPath + 'FrontOffice/RoomChart/GetRoomChartRoomType/' + propertyId;
        var deferred = $q.defer();
        $http({
            method: 'GET',
            url: url,
            data: {},
            headers: { 'duxtechApiKey': accessToken },
            contentType: "application/json; charset=utf-8"
        }).success(function (data, status, headers, cfg) {
            deferred.resolve(data);
        }).error(function (data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        });
        return deferred.promise;
    };
    return {
        getRoomChart: getRoomChart,
        getDepartment: getDepartment,
        getReason: getReason,
        saveRoomStatus: saveRoomStatus,
        getCurrentRoomGuests: getCurrentRoomGuests,
        saveRoomTransfer: saveRoomTransfer,
        getByRoomId: getByRoomId,
        getRoomList: getRoomList,
        getRoomCustom: getRoomCustom,
        getRoomType: getRoomType,
        getFloor: getFloor,
        getRoomFeature: getRoomFeature,
        getBlock: getBlock,
        getRoomChartTest: getRoomChartTest,
        getReservationByRoomTypeId: getReservationByRoomTypeId,
        getRoomStatusById: getRoomStatusById,
        noShow: noShow,
        getAllReservationRoomType: getAllReservationRoomType,
        SaveRoomBlock: SaveRoomBlock,
        ReleaseRoomBlock: ReleaseRoomBlock,
        getRoomBlockById: getRoomBlockById,
        ChangeRoomOutDate: ChangeRoomOutDate,
        UpdateInventory: UpdateInventory,
        MapReport: MapReport,
        SendMail: SendMail,
        sendSMS: sendSMS,
        GetPropertyGroupByPropertyId: GetPropertyGroupByPropertyId,

        GetRoomChartCalendar: GetRoomChartCalendar,
        GetRoomChartReservationRoomType: GetRoomChartReservationRoomType,
        GetRoomChartCheckINGuestRoom: GetRoomChartCheckINGuestRoom,
        GetRoomChartRoomBlock: GetRoomChartRoomBlock,
        SaveReservationInterPropertyTransfer: SaveReservationInterPropertyTransfer,
        SaveCheckINGuestRoomInterPropertyTransfer: SaveCheckINGuestRoomInterPropertyTransfer,
        GetRoomChartRoomType: GetRoomChartRoomType,
        getRoomFeatureRoom: getRoomFeatureRoom,
        cancelReservationConfirm: cancelReservationConfirm,
    };

}
]);