﻿
app.service("periodCloseService", function ($q, $http, $filter) {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.GetAll = function (propertyId) {
        return httpCaller(apiPath + "AccountReceiveable/PeriodClose/all/" + propertyId, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/PeriodClose/all/" + propertyId,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {

        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.Get = function (propertyId, dateFormat) {
        return httpCaller(apiPath + "AccountReceiveable/PeriodClose/get/" + propertyId + "/" + dateFormat, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/PeriodClose/get/" + propertyId + "/" + dateFormat,
        //    params: {},
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {

        //        parent.failureMessage(data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.getStartPeriodCall = function (propertyId) {
        var params = { propertyId: propertyId };
        return httpCaller(apiPath + "AccountReceiveable/PeriodClose/GetStartPeriod", $http, $q, params);

        //var deferred = $q.defer();
        //$http.get(apiPath + "AccountReceiveable/PeriodClose/GetStartPeriod/" + propertyId)
        //    .success(function (data, status, headers, cfg) {
        //        deferred.resolve(data);
        //    }).error(function (err, status) {
        //        
        //        msg(err.Message);
        //        deferred.reject(err, status);
        //    });
        //return deferred.promise;
    };

    this.getStartPeriod = function ($scope) {
        $scope.MinDate = $filter('date')(new Date(), "yyyy-MM-dd");
        var getData = this.getStartPeriodCall($scope.PropertyID, $scope.DateFormat);
        getData.then(function (data) {

            if (data.Message.length > 0) {
                $scope.periodCloseDate = data.Message;
                $scope.MinDate = $filter('date')(dateAdd(data.Message, 'day', -1), "yyyy-MM-dd");
                //$scope.MinDate = $filter('date')(data.Message, "yyyy-MM-dd");
            }
        });
    };

    this.Save = function (model) {
        return httpPoster(apiPath + "AccountReceiveable/PeriodClose/save/", $http, $q, model);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "AccountReceiveable/PeriodClose/save/",
        //    data: JSON.stringify(model),
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };
});
