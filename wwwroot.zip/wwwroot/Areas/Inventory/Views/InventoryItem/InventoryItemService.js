﻿
'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getData = function (propertyId) {

            var url = apiPath + "Inventory/InventoryItem/all/" + propertyId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getItemGroup = function () {
            var url = apiPath + 'ReferenceConstant/ItemGroupType/all/';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getAllItemCategory = function (propertyId, date) {

            var url = apiPath + 'GlobalSetting/ItemCategory/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: { propertyId: propertyId, date: date },
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getItemCategory = function (propertyId, itemGroupTypeId, date) {
            var url = apiPath + "GlobalSetting/ItemCategory/all";
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                params: { propertyId: propertyId, itemGroupTypeId: itemGroupTypeId, date: date, active: 1 },
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getAllUnitType = function () {

            var url = apiPath + 'ReferenceConstant/UnitType/all/';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getSelectUnit = function (propertyId, unitTypeId) {
            var url = apiPath + 'GlobalSetting/UnitOfMeasurement/all/' + propertyId + "/" + unitTypeId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getStoreType = function () {
            var url = apiPath + "ReferenceConstant/storeType/all/";
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getSubStore = function (propertyId, storeTypeId) {
            var url = apiPath + 'Inventory/Store/allByStoreType?active=1&propertyId=' + propertyId + '&storeTypeId=' + storeTypeId;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getAllBrand = function (propertyId) {

            var url = apiPath + 'GlobalSetting/Brand/all/?propertyId=' + propertyId + '&all=1';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Collection);
            }).error(function (err) {

                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getInventoryLocationList = function (propertyId) {
            var params = { propertyId: propertyId, active: 1 };
            return httpCaller(apiPath + "Inventory/InventoryLocation/all", $http, $q, params);
        };
        var getCostCenterList = function (propertyId) {
            return httpCaller(apiPath + "GlobalSetting/CostCenter/all", $http, $q, { propertyId: propertyId, active: 1 });
        };

        var save = function (model) {

            var url = apiPath + 'Inventory/InventoryItem/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });

            return deferred.promise;
        };
        var remove = function (propertyId, id) {
            var url = apiPath + 'Inventory/InventoryItem/delete/' + propertyId + "/" + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                msg(data.Message);
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        var statusChange = function (propertyId, id) {

            var url = apiPath + 'Inventory/InventoryItem/status/' + propertyId + "/" + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;


        };
        var isLocationExist = function (propertyId, code) {

            var url = apiPath + 'Inventory/InventoryItem/existcode/' + propertyId + "/" + code;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {

                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var saveFromExcel = function (fd, waiter) {

            var deferred = $q.defer();
            $http.post(apiPath + 'Inventory/InventoryItem/SaveFromExcel', fd, {
                withCredentials: false,
                headers: { 'Content-Type': undefined, 'duxtechApiKey': accessToken },
                transformRequest: angular.identity
            }).then(function (d) {

                waiter.IsUploadingExcel = false;
                msg(d.data.Message, d.data.Status);
                deferred.resolve(d.data);
            }).catch(function (e) {

                waiter.IsUploadingExcel = false;
                msg('Upload upto ' + (e.data ? e.data.Message : ''));
                deferred.reject(e.data);
            });
            return deferred.promise;

        }

        return {
            getCostCenterList: getCostCenterList,
            getData: getData,
            getSubStore: getSubStore,
            getSelectUnit: getSelectUnit,
            getStoreType: getStoreType,
            getItemCategory: getItemCategory,
            getItemGroup: getItemGroup,
            getAllUnitType: getAllUnitType,
            getInventoryLocationList: getInventoryLocationList,
            isLocationExist: isLocationExist,
            save: save,
            remove: remove,
            getAllBrand: getAllBrand,
            statusChange: statusChange,
            saveFromExcel:saveFromExcel
        };
    }

    app.factory('InventoryItemService', ['$http', '$q', service]);
})();
