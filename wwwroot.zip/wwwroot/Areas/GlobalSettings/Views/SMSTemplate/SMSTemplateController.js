﻿
app.controller("controller",[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout", "$rootScope",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout, $rootScope) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');
        $scope.keys = localStorageService.get('ActionKeys');
        $scope.Model = {
            Id: '',
            UserName: '',
            Password: '',
            IsActive: true,
            Balance: '',

            PropertyID: '',
            ModifiedBy: '',
            SMSTemplates: [],
        };

        function GetAllByPropertyId() {

            var promiseGet = service.getAllByPropertyId($scope.PropertyID);
            promiseGet.then(function (data) {
                
                angular.forEach(data.Collection, function (item) {

                    if (item.SMSTemplateTypeName == "Reservation" && item.ActionTypeName == "Add") {
                        $scope.ReservationAdd = item.Template;
                        $scope.ReservationAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "Reservation" && item.ActionTypeName == "Edit") {
                        $scope.ReservationEdit = item.Template;
                        $scope.ReservationEditActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "Reservation" && item.ActionTypeName == "Cancel") {
                        $scope.ReservationCancel = item.Template;
                        $scope.ReservationCancelActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "CheckIN" && item.ActionTypeName == "Add") {
                        $scope.CheckINAdd = item.Template;
                        $scope.CheckINAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "CheckOUT" && item.ActionTypeName == "Add") {
                        $scope.CheckOUTAdd = item.Template;
                        $scope.CheckOUTAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "PurchaseOrder" && item.ActionTypeName == "Add") {
                        $scope.PurchaseOrderAdd = item.Template;
                        $scope.PurchaseOrderAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "POSCustomer" && item.ActionTypeName == "Add") {
                        $scope.POSCustomerAdd = item.Template;
                        $scope.POSCustomerAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "POSMember" && item.ActionTypeName == "Add") {
                        $scope.POSMemberAdd = item.Template;
                        $scope.POSMemberAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "POSDeliveryDriver" && item.ActionTypeName == "Add") {
                        $scope.POSDeliveryDriverAdd = item.Template;
                        $scope.POSDeliveryDriverAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "POSDeliveryCustomer" && item.ActionTypeName == "Add") {
                        $scope.PPOSDeliveryCustomerAdd = item.Template;
                        $scope.PPOSDeliveryCustomerAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "POSSettlementCustomer" && item.ActionTypeName == "Add") {
                        $scope.POSSettlementCustomerAdd = item.Template;
                        $scope.POSSettlementCustomerAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "POSSettlementMember" && item.ActionTypeName == "Add") {
                        $scope.POSSettlementMemberAdd = item.Template;
                        $scope.POSSettlementMemberAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "KOT" && item.ActionTypeName == "Add") {
                        $scope.KOTAdd = item.Template;
                        $scope.KOTAddActive = item.IsActive;
                    }
                    else if (item.SMSTemplateTypeName == "KOTBill" && item.ActionTypeName == "Add") {
                        $scope.KOTBillAdd = item.Template;
                        $scope.KOTBillAddActive = item.IsActive;
                    } else if (item.SMSTemplateTypeName == "Birthday" && item.ActionTypeName == "Add") {
                        $scope.BirthdayAdd = item.Template;
                        $scope.BirthdayAddActive = item.IsActive;
                    } else if (item.SMSTemplateTypeName == "Anniversary" && item.ActionTypeName == "Add") {
                        $scope.AnniversaryAdd = item.Template;
                        $scope.AnniversaryAddActive = item.IsActive;
                    } else if (item.SMSTemplateTypeName == "Promotional" && item.ActionTypeName == "Add") {
                        $scope.PromotionalAdd = item.Template;
                        $scope.PromotionalAddActive = item.IsActive;
                    } else if (item.SMSTemplateTypeName == "ExpectedArrival" && item.ActionTypeName == "Add") {
                        $scope.ExpectedArrivalAdd = item.Template;
                        $scope.ExpectedArrivalAddActive = item.IsActive;
                    } else if (item.SMSTemplateTypeName == "KOTBillOTP" && item.ActionTypeName == "OTP") {
                        $scope.KOTBillOTP = item.Template;
                        $scope.KOTBillOTPActive = item.IsActive;
                    }
                });

            },
                function (error) {
                    $scope.Model = {};
                    msg(error.Message);
                    scrollPageOnTop();
                });
        };
        GetAllByPropertyId();

        $scope.Save = function (form) {
            var abc = $scope.ReservationEditActive, abc2 = $scope.ReservationEditActive == 'true', abc3 = $scope.ReservationAddActive == 'true';
            if ($scope[form].$valid) {
                
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 1, ActionTypeId: 1, Template: $scope.ReservationAdd, IsActive: $scope.ReservationAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 1, ActionTypeId: 2, Template: $scope.ReservationEdit, IsActive: $scope.ReservationEditActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 1, ActionTypeId: 3, Template: $scope.ReservationCancel, IsActive: $scope.ReservationCancelActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 2, ActionTypeId: 1, Template: $scope.CheckINAdd, IsActive: $scope.CheckINAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 3, ActionTypeId: 1, Template: $scope.CheckOUTAdd, IsActive: $scope.CheckOUTAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 4, ActionTypeId: 1, Template: $scope.PurchaseOrderAdd, IsActive: $scope.PurchaseOrderAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 7, ActionTypeId: 1, Template: $scope.POSCustomerAdd, IsActive: $scope.POSCustomerAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 8, ActionTypeId: 1, Template: $scope.POSMemberAdd, IsActive: $scope.POSMemberAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 9, ActionTypeId: 1, Template: $scope.POSDeliveryDriverAdd, IsActive: $scope.POSDeliveryDriverAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 10, ActionTypeId: 1, Template: $scope.POSDeliveryCustomerAdd, IsActive: $scope.POSDeliveryCustomerAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 11, ActionTypeId: 1, Template: $scope.POSSettlementCustomerAdd, IsActive: $scope.POSSettlementCustomerAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 12, ActionTypeId: 1, Template: $scope.POSSettlementMemberAdd, IsActive: $scope.POSSettlementMemberAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 13, ActionTypeId: 1, Template: $scope.KOTAdd, IsActive: $scope.KOTAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 14, ActionTypeId: 1, Template: $scope.KOTBillAdd, IsActive: $scope.KOTBillAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 16, ActionTypeId: 1, Template: $scope.BirthdayAdd, IsActive: $scope.BirthdayAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 17, ActionTypeId: 1, Template: $scope.AnniversaryAdd, IsActive: $scope.AnniversaryAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 18, ActionTypeId: 1, Template: $scope.PromotionalAdd, IsActive: $scope.PromotionalAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 20, ActionTypeId: 1, Template: $scope.ExpectedArrivalAdd, IsActive: $scope.ExpectedArrivalAddActive });
                $scope.Model.SMSTemplates.push({ SMSTemplateTypeId: 24, ActionTypeId: 4, Template: $scope.KOTBillOTP, IsActive: $scope.KOTBillOTPActive });

                $scope.Model.PropertyID = $scope.PropertyID;
                $scope.Model.ModifiedBy = $scope.ModifiedBy;
                $scope.Model.ModifiedDate = $scope.ModifiedDate;

                var status = service.save($scope.Model);
                status.then(function (result) {
                    if (result.Status == true) {
                        GetAllByPropertyId();
                        msg("SMS Template " + result.Message, true);
                    }
                },
                function (error) {
                    scrollPageOnTop();
                    msg(error.Message);
                });
            }
            else {
                $scope.ShowErrorMessage = true;
            }
        }

        $scope.InsertField = function (cntr, value) {
            value = cntr + ':' + value;
            $rootScope.$broadcast('add', value);
        }

    }
]);
