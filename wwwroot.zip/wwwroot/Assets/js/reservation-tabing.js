﻿$(function () {
    $('#guestinfoshow').click(function (t) {
        
        if ($("#guestinfo").is(":visible") == true) {
            return;
        }
        if (t.currentTarget.text == "Back To Reservation") {

            $('#passportvisashow, #pickdropinfoshow, #extrachargesshow, #likedislikeshow, #vehicleinformationshow, #documentcentershow, #workdetailshow').addClass('reservation-nav-inactive');
            $('#advanceshow, #discountshow, #groupinformationshow, #arrangementsamenitiesshow').removeClass('reservation-nav-inactive');

            $('#guestinfoshow').text("Guest Information");
            $('#guestinfomain').hide('slow');
        }
        else
        {
            //$('#guestinfomain').show('slow');
            //$('#guestinfomain').slideToggle('slow');
        }
        
        $('#guestinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');

    });

    $('#test').click(function () {
        
        $('#guestinfomain').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");

        $('#guestinfo, #passportinfo ,#pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#passportvisashow').click(function () {
        
        $('#passportinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");

        $('#guestinfo, #guestinfomain ,#pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#pickdropinfoshow').click(function () {
        $('#pickupdropinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#advanceshow').click(function () {
        $('#advance').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#discountshow').click(function () {
        $('#discount').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #advance, #extracharges, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#extrachargesshow').click(function () {
        $('#extracharges').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #advance, #discount, #groupinfo, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#groupinformationshow').click(function () {
        $('#groupinfo').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #likedislike, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#likedislikeshow').click(function () {
        $('#likedislike').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #vehiclenumber, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#vehicleinformationshow').click(function () {
        $('#vehiclenumber').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #arrangements,#documentcenter,#workdetail').css('display', 'none');
    });

    $('#arrangementsamenitiesshow').click(function () {
        $('#arrangements').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo,#guestinfomain , #passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber,#documentcenter,#workdetail').css('display', 'none');

    });

    $('#documentcentershow').click(function () {
        $('#documentcenter').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #guestinfomain ,#passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber,#arrangements,#workdetail').css('display', 'none');

    });
    
    $('#workdetailshow').click(function () {
        $('#workdetail').slideToggle('slow');
        $("li a").removeClass("visited")
        $(this).addClass("visited");
        $('#guestinfo, #guestinfomain ,#passportinfo, #pickupdropinfo, #advance, #discount, #extracharges, #groupinfo, #likedislike, #vehiclenumber,#arrangements,#documentcenter').css('display', 'none');

    });
});