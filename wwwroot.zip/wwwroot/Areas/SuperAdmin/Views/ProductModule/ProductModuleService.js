﻿"use strict";


(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var model = [];
        var getAll = function (options) {
            var url = apiPath + "configuration/ProductModule?currentPage=" + options.currentPage + "&" +
               "recordsPerPage=" + options.recordsPerPage + "&" +
               "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: options,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, model);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (module) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: apiPath + 'configuration/ProductModule/save',
                data: module,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        var getAllModules = function () {
            var url = apiPath + 'configuration/module/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,             
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllProducts = function () {
            var url = apiPath + 'configuration/product/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,                
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
    
        var ChangeStatus = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: apiPath + 'configuration/product/modules/status/' + id,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
            return deferred.promise;
        };

        return {
            dataAllData: model,
            getAll : getAll,
            save: save,
            getAllModules: getAllModules,
            getAllProducts: getAllProducts,
            ChangeStatus: ChangeStatus
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();

