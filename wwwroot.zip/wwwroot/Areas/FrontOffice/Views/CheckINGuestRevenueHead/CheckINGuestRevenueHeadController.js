﻿
app.controller("CheckINGuestRevenueHeadController",
[
    "$scope", "CheckINGuestRevenueHeadService", "$cookies", "localStorageService", function ($scope, service, $cookies, localStorageService) {
        $scope.UserName = $cookies.get('UserName');
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        var businessDateStr = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

        $scope.RevenueHeads = [];

        $scope.FillRevenueHead = function (checkINGuest) {
            $scope.SelectedCheckINGuest = checkINGuest;
            angular.forEach($scope.RevenueHeads, function (revenueHead) {
                revenueHead.IsSelected = false;
                angular.forEach(checkINGuest.RevenueHeads, function (item) {
                    if(revenueHead.Code == item.Code)
                    {
                        revenueHead.IsSelected = true;
                    }
                });
            });

            $('#revenueHeadBox').modal('show');
        };
        $scope.Reset = function (checkINGuest) {
            angular.forEach($scope.RevenueHeads, function (revenueHead) {
                revenueHead.IsSelected = false;
            });
        };

        $scope.GetAllGroupMember = function (checkINGuest) {
            $scope.SelectedCheckINGuest = checkINGuest;
            service.getAllGroupMember(checkINGuest.Id, businessDateStr)
                .then(function (data, status) {
                    $scope.GroupCheckINGuests = data.Collection;
                    $('#groupBox').modal('show');
                }, function (e) {
                    msg(e.Message);
                });
        };

        
        $scope.CheckINGuests = [];
        $scope.GetAllGroup = function () {
            service.getAllGroup($scope.PropertyID, 2, businessDateStr)
                .then(function (data, status) {
                    $scope.CheckINGuests = data.Collection;
                }, function (e) {
                    msg(e.Message);
                });
        };
        $scope.GetAllGroup();

        $scope.getRevenueHeadList = function () {
            service.getRevenueHeadList($scope.PropertyID)
                .then(function (result) {
                    
                    $scope.RevenueHeads = result.Collection;
                }, function (err) {
                    msg(err.Message);
                });

        };
        $scope.getRevenueHeadList();


        $scope.Save = function () {
            
            var model = {
                Id: $scope.SelectedCheckINGuest.Id,
                PropertyID: $scope.PropertyID,
                RevenueHeads:[],
            }

            angular.forEach($scope.RevenueHeads, function (revenueHead) {
                if (revenueHead.IsSelected == true) {
                    model.RevenueHeads.push({Code:revenueHead.Code});
                }
            });

            service.save(model)
                .then(function (result) {
                    $('#revenueHeadBox').modal('hide');
                    $scope.GetAllGroup();
                    msg(result.Message, true);

                    
                }, function (err) {
                    msg(err.Message);
                });

        };
    }
]);
