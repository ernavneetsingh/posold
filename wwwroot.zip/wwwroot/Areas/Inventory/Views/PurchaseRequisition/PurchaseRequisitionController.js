﻿
'use strict';
app.controller('Controller', [
    '$scope', 'PurchaseRequisitionService', '$cookies', '$filter', 'localStorageService', '$window',
    function ($scope, service, $cookies, $filter, localStorageService, $window) {

        //$scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        //$scope.ModifiedBy = $cookies.get('UserName');
        //$scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
        $scope.LoginId = $cookies.get('LoginId');
        //setTimeout(function () {
        $scope.Status = "All";
        //}, 300);

        //Common
        $scope.CostCenters = [];
        $scope.getCostCenters = function () {
            service.getCostCenters($scope.PropertyID)
                .then(function (data) {
                    $scope.CostCenters = data.Collection;
                });
        };
        $scope.getCostCenters();

        $scope.myConfig = {
            valueField: "Id",
            labelField: "Name",
            searchField: ["Name"],
            sortField: "Name",
            create: true,
            maxItems: 1
        }

        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        }
        $scope.Clearmodel = function () {

            //$scope.model = {};
            $scope.model.PurchaseRequisitionItems = [];
            $scope.PurchaseRequisitionItem = {};
            $scope.PRNumber = '';
            $scope.query = '';
            Reset();
        };

        //TAB: 1

        var pathServer = Path;
        // var pathServer = apiPath.substr(0, apiPath.indexOf('/api'));
        $scope.gridOptions = {
            expandableRowTemplate: pathServer + '/expandableRowTemplate.html',
            expandableRowHeight: 150,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: {
                text: "PR Details",
                style: 'headerStyle'
            },
            exporterPdfFooter: function (currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(),
                    style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22,
                    bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10,
                    bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'A4',
            exporterPdfMaxGridWidth: 400,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {

                    if (row.isExpanded) {

                        row.entity.subGridOptions = {
                            columnDefs: [
                            {
                                name: 'StoreName'
                            },
                            {
                                name: 'InventoryItemName'
                            },
                            {
                                name: 'BrandName'
                            },
                            {
                                name: 'ItemTypeName'
                            },
                            {
                                name: 'Quantity', cellClass: 'grid-align-right'
                            },
                            {
                                name: 'QuantityToReceive', cellClass: 'grid-align-right', displayName: "Pending"
                            },
                            {
                                name: 'UnitOfMeasurementName', displayName: 'UOM'
                            },
                             //{
                             //    name: 'CostCenterName'
                             //},
                            {
                                name: 'RequiredDate', cellFilter: 'date:' + $scope.DateFormat
                            }
                            ]
                        };
                        row.entity.subGridOptions.data = row.entity.PurchaseRequisitionItems;

                    }
                });
            }

        }
        $scope.gridOptions.columnDefs = [
        {
            name: 'PRNumber',
            pinnedLeft: true
        },
        {
            name: 'PRDate', cellFilter: 'date:grid.appScope.DateFormat'
        },
        {
            name: 'CostCenterName', displayName: 'Cost Center'
        },
        {
            name: 'ApprovedByName', displayName: 'Approved By'
        },
        {
            name: 'PRStatusTypeName', displayName: 'Status'
        }
        ];

        $scope.getAll = function (statusTypeId, searchText, searchType) {
            service.getAll($scope.PropertyID, statusTypeId, searchText, searchType)
                .then(function (result) {
                    $scope.items = result.Collection;
                    $scope.search();
                });
        };
        $scope.getAll(6, 'All', 'All');

        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.search = function () {

            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "CostCenterName" || attr === "PRNumber" || attr === "PRDate") {
                        var dd = item[attr];
                        if (dd == null || dd === 'undefined' || dd === '') {
                        } else {
                            if (searchMatch(item[attr], $scope.query))
                                return true;
                        }
                    }
                }
                return false;

            });
            $scope.gridOptions.data = $scope.filteredItems;
            if ($scope.filteredItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
            } else {
                $scope.MsgNotFound = "";
            }
        };

        //TAB: 2 Create PR

        $scope.isCreatePR = true;
        $scope.clickCopyButton = function () {
            $scope.isCreatePR = false;
            if ($scope.PRNumber != undefined && $scope.PRNumber != null && $scope.PRNumber != "") {
                $scope.showErrorCopyMsg = false;
            } else {
                $scope.showErrorCopyMsg = true;
            }
        };

        $scope.GetItemSearch = function (txt) {
            service.getItemSearch(txt, $scope.PropertyID);
        };
        $scope.GetPRSearch = function (txt) {
            service.getPRSearch(6, txt, $scope.PropertyID);// 6 for All in POStatus
        };

        $scope.Reasons = [];
        GetReason();
        function GetReason() {

            var promiseGet = service.getReasons($scope.PropertyID, 5);
            promiseGet.then(function (data) {

                $scope.Reasons = data.Collection;
            }, function (data) {
                parent.failureMessage(data.message);
                scrollpageontop();
            });
        };

        $scope.Save = function (formName) {

            if ($scope.PRNumber == "No Records Found") {
                $scope.PRNumber = "";
            }

            if (formName == 'modifyForm') {
                if (angular.isUndefined($scope.PRNumber) || $scope.PRNumber === "" || $scope.PRNumber === null) {
                    parent.failureMessage("Please Select PR Number.");
                    scrollpageontop();
                    return;
                }
            }

            if (formName == 'createForm') {
                if ($scope.model.PurchaseRequisitionItems.length === 0) {
                    parent.failureMessage("Please Select Item.");
                    scrollPageOnTop();
                    return;
                }
            }

            if ((!$scope.model.CostCenterId) || $scope.model.CostCenterId.length < 0) {
                parent.failureMessage("Please Select Cost Center.");
                scrollPageOnTop();
                return;
            }

            for (var g = 0; g < $scope.model.PurchaseRequisitionItems.length; g++) {

                if (!$scope.model.PurchaseRequisitionItems[g].Quantity || $scope.model.PurchaseRequisitionItems[g].Quantity <= 0) {
                    parent.failureMessage("Invalid item quantity.");
                    scrollPageOnTop();
                    return;
                }

                $scope.RequiredDate = new Date($scope.model.PurchaseRequisitionItems[g].RequiredDate);
                if ($scope.PRDate > $scope.RequiredDate) {
                    parent.failureMessage("Required Date should not be less then PR Create Date.");
                    scrollPageOnTop();
                    return;
                }
            }

            if (formName == 'createForm') {
                $scope.model.Id = null;
            }
            else {
                if (angular.isUndefined($scope.model.ReasonId) || $scope.model.ReasonId === "" || $scope.model.ReasonId === null) {
                    parent.failureMessage("Please Select Reason.");
                    scrollPageOnTop();
                    return;
                }
            }

            if (!$scope[formName].$valid) {
                $scope.showErrorMsg = true;
            } else {

                $scope.model.PropertyID = $scope.PropertyID;
                $scope.model.ModifiedBy = $scope.ModifiedBy;
                //$scope.model.DateFormat = $scope.DateFormat;

                $scope.IsSaving = true;
                var promiseGet = service.save($scope.model);
                promiseGet.then(function (d) {
                    parent.successMessage("PR successfully saved.");
                    Reset();
                    scrollPageOnTop();

                    service.MapReport($scope.PropertyID, 'purchase_requisition')
                        .then(function (s) {
                            var m1 = d.Message.split(" ");
                            var pid = m1.pop();
                            fancyPrintConfirm(m1.join(' '), $window, '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + pid);
                        }, function (e) {
                            //$scope.IsSaved = true;
                            msg('Error in mapping to print.');
                        });
                },
                function (xhr) {
                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                })
                .finally(function () {
                    $scope.IsSaving = false;
                });
            }
            scrollPageOnTop();
        };
        $scope.getDuplicateItem = function (item, index) {//Id, brandId, costCenterId, index) {

            var itemId = item.InventoryItemId;
            var brandId = item.BrandId;
            var costCenterId = item.CostCenterId;

            service.getItemRate($scope.PropertyID, itemId, brandId)
            .then(function (result) {

                item.Rate = result.Data;
                $scope.GetAmount(0);
            });
            service.getItemStock($scope.PropertyID, itemId, brandId, $scope.model.PRDate)//, item.CostCenterId)
                .then(function (result) {

                    item.QuantityAvailable = result.Data;

                });

            if (!index) return;
            for (var i = 0; i < $scope.model.PurchaseRequisitionItems.length; i++) {
                if (index != i) {
                    if (($scope.model.PurchaseRequisitionItems[i].InventoryItemId.length > 0) && ($scope.model.PurchaseRequisitionItems[i].BrandId.length > 0) && ($scope.model.PurchaseRequisitionItems[i].CostCenterId.length > 0)) {
                        if ($scope.model.PurchaseRequisitionItems[i].InventoryItemId === itemId && $scope.model.PurchaseRequisitionItems[i].BrandId === brandId && $scope.model.PurchaseRequisitionItems[i].CostCenterId === costCenterId) {
                            parent.failureMessage("Same Item with duplicate Brand and Cost Center.");
                            item.CostCenterId = "";
                            //$scope.model.PurchaseRequisitionItems[index].CostCenterId = "";
                            scrollPageOnTop();
                            break;
                        }
                    }
                }
            }
        }
        $scope.RemoveCreate = function (index) {
            $scope.model.PurchaseRequisitionItems.splice(index, 1);
        };

        Reset();
        function Reset() {

            $scope.model = {};
            $scope.model.PurchaseRequisitionItems = [];
            $scope.model = {
                Id: '',
                PRDate: $scope.ModifiedDate,
                PRNumber: '',
                POStatusType: '',
                POStatusTypeId: 6,
                POStatusTypeName: '',
                PaymentTerms: '',
                Remarks: '',
                ApplyDiscount: '',
                TotalAmount: 0,
                TotalTax: 0,
                TotalDiscount: 0,
                GrossAmount: 0,
                RequiredDate: '',
                ReasonId: '',
                ReasonName: '',
                ModificationRemarks: '',
                IsApproved: '',
                ApprovedBy: '',
                ApprovedByName: '',
                ApprovedDate: '',
                PurchaseRequisitionItems: [],
                PropertyID: '',
                ModifiedBy: '',
                DateFormat: '',
                items: []
            };
            $scope.model.PODate = $scope.ModifiedDate;// $filter('date')(date, $scope.DateFormat);
            $scope.PurchaseRequisitions = [];
            $scope.PurchaseRequisitionItems = [];

            $scope.AuthorizationPRs = [];
            $scope.model.Remarks = "";
            $("#authorizationSearch").val("");

            $scope.PRNumber = "";
            $scope.Search = "";

            scrollPageOnTop();
        }
        $scope.GetAmount = function (index) {

            angular.forEach($scope.model.PurchaseRequisitionItems, function (item, i) {

                //if (item.Discount == undefined) {
                //    item.Discount = 0;
                //}

                //if (i === index) {

                //$scope.Model.ApplyDiscount = "";
                //if (item.DiscountInId == '2') {
                //    if (parseFloat(item.Discount) > 100) {
                //        parent.failureMessage(item.InventoryItemName + " Percent(%) value can not be more then 100");
                //        item.Discount = 0.00;
                //        scrollPageOnTop();
                //    }
                //} else {

                //    var itemvalue = item.Amount.toString();
                //    itemvalue = replaceAll(itemvalue, ',', '');

                //    if (parseFloat(item.Discount) > parseFloat(itemvalue)) {
                //        parent.failureMessage(item.InventoryItemName + " discount value can not be more then " + item.Amount);
                //        item.Discount = 0.00;
                //        scrollPageOnTop();
                //    }
                //}

                //if (item.DiscountInId == '2') {
                //    item.DiscountAmount = parseFloat(item.Rate) * parseFloat(item.Quantity) * item.Discount * 0.01;
                //}
                //else {
                //    item.DiscountAmount = item.Discount;
                //}
                item.Amount = parseFloat(item.Rate) * parseFloat(item.Quantity);//- parseFloat(item.DiscountAmount);
                item.Amount = $filter('number')(parseFloat(item.Amount), 2);
                //}
            });

            $scope.Index = index;
            //$scope.CalculateTAX($scope.Model.PurchaseOrderItems);
            $scope.CalculateTotal();
        }
        $scope.CalculateTotal = function () {

            var totalDiscount = 0.00;
            //var totalTaxAmount = 0.00;
            var grossAmount = 0.00;
            var netAmount = 0.00;

            angular.forEach($scope.model.PurchaseRequisitionItems, function (item) {

                var amount = item.Amount.toString();
                amount = replaceAll(amount, ',', '');

                //var discount = item.Discount.toString();
                //discount = replaceAll(discount, ',', '');

                //var taxAmount = item.TaxAmount ? item.TaxAmount.toString() : "0";
                //taxAmount = replaceAll(taxAmount, ',', '');

                //if (item.DiscountInId === '2') {

                //    totalDiscount += parseFloat((parseFloat(amount) * parseFloat(discount)) / 100);

                //}
                //else {
                //    totalDiscount += parseFloat(discount);

                //}

                grossAmount += parseFloat(amount);
                //totalTaxAmount += parseFloat(taxAmount);

            });

            //netAmount = grossAmount + totalTaxAmount - totalDiscount;

            //$scope.Model.TotalAmount = $filter('number')(parseFloat(netAmount), 2).replace(/,/g, '');
            //$scope.Model.TotalTax = $filter('number')(parseFloat(totalTaxAmount), 2).replace(/,/g, '');
            //$scope.Model.TotalDiscount = $filter('number')(parseFloat(totalDiscount), 2).replace(/,/g, '');
            $scope.model.GrossAmount = $filter('number')(parseFloat(grossAmount), 2).replace(/,/g, '');

        };

        $scope.changeCopyDate = function () {

            if ($scope.isChangeCopyDate && $scope.model && $scope.model.PurchaseRequisitionItems && $scope.model.PurchaseRequisitionItems.length > 1) {
                var d = $scope.model.PurchaseRequisitionItems[0].RequiredDate;
                $scope.model.PurchaseRequisitionItems.forEach(function (pri) {
                    pri.RequiredDate = d;
                });
            }

        };

        //----for Tab-3-----
        $scope.GetItemSearch1 = function (txt) {
            service.getItemSearch1(txt, $scope.PropertyID);
        };
        $scope.GetPRSearchMO = function (txt) {
            service.getPRSearchMO(3, txt, $scope.PropertyID);   // 3 for Pending in POStatus
        };

        //------For Tab-4-------
        $scope.GetPRSearchCancel = function (txt) {

            service.getPRSearchCancel(3, txt, $scope.PropertyID);   // 3 for Pending in POStatus
        };
        $scope.CancelPR = function (formName) {



            if (angular.isUndefined($scope.PRNumber) || $scope.PRNumber === "" || $scope.PRNumber === null) {
                parent.failureMessage("Please Select PR Number.");
                scrollpageontop();
                return;
            }

            if (angular.isUndefined($scope.model.ReasonId) || $scope.model.ReasonId === "" || $scope.model.ReasonId === null) {
                parent.failureMessage("Please Select Reason.");
                scrollPageOnTop();
                return;
            }

            if ($scope[formName].$valid) {

                $scope.model.PropertyID = $scope.PropertyID;
                $scope.model.ModifiedBy = $scope.ModifiedBy;

                var promiseGet = service.cancelPR($scope.model);
                promiseGet.then(function (details) {
                    parent.successMessage("PR Cancel successfully.");
                    Reset();
                    scrollPageOnTop();

                }, function (xhr) {
                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };

        //----For Tab-5----
        $scope.GetPRSearchClose = function (txt) {
            service.getPRSearchClose(4, txt, $scope.PropertyID);    // 4 for partial in POStatus
        };
        $scope.ClosePR = function (formName) {
            if (angular.isUndefined($scope.PRNumber) || $scope.PRNumber === "" || $scope.PRNumber === null) {
                parent.failureMessage("Please Select PRNumber.");
                scrollPageOnTop();
                return;
            }
            if (angular.isUndefined($scope.model.ReasonId) || $scope.model.ReasonId === "" || $scope.model.ReasonId === null) {
                parent.failureMessage("Please Select Reason.");
                scrollPageOnTop();
                return;
            }

            if ($scope[formName].$valid) {

                $scope.model.PropertyID = $scope.PropertyID;
                $scope.model.ModifiedBy = $scope.ModifiedBy;
                //$scope.model.DateFormat = $scope.DateFormat;

                var promiseGet = service.closePR($scope.model);
                promiseGet.then(function (details) {

                    parent.successMessage("PR Closed successfully.");
                    Reset();
                    scrollPageOnTop();
                },
                function (xhr) {

                    var errorMessage = $.parseJSON(xhr.responseText);
                    alertErrorMessage(errorMessage.Message);
                });
            } else {
                $scope.showErrorMsg = true;
            }
            scrollPageOnTop();
        };

        //---For Tab-6-----
        $scope.AuthorizationPRs = [];

        $scope.checkAllAuthorizationPO = function () {
            if ($scope.selectedAllAuthorization) {
                angular.forEach($scope.PurchaseRequisitions, function (value, key) {
                    value.IsApproved = true;
                    $scope.AuthorizationPRs.push(value);
                });
                $scope.selectedAllAuthorization = true;
            } else {
                angular.forEach($scope.PurchaseRequisitions, function (value, key) {
                    value.IsApproved = false;
                });
                $scope.AuthorizationPRs = [];
                $scope.selectedAllAuthorization = false;
            }
        };

        $scope.toggleSelection = function (itm) {
            var idx = $scope.AuthorizationPRs.indexOf(itm);
            if (idx > -1) {
                $scope.AuthorizationPRs.splice(idx, 1);
            } else {
                $scope.AuthorizationPRs.push(itm);
            }
        };

        $scope.GetPRSearchAuthorized = function (txt) {
            // 3 for Pending in POStatus
            service.getPRSearchAuthorized(3, txt, $scope.PropertyID);
        };

        $scope.PurchaseRequisitions = [];

        $scope.GetUnauthorizedList = function () {
            $scope.PurchaseRequisitions = [];
            $scope.model.PurchaseRequisitionItems = [];

            var promiseGet = service.getUnauthorizedList($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.PurchaseRequisitions = data;
            }, function (data) {
                parent.failureMessage(data.Message);
                scrollpageontop();
            });
        };

        $scope.SaveAuthorization = function () {

            if ($scope.model.Remarks == undefined)
                $scope.model.Remarks = "";

            if ($scope.AuthorizationPRs.length == 0) {
                parent.failureMessage("Please select at least one PR.");
                scrollPageOnTop();
                return;
            }

            angular.forEach($scope.AuthorizationPRs, function (value, key) {
                value.ModificationRemarks = $scope.model.Remarks;
                value.ApprovedDate = $scope.ModifiedDate;
                value.PropertyID = $scope.PropertyID;
                value.ModifiedBy = $scope.ModifiedBy;
            });

            var promiseGet = service.saveAuthorization($scope.AuthorizationPRs);
            promiseGet.then(function (details) {
                parent.successMessage("Authorization successfully saved.");
                $scope.GetUnauthorizedList();
                Reset();
                scrollPageOnTop();

            }, function (xhr) {
                var errorMessage = $.parseJSON(xhr.responseText);
                parent.failureMessage(errorMessage.Message);
                scrollPageOnTop();
            });
            scrollPageOnTop();
        };


    }
]);
