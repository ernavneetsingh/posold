﻿
app.controller('NightReportController', [
    '$scope', '$cookies', 'localStorageService', '$timeout', '$window', function (
        $scope, $cookies, localStorageService, $timeout, $window) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedBy = $cookies.get('UserName');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);

        $scope.SelectedProperties = [];
        $scope.MasterSettings = { scrollableHeight: "200px", scrollable: true, enableSearch: true, displayProp: "Name" };

        $scope.loadReport = function (reportId) {
            if (!$scope['formlost'].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            var props = '';
            $scope.SelectedProperties.forEach(function (p) {
                props += p.Id + ",";
            });
            var pwin = $window.open($window.Path + 'Reporter/ReportViewer?id=' + reportId + '&p=1&@props=' + props + '&@ccyyymm=' + $scope.model.DateString.substring(0, 4) + $scope.model.DateString.substring(5, 7) + '&@day=' + $scope.model.DateString.substring(8), '_blank', 'width=1000,height=700');

        };

    }
]);
