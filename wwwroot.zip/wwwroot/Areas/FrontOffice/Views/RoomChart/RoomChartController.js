﻿app.controller("RoomChartController", [
    "$scope", "roomChartService", "localStorageService", "$cookies", "$filter", "$timeout", "$window", "manuService", "$rootScope", function (
        $scope, roomChartService, localStorageService, $cookies, $filter, $timeout, $window, manuService, $rootScope) {
        $scope.ModifiedBy = $cookies.get('UserName'); 
        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate');
        $scope.ModifiedDate = $scope.BusinessDate.Year + '-' + ('0' + $scope.BusinessDate.Month).slice(-2) + '-' + ('0' + $scope.BusinessDate.Day).slice(-2);
           
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = $scope.BusinessDate.Year +"-" + $scope.BusinessDate.Month +"-"+ $scope.BusinessDate.Day;
        $scope.businessDate = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        var businessDate = $filter('date')($scope.businessDate, $scope.DateFormat);

        $scope.ChangeDateCalendarMinDate = $scope.businessDate.getFullYear() + '/' + ('0' + ($scope.businessDate.getMonth() + 1)).slice(-2) + '/' + ('0' + $scope.businessDate.getDate()).slice(-2);

        var CalendarLength = 30; //days

        $scope.IsReservationActive = false;

        $scope.IsMouseDown = false;
        $scope.IsShowScreen1 = true;
        $scope.IsShowScreen2 = false;
        $scope.IsShowScreen3 = false;
        $scope.IsShowScreen4 = false;
        
        $scope.getRoomType = function () {
            $scope.RoomTypes = [];
            roomChartService.getRoomType($scope.PropertyID)
                   .then(function (result) {
                       $scope.RoomTypes = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };

        $scope.ShowRoomRate = function () {
            if ($scope.IsShowScreen2)
            {
                $scope.IsShowScreen1 = true;
                $scope.IsShowScreen2 = false;
                $("#reservationModelDialog").css('width', '75%');
            }
            else {
                $scope.IsShowScreen1 = false;
                $scope.IsShowScreen2 = true;
                $("#reservationModelDialog").css('width', '75%');
            }
        }

        $scope.$on("CallShowScreen1", function (event, obj) {
            $scope.CallShowScreen1();
        });

        $scope.$on("CallShowScreen2", function (event, obj) {
            $scope.CallShowScreen2();
        });

        $scope.$on("CallShowScreen3", function (event, obj) {
            $scope.CallShowScreen3();
        });

        $scope.CallShowScreen3 = function () {
            $scope.IsShowScreen1 = false;
            $scope.IsShowScreen2 = false;
            $scope.IsShowScreen3 = true;
        }

        $scope.CallShowScreen2 = function () {
            $scope.IsShowScreen1 = false;
            $scope.IsShowScreen3 = false;
            $scope.IsShowScreen2 = true;
        }

        $scope.CallShowScreen1 = function () {
            $scope.IsShowScreen1 = true;
            $scope.IsShowScreen2 = false;
            $scope.IsShowScreen3 = false;
        }
        
        $scope.ReservationRoomTypes=[];

        //-----------------------------------------------
        //Progress Bar
        //-----------------------------------------------
        $scope.ManuService = manuService;
        $scope.IsProgress = true;
        $scope.ManuService.setProgress($scope.IsProgress);
        $scope.ProgressStart = function () {
            $scope.IsProgress = true;
            $('#body').addClass("disablewholepage");
            $scope.ManuService.setProgress(true);
        }
        $scope.ProgressEnd = function () {
            //$scope.IsProgress = false;
            $('#body').removeClass("disablewholepage");
            $scope.ManuService.setProgress(false);
        }
        //-----------------------------------------------

        var selectionStart = false;
        var selectionEnd = false;
        var selectRoomId = "";
        var fromDate = ""
        var toDate = ""
        
        $scope.showModal = true;
        $scope.ToRoomDay = {};

        $scope.Model = {

            ActionName: '',
            ActionId: '',   
            BusinessDate: '',

            FromRoomId: '',

            ToRoomId: '',
            ToRoomOccupiedStatusId: '',
            ToRoomStatusTypeId: '1',
            
            FromDate: '',
            ToDate: '',

            FromCheckINId: '',
            FromCheckINDate: '',
            FromCheckOUTDate: '',
            FromCheckINGuestRoomId: '',
            ToCheckINId: '',
            ToCheckINDate: '',
            ToCheckOUTDate: '',
            ToCheckINGuestRoomId:'',

        };

        $scope.RoomStatus = {

            StatusDate: '',
            FromDate: '',
            ToDate: '',
            ToTime: '',
            RoomMasterId: '',
            RoomStatusTypeId: '1',
            OccupiedStatusId: '',

        };

        //--------------------------

        $scope.date = {
            startDate: businessDate,
            endDate: businessDate
        };
        $scope.singleDate = businessDate;
        
        function setStartDate ()
        {               
            $scope.date.startDate = businessDate;
            $scope.date.endDate = GetLocalDate(GetMomentDate(businessDate, $scope.DateFormat).add(CalendarLength, 'days'), $scope.DateFormat);
            $timeout(function () {
                $scope.getRoomType();
                $scope.changedate();
            },200);
        }
        setStartDate();

        $scope.setStartDate = function () {
            setStartDate();
        };

        $scope.changedate = function () {
            $scope.opts = {
                locale: {
                    applyClass: 'btn-green',
                    applyLabel: "Apply",
                    fromLabel: "Check-IN",
                    format: $scope.DateFormat.toUpperCase(),
                    toLabel: "Check-OUT",
                    cancelLabel: 'Cancel',
                    customRangeLabel: 'Custom range'
                },
                startDate: $scope.startdate,
                endDate: $scope.enddate,
                minDate: $scope.date.startDate,
                ranges: {
                    'Next 7 Days': [GetMomentDate(businessDate, $scope.DateFormat), GetMomentDate(businessDate, $scope.DateFormat).add(6, 'days')],
                    'Next 30 Days': [GetMomentDate(businessDate, $scope.DateFormat), GetMomentDate(businessDate, $scope.DateFormat).add(30, 'days')]
                },
                eventHandlers: {
                    'apply.daterangepicker': function (ev, picker) {
                        $scope.date = {
                            startDate: ev.model.startDate,
                            endDate: ev.model.endDate
                        };

                        $scope.GetDays();
                    },
                }
            };

            $scope.GetDays($scope.startdate, $scope.enddate);
        };
        //------------------------------------------------------------------------------------------

        $scope.Months = [];
        $scope.Month = { Id: 0, Name: '', Year: 0, IsSelected: false }

        function GetMonths() {
            
            for (var i = 0; i < 12 ; i++) {
                
                var currentDate = GetMomentDate(businessDate, $scope.DateFormat);
                var futureMonth = moment(currentDate).add(i, 'M');
                var monthNumber = futureMonth.month();
                var shortName = moment.monthsShort(monthNumber); // "Sep"
                var yearName = futureMonth.year();
                $scope.Month = { Id: monthNumber + i, Name: shortName, MonthNumber: monthNumber+1, Year: yearName, IsSelected: false }
                $scope.Months.push($scope.Month);
            }
            
        };
        GetMonths();

        $scope.Day = {};
        $scope.Days = [];

        $scope.ChangeMonth = function (month) {
            angular.forEach($scope.Months, function (item) {
                item.IsSelected = false;
            });
            month.IsSelected = !month.IsSelected;
            $scope.Days = [];
            var currentDate = moment(month.Year + "-" + month.MonthNumber + "-01", "YYYY-MM-DD");
            var futureMonth = moment(currentDate).add(1, 'M');

            if (month.MonthNumber == $scope.BusinessDate.Month) {
                currentDate = moment(month.Year + "-" + month.MonthNumber + "-" + $scope.BusinessDate.Day, "YYYY-MM-DD");
            }
            $scope.date = {
                startDate: currentDate,
                endDate: futureMonth
            };
            $scope.GetDays();
        };

        $scope.duration = 0;
        $scope.GetDays = function () {
            $scope.Reset();
            $scope.IsColMarge = false;
            $scope.ResetDayCalender();
            
            var sdate = GetMomentDate($scope.date.startDate, $scope.DateFormat);
            var edate = GetMomentDate($scope.date.endDate, $scope.DateFormat);
            $scope.duration = edate.diff(sdate, 'days');
            for (var i = 0; i < $scope.duration ; i++) {
                var futureDate = moment($scope.date.startDate).add(i, 'days');
                var day = futureDate.format('DD');
                var month = futureDate.format('MM');
                var monthName = futureDate.format('MMM');
                var year = futureDate.format('YYYY');
                
                var dayName =  futureDate.format('ddd');
                $scope.Day = { Id: i, Name: day, DayName: dayName, MonthName: monthName, MonthNumber: month, Year: year, IsSelected: false, Date: futureDate };
                $scope.Days.push($scope.Day);
                //select month
                angular.forEach($scope.Months, function (item) {
                    if (parseFloat(item.MonthNumber) == parseFloat(month))
                        item.IsSelected = true;
                });
            }
            $scope.GetRoomChart();
        };

        //--------------------------------------------
        
        $scope.RoomTypes = [];
        $scope.Rooms = [];
        $scope.RoomFeatureRooms=[];
        $scope.GetRoomType = function(){
            var promiseGet = roomChartService.GetRoomChartRoomType($scope.PropertyID);
            promiseGet.then(function (data, status) {
                $scope.RoomTypes = data.Data[0];
                $scope.Rooms = data.Data[1];
                //$scope.RoomFeatureRooms = data.Data[2];
                $scope.GetCalendar();
            },
            function (error, status) {
            });
        }
        
        $scope.GetCalendar = function(){
         
            $scope.RoomChart = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate: GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
            
            var fromDate = GetMomentDate($filter('date')($scope.RoomChart.FromDate, $scope.DateFormat), $scope.DateFormat);
            var toDate = GetMomentDate($filter('date')($scope.RoomChart.ToDate, $scope.DateFormat), $scope.DateFormat);
            var id=1;
            for (var m = moment(fromDate) ; m.isBefore(toDate) ; m.add(1, 'days')) {
                var date = m.format('YYYY')+'-'+m.format('MM')+'-'+m.format('DD');
                var day ={
                    Id : id,
                    FutureDate :date,
                    Day : m.format('DD'),
                    DayName : m.format("ddd"),
                    DayCol:m.format('DD') +'$' + m.format("ddd"),
                    Month : m.format('MM'),
                    MonthName : m.format("MMM"),
                    Year : m.format('YYYY'),
                    IsWeekEnd : m.format("ddd") == 'Sun' ? true : m.format("ddd") == 'Sat' ? true : false,
                    IsBusinessDate :GetMomentDate(date,'YYYY-MM-DD').isSame(GetMomentDate($scope.MinDate ,'YYYY-MM-DD')) ? true : false,
                };
                $scope.RoomChart.Days.push(day);
                id++;
            }
            angular.forEach($scope.RoomChart.Days,function(day,index){

                //Rooms
                var i=0;
                angular.forEach($scope.Rooms,function(room,key){
                    
                    if(!room.Days)
                    {
                        room.Days=[];
                    }
                    //AM
                    i = ++i;

                    room.Days.push({
                        Id : i,
                        DayPart : 'AM',
                        Day : day,
                        RoomStatusTypeId : '1',
                        IsSelected :false,

                    });

                    //PM
                    i = ++i;
                    room.Days.push({
                        Id : i,
                        DayPart : 'PM',
                        Day : day,
                        RoomStatusTypeId : '1',
                        IsSelected :false,

                    });
                }); 

               
            }); 
            angular.forEach($scope.RoomTypes,function(roomType){
                roomType.Rooms = $scope.Rooms.filter(x=>x.RoomTypeId == roomType.Id);
                i=0;
                angular.forEach($scope.RoomChart.Days,function(day,index){
                    if(!roomType.Availabilitys)
                    {
                        roomType.Availabilitys=[];
                    }
                    i = ++i;
                    roomType.Availabilitys.push({
                        Id : i,
                        Day : day,
                        
                        AvailabilityCount:0,
                        ManagementBlockCount:0,
                        MaintenanceBlockCount :0,
                        ReservationBlockCount:0,
                        OccupiedCount:0,
                        TotalDayReservation :0,
                        IsSelected:false,
                    });

                    roomType.IsRoomType = true;
                    roomType.IsStickyDayName = false;
                    
                }); 
            });
            $scope.RoomChart.RoomTypes = $scope.RoomTypes;
            $scope.GetRoomChartCheckINGuestRoom();
        }

        $scope.GetRoomChart = function () {
            
            $scope.GetRoomType();
            scrollPageOnTop();

        };

        $scope.GetReservationRoomType = function(){
            
            $scope.SearchModel = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate:  GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'),$scope.DateFormat) , //GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
                
            var promiseGet = roomChartService.GetRoomChartReservationRoomType($scope.SearchModel);
            promiseGet.then(function (data, status) {
                var reservationRoomTypes = data.Data;
                angular.forEach(reservationRoomTypes,function(reservationRoomType){
                    $scope.UpdateRoomChartReservation(reservationRoomType);
                });    
                    
                $scope.UpdateRoomChartAvailability();
                $timeout(function () {
                    $scope.MonthColMarge();
                    $scope.ColMarge1(); //Hide On Reservation
                    $scope.HideLoader();
                    $scope.load1($(".followMeBar"));//Hide On Reservation
                    GetDepartment();//Hide On Reservation
                    GetReason();//Hide On Reservation
                    $scope.getRoomCustom();
                    $scope.ProgressEnd();
                }, 200); // 3 seconds
            },
            function (error, status) {
            });
        }

        $scope.UpdateRoomChartReservation = function(reservationRoomType)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            
            var roomType = roomChart.RoomTypes.find(x=>x.Id ==reservationRoomType.RoomTypeId);
            
            if(reservationRoomType.RoomMasterId)
            {
                var arrivalDate = GetMomentDate($filter('date')(reservationRoomType.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(reservationRoomType.DepartureDate, $scope.DateFormat), $scope.DateFormat);
                var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat);
                var emptyRoomDays=[];
                var roomCopy={};
                angular.forEach(roomType.Rooms,function(room){
                    if(reservationRoomType.RoomMasterId == room.Id)
                    {
                        roomCopy = angular.copy(room);
                        var nights = departureDate.diff(arrivalDate, 'days');
                        var startDay=0;
                        var endDay=nights;
                        var i=0;
                        var isEmpty=true;
                        var firstDate =  moment(room.Days[0].Day.FutureDate);

                        for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                            var futureDate = ConvertDateToServerDate(m);
                                    
                            if(m.isBefore(endDate))
                            {
                                var futureDate = ConvertDateToServerDate(m);
                                    
                                if(!m.isBefore(firstDate))
                                {
                                    //skip Start Day AM
                                    if(!m.isSame(arrivalDate))
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                        //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        if(emptyRoomDays.length==0)
                                        {
                                            isEmpty=false;
                                        }
                                    }
                                    //skip Start Day PM
                                    if(!m.isSame(departureDate))
                                    {
                                        if(arrivalDate.isBefore(firstDate))
                                        {
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        else
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                    }    
                                }
                            }


                        }
                        if(isEmpty)
                        {
                            //Set ReservationStatus
                            for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                if(i==startDay)
                                {
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];
                                        //roomDay.BookingTypeId= data[10];
                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                        //currentroomstatus set bussiness 
                                    });
                                }
                                else if(i==endDay)
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                                
                                        //currentroomstatus set bussiness 

                                    });
                                }
                                else
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                    });
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =reservationRoomType.Content;
                                        var data = reservationRoomType.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.ReservationRoomTypeId = data[1];
                                        roomDay.ReservationId = data[2];
                                        roomDay.GuestName = data[4];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                        roomDay.Nights= data[9];

                                        roomDay.BookingTypeId= data[5];
                                        roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                    });
                                }

                                i++;
                            }
                        }
                    }
                });
            }
            else
            {
                var reservationRoomTypeCopy = angular.copy(reservationRoomType);                    

                var arrivalDate = GetMomentDate($filter('date')(reservationRoomTypeCopy.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(reservationRoomTypeCopy.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                var emptyRoomDays=[];
                var IsRoomSet = false;
                var roomCopy={};
                angular.forEach(roomType.Rooms,function(room){
                            
                    roomCopy = angular.copy(room);
                            
                    var test = roomCopy.Name;

                    if(reservationRoomTypeCopy.RoomTypeId)
                    {
                        if(!IsRoomSet)
                        {
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;

                            var isEmpty=true;
                                    
                            //var firstDate =  moment(room.Days[0].Day.FutureDate);
                            var firstDate = GetMomentDate($scope.date.startDate, $scope.DateFormat);
                            var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days');

                            for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                        
                                if(m.isBefore(endDate))
                                {
                                    //skip Start Day AM
                                    if(!m.isSame(arrivalDate))
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        if(emptyRoomDays.length==0)
                                        {
                                            isEmpty=false;
                                        }
                                    }

                                    //skip Start Day PM
                                    if(!m.isSame(departureDate))
                                    {
                                        var firstDate =  moment(room.Days[0].Day.FutureDate);
                                        if(arrivalDate.isBefore(firstDate))
                                        {
													
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        else
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
												
                                    }    
                                }	
                            }
                            if(isEmpty)
                            {
                                        
                                //Set ReservationStatus
                                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    if(i==startDay)
                                    {
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                        });
                                    }
                                    else if(i==endDay)
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                        });
                                    }
                                    else
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                                        });
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =reservationRoomTypeCopy.Content;
                                            var data = reservationRoomTypeCopy.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.ReservationRoomTypeId = data[1];
                                            roomDay.ReservationId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[7];
                                            roomDay.ToDateStr= data[8];
                                            roomDay.Nights= data[9];

                                            roomDay.BookingTypeId= data[10];
                                            roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                                        });
                                    }
                                    i++;
                                }
                                IsRoomSet=true;
                                //reservationRoomTypeCopy={};
                            }
                        }
                    }

                });

                if(!IsRoomSet)
                {
                            
                    var nights = departureDate.diff(arrivalDate, 'days');
                    var startDay=0;
                    var endDay=nights;
                    var i=0;
                    var isEmpty=true;
                    var max = Math.max.apply(Math,roomType.Rooms.map(function(item){return item.OrderSNo;}));

                    roomCopy.Id ='OB';
                    roomCopy.Name ='OB';
                    roomCopy.OrderSNo =max +1;
                    roomCopy.MaxPerson ='';
                    roomCopy.CurrentRoomStatus ='';
                    roomCopy.CurrentRoomStatusId ='1';
                    angular.forEach(roomCopy.Days,function(roomDay){
                        roomDay.RoomId = 'OB';
                        roomDay.Name= 'Over Booking';
                        roomDay.OccupiedStatusId='1';
                        roomDay.IsCheckOUTToday=false;
                        roomDay.Content = '';
                        roomDay.RoomStatusTypeId = '1';
                        roomDay.ReservationRoomTypeId = '';
                        roomDay.ReservationId = '';
                        roomDay.GuestName = '';
                        roomDay.FromDateStr = '';
                        roomDay.ToDateStr= '';
                        roomDay.Nights= 0;
                        roomDay.BookingTypeId= '1';
                        roomDay.CheckINGuestRoomId = '';
                        roomDay.CheckINId = '';
                    });
                          
                    //Set ReservationStatus
                    for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                        var futureDate = ConvertDateToServerDate(m);
                        if(i==startDay)
                        {
                            //PM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                            });
                        }
                        else if(i==endDay)
                        {
                            //AM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)

                            });
                        }
                        else
                        {
                            //AM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                            });
                            //PM
                            emptyRoomDays = roomCopy.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                            angular.forEach(emptyRoomDays,function(roomDay){
                                roomDay.Content =reservationRoomTypeCopy.Content;
                                var data = reservationRoomTypeCopy.Content.split('$');
                                roomDay.RoomStatusTypeId=data[0];
                                roomDay.ReservationRoomTypeId = data[1];
                                roomDay.ReservationId = data[2];
                                roomDay.GuestName = data[4];
                                roomDay.FromDateStr = data[7];
                                roomDay.ToDateStr= data[8];
                                roomDay.Nights= data[9];

                                roomDay.BookingTypeId= data[5];
                                roomDay.BookingTypeName = GetBookingTypeName(roomDay.BookingTypeId)
                            });
                        }
                        i++;

                    }
                    roomType.Rooms.push(roomCopy);
                    IsRoomSet=true;

                    reservationRoomTypeCopy={};
                }
            }
            $scope.RoomChart =roomChart;
        }

        $scope.GetRoomChartCheckINGuestRoom = function(){
            $scope.SearchModel = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate:  GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'),$scope.DateFormat) , //GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
            var promiseGet = roomChartService.GetRoomChartCheckINGuestRoom($scope.SearchModel);
            promiseGet.then(function (data, status) {
                var checkINGuestRooms = data.Data;
                angular.forEach(checkINGuestRooms,function(item){
                    $scope.UpdateRoomChartCheckINRoom(item);
                });    
                $scope.GetRoomChartRoomBlock();

            },
            function (error, status) {
            });
        }
        $scope.UpdateRoomChartCheckINRoom = function(checkINGuestRoom)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            if(checkINGuestRoom.RoomMasterId)
            {
                var roomType = roomChart.RoomTypes.find(x=>x.Id == checkINGuestRoom.RoomTypeId);
                if (roomType)
                {
                    var arrivalDate = GetMomentDate($filter('date')(checkINGuestRoom.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                    var departureDate = GetMomentDate($filter('date')(checkINGuestRoom.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                    var emptyRoomDays=[];
                    var roomCopy={};

                    angular.forEach(roomType.Rooms,function(room){
                        if(checkINGuestRoom.RoomMasterId == room.Id)
                        {
                            roomCopy = angular.copy(room);
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;
                            var isEmpty=true;
                            var firstDate =  moment(room.Days[0].Day.FutureDate);
                            var endDate =  GetMomentDate($scope.date.endDate, $scope.DateFormat);
                                
                            for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) 
                            {
                                if(m.isBefore(endDate))
                                {
                                    var futureDate = ConvertDateToServerDate(m);
                                    
                                    if(!m.isBefore(firstDate))
                                    {
                                        //skip Start Day AM
                                        if(!m.isSame(arrivalDate))
                                        {
                                            //AM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        //skip Start Day PM
                                        if(!m.isSame(departureDate))
                                        {
                                            if(arrivalDate.isBefore(firstDate))
                                            {
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                if(emptyRoomDays.length==0)
                                                {
                                                    isEmpty=false;
                                                }
                                            }
                                            else
                                            {
                                                //PM
                                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                                if(emptyRoomDays.length==0)
                                                {
                                                    isEmpty=false;
                                                }
                                            }
                                        }    
                                    }
                                }
                            }
                            if(isEmpty)
                            {
                                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    if(i==startDay)
                                    {
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];

                                            //if(roomDay.RoomStatusTypeId == '4') //ManagementBlock
                                            //else if(roomDay.RoomStatusTypeId == '5')    //MaintenanceBlock
                                            //else if(roomDay.RoomStatusTypeId == '6')    //ReservationBlock
                                            //else if(roomDay.RoomStatusTypeId == '7')    //CheckIN
                                            //else if(roomDay.RoomStatusTypeId == '8')    //CheckOUT
                                            //else if(roomDay.RoomStatusTypeId == '10')   //Reservation RoomType
                                               
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];

                                        });
                                    }
                                    else if(i==endDay)
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];

                                        });
                                    }
                                    else
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];
                                        });
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.GuestName = data[4];
                                            roomDay.FromDateStr = data[5];
                                            roomDay.ToDateStr= data[6];
                                            roomDay.Nights= data[7];
                                        });
                                    }
                                    i++;
                                }
                            }
                        }
                    });
                }
            }
           
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartCheckINGuestRoomDelete = function(checkINGuestRoomId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        if(roomDay.CheckINGuestRoomId  == checkINGuestRoomId)
                        {       
                            roomDay.RoomStatusTypeId='1';
                            roomDay.CheckINGuestRoomId = '';
                            roomDay.CheckINId  = '';
                            roomDay.IsCheckOUTToday  = '';
                            roomDay.Content = '';
                        }
                    });
                });
            });
            $scope.RoomChart =roomChart;
        }

        $scope.UpdateRoomChartReservationRoomTypeDelete = function(reservationRoomTypeId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        
                        if(roomDay.ReservationRoomTypeId  == reservationRoomTypeId)
                        {   
                            roomDay.RoomStatusTypeId='1';
                            roomDay.ReservationRoomTypeId = '';
                            roomDay.ReservationId = '';
                            roomDay.GuestName = '';
                            roomDay.FromDateStr = '';
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                            roomDay.BookingTypeId= '1';
                        }
                    });
                });
            });
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartReservationDelete = function(reservationId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        
                        if(roomDay.ReservationId  == reservationId)
                        {   
                            roomDay.RoomStatusTypeId='1';
                            roomDay.ReservationRoomTypeId = '';
                            roomDay.ReservationId = '';
                            roomDay.GuestName = '';
                            roomDay.FromDateStr = '';
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                            roomDay.BookingTypeId= '1';
                        }
                    });
                });
            });

            $scope.UpdateRoomChartAvailability();
            $timeout(function () {
                $scope.MonthColMarge();
                $scope.ColMarge1();
                $scope.HideLoader();
                $scope.load1($(".followMeBar"));
            }, 200); // 3 seconds

            $scope.RoomChart =roomChart;
        }
        $scope.GetRoomChartRoomBlock = function(){
            
            $scope.SearchModel = {
                PropertyID: $scope.PropertyID,
                FromDate: GetServerDate( $scope.date.startDate, $scope.DateFormat),
                ToDate:  GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'),$scope.DateFormat) , //GetServerDate($scope.date.endDate, $scope.DateFormat),
                BusinessDate: businessDate,
                RoomTypes:[],
                Days:[],
            };
                
            var promiseGet = roomChartService.GetRoomChartRoomBlock($scope.SearchModel);
            promiseGet.then(function (data, status) {
                var roomBlocks = data.Data;
                angular.forEach(roomBlocks,function(item){
                    $scope.UpdateRoomChartRoomBlock(item);
                });    
                $scope.GetReservationRoomType();

            },
            function (error, status) {
            });
        }
        $scope.UpdateRoomChartRoomBlock = function(roomBlock)
        {
            $scope.UpdateRoomChartRoomBlockDelete(roomBlock.Content.split('$')[1]);
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            
            var roomType = roomChart.RoomTypes.find(x=>x.Id == roomBlock.RoomTypeId);
            if(roomType)
            {
                var arrivalDate = GetMomentDate($filter('date')(roomBlock.ArrivalDate, $scope.DateFormat), $scope.DateFormat);
                var departureDate = GetMomentDate($filter('date')(roomBlock.DepartureDate, $scope.DateFormat), $scope.DateFormat);

                var emptyRoomDays=[];
                var roomCopy={};

                angular.forEach(roomType.Rooms,function(room){
                    if(roomBlock.RoomMasterId == room.Id)
                    {
                        roomCopy = angular.copy(room);
                        var nights = departureDate.diff(arrivalDate, 'days');
                        var startDay=0;
                        var endDay=nights;
                        var i=0;
                        var isEmpty=true;
                        var firstDate =  moment(room.Days[0].Day.FutureDate);
                        var endDate = GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days');

                        for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                            var futureDate = ConvertDateToServerDate(m);
                                    

                            if(m.isBefore(endDate))
                            {
                                var futureDate = ConvertDateToServerDate(m);
                                    
                                if(!m.isBefore(firstDate))
                                {
                                    //skip Start Day AM
                                    if(!m.isSame(arrivalDate))
                                    {
                                        //AM
                                            
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                        //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                        if(emptyRoomDays.length==0)
                                        {
                                            isEmpty=false;
                                        }
                                    }
                                    //skip Start Day PM
                                    if(!m.isSame(departureDate))
                                    {
                                        if(arrivalDate.isBefore(firstDate))
                                        {
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '10'  ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == ConvertDateToServerDate(firstDate) && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                        else
                                        {
                                            //PM
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6'  || x.RoomStatusTypeId == '10' ));
                                            //emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' || x.RoomStatusTypeId == '6' ));
                                            if(emptyRoomDays.length==0)
                                            {
                                                isEmpty=false;
                                            }
                                        }
                                    }    
                                }
                            }

                        }
                        if(isEmpty)
                        {
                                
                            //Set ReservationStatus
                            for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                if(i==startDay)
                                {
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                }
                                else if(i==endDay)
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                }
                                else
                                {
                                    //AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    angular.forEach(emptyRoomDays,function(roomDay){
                                        roomDay.Content =roomBlock.Content;
                                        var data = roomBlock.Content.split('$');
                                        roomDay.RoomStatusTypeId=data[0];
                                        roomDay.RoomBlockId=data[1];
                                        roomDay.FromDateStr = data[7];
                                        roomDay.ToDateStr= data[8];
                                    });
                                }
                                i++;
                            }
                        }
                    }
                });
            }
            $scope.RoomChart =roomChart;
        }
        $scope.UpdateRoomChartRoomBlockDelete = function(roomBlockId)
        {
            
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        if(roomDay.RoomBlockId  == roomBlockId)
                        {   
                            roomDay.RoomStatusTypeId='1';
                            roomDay.RoomBlock = null;
                            roomDay.RoomBlockId = '';
                            roomDay.FromDateStr = '';
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                        }
                    });
                });
            });
            $scope.RoomChart =roomChart;
        }
        function GetBookingTypeName(bookingTypeId){
            
            try{
                if (bookingTypeId == "2")
                {
                    return  "Travel Agent";
                }else if (bookingTypeId == "3")
                {
                    return "Group";
                }else if (bookingTypeId == "4")
                {
                    return "Booking Engine";
                }else if (bookingTypeId == "5")
                {
                    return "Channel Manager";
                }
                else
                {
                    return "Individual";
                }  
            }
            catch(ex)
            {return "";}
        }
        $scope.GetDistinctRoomType = function (list) {
            var distinct = [];
            var newArr = list.filter(function (el) {
                if (distinct.indexOf(el.RoomTypeId) === -1) {
                    // If not present in array, then add it
                    distinct.push(el.RoomTypeId);
                    return true;
                }
                else {
                    // Already present in array, don't add it
                    return false;
                }
            });
            return distinct;
        };
        $scope.GetAvailableRoom = function(ArrivalDate,DepartureDate,roomType)
        {   
            if(roomType)
            {
                var a = GetMomentDate(ArrivalDate, $scope.DateFormat);
                var b = GetMomentDate(DepartureDate, $scope.DateFormat);
                var myRoom = {};
                roomType.AvailableRooms =[];
                angular.forEach(roomType.Rooms, function (room) {
                    var IsAdd = true;
                    myRoom = room;
                    for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                        angular.forEach(room.Days, function (roomDay) {
                            var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                            if (futureDate.isSame(m)) {
                                if(roomDay.DayPart=='PM')
                                {
                                    if (IsAdd)
                                    {
                                        if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
                                            IsAdd = false;
                                        }
                                        else if((roomDay.RoomStatusTypeId == '10'))
                                        {
                                            //SKIP 
                                            IsAdd = false;
                                        }
                                        else {
                                            if ((roomDay.RoomStatusTypeId != '1') && !roomDay.IsCheckOUTToday) {    // || roomDay.RoomStatusTypeId != '10'
                                                IsAdd = false;
                                            }
                                        }
                                    }
                                    angular.forEach(roomType.Availabilitys  ,function(ava){
                                        var futureDate2 = GetMomentDate($filter('date')(ava.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                                        if (futureDate.isSame(futureDate2)) {
                                            if (ava.TotalRemainingCount<=0) {
                                                IsAdd = false;
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    }
                    if (IsAdd) {
                        if(myRoom.Name != 'OB')
                        {
                            //RoomType
                            for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                                angular.forEach(roomType.Availabilitys  ,function(ava){
                                    var futureDate = GetMomentDate($filter('date')(ava.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                                    if (futureDate.isSame(m)) {
                                        ava.TotalRemainingCount = ava.TotalRemainingCount-1;
                                    }
                                });
                            }
                            
                            roomType.AvailableRooms.push({ Id: myRoom.Id, Name: myRoom.Name ,MaxPerson:myRoom.MaxPerson,OrderSNo:myRoom.OrderSNo, RoomStatusTypeId:myRoom.CurrentRoomStatusId  });
                        }
                    }
                });
            }
        } 
        $scope.UpdateRoomChartAvailability = function()
        {
            
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
               
            var arrivalDate = GetMomentDate($filter('date')(roomChart.FromDate, $scope.DateFormat), $scope.DateFormat);
            var departureDate = GetMomentDate($filter('date')(roomChart.ToDate, $scope.DateFormat), $scope.DateFormat);

            angular.forEach(roomChart.RoomTypes,function(roomType)  {

                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                    var futureDate = ConvertDateToServerDate(m);
                    var roomtypes = $scope.RoomTypes.filter(x=>x.Id == roomType.Id);
                    roomType.OverBooking = roomtypes[0].OverBooking;

                    var availability = roomType.Availabilitys.filter(x=>x.Day.FutureDate == futureDate );
                    if(availability[0])
                    {
                        var occupiedRooms=[];
                        var list = roomType.Rooms.filter(
                                function(room)
                                {
                                    var roomDay = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '4' || x.RoomStatusTypeId == '5' || x.RoomStatusTypeId == '6' || x.RoomStatusTypeId == '7'|| x.RoomStatusTypeId == '10'));
                                    angular.forEach(roomDay,function(item){
                                        occupiedRooms.push(item);
                                    });
                                    return occupiedRooms;
                                }
                            );
                        
                        availability[0].RoomCount = roomType.Rooms.filter(x=>x.Id!='OB').length;
                        availability[0].OccupiedCount = occupiedRooms.length;
                        availability[0].AvailabilityCount = availability[0].RoomCount - (availability[0].OccupiedCount);
                        var OBRooms = (availability[0].RoomCount) * (roomType.OverBooking/100);
                        OBRooms = parseInt(OBRooms);
                        availability[0].TotalRemainingCount = availability[0].RoomCount + OBRooms - availability[0].OccupiedCount;
                    }

                    angular.forEach(roomType.Rooms,function(room){
                        angular.forEach(room.Days,function(roomday){
                            
                            //var availability = roomType.Availabilitys.filter(x=>x.RoomTypeId == roomType.Id && x.Day==roomday.Day && x.Month==roomday.Month && x.Year==roomday.Year);
                            var availability = roomType.Availabilitys.filter(x=> x.Day.Day==roomday.Day.Day && x.Day.Month==roomday.Day.Month && x.Day.Year==roomday.Day.Year);
                            roomday.AvailabilityCount = availability[0].AvailabilityCount;
                            roomday.DayCol = roomday.Day.Day + '$'+ roomday.Day.DayName + '$'+ availability[0].AvailabilityCount;
                        });
                    });
                }
            });

            $scope.RoomChart =roomChart;
        }

        $scope.IsHideReservation=false;
        $scope.HideReservation =function(fromRoomDay){
            if(fromRoomDay.ReservationRoomTypeId)
            {
                $scope.ProgressStart();
                $scope.IsHideReservation=true;
                $scope.UpdateRoomChartReservationRoomTypeDelete(fromRoomDay.ReservationRoomTypeId);
                $timeout(function () {
                    $scope.MonthColMarge();
                    $scope.ColMarge1(); //Hide On Reservation
                    $scope.HideLoader();
                    $scope.load1($(".followMeBar"));//Hide On Reservation
                    $scope.ProgressEnd();
                }, 10); // 3 seconds
            }
        }
        //--------------------------------------------
        var first;
        var prev = undefined;
        var prevRoomId = undefined;
        var CalendarLength = 30; //days
        var colspan = 1;
        var cellWidth =18;
        var setColspan = function () {
            //first.attr('colspan',colspan);
            first.attr('colspan','' + parseInt(colspan,10)+ '');
            colspan = 1;
        }

        $scope.IsColMarge = false;

        $scope.ColMarge1 = function () {
            
            var fromDate= GetMomentDate( $scope.date.startDate, $scope.DateFormat);
            var toDate= GetMomentDate( $scope.date.endDate, $scope.DateFormat).add(-1, 'days');;

            $scope.IsColMarge = true;
            var index = 0;

            //.reservationBlock
            index = 0;
            colspan = 1;
            var all = $('.reservationBlock');
            all.each(function (key,value) {

                

                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[7] +'-'+ txt.split('$')[8] + ' Pax : ' + txt.split('$')[6] + "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                
                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[7],'dd-MMM-yyyy');
                var d = GetMomentDate(txt.split('$')[8],'dd-MMM-yyyy')
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    if(d.isAfter(toDate))
                    {

                        nights = toDate.diff(a, 'days');
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                    else
                    {
                        nights = d.diff(a, 'days');
                        width = (2*cellWidth) * parseInt( nights);
                    }
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                
                htmltxt = "<div class='reservationBlock' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);

                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });

            //reservationRoomTypeBlock
            index = 0;
            colspan = 1;
            var all = $('.reservationRoomTypeBlock');
            all.each(function (key,value) {
                   
                var txt = $(this).text();
                var type = txt.split('$')[0];
                type = type.replace(/ /g,'');
                type = type.replace(/(\r\n\t|\n|\r\t)/gm,"");
                
                if (type=='10')
                {
                    index++;
                    var htmltxt = '';
                    if (txt.includes("$")) {
                        htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[7] +'-'+ txt.split('$')[8] + ' Pax : ' + txt.split('$')[6] + "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                    }
                    else {
                        htmltxt = txt;
                    }
                
                    var nights=0;
                    var width=0;
                    var a = GetMomentDate(txt.split('$')[7],'dd-MMM-yyyy');
                    var d = GetMomentDate(txt.split('$')[8],'dd-MMM-yyyy')
                    if(a.isBefore(fromDate))
                    {
                        nights = d.diff(fromDate, 'days');
                        width = (2*cellWidth) * parseInt( nights) + cellWidth;
                    }
                    else
                    {
                        if(d.isAfter(toDate))
                        {
                            nights = toDate.diff(a, 'days');
                            width = (2*cellWidth) * parseInt( nights)+cellWidth;
                        }
                        else
                        {
                            nights = d.diff(a, 'days');
                            width = (2*cellWidth) * parseInt( nights);
                        }
                        if(nights>CalendarLength)
                        {
                            nights=CalendarLength;
                            width = (2*cellWidth) * parseInt( nights)+cellWidth;
                        }
                    }
                                    
                    htmltxt = "<div class='reservationRoomTypeBlock' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                    
                    $(this).html(htmltxt);
                    if (prev === htmltxt) {
                        colspan += 1;
                        $(this).html('');
                    } else {
                        if (colspan > 1) {
                        }
                        first = $(this);
                        prev = htmltxt;
                    }
                }
                
            });

            //reservationRoomTypeBlockBookingEngine
            index = 0;
            colspan = 1;
            var all = $('.reservationRoomTypeBlockBookingEngine');
            all.each(function (key,value) {
                var txt = $(this).text();
                if (txt.includes("$")) {
                    index++;
                    var htmltxt = '';
                    if (txt.includes("$")) {
                        htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[7] +'-'+ txt.split('$')[8] + ' Pax : ' + txt.split('$')[6] + "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                    }
                    else {
                        htmltxt = txt;
                    }
                
                    var nights=0;
                    var width=0;
                    var a = GetMomentDate(txt.split('$')[7],'dd-MMM-yyyy');
                    var d = GetMomentDate(txt.split('$')[8],'dd-MMM-yyyy')
                    if(a.isBefore(fromDate))
                    {
                        nights = d.diff(fromDate, 'days');
                        width = (2*cellWidth) * parseInt( nights) + cellWidth;
                    }
                    else
                    {
                        if(d.isAfter(toDate))
                        {
                            nights = toDate.diff(a, 'days');
                            width = (2*cellWidth) * parseInt( nights)+cellWidth;
                        }
                        else
                        {
                            nights = d.diff(a, 'days');
                            width = (2*cellWidth) * parseInt( nights);
                        }
                        if(nights>CalendarLength)
                        {
                            nights=CalendarLength;
                            width = (2*cellWidth) * parseInt( nights)+cellWidth;
                        }

                    }
                                   
                    htmltxt = "<div class='reservationRoomTypeBlockBookingEngine' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                    $(this).html(htmltxt);
                    if (prev === htmltxt) {
                        colspan += 1;
                        $(this).html('');
                    } else {
                        if (colspan > 1) {
                        }
                        first = $(this);
                        prev = htmltxt;
                    }
                }

            });

            //reservationRoomTypeBlockChannelManager
            index = 0;
            colspan = 1;
            var all = $('.reservationRoomTypeBlockChannelManager');
            all.each(function (key,value) {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[7] +'-'+ txt.split('$')[8] + ' Pax : ' + txt.split('$')[6] + "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }

                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[7],'dd-MMM-yyyy');
                var d = GetMomentDate(txt.split('$')[8],'dd-MMM-yyyy')
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    if(d.isAfter(toDate))
                    {
                        
                        nights = toDate.diff(a, 'days');
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                    else
                    {
                        nights = d.diff(a, 'days');
                        width = (2*cellWidth) * parseInt( nights);
                    }
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                var id = 'C'+ (txt.split('$')[1]).split('-')[0];
                                
                
                var id = 'C'+ (txt.split('$')[1]).split('-')[0];
				
                htmltxt = "<div id='" + id +"' class='reservationRoomTypeBlockChannelManager' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            
            //management
            index = 0;
            colspan = 1;
            var all = $('.management');
            all.each(function (key,value) {
                
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[2]  + '<br/>' + txt.split('$')[4] + ' - ' + txt.split('$')[5]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                
                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[4],'dd-MMM-yyyy');
                var d = GetMomentDate(txt.split('$')[5],'dd-MMM-yyyy');
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    nights = d.diff(a, 'days');
                    width = (2*cellWidth) * parseInt( nights);
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                
                htmltxt = "<div class='management' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
            
            //maintenance
            index = 0;
            colspan = 1;
            var all = $('.maintenance');
            all.each(function (key,value) {
                var txt = $(this).text();
                
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    htmltxt = txt.split('$')[2]  + '<br/>' + txt.split('$')[4] + ' - ' + txt.split('$')[5]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                
                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[4],'dd-MMM-yyyy');
                var d = GetMomentDate(txt.split('$')[5],'dd-MMM-yyyy');
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    nights = d.diff(a, 'days');
                    width = (2*cellWidth) * parseInt( nights);
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                
                htmltxt = "<div class='maintenance' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });

            //todayCheckOUT
            index = 0;
            colspan = 1;
            var all = $('.todayCheckOUT');
            all.each(function (key,value) {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    var htmltxt = txt.split('$')[1] + '<br/>' + txt.split('$')[2];
                }
                else {
                    htmltxt = txt;
                }
                
                var nights = txt.split('$')[9];
                var width = (2*cellWidth) * parseInt( nights);
                var id = 'R'+ (txt.split('$')[1]).split('-')[0];
                
                htmltxt = "<div id='" + id +"' class='todayCheckOUT' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });

            //occupied
            index = 0;
            colspan = 1;
            var all = $('.occupied');
            all.each(function (key,value) {
                
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    var htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[5] + '-' + txt.split('$')[6]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                
                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[5],'dd-MMM-yyyy');
                var d = GetMomentDate(txt.split('$')[6],'dd-MMM-yyyy');
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    nights = d.diff(a, 'days');
                    width = (2*cellWidth) * parseInt( nights);
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                
                htmltxt = "<div class='occupied' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });

            //checkout
            index = 0;
            colspan = 1;
            var all = $('.checkout');
            all.each(function (key,value) {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    var htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[5] + '-' + txt.split('$')[6]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                
                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[5],'dd-MMM-yyyy');
                var d = GetMomentDate(txt.split('$')[6],'dd-MMM-yyyy');
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    nights = d.diff(a, 'days');
                    width = (2*cellWidth) * parseInt( nights);
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                
                htmltxt = "<div class='checkout' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });

            //Transferred
            index = 0;
            colspan = 1;
            var all = $('.transfer');
            all.each(function (key,value) {
                var txt = $(this).text();
                index++;
                var htmltxt = '';
                if (txt.includes("$")) {
                    var htmltxt = txt.split('$')[4] + '<br/>' + txt.split('$')[5] + '-' + txt.split('$')[6]+ "<div style='display:none;'>" + txt.split('$')[1] + '</div>';
                }
                else {
                    htmltxt = txt;
                }
                
                var nights=0;
                var width=0;
                var a = GetMomentDate(txt.split('$')[5],'dd-MMMM-yyyy');
                var d = GetMomentDate(txt.split('$')[6],'dd-MMMM-yyyy');
                if(a.isBefore(fromDate))
                {
                    nights = d.diff(fromDate, 'days');
                    width = (2*cellWidth) * parseInt( nights) + cellWidth;
                }
                else
                {
                    nights = d.diff(a, 'days');
                    width = (2*cellWidth) * parseInt( nights);
                    if(nights>CalendarLength)
                    {
                        nights=CalendarLength;
                        width = (2*cellWidth) * parseInt( nights)+cellWidth;
                    }
                }
                
                htmltxt = "<div class='transfer' style='overflow: hidden;text-overflow: ellipsis; border:1px solid white;position: absolute;width: "+(width+1)+"px;height: 30px;margin-top: -15px;margin-left: -2px;padding: 3px;text-align: center;'>" + htmltxt + '</div>';
                $(this).html(htmltxt);
                if (prev === htmltxt) {
                    colspan += 1;
                    $(this).html('');
                } else {
                    if (colspan > 1) {
                    }
                    first = $(this);
                    prev = htmltxt;
                }
            });
        }

        $scope.SelectedRoomType = {};

        var firstMonth;
        var prevMonth = undefined;
        var colspanMonth = 1;
        $scope.Reset = function () {
            $scope.CancellationRemark="";
            $scope.ReasonId="";
            var firstMonth;
            var prevMonth = undefined;
            var colspanMonth = 1;
        };
        var setMonthColspan = function () {
            firstMonth.attr('colspan', colspanMonth);
            colspanMonth = 1;
        }

        $scope.MonthColMarge = function () {     
            var allMonth = $('.monthHead');
            allMonth.each(function () {
                var txt = $(this).text();
                if (prevMonth === txt) {
                    colspanMonth += 1;
                    $(this).remove();
                } else {
                    // doesnt match, set colspan on first and reset colspan counter
                    if (colspanMonth > 1) {
                        setMonthColspan();
                    }
                    firstMonth = $(this);
                    prevMonth = txt;
                }
            });
            if (colspanMonth > 1) {
                setMonthColspan();
            }
        };
        //--------------------------------------------
        
        $scope.ResetDayCalender = function () {
            angular.forEach($scope.Months, function (item) {
                item.IsSelected = false;
            });
            $scope.Days = [];
        };
        $scope.ResetSelection = function () {
            angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                angular.forEach(roomType.Rooms, function (room) {
                    angular.forEach(room.Days, function (day) {
                        day.IsSelected = false;
                    });
                });
            });
        };

        $scope.OpenRoomStatusBox = function (room) {
            
            $scope.Model.FromRoomDay =
            {
                RoomTypeId : room.RoomTypeId,
                RoomId : room.Id,
                
                Name : room.Name,

                FromDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                ToDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                RoomStatusTypeId :room.CurrentRoomStatusId,                
                FutureDate : $scope.businessDate,
                IsBusinessDate :true,
            };

            $scope.Model.FromRoomMasterId = room.Id;
            $scope.Model.FromRoomMasterName = room.Name;
            $scope.Model.FromRoomTypeId = room.RoomTypeId;
            $scope.Model.FromRoomTypeName = room.RoomTypeName;

            //var roomType = $scope.RoomTypes.find(x=>x.Id = room.RoomTypeId);
            var roomStatus = {
                StatusDate: $scope.MinDate,
                FromDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                ToDate: $filter('date')($scope.businessDate, $scope.DateFormat),
                ToTime: '',
                RoomMasterId: room.Id,
                RoomStatusTypeId: room.CurrentRoomStatusId,
                RoomNumber: room.Name,
                RoomTypeId: room.RoomTypeId,
                RoomTypeName: room.RoomTypeName,
                EmployeeName: $scope.ModifiedBy,
                
            };

            $scope.Model.FromRoomDay.RoomStatus = roomStatus;
            $scope.OpenModel('cleanModel');

        }
        //Mouse Event

        // Initialization
        $scope.onFirstBtnClickResult = "";
        $scope.secondBtnInput = "";
        $scope.onDblClickResult = "";
        $scope.onMouseDownResult = "";
        $scope.onMouseUpResult = "";
        $scope.onMouseEnterResult = "";
        $scope.onMouseLeaveResult = "";
        $scope.onMouseMoveResult = "";
        $scope.onMouseOverResult = "";

        $scope.Nights =0;
        // Utility functions

        // Accepts a MouseEvent as input and returns the x and y
        // coordinates relative to the target element.
        var getCrossBrowserElementCoords = function (mouseEvent) {
            var result = {
                x: 0,
                y: 0
            };

            if (!mouseEvent) {
                mouseEvent = window.event;
            }

            if (mouseEvent.pageX || mouseEvent.pageY) {
                result.x = mouseEvent.pageX;
                result.y = mouseEvent.pageY;
            }
            else if (mouseEvent.clientX || mouseEvent.clientY) {
                result.x = mouseEvent.clientX + document.body.scrollLeft +
                  document.documentElement.scrollLeft;
                result.y = mouseEvent.clientY + document.body.scrollTop +
                  document.documentElement.scrollTop;
            }

            if (mouseEvent.target) {
                var offEl = mouseEvent.target;
                var offX = 0;
                var offY = 0;

                if (typeof (offEl.offsetParent) != "undefined") {
                    while (offEl) {
                        offX += offEl.offsetLeft;
                        offY += offEl.offsetTop;

                        offEl = offEl.offsetParent;
                    }
                }
                else {
                    offX = offEl.x;
                    offY = offEl.y;
                }

                result.x -= offX;
                result.y -= offY;
            }

            return result;
        };

        var getMouseEventResult = function (mouseEvent, mouseEventDesc) {
            var coords = getCrossBrowserElementCoords(mouseEvent);
            return mouseEventDesc + " at (" + coords.x + ", " + coords.y + ")";
        };

        $scope.onMouseDown = function ($event) {
            $scope.onMouseDownResult = getMouseEventResult($event, "Mouse down");
        };
        $scope.onMouseDown = function (selectedRoom, roomDay, $event) {
            
            $scope.SelectedRoomLinkRooms=[];
            roomDay.IsCheckIN = false;
            roomDay.CurrentRoomStatusId = selectedRoom.CurrentRoomStatusId;
            var checkins = selectedRoom.Days.filter(x=>x.Day.Day==roomDay.Day.Day && x.Day.Month==roomDay.Day.Month && x.Day.Year==roomDay.Day.Year && x.RoomStatusTypeId=='7' && roomDay.Day.IsBusinessDate);
            if(checkins.length>0)
            {
                roomDay.IsCheckIN = true;
            }

            var a = GetMomentDate(businessDate, $scope.DateFormat);
            var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
            if (futureDate.isBefore(a)) {
                return;
            }

            $scope.IsMouseDown = true;
            $scope.onMouseDownResult = getMouseEventResult($event, "Mouse down");
            
            $scope.ResetSelection();
            if (roomDay.DayPart == "PM")
            {
                selectionStart = true;
            }
            
            $scope.Model = {
                BusinessDate: businessDate,
                FromRoomDay:roomDay,
                //ToRoomDay:roomDay,
                FromRoomTypeId: selectedRoom.RoomTypeId,
                FromRoomTypeName: selectedRoom.RoomTypeName,
                FromRoomMasterId: selectedRoom.Id,
                FromRoomMasterName: selectedRoom.Name,
            };
            $scope.Nights=0;

        };
        $scope.onMouseUp = function ($event) {
            $scope.onMouseUpResult = getMouseEventResult($event, "Mouse up");
        };
        $scope.onMouseUp = function (selectedRoom, roomDay, $event) {
            if(!roomDay)
            {
                return;
            }
            
            if(roomDay.RoomId=='OB')
            {
                if($scope.Model.FromRoomDay.RoomStatusTypeId=='6' || $scope.Model.FromRoomDay.RoomStatusTypeId=='10')
                {
                    $scope.OpenModel('actionReservationModel');
                }
                else
                {
                    $scope.Model = {
                        FromRoomDay:{RoomStatusTypeId :'1', },
                        FromRoomTypeId: selectedRoom.RoomTypeId,
                        FromRoomTypeName: selectedRoom.RoomTypeName,
                        FromRoomMasterId: selectedRoom.Id,
                        FromRoomMasterName: selectedRoom.Name,

                    };
                    $scope.ResetSelection();              
                }
                
                return;
            }
            var a = GetMomentDate(businessDate, $scope.DateFormat);
            var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
            if (futureDate.isBefore(a)) {
                return;
            }
            $scope.onMouseUpResult = getMouseEventResult($event, "Mouse up");
            if(!$scope.Model.ToRoomDay)
            {
                $scope.Model.ToRoomDay= roomDay;
                $scope.Model.ToRoomMasterId= selectedRoom.Id;
                $scope.Model.ToRoomName= selectedRoom.Name;
                $scope.Model.ToRoomTypeId= selectedRoom.RoomTypeId;
            }
            var days = GetDays($scope.Model.FromRoomDay.Day.FutureDate,roomDay.Day.FutureDate, 'YYYY-MM-DD');
            if($scope.Model.ToRoomDay)
            {
                $scope.Model.Nights = days.length-1;

                if (days.length <= 1 && $scope.Model.FromRoomDay.RoomStatusTypeId=='1' && $scope.Model.ToRoomDay.RoomStatusTypeId=='1')
                {
                    $scope.Model = {
                
                        FromRoomDay:{RoomStatusTypeId :'1' },
                        FromRoomTypeId: selectedRoom.RoomTypeId, 
                        FromRoomMasterId: selectedRoom.Id,
                        FromRoomTypeName: selectedRoom.RoomTypeName,
                        FromRoomMasterName: selectedRoom.Name,
                    };
                    $scope.ResetSelection();
                    scrollPageOnTop();
                    return;
                }
            }
            else
            {
                return;
            }
            
            if ($scope.Model.FromRoomDay.RoomStatusTypeId=='1' && $scope.Model.ToRoomDay.RoomStatusTypeId=='1') {
                $scope.Model.FromRoomDay.DayPart == 'PM'
                if($scope.IsMouseDown)  //Drag
                {
                    if ($scope.IsReservationActive)
                    {
                        $scope.OpenModel('reservationModel');
                    }
                    else
                    {
                        $scope.OpenModel('actionConfirmationModel');
                    }
                }
            }
            else if($scope.Model.FromRoomDay.RoomStatusTypeId=='4')
            {
                $scope.OpenModel('managementBlockModel');
            }
            else if($scope.Model.FromRoomDay.RoomStatusTypeId=='5')
            {
                $scope.OpenModel('maintenanceBlockModel');
            } 
            else if($scope.Model.FromRoomDay.RoomStatusTypeId=='6' || $scope.Model.FromRoomDay.RoomStatusTypeId=='10')
            {
                $scope.Model.ToRoomDay= roomDay;
                $scope.OpenModel('actionReservationModel');
            }
            else if($scope.Model.FromRoomDay.RoomStatusTypeId=='7')
            {
                
                $scope.Model.ToRoomDay= roomDay;
                CheckINAction();
            }
            else if($scope.Model.FromRoomDay.RoomStatusTypeId=='8')
            {
            }

            $scope.IsMouseDown=false;
            $scope.Nights=0;
        };
        $scope.onMouseEnter = function ($event) {
            $scope.onMouseEnterResult = getMouseEventResult($event, "Mouse enter");
        };
        $scope.onMouseLeave = function ($event) {
            $scope.onMouseLeaveResult = getMouseEventResult($event, "Mouse leave");
        };
        $scope.onMouseOver = function (selectedRoom, roomDay, $event) {
            if(!roomDay)
            {
                return;
            }
            roomDay.Name = selectedRoom.Name;

            $scope.LinkRoomModel = {SelectedRoomLinkRooms:[]};
            $scope.SelectedRoomLinkRooms=[];
            
            var screenwidth = $('body').width();
            var screenheight = $('body').height();
            var mouseOverBoxHeight = 300;// $('#MouseOverBox').height();

            var left = $event.pageX - $event.offsetX;
            if (screenwidth < left + 350) {
                left = screenwidth - 350;
            }
            var top = $event.pageY - $event.offsetY - 60
            
            roomDay.Left = left;
            roomDay.Top = top;
            
            $scope.onMouseOverResult = getMouseEventResult($event, "Mouse over");
            if (roomDay.RoomStatusTypeId == '4') //Mana and Maint
            {
                $scope.ResetSelection();
                var contents =roomDay.Content.split('$');
                
                if(!roomDay.RoomBlock)
                {
                    var promiseGet = roomChartService.getRoomBlockById(contents[1]);
                    promiseGet.then(function (data) {
                        
                        roomDay.RoomBlock   =   data.Data;
                        roomDay.RoomBlock.FromDate    =   $filter('date')(data.Data.FromDate, $scope.DateFormat);
                        roomDay.RoomBlock.ToDate      =   $filter('date')(data.Data.ToDate, $scope.DateFormat);
                        roomDay.FromDateToDisplay     = data.Data.FromDate;
                        roomDay.ToDateToDisplay       = data.Data.ToDate;
                        
                        BindModel(roomDay);
                    },
                    function (data) {
                        parent.failureMessage(data.message);
                        scrollPageOnTop();
                    });
                }
                else
                {
                    //Bind From Model
                    BindModel(roomDay);
                }
            }
            else if (roomDay.RoomStatusTypeId == '5') //Mana and Maint
            {
                $scope.ResetSelection();
                var contents =roomDay.Content.split('$');

                if(!roomDay.RoomBlock)
                {
                    var promiseGet = roomChartService.getRoomBlockById(contents[1]);
                    promiseGet.then(function (data) {

                        
                        roomDay.RoomBlock   =   data.Data;
                        roomDay.RoomBlock.FromDate    =   $filter('date')(data.Data.FromDate, $scope.DateFormat);
                        roomDay.RoomBlock.ToDate      =   $filter('date')(data.Data.ToDate, $scope.DateFormat);
                        roomDay.FromDateToDisplay     = data.Data.FromDate;
                        roomDay.ToDateToDisplay       = data.Data.ToDate;
                       
                        //Bind From Model
                        BindModel(roomDay);
                    },
                    function (data) {
                        parent.failureMessage(data.message);
                        scrollPageOnTop();
                    });
                }
                else
                {
                    //Bind From Model
                    BindModel(roomDay);
                }
            }else if (roomDay.RoomStatusTypeId == '6' || roomDay.RoomStatusTypeId == '10') { 
                //}else if (roomDay.RoomStatusTypeId == '6') { 
 
                $scope.ResetSelection();
                
                if(!roomDay.Reservation)
                {
                    var promiseGet = roomChartService.getReservationByRoomTypeId(roomDay.ReservationRoomTypeId);
                    promiseGet.then(function (data) {
                        
                        roomDay.Reservation = data.Data;
                        roomDay.ReservationRoomType = roomDay.Reservation.ReservationRoomTypes.find(x=>x.Id==roomDay.ReservationRoomTypeId);
                        //Bind From Model
                        BindModel(roomDay);
                    },
                    function (data) {
                        parent.failureMessage(data.message);
                        scrollPageOnTop();
                    });
                }
                else
                {
                    //Bind From Model
                    BindModel(roomDay);
                }
            }else if (roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8'|| roomDay.RoomStatusTypeId == '9' ) {   //Occ Clean and Dirty
                
                if(!$scope.IsMouseDown)
                {
                    $scope.ResetSelection();
                    if(!roomDay.CurrentCheckINGuests || roomDay.CurrentCheckINGuests.length==0)
                    {
                        var date = roomDay.Day.Year +'-' + roomDay.Day.Month +'-'+roomDay.Day.Day;
                        var promiseGet = roomChartService.getCurrentRoomGuests(roomDay.CheckINGuestRoomId, date);
                        promiseGet.then(function (data) {
                            
                            roomDay.CurrentCheckINGuests = data.Collection;
                            BindModel(roomDay);
                        },
                        function (data) {
                            parent.failureMessage(data.message);
                            scrollPageOnTop();
                        });
                    }
                    else
                    {
                        //Bind From Model
                        BindModel(roomDay);
                    }
                }
            }
            else
            {
                //   
                if(!$scope.IsMouseDown)
                {
                    $scope.Model = {
                        BusinessDate: businessDate,
                        FromRoomDay:roomDay,
                        //ToRoomDay:roomDay,
                        FromRoomTypeId: selectedRoom.RoomTypeId,
                        FromRoomTypeName: selectedRoom.RoomTypeName,
                        FromRoomMasterId: selectedRoom.Id,
                        FromRoomMasterName: selectedRoom.Name,

                    }
                }
            }
        };
        $scope.onMouseMove = function ($event) {
            $scope.onMouseMoveResult = getMouseEventResult($event, "Mouse move");
        };
        $scope.onMouseMove = function (selectedRoom,roomDay, $event) {

            $scope.onMouseMoveResult = getMouseEventResult($event, "Mouse move");
            if(selectionStart && $scope.IsMouseDown && (roomDay.RoomStatusTypeId == '1' )) //|| roomDay.RoomStatusTypeId == '10'
            {
                if(!$scope.Model.FromRoomDay || !$scope.Model.FromRoomDay.Day)
                {
                    selectionStart =false;
                    $scope.IsMouseDown=false;
                    $scope.Nights=0;
                    roomDay.IsCheckIN = false;
                    $scope.ResetSelection();
                }
                $scope.ResetSelection();
                $scope.Model.ToRoomDay = roomDay;
                $scope.Model.ToRoomMasterId = selectedRoom.Id;
                $scope.Model.ToRoomNumber = selectedRoom.Name;
                $scope.Model.ToRoomTypeId = selectedRoom.RoomTypeId;
                $scope.Model.ToRoomTypeName = selectedRoom.RoomTypeName;
                $scope.Model.IsSelectionStart = selectionStart;

                var a = moment($scope.Model.FromRoomDay.Day.FutureDate, 'YYYY-MM-DD');
                var b = moment($scope.Model.ToRoomDay.Day.FutureDate, 'YYYY-MM-DD');
                $scope.Nights = b.diff(a, 'days');
                if($scope.Nights==0)
                {
                    return;
                }
                //var a = GetMomentDate( $scope.Model.FromRoomDay.Day.FutureDate,'YYYY-MM-DD');
                //var b = GetMomentDate( $scope.Model.ToRoomDay.Day.FutureDate,'YYYY-MM-DD');
                //var nights = b.diff(a, 'days');

                var startDay=0;
                var endDay=$scope.Nights;
                var i=0;

                var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id ==selectedRoom.RoomTypeId );
                angular.forEach(roomType.Rooms, function (room) {
                    if (selectedRoom.Id == room.Id) {
                        for (var m = moment(a) ; m.diff(b, 'days') <= 0 ; m.add(1, 'days')) {
                            var futureDate = ConvertDateToServerDate(m);
                            var roomDay = room.Days.filter(x=>x.Day.FutureDate == futureDate );
                            if(i==startDay)
                            {
                                //PM
                                roomDay[1].IsSelected = true;
                            }
                            else if(i==endDay)
                            {
                                //AM
                                roomDay[0].IsSelected = true;
                            }
                            else
                            {
                                //AM
                                roomDay[0].IsSelected = true;
                                //PM
                                roomDay[1].IsSelected = true;
                            }
                            i++;
                        }
                    }
                });
                
            }
            else
            {
                roomDay.IsCheckIN = false;
                selectionStart =false;
                $scope.IsMouseDown=false;
                $scope.Nights=0;
            }
            
        };
        
        $scope.onMouseOverRoom = function (room, $event) {

            $scope.LinkRoomModel = {SelectedRoomLinkRooms:[]};
            $scope.SelectedRoomLinkRooms=[];
            
            var screenwidth = $('body').width();
            var screenheight = $('body').height();
            var mouseOverBoxHeight = 300;// $('#MouseOverBox').height();

            var left = $event.pageX - $event.offsetX;
            if (screenwidth < left + 350) {
                left = screenwidth - 350;
            }
            var top = $event.pageY - $event.offsetY - 60
            
            angular.forEach($scope.LinkRooms,function(linkRoom) {
                if(linkRoom.Id == room.Id)
                {
                    angular.forEach(linkRoom.LinkRooms,function(item) {
                        $scope.SelectedRoomLinkRooms.push({Id:item.LinkRoomMasterId,Name:item.LinkRoomNumber});
                    });
                }
            });
            if($scope.SelectedRoomLinkRooms.length>0)
            {
                $scope.LinkRoomModel = {
                    SelectedRoomLinkRooms:$scope.SelectedRoomLinkRooms,
                    Left: left,
                    Top: top,
                };
            }
        };

        //RoomType
        $scope.onMouseDownAvailibility = function ($event) {
            $scope.onMouseDownResult = getMouseEventResult($event, "Mouse down");
        };
        $scope.onMouseDownAvailibility = function (roomTypeId, roomTypeDay, $event) {
            $scope.onMouseDownResult = getMouseEventResult($event, "Mouse down");
            var a = GetMomentDate(businessDate, $scope.DateFormat);
            var futureDate = GetMomentDate($filter('date')(roomTypeDay.FutureDate, $scope.DateFormat), $scope.DateFormat);
            if (futureDate.isBefore(a)) {
                return;
            }
            $scope.IsMouseDown = true;
            $scope.ResetSelectionRoomType();
            selectionStart = true;
            
            $scope.Model = {
                BusinessDate: businessDate,
                FromRoomDay:roomTypeDay,
                ToRoomDay:{},
                FromRoomTypeId:roomTypeId, 
                
            };
            $scope.Nights=0;

        };
        $scope.onMouseUpAvailibility = function ($event) {
            $scope.onMouseUpResult = getMouseEventResult($event, "Mouse up");
        };
        $scope.onMouseUpAvailibility = function (roomTypeId, roomTypeDay, $event) {
            var a = GetMomentDate(businessDate, $scope.DateFormat);
            var futureDate = GetMomentDate($filter('date')(roomTypeDay.FutureDate, $scope.DateFormat), $scope.DateFormat);
            if (futureDate.isBefore(a)) {
                return;
            }
            $scope.onMouseUpResult = getMouseEventResult($event, "Mouse up");
            var days = GetDays($scope.Model.FromRoomDay.Day.FutureDate,roomTypeDay.Day.FutureDate, 'YYYY-MM-DD');
            if(days.length>0)
            {
                $scope.OpenModel('reservationModel');
            }
            $scope.IsMouseDown=false;
            $scope.Nights=0;
        };
        $scope.onMouseEnterAvailibility = function ($event) {
            $scope.onMouseEnterResult = getMouseEventResult($event, "Mouse enter");
        };
        $scope.onMouseLeaveAvailibility = function ($event) {
            $scope.onMouseLeaveResult = getMouseEventResult($event, "Mouse leave");
        };
        $scope.onMouseOverAvailibility = function (roomTypeId, roomTypeDay, $event) {
            
            if(!roomTypeDay)
            {
                return;
            }
            roomTypeDay.RoomStatusTypeId='1';

            $scope.onMouseOverResult = getMouseEventResult($event, "Mouse over");
            if(!$scope.IsMouseDown)
            {
                $scope.Model = {
                    BusinessDate: businessDate,
                    FromRoomDay:roomTypeDay,
                    FromRoomTypeId:roomTypeId,
                }
                $scope.Nights=0;
            }
        };
        $scope.onMouseMoveAvailibility = function ($event) {
            $scope.onMouseMoveResult = getMouseEventResult($event, "Mouse move");
        };
        $scope.onMouseMoveAvailibility = function (roomTypeId, roomTypeDay, $event) {
            $scope.onMouseMoveResult = getMouseEventResult($event, "Mouse move");
            if(selectionStart && $scope.IsMouseDown)
            {
                if(!$scope.Model.FromRoomDay)
                {
                    selectionStart =false;
                    $scope.IsMouseDown=false;
                }

                $scope.Model.ToRoomDay = roomTypeDay;
                $scope.Model.ToRoomTypeId = roomTypeId;
                $scope.Model.IsSelectionStart = selectionStart;
                
                var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == roomTypeId);
                angular.forEach(roomType.Availabilitys, function (item) {
                    if(roomTypeDay.Day.FutureDate == item.FutureDate && roomTypeDay.RoomTypeId == item.RoomTypeId)
                    {
                        
                        roomTypeDay.Day.IsSelected = true;
                    }
                });
                
            }
           
        };

        $scope.ResetSelectionRoomType = function () {
            angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                angular.forEach(roomType.Availabilitys, function (roomTypeDay) {
                    roomTypeDay.Day.IsSelected = false;
                });
            });
        };

        $scope.LinkRoomModel = {SelectedRoomLinkRooms:[]};
        $scope.SelectedRoomLinkRooms=[];
        
        $scope.RoomTransferCheckIN = function(){
            $scope.SelectedRooms=[];
            if($scope.Model.FromRoomDay.RoomStatusTypeId=='7' || $scope.Model.FromRoomDay.RoomStatusTypeId=='8')
            {
                var checkINDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat) ;
                var checkOUTDate = $filter('date')($scope.Model.FromRoomDay.CurrentCheckINGuests[0].CheckOUTDate, $scope.DateFormat) ;
                var temps = $scope.GetRoomForCheckIN(checkINDate,checkOUTDate, $scope.Model.FromRoomTypeId);;
                angular.forEach(temps,function(item){
                    if(item.Id!='OB')
                    {
                        $scope.SelectedRooms.push(item);
                    }
                });

                var promiseGet = roomChartService.getCurrentRoomGuests($scope.Model.FromRoomDay.CheckINGuestRoomId, $scope.MinDate);
                promiseGet.then(function (data) {
                    $scope.CurrentCheckINGuests = data.Collection;
                    var fromCheckINGuestRoomId = $scope.CurrentCheckINGuests[0].CheckINGuestRoom.Id;
                    $scope.RoomTransfer = {
                        GuestName: $scope.CurrentCheckINGuests[0].Name,
                        FromCheckINGuestRoomId: fromCheckINGuestRoomId,
                        ToId: '',//$scope.Model.ToRoomDay.RoomId,
                        RoomMoveTypeId: '2',
                        RoomMoveTypeName: 'Room Transfer',
                        IsUpgrade: false,
                        BusinessDate: $scope.MinDate,
                        ReasonId: '',
                        RoomMoveRemark: '',
                        FromRoomNumber: $scope.Model.FromRoomDay.Name,
                        ToRoomNumber: '',//$scope.Model.ToRoomDay.RoomNumber,
                        FromRoomId : $scope.CurrentCheckINGuests[0].CheckINGuestRoom.RoomMasterId,
                        FromRoom : $scope.Model.FromRoomDay,
                        FromDate:checkINDate,
                        ToDate:checkOUTDate,
                    };
                    $("#actionCheckINModel").modal('hide');
                    $scope.OpenModel('roomTransferModel');

                },
                function (data) {
                    parent.failureMessage(data.message);
                    scrollPageOnTop();
                });
            }
        }

        $scope.RoomSwapCheckIN=function(){
            $scope.SelectedRooms=[];

            if($scope.Model.FromRoomDay.RoomStatusTypeId=='7' || $scope.Model.FromRoomDay.RoomStatusTypeId=='8')
            {
                var promiseGet = roomChartService.getCurrentRoomGuests($scope.Model.FromRoomDay.CheckINGuestRoomId, $scope.MinDate);
                promiseGet.then(function (data) {
                    $scope.CurrentCheckINGuests = data.Collection;

                    var fromCheckINGuestRoomId = $scope.CurrentCheckINGuests[0].CheckINGuestRoom.Id;

                    $scope.RoomTransfer = {
                        GuestName: $scope.CurrentCheckINGuests[0].Name,
                        FromCheckINGuestRoomId: fromCheckINGuestRoomId,
                        ToId: $scope.Model.ToRoomMasterId,
                        RoomMoveTypeId: '3',
                        RoomMoveTypeName: 'Room Swap',
                        IsUpgrade: false,
                        BusinessDate: $scope.MinDate,
                        ReasonId: '',
                        RoomMoveRemark: '',
                        FromRoomNumber: $scope.Model.FromRoomMasterName,
                        ToRoomNumber: $scope.Model.ToRoomName,
                        FromRoomId : $scope.CurrentCheckINGuests[0].CheckINGuestRoom.RoomMasterId,
                    };

                    var checkINDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat) ;
                    var checkOUTDate = $filter('date')($scope.Model.FromRoomDay.CurrentCheckINGuests[0].CheckOUTDate, $scope.DateFormat) ;
                    
                    var temps = $scope.GetOccupiedRoom(  checkINDate,checkOUTDate, $scope.Model.FromRoomTypeId);
                    angular.forEach(temps,function(item){
                        if(item.Id!='OB')
                        {
                            $scope.SelectedRooms.push(item);
                        }
                    });


                    $("#actionCheckINModel").modal('hide');
                    $scope.OpenModel('roomMoveModel');

                },
                function (data) {
                    parent.failureMessage(data.message);
                    scrollPageOnTop();
                });
            }
        }

        $scope.ChangeRoom = function(obj)
        {
            if(obj)
            {
                var checkINGuestRoomId = $.parseJSON(obj).CheckINGuestRoomId;
                $scope.RoomTransfer.ToId= $.parseJSON(obj).Id;
            
                var promiseGet = roomChartService.getCurrentRoomGuests(checkINGuestRoomId, $scope.MinDate);
                promiseGet.then(function (data) {
                    $scope.ToCurrentCheckINGuests = data.Collection;
                    var toCheckINGuestRoomId = $scope.ToCurrentCheckINGuests[0].CheckINGuestRoom.Id;
                    $scope.RoomTransfer.ToCheckINGuestRoomId = toCheckINGuestRoomId;

                },
                function (data) {
                    parent.failureMessage(data.message);
                    scrollPageOnTop();
                });
            }
        }

        function BindModel(roomDay){
            $scope.Model = {
                BusinessDate: businessDate,
                FromRoomDay:roomDay,
                Left: roomDay.Left,
                Top: roomDay.Top,
            };

            try
            {
                var fromRoomNumber = roomDay.CurrentCheckINGuests[0].CheckINGuestRoom.FromRoomNumber;
                $scope.Model.FromRoomNumber = fromRoomNumber ;
            }
            catch(ex){}
            
        }

        function CheckINAction(){
            if($scope.Model.FromRoomDay.CurrentCheckINGuests)
            {
                if($scope.Model.FromRoomDay.CurrentCheckINGuests.length>0)
                {
                    $("#actionCheckINModel").modal('show');
                }
            }
        }

        $scope.ChangeRoomTypeCheckINRoom=function (){
            
            $scope.CurrentCheckINGuests=$scope.Model.FromRoomDay.CurrentCheckINGuests;
            
            $scope.RoomTransfer = {
                GuestName: $scope.Model.FromRoomDay.CurrentCheckINGuests[0].Name,
                FromCheckINGuestRoomId: $scope.Model.FromRoomDay.CheckINGuestRoomId,
                //ToId: $scope.Model.ToRoomId,
                RoomMoveTypeId: '2',
                RoomMoveTypeName: 'Room Transfer',
                IsUpgrade: false,
                BusinessDate: $scope.MinDate,
                ReasonId: '',
                RoomMoveRemark: '',
                FromRoomNumber: $scope.Model.FromRoomMasterName,
                //ToRoomNumber: $scope.Model.ToRoomDay.ToRoomNumber,
                FromRoomId : $scope.CurrentCheckINGuests[0].CheckINGuestRoom.RoomMasterId,
            };

            $("#roomTypeTransferModel").modal('show');
            $("#actionCheckINModel").modal('hide');
        }

        $scope.ChangeRoomCheckINRoom=function (){
            $scope.CurrentCheckINGuests=$scope.Model.FromRoomDay.CurrentCheckINGuests;
            $scope.RoomTransfer = {
                GuestName: $scope.Model.FromRoomDay.CurrentCheckINGuests[0].Name,
                FromCheckINGuestRoomId: $scope.Model.FromRoomDay.CheckINGuestRoomId,
                RoomMoveTypeId: '2',
                RoomMoveTypeName: 'Room Transfer',
                IsUpgrade: false,
                BusinessDate: $scope.MinDate,
                ReasonId: '',
                RoomMoveRemark: '',
                FromRoomNumber: $scope.Model.FromRoomMasterName,
            };

            $("#roomTypeTransferModel").modal('show');
            $("#actionCheckINModel").modal('hide');
        }

        $scope.SelectedRooms=[];
        $scope.ChangeToRoomType=function (roomType){
            if(roomType)
            {
                roomType= $.parseJSON(roomType);
                //$scope.SelectedRooms = $.parseJSON(roomType).Rooms;
                
                $scope.SelectedRooms=[];

                var checkINDate = $filter('date')($scope.ModifiedDate, $scope.DateFormat) ;
                var checkOUTDate = $filter('date')($scope.Model.FromRoomDay.CurrentCheckINGuests[0].CheckOUTDate, $scope.DateFormat) ;
                var temps = $scope.GetRoomForCheckIN(checkINDate,checkOUTDate, roomType.Id);;
                angular.forEach(temps,function(item){
                    if(item.Id!='OB')
                    {
                        $scope.SelectedRooms.push(item);
                    }
                });

            }
        }

        //------------------------------------------
        
        
        //Clean = 1,
        //Dirty = 2,
        //Inspected = 3,
        //ManagementBlock = 4,
        //MaintenanceBlock = 5,
        //ReservationBlock = 6,
        
        $scope.IsReservationView = false;
        $scope.IsCheckINView = false;
        $scope.IsChasieringView = false;
        $scope.InjectReservationModel={};

        $scope.OpenModel = function (model) {

            //$scope.IsCheckINView = false;
            $scope.IsChasieringView = false;
            //$scope.IsReservationView = false;

            $scope.InjectReservationModel={};

            $("#actionReservationModel").modal('hide');
            $("#actionConfirmationModel").modal('hide');
            $("#reservationModel").modal('hide');
            $("#maintenanceBlockModel").modal('hide');
            $("#cleanModel").modal('hide');

            if (model == 'maintenanceBlockModel' || model == 'managementBlockModel' ) {
                if(!$scope.Model.FromRoomDay.RoomBlock)
                {
                    
                    $scope.Model.FromRoomDay.RoomBlock = {
                        FromDate: $filter('date')($scope.Model.FromRoomDay.Day.FutureDate, $scope.DateFormat),
                        ToDate: $filter('date')($scope.Model.ToRoomDay.Day.FutureDate, $scope.DateFormat),
                        ToTime: '',
                        RoomBlockId: $scope.Model.FromRoomDay.RoomBlockId,
                        RoomMasterId: $scope.Model.FromRoomMasterId,
                        RoomNumber: $scope.Model.FromRoomMasterName,
                        RoomTypeId: $scope.Model.FromRoomTypeId,
                        RoomTypeName: $scope.Model.FromRoomTypeName,
                        RoomStatusTypeId: '5',
                        RoomStatusTypeName: 'Maintenance Block',
                        Days: GetDays($filter('date')($scope.Model.FromRoomDay.Day.FutureDate, $scope.DateFormat), $filter('date')($scope.Model.ToRoomDay.Day.FutureDate, $scope.DateFormat),$scope.DateFormat),
                    };

                    if (model == 'maintenanceBlockModel' ) {
                        $scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId = '5';
                        $scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeName= 'Maintenance Block';
                    }
                    else
                    {
                        $scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId = '4';
                        $scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeName= 'Management Block';
                    }
                }
                if (model == 'managementBlockModel' ) {
                    model = 'maintenanceBlockModel'
                }
                $("#" + model).modal('show');
            }
            else if (model == 'cleanModel')
            {
                $scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeName= 'Room Status';
                $("#" + model).modal('show');
            }
            else if (model == 'reservationModel') {
                if(!$scope.Model.FromRoomDay || !$scope.Model.ToRoomDay)
                {
                    return;
                }

                $scope.ArrivalDate = $filter('date')($scope.Model.FromRoomDay.Day.FutureDate, $scope.DateFormat);
                $scope.DepartureDate = $filter('date')($scope.Model.ToRoomDay.Day.FutureDate, $scope.DateFormat);
                
                var roomChartRoomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == $scope.Model.ToRoomTypeId)
                if(!roomChartRoomType.AvailableRooms)
                {
                    $scope.GetAvailableRoom($scope.ArrivalDate,$scope.DepartureDate, roomChartRoomType);
                }
                roomChartRoomType.ArrivalDate=$scope.ArrivalDate;
                roomChartRoomType.DepartureDate=$scope.DepartureDate;

                if(!$scope.IsReservationValid(roomChartRoomType))
                {
                    return;
                }
                
                var roomType = $scope.RoomTypes.find(x=>x.Id == $scope.Model.FromRoomTypeId);
                $scope.InjectReservationModel = {
                    RoomChart: $scope.RoomChart,
                    ArrivalDate:$scope.ArrivalDate,
                    DepartureDate :$scope.DepartureDate ,
                    RoomMasterId:$scope.Model.ToRoomMasterId,
                    RoomNumber: $scope.Model.ToRoomName,
                    AvailableRooms:roomChartRoomType.AvailableRooms,
                    Availabilitys:roomChartRoomType.Availabilitys,
                    Rooms: roomChartRoomType.Rooms,
                    RoomTypeId:roomType.Id, 
                    RoomTypeCode: roomType.Code,
                    RoomTypeName: roomType.Name,
                    TotalRoom: roomType.TotalRoom,
                    OverBooking: roomType.OverBooking,
                    MaxPax: roomType.MaxPax,
                    Advance: roomType.Advance,
                    ReservationId:'',
                    IsCancelMode:false,
                    IsModify:false, 
                    PropertyID : $scope.PropertyID,
                };

                if($scope.IsReservationView)
                {
                    $rootScope.$broadcast("CallOpenRoomChartReservation", $scope.InjectReservationModel);
                }
                else
                {
                    $scope.IsReservationView = true;
                }


                $scope.IsMouseDown = false;

                if ($scope.IsReservationActive)
                {
                    
                }
                
                scrollPageOnTop();
                $scope.ProgressEnd();
                return;
            }
            else if (model == 'checkINModel') {
                   
                if(!$scope.Model.FromRoomDay || !$scope.Model.ToRoomDay)
                {
                    return;
                }
                

                $scope.ArrivalDate = $filter('date')($scope.Model.FromRoomDay.Day.FutureDate, $scope.DateFormat);
                $scope.DepartureDate = $filter('date')($scope.Model.ToRoomDay.Day.FutureDate, $scope.DateFormat);

                var roomChartRoomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == $scope.Model.ToRoomTypeId)
                $scope.GetAvailableRoom($scope.ArrivalDate,$scope.DepartureDate, roomChartRoomType);
                roomChartRoomType.ArrivalDate=$scope.ArrivalDate;
                roomChartRoomType.DepartureDate=$scope.DepartureDate;

                var roomType = $scope.RoomTypes.find(x=>x.Id == $scope.Model.FromRoomTypeId);
                

                $scope.InjectCheckINModel = {
                    RoomChart: $scope.RoomChart,
                    ArrivalDate: $scope.Model.FromRoomDay.Day.FutureDate,
                    DepartureDate: $scope.Model.ToRoomDay.Day.FutureDate,
                    RoomTypeId:roomType.Id, 
                    RoomTypeCode: roomType.Code,
                    RoomTypeName: roomType.Name,
                    TotalRoom: roomType.TotalRoom,
                    OverBooking: roomType.OverBooking,
                    MaxPax: roomType.MaxPax,
                    Advance: roomType.Advance,
                    RoomMasterId: $scope.Model.FromRoomMasterId,
                    RoomNumber: $scope.Model.FromRoomMasterName,
                    AvailableRooms:roomChartRoomType.AvailableRooms,
                    Availabilitys:roomChartRoomType.Availabilitys,
                    Rooms: roomChartRoomType.Rooms,
                    PropertyID: $scope.PropertyID,
                    IsWalkIN : true
                };

                if($scope.IsCheckINView)
                {
                    $rootScope.$broadcast("CallOpenRoomChartCheckIN", $scope.InjectCheckINModel);
                    $scope.IsModify = false;
                }
                else
                {
                    $scope.IsCheckINView = true;
                }
                $scope.IsMouseDown = false;

                
                if ($scope.IsCheckINActive)
                {
                    
                }
                
                scrollPageOnTop();
                $scope.ProgressEnd();
                return;
            }
            else
            {
                $("#" + model).modal('show');
            }
        };
        
        $scope.GetNights = function(a,b)
        {
            a = moment(a, 'YYYY-MM-DD');
            b = moment(b, 'YYYY-MM-DD');
            return b.diff(a, 'days');;
        }

        $scope.AvailableRoom = 1;
        $scope.SelectedRoom = "1";
        
        $scope.GetOccupiedRoom = function(ArrivalDate,DepartureDate ,RoomTypeId)
        {
            $scope.OccupiedRooms = [];
            var a = GetMomentDate(ArrivalDate, $scope.DateFormat);
            var b = GetMomentDate(DepartureDate, $scope.DateFormat);
            availabilityCount = new Array();
            var myRoom = {};
            var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == RoomTypeId);
            angular.forEach(roomType.Rooms, function (room) {
                var IsAdd = false;
                myRoom = room;
                var checkINGuestRoomId='';
                for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                    angular.forEach(room.Days, function (roomDay) {
                        var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                        if (futureDate.isSame(m)) {

                            if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
                                IsAdd = true;
                                checkINGuestRoomId=roomDay.CheckINGuestRoomId;
                            }

                            if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5' || roomDay.RoomStatusTypeId == '6') ) {
                                IsAdd = false;
                            }
                        }
                    });
                }
                if (IsAdd) {
                    $scope.OccupiedRooms.push({ Id: myRoom.Id, Name: myRoom.Name ,CheckINGuestRoomId: checkINGuestRoomId, RoomStatusTypeId:roomDay.RoomStatusTypeId});
                }
            });

            //angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
            //    if (roomType.Id == RoomTypeId) {
            //        var myRoom = {};
            //        angular.forEach(roomType.Rooms, function (room) {
            //            var IsAdd = false;
            //            myRoom = room;
            //            var checkINGuestRoomId='';
            //            for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
            //                angular.forEach(room.Days, function (roomDay) {
            //                    var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
            //                    if (futureDate.isSame(m)) {

            //                        if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
            //                            IsAdd = true;
            //                            checkINGuestRoomId=roomDay.CheckINGuestRoomId;
            //                        }

            //                        if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5' || roomDay.RoomStatusTypeId == '6') ) {
            //                            IsAdd = false;
            //                        }
            //                    }
            //                });
            //            }
            //            if (IsAdd) {
            //                $scope.OccupiedRooms.push({ Id: myRoom.Id, Name: myRoom.Name ,CheckINGuestRoomId: checkINGuestRoomId, RoomStatusTypeId:roomDay.RoomStatusTypeId});
            //            }
            //        });
            //    }
            //});
            return $scope.OccupiedRooms;//availabilityCount.min();
        }
        $scope.GetRoomForCheckIN = function(ArrivalDate,DepartureDate ,RoomTypeId)
        {
            $scope.OccupiedRooms = [];
            var a = GetMomentDate(ArrivalDate, $scope.DateFormat);
            var b = GetMomentDate(DepartureDate, $scope.DateFormat);
            availabilityCount = new Array();
            var myRoom = {};

            var roomType = $scope.RoomChart.RoomTypes.find(x=>x.Id == RoomTypeId);
            angular.forEach(roomType.Rooms, function (room) {
                var IsAdd = true;
                myRoom = room;
                var checkINGuestRoomId='';
                var roomStatusTypeId='1';

                if(a.isSame(b))
                {
                    var m = a;
                    angular.forEach(room.Days, function (roomDay) {
                        var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                        if (futureDate.isSame(m)) {

                            checkINGuestRoomId=roomDay.CheckINGuestRoomId;
                            roomStatusTypeId=roomDay.RoomStatusTypeId;
                                    
                            if(roomDay.DayPart=='AM')
                            {
                                if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
                                    IsAdd = false;
                                }
                                else if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5' || roomDay.RoomStatusTypeId == '6') ) {
                                    IsAdd = false;
                                }
                            }
                            if(room.CurrentRoomStatusId!='1')
                            {
                                IsAdd = false;
                            }
                        }
                    });
                }
                else
                {
                    for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                        angular.forEach(room.Days, function (roomDay) {
                            var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                            if (futureDate.isSame(m)) {
                                checkINGuestRoomId=roomDay.CheckINGuestRoomId;
                                roomStatusTypeId=roomDay.RoomStatusTypeId;
                                if(roomDay.DayPart=='PM')
                                {
                                    if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
                                        IsAdd = false;
                                    }
                                    else if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5' || roomDay.RoomStatusTypeId == '6') ) {
                                        IsAdd = false;
                                    }
                                }
                                if(room.CurrentRoomStatusId!='1')
                                {
                                    IsAdd = false;
                                }
                            }
                        });
                    }
                }
                        
                if (IsAdd) {
                    $scope.OccupiedRooms.push({ Id: myRoom.Id, Name: myRoom.Name, RoomTypeId: myRoom.RoomTypeId, RoomTypeName: roomType.Name,  CheckINGuestRoomId: checkINGuestRoomId, RoomStatusTypeId:roomStatusTypeId,MaxPerson:myRoom.MaxPerson,OrderSNo:myRoom.OrderSNo});
                }
            });

            //angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
            //    if (roomType.Id == RoomTypeId) {
            //        var myRoom = {};
            //        angular.forEach(roomType.Rooms, function (room) {
            //            var IsAdd = true;
            //            myRoom = room;
            //            var checkINGuestRoomId='';
            //            var roomStatusTypeId='1';

            //            if(a.isSame(b))
            //            {
            //                var m = a;
            //                angular.forEach(room.Days, function (roomDay) {
            //                    var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
            //                    if (futureDate.isSame(m)) {

            //                        checkINGuestRoomId=roomDay.CheckINGuestRoomId;
            //                        roomStatusTypeId=roomDay.RoomStatusTypeId;
                                    
            //                        if(roomDay.DayPart=='AM')
            //                        {
            //                            if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
            //                                IsAdd = false;
            //                            }
            //                            else if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5' || roomDay.RoomStatusTypeId == '6') ) {
            //                                IsAdd = false;
            //                            }
            //                        }
            //                        if(room.CurrentRoomStatusId!='1')
            //                        {
            //                            IsAdd = false;
            //                        }
            //                    }
            //                });
            //            }
            //            else
            //            {
            //                for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
            //                    angular.forEach(room.Days, function (roomDay) {
            //                        var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
            //                        if (futureDate.isSame(m)) {
            //                            checkINGuestRoomId=roomDay.CheckINGuestRoomId;
            //                            roomStatusTypeId=roomDay.RoomStatusTypeId;
            //                            if(roomDay.DayPart=='PM')
            //                            {
            //                                if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
            //                                    IsAdd = false;
            //                                }
            //                                else if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5' || roomDay.RoomStatusTypeId == '6') ) {
            //                                    IsAdd = false;
            //                                }
            //                            }
            //                            if(room.CurrentRoomStatusId!='1')
            //                            {
            //                                IsAdd = false;
            //                            }
            //                        }
            //                    });
            //                }
            //            }
                        
            //            if (IsAdd) {
            //                $scope.OccupiedRooms.push({ Id: myRoom.Id, Name: myRoom.Name, RoomTypeId: myRoom.RoomTypeId, RoomTypeName: roomType.Name,  CheckINGuestRoomId: checkINGuestRoomId, RoomStatusTypeId:roomStatusTypeId,MaxPerson:myRoom.MaxPerson,RoomOrder:myRoom.RoomOrder});
            //            }
            //        });
            //    }
            //});
            return $scope.OccupiedRooms;//availabilityCount.min();
        }
        $scope.GetRoomForReservation = function(ArrivalDate,DepartureDate ,RoomTypeId,ReservationRoomTypeId)
        {
            var returnObj={};
            $scope.OccupiedRooms = [];
            var a = GetMomentDate(ArrivalDate, $scope.DateFormat);
            var b = GetMomentDate(DepartureDate, $scope.DateFormat);
            availabilityCount = new Array();
            var myRoom = {};
            var roomType =$scope.RoomChart.RoomTypes.find(x=>x.Id == RoomTypeId);
            
            angular.forEach(roomType.Rooms, function (room) {
                var IsAdd = true;
                myRoom = room;
                var reservationRoomTypeId='';
                var roomStatusTypeId='1';

                for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                    angular.forEach(room.Days, function (roomDay) {
                        var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
                        if (futureDate.isSame(m)) {

                            checkINGuestRoomId=roomDay.ReservationRoomTypeId;
                            roomStatusTypeId=roomDay.RoomStatusTypeId;
                                    
                            if(roomDay.DayPart=='PM')
                            {
                                if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
                                    IsAdd = false;
                                }
                                else if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5') ) {
                                    IsAdd = false;
                                }
                                else if ((roomDay.RoomStatusTypeId == '6') ) {
                                    if(ReservationRoomTypeId!=roomDay.ReservationRoomTypeId)
                                    {
                                        IsAdd = false;
                                    }
                                }
                            }
                        }

                        angular.forEach(roomType.Availabilitys  ,function(ava){
                            var futureDate = GetMomentDate($filter('date')(ava.FutureDate, $scope.DateFormat), $scope.DateFormat);
                            if (ava.TotalRemainingCount<=0) {
                                IsAdd = false;

                            }
                        });

                    });
                }
                if (IsAdd) {
                    //RoomType
                    for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
                        angular.forEach(roomType.Availabilitys  ,function(ava){
                            var futureDate = GetMomentDate($filter('date')(ava.FutureDate, $scope.DateFormat), $scope.DateFormat);
                            if (futureDate.isSame(m)) {
                                ava.TotalRemainingCount = ava.TotalRemainingCount-1;
                            }
                        });
                    }
                    $scope.OccupiedRooms.push({ Id: myRoom.Id, Name: myRoom.Name, RoomTypeId: myRoom.RoomTypeId, RoomTypeName: roomType.Name,  CheckINGuestRoomId: checkINGuestRoomId, RoomStatusTypeId:roomStatusTypeId,MaxPerson:myRoom.MaxPerson,OrderSNo:myRoom.OrderSNo});
                }
            });

            returnObj = angular.copy(roomType);

            //angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                
            //    if (roomType.Id == RoomTypeId) {
            //        var myRoom = {};
            //        angular.forEach(roomType.Rooms, function (room) {
            //            var IsAdd = true;
            //            myRoom = room;
            //            var reservationRoomTypeId='';
            //            var roomStatusTypeId='1';

            //            for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
            //                angular.forEach(room.Days, function (roomDay) {
            //                    var futureDate = GetMomentDate($filter('date')(roomDay.Day.FutureDate, $scope.DateFormat), $scope.DateFormat);
            //                    if (futureDate.isSame(m)) {

            //                        checkINGuestRoomId=roomDay.ReservationRoomTypeId;
            //                        roomStatusTypeId=roomDay.RoomStatusTypeId;
                                    
            //                        if(roomDay.DayPart=='PM')
            //                        {
            //                            if ((roomDay.RoomStatusTypeId == '7' || roomDay.RoomStatusTypeId == '8' ) && !roomDay.IsCheckOUTToday) {
            //                                IsAdd = false;
            //                            }
            //                            else if ((roomDay.RoomStatusTypeId == '4' || roomDay.RoomStatusTypeId == '5') ) {
            //                                IsAdd = false;
            //                            }
            //                            else if ((roomDay.RoomStatusTypeId == '6') ) {
            //                                if(ReservationRoomTypeId!=roomDay.ReservationRoomTypeId)
            //                                {
            //                                    IsAdd = false;
            //                                }
            //                            }
            //                        }
            //                    }

            //                    angular.forEach(roomType.Availabilitys  ,function(ava){
            //                        var futureDate = GetMomentDate($filter('date')(ava.FutureDate, $scope.DateFormat), $scope.DateFormat);
            //                        if (ava.TotalRemainingCount<=0) {
            //                            IsAdd = false;

            //                        }
            //                    });

            //                });
            //            }
            //            if (IsAdd) {
            //                //RoomType
            //                for (var m = moment(a) ; m.isBefore(b) ; m.add(1, 'days')) {
            //                    angular.forEach(roomType.Availabilitys  ,function(ava){
            //                        var futureDate = GetMomentDate($filter('date')(ava.FutureDate, $scope.DateFormat), $scope.DateFormat);
            //                        if (futureDate.isSame(m)) {
            //                            ava.TotalRemainingCount = ava.TotalRemainingCount-1;
            //                        }
            //                    });
            //                }
            //                $scope.OccupiedRooms.push({ Id: myRoom.Id, Name: myRoom.Name, RoomTypeId: myRoom.RoomTypeId, RoomTypeName: roomType.Name,  CheckINGuestRoomId: checkINGuestRoomId, RoomStatusTypeId:roomStatusTypeId,MaxPerson:myRoom.MaxPerson,RoomOrder:myRoom.RoomOrder});
            //            }
            //        });

            //        returnObj = angular.copy(roomType);
            //    }
            //});
            
            returnObj.OccupiedRooms=$scope.OccupiedRooms;
            return returnObj;//$scope.OccupiedRooms;//availabilityCount.min();
        }
        
        $scope.AddRoomType = function () {
            $scope.IsReservationActive = true;
            $("#reservationModel").modal('hide');
        }
        
        $scope.ReservationResetClose = function () {
            $scope.IsReservationActive = false;
            $scope.ResetSelection();
            $scope.ResetSelectionRoomType();
            $rootScope.$broadcast("CallResetReservationRoomType", {});
            $("#reservationModel").modal('hide');
        }

        $scope.CheckINResetClose = function () {
            $scope.IsCheckINActive = false;
            $scope.ResetSelection();
            $rootScope.$broadcast("CallResetCheckIN", {});
            $("#checkINModel").modal('hide');
        }

        $scope.getNumber = function (num) {
            return new Array(num);
        }

        $scope.CallRoomLock = function () {
            
            $scope.ShowRoomRate();
            $rootScope.$broadcast("CallRoomLock", null);
        }
        
        $scope.$on("CallShowRoomRate", function (event, obj) {
            
            $scope.ShowRoomRate();
        });

        $scope.$on("CallCloseRoomChartReservation", function (event, obj) {

            $scope.ShowLoader();
            if(obj.Mode=='Cancel')
            {
                $scope.UpdateRoomChartNOShow(obj.Id);
            }
            else
            {
                var reservationRoomTypes = obj.ReservationRoomTypes;
                if(reservationRoomTypes.length>0){

                    if($scope.IsHideReservation)
                    {
                        $scope.IsHideReservation=false;
                        //$scope.GetReservationRoomType();
                    }
                    else
                    {
                        
                    }

                    //Delete Old ReservationRoomType
                    angular.forEach(obj.ReservationRoomTypeDeletes,function(item){
                        $scope.UpdateRoomChartReservationRoomTypeDelete(item.Id);
                    });

                    //Update ReservationRoomType
                    angular.forEach(reservationRoomTypes,function(reservationRoomType){
                        var item ={
                            RoomTypeId : reservationRoomType.RoomTypeId,
                            RoomMasterId : reservationRoomType.RoomMasterId,
                            ArrivalDate : reservationRoomType.ArrivalDate,
                            DepartureDate : reservationRoomType.DepartureDate,
                            Content : reservationRoomType.Content,
                        };

                        $scope.UpdateRoomChartReservation(item);
                    });

                    $scope.UpdateRoomChartAvailability();
                    $timeout(function () {
                        $scope.MonthColMarge();
                        $scope.ColMarge1();
                        $scope.HideLoader();
                        $scope.load1($(".followMeBar"));
                    }, 200); // 3 seconds
                }
            }
            $scope.ResetSelection(); 
            $("#reservationModel").modal('hide');
        });

        $scope.$on("CallCloseRoomChartCheckIN", function (event, obj) {
            $scope.ShowLoader();
            
            //Delete Old ReservationRoomType
            angular.forEach(obj.ReservationRoomTypeDeletes,function(item){
                $scope.UpdateRoomChartReservationRoomTypeDelete(item.Id);
            });

            var checkINGuestRooms = obj.CheckINGuestRooms;
            if(checkINGuestRooms.length>0){

                if($scope.IsHideReservation)
                {
                    $scope.IsHideReservation=false;
                    //$scope.GetRoomChartCheckINGuestRoom();
                }
                else
                {
                   

                }

                angular.forEach(checkINGuestRooms,function(checkINGuestRoom){
                    var item ={
                        RoomTypeId : checkINGuestRoom.RoomTypeId,
                        RoomMasterId : checkINGuestRoom.RoomMasterId,
                        ArrivalDate : checkINGuestRoom.RoomINDate,
                        DepartureDate : checkINGuestRoom.RoomOUTDate,
                        Content : checkINGuestRoom.Content,
                    };
                    $scope.UpdateRoomChartCheckINRoom(item);
                });

                $scope.UpdateRoomChartAvailability();
                $timeout(function () {
                    $scope.MonthColMarge();
                    $scope.ColMarge1();
                    $scope.HideLoader();
                    $scope.load1($(".followMeBar"));
                }, 300); 
            }

            $scope.ResetSelection(); 
            $("#checkINModel").modal('hide');
            $('.fancybox-inner').attr('style', 'width: 800px !important');
        });

        $scope.UpdateRoomChartCheckIN = function(checkINGuestRoom)
        {
            var nights =0;
            if($scope.Model.FromRoomDay.Content)
            {
                if($scope.Model.FromRoomDay.Content.length>0)
                {
                    var data = $scope.Model.FromRoomDay.Content.split('$');
                    data[6] = $filter('date')(checkINGuestRoom.RoomOUTDate, $scope.DateFormat) ;
                    nights = GetDays(data[5],data[6] , $scope.DateFormat).length;
                    checkINGuestRoom.Content = data[0] + '$' + data[1] + '$' + data[2] + '$' + data[3] + '$' + data[4] + '$' + data[5] + '$' + data[6]  + '$' +  nights;
                }
            }

            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};	
           
            angular.forEach(roomChart.RoomTypes,function(roomType){
                if(checkINGuestRoom.RoomTypeId == roomType.Id)
                {
                    
                    var calMinDate = GetMomentDate($scope.MinDate, 'yyyy-MM-dd');
                    var arrivalDate = GetMomentDate($scope.MinDate,  'yyyy-MM-dd');
                    var roomINDate = GetMomentDate(checkINGuestRoom.RoomINDate,  'yyyy-MM-dd');
                    var departureDate = GetMomentDate(checkINGuestRoom.RoomOUTDate,  'yyyy-MM-dd');

                    var emptyRoomDays=[];
                    var roomCopy={};

                    angular.forEach(roomType.Rooms,function(room){
                        if(checkINGuestRoom.RoomMasterId == room.Id)
                        {
                            room.CurrentRoomStatusId = '3';
                            room.CurrentRoomStatus = 'Clean';

                            roomCopy = angular.copy(room);
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;
                            var isEmpty=true;
                            
                            for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                //skip Start Day AM
                                if(!m.isSame(arrivalDate))
                                {//AM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    if(emptyRoomDays.length==0)
                                    {
                                        isEmpty=false;
                                    }
                                }

                                //skip Start Day PM
                                if(!m.isSame(departureDate))
                                {
                                    //PM
                                    emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' | x.RoomStatusTypeId == '6' ));
                                    if(emptyRoomDays.length==0)
                                    {
                                        isEmpty=false;
                                    }
                                }
                                
                            }


                            if(isEmpty)
                            {
                                //Set ReservationStatus
                                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    if(i==startDay)
                                    {

                                        //AM
                                        if(m.isAfter(roomINDate))
                                        {
                                            emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' ||  x.RoomStatusTypeId == '6'));
                                            angular.forEach(emptyRoomDays,function(roomDay){
                                                roomDay.Content =checkINGuestRoom.Content;
                                                var data = checkINGuestRoom.Content.split('$');
                                                roomDay.RoomStatusTypeId=data[0];
                                                roomDay.CheckINGuestRoomId = data[1];
                                                roomDay.CheckINId = data[2];
                                                roomDay.CurrentCheckINGuests=[];
                                            });
                                        }

                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' ||  x.RoomStatusTypeId == '6'));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.CurrentCheckINGuests=[];
                                        });
                                    }
                                    else if(i==endDay)
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' ||  x.RoomStatusTypeId == '6'));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.CurrentCheckINGuests=[];
                                        });
                                    }
                                    else
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && (x.RoomStatusTypeId == '1' ||  x.RoomStatusTypeId == '6'));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.CurrentCheckINGuests=[];
                                        });
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && (x.RoomStatusTypeId == '1' ||  x.RoomStatusTypeId == '6'));
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =checkINGuestRoom.Content;
                                            var data = checkINGuestRoom.Content.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                            roomDay.CurrentCheckINGuests=[];
                                        });
                                    }
                                    i++;
                                }
                            }
                        }
                    });
                }
            });

            $scope.RoomChart =roomChart;
        }

        $scope.$on("CallShowError", function (event, obj) {
            
            var msg = obj.Message;
            if (obj.IsError)
            {
                parent.popErrorMessage(obj.Message);
            }
            else
            {
                parent.popSuccessMessage(obj.Message);
            }    
        });
           
        $scope.IsCancelMode = false;

        $scope.IsReservationValid = function (selectedRoomType)
        {
            var a = GetMomentDate(selectedRoomType.ArrivalDate, $scope.DateFormat);
            var b = GetMomentDate(selectedRoomType.DepartureDate, $scope.DateFormat);

            var IsValidBooking=true;
            angular.forEach(selectedRoomType.Availabilitys,function(item){
               
                var futureDate = GetMomentDate($filter('date')(item.FutureDate, $scope.DateFormat), $scope.DateFormat);
                if (futureDate.isSame(a) || futureDate.isAfter(a)) {
                    if (futureDate.isBefore(b)) {

                        var roomtypes = $scope.RoomTypes.filter(x=>x.Id == item.RoomTypeId);
                        selectedRoomType.OverBooking = roomtypes[0].OverBooking;
                        var reservationRoomTypeCounts =$scope.ReservationRoomTypes.filter(x=>x.RoomTypeId == item.RoomTypeId).length;
                        var currentOBRoomCount=0;
                        try{
                            currentOBRoomCount = selectedRoomType.Rooms.filter(x=>x.Id == 'OB').length;
                        }
                        catch(ex){}
                
                        var OBRooms = (selectedRoomType.Rooms.length-currentOBRoomCount) * (selectedRoomType.OverBooking/100);
                        OBRooms = parseInt(OBRooms);

                        item.TotalAvailabilityCount =item.AvailabilityCount + OBRooms-reservationRoomTypeCounts;

                        if(item.TotalAvailabilityCount<=0)
                        {
                            IsValidBooking=false;
                        }
                    }
                }

            });

            if(!IsValidBooking)
            {
                parent.failureMessage("Overbooking room limit exceded.");
                return IsValidBooking;
            }
            return IsValidBooking;

        };

      
                
        $scope.$on("CallGetAvailableRoom", function (event, obj) {
            
            $scope.AvailableRooms = $scope.GetRoomForCheckIN(obj.ArrivalDate,obj.DepartureDate, obj.RoomTypeId);
            var model = {
                ArrivalDate: obj.ArrivalDate,//ArrivalDate,
                DepartureDate: obj.DepartureDate,// $scope.DepartureDate,
                RoomTypeId: obj.RoomTypeId,
                RoomMasterId: '',
                RoomNumber: '',
                AvailableRooms: $scope.AvailableRooms,
                PropertyID: $scope.PropertyID,
            };

            $timeout(function() { 
                $rootScope.$broadcast("CallSetGetAvailableRoom", model);
                $scope.ProgressEnd();
            }, 20);
        });

        $scope.ShowArrangement = function () {
            $("#arrangementsBox").modal('show');
        }

        $scope.getRoomList = function () {
            $scope.RoomList = [];
            roomChartService.getRoomList($scope.PropertyID, $scope.Model.ToRoomTypeId, null, null, null, null, $scope.ModifiedDate)
                   .then(function (result) {

                       $scope.RoomList = result.Collection;

                   }, function (err) {
                       msg(err.Message);
                   });
        };

        function getDays(fromDate, toDate) {

            $scope.days = [];
            fromDate = GetMomentDate(fromDate, $scope.DateFormat);
            toDate = GetMomentDate(toDate, $scope.DateFormat);
            var duration = toDate.diff(fromDate, 'days')
            for (var i = 0; i <= duration ; i++) {
                var futureDate = moment(fromDate).add(i, 'days');
                $scope.days.push(futureDate);
            }
            return $scope.days;
        };

        $scope.UpdateRoomChartRoomStatus = function(roomId, roomStatusTypeId)
        {
            angular.forEach($scope.RoomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    if(room.Id==roomId)
                    {
                        room.CurrentRoomStatusId = roomStatusTypeId;
                        if(roomStatusTypeId=='1')
                        {
                            room.CurrentRoomStatus="Ready";
                        }
                        else if(roomStatusTypeId=='2')
                        {
                            room.CurrentRoomStatus="Dirty";
                        }
                        else if(roomStatusTypeId=='3')
                        {
                            room.CurrentRoomStatus="Clean";
                        }
                    }
                });
            });
        }

        $scope.SaveRoomStatus = function (frm) {
            
            if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId != 1 && frm)
            {
                if ($scope[frm].$valid) {
                } else {
                    scrollPageOnTop();
                    $scope.ShowErrorManagementBlock = true;
                    return;
                }
            }
            
            if (!$scope.Model.FromRoomDay.RoomStatus.MaintenanceTypeId && $scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId==5) {
                $scope.ShowErrorMaintenanceType = true;
                return;
            }

            $scope.Model.FromRoomDay.RoomStatus.PropertyID = $scope.PropertyID;
            $scope.Model.FromRoomDay.RoomStatus.ModifiedBy = $scope.ModifiedBy;
            $scope.Model.FromRoomDay.RoomStatus.DateFormat = $scope.DateFormat;
            $scope.Model.FromRoomDay.RoomStatus.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

            var roomStatus = angular.copy($scope.Model.FromRoomDay.RoomStatus);
            roomStatus.FromDate = GetServerDate(roomStatus.FromDate, $scope.DateFormat);
            roomStatus.ToDate = GetServerDate(roomStatus.ToDate, $scope.DateFormat);
            
            if($scope.Model.FromRoomDay.RoomStatus.CheckINGuestRoomId)
            {
                roomStatus.CheckINGuestRoomId = $scope.Model.FromRoomDay.RoomStatus.CheckINGuestRoomId
                if($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId=='3')
                {
                    roomStatus.RoomStatusTypeId='7';
                }
                else if($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId=='4')
                {
                    roomStatus.RoomStatusTypeId='8';
                }
            }
            var promiseGet = roomChartService.saveRoomStatus(roomStatus);
            promiseGet.then(function (details) {

                //$scope.SetStatus();
                scrollPageOnTop();

                var msg = "";
                if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 1) {
                    msg = "Room Status changed to Ready.";
                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 2) {
                    
                    var fromdate = GetMomentDate($scope.Model.FromRoomDay.RoomStatus.FromDate, $scope.DateFormat);
                    var businessDate = GetMomentDate($scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day, "YYYY-MM-DD")

                    if (businessDate.isSame(fromdate))
                    {
                        msg = "Room Status changed to Dirty.";
                    }
                    else
                    {
                        msg = "Room Released successfully.";
                    }

                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 3) {
                    msg = "Room Status changed to Clean.";
                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 4) {
                    if($scope.Model.FromRoomDay.RoomStatus.IsExtend)
                    {
                        msg = "Room Status changed successfully.";
                    }
                    else
                    {
                        msg = "Room Status changed as Management Block .";
                    }
                }
                else if ($scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId == 5) {
                    if($scope.Model.FromRoomDay.RoomStatus.IsExtend)
                    {
                        msg = "Room Status changed successfully.";
                    }
                    else
                    {
                        msg = "Room Status changed as Maintenance Block.";
                    }
                }
                
                $("#cleanModel").modal('hide');
                $("#maintenanceBlockModel").modal('hide');
                $("#managementBlockModel").modal('hide');
                
                parent.successMessage(msg);

                $scope.UpdateRoomChartRoomStatus($scope.Model.FromRoomMasterId,$scope.Model.FromRoomDay.RoomStatus.RoomStatusTypeId);
                $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};
                
                //$scope.RoomChart={};
                //$scope.GetRoomChart();
                

            },
            function (xhr) {
                parent.popErrorMessage(xhr.Message);
            });
            scrollPageOnTop();

        };
       
        $scope.open = function () {
            $scope.showModal = true;
            $("#action").modal('show');
        };

        $scope.ok = function () {
            $scope.showModal = false;
        };

        $scope.cancel = function () {
            $scope.showModal = false;
        };
        
        $scope.Departments = [];
        $scope.Reasons = [];

        function GetDepartment() {
            var promiseGet = roomChartService.getDepartment($scope.PropertyID);
            promiseGet.then(function (data) {
                
                $scope.Departments = data;

            },
                function (data) {
                    parent.failureMessage(data.message);
                    $scope.HideLoader();

                });
        };

        function GetReason() {
            
            var promiseGet = roomChartService.getReason($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.Reasons = data;
                $scope.HideLoader();
            },
            function (data) {
                parent.failureMessage(data.message);
                scrollPageOnTop();
                $scope.HideLoader();
            });
        };

        $scope.GetTotalAdvance = function (roomDay) {
            var total = 0;
            if(roomDay)
            {
                angular.forEach(roomDay.CurrentCheckINGuests, function (item) {
                    total += item.AdvanceAmount;
                });
            }
            return total;
        };

        //Room Transfer
        $scope.RoomTransfer = {
            FromCheckINGuestRoomId: '',
            ToId: '',
            RoomMoveTypeId: '',
            RoomMoveTypeName: '',
            IsUpgrade: '',
            BusinessDate: '',
            ReasonId: '',
            RoomMoveRemark: '',
        };
        $scope.SaveRoomTransfer = function (frm) {
            
            if ($scope[frm].$valid) {
                $scope.RoomTransfer.PropertyID = $scope.PropertyID;
                $scope.RoomTransfer.ModifiedBy = $scope.ModifiedBy;
                $scope.RoomTransfer.DateFormat = $scope.DateFormat;
                if($scope.RoomTransfer.RoomMoveTypeId=='2')
                {
                    $scope.RoomTransfer.ToRoomId= $scope.RoomTransfer.ToId;
                    var promiseGet = roomChartService.saveRoomTransfer($scope.RoomTransfer);
                    promiseGet.then(function (result) {
                        
                        var newCheckINGuestRoomId= result.Data;

                        scrollPageOnTop();
                        $("#roomTransferModel").modal('hide');
                        $("#roomMoveModel").modal('hide');

                        if ($scope.RoomTransfer.RoomMoveTypeId == 2)
                        {
                            parent.successMessage("Room Transfer Successfully Saved.");
                        }
                        else if ($scope.RoomTransfer.RoomMoveTypeId == 3)
                        {
                            parent.successMessage("Room Swap Successfully Saved.");
                        }

                        
                        //$scope.GetRoomChart();
                        $scope.UpdateRoomChartRoomTransfer($scope.Model,$scope.RoomTransfer.ToRoomId,$scope.RoomTransfer.FromDate,$scope.RoomTransfer.ToDate, newCheckINGuestRoomId);
                        
                        $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};
                        
                    },
                    function (xhr) {
                        msg(xhr.Message);
                    });
                    scrollPageOnTop();
                }
               

            } else {
                scrollPageOnTop();
                $scope.ShowErrorRoomTransfer = true;
                return;
            }
        };
        $scope.UpdateRoomChartRoomTransfer = function(model,toRoomId,fromDate,toDate,newCheckINGuestRoomId)
        {
            
            var data = model.FromRoomDay.Content.split('$');
            var newContent = data[0] + '$' + newCheckINGuestRoomId + '$' + data[2] + '$' + data[3] + '$' + data[4] + '$' + data[5] + '$' + data[6] + '$' +  data[7];

            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
           
            angular.forEach(roomChart.RoomTypes,function(roomType){
                if(model.FromRoomTypeId == roomType.Id)
                {
                    var arrivalDate = GetMomentDate(fromDate, $scope.DateFormat);
                    var departureDate = GetMomentDate(toDate, $scope.DateFormat);

                    var emptyRoomDays=[];
                    var roomCopy={};

                    angular.forEach(roomType.Rooms,function(room){
                        
                        if(model.FromRoomMasterId == room.Id)
                        {
                            room.CurrentRoomStatusId = '2';
                            room.CurrentRoomStatus = 'Dirty';
                        }

                        if(toRoomId == room.Id)
                        {
                            room.CurrentRoomStatusId = '3';
                            room.CurrentRoomStatus = 'Clean';

                            roomCopy = angular.copy(room);
                            var nights = departureDate.diff(arrivalDate, 'days');
                            var startDay=0;
                            var endDay=nights;
                            var i=0;
                            var isEmpty=true;

                            for (var m = moment(arrivalDate) ; m.isBefore(departureDate) ; m.add(1, 'days')) {
                                var futureDate = ConvertDateToServerDate(m);
                                //AM
                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                if(emptyRoomDays.length==0)
                                {
                                    isEmpty=false;
                                }
                                //PM
                                emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                if(emptyRoomDays.length==0)
                                {
                                    isEmpty=false;
                                }
                            }
                            if(isEmpty)
                            {
                                //Set ReservationStatus
                                for (var m = moment(arrivalDate) ; m.diff(departureDate, 'days') <= 0 ; m.add(1, 'days')) {
                                    var futureDate = ConvertDateToServerDate(m);
                                    if(i==startDay)
                                    {
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =newContent;
                                            var data =newContent.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                        });
                                    }
                                    else if(i==endDay)
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =newContent;
                                            var data = newContent.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                        });
                                    }
                                    else
                                    {
                                        //AM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='AM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =newContent;
                                            var data = newContent.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                        });
                                        //PM
                                        emptyRoomDays = room.Days.filter(x=>x.Day.FutureDate == futureDate && x.DayPart=='PM' && x.RoomStatusTypeId == '1');
                                        angular.forEach(emptyRoomDays,function(roomDay){
                                            roomDay.Content =newContent;
                                            var data = newContent.split('$');
                                            roomDay.RoomStatusTypeId=data[0];
                                            roomDay.CheckINGuestRoomId = data[1];
                                            roomDay.CheckINId = data[2];
                                        });
                                    }
                                    i++;
                                }
                            }
                        }
                    });
                }
            });

            $scope.RoomChart =roomChart;
            $scope.UpdateRoomChartCheckINGuestRoomDelete(model.FromRoomDay.CheckINGuestRoomId);

            $scope.UpdateRoomChartAvailability();
            $timeout(function () {
                $scope.MonthColMarge();
                $scope.ColMarge1();
                $scope.HideLoader();
                $scope.load1($(".followMeBar"));
            }, 300); 
        }
        
        //END Room Transfer



        var $window = $(window),
                $stickies;

        $scope.load1 = function (stickies) {

            if (typeof stickies === "object" && stickies instanceof jQuery && stickies.length > 0) {

                $stickies = stickies.each(function () {
                    
                    var $thisSticky = $(this).wrap('<div class="followWrap" />');

                    $thisSticky
                        .data('originalPosition', $thisSticky.offset().top)
                        .data('originalHeight', $thisSticky.outerHeight())
                          .parent()
                          .height($thisSticky.outerHeight());
                });

                $window.off("scroll.stickies").on("scroll.stickies", function () {
                    $scope._whenScrolling();
                });
            }
        };

        $scope.IsStickyDayName = false;
        $scope._whenScrolling = function () {
            $stickies.each(function (i) {
                var $thisSticky = $(this),
                    $stickyPosition = $thisSticky.data('originalPosition');

                if ($stickyPosition <= $window.scrollTop()) {

                    var $nextSticky = $stickies.eq(i + 1),
                        $nextStickyPosition = $nextSticky.data('originalPosition') - $thisSticky.data('originalHeight')-63;

                    angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                        if ($thisSticky.context.innerText.indexOf(roomType.Name) !== -1) {
                            //$scope.$apply(function () {
                            //    roomType.IsStickyDayName = true;
                            //});

                            $timeout(function(){ 
                                roomType.IsStickyDayName = true;
                            });

                        }
                        else {
                            //$scope.$apply(function () {
                            //    roomType.IsStickyDayName = false;
                            //});

                            $timeout(function(){ 
                                roomType.IsStickyDayName = false;
                            });
                        }
                    });

                    
                    $thisSticky.addClass("fixed");
                    if ($nextSticky.length > 0 && $thisSticky.offset().top >= $nextStickyPosition) {
                        $thisSticky.addClass("absolute").css("top", $nextStickyPosition);
                    }
                } else {

                    var $prevSticky = $stickies.eq(i - 1);

                    $thisSticky.removeClass("fixed");

                    if ($prevSticky.length > 0 && $window.scrollTop() <= $thisSticky.data('originalPosition') - $thisSticky.data('originalHeight')) {
                        $prevSticky.removeClass("absolute").removeAttr("style");
                    }
                }
            });
        };

        $scope.Previous = {};
        $scope.Next = {};

        $scope.PreMonth = "";
        $scope.NextMonth = "";
        $scope.PreDay = "";
        $scope.NextMonth = "";

        $scope.NextMonth = function(day)
        {
            
            //var startDay = $filter('date')(day.FutureDate, $scope.DateFormat);
            //var sdate = GetMomentDate(startDay, $scope.DateFormat);
            //var edate = GetMomentDate(startDay, $scope.DateFormat).add(30, 'days');
            //$scope.date = {
            //    startDate: GetLocalDate(sdate, $scope.DateFormat),
            //    endDate: GetLocalDate(edate, $scope.DateFormat),
            //};

            $scope.date = {
                startDate: GetLocalDate(GetMomentDate($scope.date.startDate, $scope.DateFormat).add(CalendarLength, 'days'), $scope.DateFormat),
                endDate: GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(CalendarLength, 'days'), $scope.DateFormat),
            };

            $scope.GetDays();
        }
        $scope.PreMonth = function (day) {
            
            //var endDay = $filter('date')(day.FutureDate, $scope.DateFormat);
            //var edate = GetMomentDate(endDay, $scope.DateFormat).add(-30, 'days');;
            //var sdate = GetMomentDate(endDay, $scope.DateFormat).add(-60, 'days');
            //$scope.date = {
            //    startDate: GetLocalDate(sdate, $scope.DateFormat),
            //    endDate: GetLocalDate(edate, $scope.DateFormat),
            //};
            $scope.date = {
                startDate: GetLocalDate(GetMomentDate($scope.date.startDate, $scope.DateFormat).add(-CalendarLength, 'days'), $scope.DateFormat),
                endDate: GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-CalendarLength, 'days'), $scope.DateFormat),
            };
            $scope.GetDays();
        }

        $scope.NextDay = function (day) {
            //var startDay = $filter('date')(day.FutureDate, $scope.DateFormat);
            //var edate = GetMomentDate(startDay, $scope.DateFormat).add(1, 'days');
            //var sdate = GetMomentDate(startDay, $scope.DateFormat).add(1, 'days').add(-30, 'days');
            //$scope.date = {
            //    startDate: GetLocalDate(sdate, $scope.DateFormat),
            //    endDate: GetLocalDate(edate, $scope.DateFormat),
            //};

            $scope.date = {
                startDate: GetLocalDate(GetMomentDate($scope.date.startDate, $scope.DateFormat).add(1, 'days'), $scope.DateFormat),
                endDate: GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(1, 'days'), $scope.DateFormat),
            };
            $scope.GetDays();
        }
        $scope.PreDay = function (day) {
            
            //var endDay = $filter('date')(day.FutureDate, $scope.DateFormat);
            //var edate = GetMomentDate(endDay, $scope.DateFormat).add(-1, 'days');;
            //var sdate = GetMomentDate(endDay, $scope.DateFormat).add(-1, 'days').add(-30, 'days');
            //$scope.date = {
            //    startDate: GetLocalDate(sdate, $scope.DateFormat),
            //    endDate: GetLocalDate(edate, $scope.DateFormat),
            //};
            $scope.date = {
                startDate: GetLocalDate(GetMomentDate($scope.date.startDate, $scope.DateFormat).add(-1, 'days'), $scope.DateFormat),
                endDate: GetLocalDate(GetMomentDate($scope.date.endDate, $scope.DateFormat).add(-1, 'days'), $scope.DateFormat),
            };

            $scope.GetDays();
        }

        //Search
        $scope.GetSetting =function(){
            $scope.getBlock();
            $scope.getRoomFeature();
            $scope.getFloor();
            $scope.getRoomFeatureRoom();
        };
        
        $scope.getRoomCustom = function () {
            $scope.Rooms = [];
            roomChartService.getRoomCustom($scope.PropertyID)
                   .then(function (result) {
                       
                       //$scope.Rooms = result.Collection;
                       $scope.LinkRooms = result.Collection.filter(x=>x.IsLinkRoom ==true);

                       //
                       //angular.forEach($scope.RoomChart.RoomTypes,function(roomType) {
                       //    angular.forEach(roomType.Rooms,function(r) {
                       
                       //        angular.forEach($scope.LinkRooms,function(linkRoom) 
                       //        {
                       //            var linkRooms =[];
                       //            if(linkRoom.Id == r.Id)
                       //            {
                       //                r.IsLinkRoom = true;
                       //                angular.forEach(linkRoom.LinkRooms,function(item) {
                       //                    linkRooms.push({Id:item.LinkRoomMasterId,Name:item.LinkRoomNumber});
                       //                });
                       //            }
                       //            r.LinkRooms = linkRooms;
                       //        });
                       //    });
                       //});


                   }, function (err) {
                       msg(err.Message);
                   });
        };
        
        $scope.getFloor = function () {
            $scope.Floors = [];
            roomChartService.getFloor($scope.PropertyID)
                   .then(function (result) {
                       $scope.Floors = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getRoomFeature = function () {
            $scope.RoomFeatures = [];
            roomChartService.getRoomFeature($scope.PropertyID)
                   .then(function (result) {
                       $scope.RoomFeatures = result.Collection;
                       
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getBlock = function () {
            $scope.Blocks = [];
            roomChartService.getBlock($scope.PropertyID)
                   .then(function (result) {
                       $scope.Blocks = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.getRoomFeatureRoom = function () {
            
            $scope.RoomFeatureRooms = [];
            roomChartService.getRoomFeatureRoom($scope.PropertyID)
                   .then(function (result) {
                       $scope.RoomFeatureRooms = result.Data[0];
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        //checklist-model------------------------------------------------------------------------------------

        //$scope.RoomTypes = [];
        $scope.SelectedSearchRoomType = {
            RoomTypes: []
        };
        $scope.checkAllRoomType = function () {
            $scope.SelectedSearchRoomType.RoomTypes = $scope.RoomTypes.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllRoomType = function () {
            $scope.SelectedSearchRoomType.RoomTypes = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstRoomType = function () {
            $scope.SelectedSearchRoomType.RoomTypes.splice(0, $scope.SelectedSearchRoomType.RoomTypes.length);
            $scope.SelectedSearchRoomType.RoomTypes.push(1);
        };

        $scope.SelectedSearchFloor = {
            Floors: []
        };
        $scope.checkAllFloor = function () {
            $scope.SelectedSearchFloor.Floors = $scope.Floors.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllFloor = function () {
            $scope.SelectedSearchFloor.Floors = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstFloor = function () {
            $scope.SelectedSearchFloor.Floors.splice(0, $scope.SelectedSearchFloor.Floors.length);
            $scope.SelectedSearchFloor.Floors.push(1);
        };

        $scope.SelectedSearchBlock = {
            Blocks: []
        };
        $scope.checkAllBlock = function () {
            $scope.SelectedSearchBlock.Blocks = $scope.Blocks.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllBlock = function () {
            $scope.SelectedSearchBlock.Blocks = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstBlock = function () {
            $scope.SelectedSearchBlock.Blocks.splice(0, $scope.SelectedSearchBlock.Blocks.length);
            $scope.SelectedSearchBlock.Blocks.push(1);
        };

        $scope.SelectedSearchRoomFeature = {
            RoomFeatures: []
        };
        $scope.checkAllRoomFeature = function () {
            
            $scope.SelectedSearchRoomFeature.RoomFeatures = $scope.RoomFeatures.map(function (item) { return item.Id; });
            $scope.SearchRoom();
        };
        $scope.uncheckAllRoomFeature = function () {
            $scope.SelectedSearchRoomFeature.RoomFeatures = [];
            $scope.SearchRoom();
        };
        $scope.checkFirstRoomFeature = function () {
            $scope.SelectedSearchRoomFeature.RoomFeatures.splice(0, $scope.SelectedSearchRoomFeature.RoomFeatures.length);
            $scope.SelectedSearchRoomFeature.RoomFeatures.push(1);
        };

        //end checklist-model------------------------------------------------------------------------------------

        $scope.searchModel = function () {
            $scope.SearchCount = 0;
            $scope.SearchRooms = [];
            $scope.BalanceRooms = [];
            $scope.ResetIsFindTrue();
            $scope.GetSetting();

            $scope.SelectedRoomLinkRooms=[];
            $("#searchModel").modal('show');
        }
        $scope.SearchRooms = [];
        $scope.SearchCount = 0;

        $scope.SearchRoom = function () {
            
            $scope.SearchCount = 0;
            $scope.SearchRooms = [];
            $scope.BalanceRooms = [];
            $scope.ResetIsFindTrue();

            //RoomType
            $scope.SearchRoomTypes = [];
            if ($scope.SelectedSearchRoomType.RoomTypes.length > 0)
            {
                angular.forEach($scope.SelectedSearchRoomType.RoomTypes, function (id) {
                    angular.forEach($scope.Rooms, function (room) {
                        if (id == room.RoomTypeId) {
                            $scope.SearchRoomTypes.push(room);
                        }
                    });
                });
            }
            else
            {
                $scope.SearchRoomTypes = $scope.Rooms;
            }
            //Floor
            $scope.SearchFloors = [];
            if ($scope.SelectedSearchFloor.Floors.length > 0 && $scope.SearchRoomTypes.length > 0) {
                angular.forEach($scope.SelectedSearchFloor.Floors, function (id) {
                    angular.forEach($scope.SearchRoomTypes, function (room) {
                        if (id == room.FloorId) {
                            //$scope.SearchRooms.push({ Id: room.Id });
                            $scope.SearchFloors.push(room);
                            //$scope.AddSearchRoom(room.Id);
                        }
                    });
                });
            }
            else
            {
                $scope.SearchFloors = $scope.SearchRoomTypes;
            }
            
            //Block
            $scope.SearchBlocks = [];
            if ($scope.SelectedSearchBlock.Blocks.length > 0 && $scope.SearchFloors.length > 0) {
                angular.forEach($scope.SelectedSearchBlock.Blocks, function (id) {
                    angular.forEach($scope.SearchFloors, function (room) {
                        if (id == room.BlockId) {
                            //$scope.SearchRooms.push({ Id: room.Id });
                            $scope.SearchBlocks.push(room);
                            // $scope.AddSearchRoom(room.Id);
                        }
                    });
                });
            }
            else
            {
                $scope.SearchBlocks = $scope.SearchFloors;
            }
            
            //Mini Bar
            $scope.SearchMiniBars = [];
            if ($scope.SearchIsMiniBar && $scope.SearchBlocks.length > 0) {
                angular.forEach($scope.SearchBlocks, function (room) {
                    if (room.IsMiniBar == true) {
                        //$scope.SearchRooms.push({ Id: room.Id });
                        $scope.SearchMiniBars.push(room);
                        //$scope.AddSearchRoom(room.Id);
                    }
                });
            }
            else {
                $scope.SearchMiniBars = $scope.SearchBlocks;
            }
            
            //RoomFeature
            $scope.SearchRoomFeatures = [];
            if ($scope.SelectedSearchRoomFeature.RoomFeatures.length > 0 && $scope.SearchMiniBars.length > 0) {
                angular.forEach($scope.SearchMiniBars, function (room) {
                    var selectedRoomFeatures = [];
                    angular.forEach($scope.SelectedSearchRoomFeature.RoomFeatures, function (id) {
                        selectedRoomFeatures.push({ Id: id, IsFind: false });
                    });
                    
                    room.RoomFeatures=[];
                    room.RoomFeatures = $scope.RoomFeatureRooms.filter(x=>x.RoomMasterId == room.Id);
                    angular.forEach(room.RoomFeatures, function (roomFeature) {
                        angular.forEach(selectedRoomFeatures, function (selectedRoomFeature) {
                            if (selectedRoomFeature.Id == roomFeature.RoomFeatureId) {
                                selectedRoomFeature.IsFind = true;
                            }
                        });
                    });
                    var IsFind = true;
                    angular.forEach(selectedRoomFeatures, function (item) {
                        if (item.IsFind == false) {
                            IsFind = false;
                        }
                    });
                    if (IsFind && selectedRoomFeatures.length > 0) {
                        //$scope.SearchRooms.push({ Id: room.Id });
                        $scope.SearchRoomFeatures.push(room);
                        //$scope.AddSearchRoom(room.Id);
                    }
                });
            }
            else {
                $scope.SearchRoomFeatures = $scope.SearchMiniBars;
            }

            //Mini Bar
            $scope.SearchLinkRooms = [];
            if ($scope.SearchIsLinkRoom && $scope.SearchRoomFeatures.length > 0) {
                angular.forEach($scope.SearchRoomFeatures, function (room) {
                    angular.forEach($scope.LinkRooms, function (linkRoom) {
                        if (room.Id == linkRoom.Id) {
                            $scope.SearchLinkRooms.push(room);
                        }
                    });
                });
            }
            else {
                $scope.SearchLinkRooms = $scope.SearchRoomFeatures;
            }

            if ($scope.SearchLinkRooms.length > 0) {
                $scope.ResetIsFindFalse();
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    angular.forEach(roomType.Rooms, function (room) {
                        angular.forEach($scope.SearchLinkRooms, function (searchRoom) {
                            if (searchRoom.Id == room.Id) {
                                room.IsShow = true;
                                $scope.SearchCount = $scope.SearchCount +1;
                            }
                        });
                    });
                });
            }
            else
            {
                $scope.ResetIsFindFalse();
            }
        }

        $scope.ResetIsFindTrue = function () {
            $scope.SearchCount = 0;
            if ($scope.RoomChart)
            {
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    angular.forEach(roomType.Rooms, function (room) {
                        room.IsShow = true;
                        $scope.SearchCount = $scope.SearchCount + 1;
                    });
                });
            }
        }
        $scope.ResetIsFindFalse = function () {
            $scope.SearchCount = 0;
            if ($scope.RoomChart) {
                angular.forEach($scope.RoomChart.RoomTypes, function (roomType) {
                    angular.forEach(roomType.Rooms, function (room) {
                        room.IsShow = false;
                    });
                });
            }
        }

        $scope.AddSearchRoom = function(id)
        {
            var isFind = false;
            angular.forEach($scope.SearchRooms, function (item) {
                if(item.Id == id)
                {
                    isFind = true;
                }
            });

            if(!isFind)
            {
                $scope.SearchRooms.push({ Id: id });
            }
        }

        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        }

        $scope.ShowLoader = function () {
            $('#roomChart').hide('slow');
        }

        $scope.HideLoader = function () {
            if ($('#roomChart').css('display') == 'none') {
                $('#roomChart').show('slow');
                //$('#loader').hide('slow');
            }
        }

        //CheckIN
        $scope.ReservationId='';
        $scope.$on("CallOpenRoomChartCheckIN", function (event, obj) {
            if(!$scope.IsModify )
            {
                if($scope.InjectCheckINModel)
                {
                    $rootScope.$broadcast("CallWalkIN", $scope.InjectCheckINModel);
                    $("#checkINModel").modal('show');
                }
            }
            else
            {
                $scope.IsModify = true;
                $rootScope.$broadcast("CallCheckINLoadReservation", {ReservationId:$scope.ReservationId, Mode:'Modify', RoomChart:$scope.RoomChart});
                $scope.ReservationId='';
            }
            



            //var model = {IsWalkIN : false}

            //if($scope.ArrivalDate && $scope.DepartureDate && $scope.Model.ToRoomTypeId)
            //{
            //    $scope.AvailableRooms = $scope.GetRoomForCheckIN($scope.ArrivalDate,$scope.DepartureDate, $scope.Model.ToRoomTypeId);
            //    model = {
            //        ArrivalDate: $scope.Model.FromRoomDay.Day.FutureDate,//ArrivalDate,
            //        DepartureDate: $scope.Model.ToRoomDay.Day.FutureDate,// $scope.DepartureDate,
            //        RoomTypeId: $scope.Model.FromRoomTypeId,
            //        RoomTypeName: $scope.Model.FromRoomTypeName,
            //        RoomMasterId: $scope.Model.FromRoomMasterId,
            //        RoomNumber: $scope.Model.FromRoomMasterName,
            //        MyRoomList: $scope.MyRoomList,
            //        AvailableRooms: $scope.AvailableRooms,
            //        PropertyID: $scope.PropertyID,
            //        IsWalkIN : true
            //    };
            //}
            //$timeout(function() { 
            //    $rootScope.$broadcast("CallWalkIN", model);
            //    $("#checkINModel").modal('show');
            //    $scope.ProgressEnd();
            //}, 2000)
        });


        $scope.$on("CallCheckINLoaded", function (event, obj) {
            $("#actionReservationModel").modal('hide');
            $("#checkINModel").modal('show');
            $scope.ProgressEnd();
        });

        $scope.CallCheckINLoadReservation = function(reservationId){
            

            if(reservationId=='undefined')
            {return;}
            $scope.IsModify = true;
            scrollPageOnTop();
            $scope.ReservationId=reservationId;
            
            if($scope.IsCheckINView)
            {
                $rootScope.$broadcast("CallOpenRoomChartCheckIN", null);
            }
            else
            {
                $scope.IsModify = false;
                $scope.IsCheckINView = true;
            }

            //$timeout(function() { 
            //    $rootScope.$broadcast("CallCheckINLoadReservation", {ReservationId:reservationId});
            //    $scope.ProgressEnd();
            //}, 4000);
            //$("#actionReservationModel").modal('hide');
            //$scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};

            //$scope.UpdateRoomChartAvailability();
            //$timeout(function () {
            //    $scope.MonthColMarge();
            //    $scope.ColMarge1();
                        
            //    $scope.HideLoader();
            //    //$scope.ResetSelection();
            //    $scope.load1($(".followMeBar"));
            //    GetDepartment();
            //    GetReason();
            //    $scope.getRoomCustom();
                        
            //}, 200); // 3 seconds
        }

        //Reservation
        
        $scope.IsModify = false;
        $scope.$on("CallOpenRoomChartReservation", function (event, obj) {
            if(!$scope.IsModify )
            {
                $scope.CallShowScreen1();
                if($scope.InjectReservationModel)
                {
                    $rootScope.$broadcast("CallAddReservationRoomType", $scope.InjectReservationModel);    
                    $("#reservationModel").modal('show');
                }
            }
            else
            {
                $scope.IsModify = true;
                $rootScope.$broadcast("CallReservationModify", {ReservationId:$scope.ReservationId, Mode:'Modify', RoomChart:$scope.RoomChart});
            }
        });

        $scope.CallReservationModify = function(reservationId,mode){
            
            $scope.IsModify = true;
            //$scope.ProgressStart();
            scrollPageOnTop();
            $scope.ReservationId=reservationId;
            if($scope.IsReservationView)
            {
                $rootScope.$broadcast("CallOpenRoomChartReservation", {ReservationId:reservationId, Mode:mode});
            }
            else{
                $scope.IsReservationView = true;
            }
            
            //$timeout(function() { 
                
            //    $scope.ProgressEnd();
            //}, 4000);
            //$("#actionReservationModel").modal('hide');
            
            //if(!$scope.Model.FromRoomDay.RoomStatusTypeId)
            //{
            //    $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};
            //}

            //$scope.ProgressStart();
            //scrollPageOnTop();
            //$scope.IsReservationView = true;
            //$timeout(function() { 
            //    $rootScope.$broadcast("CallReservationModify", {ReservationId:reservationId, Mode:mode});
            //    $scope.ProgressEnd();
            //}, 4000);
            //$("#actionReservationModel").modal('hide');
            
            //if(!$scope.Model.FromRoomDay.RoomStatusTypeId)
            //{
            //    $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};
            //}
        }
        $scope.$on("CallOpenRoomChartReservationModify", function (event, obj) {
            
            $("#reservationModel").modal('show');
            $("#actionReservationModel").modal('hide');
            $scope.ProgressEnd();
        });
        $scope.IsReservationSaveActive=false;
        $scope.$on("CallIsReservationSaveActive", function (event, obj) {
            $scope.IsReservationSaveActive=obj.IsActive;
        });
        //$scope.CancelReservation = function () {
        //    $rootScope.$broadcast("CallRoomChartCancelReservation", {});
        //};
        $scope.CancelReservation = function (reservationId) {
            $scope.reservationId=reservationId;
            $("#actionReservationModel").modal('hide');
            GetReason();
            $("#cancelBox").modal('show');
        };
        $scope.CancelReservationConfirm = function (form) {
            
            if ($scope[form].$valid) {

                var model = {
                    Id: $scope.reservationId,
                    ReservationDate: $scope.MinDate,
                    ReasonId: $scope.ReasonId,
                    CancellationRemark : $scope.CancellationRemark,
                    PropertyID: $scope.PropertyID,
                    ModifiedBy: $scope.UserName,
                };

                var promiseGet = roomChartService.cancelReservationConfirm(model);
                promiseGet.then(function (data) {
                    parent.posSuccessMessage("Reservation " + data.Message);

                    $scope.Model = data.Data;
                    $scope.UpdateRoomChartNOShow($scope.reservationId);
                    $scope.ResetSelection(); 
                    $("#cancelBox").modal('hide');
                    $scope.Reset();
                    $scope.reservationId="";
                    scrollPageOnTop();

                },
                    function (error) {
                        //parent.posFailureMessage(error.data.Message);
                        parent.popErrorMessage(error.responseJSON.Message); scrollPageOnTop();
                        //CallRoomChartIsReservationSaveActive(false);
                    });
            } 

        };
        $scope.IsNOShow = false;
        $scope.NowShoRemark = "";

        $scope.SaveNOShow = function () {

            $("#actionReservationModel").modal('hide');

            if(!$scope.Model.FromRoomDay)
            {
                parent.popErrorMessage('Select Reservation.');
                return;
            }
            if ($scope.IsNOShow) {

                if($scope.Model.FromRoomDay.ReservationId)
                {
                    var reservationId = $scope.Model.FromRoomDay.ReservationId;
                    var model = {
                        Id         : reservationId,
                        ReasonId   : $scope.ReasonId,
                        CancellationRemark     :$scope.NowShoRemark,
                        PropertyID : $scope.PropertyID,
                        ModifiedBy : $scope.UserName,
                        DateFormat : $scope.DateFormat,
                    }
                    var promiseGet = roomChartService.noShow(model);
                    promiseGet.then(function (data, status) {

                        //$scope.GetRoomChart();
                        $scope.UpdateRoomChartNOShow($scope.Model.FromRoomDay.ReservationId);
                        $scope.IsNOShow = false;
                        $scope.NowShoRemark = "";
                        parent.successMessage("NO Show marked.");
                        $('#actionConfirmationModel').modal('hide');
                        $('#noshowbox').modal('hide');

                    }, function (error, status) {
                        parent.popErrorMessage(error.Message);
                    });
                }
                else
                {
                    parent.popErrorMessage('Select Reservation.');
                    return;
                }
            }
        };

        $scope.UpdateRoomChartNOShow = function(reservationId)
        {
            var roomChart = angular.copy($scope.RoomChart);
            $scope.RoomChart ={};
            angular.forEach(roomChart.RoomTypes,function(roomType){
                angular.forEach(roomType.Rooms,function(room){
                    angular.forEach(room.Days,function(roomDay){
                        if(roomDay.ReservationId  == reservationId)
                        {       
                            roomDay.RoomStatusTypeId='1';
                            roomDay.ReservationRoomTypeId = '';
                            roomDay.ReservationId  = '';
                            roomDay.GuestName  = '';
                            roomDay.FromDateStr= ''; 
                            roomDay.ToDateStr= '';
                            roomDay.Content = '';
                            roomDay.BookingTypeId= '1';
                        }
                    });
                });
            });
            $timeout(function () {
                $scope.RoomChart =roomChart;
                $scope.UpdateRoomChartAvailability();
            }, 200); 
            $timeout(function () {
                $scope.MonthColMarge();
                $scope.ColMarge1();
                $scope.HideLoader();
                $scope.load1($(".followMeBar"));
            }, 300); 
        }

        //-------POST CHARGE
        $scope.SelectedFromRoomDay={};
        $scope.CallPostCharge = function(roomDay){
            
            $scope.SelectedFromRoomDay = roomDay;
            $scope.SelectedFromRoomDay.CurrentCheckINGuests.CheckINGuestRoomId=roomDay.CheckINGuestRoomId;
            
            if($scope.IsChasieringView)
            {
                $rootScope.$broadcast("CallPostChargeOpen", {});

            }
            else
            {
                $scope.IsChasieringView = true;
            }
        }

        $scope.$on("CallPostChargeOpen", function (event, obj) {
            $rootScope.$broadcast("CallPostCharge", {CurrentCheckINGuests:$scope.SelectedFromRoomDay.CurrentCheckINGuests});
        }); 

        $scope.$on("CallOpenPostCharge", function (event, obj) {
            $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};
            $("#actionCheckINModel").modal('hide');
            $("#postingModal").modal('show');
        }); 

        $scope.$on("CallRoomChartPostChargeMessage", function (event, obj) {
            
            if(obj.Status)
            {
                parent.popSuccessMessage(obj.Message);
            }
            else
            {
                parent.popErrorMessage(obj.Message);
                parent.posFailureMessage(obj.Message);
            }
            
        });
        $scope.$on("CallRoomChartReload", function (event, obj) {
            $scope.Model.FromRoomDay={
                RoomStatusTypeId:'1',
            };
            $("#postingModal").modal('hide');
            $scope.GetRoomChart();

        });
        
        //RoomBlock
        $scope.SaveRoomBlock = function (frm) {
            if ($scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId != 1 && frm)
            {
                if ($scope[frm].$valid) {
                } else {
                    scrollPageOnTop();
                    $scope.ShowErrorManagementBlock = true;
                    return;
                }
            }
            
            if (!$scope.Model.FromRoomDay.RoomBlock.MaintenanceTypeId && $scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId==5) {
                $scope.ShowErrorMaintenanceType = true;
                return;
            }

            $scope.Model.FromRoomDay.RoomBlock.PropertyID = $scope.PropertyID;
            $scope.Model.FromRoomDay.RoomBlock.ModifiedBy = $scope.ModifiedBy;
            $scope.Model.FromRoomDay.RoomBlock.DateFormat = $scope.DateFormat;
            $scope.Model.FromRoomDay.RoomBlock.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

            var roomBlock = angular.copy($scope.Model.FromRoomDay.RoomBlock);
            roomBlock.FromDate = GetServerDate(roomBlock.FromDate, $scope.DateFormat);
            roomBlock.ToDate = GetServerDate(roomBlock.ToDate, $scope.DateFormat);
            

            var promiseGet = roomChartService.SaveRoomBlock(roomBlock);
            promiseGet.then(function (result) {

                //$scope.SetStatus();
                scrollPageOnTop();

                var msg = "";
                if ($scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId == 4) {
                    if($scope.Model.FromRoomDay.RoomBlock.IsExtend)
                    {
                        msg = "Room Status changed successfully.";
                    }
                    else
                    {
                        msg = "Room Status changed as Management Block .";
                    }
                }
                else if ($scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId == 5) {
                    if($scope.Model.FromRoomDay.RoomBlock.IsExtend)
                    {
                        msg = "Room Status changed successfully.";
                    }
                    else
                    {
                        msg = "Room Status changed as Maintenance Block.";
                    }
                }
                
                $("#cleanModel").modal('hide');
                $("#maintenanceBlockModel").modal('hide');
                $("#managementBlockModel").modal('hide');
                
                parent.successMessage(msg);

                roomBlock.Id = result.Data.split('$')[1];
                roomBlock.Content = result.Data;

                var item ={
                    RoomTypeId : roomBlock.RoomTypeId,
                    RoomMasterId : roomBlock.RoomMasterId,
                    ArrivalDate : roomBlock.FromDate,
                    DepartureDate : roomBlock.ToDate,
                    Content : roomBlock.Content,
                };
                
                $scope.UpdateRoomChartRoomBlock(item);
                $scope.Model.FromRoomDay = {RoomStatusTypeId:'1'};


                $scope.UpdateRoomChartAvailability();
                $timeout(function () {
                    $scope.MonthColMarge();
                    $scope.ColMarge1();
                    $scope.HideLoader();
                    $scope.load1($(".followMeBar"));
                }, 200); // 3 seconds
                $scope.ProgressEnd();

            },
            function (xhr) {
                parent.popErrorMessage(xhr.Message);
            });
            scrollPageOnTop();

        };
        $scope.ReleaseRoomBlock = function (frm) {
            
            if ($scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId != 1 && frm)
            {
                if ($scope[frm].$valid) {
                } else {
                    scrollPageOnTop();
                    $scope.ShowErrorManagementBlock = true;
                    return;
                }
            }
            
            if (!$scope.Model.FromRoomDay.RoomBlock.MaintenanceTypeId && $scope.Model.FromRoomDay.RoomBlock.RoomStatusTypeId==5) {
                $scope.ShowErrorMaintenanceType = true;
                return;
            }

            $scope.Model.FromRoomDay.RoomBlock.PropertyID = $scope.PropertyID;
            $scope.Model.FromRoomDay.RoomBlock.ModifiedBy = $scope.ModifiedBy;
            $scope.Model.FromRoomDay.RoomBlock.DateFormat = $scope.DateFormat;
            $scope.Model.FromRoomDay.RoomBlock.BusinessDate = $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day;

            var roomBlock = {
                Id: $scope.Model.FromRoomDay.RoomBlock.Id,
                PropertyID : $scope.PropertyID,
                ModifiedBy : $scope.ModifiedBy,
                DateFormat : $scope.DateFormat,
                ReleasedDate : $scope.BusinessDate.Year + "-" + $scope.BusinessDate.Month + "-" + $scope.BusinessDate.Day,
                Remarks:$scope.Model.FromRoomDay.RoomBlock.Remarks,
            };


            var promiseGet = roomChartService.ReleaseRoomBlock(roomBlock);
            promiseGet.then(function (result) {

                //$scope.SetStatus();
                scrollPageOnTop();

                var msg = "";
                msg = "Room Release successfully.";
                
                $("#cleanModel").modal('hide');
                $("#maintenanceBlockModel").modal('hide');
                $("#managementBlockModel").modal('hide');
                
                parent.successMessage(msg);
                
                $scope.UpdateRoomChartRoomBlockDelete(roomBlock.Id)
                $scope.UpdateRoomChartAvailability();

                $scope.Model.FromRoomDay.RoomBlock={};

                $timeout(function () {
                    $scope.MonthColMarge();
                    $scope.ColMarge1();
                    $scope.HideLoader();
                    $scope.load1($(".followMeBar"));
                }, 200); // 3 seconds
                $scope.ProgressEnd();

            },
            function (xhr) {
                parent.popErrorMessage(xhr.Message);
            });
            scrollPageOnTop();

        };

        $scope.IsLoadingChangeRoomOutDate=false;

        $scope.ChangeRoomOutDate = function(checkINGuest){
            
            if($scope.IsLoadingChangeRoomOutDate)
            {
                return;
            }
            else
            {
                $scope.IsLoadingChangeRoomOutDate=true;
            }

            checkINGuest.IsLoadingChangeRoomOutDate=$scope.IsLoadingChangeRoomOutDate;
            var newRoomOUTDate =  GetServerDate(checkINGuest.NewRoomOUTDate, $scope.DateFormat) ;
            var bDate=   $scope.BusinessDate.Year +"-" + $scope.BusinessDate.Month +"-"+ $scope.BusinessDate.Day;

            var promiseGet = roomChartService.ChangeRoomOutDate(checkINGuest.Id, newRoomOUTDate,bDate);
            promiseGet.then(function (result) {
                if(result.Data == "Success")
                {
                    $scope.IsLoadingChangeRoomOutDate=false;
                    checkINGuest.IsLoadingChangeRoomOutDate=false;
                    
                    $scope.UpdateRoomChartCheckINGuestRoomDelete(checkINGuest.CheckINGuestRoom.Id);

                    parent.popSuccessMessage("Departure date change successfully.");
                    var room = checkINGuest.CheckINGuestRoom;

                    checkINGuest.NewRoomOUTDate = GetServerDate(checkINGuest.NewRoomOUTDate, $scope.DateFormat);;

                    room.RoomINDate = checkINGuest.RoomINDate;
                    room.RoomOUTDate = checkINGuest.NewRoomOUTDate;
                    checkINGuest.RoomOUTDate = checkINGuest.NewRoomOUTDate;
                    
                    $scope.UpdateRoomChartCheckIN(room);

                    $scope.UpdateRoomChartAvailability();
                    $timeout(function () {
                        $scope.MonthColMarge();
                        $scope.ColMarge1();
                        $scope.HideLoader();
                        $scope.load1($(".followMeBar"));

                        if($scope.Model.FromRoomDay.CurrentCheckINGuests.length==1)
                        {
                            $("#expecteddeparturepopup").modal('hide');
                        }
                        
                        scrollPageOnTop();
                        //$scope.Model={};
                    }, 300); 

                    
                }
            },
            function (message) {
                $scope.IsLoadingChangeRoomOutDate=false;
                checkINGuest.IsLoadingChangeRoomOutDate=false;
                parent.popErrorMessage(message);
            });
            scrollPageOnTop();
        }

        $scope.OpenExpectedDeparturePOP = function(){
            $scope.IsMouseDown=false;
            $("#expecteddeparturepopup").modal('show');
        }

        $scope.OpenAvailabilityPOP = function(){
            scrollPageOnTop();
            $("#AvailabilityPOP").modal('show');
        }

        $scope.UpdateInventory = function(roomType){

            //
            var sdate = GetServerDate($scope.date.startDate, $scope.DateFormat);
            var edate = GetServerDate($scope.date.endDate, $scope.DateFormat);

            angular.forEach($scope.RoomChart.RoomTypes ,function(roomType){
                var roomTypeInventoryViewModel = {
                    RoomTypeId:roomType.Id,
                    FromDate :sdate,
                    ToDate : edate,
                    BusinessDate : GetServerDate(businessDate, $scope.DateFormat),
                    PropertyID :$scope.PropertyID,
                    ModifiedBy :$scope.ModifiedBy,
                }; 

                var promiseGet = roomChartService.UpdateInventory(roomTypeInventoryViewModel);
                promiseGet.then(function (details) {
                    scrollPageOnTop();
                },
                function (xhr) {
                    parent.popErrorMessage(xhr.Message);
                });
                scrollPageOnTop();


            });

            msg("Inventory sent to Channel Manager.",true);
           
        }

        $scope.printReport = function (checkINGuestId,reportName) {
            
            roomChartService.MapReport($scope.PropertyID, reportName)
                .then(function (s) {
                    $window.open(origin + '/Reporter/ReportViewer?id=' + s.Data + '&pid=' + checkINGuestId, '_blank');
                }, function (e) {
                    $scope.IsSaved = true;
                    msg('Error in mapping to print.');
                }).finally(function () {
                    $scope.reset();
                });
        };

        $scope.IsSending=false;

        $scope.SendMail = function (id,smsTemplateTypeId) {
            $scope.IsSending=true;
            var promiseGet = roomChartService.SendMail(id, smsTemplateTypeId, $scope.PropertyID, $scope.MinDate);
            promiseGet.then(function (data, status) {
                scrollPageOnTop();
                $scope.IsSending=false;
                if (data.Status) {
                    parent.popSuccessMessage("E-Mail sent to User successfully!");
                }
                else
                {
                    parent.popErrorMessage(  "Error occured while sending the E-Mail!");
                }
            },
                function (error, status) {
                    $scope.IsSending=false;
                    parent.popErrorMessage(error.Message);
                    scrollPageOnTop();
                });

        }

        //Send EMail & SMS
        $scope.SendSMS = function (id) {
            $scope.IsSending=true;
            var model={};
            model.Id = id;
            model.ModifiedBy = $scope.UserName;
            model.PropertyID = $scope.PropertyID;

            var promiseGet = roomChartService.sendSMS(model);
            promiseGet.then(function (data, status) {
                $scope.IsSending=false;
                if (data.Status) {
                    parent.popSuccessMessage("SMS sent to User successfully!");
                }
                else
                {
                    parent.popErrorMessage(  "Error occured while sending the SMS!");
                }

            },
                function (error, status) {
                    $scope.IsSending=false;
                    parent.popErrorMessage(error.Message);
                    scrollPageOnTop();
                });

        };

        //OpenInterProperty
        $scope.OpenInterProperty = function(reservationId){
            $scope.SelectedReservationId =     reservationId;    
            $scope.ToPropertyId ='';
            $scope.ReservationInterPropertyTransferRemark='';

            scrollPageOnTop();
            $("#actionReservationModel").modal('hide');
            $("#InterPropertyPOP").modal('show');
        }

        $scope.PropertyGroups = [];
        $scope.GetPropertyGroupByPropertyId = function () {
            if($scope.PropertyGroups.length>0)
            {
                return;
            }
            roomChartService.GetPropertyGroupByPropertyId($scope.PropertyID)
                   .then(function (result) {
                       $scope.PropertyGroups = result.Collection;
                   }, function (err) {
                       msg(err.Message);
                   });
        };
        $scope.GetPropertyGroupByPropertyId();
        //ReservationInterPropertyTransfer
        $scope.SelectedReservationId='';
        $scope.TransferReservation = function(reservationId){

            if(!$scope.SelectedReservationId)
            {
                parent.popErrorMessage(  "Please Select Reservation.");
                return;
            }
            if(!$scope.ToPropertyId)
            {
                parent.popErrorMessage(  "Please Select Property.");
                return;
            }

            var strDelete = DeletePopup("Are you sure you want to Transfer Reservation?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {
                            ret = true;
                            
                            var model={};
                            model.ReservationId = $scope.SelectedReservationId;
                            model.ToPropertyId=$scope.ToPropertyId;
                            model.TransferDate=$scope.MinDate;
                            model.Remark=$scope.ReservationInterPropertyTransferRemark;
                            model.ModifiedBy = $scope.UserName;
                            model.PropertyID = $scope.PropertyID;

                            var promiseGet = roomChartService.SaveReservationInterPropertyTransfer(model);
                            promiseGet.then(function (data, status) {
                                $scope.UpdateRoomChartReservationDelete($scope.SelectedReservationId);
                                parent.popSuccessMessage(data.Data);
                                $("#InterPropertyPOP").modal('hide');
                            },
                                function (error, status) {
                                    parent.popErrorMessage(error.responseJSON.Message);
                                    scrollPageOnTop();
                                });
                            $.fancybox.close();
                        });
                }
            });

        }
        
        //CheckIN
        //OpenInterProperty
        $scope.OpenInterPropertyCheckIN = function(){
            
            $scope.ToPropertyId ='';
            $scope.CheckINGuestRoomInterPropertyTransferRemark='';
            scrollPageOnTop();
            $("#InterPropertyPOPCheckIN").modal('show');
            $("#actionCheckINModel").modal('hide');
        }

       
        //ReservationInterPropertyTransfer
        $scope.TransferCheckIN = function(){
            
            if(!$scope.Model.FromRoomDay.CurrentCheckINGuests)
            {
                parent.popErrorMessage(  "Please Select Room.");
                return;
            }
            var checkINGuestRoomId = $scope.Model.FromRoomDay.CurrentCheckINGuests[0].CheckINGuestRoom.Id;

            if(!checkINGuestRoomId)
            {
                parent.popErrorMessage("Please Select Room.");
                return;
            }

            if(!$scope.ToPropertyId)
            {
                parent.popErrorMessage(  "Please Select Property.");
                return;
            }

            var strDelete = DeletePopup("Are you sure you want to Transfer Room?");
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel")
                        .click(function () {
                            ret = false;
                            $.fancybox.close();
                        });
                    $("#fancyConfirm_ok")
                        .click(function () {
                            ret = true;
                            var model={};
                            
                            model.CheckINGuestRoomId = checkINGuestRoomId;
                            model.ToPropertyId=$scope.ToPropertyId;
                            model.TransferDate=businessDate;
                            model.Remark=$scope.CheckINGuestRoomInterPropertyTransferRemark;
                            model.ModifiedBy = $scope.UserName;
                            model.PropertyID = $scope.PropertyID;

                            var promiseGet = roomChartService.SaveCheckINGuestRoomInterPropertyTransfer(model);
                            promiseGet.then(function (data, status) {
                                msg(data.Data, true);
                                
                                $scope.UpdateRoomChartCheckINGuestRoomDelete(checkINGuestRoomId);
                                $scope.UpdateRoomChartAvailability();
                                $timeout(function () {
                                    $scope.MonthColMarge();
                                    $scope.ColMarge1();
                                    $scope.HideLoader();
                                    $scope.load1($(".followMeBar"));
                                }, 300); 
                                $("#InterPropertyPOPCheckIN").modal('hide');
                            },
                                function (error, status) {
                                    $scope.getOccupiedRooms();
                                    parent.popErrorMessage(error.responseJSON.Message);
                                    scrollPageOnTop();
                                });
                            $.fancybox.close();
                        });
                }
            });

        }


        //TODO: Navneet2.0

        $scope.OpenReservation = function () {
            $("#reservationModel").modal('show');
        };
    }
]);
