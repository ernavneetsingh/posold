﻿
app.controller("controller",
[
    "$scope", "service", "$cookies", "$filter", "localStorageService", "$timeout",
    function ($scope, service, $cookies, $filter, localStorageService, $timeout) {

        $scope.PropertyID = localStorageService.get('PropertyId'); $scope.DateFormat = localStorageService.get('DateFormat'); $scope.BusinessDate = localStorageService.get('BusinessDate'); 
        $scope.ModifiedBy = $cookies.get('UserName');
        
        $scope.LoginId = $cookies.get('LoginId');

        
        var date = new Date($scope.BusinessDate.Year, $scope.BusinessDate.Month - 1, $scope.BusinessDate.Day);
        $scope.MinDate = date.getFullYear() + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2);

        $scope.Model = {
            Id: '',
            Code: '',
            FirstName: '',
            LastName: '',
            Address1: '',
            Address2: '',
            City: '',
            StateId: '',
            StateName: '',
            CountryMasterId: '',
            CountryMasterName: '',
            PIN: '',
            Mobile1: '',
            Mobile2: '',
            Email: '',
            DOB: '',
            DOJ: '',
            IsActive: true,
            IsEmployee: '',
            PropertyID: '',
            ModifiedBy: '',
            DateFormat: '',
            items: []
        };

        $scope.IsReadonly = false;
        $scope.MsgNotFound = "";
        $scope.sortingOrder = "Name";
        $scope.pageSizes = [5, 10, 25, 50];
        $scope.reverse = false;
        $scope.filteredItems = [];
        $scope.groupedItems = [];
        $scope.itemsPerPage = 10;
        $scope.pagedItems = [];
        $scope.currentPage = 0;

        $scope.search = function () {
            $scope.filteredItems = $filter("filter")($scope.items, function (item) {
                for (var attr in item) {
                    if (attr === "FirstName") {
                        if (searchMatch(item[attr], $scope.query))
                            return true;
                    }
                }
                
                return false;
            });

            // take care of the sorting order
            if ($scope.sortingOrder !== '') {
                $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
            }
            $scope.currentPage = 0;
            // now group by pages
            $scope.groupToPages();
        };
        var searchMatch = function (haystack, needle) {
            if (!needle) {
                return true;
            }
            return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        };
        $scope.perPage = function () {
            $scope.groupToPages();
        };
        $scope.groupToPages = function () {

            $scope.pagedItems = [];
            $scope.currentPage = 0;
            if ($scope.itemsPerPage === "All") {
                $scope.itemsPerPage = $scope.filteredItems.length;
            }
            for (var i = 0; i < $scope.filteredItems.length; i++) {
                if (i % $scope.itemsPerPage === 0) {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
                } else {
                    $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
                }
            }
            if ($scope.pagedItems.length === 0) {
                $scope.MsgNotFound = "Record Not Found.";
                $scope.pagedItems.length = 1;

            } else {
                $scope.MsgNotFound = "";
            }
        };
        $scope.range = function (start, end) {
            var ret = [];
            if (!end) {
                end = start;
                start = 0;
            }
            for (var i = start; i < end; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };
        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pagedItems.length - 1) {
                $scope.currentPage++;
            }
        };
        $scope.firstPage = function () {
            $scope.currentPage = 0;
        }
        $scope.lastPage = function () {
            $scope.currentPage = $scope.pagedItems.length - 1;
        }
        $scope.setPage = function () {
            $scope.currentPage = this.n;
        };
        $scope.sort_by = function (newSortingOrder) {
            
            if ($scope.sortingOrder === newSortingOrder)
                $scope.reverse = !$scope.reverse;

            $scope.sortingOrder = newSortingOrder;
        };

        getData();
        function getData() {
            var promiseGet = service.getData($scope.PropertyID);
            promiseGet.then(function (data) {
                $scope.items = data;
                $scope.search();
            }, function (data) {
                parent.failureMessage(data.message);
            });

        };

        GetAllCountry();
        function GetAllCountry() {
            var promiseGet = service.getAllCountry();
            promiseGet.then(function (data) {
                $scope.Countries = data;
            }, function (data) {
                parent.failureMessage(data.Message);
            });
        }

        $scope.CountryChange = function (selectedModelCountry) {
            

            $scope.SelectedModelCountry = [];
            $scope.States = [];
            $scope.Model.StateId = $scope.Model.StateIdStore;
            $scope.Model.StateIdStore = "";
            if (selectedModelCountry != null) {
                $scope.SelectedModelCountry = selectedModelCountry;

                var promiseGet = service.getAllState(selectedModelCountry.CountryMasterId);
                promiseGet.then(function (data) {
                    
                    $scope.States = data.Collection;
                }, function (error) {
                    
                    parent.failureMessage(error.Message);
                });
            }
        };

        $scope.Save = function (model, form) {
            
            if ($scope[form].$valid) {
                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;
                var status = service.save(model);
                status.then(function (result) {
                    
                    if (result.Status == true) {
                        var msg1 = model.FirstName + ' ' + result.Message;
                        parent.successMessage(msg1);
                        getData();
                        scrollPageOnTop();
                    }
                    $scope.Reset();
                }, function (error) {
                    
                    scrollPageOnTop();
                    parent.failureMessage(error.Message);
                });
            } else {
                $scope.ShowErrorMessage = true;
            }
        }
        $scope.Remove = function (model) {
            var strDelete = DeletePopup("Are you sure to delete " + model.Name);
            var ret;
            $.fancybox({
                'modal': true,
                'content': strDelete,
                'afterShow': function () {
                    $("#fancyconfirm_cancel").click(function () {
                        ret = false;
                        $.fancybox.close();
                    });
                    $("#fancyConfirm_ok").click(function () {
                        ret = true;
                        var status = service.remove(model.Id);
                        status.then(function (model) {
                            
                            parent.successMessage("Record Successfully deleted.");
                            getData();
                        });
                        $.fancybox.close();
                    });
                }
            });
        }
        $scope.ChangeStatus = function (model) {
            
            model.PropertyID = $scope.PropertyID;
            model.ModifiedBy = $scope.ModifiedBy;

            var promiseGet = service.statusChange(model);
            promiseGet.then(function (data, status) {
                getData();
                if (data.Status) {
                    parent.successMessage(data.Message);
                }
            }, function (error, status) {
                parent.failureMessage(error.Message);
            });
            scrollPageOnTop();
        };
        $scope.SelectedUnitTypeId = "";
        $scope.Edit = function (model) {
            
            $scope.Model = model;
            $scope.Model.CountryMasterId = model.CountryMasterId.toString();
            $scope.Model.StateIdStore = model.StateId.toString();
            $scope.CountryChange({ CountryMasterId: model.CountryMasterId });
            $scope.IsReadonly = true;
            $scope.Model.IsActive = model.IsActive;
            scrollPageOnTop();
        }
        $scope.Reset = function () {
            $scope.Model = {};
            $scope.Model.IsActive = true;
            $scope.IsReadonly = false;
            $scope.query = "";
            getData();
            scrollPageOnTop();
        }
        $scope.IsCodeExist = function (model) {

            if (model.Code.toString().length > 0) {
                model.PropertyID = $scope.PropertyID;
                model.ModifiedBy = $scope.ModifiedBy;

                var promiseGet = service.isCodeExist($scope.PropertyID, model.Code);
                promiseGet.then(function (data) {
                },
                    function (error) {

                        $scope.Model.Code = "";
                        parent.failureMessage("Code is already exist");

                        scrollPageOnTop();
                        $scope.focusElement = "Code";
                    });
            }
        };
    }
]);
