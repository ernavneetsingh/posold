﻿
app.controller("PaymentTermController", ["$scope", "PaymentTermService", "$filter",
   function ($scope, service, $filter) {

       $scope.reset = function () {
           $scope.model = { IsActive: true };
           $scope.getAllPaymentTerms();
           $scope.query = '';
           $scope.IsReadonly = false;
       };
       $scope.save = function (f) {
           if (!$scope[f].$valid) {
               $scope.ShowErrorMessage = true;
               return;
           }
           $scope.model.PropertyID = $scope.PropertyID;
           $scope.model.ModifiedBy = $scope.ModifiedBy;
           $scope.IsSaving = true;

           service.save($scope.model)
               .then(function (s) {
                   msg(s.Message, true);
                   $scope.reset();
               }, function (e) {
                   msg(e.Message);
               }).finally(function () {
                   $scope.IsSaving = false;
               });
       };
       $scope.getAllPaymentTerms = function () {

           service.getAllPaymentTerms($scope.PropertyID)
               .then(function (s) {
                   $scope.items = s.Collection;
                   $scope.search();
               }, function (e) {
                   msg(e.Message);
               });
       };
       $scope.fillData = function (record) {
           $scope.model = angular.copy(record);
           $scope.IsReadonly = true;
       };
       $scope.changeStatus = function (item) {
           item.PropertyID = $scope.PropertyID;
           item.ModifiedBy = $scope.ModifiedBy;
           service.changeStatus(item).then(function (s) {
               msg(s.Message, true);
               $scope.getAllPaymentTerms();
           });
       };
       $scope.codeChange = function () {
           if (!$scope.model.Code || $scope.model.Code.length < 1) return;
           service.isCodeExist($scope.PropertyID, $scope.model.Code)
               .then(function (s) {
                   if (s.Status === true) {
                       $scope.model.Code = '';
                       msg("Error! Code already exists.");
                   }
               }, function (e) {
                   msg(e.Message);
               });
       };

       $scope.search = function () {
           $scope.filteredItems = $filter("filter")($scope.items, function (item) {
               for (var attr in item) {
                   if (attr === "Code" || attr === "Name") {
                       if (searchMatch(item[attr], $scope.query))
                           return true;
                   }
               }
               return false;
           });
           if ($scope.sortingOrder !== '') {
               $scope.filteredItems = $filter("orderBy")($scope.filteredItems, $scope.sortingOrder, $scope.reverse);
           }
           $scope.currentPage = 0;
           groupToPages($scope);
       };
       $scope.pageSizes = [5, 10, 25, 50];
       $scope.perPage = function () {
           groupToPages($scope);
       };
       $scope.prevPage = function () {
           if ($scope.currentPage > 0) {
               $scope.currentPage--;
           }
       };
       $scope.nextPage = function () {
           if ($scope.currentPage < $scope.pagedItems.length - 1) {
               $scope.currentPage++;
           }
       };
       $scope.firstPage = function () {
           $scope.currentPage = 0;
       };
       $scope.lastPage = function () {
           $scope.currentPage = $scope.pagedItems.length - 1;

       };
       $scope.range = function (start, end) {
           var ret = [];
           if (!end) {
               end = start;
               start = 0;
           }
           for (var i = start; i < end; i++) {
               ret.push(i);
           }
           return ret;
       };
       $scope.setPage = function () {
           $scope.currentPage = this.n;
       };

       $scope.reset();

   }
]);
