﻿
app.controller('SendAriController', [
    '$scope', '$cookies', 'SendAriService', 'localStorageService', '$http', '$q', '$filter', function (
        $scope, $cookies, service, localStorageService, $http, $q, $filter) {

        $scope.ModifiedDate = $filter('date')(new Date(), 'yyyy-MM-dd');

        $scope.getRoomTypes = function () {
            service.getRoomTypes($scope.PropertyID)
                .then(function (s) {
                    $scope.RoomTypes = s.Collection;
                });
        };
        $scope.getRateTypes = function () {
            service.getRateTypes($scope.PropertyID)
                .then(function (s) {
                    $scope.RateTypes = s.Collection;
                });
        };
        $scope.getPropertyChannelManager = function () {
            service.getPropertyChannelManager($scope.PropertyID)
                .then(function (s) {
                    $scope.PropertyChannelManager = s.Data;
                });
        };

        $scope.save = function (form) {

            if (!$scope.PropertyChannelManager) {
                msg('ChannelManager not found for this property.');
                return;
            }
            if (!$scope[form].$valid) {
                $scope.ShowErrorMessage = true;
                return;
            }
            $scope.IsSaving = true;

            $scope.model.PropertyID = $scope.PropertyID;
            $scope.model.ModifiedBy = $scope.ModifiedBy;
            $scope.model.ModifiedDate = $scope.ModifiedDate;
            $scope.model.Path = $scope.PropertyChannelManager.Url + ($scope.PropertyChannelManager.PushAriUrl ? $scope.PropertyChannelManager.PushAriUrl : '') + '/' + $scope.PropertyID;
            $scope.model.cmCode = $scope.PropertyChannelManager.Code;
            $scope.model.IsPosAri = $scope.PropertyChannelManager.IsPosAri;
            $scope.model.PmsCode = $scope.PropertyChannelManager.PmsCode;
            $scope.model.HotelCode = $scope.PropertyChannelManager.HotelCode;
            $scope.model.UserName = $scope.PropertyChannelManager.UserName;
            $scope.model.Password = $scope.PropertyChannelManager.Password;

            service.save(//$scope.model.Path //$scope.PropertyChannelManager.Url + ($scope.PropertyChannelManager.PushAriUrl ? $scope.PropertyChannelManager.PushAriUrl : '')
                //+ '/' + $scope.PropertyID,
               $scope.model)
                .then(function (s) {
                    msg(s.Message, true);
                }, function (e) {
                    msg("Error : unable to save : " + e.Message);
                }).finally(function () {
                    $scope.IsSaving = false;
                });
        };
        $scope.reset = function () {

            //    $scope.KitchenId = '';
            //    $scope.fromDate = '';
            //    $scope.toDate = '';
            //    $scope.SelectedMenuGroupTypes = [];
            //    $scope.SelectedMenuCategorys = [];
            //    $scope.IncludeNC = false;
            $scope.model = {};
            //    //$scope.model.SalesBasedCostingTypeId = 1;
            //    //$scope.SalesBasedCostingItems = [];
            //    //$scope.IsEdit = false;
            //    $scope.items = [];
            //    $scope.search();
        };

        $scope.getRoomTypes();
        $scope.getRateTypes();
        $scope.getPropertyChannelManager();
        $scope.reset();

    }
]);
