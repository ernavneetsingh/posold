﻿
"use strict";

(function () {

    function service($http, $q) {

        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";
        var model = [];

        var getAllCurrency = function () {

            var url = apiPath + 'referencedata/currency';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllRoomType = function (propertyid) {
            var url = apiPath + 'frontoffice/RoomType/GetAllByPropertyId/?propertyId=' + propertyid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllRateMaster = function (propertyid) {
            var url = apiPath + 'frontoffice/RateMaster/GetAllByRateTypeId/1/' + propertyid;
            //var url = apiPath + 'frontoffice/RateMaster/GetAllByPropertyId/' + propertyid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllMarketSegment = function (propertyid) {
            var url = apiPath + 'frontoffice/MarketSegment/details/' + propertyid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllBusinessSource = function (propertyid) {
            var url = apiPath + 'GlobalSetting/businessSource/details/' + propertyid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllMealPlan = function () {
            var url = apiPath + 'referencedata/mealplan';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllSalutation = function () {
            var url = apiPath + 'referencedata/salutation';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllPaymentMode = function (propertyId) {
            var url = apiPath + 'GlobalSetting/SettlementMode/allByModuleId/' + propertyId + '/1';
            //var url = apiPath + 'GlobalSetting/RevenueHead/revenuedetails/' + propertyId + '/5';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var getAllCountry = function () {
            var url = apiPath + 'referencedata/country';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getAllState(id) {
            var url = apiPath + 'referencedata/state/' + id;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var getDefaultSetting = function (propertyid) {

            var url = apiPath + 'GlobalSetting/DefaultSetting/Details/' + propertyid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {

                deferred.resolve(result.Data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var save = function (model) {
            var url = apiPath + 'GlobalSetting/DefaultSetting/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }

        var GetRoundOff = function () {
            var url = apiPath + 'ReferenceConstant/RoundOffType/all';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };
        return {
            dataModel: model,
            getAllCurrency: getAllCurrency,
            getAllRoomType: getAllRoomType,
            getAllRateMaster: getAllRateMaster,
            getAllMarketSegment: getAllMarketSegment,
            getAllBusinessSource: getAllBusinessSource,
            getAllMealPlan: getAllMealPlan,
            getAllSalutation: getAllSalutation,
            getAllCountry: getAllCountry,
            getAllState: getAllState,
            getDefaultSetting: getDefaultSetting,
            getAllPaymentMode: getAllPaymentMode,
            save: save,
            GetRoundOff: GetRoundOff,
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
