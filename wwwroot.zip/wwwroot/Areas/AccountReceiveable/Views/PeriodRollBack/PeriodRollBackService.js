﻿


app.service("periodRollBackService", function () {
    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    this.Get = function (propertyId, dateFormat) {
        return httpCaller(apiPath + "AccountReceiveable/PeriodRollBack/all/" + propertyId + "/" + dateFormat, $http, $q);
        //return $.ajax({
        //    type: "GET",
        //    url: apiPath + "AccountReceiveable/PeriodRollBack/all/" + propertyId + "/" + dateFormat,
        //    params: {},           
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) {
                
        //        parent.failureMessage("Error!\n" + data.responseJSON.Message);
        //        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);
        //    }
        //});

    };
    this.Save = function (model) {
        return httpPoster(apiPath + "AccountReceiveable/PeriodRollBack/save/", $http, $q, model);
        //return $.ajax({
        //    type: "POST",
        //    url: apiPath + "AccountReceiveable/PeriodRollBack/save/",
        //    data: JSON.stringify(model),            
        //    dataType: "json",
        //    headers: { 'duxtechApiKey': accessToken },
        //    contentType: "application/json; charset=utf-8",
        //    success: function () {
        //    },
        //    error: function (data) { parent.failureMessage("Error!\n" + data.responseJSON.Message); }
        //});

    };
});