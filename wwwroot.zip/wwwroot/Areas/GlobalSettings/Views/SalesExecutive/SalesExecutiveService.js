﻿
'use strict';

(function () {

    function service($http, $q) {
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        var getData = function (propertyId, all) {
            
            var url = apiPath + 'GlobalSetting/SalesExecutive/GetAllByPropertyId?propertyId=' + propertyId + "&all=" + all;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                
                deferred.resolve(result.Collection);
            }).error(function (err) {
                
                deferred.reject(err);
            });
            return deferred.promise;

        };
        var getAllCountry = function () {
            var url = apiPath + 'referencedata/country';
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                deferred.resolve(result.Collection);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        function getAllState(countryid) {
            var url = apiPath + 'referencedata/state/' + countryid;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data) {
                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var save = function (model) {
            
            var url = apiPath + 'GlobalSetting/SalesExecutive/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };
        var remove = function (id) {
            
            var url = apiPath + 'GlobalSetting/SalesExecutive/delete/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {
                
                parent.failureMessage(data.Message);
                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;

        };

        var statusChange = function (model) {
            
            var url = apiPath + 'GlobalSetting/SalesExecutive/status';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;


        };

        var isCodeExist = function (PropertId, code) {
            
            var url = apiPath + 'GlobalSetting/SalesExecutive/IsCodeExist/' + PropertId + "/" + code;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    
                    deferred.resolve(data);
                })
                .error(function (err, status) {

                    deferred.reject(err);
                });
            return deferred.promise;
        };
        var isEmailExist = function (PropertId, email, id) {
            
            return httpPoster(apiPath + "GlobalSetting/SalesExecutive/IsEmailExist/" + PropertId + "?email=" + email + "&id=" + id, $http, $q);
        };
        var isMobile1Exist = function (PropertId, mobile, id) {
            return httpPoster(apiPath + "GlobalSetting/SalesExecutive/IsMobile1Exist/" + PropertId + "?mobile=" + mobile + "&id=" + id, $http, $q);
        };

        return {
            getData: getData,
            getAllCountry: getAllCountry,
            getAllState: getAllState,
            save: save,
            remove: remove,
            statusChange: statusChange,
            isCodeExist: isCodeExist,
            isEmailExist: isEmailExist,
            isMobile1Exist: isMobile1Exist

        };
    }

    app.factory('service', ['$http', '$q', service]);
})();
