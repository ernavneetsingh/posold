﻿"use strict";
(function () {
 
    function loginTouchService($http, $q) {

        var getAllOutlet = function (propertyId) {
            var deferred = $q.defer();
            $http.get(apiPath + "touch/login/" + propertyId)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };
        var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

        //function pOSLoginTouchScreen(model) {
        //    var deferred = $q.defer();
        //    $.ajax({
        //        type: "POST",
        //        url: apiPath + "PointOfSale/Operation/LoginTouchScreen/Request",
        //        data: "{model: " + JSON.stringify(model) + "}",
        //        contentType: "application/json; charset=utf-8",
        //        dataType: "json",
        //        headers: {
        //            'duxtechApiKey': accessToken
        //        },
        //        success: function (response) {
        //            deferred.resolve(response);
        //        },
        //        error: function (error, status, headers, config) {
        //            deferred.reject(error, status, headers, config);
        //        }
        //    });
        //    return deferred.promise;
        //}

        function loginRequest(model) {

            var url = apiPath + "security/login";

            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model
            }).success(function (data) {

                deferred.resolve(data);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        //function loginRequest(model) {
            
        //    var url = apiPath + "security/LoginRequest";

        //    var deferred = $q.defer();
        //    $http({
        //        method: 'POST',
        //        url: url,
        //        data: model
        //    }).success(function (data) {

        //        deferred.resolve(data);
        //    }).error(function (err) {
        //        deferred.reject(err);
        //    });
        //    return deferred.promise;
        //}

        return {
            getAllOutlet: getAllOutlet,
            loginRequest: loginRequest
        };
    }

    apppos.factory("loginTouchService", ["$http", "$q", loginTouchService]);
})();

