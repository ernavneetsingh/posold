﻿"use strict";


(function () {

    var accessToken = "ad65n562dc5t48i4edc4:9k93s278e370c59a08t";

    function service($http, $q) {

        var model = [];
        var getAll = function (options) {
            
            var url = apiPath + "configuration/UserProduct?currentPage=" + options.currentPage + "&" +
              "recordsPerPage=" + options.recordsPerPage + "&" +
             "sortKey=" + options.sortKeyOrder.key + "&" + "sortOrder=" + options.sortKeyOrder.order + "&searchfor=" + options.searchfor;
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: url,
                data: options,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (result) {
                angular.copy(result.Collection, model);
                deferred.resolve(result.RecordCount);
            }).error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;

        };

        var changeStatus = function (id) {

            var url = apiPath + 'configuration/userproduct/status/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var changeApproved = function (id) {

            var url = apiPath + 'configuration/UserProduct/approved/'+ id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var changeLocked = function (id) {

            var url = apiPath + 'configuration/userproduct/locked/' + id;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: {},
                 headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            })
                .success(function (data) {
                    deferred.resolve(data);

                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var save = function (model) {
            var url = apiPath + 'configuration/userproduct/save';
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: model,
                headers: { 'duxtechApiKey': accessToken },
                contentType: "application/json; charset=utf-8"
            }).success(function (data, status, headers, cfg) {
                deferred.resolve(data);

            }).error(function (data, status, headers, config) {

                deferred.reject(data, status, headers, config);
            });
            return deferred.promise;
        }


        var getGetById = function (id) {
            var deferred = $q.defer();
            $http.get(apiPath + "configuration/UserProduct/GetById/" + id)
                .then(function (result) {
                    deferred.resolve(result.data);
                },
                    function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config);
                    });
            return deferred.promise;
        };

        return {
            dataModel: model,
            getAll:getAll,
            changeStatus: changeStatus,
            changeApproved: changeApproved,
            changeLocked: changeLocked,
            save: save,
            getGetById: getGetById,
        };
    }

    app.factory('service', ['$http', '$q', service]);
})();

